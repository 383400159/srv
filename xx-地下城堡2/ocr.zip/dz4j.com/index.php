
<?php
//echo get_include_path() . PATH_SEPARATOR;exit;
define('ROOT',dirname(__FILE__).'/');
//error_reporting(E_ALL);
//set_include_path(get_include_path() . PATH_SEPARATOR.ROOT );
//require(ROOT.'TesseractOCR/TesseractOCR.php');
$max = 51200;   //文件大小限制
if($_POST['user']=='abcd123456' && $_POST['pwd']=='yu_pw123456'){
       // echo json_encode(array($_POST,$_FILES));exit;
  if($_FILES['img']['error']==0){
    if($_FILES['img']['size']<=$max){
                if(getimagesize($_FILES['img']['tmp_name'])['mime'] === 'image/jpeg'){
                        $digits = false;
                        switch($_POST['type']){
                                //只识别数字
                                case 0:$digits=true;break;
                                //识别中文
                                //识别中文
                                case 1:$lang='chi_sim';break;
                        }
                        //define('ROOT',dirname(__FILE__).'/');
                        //error_reporting(E_ALL);
                        $dir = ROOT.'images/';
                        if (!file_exists($dir) && !mkdir($dir, 0777, true)) {
                                echo '无法创建';
                                exit;
                        }

                        //放大两倍图片
                        $percent = 2;
                        list($width, $height) = getimagesize($_FILES['img']['tmp_name']);
                        $newwidth = $width * $percent;
                        $newheight = $height * $percent;
                        $thumb = imagecreatetruecolor($newwidth, $newheight);
                        $source = imagecreatefrompng($filename);
                        imagecopyresized($thumb, $source, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
                        imagejpg($thumb,$dir.'1.jpg');
                        imagedestroy($thumb);
                        //if(move_uploaded_file($_FILES['img']['tmp_name'],$dir.'1.jpg')){
                                require(ROOT.'TesseractOCR/TesseractOCR.php');
                                $ocr = new TesseractOCR('images/1.jpg');
                                if($digits) $ocr->digits($digits);
                                if($lang) $ocr->lang($lang);
                                $str = $ocr->run();
                                $str = str_replace(' ','',$str);
                                if(!$str) echo '识别不出结果';
                                else echo $str;
                                exit;
                        //}else{
                        //        echo '文件错误';exit;
                        //}


                }else{
                        echo '图片格式错误,只支持jpeg格式';exit;
                }
    }else{
                echo '图片大小不能超过500kb';exit;
    }
  }else{
        echo '接收图片失败';exit;
  }
}else{
        echo '1';
}
