init("0", 0)
windowsX,windowsY = getScreenSize()
gameX,gameY=windowsX/2,windowsY/2
isPriviateMode = isPriviateMode or function() return 1 end

require "yuUtils"
require "bblibs/utils"
local run = require "gameLibs"
run:init()