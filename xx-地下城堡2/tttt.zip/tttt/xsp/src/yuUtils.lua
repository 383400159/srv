local socket = require 'bblibs.socket.socket'
local http = require "bblibs.socket.http"
local ltn12 = require "bblibs.socket.ltn12"

-- 精确延时
function sleep(sec)
	local sec = sec or 1
	sec = sec/1000
    socket.select(nil,nil,sec);
end

--单点比色
--x,y颜色坐标
--c,颜色值
--s,相似度
function findColor2(x,y,c,s)
	local fl,abs = math.floor,math.abs
	local s=s or 95
	local x=x or 0
	local y=y or 0
	local c=c or 0xffffffff
	s = fl(0xff*(100-s)*0.01)
	local r,g,b = fl(c/0x10000),fl(c%0x10000/0x100),fl(c%0x100)
	local rr,gg,bb = getColorRGB(x,y)
	if abs(r-rr)<s and abs(g-gg)<s and abs(b-bb)<s then
			return true
	end
	return false
end

-- 模拟一次按住
function tap2(x, y)
	if x == nil or y==nil then return false end
	math.randomseed(tostring(os.time()):reverse():sub(1, 6))  --设置随机数种子
	local index = math.random(1,5)
	-- x = x + math.random(-2,2)
	-- y = y + math.random(-2,2)
	touchDown(index,x, y)
	sleep(math.random(500,1000))	
	touchUp(index, x, y)
	sleep(100)
	local id = createHUD()
	showHUD(id,'',0,"0x00000000","0xffff0000",0,x,y,10,10)
	sleep(100)
	hideHUD(id)
end

--字符串分割
function split(str, delimiter)
	if str==nil or str=='' or delimiter==nil then
		return nil
	end
	
	local result = {}
	for match in (str..delimiter):gmatch("(.-)"..delimiter) do
		table.insert(result, match)
	end
	return result
end

--随机数
function rand(num1,num2)
	local t1 = num1 or 1
	local t2 = num2 or 100
	math.randomseed(tostring(mTime()):reverse():sub(1, 6))
	return math.random(t1,t2)
end

--显示坐标位置
function showIndex(x,y)
	local id = createHUD()
	showHUD(id,'',0,"0x00000000","0xffff0000",0,x,y,10,10)
	sysLog('showIndex('..x..','..y..')')
	mSleep(1000)
	hideHUD(id)     --隐藏HUD
end

-- 使用multipart/form-data编码进行POST传输（支持文件上传）
-- url string post地址
-- form table post数据
--[[ httpFormPost("dz4j.com/ocr.php",{
	{field="user",body="a123456"},
	{field="pwd",body="abc123345"},
	{filename="a.png",type="image/png",body="a.png",filepath="[public]/b.png"}
})
]]
function httpFormPost(url,form)
    local respbody = {}
	local f_ltn12 = {}
	local f = {}
	local s = ''

	local function _close(t)
	    -- 关闭文件句柄
	    for i,k in pairs(t) do
	    	if io.type(k) == 'file' then
	    		k:close()
	    	end
	    end
	end

	for i,k in pairs(form) do
		if k.field ~= nil and k.body ~= nil and k.field~='' then
			s = s..'--abcd\r\nContent-Disposition: form-data; name="'..k.field..'";'
			if k.filename ~= nil and k.type ~= nil and k.filepath ~= nil then
				s = s..' filename="'..k.filename..'"\r\nContent-Type: '..k.type
				f[i] = assert(io.open(k.filepath,'rb'))
				table.insert(f_ltn12,ltn12.source.file(f[i]))
				k.body = f[i]:read('*a')
			end
			s = s..'\r\n\r\n'..k.body..'\r\n'
		end
	end
	s = s .. [[--abcd--]]..'\r\n'

    local  body, code, headers, status = http.request {
        method = "POST",
        url = url,
        headers = {
            ["Content-Type"] =  "multipart/form-data;boundary=abcd",
            ["Content-Length"] = #s
        },
        source = ltn12.source.cat(ltn12.source.string(s),unpack(f_ltn12)),
        sink = ltn12.sink.table(respbody),
		protocol = "tlsv1"
    }

	if code == 200 then
		sysLog("请求成功: " .. tostring(respbody[1]))
		_close(f)
		return respbody[1]
	else
		_close(f)
		sysLog(code)
		return false
	end
end

-- OCR识别
-- x1:需要识别的区域左上角x坐标
-- y1:需要识别的区域左上角y坐标
-- x2:需要识别的区域右下角x坐标
-- y2:需要识别的区域右下角y坐标
-- types:识别类型:0,只识别数字;1,识别中文,数字,字母
function ocr(x1, y1, x2, y2,types)
	snapshot("[public]ocr.png", x1, y1, x2, y2)
	local types = types or 0

	local postdata = httpFormPost("http://jinquanfz.com/dz4j.com/ocr.php",{
		{field="img",filename="ocr.png",type="image/png",body="ocr.png",filepath="[public]/ocr.png"},
		{field="type",body=types},
		{field="user",body="abcd123456"},
		{field="pwd",body="yu_pw123456"},
	})
	return postdata
end

-- 四舍五入
function found(n)
	local n = n or 0
	return math.floor(n*100+0.5)*0.01
end

-- 自定义路线处理成table
-- 例:w12d21s14a6a8=>{{w,12},{d,21}}
function path_split(str)
	if str==false or str=='' or str==nil then
		return false
	end
	
	local result = {}
	for o,n in str:gmatch('(%a)(%d+)') do
		n = tonumber(n)
		if o == nil or n == nil then
			return false
		else
			table.insert(result,{o,n})
		end
		
	end
	return result
end