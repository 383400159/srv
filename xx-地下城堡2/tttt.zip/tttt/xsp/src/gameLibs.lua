local colordata
local config = require 'config'

if windowsX==750 then
	colordata = require "6s-data"
else
	dialog('该分辨率不支持')
	lua_exit()
end

local Dxcb={
	_version = '0.1.99'
}

-- 初始化
function Dxcb:init()
	config._state = 0
	config._lv = 8                               -- 当前地图初始化,9图
	config._warnfood = 350                       -- 报警食物初始化
	config._block = 25                           -- iphone 6s
	config._diymap = path_split('w12d21s14a6a8') -- 自定义路线初始化
	config._dig = true                           -- 开启挖矿
	config._thisfood = 1000                      -- 当前食物初始化
	self:set_usefood()                           -- 消耗食物初始化

	------------ 初始化结束 -----------
	sysLog("开始自定义路线")
	self:diyMap()
end

--设置消耗食物
function Dxcb:set_usefood()
  if config._lv==0 or config._lv==1 then config._usefood = 1
  elseif config._lv==2 or config._lv==3 then config._usefood = 2
  elseif config._lv==4 or config._lv==5 or config._lv==6 then config._usefood = 3
  elseif config._lv==7 or config._lv==8 or config._lv==9 then config._usefood = 4
  -- 10-16
  elseif config._lv==10 or config._lv==11 or config._lv==12 or config._lv==13 then config._usefood = 5
  elseif config._lv==14 then config._usefood = 6
  elseif config._lv==15 then config._usefood = 8
  else dialog("地图错误") lua_exit() end
end

-- 是否移动了
function Dxcb:isMove()
  local x,y = gameX+100,gameY+100
  local color = getColor(x,y)
  sleep(1000)
  if color == getColor(x,y) then return false
  else return true end
end

-- 走路处理
function Dxcb:moveEvent(fun)
	-- 移动事件回调
	if fun then
		return fun()
	else
		while true do
			-- 移动事件结束
			if self:isMove()==false then
				break
			end
		end

		return self:battle()
	end
end

-- 获取食物
function Dxcb:getFood()
	-- 83,88,159,117
	local x,y = findColorInRegionFuzzy(0xc7c3c2,90,unpack(colordata[12]))
	if x>-1 then
		local st = os.clock()
		local food = ocr(unpack(colordata[12]))
		local pr
		food = tonumber(food)
		pr = food
		if food == nil then food = -1 pr=0 end
		sysLog('食物量：'..pr..'耗时：'..os.clock()-st)
		return food
	else
		return 0
	end
end

-- 步数转食物量
-- step:需要转换的步数
function Dxcb:stepToFood(step)
	local step = step or 0
	return step*config._usefood
end

--更新食物
--step:步数
function Dxcb:update(step)
	local step = step
	if step == nil and not self:isBattle() then
		local food = self:getFood()
		if food >=0 then
			config._thisfood = food
		end
		
	else
		-- 步数转食物量
		step = self:stepToFood(step)
		config._thisfood = config._thisfood - step
	end

	sysLog('当前食物量：'..config._thisfood)
	toast("当前食物量："..config._thisfood)
	
	-- 剩余步数
	if config._thisfood <= config._warnfood then
		sysLog('食物过低')
		config._state=3
	else
		sysLog('食物正常')
	end
end

-- 是否战斗状态
function Dxcb:isBattle()
	-- keepScreen(true)
	if config._state == 3 or config._state == 0 then
		--if windowsX == 1242 then
		local x,y = findColor(unpack(colordata[35]))
		if x > -1 then
			sysLog('不是战斗状态')
			return false
		else
			sysLog('是战斗状态')
			return true
		end
	end
end

-- 是否关卡处理界面
function Dxcb:isLevelUi()
	local x,y = findColor(colordata[23][1],"0|0|0xf6f6f6",90,0,0,0)
	return x>-1
end

--关卡选项处理
function Dxcb:lvSel()
  -- 重写关卡处理
	local colortab = colordata[7]
	local level = function()
		keepScreen(true)
		if self:isLevelUi() then
			-- 开启打英灵就找是否英灵界面 如果是就点第一个
			if false then
				tap(colortab[4][1],colortab[4][2])
			else
				sysLog("是关卡界面,进行点击")
				if findColor2(unpack(colortab[1])) then
					-- 存在最后一种就往下拉再点击
					swip(gameX,gameY,gameX,100)
					sleep(700)
					tap(colortab[1][1],colortab[1][2])

				elseif findColor2(unpack(colortab[2])) then
					tap(colortab[2][1],colortab[2][2])

				elseif findColor2(unpack(colortab[3])) then
					tap(colortab[3][1],colortab[3][2])

				elseif findColor2(unpack(colortab[4])) then
					tap(colortab[4][1],colortab[4][2])
				end
			end

		end
		keepScreen(false)
		sleep(200)
	end

	sleep(500)
	if config._state==3 then
		sysLog('回家')
	elseif config._dig and self:isOreUI() then
		sysLog('点击矿石')
		tap(colortab[4][1],colortab[4][2])
		sleep(200)
		if self:isOreUI() then tap(colortab[3][1],colortab[3][2]) sleep(200) end
		return self:booty()
	else
		level()
	end
end

-- 是否矿石界面
function Dxcb:isOreUI()
	local x,y
	x, y = findColor(unpack(colordata[23]))
	if x > -1 then
		sysLog('是矿石界面')
		return true
	else
		return false
	end
end

-- 掉落检测
function Dxcb:booty()
  -- 重写掉落
	if not self:isBattleing() then
		local taptab = colordata[9]
		  -- keepScreen(true)
		if findColor2(unpack(taptab[1])) and findColor2(unpack(taptab[2])) then

			tap(taptab[1][1],taptab[1][2])
			sleep(1000)
			if findColor2(unpack(taptab[2])) then
				tap(taptab[2][1],taptab[2][2])
			end
			-- keepScreen(false)
			return true
		end
	end

end

-- 是否战斗中
function Dxcb:isBattleing()
	local function _is(data)
		local x,y = findColor(data,"0|0|0xcc0100",95,0,0,0)
		return x>-1
	end
	
	if _is(colordata[26][1]) or _is(colordata[26][2]) then
		sysLog('正在战斗')
		return true
	else
		sysLog('不在战斗')
		return false
	end
end

--战斗处理
function Dxcb:battle()
	if config._state~=2 then
		sysLog('战斗处理')
		toast("战斗处理")
		sleep(500)
		while self:isBattle() do
			if config._state==2 then break end
			self:booty()	--处理掉落
			sleep(200)
			self:lvSel()	--处理关卡选项
		end
		sleep(500)
		if self:isMove() or self:isBattle() then
			return self:battle()
		else
			-- 回家状态不更新
			if config._state==0 then
				return self:update()
			end
		end
	end
end

-- 重写寻怪
function Dxcb:findBeast(ty)
	toast("正在寻怪")
	sysLog("正在寻怪,当前状态:" .. config._state)
	if config._state == 0 then
		if config._thisfood>config._warnfood then
			local tab_beast,count = colordata[4]
			local ty = ty or 0 --0：搜索全部；1：只搜索火把内
			if ty==0 then count = #tab_beast else count = 2 end
			keepScreen(true)
			for i=1,count do
				local x,y = findColor(unpack(tab_beast[i]))
				if x>-1 then
					-- showIndex(x,y)
					sysLog('找到怪物')
					toast("找到怪物")
					tap2(x,y)
					keepScreen(false)
					self:moveEvent()
					return true
				end
			end
			keepScreen(false)
			return false
		else
			sysLog("当前食物过低")
			toast("当前食物过低,回家")
			config._state = 3
			return false
		end
	else
		return false
	end
end

-- 搜索矿石
function Dxcb:findOre()
	if config._dig and config._state==0 then
		local ore = colordata[22]
		local x,y
		keepScreen(true)
		for i=1,2 do
			x, y = findColor(unpack(ore[i]))
			if x > -1 then
				break
			end
		end
		if x>-1 then
			tap2(x,y)
			toast('找到矿石')
			keepScreen(false)
			self:moveEvent()
			return true
		else
			keepScreen(false)
			sysLog('没找到')
			return false
		end
	end
end

-- 字母方向转数字方向
function Dxcb:letterToNumber(d)
	if d == 'w' then
		return 1
	elseif d == 's' then
		return 2
	elseif d == 'a' then
		return 3
	else
		return 4
	end
end

-- 移动方向转坐标
-- step:移动的步数
-- d:方向,1上2下3左4右
function Dxcb:dirToAxis(step,d)
	if config._state == 0 or config._state == 3 then
		local step = step or 10
		local d = d or 1
		if type(d) == 'string' then
			d = self:letterToNumber(d)
		end
		
		local x,y=gameX,gameY
		local str
		if step>15 then step=15 end
		if d==1 then
			y=windowsY-(step*config._block+gameY)+10
			str = '向上移动'..step..'步的坐标为('
		elseif d==2 then
			y=gameY+step*config._block-10
			str = '向下移动'..step..'步的坐标为('
		elseif d==3 then
			x=windowsX-(step*config._block+gameX)
			str = '向左移动'..step..'步的坐标为('
		else
			x=gameX+step*config._block
			str = '向右移动'..step..'步的坐标为('
		end
		
		if y>=windowsY then
			y=windowsY-10
		elseif y<0 then
			y=10
		end
		
		if x>=windowsX then
			x=windowsX-10
		elseif x<0 then
			x=10
		end
		sysLog(str..x..','..y..')')

		return x,y
	end
end

-- 自定义路线
function Dxcb:diyMap()
	
	local function refind()
		if config._state == 0 then
			self:findBeast(1)
			self:findOre()
		else
			return false
		end
	end
		
	if config._diymap then

		for _,v in pairs(config._diymap) do
			toast('向'..v[1]..'移动'..v[2]..'步')
			sysLog('向'..v[1]..'移动'..v[2]..'步')
			if config._state==0 then
				tap2(self:dirToAxis(v[2],v[1]))
				self:moveEvent()
				refind()
			else
				break
			end
		end
		sysLog('结束')
		toast('走完')
		config._state = 3
		
		return true

	else
		sysLog('格式错误,请检查路线')
		return false
	end

end


return Dxcb