original-bitcoin
================

This is a historical repository of Satoshi Nakamoto's original bitcoin sourcecode