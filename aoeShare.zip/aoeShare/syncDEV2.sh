#!/bin/bash
cd /home/aoeShare/

ls -1 *.lua | awk '{ print "luajit -bg " $1 " /var/aoe_dev2/gameroom/" $1 } ' | sh
ls -1 */*.lua | awk '{ print "luajit -bg " $1 " /var/aoe_dev2/gameroom/" $1 } ' | sh

chown -R feng.staff /var/aoe_dev2/gameroom/*
chmod -R 770 /var/aoe_dev2/gameroom/*
