#!/bin/bash

#/home/aoeShare/sync.sh

ps aux |grep 3003 |grep "main" |awk '{print "sudo kill "$2}' |sh

sleep 1

sudo /var/aoe_w6test/MasterGame.sh
