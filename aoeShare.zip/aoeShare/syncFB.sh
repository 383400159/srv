#!/bin/bash

#cd /home/aoeShare-fb/
#ls -1 *.lua | awk '{ print "luajit -bg " $1 " /var/aoe_fb/gameroom/" $1 } ' | sh
