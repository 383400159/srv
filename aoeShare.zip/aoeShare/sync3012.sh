#!/bin/bash
cd /home/aoeShare/
ls -1 *.lua | awk '{ print "luajit -bg " $1 " /var/aoe_pvp2/gameroom/" $1 } ' | sh
ls -1 */*.lua | awk '{ print "luajit -bg " $1 " /var/aoe_pvp2/gameroom/" $1 } ' | sh

cd /var/aoe_pvp2/
./kill.sh
#ps aux |grep 3010 |grep "main" |awk '{print "sudo kill "$2}' |sh
#./MasterGame.sh
