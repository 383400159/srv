local SBossInWorld8007 = class("SBossInWorld8007", require("gameroomcore.SHeroBase"))

function SBossInWorld8007:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld8007.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SBossInWorld8007