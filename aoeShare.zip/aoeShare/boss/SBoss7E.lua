local SBoss7E = class("SBoss7E", require("gameroom.boss.SBoss3B")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss7E:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss7E" 
	end 

	SBoss7E.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		----debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
end 


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss7E:prepareHit(mode,adjTime,buff)  


	local hitValueBoth=SBoss7E.super.prepareHit(self,mode,adjTime,buff) 



	if mode==16  or  mode==19 then
		self.modeatklist={}
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		self:D("boss释放精准打击........",self.world.cjson.encode(parameters))
		local teamlist = {}
		local visRange = {posX=self.posX,posY=self.posY,radius=(parameters.JZDJDIS/self.world.setting.AdjustAttRange)}
		local dlist = {}
		--TARGETNUMMIN=2;TARGETNUNMAX=5
		local TARGETNUM =  self.world.formula:getRandnum(parameters.TARGETNUMMIN,parameters.TARGETNUNMAX)
		self:D("机器人 TARGETNUM:",TARGETNUM)
		local atknum = TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if (obj.attribute.roleId%5==2) then ok=false end
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
					if (d>=0) then 
						-- dlist[#dlist+1] = obj   
						dlist[#dlist+1]={itemID=obj.itemID,DIS=d}  
					end
				end
			end
		end
		)

		-- dlist=table.shuffle(dlist)
		if #dlist>1 then
			self.world.tSort(dlist,function( a1,b1 )
				return a1['DIS'] > b1['DIS']
			end)
		end

		local newDlist = {}
		for i=1,atknum do
			newDlist[#newDlist+1] = dlist[1]
		end

		if #newDlist>0 then
			--debuglog("机器人有目标 dlist:"..#dlist)
			for k,v in pairs(newDlist) do
				local obj = self.world.allItemList[v.itemID] 
				local d = self:distance(obj.posX,obj.posY)
				local FLYTIME = (d*self.world.setting.AdjustAttRange)/skill.bulletSpeed
				local attributes = table.deepcopy(hitValueBoth)
				if parameters.RANGE==nil then
					self:directHurtToDalay(mode,obj.itemID,attributes,parameters['HITTIME'..k]+FLYTIME)
				else
					self:directFightAuratoDalay(mode,obj.itemID,attributes,{posX=obj.posX,posY=obj.posY,RANGE=parameters.RANGE},parameters['HITTIME'..k]+FLYTIME) 
				end


				self.modeatklist[#self.modeatklist+1]=obj.itemID..","..parameters['HITTIME'..k]..","..FLYTIME
				if parameters.ADDJZDJSTATUS~=nil then
					local obj1 = self.world.allItemList[obj.itemID] 
					obj1:addStatusList({s=parameters.ADDJZDJSTATUS,r=self.world:getGameTime(),t=parameters.ADDJZDJSTATUSTIME,i=self.itemID})	
					--self:D("机器人 精准打击 是不是加了:",parameters5.ADDSTATUS2,parameters5.ADDSTATUSTIME2)
				end

			end	
		end

	end

	return hitValueBoth 
end 

--- 准备攻击前置设置，在prepareHit之前执行，call父类
-- @param mode int - 技能1-7
-- @param itemID int - 目标对象itemID
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SBoss7E:prepareSkillAttackCustom(mode,itemID,x,y,adjTime,syncMsg)  

	if (mode==16 or mode==19) and self.modeatklist~=nil and #self.modeatklist>0 then
		syncMsg['a']['p'] = implode(';',self.modeatklist)
		self.modeatklist = {}
	end
	SBoss7E.super.prepareSkillAttackCustom(self,mode,itemID,x,y,adjTime,syncMsg)


end 

return SBoss7E 