local SBoss2A = class("SBoss2A", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss2A:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss2A" 
	end 
	self.creatureList = {}
	self.tpList = {}
	--boss阶段
	self.bossType = 1

	--存储玩家被击中的数量
	self.mode3list={}
	self.modeatklist={}
	SBoss2A.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		----debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end		
	--左天平
	self.mode7Alist = {}
	--右天平
	self.mode7Blist = {}
	--天平外
	self.mode7Clist = {}

	--天平计算时间
	self.mode7time = 0
end 

--boss免控
function SBoss2A:addIMMUNECONTROLBUFF()
	--IMMUNECONTROL_RATE=100

	--debuglog("addIMMUNECONTROLBUFF boss itemID:"..self.itemID)
	-- --debuglog("boss allItemList:"..self.world.cjson.encode(self.world.allItemList[self.itemID]))
	self:callCreateInit()
end


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss2A:prepareHit(mode,adjTime,buff)  

	--80;ADDSTATUS=4026;ADDSTATUSTIME=999;CLEANSELFSTATUS=4024;ADDSTATUS2=41;ADDSTATUSTIME2=7.8;;DIZZYDELAY=2;DIZZY_RATE2=100;BUFFTIME2=3
	if mode==107 then
		local skill = self.attribute.skills[7] 
		local parameters = skill.parameters 
		--local enemy = self:getEnemylist()
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(v)
		 	if self.mode7Alist[""..v['itemID']]==nil and self.mode7Blist[""..v['itemID']]==nil then
				self.mode7Clist[""..v['itemID']]=v['itemID']
			end
			local hitValueNew={}
			hitValueNew['DIZZY_RATE']=parameters.DIZZY_RATE2
			hitValueNew["BUFFTIME"]=parameters.BUFFTIME2
			hitValueNew["INEVITABLEHIT"]=1
			v:directHurt(self.itemID,mode,hitValueNew,0)
			self:D("天平回调 :",v.itemID) 
		end
		)

		-- for k,v in pairs(enemy) do
		-- 	if self.mode7Alist[""..v['itemID']]==nil and self.mode7Blist[""..v['itemID']]==nil then
		-- 		self.mode7Clist[""..v['itemID']]=v['itemID']
		-- 	end
		-- 	local hitValueNew={}
		-- 	hitValueNew['DIZZY_RATE']=parameters.DIZZY_RATE2
		-- 	hitValueNew["BUFFTIME"]=parameters.BUFFTIME2
		-- 	v:directHurt(self.itemID,mode,hitValueNew,0) 
		-- end
		--debuglog("天平 回调 A:"..self.world.cjson.encode(self.mode7Alist).." B:"..self.world.cjson.encode(self.mode7Blist).." C:"..self.world.cjson.encode(self.mode7Clist))
		--需要计算谁重谁轻
		if  table.nums(self.mode7Alist)==table.nums(self.mode7Blist)  then
			local zID = self.tpList[1]
			local zObj  = self.world.allItemList[zID]
			zObj.statusList[4029]=nil
			zObj:addStatusList({s=4029,r=self.world:getGameTime(),t=20,i=self.itemID,p1=1})
			local yID = self.tpList[2]
			local yObj  = self.world.allItemList[yID]
			yObj.statusList[4029]=nil
			yObj:addStatusList({s=4029,r=self.world:getGameTime(),t=20,i=self.itemID,p1=1})
			--debuglog("天平 回调 2边一样重")
		end
		if table.nums(self.mode7Alist)<table.nums(self.mode7Blist) then
			local zID = self.tpList[1]
			local zObj  = self.world.allItemList[zID]
			zObj.statusList[4029]=nil
			zObj:addStatusList({s=4029,r=self.world:getGameTime(),t=20,i=self.itemID,p1=1})
			--debuglog("天平 回调 左边轻")
		end
		if table.nums(self.mode7Alist)>table.nums(self.mode7Blist) then
			local yID = self.tpList[2]
			local yObj  = self.world.allItemList[yID]
			yObj.statusList[4029]=nil
			yObj:addStatusList({s=4029,r=self.world:getGameTime(),t=20,i=self.itemID,p1=1})
			--debuglog("天平 回调 右边轻")
		end
		hitValueBoth =nil

		self:D("天平回调...............")
		return hitValueBoth
	end

	-- if mode==2 then
	-- 	local skill = self.attribute.skills[2] 
	-- 	local parameters = skill.parameters 
		--增加玩家生命封锁特效
		--self:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID})
	-- end

	local hitValueBoth=SBoss2A.super.prepareHit(self,mode,adjTime,buff) 

	--唤生命天平，玩家在限定时间内（3-5秒）必须要走到生命天平两侧，否则：1、生命天平外玩家会受到生命封锁2、生命天平中较重一方会受到生命封锁
	--APADJ=100;ADDSTATUS=4025;ADDSTATUSTIME=5;TRIGGERSTATUS=4026;TRIGGERSTATUSTIME=999;CLEANSELFSTATUS=4024;tpPosx1=132;toPosy1=109;tpID1=115;tpPosx2=132;toPosy2=74;tpID2=115-
	if mode==7 then	
		--去掉召唤生命天平状态
		--self.statusList[4023]=nil
		self.world.tpAIMoveTime = self.world:getGameTime()+99999
		self.mode7Alist={}
		self.mode7Blist={}
		self.mode7Clist={}

		local skill = self.attribute.skills[7] 
		local parameters = skill.parameters 

		--先加2个预警圈
		-- self:addStatusList({s=22,r=self.world:getGameTime(),t=5},skill.hitTime)
		-- self:addStatusList({s=22,r=self.world:getGameTime(),t=5},skill.hitTime)

		--天平坐标
		----debuglog("jaylog SBoss1A:prepareHit: duration"..skill.duration..' buffIntervalTime:'..skill.bulletTimeInterval)
		local Aset=string.splitNumber(self.world.setting.balanceAreaA,',')
		local Bset=string.splitNumber(self.world.setting.balanceAreaB,',')
		parameters['tpID1']=Aset[4]
		parameters['tpPosX1']=Aset[1]
		parameters['tpPosY1']=Aset[2]
		parameters['RANGE1']=Aset[3]
		parameters['lifeTime1']=Aset[5]

		parameters['tpID2']=Bset[4]
		parameters['tpPosX2']=Bset[1]
		parameters['tpPosY2']=Bset[2]
		parameters['RANGE2']=Bset[3]
		parameters['lifeTime2']=Bset[5]
		self.world.tpAIAllTime = parameters['lifeTime1']
		for i=1,2 do
			local creatureID=self.world:addCreature(self.world.tostring(parameters['tpID'..i]),self.teamOrig,parameters['tpPosX'..i],parameters['tpPosY'..i],self,1,0)
			--local creatureID=self.world:addCreature(self.world.tostring(parameters['tpID'..i]),self.teamOrig,self.posX+i*3,self.posY,self,1,0)
			local obj  = self.world.allItemList[creatureID]
			self.creatureList[#self.creatureList+1]=creatureID  
			self.tpList[i] = creatureID
			--持续时间
			local lifeTime=parameters['lifeTime'..i]		--skill.parameters.DEAD
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			attributes['buffParameter'] = table.deepcopy(hitValueBoth)
			--attributes['buffParameter']['FIXHURT'] = 250
			-----debuglog("atkDis:"..parameters.hitTime)
			attributes['buffParameter']['RANGE'] =parameters['RANGE'..i]*self.world.setting.AdjustVisRange --obj.attribute.width * self.world.setting.AdjustAttRange
			attributes['buffParameter']['creatureDirectHurCallBack'] = 'tpID'..i
			----debuglog("jaylog addCreature  creatureID:"..creatureID)
			attributes['buffParameter']['buffType'] = 1
			--attributes['buffParameter']['buffAtleastOnce']=true
			attributes['buffParameter']['buffIntervalTime'] = skill.animationTime
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,skill.hitTime)
			self.mode7time = self.world.gameTime  + 1
			obj:addBuff(buff)
			obj:setDeadTime(lifeTime) 
			--obj:addStatusList({s=4029,r=self.world:getGameTime(),t=20,i=self.itemID,p1=1})
		end
		
		for k,v in pairs(self.world.itemListFilter.heroList) do
			if v.attribute.actorType==0 and  not v:isAIObj() and not v:isDead() then
				v:setAutoBlocked(false)
				v:addStatusList({zz=3,s=4016,r=self.world:getGameTime(),t=99,i=self.itemID,p1=self.tpList[1],p2=self.tpList[2],p5=1})	
			end
		end	
			-- local creatureID=self.world:addCreature(self.world.tostring(159),self.teamOrig,self.posX,self.posY,self,1,0)
			-- local obj  = self.world.allItemList[creatureID]
			-- self.creatureList[#self.creatureList+1]=creatureID  
			-- --持续时间
			-- local lifeTime=10			--skill.parameters.DEAD
			-- local attributes = {}
			-- attributes['buffParameter']={}
			-- attributes['BUFFONLY']=1
			-- attributes['buffParameter'] = table.deepcopy(hitValueBoth)
			-- --attributes['buffParameter']['FIXHURT'] = 250
			-- -----debuglog("atkDis:"..parameters.hitTime)
			-- attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
			-- --attributes['buffParameter']['creatureDirectHurCallBack'] = 'tpID'..i
			-- ----debuglog("jaylog addCreature  creatureID:"..creatureID)
			-- attributes['buffParameter']['buffType'] = 1
			-- --attributes['buffParameter']['buffAtleastOnce']=true
			-- attributes['buffParameter']['buffIntervalTime'] = skill.animationTime
			-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,skill.hitTime)
			-- obj:addBuff(buff)
			-- obj:setDeadTime(lifeTime) 
		--咏唱动作
		--self:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID})
	end	

	if mode==11 then
		--去掉可释放全屏版的生命封锁
		--self.statusList[4025]=nil
		--去掉提示
		for k,v in pairs(self.world.itemListFilter.heroList) do
			if v.attribute.actorType==0 and  not v:isAIObj() then
				v:setAutoBlocked(true)
				v:removeStatusList(4016)
			end
		end	

		self.world.tpAIMoveTime = 0
		local skill = self.attribute.skills[11] 
		local parameters = skill.parameters 
		--MaxHP_DOWN_RATE2=100;MaxHP_DOWN2=20;BUFFTIME2=10
		--假设AB队相等 不受伤害
		if table.nums(self.mode7Alist)==table.nums(self.mode7Blist) then

		end
		local list = {}
		--封锁
		if table.nums(self.mode7Alist)>table.nums(self.mode7Blist) then
			list = self.mode7Alist
		end

		if table.nums(self.mode7Alist)<table.nums(self.mode7Blist) then
			list = self.mode7Blist
		end

		--C队无论如何都要受buff
		table.merge(list,self.mode7Clist)
		--debuglog("天平 回调 A:"..self.world.cjson.encode(self.mode7Alist).." B:"..self.world.cjson.encode(self.mode7Blist).." C:"..self.world.cjson.encode(self.mode7Clist))
		for k,v in pairs(list) do
			--debuglog("天平打中了谁 itemID:"..v)
			local obj  = self.world.allItemList[v]
			--self.world:--debuglog('jaylog Boss2A skill mode11 k',v)
			-- for k1,v1 in pairs(self.world.allItemList) do
			-- 	self.world:--debuglog('jaylog Boss2A skill mode11 allItemList',k1,' v1',v1.attribute.roleId)
			-- end
			-- local attributes = {}
			-- attributes['MaxHP_DOWN_RATE'] = 100
			-- attributes['MaxHP_DOWN'] = 70
			-- attributes["BUFFTIME"]=parameters.BUFFTIME2
			-- local bufftime =  parameters.BUFFTIME2
			-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,bufftime,{},0,self.itemID,self.itemID)
			-- if obj~=nil and not obj:isDead() then
			-- 	--debuglog("天平打中了谁 添加buff itemID:"..v.." attributes:"..self.world.cjson.encode(attributes))
			-- 	obj:addBuff(buff)
			-- end
			--MaxHP_DOWN_RATE2=100;MaxHP_DOWN2=70;BUFFTIME2=10;CLEANSELFSTATUS=4026;ADDSTATUS=53;ADDSTATUSTIME=10;ADDSTATUS2=4019;ADDSTATUSTIME2=10
			if obj~=nil and not obj:isDead() then
				local hitValueNew={}
				hitValueNew['APADJ']=1
				hitValueNew['MaxHP_DOWN_RATE']=parameters.MaxHP_DOWN_RATE2 
				hitValueNew["MaxHP_DOWN"]=parameters.MaxHP_DOWN2
				hitValueNew["BUFFTIME"]=parameters.BUFFTIME2
				hitValueNew["INEVITABLEHIT"]=1
				obj:directHurt(self.itemID,mode,hitValueNew,0) 
			end
			--增加玩家生命封锁特效
			--self:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID})
		end
	end
	--POSX=66;POSY=46;ADDSTATUS=4024;ADDSTATUSTIME=999;CLEANSELFSTATUS=4027
	if mode==12 then
		local skill = self.attribute.skills[12] 
		local parameters = skill.parameters
		--debuglog("BOSS2A mode 12  移动到:POSX:"..parameters.POSX.." POSY:"..parameters.POSY) 
		self:moveTo(parameters.POSX,parameters.POSY)
		-- self.outOfCtlAllTime =  self.moveToEndTime + 2
		self:setOutOfCtlAllTime(self.moveToEndTime )
		-- self.attackTarget = nil
		--debuglog("BOSS2A mode 12 outOfCtlAllTime:"..self.outOfCtlAllTime.." gameTime:"..self.world.gameTime.." "..self.world.cjson.encode(self.paths))
		-- 	self:addStatusList({s=4023,r=self.world:getGameTime(),t=9999},self.paths[#self.paths].t-self.world.gameTime)
		-- end
	end

	-- if mode==3 or mode==15 or mode==16 then
	-- 	self.mode3list={}
	-- 	local skill = self.attribute.skills[mode] 
	-- 	local parameters = skill.parameters 
	-- 	local teamlist = {}

	-- 	local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
	-- 	----debuglog('jaylog useDis:'..skill.useDis..' AdjustAttRange:'..self.world.setting.AdjustAttRange)
	-- 	local dlist={}
	-- 	--local oldlist={}
	-- 	local atknum = parameters.TARGETNUM
	-- 	local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
	-- 	function(obj)
	-- 	 	if obj.teamOrig~=self.teamOrig then
	-- 			ok = true
	-- 			if (obj:isDead()) then ok = false end
	-- 			--if (atknum<=0) then ok = false end

	-- 			if ok then
	-- 				local d = obj:colliding(visRange,0,0,self.itemID)

	-- 				if (d>=0) then 
	-- 					--atknum = atknum - 1
	-- 					--dlist[#dlist+1] = obj 
	-- 					dlist[#dlist+1]={itemID=obj.itemID,DIS=d}  
	-- 				end
	-- 			end
	-- 		end
	-- 	end
	-- 	)

	-- 	self.world.tSort(dlist,function( a1,b1 )
	-- 				return a1['DIS'] > b1['DIS']
	-- 			end)
	-- 	-- local hlist = parameters.ROLESORT
	-- 	-- for k,v in pairs(hlist) do
	-- 	-- 	for objk,obj in pairs(oldlist) do
	-- 	-- 		if  obj.attribute.roleId==v then
	-- 	-- 			dlist[#dlist+1] = obj
	-- 	-- 		end
	-- 	-- 	end
	-- 	-- end
	-- 	local newDlist = {}
	-- 	newDlist[1]=dlist[#dlist]
	-- 	for i=1,atknum-1 do
	-- 		newDlist[#newDlist+1]=dlist[i]
	-- 	end

	-- 	--找到目标释放一个群体aoe在目标脚下
	-- 	for k,v in pairs(newDlist) do
	-- 		--debuglog(" SBoss2A:prepareHit: duration"..parameters.HURTLIFE..' buffIntervalTime:'..parameters.HURTITNTERVAL)
	-- 		local obj  = self.world.allItemList[v.itemID]
	-- 		local creatureID=self.world:addCreature(self.world.tostring(parameters.ENEMY),self.teamOrig,obj.posX,obj.posY,self,1,0)

	-- 		local obj  = self.world.allItemList[creatureID]
	-- 		self.creatureList[#self.creatureList+1]=creatureID  
	-- 		local lifeTime=parameters.HURTLIFE		
	-- 		local attributes = {}
	-- 		attributes['buffParameter']={}
	-- 		attributes['BUFFONLY']=1
			
	-- 		attributes['buffParameter'] = hitValueBoth

	-- 		attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
	-- 		attributes['buffParameter']['creatureDirectHurCallBack'] = "hlszy"

	-- 		attributes['buffParameter']['buffType'] = 1
	-- 		attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
	-- 		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,parameters.HURTSTARTTIME)
	-- 		obj:addBuff(buff)
	-- 		obj:setDeadTime(lifeTime) 
	-- 	end
		
	-- 	self:addStatusList({s=parameters.ADDSELFSTATUS,r=self.world:getGameTime(),t=parameters.ADDSELFSTATUSTIME,i=self.itemID})
	-- 	hitValueBoth = nil
	-- end

	if mode==5 or mode==18 or mode==19 then
		self.modeatklist={}
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local teamlist = {}
		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		local dlist = {}
		--local oldlist = {}
		--local atknum = parameters.TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				--if (atknum<=0) then ok = false end
				----debuglog('jaylog ok:'..ok)
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
					----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
					if (d>=0) then 
						--atknum = atknum - 1
						dlist[#dlist+1] = obj   
					end
				end
			end
		end
		)

		-- local hlist = parameters.ROLESORT
		-- for k,v in pairs(hlist) do
		-- 	for objk,obj in pairs(oldlist) do
		-- 		if  obj.attribute.roleId==v then
		-- 			dlist[#dlist+1] = obj
		-- 		end
		-- 	end
		-- end
		--dlist=oldlist

		dlist=table.shuffle(dlist)
		local nwdlist = {}
		if #dlist<parameters.TARGETNUM and #dlist>0 then
			--所欠的人数
			nwdlist= table.deepcopy(dlist)
			local num = parameters.TARGETNUM-#dlist
			self:D("机器人有目标 num:",#dlist)
			for i=1,num do
				nwdlist[#nwdlist+1]=dlist[1]
			end
		end

		if #dlist>=parameters.TARGETNUM then
			for i=1,parameters.TARGETNUM do
				nwdlist[#nwdlist+1]=dlist[i]
			end
		end

		if #nwdlist>0 then
			self:D("机器人有目标 nwdlist:",#nwdlist)
			for k,v in pairs(nwdlist) do
				-- TARGETNUM=3;HURTLIFE=5;HURTSTARTTIME=1.7;HURTITNTERVAL=5;HITTIME1=1.5;HITTIME2=1.8;HITTIME3=2.0
				local d = self:distance(v.posX,v.posY)
				local FLYTIME = (d*100)/skill.bulletSpeed
				local attributes = table.deepcopy(hitValueBoth)
				--attributes['APADJ']=attributes['APADJ2']
				self:directHurtToDalay(5,v.itemID,attributes,parameters['HITTIME'..k]+FLYTIME)
				self.modeatklist[#self.modeatklist+1]=v.itemID..","..parameters['HITTIME'..k]..","..FLYTIME
				

				local obj1 = self.world.allItemList[v.itemID] 
				-- local skill5 = self.attribute.skills[5] 
				-- local parameters5 = skill5.parameters 
				--obj1:addStatusList({s=parameters5.ADDSTATUS2,r=self.world:getGameTime(),t=parameters5.ADDSTATUSTIME2,i=self.itemID})	
				--self:D("机器人 精准打击 是不是加了:",parameters5.ADDSTATUS2,parameters5.ADDSTATUSTIME2)
				obj1:addStatusList({s=parameters.ADDSTATUS1,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME1,i=self.itemID,p1=parameters.HELUSI_EYE_RADIUS},parameters['HITTIME'..k]+FLYTIME)
				obj1:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID,p1=parameters.HELUSI_EYE_RADIUS},parameters['HITTIME'..k]+FLYTIME)
				--设置成就 天怎么黑了？快开灯！
				obj1:setCounter("blind_2002",1)
			end	
			--debuglog("机器人有目标 :"..self.world.cjson.encode(self.modeatklist))
		else	
			--debuglog("机器人没有目标")
		end
		hitValueBoth=nil
	end




	return hitValueBoth 
end 


--- 這個function 會在 執行前搖時call 當skill.delayCalTime>0
-- @param skill skillobj - skillobj
function SBoss2A:prepareSkillAttackDelayInit(skill)
	local hitValueBoth = SBoss2A.super.prepareSkillAttackDelayInit(self,skill)
	local mode=skill.rank

	if mode==3 or mode==15 or mode==16   then
		self.mode3list={}
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		self:D("boss释放噩梦漩涡........",self.world.cjson.encode(parameters))
		local teamlist = {}

		local visRange = {posX=self.posX,posY=self.posY,radius=(parameters.EMXWDIS/self.world.setting.AdjustAttRange)}
		local dlist={}
		local TARGETNUM =  self.world.formula:getRandnum(parameters.TARGETNUMMIN,parameters.TARGETNUNMAX)
		local atknum = TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)

					if (d>=0) then 
						dlist[#dlist+1]={itemID=obj.itemID,DIS=d}  
					end
				end
			end
		end
		)

		dlist=table.shuffle(dlist)
		local newDlist = {}
		for i=1,atknum do
			newDlist[#newDlist+1] = dlist[i]
		end

		--找到目标释放一个群体aoe在目标脚下
		for k,v in pairs(newDlist) do
			local obj  = self.world.allItemList[v.itemID]
			self:D("boss释放噩梦漩涡 到底打了谁:",obj.itemID,obj.posX,obj.posY,parameters.YJLIFETIME)
			--加预警时间
			if parameters.YJENEMY~=nil then
				local creatureID = self.world:addCreature(self.world.tostring(parameters.YJENEMY),self.teamOrig,obj.posX,obj.posY,self,1,0)
				local obj  = self.world.allItemList[creatureID]
				obj:setDeadTime(parameters.YJLIFETIME) 
			end	

			local creatureID=self.world:addCreature(self.world.tostring(parameters.ENEMY),self.teamOrig,obj.posX,obj.posY,self,1,skill.hitTime)

			local obj  = self.world.allItemList[creatureID]
			local lifeTime=parameters.HURTLIFE	
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			attributes['buffParameter'] = hitValueBoth
			attributes['buffParameter']['RANGE'] = parameters.EMXWATKDIS --obj.attribute.width * self.world.setting.AdjustAttRange
			attributes['buffParameter']['buffType'] = 1
			attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
			attributes['buffParameter']['INEVITABLEHIT'] = 1
			attributes['buffParameter']['creatureDirectHurCallBack'] = "hlszy"
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,(skill.hitTime+parameters.HURTSTARTTIME))
			obj:addBuff(buff)
			obj:setDeadTime(lifeTime+skill.hitTime) 
		end
		hitValueBoth = nil
	end

	
	return hitValueBoth
end



--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss2A:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 

	if mode==2 then
		local skill = self.attribute.skills[2] 
		local parameters = skill.parameters 
		--增加玩家生命封锁特效
		local obj  = self.world.allItemList[itemID]
		obj:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=itemID})
	end

	--在自身周围召唤沙暴，弹走所有目标
	if mode==4 or mode==23 then
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[4] 
		adjTime = adjTime + 0.2
		hitValue['DIZZY_RATE'] = 100
		hitValue['BUFFTIME'] = skill.animationTime-skill.hitTime-adjTime
		--d*100/parameters.BACKWARDSPEED2
	end

	--在目标召唤流沙，持续2秒，且减速，如果目标在流沙中停留2秒则会眩晕3秒
	--APADJ=100;MSPD_DOWN_RATE=100;MSPD_DOWN=50;DIZZY_RATE1=100;BUFFTIME1=3
	--APADJ=100;MSPD_DOWN_RATE=100;MSPD_DOWN=50;DIZZY_RATE=100;BUFFTIME=3;ADDSTATUS=4020;ADDBUFFTIME=3
	-- if mode==3 then
	-- 	local skill = self.attribute.skills[3] 
	-- 	local parameters = skill.parameters 

	-- 	self.mode3list[""..itemID] = (self.mode3list[""..itemID]==nil and 0 or self.mode3list[""..itemID]) + 1 
	-- 	--停留时间超多少秒
	-- 	--debuglog("BOSS2A mode 3 mode3list Num:"..self.mode3list[""..itemID].." itemID:"..itemID)
	-- 	if self.mode3list[""..itemID]==4 then
	-- 		hitValue['DIZZY_RATE'] = parameters.DIZZY_RATE2 
	-- 		hitValue['BUFFTIME'] = parameters.BUFFTIME2 
	-- 	end
	-- end


	ret = SBoss2A.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	--在自身周围召唤沙暴，弹走所有目标
	if mode==4 or mode==23 then
		--弹飞所有的目标....BACKWARD=800;BACKWARDSPEED=3000
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 

		--弹飞园半径
		local r = parameters.BACKWARD/self.world.setting.AdjustAttRange
		--圆心
		local x = self.posX
		local y = self.posY
		--目标坐标
		local tx = obj.posX
		local ty = obj.posY
		--目标和圆心的距离
		local r1 =self.world.mPow(self.world.mPow(obj.posX-self.posX,2) + self.world.mPow(obj.posY-self.posY,2),0.5)

		--目标偏移位置
		local toX = (tx-x)*r/r1+x
		local toY = (ty-y)*r/r1+y

		ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,toX,toY) 
		--目标到偏移位置的距离
		local d =self.world.mPow(self.world.mPow(obj.posX-toX,2) + self.world.mPow(obj.posY-toY,2),0.5)
		----debuglog("BOSS2A mode 4 posX:"..obj.posX.." posY:"..obj.posY.." toX:"..toX.." toY:"..toY.." d:"..d.." itemID:"..obj.itemID)
		local bulletSpeed = parameters.BACKWARDSPEED2
		obj:moveTo(toX,toY,true,5,bulletSpeed,0)
		----debuglog("BOSS2A mode 4 posX:"..obj.posX.." posY:"..obj.posY.." toX:"..toX.." toY:"..toY.." d:"..d.." itemID:"..obj.itemID.." "..self.world.cjson.encode(obj.syncMsg['m']).." "..self.world.cjson.encode(obj.debugPaths))
	end


	--唤生命天平，玩家在限定时间内（3-5秒）必须要走到生命天平两侧，否则：1、生命天平外玩家会受到生命封锁2、生命天平中较重一方会受到生命封锁

	if mode==11 then
		--去掉可释放全屏版的生命封锁
		--self.statusList[4025]=nil
		--MaxHP_DOWN_RATE2=100;MaxHP_DOWN2=60;BUFFTIME2=10;CLEANSELFSTATUS=4026;ADDSTATUS=53;ADDSTATUSTIME=10;ADDSTATUS2=4019;ADDSTATUSTIME2=10;INEVITABLEHIT=1
		local skill = self.attribute.skills[11] 
		local parameters = skill.parameters 
		--MaxHP_DOWN_RATE2=100;MaxHP_DOWN2=20;BUFFTIME2=10
		--假设AB队相等 不受伤害
		if #self.mode7Alist==#self.mode7Blist then

		end
		-- local list = {}
		-- --封锁
		-- if #self.mode7Alist>#self.mode7Blist then
		-- 	list = self.mode7Alist
		-- else
		-- 	list = self.mode7Blist
		-- end
		local list = {}
		--封锁
		if table.nums(self.mode7Alist)>table.nums(self.mode7Blist) then
			list = self.mode7Alist
		end

		if table.nums(self.mode7Alist)<table.nums(self.mode7Blist) then
			list = self.mode7Blist
		end

		--C队无论如何都要受buff
		table.merge(list,self.mode7Clist)
		for k,v in pairs(list) do
			local obj  = self.world.allItemList[v]
			--增加玩家生命封锁特效
			if obj~=nil and not obj:isDead() then
				obj:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=obj.itemID})
				--obj:addStatusList({s=parameters.ADDSTATUS1,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME1,i=obj.itemID})
			end
		end

	end

	-- if mode==5 then
	-- 	--`parameter` =  'APADJ=150;BLIND_RATE=100;BUFFTIME1=5;HIT_DOWN_RATE=100;HIT_DOWN=60;BUFFTIME=5;ADDSTATUS1=4021;ADDSTATUSTIME1=8'
	-- 	local skill = self.attribute.skills[5] 
	-- 	local parameters = skill.parameters 
	-- 	local obj  = self.world.allItemList[itemID]
	-- 	obj:addStatusList({s=parameters.ADDSTATUS1,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME1,i=self.itemID,p1=parameters.HELUSI_EYE_RADIUS})
	-- end

	return ret 
end 


-- --- 子彈完結callback
-- -- @param bulletID int - 子彈ID
-- -- @return null
-- function SBoss2A:endBullet(bulletID)
-- 	self.mode3list={}
-- end

--- 准备攻击前置设置，在prepareHit之前执行，call父类
-- @param mode int - 技能1-7
-- @param itemID int - 目标对象itemID
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SBoss2A:prepareSkillAttackCustom(mode,itemID,x,y,adjTime,syncMsg)  

	if mode==5  and #self.modeatklist>0 then
		--debuglog("机器人 导弹列表 mode:"..mode)
		syncMsg['a']['p'] = implode(';',self.modeatklist)
		--debuglog("机器人 导弹列表:"..syncMsg['a']['p'].." syncMsg:"..self.world.cjson.encode(syncMsg))
	end
	SBoss2A.super.prepareSkillAttackCustom(self,mode,itemID,x,y,adjTime,syncMsg)
	if mode==12 then
		local bulletObj = self.world.bulletList[self.lastBulletID]
		bulletObj.attr.debug = true
	end

end 




--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SBoss2A:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 

	----debuglog("天平回调  前 ....... 击中itemID:"..itemID.." creatureDirectHurCallBack:"..hitValue['creatureDirectHurCallBack'])
	--假设101是左天平
	--debuglog("天平回调 gameTime:"..self.world.gameTime.." mode7time:"..self.mode7time)
	if isset(hitValue['creatureDirectHurCallBack']) and hitValue['creatureDirectHurCallBack']=="tpID1" and self.world.gameTime>self.mode7time then --and in_array(hitValue['creatureDirectHurCallBack'],self.creatureList)) then
		local obj  = self.world.allItemList[itemID]
		if not obj:isDead() then
			self.mode7Alist[""..itemID]=itemID 
		end
		--debuglog("天平回调  左....... 击中itemID:"..itemID.." num:"..table.nums(self.mode7Alist))
	end
	--假设102是右天平
	if isset(hitValue['creatureDirectHurCallBack']) and hitValue['creatureDirectHurCallBack']=="tpID2" and self.world.gameTime>self.mode7time then --and in_array(hitValue['creatureDirectHurCallBack'],self.creatureList)) then
		local obj  = self.world.allItemList[itemID]
		if not obj:isDead() then
			self.mode7Blist[""..itemID]=itemID	
		end
		--debuglog("天平回调  右....... 击中itemID:"..itemID.." num:"..table.nums(self.mode7Blist))
	end

	if isset(hitValue['creatureDirectHurCallBack']) and hitValue['creatureDirectHurCallBack']=="hlszy"  then --and in_array(hitValue['creatureDirectHurCallBack'],self.creatureList)) then
		self:D("流沙 回调.........击中了:",itemID)
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 

		self.mode3list[""..itemID] = (self.mode3list[""..itemID]==nil and 0 or self.mode3list[""..itemID]) + 1 
		--停留时间超多少秒
		--debuglog("BOSS2A mode 3 mode3list Num:"..self.mode3list[""..itemID].." itemID:"..itemID)
		if self.mode3list[""..itemID]==6 then
			local hitValueNew = table.deepcopy(self:getPrepareHithitValue())
			
			hitValueNew['INEVITABLEHIT']=1
			hitValueNew['DIZZY_RATE'] = parameters.DIZZY_RATE2 
			hitValueNew['BUFFTIME'] = parameters.BUFFTIME2 
		

			self:directHurtToDalay(3,itemID,hitValueNew,0)
		end
	end
end

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SBoss2A:goToDead(itemID,mode,adjTime,bonus)
	local obj  = self.world.allItemList[itemID]
	--成就 嘿嘿嘿嘿！
	obj:setCounter("lastKill_2002",1)
	local dlist = {}
	local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if ok then
					dlist[#dlist+1] = obj   
				end
			end
		end
		)

	
	if #dlist==1 then
		--成就 拯救世界的我
		obj:setCounter("killBossOnlyMeAlive_2002",1)
	end

	ret = SBoss2A.super.goToDead(self,itemID,mode,adjTime,bonus) 
	return ret
end
return SBoss2A 
