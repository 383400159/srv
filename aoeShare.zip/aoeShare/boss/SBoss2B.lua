local SBoss2B = class("SBoss2B", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss2B:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss2B" 
	end 

	SBoss2B.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		--debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
end 


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss2B:prepareHit(mode,adjTime,buff)  

	--debuglog("SBoss2B:prepareHit....mode:"..mode..' adjtime:'..adjTime)
	local hitValueBoth=SBoss2B.super.prepareHit(self,mode,adjTime,buff) 
	--debuglog("SBoss2B:prepareHit....hitValueBoth:"..self.world.cjson.encode(hitValueBoth))

	if mode==1 then
		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters 
		self:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID})
	end

	if mode==3 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local teamlist = {}
		--搜敌找到所需要的目标
		--debuglog('jaylog teamlist:'..self.world.cjson.encode(teamlist))
		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		--debuglog('jaylog useDis:'..skill.useDis..' AdjustAttRange:'..self.world.setting.AdjustAttRange)
		local dlist = {}
		local dlistXY = {}	--相同玩家的小怪出生位偏移量
		local atknum = parameters.TARGETNUM
		local hlist = parameters.ROLESORT
		for k,v in pairs(hlist) do
			for objk,obj in pairs(self.world.itemListFilter.heroList) do
				--debuglog('jaylog allItemList:'..k..' id:'..obj.itemID..' ot:'..obj.teamOrig..' st:'..self.teamOrig)
				if obj.actorType==0 and obj.teamOrig~=self.teamOrig and obj.attribute.roleId==v then
					ok = true
					if (obj:isDead()) then ok = false end
					if (atknum<=0) then ok = false end
					if ok then
						local d = obj:colliding(visRange,0,0,self.itemID)
						if (d>=0) then 
							atknum = atknum - 1
							dlist[#dlist+1] = obj
							dlistXY[#dlistXY+1] = {x=0,y=0}
						end
					end
				end
			end
		end

		if not empty(dlist) and #dlist<parameters.TARGETNUM then
			for i=#dlist+1,parameters.TARGETNUM do
				dlist[#dlist+1] = dlist[1]
				dlistXY[#dlistXY+1] = {x=i,y=i}
			end
		end
		--self.world:debuglog('jaylog dlist:',self.world.tNums(dlist))

		local syncMsg = {}
		syncMsg['a'] = {}
		--找到目标释放一个群体aoe在目标脚下
		for k,obj in pairs(dlist) do
			local distance = self.world.map:distance(self.posX,self.posY,obj.posX+dlistXY[k]['x'],obj.posY+dlistXY[k]['y'])
			local hurtTime = math.round( ( (distance ) / skill.bulletSpeed ) * self.world.setting.walkingSpeed, 2) 
			local creatureID=self.world:addCreature(self.world.tostring(parameters.ENEMYID),self.teamOrig,obj.posX+dlistXY[k]['x'],obj.posY+dlistXY[k]['y'],self,1,hurtTime+parameters.DELAYTIME)
			local creature  = self.world.allItemList[creatureID]
			--self.creatureList[#self.creatureList+1]=creatureID  
			local lifeTime=9999
			creature:setDeadTime(lifeTime) 
			creature.DELAYTIME = hurtTime+parameters.DELAYTIME
			-- creature:directHurt(self.itemID,1,{},0)
			self:D("熔渣 招小怪 hurtTime:",hurtTime," DELAYTIME:",parameters.DELAYTIME)
			syncMsg['a'][#syncMsg['a']+1] = {x=obj.posX+dlistXY[k]['x'],y=obj.posY+dlistXY[k]['y'],sx=self.posX,sy=self.posY,ht=hurtTime,ti=creatureID,m=mode,i=self.itemID}
		end
		-- local creatureID=self.world:addCreature(self.world.tostring(272),self.teamOrig,self.posX+10,self.posY+10,self,1,parameters.SUMMONDELAY)
		-- local obj  = self.world.allItemList[creatureID]
		-- local lifeTime=9999
		-- obj:setDeadTime(lifeTime) 
		-- local distance = obj:distance(self.posX,self.posY,self.itemID)
		-- local hurtTime = math.round( ( (distance ) / skill.bulletSpeed ) * self.world.setting.walkingSpeed, 2)
		-- local syncMsg = {a={{x=obj.posX,y=obj.posY,sx=self.posX,sy=self.posY,ht=hurtTime,ti=creatureID,m=mode,i=self.itemID}}}
		if syncMsg['a']~=nil and not empty(syncMsg['a']) then
			--self.world:debuglog('jaylog SBoss2B:prepareHit syncMsg:',self.world.cjson.encode(syncMsg),distance,skill.bulletSpeed)
			self:updateSyncMsg(syncMsg)
		end
		if not empty(dlist) then
			hitValueBoth = nil
		else
			SBoss2B.super.callCreature(self,hitValueBoth,mode)
		end
	end

	if (mode==4) then 
 		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
 	 	--self:addStatusList({s=41,r=self.world:getGameTime(),t=parameters.KEEPTIME,i=self.itemID}) 
 	 	for k,v in pairs(self.world.allItemList) do
 	 		--self.world:debuglog('jaylog SBoss2B mode4 ',v.attribute.roleId,v.attribute.roleId==273)
 	 		if self.world.tonumber(v.attribute.roleId)==273 then
 	 			if v.statusList[parameters.ADDSTATUS2]==nil then
 	 				v:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID})
 	 			end
 	 		end
 	 	end
		return nil
	end 
	if (mode==104) then 
		--計第8秒
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		local baseNum = parameters.APADJ
		for k,v in pairs(self.world.allItemList) do
			if self.world.tonumber(v.attribute.roleId)==273 then
				--self.world:debuglog('jaylog SBoss2B mode104 ',v.itemID,v.attribute.roleId,v.posX,v.posY,self.posX,self.posY,parameters.SORBSPEED)
				local d =self.world.mPow(self.world.mPow(v.posX-self.posX,2) + self.world.mPow(v.posY-self.posY,2),0.5)
				if d>1 then
					d=d-1
				end
				local toX,toY = self.world.map:getXYLength(v.posX,v.posY,self.posX,self.posY,d)
				local ret
				ret,toX,toY=self.world.map:findPointStraightLineNearest(v.posX,v.posY,v.posX+toX,v.posY+toY) 
				--实际距离求速度
				local sd = d
				local bulletSpeed = (sd/parameters.ABSORDTIME)*100
				v:moveTo(toX,toY,false,5,bulletSpeed,0)
				--v:moveTo(self.posX,self.posY,false,2,parameters.SORBSPEED)
				--self.world:debuglog('jaylog SBoss2B mode104 move ',v.moveToEndTime,self.world.gameTime)
				v:addStatusList({s=42,r=self.world:getGameTime(),t=999,i=self.itemID},v.moveToEndTime-self.world.gameTime)
			end
			if self.world.tonumber(v.attribute.roleId)==272 then
				--self.world:debuglog('jaylog SBoss2B mode104 ',v.itemID,v.attribute.roleId,v.posX,v.posY,self.posX,self.posY,parameters.SORBSPEED)
				local d =self.world.mPow(self.world.mPow(v.posX-self.posX,2) + self.world.mPow(v.posY-self.posY,2),0.5)
				if d>1 then
					d=d-1
				end
				local toX,toY = self.world.map:getXYLength(v.posX,v.posY,self.posX,self.posY,d)
				local ret
				ret,toX,toY=self.world.map:findPointStraightLineNearest(v.posX,v.posY,v.posX+toX,v.posY+toY) 
				--实际距离求速度
				local sd = d
				local bulletSpeed = (sd/parameters.ABSORDTIME)*100
				v:moveTo(toX,toY,false,5,bulletSpeed,0)
				--v:moveTo(self.posX,self.posY,false,2,parameters.SORBSPEED)
				--self.world:debuglog('jaylog SBoss2B mode104 move ',v.moveToEndTime,self.world.gameTime)
				v:addStatusList({s=42,r=self.world:getGameTime(),t=999,i=self.itemID},v.moveToEndTime-self.world.gameTime)
			end
		end
		mode = 4
		--self.world:debuglog('jaylog SBoss2B hitValueBoth:',self.world.cjson.encode(hitValueBoth))
	end

	-- if mode==6 then
	-- 	if hitValueBoth['ADDATTACK']~=nil then
	-- 		local skill = self.attribute.skills[6]
	-- 		hitValueBoth['MODE'] = mode
	-- 		hitValueBoth['BULLETSPEED'] = skill.bulletSpeed
	-- 	end
	-- end

	if mode==9 then
		--計第8秒
		local skill = self.attribute.skills[9] 
		local parameters = skill.parameters 
		local baseNum = parameters.APADJ
		for k,v in pairs(self.world.allItemList) do
			if self.world.tonumber(v.attribute.roleId)==273 then
				if v.statusList[parameters.ADDSTATUS2]~=nil then
					baseNum = baseNum + parameters.APADJ2
				else
					baseNum = baseNum + parameters.APADJ1
				end
				v.attribute.HP = 0
				v:directHurt(v.itemID,1,{})
			end
			if self.world.tonumber(v.attribute.roleId)==272 then
				baseNum = baseNum + parameters.APADJ3
				v.attribute.HP = 0
				v:directHurt(v.itemID,1,{})
			end
		end
		hitValueBoth['APADJ'] = baseNum
		--self.world:debuglog('jaylog SBoss2B hitValueBoth:',self.world.cjson.encode(hitValueBoth))
	end

	return hitValueBoth 
end 

function SBoss2B:callCreature(hitValue,mode)
	if mode~=3 then
		SBoss2B.super.callCreature(self,hitValue,mode)
	end
end

function SBoss2B:createInit()
	self:callCreateInit()
end

return SBoss2B 
