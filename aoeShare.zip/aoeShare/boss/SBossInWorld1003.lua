local SBossInWorld1003 = class("SBossInWorld1003", require("gameroomcore.SHeroBase"))

function SBossInWorld1003:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld1003.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBossInWorld1003:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	local ret = SBossInWorld1003.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	if ret>0 then
		local obj  = self.world.allItemList[itemID]
		--obj.statusList[999] = nil
		if obj.statusList[41]~=nil then
			obj:removeStatusList(999)
		end
		obj:removeSkillAttackMode9()
		self:D("挖矿  取消挖矿状态:",obj.itemID)
	end
	return ret 
end


-- ---自动攻击..........
-- --返回true代表执行world的AI false执行AI
-- function SBossInWorld1003:_autoFight()
-- 	--self:D("保卫雅典娜 _autoFight ")
-- 	self:D("SBossInWorld1004:_autoFight()")
-- 	if self.team=="" and self.world:getGameTime()>self.nextAtkTime then
-- 		local atkList = {}
-- 		local atkItemID  = self.oldItemID
-- 		for k,v in pairs(self.world.allItemList) do
-- 			if v.attribute.actorType==0 and v.statusList[41]~=nil and v.statusList[41]["p1"]=283 then
-- 				atkList[#atkList+1]=v
-- 			end
-- 		end

-- 		--判断原先的家伙还有没有在采集
-- 		local obj = self.world.allItemList[self.oldItemID]
-- 		if obj~=nil and obj.statusList[41]~=nil and obj.statusList[41]["p1"]=283 then
-- 			atkItemID  = self.oldItemID
-- 		else
-- 			lcoal r1 = self.world.formula:getRandnum(1,#atkList)
-- 			atkItemID = atkList[r1].itemID
-- 		end

-- 		-- if self.lastHurtItemID>0  then
-- 		-- 	local obj = self.world.allItemList[self.lastHurtItemID]
-- 		-- 	local lastTime = 10
-- 		-- 	if not obj:isDead() and (self.lastHurtTime+lastTime)>self.world:getGameTime() then
-- 		-- 		atkItemID =self.lastHurtItemID
-- 		-- 		if atkItemID~=self.oldItemID then
-- 		-- 			self.prepareSkillAttackNum = 0
-- 		-- 		end

-- 		-- 		self.oldItemID = atkItemID
-- 		-- 		self.autoFightAI.runAI=true
-- 		-- 		self:D("SBossInWorld1004:_autoFight(1)")
-- 		-- 		--用回bossAI
-- 		-- 		return false
-- 		-- 	end
-- 		-- end
-- 		if #self.BossHatredlist>0  then

-- 			local obj = self.world.allItemList[self.BossHatredlist[#self.BossHatredlist]['itemID']]
-- 			if  obj.statusList[4007]==nil then
-- 				atkItemID =self.BossHatredlist[#self.BossHatredlist]['itemID']
-- 				if atkItemID~=self.oldItemID then
-- 					self.prepareSkillAttackNum = 0
-- 				end

-- 				self.oldItemID = atkItemID
-- 				self.autoFightAI.runAI=true
-- 				self:D("SBossInWorld1004:_autoFight(1)")
-- 				--用回bossAI
-- 				return false

-- 			end
-- 		end
		
-- 		if atkItemID~=self.oldItemID then
-- 			self.prepareSkillAttackNum = 0
-- 		end
-- 		self:skillAttack(1,atkItemID)
-- 		--self:D("保卫雅典娜 ",atkItemID,self.itemID)
-- 		self.nextAtkTime = self.world:getGameTime()+1
-- 		self.oldItemID = atkItemID
-- 		return true
-- 	end
-- 	return true
-- end



return SBossInWorld1003