local SBossInWorld5007 = class("SBossInWorld5007", require("gameroomcore.SHeroBase"))

function SBossInWorld5007:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld5007.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld5007
