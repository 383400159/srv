local SBoss3A = class("SBoss3A", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss3A:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss3A" 
	end 
	self.creatureList = {}
	--boss阶段
	self.bossType = 1

	--记录击中玩家的毒性
	self.mode1list = {}

	--记录mode10 enemy list
	self.mode10enemy = {}
	self.mode10EndTime = 0
	self.energyNum = 0
	self.mode10CheckTime = 0

	SBoss3A.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		----debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end		


end 

--boss免控
function SBoss3A:addIMMUNECONTROLBUFF()
	self:callCreateInit()
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss3A:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SBoss3A.super.prepareHit(self,mode,adjTime,buff) 
	if mode==4 or mode==13 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local lifeTime= 10
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		
		attributes['buffParameter'] =  table.deepcopy(self:getPrepareHithitValue())
		attributes['buffParameter']['RANGE'] = 1000
		attributes['buffParameter']['FIXHURT'] = 9
		attributes['buffParameter']['buffType'] = 1
		attributes['buffParameter']['buffIntervalTime'] = 0.3
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,self.itemID,self.itemID,adjTime)
		self:addBuff(buff)
	end

	-- if mode==6 then
	-- 	self.modeatklist={}
	-- 	local skill = self.attribute.skills[6] 
	-- 	local parameters = skill.parameters 
	-- 	local teamlist = {}
	-- 	local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
	-- 	local dlist = {}
	-- 	--local oldlist = {}
	-- 	--local atknum = parameters.TARGETNUM
	-- 	local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
	-- 	function(obj)
	-- 	 	if obj.teamOrig~=self.teamOrig then
	-- 			ok = true
	-- 			if (obj:isDead()) then ok = false end
	-- 			--if (atknum<=0) then ok = false end
	-- 			----debuglog('jaylog ok:'..ok)
	-- 			if ok then
	-- 				local d = obj:colliding(visRange,0,0,self.itemID)
	-- 				----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
	-- 				if (d>=0) then 
	-- 					--atknum = atknum - 1
	-- 					dlist[#dlist+1] = obj   
	-- 				end
	-- 			end
	-- 		end
	-- 	end
	-- 	)

	-- 	dlist=table.shuffle(dlist)
	-- 	local nwdlist = {}
	-- 	for i=1,parameters.TARGETNUM do
	-- 		nwdlist[#nwdlist+1] = dlist[i]
	-- 	end


	-- 	if #nwdlist>0 then
	-- 		self:D("机器人有目标 nwdlist:",#nwdlist)
	-- 		for k,v in pairs(nwdlist) do
	-- 			local d = self:distance(v.posX,v.posY)
	-- 			local FLYTIME = (d*100)/skill.bulletSpeed
	-- 			local attributes = table.deepcopy(hitValueBoth)
	-- 			attributes['FIXHURT'] = 888 
	-- 			self:directHurtToDalay(6,v.itemID,attributes,parameters['HITTIME'..k]+FLYTIME)
	-- 			self.modeatklist[#self.modeatklist+1]=v.itemID..","..parameters['HITTIME'..k]..","..FLYTIME
	-- 			-- local obj1 = self.world.allItemList[v.itemID] 
	-- 			-- obj1:addStatusList({s=parameters.ADDSTATUS1,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME1,i=self.itemID,p1=parameters.HELUSI_EYE_RADIUS},parameters['HITTIME'..k]+FLYTIME)
	-- 			-- obj1:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID,p1=parameters.HELUSI_EYE_RADIUS},parameters['HITTIME'..k]+FLYTIME)
	-- 		end	

	-- 	end
	-- 	hitValueBoth=nil
	-- end

	if mode==10 then
		local skill = self.attribute.skills[10] 
		local parameters = skill.parameters 
		local cList = parameters['SUMMONPOINT']

		for i=1,5 do
			self.mode10enemy[i] = self.world:addCreature(cList[2],self.teamOrig,parameters['CIRCLE'..i]['POSX'],parameters['CIRCLE'..i]['POSY'],self,1)
		end

		local LIFETIME = parameters.SADDSELFSTATUSTIMEB
		self.mode10EndTime = self.world.gameTime + LIFETIME
		-- local attributes = {}
		-- attributes['buffParameter']={}
		-- attributes['BUFFONLY']=1
		-- attributes['buffParameter'] = {}
		-- -- attributes['buffParameter']['buffIntervalTime'] = parameters.MOVEINTERVAL
		-- local buffObj=self.world:createBuff(self:__skillID2buffID(skill.skillID,0),attributes,LIFETIME,{mode},0,self.itemID,self.itemID,skill.hitTime) 
 	-- 	self:addBuff(buffObj)

 		for k,v in pairs(self.world.itemListFilter.heroList) do
 			if v.actorType==0 then
	 			local attributes = {}
				attributes['SILIENCE_RATE'] = 100 
				local buffObj=self.world:createBuff(v:__skillID2buffID(0),attributes,LIFETIME,{},0,v.itemID,v.itemID)
		 		v:addBuff(buffObj)
		 	end
 		end

 		self.world:D('jaylog SBoss3A mode10 ',self.energyNum,LIFETIME,self.mode10EndTime,self.world.gameTime,self.world.cjson.encode(self.mode10enemy))

		hitValueBoth = nil
	end

	if mode==110 then
		local skill = self.attribute.skills[10] 
		local parameters = skill.parameters 

		if self.world.gameTime<self.mode10EndTime then
			-- if self.energyNum>=3 then
			-- 	for i=1,5 do
			-- 		self.world.allItemList[self.mode10enemy[i]].attribute.HP = 0
			-- 		self.world.allItemList[self.mode10enemy[i]]:directHurt(self.mode10enemy[i],1,{},0)
			-- 	end
			-- 	self:removeBuffToID(self:__skillID2buffID(skill.skillID,0))
			-- 	self:removeStatusList(parameters.SADDSELFSTATUSB)
			-- 	self:setCoolDownTime(self.world.gameTime)
			-- 	self:resetEnergy()
			-- end
			hitValueBoth = nil
		else
			if self.energyNum>=3 then
				for i=1,5 do
					self.world.allItemList[self.mode10enemy[i]].attribute.HP = 0
					self.world.allItemList[self.mode10enemy[i]]:directHurt(self.mode10enemy[i],1,{},0)
				end
				hitValueBoth = nil
				self:resetEnergy()
			else
				for i=1,5 do
					self.world.allItemList[self.mode10enemy[i]].attribute.HP = 0
					self.world.allItemList[self.mode10enemy[i]]:directHurt(self.mode10enemy[i],1,{},0)
				end
				self:addStatusList({s=4035,r=self.world:getGameTime(),t=5,i=self.itemID})
				-- hitValueBoth = {APADJ=270}
				self:resetEnergy()
			end
		end
		self.world:D('jaylog SBoss3A mode110 ',self.energyNum,self.world.gameTime,self.world.cjson.encode(hitValueBoth))
		mode = 10
	end

	return hitValueBoth 
end 

--- fight motion , call every update loop
-- @return null
function SBoss3A:fight()
	if self.mode10CheckTime+1<self.world:getGameTime() then
		if self.energyNum>=3 then
			for i=1,5 do
				self.world.allItemList[self.mode10enemy[i]].attribute.HP = 0
				self.world.allItemList[self.mode10enemy[i]]:directHurt(self.mode10enemy[i],1,{},0)
			end
			self:removeBuffToID(self:__skillID2buffID(skill.skillID,0))
			self:removeStatusList(parameters.SADDSELFSTATUSB)
			self:setCoolDownTime(self.world.gameTime)
			self:resetEnergy()
		end
		self.mode10CheckTime = self.world:getGameTime()
	end
	SBoss3A.super.fight(self)
end

--- 准备攻击前置设置，在prepareHit之前执行，call父类
-- @param mode int - 技能1-7
-- @param itemID int - 目标对象itemID
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SBoss3A:prepareSkillAttackCustom(mode,itemID,x,y,adjTime,syncMsg)  

	-- if mode==6  and #self.modeatklist>0 then
	-- 	--debuglog("机器人 导弹列表 mode:"..mode)
	-- 	syncMsg['a']['p'] = implode(';',self.modeatklist)
	-- 	--debuglog("机器人 导弹列表:"..syncMsg['a']['p'].." syncMsg:"..self.world.cjson.encode(syncMsg))
	-- end
	SBoss3A.super.prepareSkillAttackCustom(self,mode,itemID,x,y,adjTime,syncMsg)
	
end 


--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss3A:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 

	ret = SBoss3A.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime)
	--横扫前方目标，并让目标中毒，对同一个目标攻击会让中毒的层数越来越高，伤害越来越大 
	--APADJ=100;POISON_HURT_RATE=100;POISON_HURT=100;BUFFTIME=10;MAXMULTI=999
	-- if mode==1 then
	-- 	local skill = self.attribute.skills[1] 
	-- 	local parameters = skill.parameters 
	-- 	if self.mode1list[""..itemID]==nil then
	-- 		self.mode1list[""..itemID]={
	-- 			num=0,
	-- 			updateTime=0,
	-- 		}
	-- 	end 
	-- 	if self.mode1list[""..itemID]['updateTime']+parameters.BUFFTIME>self.world.gameTime then
	-- 		self.mode1list[""..itemID]['num']=self.mode1list[""..itemID]['num']+1
	-- 		self.mode1list[""..itemID]['updateTime']=self.world.gameTime
	-- 	else
	-- 		self.mode1list[""..itemID]['num']=1
	-- 		self.mode1list[""..itemID]['updateTime']=self.world.gameTime
	-- 	end
	-- 	hitValue['APADJ']=hitValue['APADJ'] * (1+self.mode1list[""..itemID]['num']*0.2)
	-- end

	if mode==3 or mode==12 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local obj  = self.world.allItemList[itemID]
		local lifeTime= 10
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		
		attributes['buffParameter'] =  table.deepcopy(self:getPrepareHithitValue())
		attributes['buffParameter']['FIXHURT'] = 777
		attributes['buffParameter']['buffType'] = 1
		attributes['buffParameter']['buffIntervalTime'] = 0.3
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{98},0,self.itemID,itemID,adjTime)
		obj:addBuff(buff)
	end
	
	return ret 
end 

--- 设置击中炮弹数量
-- @param num int - 设置击中炮弹数量
-- @return null
function SBoss3A:setEnergy(num)
	self.energyNum = self.energyNum + num
end

--- 重置被炮弹击中数量
-- @param null
-- @return null
function SBoss3A:resetEnergy()
	self.energyNum = 0
end

--- 通过hitValue参数召唤小怪
-- @param hitValue table - 伤害基础参数
-- @param mode int - call些function的技能ID
-- @return null
function SBoss3A:callCreature(hitValue,mode)
	if mode==10 then
		return nil
	else
		return SBoss3A.super.callCreature(self,hitValue,mode)
	end
end

return SBoss3A 