local SBoss4A = class("SBoss4A", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss4A:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss4A" 
	end 
	self.creatureList = {}
	--boss阶段
	self.bossType = 1
	--闪电链列表
	self.dlist = {}

	self.startID = 0

	SBoss4A.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		----debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end		


end 

--boss免控
function SBoss4A:addIMMUNECONTROLBUFF()
	--IMMUNECONTROL_RATE=100

	--debuglog("addIMMUNECONTROLBUFF boss itemID:"..self.itemID)
	-- --debuglog("boss allItemList:"..self.world.cjson.encode(self.world.allItemList[self.itemID]))
	self:callCreateInit()
end


--- 准备攻击前置设置，在prepareHit之后执行
-- @param mode int - 技能1-7
-- @param itemID int - 目标对象id
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SBoss4A:prepareSkillAttackCustom(mode,itemID,x,y,adjtime,syncMsg)
	--发出一个连锁闪电，最多可跳转6-8个目标（包括黑电球和白电球），每跳转一次，闪电伤害增加20%（黑电球和白电球不会受到伤害）
	--APADJ=100;MINBALLNUM=2;MINPLAYERNUM=2;MAXATKNUM=10
	--debuglog("SBoss4A:prepareSkillAttackCustom")
	if (mode==3 or mode==19) and #self.dlist>0 then
		--debuglog("闪电链列表 mode:"..mode)
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local itemIDList = {}
		for k,v in pairs(self.dlist) do
			itemIDList[#itemIDList+1]=v.itemID
		end
		syncMsg['a']['p'] = implode(',',itemIDList)..";"..parameters.LIGHTNINGNEXTDELAY
		--debuglog("闪电链列表:"..syncMsg['a']['p'].." syncMsg:"..self.world.cjson.encode(syncMsg))
	end
	SBoss4A.super.prepareSkillAttackCustom(self,mode,itemID,x,y,adjTime,syncMsg)
end


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss4A:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SBoss4A.super.prepareHit(self,mode,adjTime,buff) 
	----debuglog("SBoss4A:prepareHit....hitValueBoth:"..self.world.cjson.encode(hitValueBoth))
	--发出一个连锁闪电，最多可跳转6-8个目标（包括黑电球和白电球），每跳转一次，闪电伤害增加20%（黑电球和白电球不会受到伤害）
	--APADJ=100;MINBALLNUM=2;MINPLAYERNUM=2;MAXATKNUM=10
	if mode==3 or mode==19 then
		
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local teamlist = {}


		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		----debuglog('jaylog useDis:'..skill.useDis..' AdjustAttRange:'..self.world.setting.AdjustAttRange)
		local dlist,delist,dtlist = {},{},{}
		local atknum = parameters.TARGETNUM

		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				----debuglog('jaylog ok:'..ok)
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
					----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
					if (d>=0) then 
						delist[#delist+1] = {itemID=obj.itemID,DIS=d}
					end
				end
			end
		end
		)

		local team = self.world:runTargetTypeFilter(11,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig==self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				----debuglog('jaylog ok:'..ok)
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
					----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
					if (d>=0) then 
						dtlist[#dtlist+1] = {itemID=obj.itemID,DIS=d}
					end
				end
			end
		end
		)



		-- local enemy = self:getEnemylist()
		-- local team = self:getTeammatelist(true)
	
		-- --选择合适的敌方
		-- for k,obj in pairs(enemy) do
		-- 	----debuglog('jaylog enemy allItemList:'..k..' id:'..obj.itemID..' ot:'..obj.teamOrig..' st:'..self.teamOrig)
		-- 	if obj.teamOrig~=self.teamOrig then
		-- 		ok = true
		-- 		if (obj:isDead()) then ok = false end
		-- 		----debuglog('jaylog ok:'..ok)
		-- 		if ok then
		-- 			local d = obj:colliding(visRange,0,0,self.itemID)
		-- 			----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
		-- 			if (d>=0) then 
		-- 				delist[#delist+1] = {itemID=obj.itemID,DIS=d}
		-- 			end
		-- 		end
		-- 	end
		-- end

		-- --选择合适的队友
		-- for k,obj in pairs(team) do
		-- 	----debuglog('jaylog  team allItemList:'..k..' id:'..obj.itemID..' ot:'..obj.teamOrig..' st:'..self.teamOrig)
		-- 	if obj.teamOrig==self.teamOrig then
		-- 		ok = true
		-- 		if (obj:isDead()) then ok = false end
		-- 		----debuglog('jaylog ok:'..ok)
		-- 		if ok then
		-- 			local d = obj:colliding(visRange,0,0,self.itemID)
		-- 			----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
		-- 			if (d>=0) then 
		-- 				dtlist[#dtlist+1] = {itemID=obj.itemID,DIS=d}
		-- 			end
		-- 		end
		-- 	end
		-- end

		-- self.world.tSort(targetList,function( a1,b1 )
		-- 				return a1['DIS'] < b1['DIS']
		-- 			end)

		--随机目标列表
		delist = table.shuffle(delist)
		dtlist = table.shuffle(dtlist)

		--debuglog("闪电链 delist NUM:"..#delist)
		--debuglog("闪电链 dtlist NUM:"..#dtlist)

		--debuglog("闪电链 dlist  delist:"..self.world.cjson.encode(delist))
		--debuglog("闪电链 dlist  dtlist:"..self.world.cjson.encode(dtlist))
		--3种情况
		--1.球的数量少于指定数量
		if #dtlist<=parameters.MINBALLNUM then
			for i=1,#dtlist do
				dlist[#dlist+1]=dtlist[i]
			end
			
			--拿敌方的数量
			local num = parameters.MAXATKNUM-#dtlist>#delist and #delist or parameters.MAXATKNUM-#dtlist 

			for i=1,num do
				dlist[#dlist+1]=delist[i]
			end
			--debuglog("闪电链 dlist  球的数量少于指定数量dlist:"..self.world.cjson.encode(dlist))
		end

		--APADJ2=100;MINBALLNUM=2;MINPLAYERNUM=2;MAXATKNUM=10;ADDSTATUS=4047;ADDSTATUSTIME=25;LIGHTNINGSTARTDELAY=0.5;LIGHTNINGNEXTDELAY=0.25
		-- --2.敌方的数量少于指定数量
		-- if #delist<=parameters.MINBALLNUM then
		-- 	for i=1,#delist do
		-- 		dlist[#dlist+1]=delist[1]
		-- 	end
		-- 	--拿敌方的数量
		-- 	local num = parameters.MAXATKNUM-#delist>#dtlist and #dtlist or parameters.MAXATKNUM-#delist 

		-- 	for i=1,num do
		-- 		dlist[#dlist+1]=dtlist[i]
		-- 	end
		-- 	--debuglog("闪电链 dlist  敌方的数量少于指定数量dlist:"..self.world.cjson.encode(dlist))
		-- end

		-- --3.球和敌人都多余最小值
		-- if #dtlist+#delist<=parameters.MINBALLNUM then
		-- 	dlist[#dlist+1]=dtlist[1]
		-- 	local rMax= #delist>parameters.MAXATKNUM-#dtlist and parameters.MAXATKNUM-#dtlist or #delist
		-- 	--随机敌方的数
		-- 	local rNum = self.world.formula:getRandnum(#delist,rMax)

		-- 	for i=1,rNum do
		-- 		dlist[#dlist+1]=delist[i]
		-- 	end

		-- 	for i=1,parameters.MAXATKNUM - rNum do
		-- 		dlist[#dlist+1]=dtlist[i]
		-- 	end
		-- 	--debuglog("闪电链 dlist  球和敌人都多余最小值dlist:"..self.world.cjson.encode(dlist))
		-- end

		--4.球的数量大于指定数量
		if #dtlist>parameters.MINBALLNUM then
			if #delist+parameters.MINBALLNUM<=parameters.MAXATKNUM then
				for i=1,parameters.MAXATKNUM-#delist do
					dlist[#dlist+1]=dtlist[i]
				end
				for i=1,#delist do
					dlist[#dlist+1]=delist[i]
				end
			else
				for i=1,parameters.MINBALLNUM do
					dlist[#dlist+1]=dtlist[i]
				end
				for i=1,parameters.MAXATKNUM-parameters.MINBALLNUM do
					dlist[#dlist+1]=delist[i]
				end
			end
			--debuglog("闪电链 dlist  球的数量大于指定数量dlist:"..self.world.cjson.encode(dlist))
		end


		if #dlist>0 then
			--debuglog("闪电链 dlist NUM:"..#dlist)

			self.world.tSort(dlist,function( a1,b1 )
				return a1['DIS'] < b1['DIS']
			end)
			--debuglog("闪电链 dlist dlist:"..self.world.cjson.encode(dlist))
			--抽一个敌人在最后面
			local obj  = self.world.allItemList[dlist[#dlist].itemID]
			if obj.teamOrig==self.teamOrig then
				for k,v in pairs(dlist) do
					local obj1  = self.world.allItemList[v.itemID]
					if obj1.teamOrig~=self.teamOrig then
						local old = dlist[#dlist]
						dlist[#dlist]=v
						dlist[k]=old
						break
					end
				end
			end

			--插队一个起点
			if self.startID > 0 then
				local newDlist = {}
				newDlist[#newDlist+1] = {itemID=self.startID,DIS=0}
				
				for k,v in pairs(dlist) do
					newDlist[#newDlist+1]=v
				end
				dlist = newDlist
				self.startID = 0
			end

			--LIGHTNINGBASEHURT=20;LIGHTNINGHURTUPONPLAYER=1;LIGHTNINGHURTUPONBALL=2;
			local fixHurtPro = parameters.LIGHTNINGBASEHURT
			for i=1,#dlist do
				--MINPLAYERNUM=2;MAXATKNUM=10;ADDSTATUS=4047;ADDSTATUSTIME=25;LIGHTNINGSTARTDELAY=1;LIGHTNINGNEXTDELAY=0.5
				local hitValueNew = table.deepcopy(self:getPrepareHithitValue())
				local obj  = self.world.allItemList[dlist[i].itemID]
				if obj.teamOrig~=self.teamOrig then
					-- hitValueNew['INEVITABLEHIT']=1
					-- hitValueNew['ATK'] = hitValueBoth['ATK']
					-- hitValueNew['APADJ']  = hitValueBoth['APADJ2']*(1+parameters.LIGHTNINGHURTUP*(i-1))
					fixHurtPro = fixHurtPro + parameters.LIGHTNINGHURTUPONPLAYER
					hitValueNew['FIXHURT'] = fixHurtPro*0.01*obj.attribute.MaxHP

					self:directHurtToDalay(mode,obj.itemID,hitValueNew,i*parameters.LIGHTNINGNEXTDELAY+parameters.LIGHTNINGSTARTDELAY)
				else
					fixHurtPro = fixHurtPro + parameters.LIGHTNINGHURTUPONBALL
				end
				
			end
		end
		self.dlist = dlist
		hitValueBoth=nil
		return nil
	end

	if mode==8 or mode==21 then
		--SUMMONRING=1,157,2;CIRCLE1=POSX:1,POSY:1,CIRCLENUM:1,R1:50,POINTNUM1:10,SUMMONNUM:1,HITTIME:0,DELAYTIME:0;POSX=74;POSY=28.8;RANGE=18
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 

		randlist = self.world.formula:formationPoint(6,parameters.RANGE,true)
		----debuglog("hitTime_:"..skill.hitTime)
		--debuglog("jaylog SBoss4A:prepareHit: duration"..skill.duration..' buffIntervalTime:'..skill.bulletTimeInterval)
		local id = self.world.formula:getRandnum(1,#randlist)
		local creatureID=self.world:addCreature(self.world.tostring(157),self.teamOrig,parameters.POSX+randlist[id][1],parameters.POSY+randlist[id][2],self,1,0)
		local obj  = self.world.allItemList[creatureID]
		self.creatureList[#self.creatureList+1]=creatureID  
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['buffParameter'] =  table.deepcopy(self:getPrepareHithitValue())
		attributes['buffParameter']['APADJ'] = parameters.APADJ2
		attributes['buffParameter']['DIZZY_RATE'] =parameters.DIZZY_RATE2
		attributes['buffParameter']['BUFFTIME'] = parameters.BUFFTIME2
		-- attributes['buffParameter']['FIXHURT'] = 250
		-----debuglog("atkDis:"..parameters.hitTime)
		attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
		attributes['buffParameter']['creatureDirectHurCallBack'] = 'gl'
		----debuglog("jaylog addCreature  creatureID:"..creatureID)
		attributes['buffParameter']['buffType'] = 1
		--attributes['buffParameter']['buffAtleastOnce']=true
		attributes['buffParameter']['buffIntervalTime'] = skill.buffIntervalTime
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,9999,{99},0,self.itemID,creatureID,skill.hitTime)
		obj:addBuff(buff)

	end

	-- if mode==4 or mode==5 then
	-- 	--给召唤物上一个buff
	-- 	if hitValueBoth['autoCreatureIDList']~=nil then
	-- 		for k,v in pairs(hitValueBoth['autoCreatureIDList']) do
	-- 			local obj  = self.world.allItemList[v]
	-- 				--持续时间
	-- 			local lifeTime=skill.duration 			--skill.parameters.DEAD
	-- 			local attributes = {}
	-- 			attributes['buffParameter']={}
	-- 			attributes['BUFFONLY']=1
	-- 			attributes['buffParameter'] = {}
	-- 			--attributes['buffParameter']['FIXHURT'] = 250
	-- 			-----debuglog("atkDis:"..parameters.hitTime)
	-- 			attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
	-- 			attributes['buffParameter']['creatureDirectHurCallBack'] = obj.itemID
	-- 			----debuglog("jaylog addCreature  creatureID:"..creatureID)
	-- 			attributes['buffParameter']['buffType'] = 1
	-- 			--attributes['buffParameter']['buffAtleastOnce']=true
	-- 			attributes['buffParameter']['buffIntervalTime'] = skill.bulletTimeInterval
	-- 			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,skill.hitTime)
	-- 			obj:addBuff(buff)
	-- 			obj:setDeadTime(lifeTime) 

	-- 		end
	-- 	end
	-- end


	-- if mode==11 then
	-- 	local skill = self.attribute.skills[11] 
	-- 	local parameters = skill.parameters 
	-- 	local teamlist = {}
	-- 	--搜敌找到所需要的目标
	-- 	-- if ( self.teamOrig=="A")  then
	-- 	-- 	teamlist=self.world.itemListFilter.teamB
	-- 	-- else
	-- 	-- 	teamlist=self.world.itemListFilter.teamA
	-- 	-- end
	-- 	----debuglog('jaylog teamlist:'..self.world.cjson.encode(teamlist))
	-- 	local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
	-- 	----debuglog('jaylog useDis:'..skill.useDis..' AdjustAttRange:'..self.world.setting.AdjustAttRange)
	-- 	local dlist = {}
	-- 	local atknum = parameters.TARGETNUM
	-- 	local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
	-- 	function(obj)
	-- 	 	if obj.teamOrig~=self.teamOrig then
	-- 			ok = true
	-- 			if (obj:isDead()) then ok = false end
	-- 			if (atknum<=0) then ok = false end
	-- 			----debuglog('jaylog ok:'..ok)
	-- 			if ok then
	-- 				local d = obj:colliding(visRange,0,0,self.itemID)
	-- 				----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
	-- 				if (d>=0) then 
	-- 					atknum = atknum - 1
	-- 					dlist[#dlist+1] = obj   
	-- 				end
	-- 			end
	-- 		end
	-- 	end
	-- 	)
		
	-- 	-- local enemy = self:getEnemylist()
	-- 	-- for k,obj in pairs(enemy) do
	-- 	-- 	----debuglog('jaylog allItemList:'..k..' id:'..obj.itemID..' ot:'..obj.teamOrig..' st:'..self.teamOrig)
	-- 	-- 	if obj.teamOrig~=self.teamOrig then
	-- 	-- 		ok = true
	-- 	-- 		if (obj:isDead()) then ok = false end
	-- 	-- 		if (atknum<=0) then ok = false end
	-- 	-- 		----debuglog('jaylog ok:'..ok)
	-- 	-- 		if ok then
	-- 	-- 			local d = obj:colliding(visRange,0,0,self.itemID)
	-- 	-- 			----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
	-- 	-- 			if (d>=0) then 
	-- 	-- 				atknum = atknum - 1
	-- 	-- 				dlist[#dlist+1] = obj   
	-- 	-- 			end
	-- 	-- 		end
	-- 	-- 	end
	-- 	-- end

	-- 	--找到目标释放一个群体aoe在目标脚下
	-- 	for k,obj in pairs(dlist) do
	-- 		----debuglog('jaylog dlist:'..k)
	-- 		local skill = self.attribute.skills[11] 
	-- 		local parameters = skill.parameters 
	-- 		--APADJ=125;DEF_DOWN=50;DEF_DOWN_RATE=100;BUFFTIME=10

	-- 		----debuglog("hitTime_:"..skill.hitTime)
	-- 		--debuglog("jaylog SBoss1A:prepareHit: duration"..parameters.HURTLIFE..' buffIntervalTime:'..parameters.HURTITNTERVAL)
	-- 		local creatureID=self.world:addCreature(self.world.tostring(parameters.ENEMY),self.teamOrig,obj.posX,obj.posY,self,1,0)
	-- 		local obj  = self.world.allItemList[creatureID]
	-- 		self.creatureList[#self.creatureList+1]=creatureID  
	-- 		local lifeTime=parameters.HURTLIFE		--skill.parameters.DEAD
	-- 		local attributes = {}
	-- 		attributes['buffParameter']={}
	-- 		attributes['BUFFONLY']=1
	-- 		--debuglog("xxxxxxxxxxxxxxxxxx SBoss4A:prepareHit------------....hitValueBoth:"..self.world.cjson.encode(hitValueBoth))
	-- 		attributes['buffParameter'] = hitValueBoth
	-- 		--attributes['buffParameter']['FIXHURT'] = 250
	-- 		-----debuglog("atkDis:"..parameters.hitTime)
	-- 		attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
	-- 		attributes['buffParameter']['creatureDirectHurCallBack'] = creatureID
	-- 		----debuglog("jaylog addCreature  creatureID:"..creatureID)
	-- 		attributes['buffParameter']['buffType'] = 1
	-- 		--attributes['buffParameter']['buffAtleastOnce']=true
	-- 		attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
	-- 		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,parameters.HURTSTARTTIME)
	-- 		obj:addBuff(buff)
	-- 		obj:setDeadTime(lifeTime) 
	-- 	end
	-- 	hitValueBoth = nil
	-- end



	if mode==6 or mode==24 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		for i=1,parameters.CREATENUME do
			local toX,toY = self.world.formula:getRandomCirclePoint(0,0,parameters.R1,true)
			local x = self.posX
			local y = self.posY
			local ret,toX,toY=self.world.map:findPointStraightLineNearest(x,y,x+toX,y+toY)

			local creatureID=self.world:addCreature(self.world.tostring(147),self.teamOrig,toX,toY,self,1,0)
			--local creatureID=self.world:addCreature(self.world.tostring(parameters['tpID'..i]),self.teamOrig,self.posX+i*3,self.posY,self,1,0)
			local obj  = self.world.allItemList[creatureID]
			self.creatureList[#self.creatureList+1]=creatureID  
			local attributes = {}
			attributes['IMMUNEAD_RATE'] = 100 
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,9999,{},0,self.itemID,self.itemID,0.1)
			obj:addBuff(buff)
		end
	
	end

	if mode==7 or mode==25 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		for i=1,parameters.CREATENUME do
			local toX,toY = self.world.formula:getRandomCirclePoint(0,0,parameters.R1,true)
			local x = self.posX
			local y = self.posY
			local ret,toX,toY=self.world.map:findPointStraightLineNearest(x,y,x+toX,y+toY)

			local creatureID=self.world:addCreature(self.world.tostring(148),self.teamOrig,toX,toY,self,1,0)
			--local creatureID=self.world:addCreature(self.world.tostring(parameters['tpID'..i]),self.teamOrig,self.posX+i*3,self.posY,self,1,0)
			local obj  = self.world.allItemList[creatureID]
			self.creatureList[#self.creatureList+1]=creatureID  
			local attributes = {}
			attributes['IMMUNEAP_RATE'] = 100 
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,9999,{},0,self.itemID,self.itemID,0.1)
			obj:addBuff(buff)
		end
	end


	if mode==12 then
		--debuglog("转场清除场上的小怪.....")
		for k,v in pairs(self.world.allItemList) do
			if not v:isDead() and (v.subName=="BLACK_BALL" or v.subName=="WHITE_BALL")  then
				--debuglog("转场清除场上的小怪.....itemID:"..v.itemID)
				v.attribute.HP=0
				v:addStatusList({s=42,r=self.world.gameTime,t=16,i=v.itemID},0.2)
			end  
		end
	end

	return hitValueBoth 
end 


--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss4A:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	if mode==10 or mode==22 then
		--成就 	天谴啦！
		local obj  = self.world.allItemList[itemID]
		obj:setCounter("thundered_2004",1)
	end
	local ret = SBoss4A.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	return ret 
end 

--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SBoss4A:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	local hurt = SBoss4A.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
	if isset(hitValue['creatureDirectHurCallBack']) and hitValue['creatureDirectHurCallBack']=="gl"  then 
		--成就 是要滚还是不滚
		local obj  = self.world.allItemList[itemID]
		obj:setCounter("rollingThundered_2004",1)
	end
end


--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SBoss4A:goToDead(itemID,mode,adjTime,bonus)
	local obj  = self.world.allItemList[itemID]
	--成就 嘿嘿嘿嘿！
	obj:setCounter("lastKill_2004",1)
	local dlist = {}
	local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if ok then
					dlist[#dlist+1] = obj   
				end
			end
		end
		)

	
	if #dlist==1 then
		--成就 拯救世界的我
		obj:setCounter("killBossOnlyMeAlive_2004",1)
	end

	ret = SBoss4A.super.goToDead(self,itemID,mode,adjTime,bonus) 
	return ret
end

--- 子彈完結callback
-- @param bulletID int - 子彈ID
-- @return null
function SBoss4A:endBullet(bulletID)
	self.mode3list={}
end



return SBoss4A 