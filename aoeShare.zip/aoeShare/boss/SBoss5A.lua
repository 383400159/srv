local SBoss5A = class("SBoss5A", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss5A:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss5A" 
	end 
	self.mode8ObjList = {}
	SBoss5A.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		----debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
end 

function SBoss5A:goToDead(itemID,mode,adjTime,bonus)  
	SBoss5A.super.goToDead(self,itemID,mode,adjTime,bonus) 
end 



--- move motion , call every update loop
-- @return null
function SBoss5A:move()
	SBoss5A.super.move(self)
end

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SBoss5A:goToDead(itemID,mode,adjTime,bonus)
	ret = SBoss5A.super.goToDead(self,itemID,mode,adjTime,bonus) 

end


--- 這個function 會在 執行前搖時call 當skill.delayCalTime>0
-- @param skill skillobj - skillobj
function SBoss5A:prepareSkillAttackDelayInit(skill)
	local hitValueBoth = SBoss5A.super.prepareSkillAttackDelayInit(self,skill)
	local mode=skill.rank
	if mode==5 or mode==18 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local obj = self.world.allItemList[self.lastBulletTarget]
		obj:addStatusList({s=4131,r=self.world.gameTime,t=99,i=self.itemID})	
	end

end



--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss5A:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SBoss5A.super.prepareHit(self,mode,adjTime,buff) 

	if mode==5 or mode==18 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local obj = self.world.allItemList[self.lastBulletTarget]
		local d1 = self:distance(obj.posX,obj.posY)
		--local d2 = (d1-self.attribute.width)>0 and (d1-self.attribute.width) or d1
		local ret,toX,toY = self.world.map:findNearestIdlePoint(self.posX,self.posY,obj.posX,obj.posY,d1)
		local d = self:distance(toX,toY)
		local FLYSPEED = (d*100)/parameters.FLYTIME
		self:moveTo(toX,toY,false,1,FLYSPEED,skill.hitTime+adjTime)
	end


	if mode==4 or mode==17 then
		--ADDSTATUS=35;ADDSTATUSTIME=3;FLYTIME=0.35
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local d1 = self:distance(self.lastBulletPositionX,self.lastBulletPositionY)
		local atkDis = (d1-parameters.NEARESTUSEDIS/self.world.setting.AdjustAttRange)>0 and (d1-parameters.NEARESTUSEDIS/self.world.setting.AdjustAttRange) or d1

		local toX1,toY1 = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,atkDis)
		local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX1,self.posY+toY1) 
		--local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY)
		--debuglog("伊利丹 大招 posX:"..self.posX.." posY:"..self.posY.." lastBulletPositionX:"..self.lastBulletPositionX.." lastBulletPositionY:"..self.lastBulletPositionY.." toX:"..toX.." toY:"..toY)
		local d = self:distance(toX,toY)
		-- local stopD=parameters.STOPTIME*5
		-- local FLYSPEED = ((d-stopD)*100)/(parameters['FLYTIME']+parameters['DOWNTIME'])
		local FLYSPEED = (d*100)/(parameters['FLYTIME'])

		self:moveTo(toX,toY,false,6,FLYSPEED,skill.hitTime+adjTime)
		--local dealyTime = (d*100)/parameters['FLYSPEED']
		local dealyTime = parameters['FLYTIME']
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['buffParameter'] = {}
		attributes['buffParameter']['buffIntervalTime'] = dealyTime
		local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,dealyTime*1.1,{mode},0,self.itemID,self.itemID,skill.hitTime+adjTime) 
 		self:addBuff(buffObj)
 		--debuglog("伊利丹 大招 d:"..d.."dealyTime:"..dealyTime.." lastBulletPositionX:"..self.lastBulletPositionX.." lastBulletPositionY:"..self.lastBulletPositionY.." posX"..self.posX.." posY:"..self.posY)
		hitValueBoth=nil
		self.mode4time = self.world.gameTime+skill.hitTime+adjTime+dealyTime*0.1

		-- local hitValueNew={}
		-- hitValueNew['ATK_UPFIX_RATE']=parameters.ATK_UPFIX_RATE3 
		-- hitValueNew["ATK_UPFIX"]=parameters.ATK_UPFIX3
		-- hitValueNew["BUFFTIME"]=parameters.BUFFTIME3
		-- self:directHurt(self.itemID,mode,hitValueNew,0) 


		self.lastBulletPositionX = toX
		self.lastBulletPositionY = toY
		return nil
	end

	if mode==104 or mode==117 then
		local skill = self.attribute.skills[mode-100] 
		local parameters = skill.parameters 
		if self.world.gameTime>self.mode4time then
			debuglog("伊利丹 大招 回调")
			local hitValueNew = hitValueBoth
			hitValueNew['skillID'] = mode-100
			hitValueNew['ADADJ'] = parameters.ADADJ2 
			self:directFightAuratoDalay(mode-100,0,hitValueNew,{posX=self.posX,posY=self.posY,RANGE=skill.atkDis},0) 

		end
		hitValueBoth=nil
	end



	if mode==8 then
		self:D("一粒蛋影魔召唤  开始找目标",self.teamOrig)
		local skill = self.attribute.skills[8] 
		local parameters = skill.parameters 
		local teamlist = {}

		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		----debuglog('jaylog useDis:'..skill.useDis..' AdjustAttRange:'..self.world.setting.AdjustAttRange)
		local dlist = {}
		local atknum = 9

		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if (atknum<=0) then ok = false end
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
	
					if (d>=0) then 
						atknum = atknum - 1
						dlist[#dlist+1] = obj   
					end
				end
			end
		end
		)

		--分3种颜色 最少2个
		local colourR = self.world.formula:getRandnum(0,3)
		local colourG = self.world.formula:getRandnum(0,3-colourR)
		local colourB = 3-(colourR+colourG)

		--可以分配的颜色
		local colourlist = {}
		local R = 2 + colourR
		for i=1,R do
			colourlist[#colourlist+1] = 'R'
		end
		local G = 2 + colourG
		for i=1,G do
			colourlist[#colourlist+1] = 'G'
		end
		local B = 2 + colourB
		for i=1,B do
			colourlist[#colourlist+1] = 'B'
		end
		colourlist=table.shuffle(colourlist)
		self:D("一粒蛋影魔召唤  colourlist:",self.world.cjson.encode(colourlist))
		--打乱玩家
		--ADDSTATUS2=41;ADDSTATUSTIME2=8;CLEANSELFSTATUS=4118;RADIUS=300;DURATION=8;HURTTIME=9;HURTINTERVAL=1;HURT=10;ENEMYHP=7
		dlist=table.shuffle(dlist)
		for k,v in pairs(dlist) do
			--给玩家添加对应的颜色buff
			if colourlist[k]=='R' then
				self:D("一粒蛋影魔召唤   添加R状态:",v.itemID)
				v:addStatusList({s=4113,r=self.world.gameTime,t=parameters.DURATION,i=self.itemID})
				v.colour = "R"
			end
			if colourlist[k]=='G' then
				self:D("一粒蛋影魔召唤   添加G状态:",v.itemID)
				v:addStatusList({s=4114,r=self.world.gameTime,t=parameters.DURATION,i=self.itemID})
				v.colour = "G"
			end
			if colourlist[k]=='B' then
				self:D("一粒蛋影魔召唤   添加B状态:",v.itemID)
				v:addStatusList({s=4115,r=self.world.gameTime,t=parameters.DURATION,i=self.itemID})
				v.colour = "B"
			end
		end
		-- self:addStatusList({s=parameters.ADDSTATUS2,r=self.world.gameTime,t=parameters.ADDSTATUSTIME2,i=self.itemID})	
		self:addStatusList({s=parameters.ADDSTATUS3,r=self.world.gameTime,t=parameters.ADDSTATUSTIME3,i=self.itemID})	
		self.mode8ObjList = dlist
	end

	if mode==108 then
		self:D("一粒蛋影魔召唤  结算")
		local skill = self.attribute.skills[8] 
		local parameters = skill.parameters 
		--结算 看看玩家有没有站一起
		local endlist = {}
		for k,v in pairs(self.mode8ObjList) do
			self:D("一粒蛋影魔召唤  结算 开始玩家检测:",v.itemID)
			local a = {itemID=v.itemID,num=0}
			local visRange = {posX=v.posX,posY=v.posY,radius=(parameters.RADIUS/self.world.setting.AdjustVisRange)}
			for k,obj in pairs(self.mode8ObjList) do
				--self:D("一粒蛋影魔召唤  结算 被检测:",obj.itemID)
				--拿其他玩家的位置进行对比
				if obj.itemID~=v.itemID then
					ok = true
					if (obj:isDead()) then ok = false end
					if ok then
						local d = obj:colliding(visRange,0,0,v.itemID)
						self:D("一粒蛋影魔召唤  结算 被检测d:",obj.itemID,d)
						if (d>0) then 
							--判断2个靠近玩家的颜色
							if obj.colour==v.colour then
								a['num'] = a['num'] + 1 
							else
								a['num'] = a['num'] + 10
							end
						end
					end
				end
			end
			if a['num']==0 or a['num']>=10 then
				endlist[#endlist+1]=v
				self:D("一粒蛋影魔召唤  抱团itemiD不安全:",v.itemID)
			end
		end

		--判断玩家是否安全
		for k,v in pairs(endlist) do
			self:D("一粒蛋影魔召唤  抱团itemiD不安全  添加状态4116:",v.itemID)
			if v.st4116List==nil then
				v.st4116List = {}
			end
			v.st4116List[#v.st4116List+1]={starTime=self.world.gameTime,t=parameters.HURTTIME,hp=parameters.ENEMYHP}
			v:addStatusList({s=4116,r=self.world.gameTime,t=parameters.HURTTIME,i=self.itemID})	
		end
	

	end

	--闪现
	if mode==10 then
		local skill = self.attribute.skills[10] 
		local parameters = skill.parameters
		--debuglog("BOSS2A mode 12  移动到:POSX:"..parameters.POSX.." POSY:"..parameters.POSY) 
		self:moveTo(parameters.FLASHPOINTX,parameters.FLASHPOINTY,true,1)
	end

	if mode==12 then
		local skill = self.attribute.skills[12] 
		local parameters = skill.parameters
		self:addStatusList({s=parameters.ADDSTATUS2,r=self.world.gameTime,t=parameters.ADDSTATUSTIME2,i=self.itemID})
	end
	return hitValueBoth 
end 

function SBoss5A:createInit()
	self:callCreateInit()
end
--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss5A:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 

	ret = SBoss5A.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	if mode==3 or mode==16 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		if (self.attribute.HP/self.attribute.MaxHP)*100<(parameters.BOSSREHPMAX-parameters.BOSSREHP)   then
  			--debuglog("伊利丹 BOSS回血前:"..self.attribute.HP)
			local bossHitValueNew = {}
	 		bossHitValueNew['FIXHURT']  = -self.attribute.MaxHP*parameters.BOSSREHP*0.01
	  		self:directHurt(self.itemID,1,bossHitValueNew,0) 
	  		--debuglog("伊利丹 BOSS回血后:"..self.attribute.HP.." FIXHURT:"..bossHitValueNew['FIXHURT'].." MaxHP:"..self.attribute.MaxHP.." BOSSREHP:"..parameters.BOSSREHP*0.01)
  		end
  		self:addStatusList({s=parameters.ADDSELFSTATUS2,r=self.world.gameTime,t=parameters.ADDSELFSTATUSTIME2,i=self.itemID})
	end

	return ret 
end 

return SBoss5A 