local SBoss1A = class("SBoss1A", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss1A:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss1A" 
	end 
	self.creatureList = {}
	--共生id 相互复活
	self.coexistID = 0
	self.coexistRevivetTime = 0
	--boss阶段
	self.bossType = 1
	--复活比例
	self.hpProp = 1
	self.addStatusTime = 0 				--增加

	--已释放列表
	self.mode7yslist = {}
	SBoss1A.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		----debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end		


end 

--boss免控
function SBoss1A:addIMMUNECONTROLBUFF()
	--IMMUNECONTROL_RATE=100

	self:D("fenglog addIMMUNECONTROLBUFF boss itemID:",self.itemID)
	-- --debuglog("boss allItemList:"..self.world.cjson.encode(self.world.allItemList[self.itemID]))
	self:callCreateInit()
	-- 	--APADJ=0;ADADJ=150;DEF_UP2=35;IMMUNECONTROL_RATE2=100;BUFFTIME2=5;CDTIME=30
	-- 	local skill = self.attribute.skills[5] 
	-- 	local parameters = skill.parameters 
	-- 	local attributes = {}
	-- 	attributes['DEF_UP'] = parameters.DEF_UP2
	-- 	attributes['IMMUNECONTROL_RATE'] = parameters.IMMUNECONTROL_RATE2
	-- 	attributes['BUFFTIME'] = parameters.BUFFTIME2
	-- 	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,parameters.BUFFTIME2,{},0,self.itemID,self.itemID,0)
	-- 	self:addBuff(buff)

end



--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss1A:prepareHit(mode,adjTime,buff)  

	----debuglog("SBoss1A:prepareHit....mode:"..mode..' adjtime:'..adjTime)
	local hitValueBoth=SBoss1A.super.prepareHit(self,mode,adjTime,buff) 
	----debuglog("SBoss1A:prepareHit....hitValueBoth:"..self.world.cjson.encode(hitValueBoth))

	-- if mode==5 then
	-- 	local skill = self.attribute.skills[5] 
	-- 	local parameters = skill.parameters 
	-- 	local teamlist = {}
	-- 	--搜敌找到所需要的目标
	-- 	-- if ( self.teamOrig=="A")  then
	-- 	-- 	teamlist=self.world.itemListFilter.teamB
	-- 	-- else
	-- 	-- 	teamlist=self.world.itemListFilter.teamA
	-- 	-- end
	-- 	----debuglog('jaylog teamlist:'..self.world.cjson.encode(teamlist))
	-- 	local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
	-- 	----debuglog('jaylog useDis:'..skill.useDis..' AdjustAttRange:'..self.world.setting.AdjustAttRange)
	-- 	local dlist = {}
	-- 	local atknum = parameters.TARGETNUM
	-- 	local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
	-- 	function(obj)
	-- 	 	if obj.teamOrig~=self.teamOrig then
	-- 			ok = true
	-- 			if (obj:isDead()) then ok = false end
	-- 			if (atknum<=0) then ok = false end
	-- 			----debuglog('jaylog ok:'..ok)
	-- 			if ok then
	-- 				local d = obj:colliding(visRange,0,0,self.itemID)
	-- 				----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
	-- 				if (d>=0) then 
	-- 					atknum = atknum - 1
	-- 					dlist[#dlist+1] = obj   
	-- 				end
	-- 			end
	-- 		end
	-- 	end
	-- 	)
		
	-- 	-- local enemy = self:getEnemylist()
	-- 	-- for k,obj in pairs(enemy) do
	-- 	-- 	----debuglog('jaylog allItemList:'..k..' id:'..obj.itemID..' ot:'..obj.teamOrig..' st:'..self.teamOrig)
	-- 	-- 	if obj.teamOrig~=self.teamOrig then
	-- 	-- 		ok = true
	-- 	-- 		if (obj:isDead()) then ok = false end
	-- 	-- 		if (atknum<=0) then ok = false end
	-- 	-- 		----debuglog('jaylog ok:'..ok)
	-- 	-- 		if ok then
	-- 	-- 			local d = obj:colliding(visRange,0,0,self.itemID)
	-- 	-- 			----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
	-- 	-- 			if (d>=0) then 
	-- 	-- 				atknum = atknum - 1
	-- 	-- 				dlist[#dlist+1] = obj   
	-- 	-- 			end
	-- 	-- 		end
	-- 	-- 	end
	-- 	-- end

	-- 	--找到目标释放一个群体aoe在目标脚下
	-- 	for k,obj in pairs(dlist) do
	-- 		----debuglog('jaylog dlist:'..k)
	-- 		local skill = self.attribute.skills[5] 
	-- 		local parameters = skill.parameters 


	-- 		----debuglog("hitTime_:"..skill.hitTime)
	-- 		self:D("jaylog SBoss1A:prepareHit: duration",skill.duration,' buffIntervalTime:',skill.bulletTimeInterval)
	-- 		local creatureID=self.world:addCreature(self.world.tostring(100+12),self.teamOrig,obj.posX,obj.posY,self,1,parameters.ATKDISSHOWDELAY)
	-- 		local obj  = self.world.allItemList[creatureID]
	-- 		self.creatureList[#self.creatureList+1]=creatureID  
	-- 		local lifeTime=skill.duration 			--skill.parameters.DEAD
	-- 		local attributes = {}
	-- 		attributes['buffParameter']={}
	-- 		attributes['BUFFONLY']=1
	-- 		attributes['buffParameter'] = table.deepcopy(hitValueBoth)
	-- 		--attributes['buffParameter']['FIXHURT'] = 250
	-- 		-----debuglog("atkDis:"..parameters.hitTime)
	-- 		attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
	-- 		attributes['buffParameter']['creatureDirectHurCallBack'] = creatureID
	-- 		----debuglog("jaylog addCreature  creatureID:"..creatureID)
	-- 		attributes['buffParameter']['buffType'] = 1
	-- 		--attributes['buffParameter']['buffAtleastOnce']=true
	-- 		attributes['buffParameter']['buffIntervalTime'] = skill.bulletTimeInterval
	-- 		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,skill.hitTime)
	-- 		obj:addBuff(buff)
	-- 		obj:setDeadTime(lifeTime) 
	-- 	end
	-- 	hitValueBoth = nil
	-- end

	
	--召唤传送门和梦境分身
	--BUFFTIME2=100;PASSCD=1;PASSNUM=3;PASSRANGE=200;PORTALX=92;PORTALY=243;DREAMBODYX=115;DREAMBODYY=45
	if mode==9  then
		local skill = self.attribute.skills[9] 
		local parameters = skill.parameters 

		local creatureID=self.world:addCreature(self.world.tostring(111),self.teamOrig,parameters.PORTALX,parameters.PORTALY,self,1,adjTime) 
		--local creatureID=self.world:addNPC(self.world.tostring(111),self.teamOrig,parameters.PORTALX,parameters.PORTALY,self,1,adjTime) 
		self.world.transitDoor = self.world.allItemList[creatureID]
		local obj1  = self.world.allItemList[creatureID]
		if parameters.SUBNAME~=nil then
			obj1:setSubName(parameters.SUBNAME)
		end
		--self.creatureList[#self.creatureList+1]=creatureID 
		----debuglog('jaylog mode 9 x:'..parameters.PORTALX..' y:'..parameters.PORTALY..' t:'..self.teamOrig..' id:'..obj.itemID..' creatureID:'..creatureID) 
		local lifeTime=9999
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		--attributes['buffParameter'] = table.deepcopy(hitValueBoth)
		--attributes['buffParameter']['INVICINBLE_RATE'] = 100
		--attributes['buffParameter']['FIXHURT'] = 250
		attributes['INEVITABLEHIT'] = 1
		attributes['buffParameter']['RANGE'] = obj1.attribute.width * self.world.setting.AdjustAttRange
		attributes['buffParameter']['creatureDirectHurCallBack'] = creatureID
		----debuglog("jaylog addCreature  creatureID:"..creatureID)
		attributes['buffParameter']['buffType'] = 1 			--parameters.PASSNUM
		attributes['buffParameter']['buffIntervalTime'] = 0.2 	--parameters.PASSCD
		attributes['BUFFTIME'] = 9999
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,0.1)
		--buff.debug = true
		obj1:addBuff(buff)
		----debuglog('jaylog finish transitDoor addBuff')
		obj1:setDeadTime(lifeTime) 
		self.world.gameFlag['passTransitDoorLastNum'] = parameters.PASSNUM
		self.world.transitDoor:addStatusList({s=4002,r=self.world.gameTime,t=99999,i=self.world.transitDoor.itemID,p1=self.world.gameFlag['passTransitDoorLastNum']},0.2)
	end

	
	if mode==12  then

		local skill = self.attribute.skills[12] 
		local parameters = skill.parameters 

		-- local toX,toY = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,300/self.world.setting.AdjustAttRange)
		-- local ret
		-- --print("prepareHit 飞飞飞........ x tox y toy distance ",self.posX,toX,self.posY,toY,(skill.atkDis-parameters.MOVECUT)/self.world.setting.AdjustAttRange)
		-- ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX,self.posY+toY) 

		--self:addStatusList({s=41,r=self.world.gameTime,t=parameters.CHANTTIME,i=self.itemID})

		local TABLE_X1 = parameters.TABLE_X1 
		local TABLE_Y1 = parameters.TABLE_Y1 
		local randsk=self.world.formula:getRandnum(1,#TABLE_X1)
		----debuglog("boss1A TABLE_X1:"..self.world.cjson.encode(TABLE_X1))

		local obj=self.world:addBoss(1001,self.teamOrig,"造梦者5人（P3)",TABLE_X1[randsk],TABLE_Y1[randsk],parameters.SKINNO)
		if parameters.SUBNAME~=nil then
			obj:setSubName(parameters.SUBNAME)
		end
		self.world:D('jaylog add boss3 before HP',obj.attribute.HP,' SKINNO',parameters.SKINNO,' SUBNAME',parameters.SUBNAME)
		obj.attribute.HP = self.attribute.MaxHP*0.1
		----debuglog('jaylog add boss3 after HP'..obj.attribute.HP)
		local result = obj:getAllInfo()
		obj:updateSyncMsg({i=result})
		self.world.bossObj3 = obj
		obj:addStatusList({s=9003,r=self.world.gameTime,t=99999,i=self.world.bossObj3.itemID},0.2)	--用于识别是PART3中的BOSS
		self:setCoexistID(obj.itemID)
		obj:setCoexistID(self.itemID)

		local attributes = {}
		attributes['IMMUNEAP_RATE'] = 100 
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,9999,{},0,self.itemID,self.itemID,0.1)
		self:addBuff(buff)

		local attributes = {}
		attributes['IMMUNEAD_RATE'] = 100 
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,9999,{},0,obj.itemID,obj.itemID,0.1)
		obj:addBuff(buff)

	end

--	--debuglog('jaylog skill mode '..mode)
	if (mode==13) then 
		----debuglog('jaylog boss start run skill 13 add loop buff')
 		local skill = self.attribute.skills[13] 
		local parameters = skill.parameters 
		self:D("fenglog goToDead 给对方释放一个状态 13技能 gameTime:"..self.world.gameTime)
		-- self.coexistRevivetTime = self.world:getGameTime() + parameters.CHANTTIME
		----debuglog('jaylog coexistRevivetTime:'..self.coexistRevivetTime)
 		--local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),{BUFFONLY=1,buffParameter={buffTargetPosX=self.lastBulletPositionX,buffTargetPosY=self.lastBulletPositionY,buffIntervalTime=parameters.INTERVALTIME}},skill.duration,{mode},0,self.itemID,self.itemID,adjTime+skill.hitTime) 
 		--local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),{BUFFONLY=1,buffParameter={buffTargetPosX=self.lastBulletPositionX,buffTargetPosY=self.lastBulletPositionY,buffIntervalTime=1}},skill.duration,{mode},0,self.itemID,self.itemID,adjTime+skill.hitTime) 
 		-- local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),{BUFFONLY=1,buffParameter={buffTargetPosX=self.lastBulletPositionX,buffTargetPosY=self.lastBulletPositionY,buffIntervalTime=0.5}},parameters.CHANTTIME+1,{mode},0,self.itemID,self.itemID,0) 
 		-- self:addBuff(buffObj)
 	 	self:addStatusList({s=41,r=self.world:getGameTime(),t=parameters.CHANTTIME,i=self.itemID}) 
		local obj = self.world.allItemList[self.coexistID]
 	 	obj:addStatusList({s=4013,r=self.world:getGameTime(),t=parameters.CHANTTIME,i=obj.itemID})
 		obj.hpProp = self.world.tonumber(parameters.REBORNHP)*0.01
		self.statusList[4012]=nil
		return nil
	end 
	if (mode==113) then 
		--計第8秒就 reset deadTime
		--self:debuglog("fenglog goToDead 给对方释放一个状态 113技能 gameTime:"..self.world.gameTime)
		local obj = self.world.allItemList[self.coexistID]
		----debuglog('jaylog start run skill 113 crtime'..self.coexistRevivetTime..' gt:'..self.world.gameTime..' cid:'..self.coexistID..' selfid:'..self.itemID..' isDead:'..self.world.cjson.encode(obj:isDead())..' status:'..obj.status)
		if obj:isDead() then
			----debuglog('jaylog set deadtime 0')
			self.buffList[self:__skillID2buffID(13,0)].isRemove = 1
			mode = 13
			obj.deadTime = 0
			local skill = self.attribute.skills[13] 
			local parameters = skill.parameters 
			obj.hpProp = self.world.tonumber(parameters.REBORNHP)*0.01
			obj:removeStatusList(4013)
			self:removeStatusList(41)
			if self.attribute.HP<self.attribute.MaxHP*self.world.tonumber(parameters.CASTERHP)*0.01 and self.world.tonumber(parameters.CASTERHP)~=0 then
				self.attribute.HP = self.attribute.MaxHP*self.world.tonumber(parameters.CASTERHP)*0.01
				--local result = self:getAllInfo()
				--self:updateSyncMsg({i=result})
			end
		end
		return nil
	end

	if mode==15 then
		local skill = self.attribute.skills[15] 
		local parameters = skill.parameters 

		local obj=self.world:addBoss(1001,self.teamOrig,"造梦者5人（P1和P2）",parameters.DREAMBODYX,parameters.DREAMBODYY,parameters.SKINNO)
		if parameters.SUBNAME~=nil then
			obj:setSubName(parameters.SUBNAME)
		end
		self.world.bossObj2 = obj
		self:setShared(obj.itemID)
		obj:setShared(self.itemID)	
		--obj.attribute.HP = self.attribute.HP 		--*(parameters.DREAMBODYHP/100)
		--obj.attribute.MaxHP = self.attribute.MaxHP  --*(parameters.DREAMBODYHP/100)
		self.attribute:cloneProperty(obj)
		--obj:updateSyncMsg({i={mhp=(obj.attribute:getMaxHP()),mmp=(obj.attribute:getMaxMP())}})
		----debuglog('jaylog boss hp:'..obj.attribute.HP..' mhp:'..obj.attribute.MaxHP)
		-- local result = obj:getAllInfo()
		-- obj:updateSyncMsg({i=result})
		-- --debuglog('jaylog show synMsg:'..self.world.cjson.encode(obj.syncMsg)..' result:'..self.world.cjson.encode(result))
		-- obj:updateSyncMsg({i={t=obj.teamOrig,a=obj.attribute.ID,at=obj.attribute.actorType,hp=obj.attribute.HP,mp=obj.attribute.MP,
		-- 	mhp=(obj.attribute:getMaxHP()),s=0,st=0,x=obj.posX,y=obj.posY,mmp=(obj.attribute:getMaxMP()),
		-- 	l=obj.attribute.level,rehp=obj.attribute.REHP,remp=obj.attribute.REMP,mhpe=obj.attribute.MaxHPEXTRA,
		-- 	aspdr=obj.attribute.ASPDR,mspdr=obj.attribute.MSPDR,ne=obj.attribute.nextexp,v=obj.attribute.VISRNG,si=obj.skinNum}})
		obj:addStatusList({s=4009,r=self.world.gameTime,t=99999,i=self.world.bossObj2.itemID},0.2)
		obj:addStatusList({s=9002,r=self.world.gameTime,t=99999,i=self.world.bossObj2.itemID},0.2)	--用于识别是梦境中的BOSS
	end

	return hitValueBoth 
end 


--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss1A:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	if mode==6 then
		--local targetShareObj=self.world:addHero(1001,targetObj.teamOrig,targetObj.id..'Tmp',targetObj.posX+10,targetObj.posY+10)
		local target = self.world.allItemList[itemID]
		if target.attribute.actorType==0 and target.statusList[4007]==nil and target.inTransitDoor~=nil and not target.inTransitDoor then
			--local num = self.world.formula:getRandnum(5,20)
			local skill = self.attribute.skills[6] 
			local parameters = skill.parameters 

			local TABLE_X1 = parameters.TABLE_X1 
			local TABLE_Y1 = parameters.TABLE_Y1 
			local randsk=self.world.formula:getRandnum(1,#TABLE_X1)

			local creatureID=self.world:addCreature(self.world.tostring(113),target.teamOrig,target.posX,target.posY,target,1,parameters.DREAMDELAY,target.attribute.roleId,target.attribute.actorType)  
			local targetShareObj = self.world.allItemList[creatureID]
			
			local lifeTime=9999
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			--attributes['buffParameter'] = table.deepcopy(hitValueBoth)
			--attributes['buffParameter']['FIXHURT'] = 250
			attributes['buffParameter']['RANGE'] = targetShareObj.attribute.width * self.world.setting.AdjustAttRange
			attributes['buffParameter']['creatureDirectHurCallBack'] = creatureID
			attributes['buffParameter']['buffType'] = 5			--parameters.PASSNUM
			attributes['BUFFTIME'] = 9999
			attributes['buffParameter']['buffIntervalTime'] = 0.5
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,0.1)
			targetShareObj:addBuff(buff)
			targetShareObj:setDeadTime(lifeTime) 

			targetShareObj:setShared(target.itemID)
			target.attribute:cloneProperty(targetShareObj)
			-- targetShareObj.attribute.HP = target.attribute.HP
			-- targetShareObj.attribute.MaxHP = target.attribute.MaxHP
			-- targetShareObj.attribute.baseTable.HP = target.attribute.baseTable.HP
			-- targetShareObj.attribute.baseTable.MaxHP = target.attribute.baseTable.MaxHP
			-- targetShareObj.attribute.MP = target.attribute.MP
			-- targetShareObj.attribute.MaxMP = target.attribute.MaxMP
			-- targetShareObj.attribute.DEF = target.attribute.DEF
			-- targetShareObj.attribute.MDEF = target.attribute.MDEF
			-- targetShareObj.attribute.baseTable.DEF = target.attribute.baseTable.DEF
			-- targetShareObj.attribute.baseTable.MDEF = target.attribute.baseTable.MDEF
			-- targetShareObj.attribute.HIT = target.attribute.HIT
			-- targetShareObj.attribute.DODGE = target.attribute.DODGE
			-- local result = targetShareObj:getAllInfo()
			-- targetShareObj:updateSyncMsg({i=result})

			targetShareObj:addStatusList({s=22,r=self.world:getGameTime(),t=99999},parameters.DREAMDELAY)
			targetShareObj:addStatusList({s=4001,r=self.world.gameTime,t=99999})
			targetShareObj:addStatusList({s=4006,r=self.world.gameTime,t=99999,p1=target.itemID},parameters.DREAMDELAY)
			----debuglog('jaylog targetShareObj mode 6 itemID:'..targetShareObj.itemID..' creatureID:'..creatureID..' hp:'..targetShareObj.attribute.HP..' maxhp:'..targetShareObj.attribute.MaxHP..' selfhp:'..target.attribute.HP..' selfmaxhp:'..target.attribute.MaxHP..' selfitemid:'..target.itemID)
			--传目标分身信息给client
			-- self.world:syncRoomInfo()

			local attributes = {}
			attributes['STOPMOVE_RATE'] = 100 
			attributes['DIZZY_RATE'] = 100
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,1.5,{},0,target.itemID,target.itemID,0.1)
			target:addBuff(buff)
			-- target:removeBUff('STOPMOVE')
			--target:setDeadTime(lifeTime)
			--在目标身上加无敌状态
			--local lifeTime=9999
			local attributes = {}
			attributes['INVICINBLE_RATE'] = 100
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,lifeTime,{},0,target.itemID,target.itemID,0.1)
			target:addBuff(buff)
			----debuglog('jaylog boss skill mode 6 moveTo delaytime:'..parameters.DREAMDELAY)

			target:setShared(creatureID)
			--target:addStatusList({s=38,r=self.world:getGameTime(),t=999},0)
			target:addStatusList({s=4007,r=self.world.gameTime,t=99999},parameters.DREAMDELAY)
			target:addStatusList({s=4008,r=self.world.gameTime,t=1},parameters.DREAMDELAY)
			target:addStatusList({s=4010,r=self.world.gameTime,t=99999},parameters.DREAMDELAY)
			target:moveTo(TABLE_X1[randsk],TABLE_Y1[randsk],true,1,999999,parameters.DREAMDELAY+0.1)
			target:control()
			self.prepareSkillAttackNum = 0
		end
	end

	if mode==7 then
		if self.world.allItemList[itemID]~=nil and self.world.allItemList[itemID].statusList[4005]~=nil then
			self.world.allItemList[itemID]:removeStatusList(4005)
		end
	end

	if mode==8 then
		----debuglog('jaylog hitTarget mode '..mode..' targetID:'..itemID)
	end
	ret = SBoss1A.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	return ret 
end 



--设置共存id
function SBoss1A:setCoexistID(id)
	self.coexistID = id
end

--设置共享生命id 
function SBoss1A:setSharedID(id)
	self.sharedID = id
end



--- 复活, 游戏loop
-- @param null
-- @return null
function SBoss1A:revive()
	if self.deadTime<=self.world:getGameTime() then
		--用于
		self.AIlastCoolDown = self.world:getGameTime() + 3

		self:removeStatusList(9)
		self.towerComplete = 0
		if table.nums(self.buffList)>0 then
			local recal = false
			local skillID = 0
			for k,v in pairs(self.buffList) do
				skillID = v.buffID%1000000
				if skillID<990000 then
					self.buffList[k].isRemove = 1
					local statusNum = self:__buffID2StatusNum(v.buffID,v.buffParameter['statusnum'])
					if self.statusList[statusNum]~=nil and v.buffID>10000 then
						--self:removeStatusList(statusNum)
					end
					recal = true
				end
			end
			if recal then
				self:reCalBuff()
			end
		end
		for k,v in pairs(self.statusList) do
			self:addStatusList({s=v.s,r=v.r,t=v.t,i=v.i})
		end
		--debuglog("jaylog boss 复活......恢复多少百分比:"..self.hpProp)
		self.attribute.HP = self.attribute:getMaxHP()*self.hpProp
		--self.attribute.MP = self.attribute:getMaxMP()*self.hpProp
		self.hpProp = 1
		--debuglog("boss 复活......恢复多少百分比:"..self.hpProp)
		--self.posX = self.initX
		--self.posY = self.initY
		self.skeleton = 0
		self.lastWalkTime = self.world:getGameTime()
		self.invincibleTime = self.world:getGameTime() + 3
		--self:moveTo(self.posX,self.posY,true,1)
		--self.syncMsg['m']['d']=0.05
		self.attackTarget = nil
		self.prepareSkillAttackNum = 0
		self.status = 0

		self:setCounter('revive')
		self:__getInfo()
		self:syncStatus()
		
		local result=self:getAllInfo(0,true)
		self:updateSyncMsg({i=result})
	end

end

--- boss复活
-- @param null
-- @return null
function SBoss1A:boosRevive()
	----debuglog("boss 复活.......deadTime:"..self.deadTime.." getGameTime:"..self.world.getGameTime())
	self.attribute.HP = self.attribute:getMaxHP()*self.hpProp
	self.attribute.MP = self.attribute:getMaxMP()*self.hpProp
	self.hpProp = 1
	--debuglog("boss 复活......恢复多少百分比:"..self.hpProp)
	-- self.posX = self.initX
	-- self.posY = self.initY
	self:__getInfo()
	self:syncStatus()
	self:updateSyncMsg({i={t=self.teamOrig,a=self.attribute.ID,at=self.attribute.actorType,
		mhp=(self.attribute:getMaxHP()),s=0,st=0,x=self.posX,y=self.posY,mmp=(self.attribute:getMaxMP()),
		l=self.attribute.level,rehp=self.attribute.REHP,remp=self.attribute.REMP,mhpe=self.attribute.MaxHPEXTRA,
		aspdr=self.attribute.ASPDR,mspdr=self.attribute.MSPDR,ne=self.attribute.nextexp,v=self.attribute.VISRNG}})
end

--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SBoss1A:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	----debuglog("jaylog start in SBoss1A:directHurtCallBack mode:"..mode)
	--if mode==9 then
		----debuglog("jaylog 烧到人回调........... 预备传送 "..hitValue['creatureDirectHurCallBack']..' mode:'..mode..' roleId:'..self.world.allItemList[hitValue['creatureDirectHurCallBack']].attribute.roleId)
		if isset(hitValue['creatureDirectHurCallBack']) and hitValue['creatureDirectHurCallBack']>0 then --and in_array(hitValue['creatureDirectHurCallBack'],self.creatureList)) then
			if self.world.tonumber(self.world.allItemList[hitValue['creatureDirectHurCallBack']].attribute.roleId)==111 and self.world.bossObj2.attribute.HP>0 then
				local skill = self.attribute.skills[9] 
				local parameters = skill.parameters
				----debuglog("jaylog ready moveTo: itemID "..itemID..' '..parameters.DREAMBODYX..' '..parameters.DREAMBODYY)
				if itemID~=hitValue['creatureDirectHurCallBack'] and self.world.allItemList[itemID].attribute.actorType==0 and self.world.gameFlag['passTransitDoorNum']<parameters.PASSNUM and self.world.allItemList[itemID].statusList[4007]==nil then
					local obj = self.world.allItemList[itemID] 
					--debuglog('jaylog now ready to addCreature:'..obj.attribute.roleId..' actorType:'..obj.attribute.actorType)
					local toX,toY = 0,0
					toX = self.posX - obj.posX
					toY = self.posY - obj.posY
					if toX<0 then
						toX = obj.posX-2
					elseif ex==0 then
						toX = obj.posX
					else
						toX = obj.posX+2
					end
					if toY<0 then
						toY = obj.posY-2
					elseif toY==0 then
						toY = obj.posY
					else
						toY = obj.posY+2
					end
					local creatureID=self.world:addCreature(self.world.tostring(113),obj.teamOrig,toX,toY,obj,1,0,obj.attribute.roleId,obj.attribute.actorType) 
					local targetShareObj = self.world.allItemList[creatureID]
					local lifeTime=9999
					-- local attributes = {}
					-- attributes['INVICINBLE_RATE'] = 100 
					-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,lifeTime,{},0,targetShareObj.itemID,targetShareObj.itemID)
					-- targetShareObj:addBuff(buff)
					targetShareObj:setDeadTime(lifeTime) 
					targetShareObj:setShared(obj.itemID)
					targetShareObj.attribute.HP = obj.attribute.HP
					targetShareObj.attribute.MaxHP = obj.attribute.MaxHP
					targetShareObj.attribute.MP = obj.attribute.MP
					targetShareObj.attribute.MaxMP = obj.attribute.MaxMP
					targetShareObj.attribute.DEF = obj.attribute.DEF
					targetShareObj.attribute.MDEF = obj.attribute.MDEF
					targetShareObj.attribute.HIT = obj.attribute.HIT
					targetShareObj.attribute.DODGE = obj.attribute.DODGE
					targetShareObj.attribute.baseTable = table.deepcopy(obj.attribute.baseTable)
					targetShareObj:addStatusList({s=22,r=self.world:getGameTime(),t=999},0.2)
					targetShareObj:addStatusList({s=4006,r=self.world.gameTime,t=99999,p1=obj.itemID},0.2)
					targetShareObj:addStatusList({s=4001,r=self.world.gameTime,t=99999})
					local result = targetShareObj:getAllInfo()
					targetShareObj:updateSyncMsg({i=result})

					obj:addStatusList({s=4010,r=self.world.gameTime,t=99999},0.2)
					obj:setShared(creatureID)
					-- local result = obj:getAllInfo()
					-- obj:updateSyncMsg({i=result})
					--debuglog('jaylog targetShareObj hp:'..targetShareObj.attribute.HP..' maxhp:'..targetShareObj.attribute.MaxHP..' DEF:'..targetShareObj.attribute.DEF..' MDEF:'..targetShareObj.attribute.MDEF..' creatureID:'..creatureID..' itemID:'..obj.itemID..' itemHP:'..obj.attribute.HP..' itemMaxHP:'..obj.attribute.MaxHP)
					--debuglog('jaylog start moveTo:'..parameters.PORTALSENDX..' '..parameters.PORTALSENDY)
					obj.inTransitDoor = true
					obj:moveTo(parameters.PORTALSENDX,parameters.PORTALSENDY,true,1,99999)
					self.world.gameFlag['passTransitDoorNum'] = self.world.gameFlag['passTransitDoorNum'] + 1
					--self.world.gameFlag['passTransitDoorID'][#self.world.gameFlag['passTransitDoorID']+1] = itemID
					self.world.gameFlag['passTransitDoorID'][''..itemID] = itemID
					self.world.gameFlag['passTransitDoorLastNum'] = self.world.gameFlag['passTransitDoorLastNum'] - 1
					self.world.transitDoor:addStatusList({s=4002,r=self.world.gameTime,t=99999,i=self.world.transitDoor.itemID,p1=self.world.gameFlag['passTransitDoorLastNum']},0.2)
				
					--成就统计 深度睡眠
					obj:setCounter("dream_2001",1)
				end
			end

			if self.world.tonumber(self.world.allItemList[hitValue['creatureDirectHurCallBack']].attribute.roleId)==112 then
				----debuglog('jaylog mode 5 directHurt: cbID:'..hitValue['creatureDirectHurCallBack']..' itemID:'..itemID)
				if itemID~=hitValue['creatureDirectHurCallBack'] and self.world.allItemList[itemID].attribute.actorType==0 then
					local skill = self.attribute.skills[5] 
					local parameters = skill.parameters
					local obj = self.world.allItemList[itemID]
					obj:addStatusList({s=4005,r=self.world.gameTime,t=99999,i=itemID})
					-- for k,v in pairs(obj.statusList) do
					-- 	--debuglog('jaylog mode 5 directHurt status:'..k)
					-- end
				end
			end
		end
	--end
end

--定时添加SBoss1A的status
function SBoss1A:addStatusEvery()
	if self.addStatusTime<=self.world.gameTime then
	end
end

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SBoss1A:goToDead(itemID,mode,adjTime,bonus)
	--给共生体加上一个static
	local skill = self.attribute.skills[13] 
	local parameters = skill.parameters 
	local obj = self.world.allItemList[self.coexistID]
	if self.coexistID~=0 and not obj:isDead() then
		--self:debuglog("fenglog goToDead 给对方释放一个状态 itemID:"..self.itemID)
		obj:addStatusList({s=4012,r=self.world:getGameTime(),t=99999,i=obj.itemID})
	end
	
	if self.statusList[9002]~=nil or self.statusList[9003]~=nil then
		local time = 9999
		self.deadTime = self.world:getGameTime() + time + adjTime
		self:addStatusList({s=9,r=self.world:getGameTime()+adjTime,t=time,i=self.itemID},adjTime)
		--debuglog('SBoss1A:goToDead '..self.world.cjson.encode(self.statusList[9])..' sharedID:'..self.sharedID)
		if self.statusList[9002]~=nil then
			if self.sharedID>0 and self.world.allItemList[self.sharedID]~=nil then
				self.world.allItemList[self.sharedID]:setShared(0)
			end
			self:setShared(0)
		end
	end

	--成就 拯救世界的我
	obj:setCounter("lastKill_2001",1)

	ret = SBoss1A.super.goToDead(self,itemID,mode,adjTime,bonus) 
	return ret
end

return SBoss1A 
