local SBossInWorld1998 = class("SBossInWorld1998", require("gameroomcore.SHeroBase"))

function SBossInWorld1998:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld1998.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld1998
