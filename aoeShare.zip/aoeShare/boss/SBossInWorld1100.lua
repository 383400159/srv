local SBossInWorld1100 = class("SBossInWorld1100", require("gameroomcore.SHeroBase"))

function SBossInWorld1100:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld1100.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SBossInWorld1100