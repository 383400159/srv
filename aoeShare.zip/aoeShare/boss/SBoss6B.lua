local SBoss6B = class("SBoss6B", require("gameroom.boss.SBoss")) 
 
--- Constructor 地狱犬
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss6B:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss6B" 
	end 

	SBoss6B.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		--debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
end 


function SBoss6B:createInit()
	self:callCreateInit()
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss6B:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SBoss6B.super.prepareHit(self,mode,adjTime,buff) 
	if mode==3  then
		self.mode3list={}
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local teamlist = {}

		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		local dlist={}
	
		local atknum = parameters.TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if (atknum<=0) then ok = false end

				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)

					if (d>=0) then 
						atknum = atknum - 1
						--dlist[#dlist+1] = obj 
						dlist[#dlist+1]={itemID=obj.itemID,DIS=d}  
					end
				end
			end
		end
		)

		self.world.tSort(dlist,function( a1,b1 )
					return a1['DIS'] > b1['DIS']
				end)
		-- local hlist = parameters.ROLESORT
		-- for k,v in pairs(hlist) do
		-- 	for objk,obj in pairs(oldlist) do
		-- 		if  obj.attribute.roleId==v then
		-- 			dlist[#dlist+1] = obj
		-- 		end
		-- 	end
		-- end
		-- local newDlist = {}
		-- newDlist[1]=dlist[#dlist]
		-- for i=1,atknum-1 do
		-- 	newDlist[#newDlist+1]=dlist[i]
		-- end

		--找到目标释放一个群体aoe在目标脚下
		for k,v in pairs(dlist) do
			--debuglog(" SBoss2A:prepareHit: duration"..parameters.HURTLIFE..' buffIntervalTime:'..parameters.HURTITNTERVAL)
			local obj  = self.world.allItemList[v.itemID]
			local creatureID=self.world:addCreature(self.world.tostring(parameters.ENEMY),self.teamOrig,obj.posX,obj.posY,self,1,0)

			local obj  = self.world.allItemList[creatureID]
			self.creatureList[#self.creatureList+1]=creatureID  
			local lifeTime=parameters.HURTLIFE		
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			
			attributes['buffParameter'] = hitValueBoth

			attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
			attributes['buffParameter']['creatureDirectHurCallBack'] = "hlszy"

			attributes['buffParameter']['buffType'] = 1
			attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,parameters.HURTSTARTTIME)
			obj:addBuff(buff)
			obj:setDeadTime(lifeTime) 
		end
		
		--self:addStatusList({s=parameters.ADDSELFSTATUS,r=self.world:getGameTime(),t=parameters.ADDSELFSTATUSTIME,i=self.itemID})
		hitValueBoth = nil
	end
	if mode==6 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local hitValueNew = hitValueBoth
		hitValueNew['skillID'] = 6
		hitValueNew['FIXHURT'] = 7
		hitValueNew['DIZZY_RATE'] = parameters.DIZZY_RATE2
		hitValueNew['BUFFTIME'] = parameters.BUFFTIME2
		-- hitValueNew['ADADJ'] = parameters.ADADJ2 
		self:directFightAuratoDalay(6,0,hitValueNew,{posX=self.posX,posY=self.posY,RANGE=parameters.SMALLCIRCLE},0) 
	end
	if mode==106 then
		local skill = self.attribute.skills[6] 
		local parameters = skill.parameters 
		local hitValueNew = hitValueBoth
		hitValueNew['skillID'] = 6
		hitValueNew['FIXHURT'] = 8
		hitValueNew['DIZZY_RATE'] = 0
		
		--hitValueNew['ADADJ'] = parameters.ADADJ3
		self:directFightAuratoDalay(6,0,hitValueNew,{posX=self.posX,posY=self.posY,RANGE=skill.atkDis},0) 
	end

	if mode==5 then
		local skill = self.attribute.skills[5] 
		local parameters = skill.parameters 
		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.atkDis/self.world.setting.AdjustAttRange)}
		local dlist = {}
		local atknum = parameters.TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				--if (atknum<=0) then ok = false end
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
					----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
					if (d>=0) then 
						--atknum = atknum - 1
						dlist[#dlist+1] = obj   
					end
				end
			end
		end
		)
		dlist=table.shuffle(dlist)
		local newDlist = {}
		for i=1,atknum do
			newDlist[#newDlist+1] = dlist[i]
		end
		local lifeTime=parameters.KEEPTIME
		--找到目标释放一个群体aoe在目标脚下
		for k,v in pairs(newDlist) do
			local toX,toY = self.world.formula:getRandomCirclePoint(self.posX,self.posY,3,true)
			local creatureID=self.world:addCreature(self.world.tostring(parameters.ENEMY),self.teamOrig,toX,toY,self,1,0)
			self:D("黑色闪电 召唤怪:",creatureID)
			local obj = self.world.allItemList[creatureID] 
			obj:setDeadTime(lifeTime) 
			obj.Hatredlist[""..v.itemID]=99999
		end

	end

	return hitValueBoth 
end 


--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss6B:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	ret = SBoss6B.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	return ret 
end 



return SBoss6B 
