local SBoss9E = class("SBoss9E", require("gameroom.boss.SBoss2B")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss9E:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss9E" 
	end 

	SBoss9E.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		----debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
	self.mode4num = 0
	self.mode4idx = 0
	self.modeStartAI = 0
end 

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss9E:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SBoss9E.super.prepareHit(self,mode,adjTime,buff) 
	if mode==6 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		-- self.world:callCreature(hitValueBoth,self)
 	 	--self:addStatusList({s=41,r=self.world:getGameTime(),t=parameters.KEEPTIME,i=self.itemID}) 
 	 	for k,v in pairs(self.world.allItemList) do
 	 		-- self.world:debuglog('jaylog SBoss2B mode4 ',v.attribute.roleId,v.attribute.roleId==273)
 	 		if self.world.tonumber(v.attribute.roleId)==273 then
 	 			if v.statusList[parameters.ADDSTATUS2]==nil then
 	 				v:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=v.itemID},0.2)
 	 			end
 	 		end
 	 	end
 	 	for k,v in pairs(self.world.itemListFilter.heroList) do
 			if v.actorType==0 then
 				local dist = 9999
 				local distNew,targetID = 0,0
 				for k1,v1 in pairs(self.world.allItemList) do
 					if self.world.tonumber(v1.attribute.roleId)==273 then
 						distNew = v:distance(v1.posX,v1.posY)
 						if distNew<dist then
 							dist = distNew
 							targetID = v1.itemID
 						end
 					end
 				end
 				v:addStatusList({zz=3,i=v.itemID,s=984,r=self.world.gameTime,t=9999,p1=273,p2=self.world.tonumber(self.world.setting['takeFireTime']),p3=targetID,p4=dist,p5=1})
 				if not v:isAIObj() then
	 	 			v:setAutoBlocked(true)
	 	 		end
 			end
 		end
	end

	if mode==25 then
		local skill = self.attribute.skills[mode]
		local parameters = skill.parameters
		self.mode4num = 2
 	 	self.mode4idx = 0
 	 	local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['buffParameter'] = {}
		attributes['buffParameter']['buffIntervalTime'] = parameters.CALLBACK
		local buffObj=self.world:createBuff(self:__skillID2buffID(skill.skillID,0),attributes,parameters.CALLBACK,{mode},0,self.itemID,self.itemID,skill.hitTime) 
 		--buffObj.debug = true
 		self:addBuff(buffObj)
 		for k,v in pairs(self.world.allItemList) do
 	 		-- self.world:debuglog('jaylog SBoss2B mode4 ',v.attribute.roleId,v.attribute.roleId==273)
 	 		if self.world.tonumber(v.attribute.roleId)==273 then
 	 			if v.statusList[parameters.ADDSTATUS3]==nil then
 	 				v:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=v.itemID},0.2)
 	 				v:addStatusList({s=parameters.ADDSTATUS3,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME3,i=v.itemID})
 	 				v.parentMode = mode
 	 				v.parentID = self.itemID
 	 			end
 	 		end
 	 		if v.actorType==0 and not v:isAIObj() then
 	 			v:setAutoBlocked(false)
 	 		end
 	 	end
 	 	self.world:D('jaylog SBoss9E mode',mode,self.world.gameTime)
	end

	if mode==125 then 
		--計第8秒
		local skill = self.attribute.skills[mode-100]
		local parameters = skill.parameters
		self.world:D('jaylog SBoss9E mode',mode,self.world.gameTime)
		self.world:D('jaylog SBoss9E statusList:',self.world.cjson.encode(self.statusList[83]),self.world.cjson.encode(self.statusList[41]),self.world.gameTime)
		self.mode4idx = self.mode4idx + 1
		-- local existEnemy = false
		-- for k1,v1 in pairs(self.world.allItemList) do
		-- 	if self.world.tonumber(v1.attribute.roleId)==273 and not v1:isDead() then
		-- 		existEnemy = true
		-- 		break
		-- 	end
		-- end
		-- if not existEnemy then
		-- 	self.world:D('jaylog SBoss9E existEnemy removeStatusList 83')
		-- 	self:removeBuffToID(self:__skillID2buffID(skill.skillID,0))
		-- 	self:removeStatusList(41)
		-- 	self:removeStatusList(83)
		-- 	self:addStatusList({zz=3,s=4105,r=self.world:getGameTime(),t=1})
		-- 	return nil
		-- end
		if self.mode4idx==self.mode4num or self.buffList[self:__skillID2buffID(skill.skillID,0)].isRemove==1 then
			local skill = self.attribute.skills[mode-100] 
			local parameters = skill.parameters 
			for k,v in pairs(self.world.allItemList) do
				if self.world.tonumber(v.attribute.roleId)==273 and not v:isDead() then
					local d =self.world.mPow(self.world.mPow(v.posX-self.posX,2) + self.world.mPow(v.posY-self.posY,2),0.5)
					if d>1 then
						d=d-1
					end
					local toX,toY = self.world.map:getXYLength(v.posX,v.posY,self.posX,self.posY,d)
					local ret
					toX,toY = v.posX+toX,v.posY+toY
					-- ret,toX,toY=self.world.map:findPointStraightLineNearest(v.posX,v.posY,v.posX+toX,v.posY+toY) 
					--实际距离求速度
					local sd = d
					local bulletSpeed = (sd/parameters.ABSORDTIME)*100
					v:moveTo(toX,toY,false,5,bulletSpeed,0)
					v:addStatusList({s=42,r=self.world:getGameTime(),t=999,i=self.itemID},v.moveToEndTime-self.world.gameTime)
					self.world:D('jaylog SBoss9E mode ',mode,self.world.cjson.encode(self.statusList[4103]))
					if self.statusList[4103]==nil then
						self.world:D('jaylog SBoss9E mode2 add 4103')
						self:addStatusList({s=4103,r=self.world:getGameTime(),t=999,i=self.itemID})
					end
				end
				if v.actorType==0 then
					v.canPickUp = false
					v:removeSkillAttackMode9()
					v:setAutoTo()
				end
			end
			self:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID})
			hitValueBoth = nil
		else
			hitValueBoth = nil
		end
		if self.mode4idx>=self.mode4num or self.buffList[self:__skillID2buffID(skill.skillID,0)].isRemove==1 then
			self.world:D('jaylog removeStatusList',self.world.gameTime)
			self:removeStatusList(parameters.SADDSELFSTATUSA)
			self:removeStatusList(parameters.SADDSELFSTATUSB)
		end
		mode = mode-100
		--self.world:debuglog('jaylog SBoss9E hitValueBoth:',self.world.cjson.encode(hitValueBoth))
	end

	if mode==14 or mode==15 then 
 		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		self.world:callCreature(hitValueBoth,self)
 	 	--self:addStatusList({s=41,r=self.world:getGameTime(),t=parameters.KEEPTIME,i=self.itemID}) 
 	 	for k,v in pairs(self.world.allItemList) do
 	 		-- self.world:debuglog('jaylog SBoss2B mode4 ',v.attribute.roleId,v.attribute.roleId==273)
 	 		if self.world.tonumber(v.attribute.roleId)==273 then
 	 			if v.statusList[parameters.ADDSTATUS2]==nil then
 	 				v:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=v.itemID},0.2)
 	 				v:addStatusList({s=parameters.ADDSTATUS3,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME3,i=v.itemID},0.2)
 	 				v.parentMode = mode
 	 				v.parentID = self.itemID
 	 			end
 	 		end
 	 		-- if v.actorType==0 and not v:isAIObj() then
 	 		-- 	v:setAutoBlocked(false)
 	 		-- end
 	 	end
 	 	self.mode4num = 2
 	 	self.mode4idx = 0
 	 	local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['buffParameter'] = {}
		attributes['buffParameter']['buffIntervalTime'] = parameters.CALLBACK
		local buffObj=self.world:createBuff(self:__skillID2buffID(skill.skillID,0),attributes,parameters.CALLBACK,{mode},0,self.itemID,self.itemID,skill.hitTime) 
 		--buffObj.debug = true
 		self:addBuff(buffObj)
 		self.world:D('jaylog SBoss9E 1 statusList:',self.world.cjson.encode(self.statusList[83]),self.world.cjson.encode(self.statusList[41]))
 		for k,v in pairs(self.world.itemListFilter.heroList) do
 			if v.actorType==0 then
 				local dist = 9999
 				local distNew,targetID = 0,0
 				for k1,v1 in pairs(self.world.allItemList) do
 					if self.world.tonumber(v1.attribute.roleId)==273 then
 						distNew = v:distance(v1.posX,v1.posY)
 						if distNew<dist then
 							dist = distNew
 							targetID = v1.itemID
 						end
 					end
 				end
 				if v.statusList[984]~=nil then
 					v:removeStatusList(984)
 				end
 				v:addStatusList({zz=3,i=v.itemID,s=984,r=self.world.gameTime,t=9999,p1=273,p2=self.world.tonumber(self.world.setting['takeFireTime']),p3=targetID,p4=dist,p5=1})
 				self.world:D('jaylog SBoss9E hero statusList:',self.world.cjson.encode({zz=3,i=v.itemID,s=984,r=self.world.gameTime,t=9999,p1=273,p2=self.world.tonumber(self.world.setting['takeFireTime']),p3=targetID,p4=dist,p5=1}))
 			end
 		end
		hitValueBoth = nil
	end 
	if mode==114 or mode==115 then 
		local skill = self.attribute.skills[mode-100] 
		local parameters = skill.parameters 
		--計第8秒
		self.world:D('jaylog SBoss9E mode',mode)
		self.world:D('jaylog SBoss9E statusList:',self.world.cjson.encode(self.statusList[83]),self.world.cjson.encode(self.statusList[41]))
		self.mode4idx = self.mode4idx + 1
		-- local existEnemy = false
		-- for k1,v1 in pairs(self.world.allItemList) do
		-- 	if self.world.tonumber(v1.attribute.roleId)==273 and not v1:isDead() then
		-- 		existEnemy = true
		-- 		break
		-- 	end
		-- end
		-- if not existEnemy then
		-- 	self.world:D('jaylog SBoss9E existEnemy removeStatusList 83')
		-- 	self:removeBuffToID(self:__skillID2buffID(skill.skillID,0))
		-- 	self:removeStatusList(41)
		-- 	self:removeStatusList(83)
		-- 	self:addStatusList({zz=3,s=4105,r=self.world:getGameTime(),t=1})
		-- 	return nil
		-- end
		if self.mode4idx==self.mode4num or self.buffList[self:__skillID2buffID(skill.skillID,0)].isRemove==1 then
			for k,v in pairs(self.world.allItemList) do
				if self.world.tonumber(v.attribute.roleId)==273 and not v:isDead() then
					local d =self.world.mPow(self.world.mPow(v.posX-self.posX,2) + self.world.mPow(v.posY-self.posY,2),0.5)
					if d>1 then
						d=d-1
					end
					local toX,toY = self.world.map:getXYLength(v.posX,v.posY,self.posX,self.posY,d)
					local ret
					ret,toX,toY=self.world.map:findPointStraightLineNearest(v.posX,v.posY,v.posX+toX,v.posY+toY) 
					--实际距离求速度
					local sd = d
					local bulletSpeed = (sd/parameters.ABSORDTIME)*100
					v:moveTo(toX,toY,false,5,bulletSpeed,0)
					v:addStatusList({s=42,r=self.world:getGameTime(),t=999,i=self.itemID},v.moveToEndTime-self.world.gameTime)
					self.world:D('jaylog SBoss9E mode ',mode,self.world.cjson.encode(self.statusList[4103]))
					if self.statusList[4103]==nil then
						self.world:D('jaylog SBoss9E mode2 add 4103')
						self:addStatusList({s=4103,r=self.world:getGameTime(),t=999,i=self.itemID})
					end
				end
				if v.actorType==0 then
					v.canPickUp = false
				end
			end
			self:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID})
			hitValueBoth = nil
		else
			hitValueBoth = nil
		end
		if self.mode4idx>=self.mode4num or self.buffList[self:__skillID2buffID(skill.skillID,0)].isRemove==1 then
			self:removeStatusList(parameters.SADDSELFSTATUSA)
			self:removeStatusList(parameters.SADDSELFSTATUSB)
		end
		mode = mode-100
		--self.world:debuglog('jaylog SBoss9E hitValueBoth:',self.world.cjson.encode(hitValueBoth))
	end

	if mode==16 then
		for k,v in pairs(self.world.allItemList) do
			if self.world.tonumber(v.attribute.roleId)==273 then
				v.attribute.HP = 0
				v:directHurt(v.itemID,1,{})
			end
		end
	end

	if mode==17 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters
		self:moveTo(parameters.POSX,parameters.POSY)
		self:setOutOfCtlAllTime(self.moveToEndTime)
	end

	return hitValueBoth
end

function SBoss9E:callCreature(hitValue,mode)
	if mode==14 or mode==15 then
	else
		SBoss9E.super.callCreature(self,hitValue,mode)
	end
end

-- function SBoss9E:addStatusList(statusArray, adjTime)
-- 	self.world:D('jaylog SBoss9E addStatusList:',self.world.cjson.encode(statusArray),adjTime)
-- 	return SBoss9E.super.addStatusList(self,statusArray,adjTime)
-- end

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SBoss9E:goToDead(itemID,mode,adjTime,bonus)
	SBoss9E.super.goToDead(self,itemID,mode,adjTime,bonus)
	for k,v in pairs(self.world.allItemList) do
		if self.world.tonumber(v.attribute.roleId)==273 then
			v.attribute.HP = 0
			v:directHurt(v.itemID,1,{})
		end
	end
	for k,v in pairs(self.statusList) do
		if k~=9 then
			self:removeStatusList(k)
		end
	end
end

--- 檢查角色info是否需要同步, 及做相應處理
-- @return null
function SBoss9E:syncInfo()
	if self.modeStartAI>0 and self.world.gameTime>self.modeStartAI then
		self.autoFightAI.runAI = true
		self.autoFightAI.runMoveAI = true
		self.autoFightAI.noAutoPatrol = false
		self.modeStartAI = 0
	end
	SBoss9E.super.syncInfo(self)
end

return SBoss9E 