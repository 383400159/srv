local SBossInWorld3018 = class("SBossInWorld3018", require("gameroomcore.SHeroBase"))

function SBossInWorld3018:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld3018.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld3018
