local SBoss7B = class("SBoss7B", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss7B:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss7B" 
	end 

	SBoss7B.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		--debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
	self.creatureList={}
end 

function SBoss7B:createInit()
	self:callCreateInit()
end



--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss7B:prepareHit(mode,adjTime,buff)  


	local hitValueBoth=SBoss7B.super.prepareHit(self,mode,adjTime,buff) 



	if mode==3 then
		self.mode5atklist={}
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 
		local teamlist = {}
		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		local dlist = {}
		--TARGETNUMMIN=2;TARGETNUNMAX=5
		local TARGETNUM =  self.world.formula:getRandnum(parameters.TARGETNUMMIN,parameters.TARGETNUNMAX)
		self:D("机器人 TARGETNUM:",TARGETNUM)
		local atknum = TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if (atknum<=0) then ok = false end
				----debuglog('jaylog ok:'..ok)
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
					----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
					if (d>=0) then 
						atknum = atknum - 1
						dlist[#dlist+1] = obj   
					end
				end
			end
		end
		)


		if #dlist<TARGETNUM and #dlist>0 then
			--所欠的人数
			local num = TARGETNUM-#dlist
			--debuglog("机器人有目标 num:"..#dlist)
			for i=1,num do
				dlist[#dlist+1]=dlist[1]
			end
		end

		if #dlist>0 then
			--debuglog("机器人有目标 dlist:"..#dlist)
			for k,v in pairs(dlist) do
				local d = self:distance(v.posX,v.posY)
				local FLYTIME = (d*100)/skill.bulletSpeed
				local attributes = table.deepcopy(hitValueBoth)
				attributes['APADJ']=attributes['APADJ2']
				parameters['HITTIME'..k] = 0.2
				self:directHurtToDalay(5,v.itemID,attributes,parameters['HITTIME'..k]+FLYTIME)
				self.mode5atklist[#self.mode5atklist+1]=v.itemID..","..parameters['HITTIME'..k]..","..FLYTIME
				

				local obj1 = self.world.allItemList[v.itemID] 
				-- local skill5 = self.attribute.skills[5] 
				-- local parameters5 = skill5.parameters 
				obj1:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID})	
				--self:D("机器人 精准打击 是不是加了:",parameters5.ADDSTATUS2,parameters5.ADDSTATUSTIME2)

			end	
			--debuglog("机器人有目标 :"..self.world.cjson.encode(self.mode5atklist))
		else	
			--debuglog("机器人没有目标")
		end

	end

	if mode==4  then
		self.mode3list={}
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local teamlist = {}

		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		local dlist={}
	
		local atknum = parameters.TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				--if (atknum<=0) then ok = false end

				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)

					if (d>=0) then 
						--atknum = atknum - 1
						--dlist[#dlist+1] = obj 
						dlist[#dlist+1]={itemID=obj.itemID,DIS=d}  
					end
				end
			end
		end
		)

		self.world.tSort(dlist,function( a1,b1 )
					return a1['DIS'] > b1['DIS']
				end)
		-- local hlist = parameters.ROLESORT
		-- for k,v in pairs(hlist) do
		-- 	for objk,obj in pairs(oldlist) do
		-- 		if  obj.attribute.roleId==v then
		-- 			dlist[#dlist+1] = obj
		-- 		end
		-- 	end
		-- end
		local newDlist = {}
		newDlist[1]=dlist[#dlist]
		for i=1,atknum-1 do
			newDlist[#newDlist+1]=dlist[i]
		end

		--找到目标释放一个群体aoe在目标脚下
		for k,v in pairs(newDlist) do
			--debuglog(" SBoss2A:prepareHit: duration"..parameters.HURTLIFE..' buffIntervalTime:'..parameters.HURTITNTERVAL)
			local obj  = self.world.allItemList[v.itemID]
			local creatureID=self.world:addCreature(self.world.tostring(parameters.ENEMY),self.teamOrig,obj.posX,obj.posY,self,1,0)

			local obj  = self.world.allItemList[creatureID]
			self.creatureList[#self.creatureList+1]=creatureID  
			local lifeTime=parameters.HURTLIFE		
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			
			attributes['buffParameter'] = hitValueBoth

			attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
			attributes['buffParameter']['creatureDirectHurCallBack'] = "hlszy"

			attributes['buffParameter']['buffType'] = 1
			attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,parameters.HURTSTARTTIME)
			obj:addBuff(buff)
			obj:setDeadTime(lifeTime) 
		end
		
		--self:addStatusList({s=parameters.ADDSELFSTATUS,r=self.world:getGameTime(),t=parameters.ADDSELFSTATUSTIME,i=self.itemID})
		hitValueBoth = nil
	end



	if mode==2 then
		--清仇恨
		self.Hatredlist={}
	end

	return hitValueBoth 
end 



--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss7B:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 

	--在自身周围召唤沙暴，弹走所有目标
	if mode==2 then
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[2] 
		adjTime = adjTime + 0.2
		hitValue['DIZZY_RATE'] = 100
		hitValue['BUFFTIME'] = skill.animationTime-skill.hitTime-adjTime
		--d*100/parameters.BACKWARDSPEED2
	end


	ret = SBoss7B.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	--在自身周围召唤沙暴，弹走所有目标
	if mode==2 then
		--弹飞所有的目标....BACKWARD=800;BACKWARDSPEED=3000
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[2] 
		local parameters = skill.parameters 

		--弹飞园半径
		local r = parameters.BACKWARD/self.world.setting.AdjustAttRange
		--圆心
		local x = self.posX
		local y = self.posY
		--目标坐标
		local tx = obj.posX
		local ty = obj.posY
		--目标和圆心的距离
		local r1 =self.world.mPow(self.world.mPow(obj.posX-self.posX,2) + self.world.mPow(obj.posY-self.posY,2),0.5)

		--目标偏移位置
		local toX = (tx-x)*r/r1+x
		local toY = (ty-y)*r/r1+y

		ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,toX,toY) 
		--目标到偏移位置的距离
		local d =self.world.mPow(self.world.mPow(obj.posX-toX,2) + self.world.mPow(obj.posY-toY,2),0.5)
		----debuglog("BOSS2A mode 4 posX:"..obj.posX.." posY:"..obj.posY.." toX:"..toX.." toY:"..toY.." d:"..d.." itemID:"..obj.itemID)
		local bulletSpeed = parameters.BACKWARDSPEED2
		obj:moveTo(toX,toY,true,5,bulletSpeed,0)
		----debuglog("BOSS2A mode 4 posX:"..obj.posX.." posY:"..obj.posY.." toX:"..toX.." toY:"..toY.." d:"..d.." itemID:"..obj.itemID.." "..self.world.cjson.encode(obj.syncMsg['m']).." "..self.world.cjson.encode(obj.debugPaths))
	end

	return ret 
end 


return SBoss7B 
