local SBossInWorld2007 = class("SBossInWorld2007", require("gameroomcore.SHeroBase"))

function SBossInWorld2007:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld2007.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld2007
