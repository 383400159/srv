local SBossInWorld1995 = class("SBossInWorld1995", require("gameroomcore.SHeroBase"))

function SBossInWorld1995:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld1995.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld1995
