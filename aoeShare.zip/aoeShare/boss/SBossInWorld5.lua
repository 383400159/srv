local SBossInWorld5 = class("SBossInWorld5", require("gameroomcore.SHeroBase"))

function SBossInWorld5:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld5.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SBossInWorld5