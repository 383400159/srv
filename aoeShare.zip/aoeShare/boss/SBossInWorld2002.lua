local SBossInWorld2002 = class("SBossInWorld2002", require("gameroomcore.SHeroBase"))

function SBossInWorld2002:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld2002.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SBossInWorld2002