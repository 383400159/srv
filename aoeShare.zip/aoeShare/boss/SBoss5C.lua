local SBoss5C = class("SBoss5C", require("gameroom.boss.SBoss9B")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss5C:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss5C" 
	end 
	--激光的方向
	self.mode4X=0
	self.mode4Y=0

	self.mode3time = 0
	self.mode3x = 0--记录2号技能的落点
	self.mode3y = 0
	self.modeold3x = 0 --记录2号发技能的起点
	self.modeold3y = 0 --记录2号发技能的起点

	self.mode5atklist = {}

	self.creatureList={}
	SBoss5C.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		----debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
end 




return SBoss5C 
