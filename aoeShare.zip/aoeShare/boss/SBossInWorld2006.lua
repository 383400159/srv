local SBossInWorld2006 = class("SBossInWorld2006", require("gameroomcore.SHeroBase"))

function SBossInWorld2006:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld2006.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld2006
