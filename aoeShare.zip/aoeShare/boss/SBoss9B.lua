local SBoss9B = class("SBoss9B", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss9B:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss9B" 
	end 
	--激光的方向
	self.mode4X=0
	self.mode4Y=0

	self.mode3time = 0
	self.mode3x = 0--记录2号技能的落点
	self.mode3y = 0
	self.modeold3x = 0 --记录2号发技能的起点
	self.modeold3y = 0 --记录2号发技能的起点

	self.mode5atklist = {}

	self.creatureList={}
	SBoss9B.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		----debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end

	--旋转射线
	self.angle1 = 120	
	self.angle2 = 360
	self.angleMid = 240
	self.offsetsAngle1 = 0
	self.offsetsAngle2 = 0
	self.leftX = 0
	self.leftY = 0
	self.rightX = 0
	self.rightY = 0
	self.angleSpeed = 0
	self.mode7Time = self.world.gameTime
	self.mode7AtkTime = 0

	--装炸药包激活情况
	self.qteCList = {}
	self.r = 0
	self.g = 0
end 

function SBoss9B:goToDead(itemID,mode,adjTime,bonus)  
	SBoss9B.super.goToDead(self,itemID,mode,adjTime,bonus) 
end 

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss9B:prepareHit(mode,adjTime,buff)  

	if mode==4 then
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		if self.statusList[parameters.ADDSELFSTATUS2]==nil then
			self:addStatusList({s=parameters.ADDSELFSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSELFSTATUSTIME2,i=self.itemID},0)
		end
	end

	local hitValueBoth=SBoss9B.super.prepareHit(self,mode,adjTime,buff) 

	-- if mode==4 then
	-- 	local skill = self.attribute.skills[4] 
	-- 	local parameters = skill.parameters

	-- 	local attributes = {}
	-- 	attributes['buffParameter']={}
	-- 	attributes['BUFFONLY']=1
	-- 	attributes['buffParameter'] = {}
	-- 	attributes['buffParameter']['buffIntervalTime'] = parameters.ATTACKINTERVAL
	-- 	local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,parameters.LIFETIME,{mode},0,self.itemID,self.itemID,skill.hitTime) 
 -- 		self:addBuff(buffObj)
 -- 		self.mode4X=self.lastBulletPositionX
	-- 	self.mode4Y=self.lastBulletPositionY
	-- 	--debuglog("激光释放")
	-- end

	-- if mode==104 then
	-- 	local skill = self.attribute.skills[4] 
	-- 	local parameters = skill.parameters

	-- 	local customize = self.world:createSkillValue()
	-- 	customize['attackMode'] = 4
	-- 	customize['atkDis'] = skill.atkDis
	-- 	customize['bulletSpeed'] = skill.bulletSpeed
	-- 	customize['targetType'] = 1
	-- 	customize['degree'] = skill.degree
	-- 	customize['maxEnemy']=skill.maxEnemy
	-- 	customize['numOfBullet']=10
	-- 	local toX = self.mode4X
	-- 	local toY = self.mode4Y
	-- 	local hitValue=table.deepcopy(hitValueBoth)
	-- 	hitValue['APADJ'] = hitValue['APADJ2']
	-- 	local bulletID = self.world:addBullet(4,self.itemID,self.world.gameTime,0,toX,toY,false,hitValue,customize) 

	-- 	--debuglog("激光发射 customize:"..self.world.cjson.encode(customize).." hitValue:"..self.world.cjson.encode(hitValue))

	-- end

	if mode==5 then
		self.mode5atklist={}
		local skill = self.attribute.skills[5] 
		local parameters = skill.parameters 
		local teamlist = {}
		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		local dlist = {}
		local atknum = parameters.TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if (atknum<=0) then ok = false end
				----debuglog('jaylog ok:'..ok)
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
					----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
					if (d>=0) then 
						atknum = atknum - 1
						dlist[#dlist+1] = obj   
					end
				end
			end
		end
		)


		if #dlist<parameters.TARGETNUM and #dlist>0 then
			--所欠的人数
			local num = parameters.TARGETNUM-#dlist
			--debuglog("机器人有目标 num:"..#dlist)
			for i=1,num do
				dlist[#dlist+1]=dlist[1]
			end
		end

		if #dlist>0 then
			--debuglog("机器人有目标 dlist:"..#dlist)
			for k,v in pairs(dlist) do
				-- TARGETNUM=3;HURTLIFE=5;HURTSTARTTIME=1.7;HURTITNTERVAL=5;HITTIME1=1.5;HITTIME2=1.8;HITTIME3=2.0
				local d = self:distance(v.posX,v.posY)
				local FLYTIME = (d*100)/skill.bulletSpeed
				local attributes = table.deepcopy(hitValueBoth)
				attributes['APADJ']=attributes['APADJ2']
				self:directHurtToDalay(5,v.itemID,attributes,parameters['HITTIME'..k]+FLYTIME)
				self.mode5atklist[#self.mode5atklist+1]=v.itemID..","..parameters['HITTIME'..k]..","..FLYTIME
				

				local obj1 = self.world.allItemList[v.itemID] 
				local skill5 = self.attribute.skills[5] 
				local parameters5 = skill5.parameters 
				obj1:addStatusList({s=parameters5.ADDSTATUS2,r=self.world:getGameTime(),t=parameters5.ADDSTATUSTIME2,i=self.itemID})	
				--self:D("机器人 精准打击 是不是加了:",parameters5.ADDSTATUS2,parameters5.ADDSTATUSTIME2)

			end	
			--debuglog("机器人有目标 :"..self.world.cjson.encode(self.mode5atklist))
		else	
			--debuglog("机器人没有目标")
		end

	end

	-- if (mode==3 ) then 
	-- 	--print("prepareHit 飞飞飞........ x y tox toy distance ",self.posX,toX,self.posY,toY,skill.atkDis/self.world.setting.AdjustAttRange)
	-- 	local skill = self.attribute.skills[3] 
	-- 	local parameters = skill.parameters 

	-- 	local toX,toY = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,skill.atkDis/self.world.setting.AdjustAttRange)
	-- 	local ret
	-- 	print("prepareHit 飞飞飞........ x tox y toy distance ",self.posX,toX,self.posY,toY,skill.atkDis/self.world.setting.AdjustAttRange)
	-- 	ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX,self.posY+toY) 

	-- 	local delaytime = 0
	-- 	self.mode3time = self.world:getGameTime()+adjTime+delaytime
	-- 	self.modeold3x = self.posX
	-- 	self.modeold3y = self.posY
	-- 	self.world:--debuglog('============= hero rush itemid ox oy x y ',self.itemID,self.modeold3x,self.modeold3y,toX,toY)
	-- 	--self:moveTo(toX,toY,false,6,skill.bulletSpeed,adjTime+delaytime) 
	-- 	self.mode3x = toX
	-- 	self.mode3y = toY
	-- 	local attributes = {}
	-- 	attributes['IMMUNECONTROL_RATE'] = 100
	-- 	--attributes['IMMUNECONTROL'] = self.moveToEndTime
	-- 	attributes['BUFFTIME'] = 0.2
	-- 	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,0.2,{},0,self.itemID,self.itemID,adjTime)
	-- 	self:addBuff(buff)

	-- end


	-- if mode==5 then
	-- 	local skill = self.attribute.skills[5] 
	-- 	local parameters = skill.parameters 
	-- 	local teamlist = {}
	-- 	--搜敌找到所需要的目标
	-- 	-- if ( self.teamOrig=="A")  then
	-- 	-- 	teamlist=self.world.itemListFilter.teamB
	-- 	-- else
	-- 	-- 	teamlist=self.world.itemListFilter.teamA
	-- 	-- end
	-- 	----debuglog('jaylog teamlist:'..self.world.cjson.encode(teamlist))
	-- 	local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
	-- 	----debuglog('jaylog useDis:'..skill.useDis..' AdjustAttRange:'..self.world.setting.AdjustAttRange)
	-- 	local dlist = {}
	-- 	local atknum = parameters.TARGETNUM
	-- 	local enemy = self:getEnemylist()
	-- 	for k,obj in pairs(enemy) do
	-- 		----debuglog('jaylog allItemList:'..k..' id:'..obj.itemID..' ot:'..obj.teamOrig..' st:'..self.teamOrig)
	-- 		if obj.teamOrig~=self.teamOrig then
	-- 			ok = true
	-- 			if (obj:isDead()) then ok = false end
	-- 			if (atknum<=0) then ok = false end
	-- 			----debuglog('jaylog ok:'..ok)
	-- 			if ok then
	-- 				local d = obj:colliding(visRange,0,0,self.itemID)
	-- 				----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
	-- 				if (d>=0) then 
	-- 					atknum = atknum - 1
	-- 					dlist[#dlist+1] = obj   
	-- 				end
	-- 			end
	-- 		end
	-- 	end

	-- 	--找到目标释放一个群体aoe在目标脚下
	-- 	for k,obj in pairs(dlist) do
	-- 		----debuglog('jaylog dlist:'..k)
	-- 		local skill = self.attribute.skills[5] 
	-- 		local parameters = skill.parameters 
	-- 		--APADJ=125;DEF_DOWN=50;DEF_DOWN_RATE=100;BUFFTIME=10

	-- 		----debuglog("hitTime_:"..skill.hitTime)
	-- 		--debuglog("jaylog SBoss1A:prepareHit: duration"..skill.duration..' buffIntervalTime:'..skill.bulletTimeInterval)
	-- 		local creatureID=self.world:addCreature(self.world.tostring(275),self.teamOrig,obj.posX,obj.posY,self,1,skill.hitTime)
	-- 		local obj  = self.world.allItemList[creatureID]
	-- 		self.creatureList[#self.creatureList+1]=creatureID  
	-- 		local lifeTime=parameters.HURTLIFE		--skill.parameters.DEAD
	-- 		local attributes = {}
	-- 		attributes['buffParameter']={}
	-- 		attributes['BUFFONLY']=1
	-- 		--debuglog("SBoss4A:prepareHit------------....hitValueBoth:"..self.world.cjson.encode(hitValueBoth))
	-- 		attributes['buffParameter'] = hitValueBoth
	-- 		--attributes['buffParameter']['FIXHURT'] = 250
	-- 		-----debuglog("atkDis:"..parameters.hitTime)
	-- 		attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
	-- 		attributes['buffParameter']['creatureDirectHurCallBack'] = creatureID
	-- 		----debuglog("jaylog addCreature  creatureID:"..creatureID)
	-- 		attributes['buffParameter']['buffType'] = 1
	-- 		--attributes['buffParameter']['buffAtleastOnce']=true
	-- 		attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
	-- 		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,parameters.HURTSTARTTIME)
	-- 		obj:addBuff(buff)
	-- 		obj:setDeadTime(lifeTime) 
	-- 	end
	-- 	hitValueBoth = nil
	-- end

	if mode==7 or mode==13 then
		local skill = self.attribute.skills[mode]
		local parameters = skill.parameters
		local angleChange = parameters.ANGLE*0.5
		self.mode7Time = self.world.gameTime + parameters.STAYTIME + skill.hitTime
		self.angleSpeed = angleChange/parameters.ROTATIONTIME
		self.mode7AtkTime = self.world.gameTime + parameters.STAYTIME + skill.hitTime

		local LIFETIME = parameters.ROTATIONTIME + parameters.STAYTIME
		self.angleMid = self.world:getAngle(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY)
		self.angle1 = self.angleMid + angleChange
		self.angle2 = self.angleMid - angleChange
		-- self.leftX = self.posX + math.cos(math.rad(self.angleMid-90+180))*0.5
		-- self.leftY = self.posY + math.sin(math.rad(self.angleMid-90+180))*0.5
		-- self.rightX = self.posX + math.cos(math.rad(self.angleMid+90+180))*0.5
		-- self.rightY = self.posY + math.sin(math.rad(self.angleMid+90+180))*0.5
		self.world:D('jaylog SBoss9B mode7 1',self.world.gameTime,self.angle1,self.angle2,self.lastBulletPositionX,self.lastBulletPositionY,self.posX,self.posY,self.leftX,self.leftY,self.rightX,self.rightY)
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['buffParameter'] = {}
		attributes['buffParameter']['buffIntervalTime'] = parameters.ATTACKINTERVAL
		local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,LIFETIME,{mode},0,self.itemID,self.itemID,skill.hitTime) 
 		self:addBuff(buffObj)
 		-- local sdata = {s=4081,r=self.world:getGameTime(),t=LIFETIME,i=self.itemID,p1=self.mode7Time*100,p2=self.angleSpeed,p3=self.angle1,p4=self.angle2,p5=self.angleMid}
 		-- -- self.world:D('jaylog SBoss9B mode7','ac',angleChange,'m7t',self.mode7Time,'as',self.angleSpeed,'m7at',self.mode7AtkTime,'lt',LIFETIME,'am',self.angleMid,'a1',self.angle1,'a2',self.angle2)
 		-- self:addStatusList(sdata)
	end

	if mode==107 or mode==113 then
		local skill = self.attribute.skills[mode-100] 
		local parameters = skill.parameters
		local angleChange = parameters.ANGLE*0.5
		local LIFETIME = parameters.ROTATIONTIME + parameters.STAYTIME
		if self.mode7AtkTime<self.world.gameTime then
			--左手向中间
			local offsetsAngle1 = (self.world.gameTime-self.mode7Time)*self.angleSpeed*(-1)
			-- local offsetsAngle1 = (self.world.gameTime-self.mode7Time)*self.angleSpeed
			local customize1 = self.world:createSkillValue()
			customize1['attackMode'] = 1
			customize1['atkDis'] = 1000000
			customize1['bulletSpeed'] = 99999
			customize1['targetType'] = 1
			customize1['degree'] = self.world.mAbs((self.world.gameTime-self.mode7AtkTime)*self.angleSpeed)
			-- customize1['degree'] = skill.degree
			-- customize1['numOfBullet'] = skill.numOfBullet
			local toX1 = self.posX + math.cos(math.rad(self.angle1+offsetsAngle1))*100
			local toY1 = self.posY + math.sin(math.rad(self.angle1+offsetsAngle1))*100
			-- local toX1 = self.posX + math.cos(math.rad(self.angle1+offsetsAngle1))*100
			-- local toY1 = self.posY + math.sin(math.rad(self.angle1+offsetsAngle1))*100
			local hitValue1=table.deepcopy(hitValueBoth)
			-- hitValue1['mode11Angle'] = self.angle1+offsetsAngle1+180
			hitValue1['mode11Angle'] = self.angle1+offsetsAngle1
			hitValue1['APADJ'] = hitValue1['APADJ2']
			-- hitValue1['bulletStartPositionX'] = self.leftX
			-- hitValue1['bulletStartPositionY'] = self.leftY
			local bulletID = self.world:addBullet(mode-100,self.itemID,0,0,toX1,toY1,false,hitValue1,customize1)	--self.world.gameTime
			-- local bulletObj = self.world.bulletList[bulletID]
			-- bulletObj.attr.startPositionX = self.leftX
			-- bulletObj.attr.startPositionY = self.leftY
			-- self.world:D('jaylog a 1 toX',toX1,'toY',toY1,'am',self.angleMid,'a1',self.angle1,'a2',self.angle2,offsetsAngle1)
			self.world:D('jaylog SBoss9B mode107 1','ac',angleChange,'gt',self.world.gameTime,'m7t',self.mode7Time,'as',self.angleSpeed,'m7at',self.mode7AtkTime,'lt',LIFETIME,'am',self.angleMid,'a1',self.angle1,'a2',self.angle2,'oa1',offsetsAngle1,'oa2',offsetsAngle2,'spx',self.posX,'spy',self.posY,'tx1',toX1,'ty1',toY1,'bulletID',bulletID) 
			--右手向中间
			local offsetsAngle2 = (self.world.gameTime-self.mode7Time)*self.angleSpeed
			-- local offsetsAngle2 = (self.world.gameTime-self.mode7Time)*self.angleSpeed*(-1)
			local customize2 = self.world:createSkillValue()
			customize2['attackMode'] = 1
			customize2['atkDis'] = 1000000
			customize2['bulletSpeed'] = 99999
			customize2['targetType'] = 1
			customize2['degree'] = self.world.mAbs((self.world.gameTime-self.mode7AtkTime)*self.angleSpeed)
			-- customize2['degree'] = skill.degree
			-- customize2['numOfBullet'] = skill.numOfBullet
			local toX2 = self.posX + math.cos(math.rad(self.angle2+offsetsAngle2))*100
			local toY2 = self.posY + math.sin(math.rad(self.angle2+offsetsAngle2))*100
			-- local toX2 = self.posX + math.cos(math.rad(self.angle2+offsetsAngle2))*100
			-- local toY2 = self.posY + math.sin(math.rad(self.angle2+offsetsAngle2))*100
			local hitValue2=table.deepcopy(hitValueBoth)
			-- hitValue2['mode11Angle'] = self.angle2+offsetsAngle2+180
			hitValue2['mode11Angle'] = self.angle2+offsetsAngle2
			hitValue2['APADJ'] = hitValue2['APADJ2']
			-- hitValue2['bulletStartPositionX'] = self.rightX
			-- hitValue2['bulletStartPositionY'] = self.rightY
			local bulletID2 = self.world:addBullet(mode-100,self.itemID,0,0,toX2,toY2,false,hitValue2,customize2) 	--self.world.gameTime
			-- local bulletObj2 = self.world.bulletList[bulletID2]
			-- bulletObj2.attr.startPositionX = self.rightX
			-- bulletObj2.attr.startPositionY = self.rightY
			-- self.world:D('jaylog a 2 toX',toX2,'toY',toY2,'am',self.angleMid,'a1',self.angle1,'a2',self.angle2,offsetsAngle2)
			self.world:D('jaylog SBoss9B mode107 2','ac',angleChange,'gt',self.world.gameTime,'m7t',self.mode7Time,'as',self.angleSpeed,'m7at',self.mode7AtkTime,'lt',LIFETIME,'am',self.angleMid,'a1',self.angle1,'a2',self.angle2,'oa1',offsetsAngle1,'oa2',offsetsAngle2,'spx',self.posX,'spy',self.posY,'tx1',toX2,'ty1',toY2,'bulletID',bulletID2) 

			self.mode7AtkTime = self.world.gameTime
		end
		mode = mode-100
	end
	

	--qte
	-- 1、BOSS移动到场景中心，然后进入咏唱15秒，在15秒后引发一次大爆炸，期间处于无敌状态
	-- 2、在场上召唤5个操控台（根据玩家人数来定，最少3个操作台），每位玩家都可以选一个操作台进行剪线（红线或蓝线，使用UI操作），每个操作台只能操作一次，剪线操作需要咏唱1秒
	-- 3、界面UI上提示这次剪线的目标（蓝色和红色数目随机，总和根据玩家人数而定，最少3个）
	-- 4、界面UI上显示当前的剪线情况（显示头像和他剪的颜色）
	-- 5、当剪完线/咏唱时间结束/剪线出现不匹配时(如目标剪红线2条，但是已经剪了3条红线)，进行结果验算
	-- 6、当玩家剪线的红蓝数目和目标数目不匹配时会引发大爆炸；如果匹配则可以让BOSS停止咏唱
	-- 7、玩家不剪线视为不是红色也不是蓝色，而是不剪线（UI显示为不剪线状态）
	-- 【玩家提示：红线，还是蓝线？剪剪试试！】
	-- 【玩法：匹配提示的剪线数目】

	if mode==9 then
		local tNum = 0
		local elist = {}
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if ok then
					tNum = tNum + 1
					elist[#elist+1] = obj.itemID
				end
			end
		end
		)
		if tNum<3 then
			tNum = 3
		end
		self.qteCList  = {}
		local consolePos = {}
		consolePos[#consolePos+1]=string.splitNumber(self.world.setting.consolePos1,',')
		consolePos[#consolePos+1]=string.splitNumber(self.world.setting.consolePos2,',')
		consolePos[#consolePos+1]=string.splitNumber(self.world.setting.consolePos3,',')
		consolePos[#consolePos+1]=string.splitNumber(self.world.setting.consolePos4,',')
		consolePos[#consolePos+1]=string.splitNumber(self.world.setting.consolePos5,',')
		local alist = {}
		for i=1,tNum do
			alist[#alist+1] = elist[i]
		end
		alist = table.shuffle(alist)

		--分配颜色
		self.r = self.world.formula:getRandnum(1,tNum-1)
		self.g = tNum - self.r
		self:D("qte 开始:",tNum,self.r,self.g)
		
		local colList = {}
		for i=1,self.r do
			colList[#colList+1] = 2
		end
		for i=1,self.g do
			colList[#colList+1] = 1
		end
		colList = table.shuffle(colList)

		for i=1,tNum do
			local randlist = self.world.formula:formationPoint(6,10,true)
			--local creatureID=self.world:addCreature(self.world.tostring(312),self.teamOrig,self.posX+randlist[i][1],self.posY+randlist[i][2],self,1,0)
			local creatureID=self.world:addCreature(self.world.tostring(312),self.teamOrig,consolePos[i][1],consolePos[i][2],self,1,0)
			self.qteCList[#self.qteCList+1]=creatureID
			local obj  = self.world.allItemList[creatureID]
			-- obj.attribute.STANDPOINT = extraParam['POSITION'][3]
			-- obj.syncMsg['i']['jd'] = extraParam['POSITION'][3]
			obj:setDeadTime(15)
			--标示两两配对
			obj.isQTENum = alist[1]
			obj.iscolor = colList[i]

			local hobj  = self.world.allItemList[alist[1]]
			hobj.isQTENum = i
			hobj.cztID = obj.itemID
			hobj:addStatusList({s=4134,r=self.world.gameTime,t=16,i=obj.itemID,p1=i,p2=obj.itemID},0)
			hobj:addStatusList({s=4137,r=self.world.gameTime,t=16,i=obj.itemID,p1=i,p2=obj.itemID},0)
			hobj.is41=false
			obj:addStatusList({s=4135,r=self.world:getGameTime(),t=16,i=self.itemID,p1=hobj.itemID,p2=i,p3=colList[i],p4=1})
			table.remove(alist,1)
		end
	end

	if mode==109 then
		local isEndRNum = 0
		local isEndGNum = 0
		for i,v in ipairs(self.qteCList) do
			local obj  = self.world.allItemList[v]
			if obj.isEnd~=nil and obj.isEnd==1 then
				isEndRNum = isEndRNum + 1
			end
			if obj.isEnd~=nil and obj.isEnd==2 then
				isEndGNum = isEndGNum + 1
			end
		end
		--已经达到上限 提前结束
		if isEndRNum>self.g or isEndGNum>self.r then
			self:D("qte 不安全 时间到")
			self:addStatusList({s=4136,r=self.world:getGameTime(),t=99,i=self.itemID})	
		else
			if (isEndRNum+isEndGNum)==#self.qteCList then
				self:D("qte 安全 时间到")
				self:addStatusList({s=4133,r=self.world:getGameTime(),t=99,i=self.itemID})	
			else
				self:D("qte 不安全 时间到")
				self:addStatusList({s=4136,r=self.world:getGameTime(),t=99,i=self.itemID})	
			end
		end
		-- for k,v in pairs(self.qteCList) do
		-- 	local obj  = self.world.allItemList[v]
		-- 	if obj~=nil and not obj:isDead() then
		-- 		obj.attribute.HP=0
		-- 		obj:addStatusList({s=42,r=self.world.gameTime,t=16,i=obj.itemID},2)
		-- 		obj:directHurt(obj.itemID,1,{},0)
		-- 	end
		-- end
	end

	return hitValueBoth 
end 


--- fight motion , call every update loop
-- @return null
function SBoss9B:fight()
	SBoss9B.super.fight(self) 
	if #self.qteCList>0 then
		-- local isEndRNum = 0
		-- local isEndGNum = 0
		-- for i,v in ipairs(self.qteCList) do
		-- 	local obj  = self.world.allItemList[v]
		-- 	if obj.isEnd~=nil and obj.isEnd==1 then
		-- 		isEndRNum = isEndRNum + 1
		-- 	end
		-- 	if obj.isEnd~=nil and obj.isEnd==2 then
		-- 		isEndGNum = isEndGNum + 1
		-- 	end
		-- end
		-- --已经达到上限 提前结束
		-- if isEndRNum>self.g or isEndGNum>self.r then
		-- 	self:D("qte 不安全")
		-- 	local skill = self.attribute.skills[9] 
		-- 	local parameters = skill.parameters 
		-- 	self:removeBuffToID(self:__skillID2buffID(skill.skillID,0))

		-- 	for k,v in pairs(self.qteCList) do
		-- 		local obj  = self.world.allItemList[v]
		-- 		if obj~=nil and not obj:isDead() then
		-- 			obj.attribute.HP=0
		-- 			obj:addStatusList({s=42,r=self.world.gameTime,t=16,i=obj.itemID},2)
		-- 			obj:directHurt(obj.itemID,1,{},0)
		-- 		end
		-- 	end
		-- else
		-- 	if (isEndRNum+isEndGNum)==#self.qteCList then
		-- 		self:D("qte 安全")
		-- 		for k,v in pairs(self.qteCList) do
		-- 			local obj  = self.world.allItemList[v]
		-- 			if obj~=nil and not obj:isDead() then
		-- 				obj.attribute.HP=0
		-- 				obj:addStatusList({s=42,r=self.world.gameTime,t=16,i=obj.itemID},2)
		-- 				obj:directHurt(obj.itemID,1,{},0)
		-- 			end
		-- 		end
		-- 	else
		-- 		self:D("qte 不安全")
		-- 	end
		-- end
		--清除场上的炸药包

		local js = false
		for i,v in ipairs(self.qteCList) do
			local obj  = self.world.allItemList[v]
			if obj.isEnd~=nil then
				if obj.isEnd~=obj.iscolor then
					js = true				
				end
			end
		end

		if js then
			--结算
			self:D("qte 不安全   提前结算.....................")
			self:addStatusList({s=4136,r=self.world:getGameTime(),t=99,i=self.itemID})	
			-- for k,v in pairs(self.qteCList) do
			-- 	local obj  = self.world.allItemList[v]
			-- 	if obj~=nil and not obj:isDead() then
			-- 		obj.attribute.HP=0
			-- 		obj:addStatusList({s=42,r=self.world.gameTime,t=16,i=obj.itemID},2)
			-- 		obj:directHurt(obj.itemID,1,{},0)
			-- 	end
			-- end
		end
	end
end

--发送消息给前面
function SBoss9B:syncQTE()
	-- local isEndRNum = 0
	-- local isEndGNum = 0
	-- for i,v in ipairs(self.qteCList) do
	-- 	local obj  = self.world.allItemList[v]
	-- 	if obj.isEnd~=nil and obj.isEnd==1 then
	-- 		isEndRNum = isEndRNum + 1
	-- 	end
	-- 	if obj.isEnd~=nil and obj.isEnd==2 then
	-- 		isEndGNum = isEndGNum + 1
	-- 	end
	-- end
	-- --local retStr = self.r..","..self.g..","..isEndRNum..","..isEndGNum

	-- self:addStatusList({s=4135,r=self.world:getGameTime(),t=99,i=self.itemID,p1=self.r,p2=self.g,p3=isEndRNum,p4=isEndGNum})	
end

--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss9B:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 



	local ret = SBoss9B.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	if mode==3 and hitValue['Effect']~=2 then
		--print("prepareHit 飞飞飞........ x y tox toy distance ",self.posX,toX,self.posY,toY,skill.atkDis/self.world.setting.AdjustAttRange)
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 
		
		--local d = obj:distance(self.mode3x,self.mode3y)+self.attribute.width
		--local toX,toY = self.world.map:getXYLength(self.modeold3x,self.modeold3y,self.mode3x,self.mode3y,d)
		local toX,toY = self.world.map:getXYLength(self.posX,self.posY,obj.posX,obj.posY,parameters.BACKWARD/self.world.setting.AdjustAttRange)

		local ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 

		obj:moveTo(toX,toY,false,5,parameters.BACKWARDSPEED2,0) 

	end

	if mode==4 then
		--debuglog("机器人爆炸伤害 ")
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 

		local attackRange = {posX=obj.posX,posY=obj.posY,radius=parameters.EXPLODERANGE/self.world.setting.AdjustAttRange} 

		local hitValueNew = self:getPrepareHithitValue()
		hitValueNew['skillID'] = 4
		hitValueNew['APADJ'] = parameters.APADJBOMB 
		
		local bullet = require("gameroomcore.SBullet").new(self.world,4,self.itemID,0.2,0,obj.posX,obj.posY)
		bullet.attr.ignoreID = {itemID}
		bullet:directFightAura(1,attackRange,hitValueNew,bullet.attr.angle,0) 
		bullet:setDead() 
		self:addStatusList({s=4132,r=self.world:getGameTime(),t=skill.bulletTimeInterval+0.1,i=self.itemID,p1=itemID},0)
	end

	if mode==10 or mode==11 then
		--杀掉台子
		for k,v in pairs(self.qteCList) do
			local obj  = self.world.allItemList[v]
			if obj~=nil and not obj:isDead() then
				obj.attribute.HP=0
				obj:addStatusList({s=42,r=self.world.gameTime,t=16,i=obj.itemID},2)
				obj:directHurt(obj.itemID,1,{},0)
			end
		end
	end

	return ret 
end 

--- 准备攻击前置设置，在prepareHit之后执行
-- @param mode int - 技能1-7
-- @param itemID int - 目标对象id
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SBoss9B:prepareSkillAttackCustom(mode,itemID,x,y,adjtime,syncMsg)

	--debuglog("SBoss9B:prepareSkillAttackCustom")
	if mode==5  and #self.mode5atklist>0 then
		--debuglog("机器人 导弹列表 mode:"..mode)
		syncMsg['a']['p'] = implode(';',self.mode5atklist)
		--debuglog("机器人 导弹列表:"..syncMsg['a']['p'].." syncMsg:"..self.world.cjson.encode(syncMsg))
	end
	SBoss9B.super.prepareSkillAttackCustom(self,mode,itemID,x,y,adjTime,syncMsg)
end



function SBoss9B:createInit()
	self:callCreateInit()
end



return SBoss9B 
