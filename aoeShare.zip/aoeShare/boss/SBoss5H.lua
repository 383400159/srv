local SBoss5H = class("SBoss5H", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss5H:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss5H" 
	end 

	SBoss5H.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		--debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
	--远离攻击目标
	self.mode2Time = 0
	--下次远离时间
	self.mode2NextTime = 0
	--冲锋次数
	self.cfNum = 0
	--下次放AI时间
	self.cfNextTime = 0
	--调整撞击方向
	self.toX = 0
	self.toY = 0
	--起点
	self.starX = 0
	self.starY = 0
	--总撞击次数
	self.allAtkNum = 0 
end 


--- fight motion,执行攻击动作
-- @param null
-- @return null
function SBoss5H:fight()
	if self.mode2Time>self.world:getGameTime() then
		self:D("释放惧怕 fight",self.lastHurtAllID,self.lastHurtAllTime,self.world:getGameTime())
		if self.lastHurtAllID~=nil and self.lastHurtAllID>0 and (self.lastHurtAllTime+10)>self.world:getGameTime() then
			local obj = self.world.allItemList[self.lastHurtAllID] 
			
			if obj~=nil and not obj:isDead() and obj.attribute.HP>0 and self.world:getGameTime()>self.mode2NextTime then
				local skill = self.attribute.skills[2] 
				local parameters = skill.parameters
				local d = obj:distance(self.posX,self.posY)
				if d<(parameters.RUNAWAYDIS/self.world.setting.AdjustAttRange) then
					self:clearSkillAttack()
					local toX,toY = self.world.map:getXYLength(obj.posX,obj.posY,self.posX,self.posY,(parameters.RUNAWAYDIS/self.world.setting.AdjustAttRange))
					local ret,newtoX,newtoY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX,self.posY+toY) 
					local d0 = self:distance(newtoX,newtoY)
					toX1,toY1 = self.world.map:getXYLengthCross(obj.posX,obj.posY,self.posX,self.posY,(parameters.RUNAWAYDIS/self.world.setting.AdjustAttRange)) 
					local ret,newtoX1,newtoY1=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX1,self.posY+toY1) 
					local d1 = self:distance(newtoX1,newtoY1)
					self:D("英雄移动AI3".." newtoX1:"..newtoX1.." newtoY:"..newtoY1.." d:"..d1)
					toX2,toY2 = self.world.map:getXYLengthCross(obj.posX,obj.posY,self.posX,self.posY,-(parameters.RUNAWAYDIS/self.world.setting.AdjustAttRange)) 
					local ret,newtoX2,newtoY2=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX2,self.posY+toY2) 
					local d2 = self:distance(newtoX2,newtoY2)
					self:D("英雄移动AI4".." newtoX2:"..newtoX2.." newtoY2:"..newtoY2.." d:"..d2)
					toX3,toY3 = self.world.map:getXYLength(obj.posX,obj.posY,self.posX,self.posY,-(parameters.RUNAWAYDIS/self.world.setting.AdjustAttRange)) 
					local ret,newtoX3,newtoY3=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX3,obj.posY+toY3) 
					local d3 = self:distance(newtoX3,newtoY3)
					self:D("英雄移动AI5".." newtoX3:"..newtoX3.." newtoY3:"..newtoY3.." d:"..d3)


					local solist = {{d=d0,x=newtoX,y=newtoY,n=1},{d=d1*0.75,x=newtoX1,y=newtoY1,n=2},{d=d2*0.75,x=newtoX2,y=newtoY2,n=3},{d=(d3-d)*0.75,x=newtoX3,y=newtoY3,n=4}}
					self.world.tSort(solist,function( a1,b1 )
						return a1['d'] > b1['d']
					end)
					self:D("惧怕 list:",self.world.cjson.encode(solist))
					toX = solist[1]['x']
					toY = solist[1]['y']
				
					--self:setMoveTarget(toX,toY)
					local randX = self.world.formula:getRandnum(-100,100)
					local randY = self.world.formula:getRandnum(-100,100)
					self:moveTo(toX+randX*0.01,toY+randY*0.01,true,7,parameters.RUNAWAYSPEED)
					self:addStatusList({s=98,r=self.world:getGameTime(),t=(self.moveToEndTime-self.world:getGameTime()),i=self.itemID},0)
					self.mode2NextTime = self.moveToEndTime+0
					self:D("释放惧怕 moveTo",toX,toY,self.moveToEndTime-self.world:getGameTime())
				end
			end
		end	
	else
		if self.statusList[98]~=nil and self.world:getGameTime()>self.cfNextTime then
			self:removeStatusList(98)
		end
	end

	if self.cfNextTime>self.world:getGameTime() then
		self.lastCoolDownTime = self.cfNextTime
	end
	if self.world:getGameTime()>self.moveToEndTime then
		if self.statusList[98]~=nil then
				self:D(" 冲锋 重置98")
			self:removeStatusList(98)
		end
	end
	SBoss5H.super.fight(self)
end


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss5H:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SBoss5H.super.prepareHit(self,mode,adjTime,buff) 
	if mode==3 then
		--重置次数
		self.cfNum = 0
		self:D(" 冲锋 重置")
	end
	if mode==3 or mode==4 then
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 
		self.starX = self.posX
		self.starY = self.posY
		--skill.hitTime = 0
		--INEVITABLEHIT=1;RUNSPEED=2000;ATKRADIUS=300;ATKTIMES=5;BACKWARDRANGE=600;BACKWARSPEED=3000;BACKWARDINTERVAL=2;ADDSELFSTATUS=83;ADDSELFSTATUSTIME=2;SADDSELFSTATUSA=4333;SADDSELFSTATUSTIMEA=999
		local toX,toY = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,1000)
		local ret
		self:D("prepareHit 飞飞飞........ x tox y toy distance ",self.posX,toX,self.posY,toY,skill.atkDis/self.world.setting.AdjustAttRange)
		ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX,self.posY+toY) 
		local d =self:distance(toX,toY)
		self:moveTo(toX,toY,false,7,parameters.RUNSPEED,adjTime+skill.hitTime) 
		self:D(" 冲锋 paths",self.world.cjson.encode(self.paths))
		local lifetime = d*self.world.setting.AdjustAttRange/parameters.RUNSPEED
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['buffParameter'] = table.deepcopy(self:getPrepareHithitValue())
		attributes['buffParameter']['RANGE'] = parameters.ATKRADIUS
		attributes['buffParameter']['creatureDirectHurCallBack'] = 'jpjt'
		attributes['buffParameter']['buffType'] = 1
		attributes['buffParameter']['buffIntervalTime'] = 0.1
		attributes['buffParameter']['Effect'] = -1
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifetime,{99},0,self.itemID,self.itemID,adjTime+skill.hitTime)
		self:addBuff(buff)
		self.cfNextTime = lifetime + self.world:getGameTime() + adjTime+skill.hitTime + parameters.SKILLINTERVAL
		-- self:removeStatusList(98)
		self:addStatusList({i=self.itemID,s=98,r=self.world:getGameTime(),t=99},skill.hitTime)
		self:D("冲锋 时间",self.cfNextTime,self.world:getGameTime(),lifetime,skill.hitTime,adjTime,self.moveToEndTime,d)
		self.toX = toX
		self.toY = toY
	end

	if mode==4 then
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 
		--次数加1
		self.cfNum = self.cfNum + 1
		self:D(" 冲锋 +1",self.cfNum)
		if self.cfNum==parameters.ATKTIMES then
			self:D(" 冲锋 清除",self.cfNum)
			--结束4333状态 并添加一个差不多结束的4333
			self:removeStatusList(4333)
			self:addStatusList({zz=3,i=self.itemID,s=4333,r=self.world:getGameTime(),t=(self.moveToEndTime-self.world:getGameTime())},0)
		end
	end

	return hitValueBoth 
end 


--- 准备攻击前置设置，在prepareHit之后执行，call父类
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SBoss5H:prepareSkillAttackCustom(mode,target,x,y,adjTime,syncMsg)  
	if mode==3 or mode==4 then
		syncMsg['a']['x'] = self.toX
		syncMsg['a']['y'] = self.toY
	end
	SBoss5H.super.prepareSkillAttackCustom(self,mode,target,x,y,adjTime,syncMsg)  
end 



--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss5H:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	if mode==2 then
		local skill = self.attribute.skills[2] 
		local parameters = skill.parameters
		--远离正常攻击的目标
		self.attribute.skills[1].lastCoolDownTime = self.world:getGameTime() +  parameters.RUNAWAYTIME
		self.mode2Time = self.world:getGameTime() + parameters.RUNAWAYTIME
		self:D("释放惧怕 prepareHit",self.mode2Time,self.lastCoolDownTime,self.world:getGameTime())
	end
	local ret = SBoss5H.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	return ret 
end 

--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SBoss5H:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 

	if isset(hitValue['creatureDirectHurCallBack']) and hitValue['creatureDirectHurCallBack']=="jpjt"  then --and in_array(hitValue['creatureDirectHurCallBack'],self.creatureList)) then
		self:D("流沙 回调.........击中了:",itemID)
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 

		--击退
		local obj = self.world.allItemList[itemID]
		if obj.nextMoveTime==nil or self.world:getGameTime()>obj.nextMoveTime then
			--弹飞园半径
			local r = parameters.BACKWARDRANGE/self.world.setting.AdjustAttRange
			
			toX,toY = self.world.map:getXYLength(self.posX,self.posY,obj.posX+self.world.formula:getRandnum(200,250)*0.01,obj.posY+self.world.formula:getRandnum(100,200)*0.01,r) 
			ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
			--目标到偏移位置的距离
			--local d =self.world.mPow(self.world.mPow(obj.posX-toX,2) + self.world.mPow(obj.posY-toY,2),0.5)
			----debuglog("BOSS2A mode 4 posX:"..obj.posX.." posY:"..obj.posY.." toX:"..toX.." toY:"..toY.." d:"..d.." itemID:"..obj.itemID)
			-- local bulletSpeed = parameters.BACKWARDSPEED2
			obj:moveTo(toX,toY,true,5,parameters.BACKWARSPEED,0)
			obj.nextMoveTime = self.world:getGameTime() + parameters.BACKWARDINTERVAL

			local hitValueNew = table.deepcopy(self:getPrepareHithitValue())
			hitValueNew['INEVITABLEHIT']=1
			--hitValueNew['DIZZY_RATE'] = 100
			--hitValueNew['FIXHURT'] = 99
			hitValueNew['ADADJ'] = parameters.ADADJ2
			hitValueNew['APADJ'] = parameters.APADJ2
			--hitValueNew['BUFFTIME'] = 0.5 
			self:directHurtToDalay(3,itemID,hitValueNew,0)
		end
	end
end


function SBoss5H:createInit()
	self:callCreateInit()
end


return SBoss5H 
