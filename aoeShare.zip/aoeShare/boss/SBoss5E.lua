local SBoss5E = class("SBoss5E", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss5E:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss5E" 
	end 

	SBoss5E.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		----debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
end 



--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss5E:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	



	ret = SBoss5E.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	--ADDSELFSTATUS=4150;ADDSELFSTATUSTIME=999;ABSORDTIME=0.9;INEVITABLEHIT=1
	if mode==4 and hitValue['Effect']~=2 then
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 


		local d =self.world.mPow(self.world.mPow(obj.posX-self.posX,2) + self.world.mPow(obj.posY-self.posY,2),0.5)
		--debuglog(itemID.." 2点之间的距离为.......:"..d)

		if d>1 then
			d=d-1
		end

		local toX,toY = self.world.map:getXYLength(obj.posX,obj.posY,self.posX,self.posY,d)
		local ret1

		ret1,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
		--实际距离求速度
		local sd = d
		local bulletSpeed = (sd/parameters.ABSORDTIME)*100
		--debuglog("飞行时间:"..parameters.ABSORDTIME)
		--debuglog("飞行距离:"..sd)
		--debuglog("飞行速度:"..bulletSpeed)
		obj:moveTo(toX,toY,false,5,bulletSpeed,0)

	end

	if mode==5 and hitValue['isOneMode5']==nil then
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[5] 
		local parameters = skill.parameters 
		local attributes = table.deepcopy(self:getPrepareHithitValue())
		attributes['APADJ']=parameters.APADJ2
		attributes['isOneMode5']=1
		--self:directHurtToDalay(5,itemID,attributes,parameters.HURTDELAY)
		self:directFightAuratoDalay(5,0,attributes,{posX=obj.posX,posY=obj.posY,RANGE=parameters.HURTRANGE},parameters.HURTDELAY) 
	end

	return ret 
end 

function SBoss5E:createInit()
	self:callCreateInit()
end

return SBoss5E 
