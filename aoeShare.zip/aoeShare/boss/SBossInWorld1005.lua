local SBossInWorld1005 = class("SBossInWorld1005", require("gameroomcore.SHeroBase"))

function SBossInWorld1005:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld1005.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end



return SBossInWorld1005