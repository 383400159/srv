local SBossInWorld2004 = class("SBossInWorld2004", require("gameroomcore.SHeroBase"))

function SBossInWorld2004:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld2004.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld2004
