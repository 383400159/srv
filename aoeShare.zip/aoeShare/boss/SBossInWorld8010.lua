local SBossInWorld8010 = class("SBossInWorld8010", require("gameroomcore.SHeroBase"))

function SBossInWorld8010:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld8010.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SBossInWorld8010