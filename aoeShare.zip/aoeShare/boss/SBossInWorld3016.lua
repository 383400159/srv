local SBossInWorld3016 = class("SBossInWorld3016", require("gameroomcore.SHeroBase"))

function SBossInWorld3016:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld3016.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld3016
