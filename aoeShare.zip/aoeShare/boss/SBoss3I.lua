local SBoss3I = class("SBoss3I", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss3I:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss3I" 
	end 

	SBoss3I.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		--debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
	self.oldItemID = 0
end 

function SBoss3I:createInit()
	local attributes = {}
	local hitValueNew = self:getPrepareHithitValue()
	attributes = hitValueNew
	attributes['BUFFONLY']=1
	attributes['IMMUNECONTROL_RATE'] = 100
	attributes['buffType'] = 3
	attributes['BUFFTIME'] = 99999
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0,99),attributes,99999,{},0,self.itemID,self.itemID,0)
	self:addBuff(buff)
end


--- 自动释放技能 
-- @return null
function SBoss3I:_autoFight()
	--print('jaylog boss autoFightAI:',self.autoFightAI.runAI)
	--debuglog("SAI ..... outOfCtlTime:"..self.outOfCtlTime.." gameTime:"..self.world.gameTime.." getGameTime:"..self.world:getGameTime())
	local ret=SBoss3I.super._autoFight(self)

	if not ret and self.AIlastCoolDown<self.world:getGameTime() and self.lastCoolDownTime<self.world:getGameTime() and  not self:isDead() and self.autoFightAI.runAI  then
		self:D("SBossInWorld1004:_autoFight(2)")
		--需要获得自动攻击的item  释放skill的id
		local targetID,skillID,cdTime=self.autoFightAI:execute()

		local atkList = {}
		local atkItemID  = self.oldItemID
		for k,v in pairs(self.world.allItemList) do
			if v.attribute.actorType==0 and v.statusList[41]~=nil and v.statusList[41]["p1"]==283 then
				atkList[#atkList+1]=v
			end
		end

		--判断原先的家伙还有没有在采集
		local obj = self.world.allItemList[self.oldItemID]
		if obj~=nil and obj.statusList[41]~=nil and obj.statusList[41]["p1"]==283 then
			atkItemID  = self.oldItemID
		else
			if #atkList>=1 then
				local r1 = self.world.formula:getRandnum(1,#atkList)
				atkItemID = atkList[r1].itemID
			else
				atkItemID = 0
			end
		end

		if atkItemID>0 then
			targetID=atkItemID
		end
		
		if targetID>0 then
			self:D("策划SEASON放了什么技能 fenglog checkBOSS roleId:"..self.attribute.roleId.." targetID:"..targetID.." skillID:"..skillID.." cdTime:"..cdTime)
			self:skillAttack(skillID,targetID)
			self.autoFightAI.runMoveAI = false
			self.AIlastATKtoMove = self.world:getGameTime()-0.5
			self.AIlastAutoMove = self.world:getGameTime()
		end
		--boss寻敌cd
		self.AIlastCoolDown = self.world:getGameTime() + cdTime
	end


	if not self:isDead() then
		if self.AIlastATKtoMove+10<self.world:getGameTime() then 
			--self:debuglog("AIlastATKtoMove:"..self.AIlastATKtoMove.." runMoveAI true")
			if	self.attribute.parameterArr['NOMOVEAI']==nil then
				self.autoFightAI.runMoveAI = true
			end
		else
			self.autoFightAI.runMoveAI = false
		end
	end

end


return SBoss3I 
