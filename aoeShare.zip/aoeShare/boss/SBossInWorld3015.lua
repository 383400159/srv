local SBossInWorld3015 = class("SBossInWorld3015", require("gameroomcore.SHeroBase"))

function SBossInWorld3015:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld3015.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld3015
