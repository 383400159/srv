local SBoss7A = class("SBoss7A", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss7A:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss7A" 
	end 

	SBoss7A.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		--debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
	--冰河时代的时间
	self.bhsdTime = 0

	self.mode12EndTime = 0
	self.mode12enemyID = 0
	self.mode12CheckTime = 0
end 


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss7A:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SBoss7A.super.prepareHit(self,mode,adjTime,buff) 
	
	if mode==4 then
		self.modeatklist={}
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		local teamlist = {}
		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		local dlist = {}
		--local oldlist = {}
		--local atknum = parameters.TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				--if (atknum<=0) then ok = false end
				----debuglog('jaylog ok:'..ok)
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
					----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
					if (d>=0) then 
						--atknum = atknum - 1
						dlist[#dlist+1] = obj   
					end
				end
			end
		end
		)

		dlist=table.shuffle(dlist)
		local nwdlist = {}
		for i=1,parameters.TARGETNUM do
			nwdlist[#nwdlist+1] = dlist[i]
		end


		if #nwdlist>0 then
			self:D("机器人有目标 nwdlist:",#nwdlist)
			for k,v in pairs(nwdlist) do
				local d = self:distance(v.posX,v.posY)
				local FLYTIME = (d*100)/skill.bulletSpeed
				local attributes = table.deepcopy(hitValueBoth)
				self:directHurtToDalay(4,v.itemID,attributes,parameters['HITTIME'..k]+FLYTIME)
				self.modeatklist[#self.modeatklist+1]=v.itemID..","..parameters['HITTIME'..k]..","..FLYTIME
				-- local obj1 = self.world.allItemList[v.itemID] 
				-- obj1:addStatusList({s=parameters.ADDSTATUS1,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME1,i=self.itemID,p1=parameters.HELUSI_EYE_RADIUS},parameters['HITTIME'..k]+FLYTIME)
				-- obj1:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID,p1=parameters.HELUSI_EYE_RADIUS},parameters['HITTIME'..k]+FLYTIME)
			end	

		end
		hitValueBoth=nil
	end

	-- if mode==6  then
	-- 	self.modelist={}
	-- 	local skill = self.attribute.skills[mode] 
	-- 	local parameters = skill.parameters 
	-- 	local teamlist = {}

	-- 	local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
	-- 	----debuglog('jaylog useDis:'..skill.useDis..' AdjustAttRange:'..self.world.setting.AdjustAttRange)
	-- 	local dlist={}
	-- 	--local oldlist={}
	-- 	local atknum = parameters.TARGETNUM
	-- 	local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
	-- 	function(obj)
	-- 	 	if obj.teamOrig~=self.teamOrig then
	-- 			ok = true
	-- 			if (obj:isDead()) then ok = false end
	-- 			--if (atknum<=0) then ok = false end

	-- 			if ok then
	-- 				local d = obj:colliding(visRange,0,0,self.itemID)

	-- 				if (d>=0) then 
	-- 					--atknum = atknum - 1
	-- 					--dlist[#dlist+1] = obj 
	-- 					dlist[#dlist+1]={itemID=obj.itemID,DIS=d}  
	-- 				end
	-- 			end
	-- 		end
	-- 	end
	-- 	)

	-- 	self.world.tSort(dlist,function( a1,b1 )
	-- 				return a1['DIS'] > b1['DIS']
	-- 			end)

	-- 	local newDlist = {}
	-- 	newDlist[1]=dlist[#dlist]
	-- 	for i=1,atknum-1 do
	-- 		newDlist[#newDlist+1]=dlist[i]
	-- 	end

	-- 	--找到目标释放一个群体aoe在目标脚下
	-- 	for k,v in pairs(newDlist) do
	-- 		--debuglog(" SBoss2A:prepareHit: duration"..parameters.HURTLIFE..' buffIntervalTime:'..parameters.HURTITNTERVAL)
	-- 		local obj  = self.world.allItemList[v.itemID]
	-- 		local creatureID=self.world:addCreature(self.world.tostring(parameters.ENEMY),self.teamOrig,obj.posX,obj.posY,self,1,0)

	-- 		local obj  = self.world.allItemList[creatureID]
	-- 		self.creatureList[#self.creatureList+1]=creatureID  
	-- 		local lifeTime=parameters.HURTLIFE		
	-- 		local attributes = {}
	-- 		attributes['buffParameter']={}
	-- 		attributes['BUFFONLY']=1
			
	-- 		attributes['buffParameter'] = hitValueBoth

	-- 		attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
	-- 		attributes['buffParameter']['buffType'] = 1
	-- 		attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
	-- 		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,parameters.HURTSTARTTIME)
	-- 		obj:addBuff(buff)
	-- 		obj:setDeadTime(lifeTime) 
	-- 	end
		
	-- 	self:addStatusList({s=parameters.ADDSELFSTATUS,r=self.world:getGameTime(),t=parameters.ADDSELFSTATUSTIME,i=self.itemID})
	-- 	hitValueBoth = nil
	-- end
	--让地面变为冰面，玩家只要不移动超过5秒则会被冰冻，该区域持续12秒
	--ADDSELFSTATUS=4283;ADDSELFSTATUSTIME=12;TRIGGERSELFSTATUS=4284;TRIGGERSELFSTATUSTIME=9999
	if mode==8 then
		--放个怪在脚下
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local creatureID=self.world:addCreature(self.world.tostring(303),self.teamOrig,self.posX,self.posY,self,1,0)
		local obj  = self.world.allItemList[creatureID]
		obj:setDeadTime(parameters.ADDSELFSTATUSTIME) 
		self.bhsdTime = self.world:getGameTime()
	end

	--飞两秒后砸下 让目标范围所有目标受到500%【魔法伤害】，并让所有命中目标冻结，持续8秒
	if mode==10 then
		--ADDSTATUS=35;ADDSTATUSTIME=3;FLYTIME=0.35
		local skill = self.attribute.skills[10] 
		local parameters = skill.parameters 
		local d1 = self:distance(self.lastBulletPositionX,self.lastBulletPositionY)
		local atkDis = (d1-parameters.NEARESTUSEDIS/self.world.setting.AdjustAttRange)>0 and (d1-parameters.NEARESTUSEDIS/self.world.setting.AdjustAttRange) or d1

		local toX1,toY1 = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,atkDis)
		local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX1,self.posY+toY1) 
		--local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY)
		--debuglog("伊利丹 大招 posX:"..self.posX.." posY:"..self.posY.." lastBulletPositionX:"..self.lastBulletPositionX.." lastBulletPositionY:"..self.lastBulletPositionY.." toX:"..toX.." toY:"..toY)
		local d = self:distance(toX,toY)
		-- local stopD=parameters.STOPTIME*5
		-- local FLYSPEED = ((d-stopD)*100)/(parameters['FLYTIME']+parameters['DOWNTIME'])
		local FLYSPEED = (d*100)/(parameters['FLYTIME'])

		self:moveTo(toX,toY,false,6,FLYSPEED,skill.hitTime+adjTime)
		--local dealyTime = (d*100)/parameters['FLYSPEED']
		local dealyTime = parameters['FLYTIME']
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['buffParameter'] = {}
		attributes['buffParameter']['buffIntervalTime'] = dealyTime
		local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,dealyTime+0.1,{mode},0,self.itemID,self.itemID,skill.hitTime+adjTime) 
 		self:addBuff(buffObj)
 		--debuglog("伊利丹 大招 d:"..d.."dealyTime:"..dealyTime.." lastBulletPositionX:"..self.lastBulletPositionX.." lastBulletPositionY:"..self.lastBulletPositionY.." posX"..self.posX.." posY:"..self.posY)
		hitValueBoth=nil
		self.mode4time = self.world.gameTime+skill.hitTime

		self.lastBulletPositionX = toX
		self.lastBulletPositionY = toY
		return nil
	end

	if mode==110 then
		local skill = self.attribute.skills[10] 
		local parameters = skill.parameters 
		if self.world.gameTime>self.mode4time then
			--debuglog("伊利丹 大招 回调")
			local hitValueNew = hitValueBoth
			hitValueNew['skillID'] = 10
			hitValueNew['ADADJ'] = parameters.ADADJ2 
			self:directFightAuratoDalay(10,0,hitValueNew,{posX=self.posX,posY=self.posY,RANGE=skill.atkDis},0) 

		end
		hitValueBoth=nil
	end

	if mode==12 then
		local skill = self.attribute.skills[12]
		local parameters = skill.parameters
		local cList = parameters['SUMMONRING']

		local LIFETIME = parameters.SADDSELFSTATUSTIMEA
		self.mode12EndTime = self.world.gameTime + LIFETIME
		-- local attributes = {}
		-- attributes['buffParameter']={}
		-- attributes['BUFFONLY']=1
		-- attributes['buffParameter'] = {}
		-- -- attributes['buffParameter']['buffIntervalTime'] = parameters.MOVEINTERVAL
		-- local buffObj=self.world:createBuff(self:__skillID2buffID(skill.skillID,0),attributes,LIFETIME,{mode},0,self.itemID,self.itemID,skill.hitTime) 
 	-- 	self:addBuff(buffObj)

 		for k,v in pairs(self.world.itemListFilter.heroList) do
 			if v.actorType==0 then
	 			local attributes = {}
				attributes['SILIENCE_RATE'] = 100 
				local buffObj=self.world:createBuff(v:__skillID2buffID(0),attributes,LIFETIME,{},0,v.itemID,v.itemID)
		 		v:addBuff(buffObj)
		 	end
 		end

 		self.mode12enemyID = self.world:addCreature(cList[2],self.teamOrig,parameters['CIRCLE1']['POSX'],parameters['CIRCLE1']['POSY'],self,1)
 		hitValueBoth = nil
	end

	if mode==112 then
		local skill = self.attribute.skills[12]
		local parameters = skill.parameters

		local enemyObj = self.world.allItemList[self.mode12enemyID] 
		if self.world.gameTime<self.mode12EndTime then
			-- local enemyObj = self.world.allItemList[self.mode12enemyID] 
			-- if enemyObj~=nil then
			-- 	if enemyObj.canMove then
			-- 		local toX,toY = self.world.map:getXYLength (enemyObj.posX, enemyObj.posY, self.posX, self.posY, 2)
			-- 		enemyObj:moveTo(enemyObj.posX+toX,enemyObj.posY+toY)
			-- 	end
			-- 	local distance = self:distance(enemyObj.posX,enemyObj.posY)
			-- 	if distance<=1 then
			-- 		self:removeStatusList(parameters.SADDSELFSTATUSA)
			-- 		self:removeBuffToID(self:__skillID2buffID(skill.skillID,0))
			-- 		self:setCoolDownTime(self.world.gameTime)
			-- 		enemyObj.attribute.HP = 0
			-- 		enemyObj:directHurt(self.mode12enemyID,1,{},0)
			-- 	end
			-- end
			hitValueBoth = nil
		else
			if enemyObj~=nil then
				local distance = self:distance(enemyObj.posX,enemyObj.posY)
				if distance>1 then
					self:addStatusList({s=4285,r=self.world:getGameTime(),t=parameters.SADDSELFSTATUSTIMEA,i=self.itemID})
				end
				enemyObj.attribute.HP = 0
				enemyObj:directHurt(self.mode12enemyID,1,{},0)
			end
		end
	end

	return hitValueBoth 
end 

--- fight motion , call every update loop
-- @return null
function SBoss7A:fight()
	if self.mode12CheckTime+1<self.world:getGameTime() then
		local enemyObj = self.world.allItemList[self.mode12enemyID] 
		if enemyObj~=nil then
			if enemyObj.canMove then
				local toX,toY = self.world.map:getXYLength (enemyObj.posX, enemyObj.posY, self.posX, self.posY, 2)
				enemyObj:moveTo(enemyObj.posX+toX,enemyObj.posY+toY)
			end
			local distance = self:distance(enemyObj.posX,enemyObj.posY)
			if distance<=1 then
				self:removeStatusList(parameters.SADDSELFSTATUSA)
				self:removeBuffToID(self:__skillID2buffID(skill.skillID,0))
				self:setCoolDownTime(self.world.gameTime)
				enemyObj.attribute.HP = 0
				enemyObj:directHurt(self.mode12enemyID,1,{},0)
			end
		end
		self.mode12CheckTime = self.world:getGameTime()
	end
	SBoss7A.super.fight(self)
end

--- 准备攻击前置设置，在prepareHit之前执行，call父类
-- @param mode int - 技能1-7
-- @param itemID int - 目标对象itemID
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SBoss7A:prepareSkillAttackCustom(mode,itemID,x,y,adjTime,syncMsg)  

	if mode==4  and #self.modeatklist>0 then
		--debuglog("机器人 导弹列表 mode:"..mode)
		syncMsg['a']['p'] = implode(';',self.modeatklist)
		--debuglog("机器人 导弹列表:"..syncMsg['a']['p'].." syncMsg:"..self.world.cjson.encode(syncMsg))
	end
	SBoss7A.super.prepareSkillAttackCustom(self,mode,itemID,x,y,adjTime,syncMsg)
	
end 



--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss7A:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	--从自身中心发出的冲击波，让场上处于结冰状态的目标受到1000%【魔法伤害】
	if mode==9 then
		local skill = self.attribute.skills[9] 
		local parameters = skill.parameters 
		local obj  = self.world.allItemList[itemID]
		local FROZEN = obj.attribute.buffAttribute.FROZEN
		if FROZEN>0 then
			hitValue['APADJ'] = hitValue['APADJ2']
			obj:removeBUff('FROZEN')
		end
		self:D("冰雹")
	end

	local ret = SBoss7A.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	return ret 
end 




function SBoss7A:createInit()
	self:callCreateInit()
end

--- 通过hitValue参数召唤小怪
-- @param hitValue table - 伤害基础参数
-- @param mode int - call些function的技能ID
-- @return null
function SBoss7A:callCreature(hitValue,mode)
	if mode==12 then
		return nil
	else
		return SBoss7A.super.callCreature(self,hitValue,mode)
	end
end

return SBoss7A 
