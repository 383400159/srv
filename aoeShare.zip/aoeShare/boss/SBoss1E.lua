local SBoss1E = class("SBoss1E", require("gameroom.boss.SBoss2E")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss1E:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss1E" 
	end 

	SBoss1E.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		--debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end

	self.lastDegree = 0
	self.creatureList = {}
end 


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
-- function SBoss1E:prepareHit(mode,adjTime,buff)  
-- 	local hitValueBoth=SBoss1E.super.prepareHit(self,mode,adjTime,buff) 
-- 	if mode==4 then
-- 		--self.world:debuglog('jaylog SBoss1E:prepareHit mode4')
-- 		local skill = self.attribute.skills[4] 
-- 		local parameters = skill.parameters
-- 		self.lastDegree = 180 + parameters.STARTANGLE
-- 		hitValueBoth = nil
-- 	end
-- 	if mode==104 then
-- 		local skill = self.attribute.skills[4] 
-- 		local parameters = skill.parameters

-- 		local customize = skill
-- 		local toX,toY
-- 		toX = self.posX + math.cos(math.rad(self.lastDegree))*100
-- 		toY = self.posY + math.sin(math.rad(self.lastDegree))*100
-- 		local hitValue=hitValueBoth
-- 		hitValue['APADJ'] = parameters.APADJ2
-- 		local bulletID = self.world:addBullet(4,self.itemID,self.world.gameTime,0,toX,toY,false,hitValue,customize)
-- 		--self.world:debuglog('jaylog SBoss1E:prepareHit mode104 ',self.itemID,self.world.gameTime,0,'toX',toX,'toY',toY,false,hitValue,customize)
-- 		self.lastDegree = self.lastDegree+parameters.INTERVALANGLE
-- 		--self.world:debuglog('jaylog SBoss1E:prepareHit mode104 ',self.lastDegree,' x:',self.posX,' y:',self.posY)
-- 		hitValueBoth = nil
-- 		mode = 4
-- 	end
-- 	if mode==5 then
-- 		local skill = self.attribute.skills[5] 
-- 		local parameters = skill.parameters
-- 		--self.world:debuglog('jaylog SBoss1E:prepareHit mode5')
-- 		--for k,v in pairs(self.world.itemListFilter.heroList) do
-- 			--if v.actorType==0 and v.itemID==1 then
-- 				local obj = self.world.allItemList[1]
-- 				local creatureID=self.world:addCreature(self.world.tostring(parameters.ENEMYID),self.teamOrig,obj.posX,obj.posY,self,1)
-- 				local creatureObj = self.world.allItemList[creatureID]
-- 				creatureObj:setSubName(parameters.SUBNAME)
-- 				creatureObj:setDeadTime(9999)
-- 				creatureObj:addStatusList({s=self.world.tonumber(parameters.ADDSTATUS2),r=self.world.gameTime,t=9999,i=self.itemID},parameters.ADDDELAYTIME)
-- 				self.creatureList[1] = creatureObj
-- 			--end
-- 		--end
-- 	end
-- 	-- if mode==6 then
-- 	-- 	local skill = self.attribute.skills[6] 
-- 	-- 	local parameters = skill.parameters

-- 	-- 	local customize = skill
-- 	-- 	local hitValue=table.deepcopy(hitValueBoth)
-- 	-- 	for k,v in pairs(self.creatureList) do
-- 	-- 		local obj = self.world.allItemList[v]
-- 	-- 		obj.attribute.HP = 0
-- 	-- 		obj:directHurt(obj.itemID,1,{},0)
-- 	-- 		self.world:addBullet(6,self.itemID,self.world.gameTime,0,obj.posX,obj.posY,false,hitValue,customize)
-- 	-- 	end
-- 	-- 	hitValueBoth = nil
-- 	-- end
-- 	if mode==107 then
-- 		--self.world:debuglog('jaylog SBoss1E:prepareHit mode107')
-- 		mode = 7
-- 	end

-- 	return hitValueBoth 
-- end 

--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
-- function SBoss1E:hitTarget(itemID,bulletID,mode,hitValue,adjTime)
-- 	local ret = SBoss1E.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime)
-- 	-- if mode==6 then
-- 	-- 	--self.world:debuglog('jaylog SBoss1E:hitTarget mode6 ',itemID,bulletID,mode,hitValue,adjTime)
-- 	-- 	for k,v in pairs(self.creatureList) do
-- 	-- 		if self.world.allItemList[v]~=nil and not self.world.allItemList[v]:isDead() then
-- 	-- 			local obj = self.world.allItemList[v]
-- 	-- 			obj.attribute.HP = 0
-- 	-- 			obj:directHurt(obj.itemID,1,{},0)
-- 	-- 		end
-- 	-- 	end
-- 	-- end
-- 	if mode==7 then
-- 		--self.world:debuglog('jaylog SBoss1E:hitTarget mode7 ',itemID,bulletID,mode,hitValue,adjTime)
-- 		local skill = self.attribute.skills[7] 
-- 		local parameters = skill.parameters

-- 		local obj = self.world.allItemList[itemID]
-- 		local xLen,yLen = self.world.map:getXYLength(self.posX,self.posY,obj.posX,obj.posY,parameters.BACKWARD/self.world.setting.AdjustAttRange)
-- 		local ret,toX,toY
-- 		ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+xLen,obj.posY+yLen) 
-- 		obj:moveTo(toX,toY,false,5,parameters.BACKWARDSPEED,0) 
-- 	end
-- 	return ret
-- end

--- 准备攻击前置设置，在prepareHit之前执行
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
-- function SBoss1E:prepareSkillAttackCustom(mode,target,x,y,adjtime,syncMsg)
-- 	if mode==1 then
-- 		self.world.bulletList[self.lastBulletID].attr.debug = true
-- 	end
-- 	if mode==4 then
-- 		if syncMsg~=nil and syncMsg['a']~=nil then
-- 			syncMsg['a']['x'] = self.posX
-- 			syncMsg['a']['y'] = self.posY - 3
-- 		end
-- 		self.world:D('jaylog SBoss1E:prepareSkillAttackCustom ',self.world.cjson.encode(syncMsg['a']))
-- 	end
-- 	if mode==5 then
-- 		syncMsg['a']['x'] = self.creatureList[1].posX
-- 		syncMsg['a']['y'] = self.creatureList[1].posY
-- 		syncMsg['a']['ti'] = self.creatureList[1].itemID
-- 		self.world:D('jaylog SBoss1E:prepareSkillAttackCustom mode 5 syncMsg ',self.world.cjson.encode(syncMsg))
-- 	end
-- 	SBoss1E.super.prepareSkillAttackCustom(self,mode,target,x,y,adjtime,syncMsg)
-- end

function SBoss1E:createInit()
	self:callCreateInit()
end

return SBoss1E 
