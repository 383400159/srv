local SBossInWorld1009 = class("SBossInWorld1009", require("gameroomcore.SHeroBase"))

function SBossInWorld1009:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld1009.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end



return SBossInWorld1009