local SBossInWorld8011 = class("SBossInWorld8011", require("gameroomcore.SHeroBase"))

function SBossInWorld8011:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld8011.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SBossInWorld8011