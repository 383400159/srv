local SBoss8E = class("SBoss8E", require("gameroom.boss.SBoss1B")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss8E:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss8E" 
	end 

	SBoss8E.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		----debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
end 

function SBoss8E:xwmq(hitValueBoth)

end
--- 這個function 會在 執行前搖時call 當skill.delayCalTime>0
-- @param skill skillobj - skillobj
function SBoss8E:prepareSkillAttackDelayInit(skill)
	local hitValueBoth = SBoss8E.super.prepareSkillAttackDelayInit(self,skill)
	local mode=skill.rank
	if mode==4 then
		local parameters = skill.parameters 
		local teamlist = {}
		--搜敌找到所需要的目标
		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		----debuglog('jaylog useDis:'..skill.useDis..' AdjustAttRange:'..self.world.setting.AdjustAttRange)
		local dlist = {}
		local atknum = parameters.TARGETNUM

		-- local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		-- function(obj)
		--  	if obj.teamOrig~=self.teamOrig then
		-- 		ok = true
		-- 		if (obj:isDead()) then ok = false end
		-- 		if (atknum<=0) then ok = false end
		-- 		----debuglog('jaylog ok:'..ok)
		-- 		if ok then
		-- 			local d = obj:colliding(visRange,0,0,self.itemID)
		-- 			----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
		-- 			if (d>=0) then 
		-- 				atknum = atknum - 1
		-- 				dlist[#dlist+1] = obj   
		-- 			end
		-- 		end
		-- 	end
		-- end
		-- )

		--找到目标释放一个群体aoe在目标脚下
		-- for k,obj in pairs(dlist) do
			----debuglog('jaylog dlist:'..k)
			local skill = self.attribute.skills[4] 
			local parameters = skill.parameters 
			--APADJ=125;DEF_DOWN=50;DEF_DOWN_RATE=100;BUFFTIME=10

			----debuglog("hitTime_:"..skill.hitTime)
			--debuglog("jaylog SBoss1A:prepareHit: duration"..skill.duration..' buffIntervalTime:'..skill.bulletTimeInterval)
			local creatureID=self.world:addCreature(self.world.tostring(263),self.teamOrig,self.lastBulletPositionX,self.lastBulletPositionY,self,1,skill.hitTime)
			local obj  = self.world.allItemList[creatureID]
			self.creatureList[#self.creatureList+1]=creatureID  
			local lifeTime=parameters.HURTLIFE		--skill.parameters.DEAD
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			--debuglog("SBoss8E:prepareHit------------....hitValueBoth:"..self.world.cjson.encode(hitValueBoth))
			attributes['buffParameter'] = hitValueBoth
			--attributes['buffParameter']['FIXHURT'] = 250
			-----debuglog("atkDis:"..parameters.hitTime)
			attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
			attributes['buffParameter']['creatureDirectHurCallBack'] = 'xwmq'
			----debuglog("jaylog addCreature  creatureID:"..creatureID)
			attributes['buffParameter']['buffType'] = 1
			--attributes['buffParameter']['buffAtleastOnce']=true
			attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
			self:D("虚无盲区  ",parameters.HURTLIFE, parameters.HURTITNTERVAL,parameters.HURTSTARTTIME,skill.hitTime)
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,(skill.hitTime+parameters.HURTSTARTTIME))
			obj:addBuff(buff)
			obj:setDeadTime(lifeTime) 
		--end
		hitValueBoth = nil
	end
	return hitValueBoth
end

--获得旋转射线方向
function SBoss8E:mode11Direction()
	local a = 0
	return a
end

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SBoss8E:goToDead(itemID,mode,adjTime,bonus)
	SBoss8E.super.goToDead(self,itemID,mode,adjTime,bonus)
	for k,v in pairs(self.statusList) do
		if k~=9 then
			self:removeStatusList(k)
		end
	end
end


return SBoss8E 