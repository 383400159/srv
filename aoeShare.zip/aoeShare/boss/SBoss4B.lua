local SBoss4B = class("SBoss4B", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss4B:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss4B" 
	end 

	SBoss4B.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		--debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
	self.oldmode2x = 0
	self.oldmode2y = 0
	self.newmode2x = 0
	self.newmode2y = 0
end 


function SBoss4B:createInit()
	self:callCreateInit()
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss4B:prepareHit(mode,adjTime,buff)
	local hitValueBoth=SBoss4B.super.prepareHit(self,mode,adjTime,buff) 

	if mode==104 and self.world:getGameTime()>self.mode4time then
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		local hitValueNew = self:getPrepareHithitValue()
		hitValueNew['DIZZY_RATE'] = parameters.DIZZY_RATE2
		hitValueNew['BUFFTIME'] = parameters.BUFFTIME2
		hitValueNew['ADADJ'] = parameters.ADADJ2
		hitValueNew['INEVITABLEHIT']=1
		self:directFightAuratoDalay(4,0,hitValueNew,{posX=self.posX,posY=self.posY,RANGE=skill.atkDis},0)
		self.world:D('jaylog BOSS1C callback 104')
		hitValueBoth=nil 
		--mode = 4
	end

	if (mode==2) then
		hitValueBoth['bulletAttackMode4Passthru'] = false
	end

	return hitValueBoth
end


--- 准备攻击前置设置，在prepareHit之后执行
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SBoss4B:prepareSkillAttackCustom(mode,target,x,y,adjTime,syncMsg)
	if mode==2 then 
		local skill = self.attribute.skills[2] 
		local parameters = skill.parameters 

		local toX1,toY1 = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,parameters.BACKWARD/self.world.setting.AdjustAttRange)
		-- if self.posX==self.lastBulletPositionX and self.posY==self.lastBulletPositionY then
		-- 	newtoX = -self.lastBulletPositionX
		-- 	newtoY = -self.lastBulletPositionY
		-- 	local toX11,toY11 = self.world.map:getXYLengthCross(self.posX,self.posY,newtoX,newtoY,99) 
		-- 	ret,newtoX1,newtoY1=self.world.map:findPointStraightLineNearest(self.posX,self.posY,newtoX+toX11,newtoY+toY11) 
		-- 	local d1 = self:distance(newtoX1,newtoY1)
		-- 	self:D("英雄移动AI3".." newtoX1:"..newtoX1.." newtoY:"..newtoY1.." d:"..d1)
		-- 	local toX2,toY2 = self.world.map:getXYLengthCross(self.posX,self.posY,newtoX,newtoY,-99) 
		-- 	ret,newtoX2,newtoY2=self.world.map:findPointStraightLineNearest(self.posX,self.posY,newtoX+toX2,newtoY+toY2) 
		-- 	local d2 = self:distance(newtoX2,newtoY2)
		-- 	self:D("英雄移动AI4".." newtoX2:"..newtoX2.." newtoY2:"..newtoY2.." d:"..d2)
		-- 	local toX3,toY3 = self.world.map:getXYLength(self.posX,self.posY,newtoX,newtoY,-99) 
		-- 	ret,newtoX3,newtoY3=self.world.map:findPointStraightLineNearest(self.posX,self.posY,newtoX+toX3,newtoY+toY3) 
		-- 	local d3 = self:distance(newtoX3,newtoY3)
		-- 	self:D("英雄移动AI5".." newtoX3:"..newtoX3.." newtoY3:"..newtoY3.." d:"..d3)


		-- 	local solist = {{d=d1,x=toX11,y=toY11},{d=d2,x=toX2,y=toY2},{d=d3,x=toX3,y=toY3}}
		-- 	self.world.tSort(solist,function( a1,b1 )
		-- 		return a1['d'] > b1['d']
		-- 	end)

		-- 	self:D("冲锋 选个最大范围",self.world.cjson.encode(solist))

		-- 	toX1 = solist[1]['x']
		-- 	toY1 = solist[1]['y']
		-- end
		local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX1,self.posY+toY1) 

		local delaytime = parameters.COLLISIONBULLETHITTIME
		self.oldmode2x = self.posX
		self.oldmode2y = self.posY
		self.newmode2x = toX
		self.newmode2y = toY

		-- local obj = self.world.allItemList[1]
		-- local bossd=self:distance(obj.posX,obj.posY)
		-- self:D("冲锋 子弹开始释放时间:",self.world:getGameTime(),adjTime,"bossX:",self.posX,"bossY:",self.posY,"玩家X:",obj.posX,"玩家Y:",obj.posY,"相隔距离:",bossd)
		self:D("冲锋 boss开始移动延迟时间:",adjTime+delaytime)
		local bullet = self.world.bulletList[self.lastBulletID]
		bullet.positionX = toX
		bullet.positionY = toY
		syncMsg['a']['x'] = toX
		syncMsg['a']['y'] = toY
		self:D("冲锋改坐标 ",self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,bullet.positionX,bullet.positionY)
		local d=self:distance(toX,toY)
		self:moveTo(toX,toY,false,6,skill.bulletSpeed,adjTime+delaytime) 
		local attributes = {}
		attributes['IMMUNECONTROL_RATE'] = 100
		attributes['BUFFTIME'] = 0.2
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,0.2,{},0,self.itemID,self.itemID,adjTime)
		self:addBuff(buff)


		syncMsg['a']['p'] = (adjTime+delaytime)..","..((d*100)/skill.bulletSpeed)

	end

	if mode==4 then
		--NEARESTUSEDIS=200;FLYTIME=0.35;STOPTIME=0.15;DOWNTIME=0.1
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		local d1 = self:distance(self.lastBulletPositionX,self.lastBulletPositionY)
		local atkDis = (d1-parameters.NEARESTUSEDIS/self.world.setting.AdjustAttRange)>0 and (d1-parameters.NEARESTUSEDIS/self.world.setting.AdjustAttRange) or d1

		local toX1,toY1 = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,atkDis)
		local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX1,self.posY+toY1) 
		self.world:D("jaylog BOSS1C 4 posX:"..self.posX.." posY:"..self.posY.." lastBulletPositionX:"..self.lastBulletPositionX.." lastBulletPositionY:"..self.lastBulletPositionY.." toX:"..toX.." toY:"..toY)
		local d = self:distance(toX,toY)
		-- local stopD=parameters.STOPTIME*5
		-- local FLYSPEED = ((d-stopD)*100)/(parameters['FLYTIME']+parameters['DOWNTIME'])
		local FLYSPEED = (d*100)/(parameters['FLYTIME'])
		self:moveTo(toX,toY,false,6,FLYSPEED,skill.hitTime)
		--local dealyTime = (d*100)/parameters['FLYSPEED']
		local dealyTime = parameters['FLYTIME']
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['buffParameter'] = {}
		attributes['buffParameter']['buffIntervalTime'] = dealyTime
		local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,dealyTime+0.1,{mode},0,self.itemID,self.itemID,skill.hitTime) 
 		self:addBuff(buffObj)

 		self.mode4time = self.world:getGameTime()+skill.hitTime
	end

	-- if mode==2 then
	-- 	self.world.bulletList[self.lastBulletID].attr.debug = true
	-- end
end




--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss4B:hitTarget(itemID,bulletID,mode,hitValue,adjTime)
	local ret = SBoss4B.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime)

	if mode==2 and hitValue['Effect']~=2 then
		local obj = self.world.allItemList[itemID]
		local skill = self.attribute.skills[2]
		local parameters = skill.parameters
		local d = obj:distance(self.newmode2x,self.newmode2y)+obj.attribute.width
		local toX1,toY1 = self.world.map:getXYLength(self.oldmode2x,self.oldmode2y,self.newmode2x,self.newmode2y,d)
		local ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX1,obj.posY+toY1) 
		--local bossd=obj:distance(self.posX,self.posY)
		--self:D("冲锋 击中人的时间:",self.world:getGameTime(),"itemID:",itemID,"bossX:",self.posX,"bossY:",self.posY,"玩家X:",obj.posX,"玩家Y:",obj.posY,"距离boss距离",bossd)
		obj:moveTo(toX,toY,false,5,skill.bulletSpeed,0) 

	end

	return ret
end


return SBoss4B 
