local SBossInWorld103 = class("SBossInWorld103", require("gameroomcore.SHeroBase"))

function SBossInWorld103:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld103.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SBossInWorld103