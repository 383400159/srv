local SBoss2H = class("SBoss2H", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss2H:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss2H" 
	end 

	SBoss2H.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	--debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	self.mode2X = 0
	self.mode2Y = 0
	self.mode2D = 0
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
end 


function SBoss2H:createInit()
	self:callCreateInit()
end

--- 准备攻击前置设置，在prepareHit之后执行，call父类
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SBoss2H:prepareSkillAttackCustom(mode,target,x,y,adjTime,syncMsg)  


	-- if (mode==2 ) then 
	-- 	--print("prepareHit 飞飞飞........ x y tox toy distance ",self.posX,toX,self.posY,toY,skill.atkDis/self.world.setting.AdjustAttRange)
	-- 	local skill = self.attribute.skills[2] 
	-- 	local parameters = skill.parameters 
	-- 	local obj = self.world.allItemList[target] 

	-- 	if obj~=nil then
	-- 		local d = self:distance(obj.posX,obj.posY)
	-- 		if d>self.attribute.width then
	-- 			d = d - self.attribute.width
	-- 		end
	-- 		local toX,toY = self.world.map:getXYLength(self.posX,self.posY,obj.posX,obj.posY,d)
	-- 		local ret
	-- 		ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX,self.posY+toY) 
	-- 		self:D("prepareHit 飞飞飞........ x tox y toy distance ",self.posX,toX,self.posY,toY,(d/parameters.PETJUMPTIME)*self.world.setting.AdjustAttRange)
	-- 		self:moveTo(toX,toY,false,6,(d/parameters.PETJUMPTIME)*self.world.setting.AdjustAttRange,parameters.STARTJUMP) 

	-- 		syncMsg['a']['x'] = toX
	-- 		syncMsg['a']['y'] = toY

	-- 		-- local hitValueNew = self:getPrepareHithitValue()
	-- 		-- hitValueNew['ADADJ'] = parameters.ADADJ2
	-- 		-- hitValueNew['DIZZY_RATE'] = 100
	-- 		-- hitValueNew['BUFFTIME'] = 2
	-- 		-- hitValueNew['INEVITABLEHIT']=1
	-- 		-- self:directFightAuratoDalay(mode,obj.itemID,hitValueNew,{posX=obj.posX,posY=obj.posY,RANGE=skill.atkDis},skill.hitTime+parameters.PETJUMPTIME)

	-- 		--HURTLIFE
	-- 		--HURTITNTERVAL
	-- 		-- local lifeTime= 0.4
	-- 		-- --local lifeTime=2 + skill.hitTime + parameters.PETJUMPTIME 		
	-- 		-- local attributes = {}
	-- 		-- attributes['buffParameter']={}
	-- 		-- attributes['BUFFONLY']=1
	-- 		-- attributes['buffParameter'] = self:getPrepareHithitValue()
	-- 		-- attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
	-- 		-- attributes['buffParameter']['buffType'] = 1
	-- 		-- attributes['buffParameter']['FIXHURT'] = 87
	-- 		-- attributes['buffParameter']['buffIntervalTime'] = 0.3
	-- 		-- --attributes['buffParameter']['buffIntervalTime'] = 0.5
	-- 		-- attributes['buffParameter']['buffChangeHurtMode'] = mode
	-- 		-- attributes['buffParameter']['buffTargetPosX'] = obj.posX
	-- 		-- attributes['buffParameter']['buffTargetPosY'] = obj.posY
	-- 		-- --attributes['buffParameter']['ANGLE'] = nil
	-- 		-- attributes['buffParameter']['DEGREE'] = skill.degree
	-- 		-- attributes['buffParameter']['INEVITABLEHIT'] = 1
	-- 		-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,lifeTime,{99},0,self.itemID,self.itemID,parameters.STARTJUMP+parameters.PETJUMPTIME)
	-- 		-- buff.debug = true
	-- 		-- self:addBuff(buff)
	-- 		-- self:D("铁尾狼跳跃:",self.world:getAngle(toX,toY,obj.posX,obj.posY),attributes['buffParameter']['DEGREE'],skill.atkDis)

	-- 	end
	-- end
	if mode==3 then
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 
		self:moveTo(self.mode2X,self.mode2Y,false,6,(self.mode2D/parameters.PETJUMPTIME)*self.world.setting.AdjustAttRange) 
	end
	SBoss2H.super.prepareSkillAttackCustom(self,mode,target,x,y,adjTime,syncMsg)  
end 


--- 這個function 會在 執行前搖時call 當skill.delayCalTime>0
-- @param skill skillobj - skillobj
function SBoss2H:prepareSkillAttackDelayInit(skill)
	local hitValueBoth = SBoss2H.super.prepareSkillAttackDelayInit(self,skill)
	local mode=skill.rank
	--INEVITABLEHIT=1;PETJUMPTIME=0.6;STARTJUMP=2;MOVECUT=300;DIZZY_RATE=100;BUFFTIME=1.2;PREADDSELFSTATUSA=83;PREADDSELFSTATUSTIMEA=2;SADDSELFSTATUSA=4999;SADDSELFSTATUSTIMEA=2
	if (mode==3 ) then 
		--print("prepareHit 飞飞飞........ x y tox toy distance ",self.posX,toX,self.posY,toY,skill.atkDis/self.world.setting.AdjustAttRange)
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 
		-- local obj = self.world.allItemList[target] 

		--if obj~=nil then
			local d = self:distance(self.lastBulletPositionX,self.lastBulletPositionY)
			if d>parameters.MOVECUT/self.world.setting.AdjustAttRange then
				d = d-parameters.MOVECUT/self.world.setting.AdjustAttRange
			else
				d = 0
			end
			local toX,toY = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,d)
			local ret
			ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX,self.posY+toY) 
			self.world:D("prepareHit 飞飞飞........ x tox y toy distance ",self.posX,toX,self.posY,toY,(d/parameters.PETJUMPTIME)*self.world.setting.AdjustAttRange)
			self.mode2X = toX
			self.mode2Y = toY
			self.mode2D = d
			-- self.syncMsg['a'][#self.syncMsg['a']]['x'] = toX
			-- self.syncMsg['a'][#self.syncMsg['a']]['y'] = toY
			self.syncMsg['a'][#self.syncMsg['a']]['x'] = self.lastBulletPositionX
			self.syncMsg['a'][#self.syncMsg['a']]['y'] = self.lastBulletPositionY
			-- syncMsg['a']['x'] = toX
			-- syncMsg['a']['y'] = toY

		--end
	end
end


return SBoss2H 
