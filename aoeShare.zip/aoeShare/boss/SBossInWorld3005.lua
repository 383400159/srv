local SBossInWorld3005 = class("SBossInWorld3005", require("gameroomcore.SHeroBase"))

function SBossInWorld3005:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld3005.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld3005
