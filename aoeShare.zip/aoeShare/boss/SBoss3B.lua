local SBoss3B = class("SBoss3B", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss3B:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss3B" 
	end 
	self.creatureList = {}
	--boss阶段
	self.bossType = 1

	--圣甲虫列表 一次生成
	self.mode4list = {}
	--圣甲虫列表释放的次数
	self.mode4num = 0

	--圣甲虫列表 一次生成
	self.mode9list = {}
	--圣甲虫列表释放的次数
	self.mode9num = 0

	--记录3号技能子弹id
	self.mode3bulletID = 0
	self.mode3bulletB = true

	--记录11号技能开始&结束时间
	self.mode11StartTime = 0
	self.mode11EndTime = 0
	self.mode11idx = 0
	self.mode11num = 0
	self.mode11ok = false

	SBoss3B.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		----debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end		
end 

--boss免控
function SBoss3B:addIMMUNECONTROLBUFF()
	--IMMUNECONTROL_RATE=100

	--debuglog("addIMMUNECONTROLBUFF boss itemID:"..self.itemID)
	-- --debuglog("boss allItemList:"..self.world.cjson.encode(self.world.allItemList[self.itemID]))
	self:callCreateInit()
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss3B:prepareHit(mode,adjTime,buff)  

	if mode==10 or mode==24 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local attributes = table.deepcopy(self:getPrepareHithitValue())
		attributes['NOINVICINBLE_RATE'] = 100
		attributes['BUFFTIME'] = parameters.BUFFTIME 
		self:directHurtToDalay(mode,self.itemID,attributes,0)
	end

	local hitValueBoth=SBoss3B.super.prepareHit(self,mode,adjTime,buff) 

	-- if mode==3  then
	-- 	self:D("这是3号技能")
	-- 	local skill = self.attribute.skills[3] 
	-- 	local parameters = skill.parameters 
	-- 	self:addStatusList({s=parameters.ADDSTATUS2,r=self.world.gameTime,t=parameters.ADDSTATUSTIME2,i=self.itemID})
	
	-- 	for k,v in pairs(self.world.allItemList) do
	-- 		if not v:isDead() and v.subName=="worm"  then
	-- 			--debuglog("转场清除场上的小怪.....itemID:"..v.itemID)
	-- 			v.attribute.HP=0
	-- 			v:addStatusList({s=42,r=self.world.gameTime,t=16,i=v.itemID},0.2)
	-- 		end  
	-- 	end
	-- 	hitValueBoth['bulletDirtyCallback'] = true
	-- 	self.mode3bulletB = true
	-- end
	
	-- if mode==15 then
	-- 	self:D("这是15号技能")
	-- 	local skill = self.attribute.skills[15] 
	-- 	local parameters = skill.parameters 
	
	-- 	for k,v in pairs(self.world.allItemList) do
	-- 		if not v:isDead() and v.subName=="worm"  then
	-- 			--debuglog("转场清除场上的小怪.....itemID:"..v.itemID)
	-- 			v.attribute.HP=0
	-- 			v:addStatusList({s=42,r=self.world.gameTime,t=16,i=v.itemID},0.2)
	-- 		end  
	-- 	end
	-- 	hitValueBoth['bulletDirtyCallback'] = true
	-- 	self.mode3bulletB = true
	-- end

	

	if mode==4 then
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		self.mode4num = self.mode4num + 1
		if self.mode4num>6 then
			self.mode4list = {}
			self.mode4num = 1 
		end
		--初始化
		local t1={1,1,1,1,1,0}
		t1=table.shuffle(t1)
		if #self.mode4list<1 then
			for i=1,30 do
				self.mode4list[i]=0
			end
			for i=1,6 do
				if t1[i]>0 then
					for k=1,t1[i] do
						self.mode4list[k+(i-1)*5]=1
					end
				end
			end

		end 
		
		local randlist = self.world.formula:formationPoint(6,parameters.R,false,true)
		--debuglog("甲虫召唤 mode4list :"..self.world.cjson.encode(self.mode4list).." randlist:"..self.world.cjson.encode(randlist))
		for i=(self.mode4num-1)*5+1,(self.mode4num-1)*5+5 do
			if self.mode4list[i]>0 then
				--debuglog("甲虫召唤 金甲虫卵")
				creatureID=self.world:addCreature(self.world.tostring(266),self.teamOrig,parameters.POSX+randlist[i-(self.mode4num-1)*5][1],parameters.POSY+randlist[i-(self.mode4num-1)*5][2],self,1,0)
			else
				--debuglog("甲虫召唤 黑甲虫卵")
				creatureID=self.world:addCreature(self.world.tostring(270),self.teamOrig,parameters.POSX+randlist[i-(self.mode4num-1)*5][1],parameters.POSY+randlist[i-(self.mode4num-1)*5][2],self,1,0)
			end	
			self.creatureList[#self.creatureList+1]=creatureID  
			local Cobj  = self.world.allItemList[creatureID]
			Cobj:setSubName("worm")
		end	

	end


	if mode==9 then
		local skill = self.attribute.skills[9] 
		local parameters = skill.parameters 
		self.mode9num = self.mode9num + 1
		if self.mode9num>6 then
			self.mode9list = {}
			self.mode9num = 1 
		end
		local tr = self.world.formula:getRandnum(1,3)
		--初始化
		local t1={{2,2,1,0,0,0},{3,2,0,0,0,0},{3,1,1,0,0,0}}
		t1=table.shuffle(t1[tr])
		if #self.mode9list<1 then
			for i=1,30 do
				self.mode9list[i]=0
			end
			for i=1,6 do
				if t1[i]>0 then
					for k=1,t1[i] do
						self.mode9list[k+(i-1)*5]=1
					end
				end
			end

		end 
		--debuglog("甲虫召唤 mode9list :"..self.world.cjson.encode(self.mode9list))

		
		local randlist = self.world.formula:formationPoint(30,parameters.R,false,true)
		if self.mode9list[(self.mode9num-1)*5+1]>0 then
			--debuglog("甲虫召唤 金甲虫卵")
			creatureID=self.world:addCreature(self.world.tostring(266),self.teamOrig,parameters.POSX+randlist[1][1],parameters.POSY+randlist[1][2],self,1,0)
		else
			--debuglog("甲虫召唤 黑甲虫卵")
			creatureID=self.world:addCreature(self.world.tostring(270),self.teamOrig,parameters.POSX+randlist[1][1],parameters.POSY+randlist[1][2],self,1,0)
		end	
		self.creatureList[#self.creatureList+1]=creatureID  
		local Cobj  = self.world.allItemList[creatureID]
		Cobj:setSubName("worm")

		if self.mode9list[(self.mode9num-1)*5+2]>0 then
			--debuglog("甲虫召唤 金甲虫卵")
			creatureID=self.world:addCreature(self.world.tostring(266),self.teamOrig,parameters.POSX+randlist[1][1]+0.8,parameters.POSY+randlist[1][2],self,1,0)
		else
			--debuglog("甲虫召唤 黑甲虫卵")
			creatureID=self.world:addCreature(self.world.tostring(270),self.teamOrig,parameters.POSX+randlist[1][1]+0.8,parameters.POSY+randlist[1][2],self,1,0)
		end	
		self.creatureList[#self.creatureList+1]=creatureID  
		local Cobj  = self.world.allItemList[creatureID]
		Cobj:setSubName("worm")


		local rand1 =  self.world.formula:getRandnum(1,2)
		if self.mode9list[(self.mode9num-1)*5+3]>0 then
			--debuglog("甲虫召唤 金甲虫卵")
			creatureID=self.world:addCreature(self.world.tostring(266),self.teamOrig,parameters.POSX+randlist[rand1][1],parameters.POSY+randlist[rand1][2],self,1,0)
		else
			--debuglog("甲虫召唤 黑甲虫卵")
			creatureID=self.world:addCreature(self.world.tostring(270),self.teamOrig,parameters.POSX+randlist[rand1][1],parameters.POSY+randlist[rand1][2],self,1,0)
		end	
		self.creatureList[#self.creatureList+1]=creatureID  
		local Cobj  = self.world.allItemList[creatureID]
		Cobj:setSubName("worm")

		local rand1 =  self.world.formula:getRandnum(2,3)
		if self.mode9list[(self.mode9num-1)*5+4]>0 then
			--debuglog("甲虫召唤 金甲虫卵")
			creatureID=self.world:addCreature(self.world.tostring(266),self.teamOrig,parameters.POSX+randlist[rand1][1]+0.8,parameters.POSY+randlist[rand1][2],self,1,0)
		else
			--debuglog("甲虫召唤 黑甲虫卵")
			creatureID=self.world:addCreature(self.world.tostring(270),self.teamOrig,parameters.POSX+randlist[rand1][1]+0.8,parameters.POSY+randlist[rand1][2],self,1,0)
		end	
		self.creatureList[#self.creatureList+1]=creatureID  
		local Cobj  = self.world.allItemList[creatureID]
		Cobj:setSubName("worm")

		local rand1 =  self.world.formula:getRandnum(3,4)
		if self.mode9list[(self.mode9num-1)*5+5]>0 then
			--debuglog("甲虫召唤 金甲虫卵")
			creatureID=self.world:addCreature(self.world.tostring(266),self.teamOrig,parameters.POSX+randlist[rand1][1],parameters.POSY+randlist[rand1][2],self,1,0)
		else
			--debuglog("甲虫召唤 黑甲虫卵")
			creatureID=self.world:addCreature(self.world.tostring(270),self.teamOrig,parameters.POSX+randlist[rand1][1],parameters.POSY+randlist[rand1][2],self,1,0)
		end	
		self.creatureList[#self.creatureList+1]=creatureID  
		local Cobj  = self.world.allItemList[creatureID]
		Cobj:setSubName("worm")


	end

	if mode==1 then
		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters 
		self:addStatusList({s=parameters.ADDSTATUS2,r=self.world.gameTime,t=parameters.ADDSTATUSTIME2,i=self.itemID})
	end

	if mode==10 or mode==24 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		-- self.world:D('jaylog SBoss3B mode10 ',parameters.ADDSELFSTATUS2,parameters.ADDSELFSTATUSTIME2)
		self:addStatusList({s=parameters.ADDSELFSTATUS2,r=self.world.gameTime,t=parameters.ADDSELFSTATUSTIME2,i=self.itemID})
		-- 增加‘取消BOSS碰撞’状态
		self:addStatusList({s=105,r=self.world:getGameTime(),t=9999,i=self.itemID})
	end

	if mode==11 or mode==20 then
		local skill = self.attribute.skills[mode]
		local parameters = skill.parameters
		--CLEANSELFSTATUS99=76;CLEANSELFSTATUS1=4096;BACKWARD=750;BACKWARDSPEED2=2000;MOVESPEED=300;CHANTSHOW=1;SADDSELFSTATUSA=83;SADDSELFSTATUSTIMEA=5;MOVEINTERVAL=0.5;HURTDELAY=0.6
		local LIFETIME = parameters.SADDSELFSTATUSTIMEA + parameters.HURTDELAY
		self.mode11StartTime = self.world.gameTime
		self.mode11EndTime = self.world.gameTime + LIFETIME
		self.mode11idx = 0
		self.mode11num = self.world.mFloor(LIFETIME/parameters.MOVEINTERVAL)+1
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['buffParameter'] = {}
		attributes['buffParameter']['buffIntervalTime'] = parameters.MOVEINTERVAL
		local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,LIFETIME,{mode},0,self.itemID,self.itemID,skill.hitTime) 
 		self:addBuff(buffObj)
 		--99状态结束时会将p1的statusID删除
 		self:addStatusList({s=99,r=self.world.gameTime,t=LIFETIME,i=self.itemID,p1=parameters.CLEANSELFSTATUS99})
 		-- 加无敌
	 	self:addStatusList({s=76,r=self.world.gameTime,t=LIFETIME,i=self.itemID})
	 	-- 加无法被锁定
	 	self:addStatusList({s=101,r=self.world.gameTime,t=LIFETIME,i=self.itemID})
 	-- 	local attributes2 = {}
		-- attributes2['INVICINBLE_RATE'] = 100
		-- local buffObj2 = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes2,LIFETIME-parameters.MOVEINTERVAL,{},0,self.itemID,self.itemID,0)
		-- self:addBuff(buffObj2)
		-- self:D('jaylog SBoss3B mode',mode,self.world.gameTime,self.mode11StartTime,self.mode11EndTime,parameters.MOVEINTERVAL,self.mode11num)
		return nil
	end

	if mode==111 or mode==120 then
		local skill = self.attribute.skills[mode-100]
		local parameters = skill.parameters
		self.mode11idx = self.mode11idx + 1

		local obj = self.world.allItemList[self.lastBulletTarget]
		if self.mode11idx<self.mode11num and self.buffList[self:__skillID2buffID(skill.skillID,0)].isRemove==1 then
			self.world:D('jaylog SBoss3B mode11idx less mode11num but end',self.mode11idx,self.mode11num,self:__skillID2buffID(skill.skillID,0),self.buffList[self:__skillID2buffID(skill.skillID,0)].isRemove,self.world.gameTime,self.mode11StartTime)
		end
		if self.world.gameTime>=self.mode11StartTime and self.mode11idx<(self.mode11num-1) then
			if obj~=nil then
				local distance = self.world.map:distance(obj.posX,obj.posY,self.posX,self.posY)
				-- self.world:D('jaylog SBoss3B mode111 1 moveTo ',obj.posX,obj.posY,'--',self.posX,self.posY,'--',self.world.gameTime)
				if distance>0.5 then
					local ret,toX,toY = self.world.map:findNearestIdlePoint(obj.posX,obj.posY,self.posX,self.posY,0.5)
					if not ret then
						toX = obj.posX
						toY = obj.posY
					end
					self:setOutOfCtlAllTime(0)
					self:moveTo(toX,toY,true,6)--,parameters.MOVESPEED
					--self:D("甲虫潜地:",self.outOfCtlAllTime,self.world:getGameTime(),self.world.cjson.encode(self.paths),self.posX,self.posY,toX,toY)
				end
				for k,v in pairs(self.syncMsg['s']) do
					if v['s']==parameters.SADDSELFSTATUSA then
						self.syncMsg['s'][k] = nil
					end
				end
				self.world:D('jaylog SBoss3B moveTo mode',mode,obj.posX,obj.posY,'--',self.posX,self.posY,'--',toX,toY,self.world.gameTime,self.mode11idx,self.mode11num,self:__skillID2buffID(skill.skillID,0),self.buffList[self:__skillID2buffID(skill.skillID,0)].isRemove)
			end
			return nil
		end

		if self.mode11idx==(self.mode11num-1) or (self.mode11idx<self.mode11num and self.buffList[self:__skillID2buffID(skill.skillID,0)].isRemove==1)  then
			hitValueBoth = nil
			self:setOutOfCtlAllTime(0)
			self:moveTo(self.posX,self.posY,true,6)
			self:removeStatusList(parameters.SADDSELFSTATUSA)
			-- self.world:D('jaylog SBoss3B syncMsg',self.world.gameTime)
			local syncMsg = {a={{x=self.posX,y=self.posY,sx=self.posX,sy=self.posY,ht=0,ti=0,m=(mode-100),i=self.itemID}}}
			self:updateSyncMsg(syncMsg)
			self.world:D('jaylog SBoss3B syncMsg end',self.world.cjson.encode(self.syncMsg))
			if self.buffList[self:__skillID2buffID(skill.skillID,0)].isRemove==1 then
				-- 删除‘取消BOSS碰撞’状态
				self:removeStatusList(105)
				self:removeBUff("MSPD",true)
				self:setCoolDownTime(self.world:getGameTime()+parameters.CUTTIMEA)
			end
			if self.mode11idx==(self.mode11num-1) then
				return nil
			end
		end
		if self.mode11idx==self.mode11num or self.buffList[self:__skillID2buffID(skill.skillID,0)].isRemove==1 then
			self:removeStatusList(parameters.SADDSELFSTATUSA)
			-- 删除‘取消BOSS碰撞’状态
			self:removeStatusList(105)
			self:removeBUff("MSPD",true)
			self:setCoolDownTime(self.world:getGameTime()+parameters.CUTTIMEA)
		end
		self:D('jaylog SBoss3B end mode',mode,self.world.gameTime)
		mode = mode-100
	end

	return hitValueBoth 
end 

--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss3B:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	local ret = SBoss3B.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	-- if mode==11 then
	-- 	--弹飞所有的目标....BACKWARD=800;BACKWARDSPEED=3000
	-- 	local obj = self.world.allItemList[itemID] 
	-- 	local skill = self.attribute.skills[11] 
	-- 	local parameters = skill.parameters 

	-- 	--弹飞园半径
	-- 	local r = parameters.BACKWARD/self.world.setting.AdjustAttRange
	-- 	--圆心
	-- 	local x = self.posX
	-- 	local y = self.posY
	-- 	--目标坐标
	-- 	local tx = obj.posX
	-- 	local ty = obj.posY
	-- 	--目标和圆心的距离
	-- 	local r1 =self.world.mPow(self.world.mPow(obj.posX-self.posX,2) + self.world.mPow(obj.posY-self.posY,2),0.5)

	-- 	--目标偏移位置
	-- 	local toX = (tx-x)*r/r1+x
	-- 	local toY = (ty-y)*r/r1+y

	-- 	ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,toX,toY) 
	-- 	--目标到偏移位置的距离
	-- 	local d =self.world.mPow(self.world.mPow(obj.posX-toX,2) + self.world.mPow(obj.posY-toY,2),0.5)
	-- 	local bulletSpeed = parameters.BACKWARDSPEED2
	-- 	obj:moveTo(toX,toY,true,5,bulletSpeed,0)
	-- end

	if mode==11 or mode==20 then
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 

		if self.world.gameTime>=self.mode11StartTime and self.mode11idx<(self.mode11num-1) and self.buffList[self:__skillID2buffID(skill.skillID,0)].isRemove~=1 then
			return nil
		end

		if self.mode11idx==self.mode11num or self.buffList[self:__skillID2buffID(skill.skillID,0)].isRemove==1 then
			--弹飞园半径
			local r = parameters.BACKWARD/self.world.setting.AdjustAttRange
			--圆心
			local x = self.posX
			local y = self.posY
			--目标坐标
			local tx = obj.posX
			local ty = obj.posY
			--目标和圆心的距离
			local r1 =self.world.mPow(self.world.mPow(obj.posX-self.posX,2) + self.world.mPow(obj.posY-self.posY,2),0.5)

			--目标偏移位置
			local toX = (tx-x)*r/r1+x
			local toY = (ty-y)*r/r1+y

			ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,toX,toY) 
			--目标到偏移位置的距离
			local d =self.world.mPow(self.world.mPow(obj.posX-toX,2) + self.world.mPow(obj.posY-toY,2),0.5)
			local bulletSpeed = parameters.BACKWARDSPEED2
			obj:moveTo(toX,toY,true,5,bulletSpeed,0)

			self:removeBUff("MSPD",true)
		end
	end

	return ret 
end 


--- 准备攻击前置设置，在prepareHit之后执行，call父类
-- @param mode int - 技能1-7
-- @param itemID int - 目标对象itemID
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SBoss3B:prepareSkillAttackCustom(mode,itemID,x,y,adjTime,syncMsg)  

	SBoss3B.super.prepareSkillAttackCustom(self,mode,itemID,x,y,adjTime,syncMsg)

	-- if mode==3 or mode==15 then
	-- 	self.mode3bulletID = self.lastBulletID
	-- end

	if mode==11 or mode==20 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		if self.world.gameTime>=self.mode11StartTime and self.mode11idx<self.mode11num and self.buffList[self:__skillID2buffID(skill.skillID,0)].isRemove==1 then
			return nil
		end
		if self.world.gameTime>=self.mode11StartTime and self.mode11idx~=(self.mode11num-1) then
			self:D('jaylog SBoss3B remove a ',self.world.gameTime)
			syncMsg['a'] = nil
		end
	end

	if mode==111 or mode==120 then
		local skill = self.attribute.skills[mode-100] 
		local parameters = skill.parameters 
		if self.world.gameTime>=self.mode11StartTime and self.mode11idx<self.mode11num and self.buffList[self:__skillID2buffID(skill.skillID,0)].isRemove==1 then
			return nil
		end
		if self.world.gameTime>=self.mode11StartTime and self.mode11idx~=(self.mode11num-1) then
			self:D('jaylog SBoss3B remove a100 ',self.world.gameTime)
			syncMsg['a'] = nil
		end
	end

end 

--- 子彈擊中callback
-- @param bulletID int - 子彈ID
-- @param adjTime float - 調整時間
-- @return null
-- function SBoss3B:dirtyBullet(bulletID,adjTime)

-- 	if bulletID==self.mode3bulletID and self.mode3bulletB  then
-- 		local skill = self.attribute.skills[self.world.bulletList[bulletID].mode] 
-- 		local parameters = skill.parameters 

-- 		self.mode3bulletB = false	
-- 		local arrow = self.world.bulletList[bulletID].attr.arrow 
-- 		--debuglog("虫群回调 list :"..self.world.cjson.encode(arrow))
-- 		local data = {}
-- 		for k,v in pairs(arrow) do
-- 			-- local obj  = self.world.allItemList[v.itemID]
-- 			-- local d =self.world.mPow(self.world.mPow(obj.posX-self.posX,2) + self.world.mPow(obj.posY-self.posY,2),0.5)
-- 			data[#data+1]=v.itemID..","..self.world.mCeil((v.time-self.world.gameTime)*1000)

-- 			local attributes = table.deepcopy(self:getPrepareHithitValue())
-- 			attributes['APADJ'] = parameters.APADJ2
-- 			self:directHurtToDalay(self.world.bulletList[bulletID].mode,v.itemID,attributes,(v.time-self.world.gameTime))
-- 		end

-- 		local atkStr= implode(";",data)	
-- 		local syncMsg = {a={{x=self.lastBulletPositionX,y=self.lastBulletPositionY,sx=self.posX,sy=self.posY,ht=skill.hitTime,ti=self.itemID,m=self.world.bulletList[bulletID].mode,i=self.itemID,p=''}}}
-- 		syncMsg['a'][#syncMsg['a']]['p'] = atkStr
-- 		debuglog("虫群回调 atkStr:"..atkStr.." syncMsg:"..self.world.cjson.encode(syncMsg))
-- 		self:updateSyncMsg(syncMsg)
-- 		self:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID}) 
-- 	end

-- end



return SBoss3B 