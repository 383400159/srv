local SBossInWorld3017 = class("SBossInWorld3017", require("gameroomcore.SHeroBase"))

function SBossInWorld3017:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld3017.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld3017
