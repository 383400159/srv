local SBossInWorld1004 = class("SBossInWorld1004", require("gameroomcore.SHeroBase"))

function SBossInWorld1004:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld1004.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.nextAtkTime = 0
	self.oldItemID = 0
end

---自动攻击..........
--返回true代表执行world的AI false执行AI
function SBossInWorld1004:_autoFight()
	--self:D("保卫雅典娜 _autoFight ")
	self:D("SBossInWorld1004:_autoFight()")
	if self.team=="" and self.world:getGameTime()>self.nextAtkTime then
		
		local atkItemID = self.world.baseID

		-- if self.lastHurtItemID>0  then
		-- 	local obj = self.world.allItemList[self.lastHurtItemID]
		-- 	local lastTime = 10
		-- 	if not obj:isDead() and (self.lastHurtTime+lastTime)>self.world:getGameTime() then
		-- 		atkItemID =self.lastHurtItemID
		-- 		if atkItemID~=self.oldItemID then
		-- 			self.prepareSkillAttackNum = 0
		-- 		end

		-- 		self.oldItemID = atkItemID
		-- 		self.autoFightAI.runAI=true
		-- 		self:D("SBossInWorld1004:_autoFight(1)")
		-- 		--用回bossAI
		-- 		return false
		-- 	end
		-- end
		if #self.BossHatredlist>0  then

			local obj = self.world.allItemList[self.BossHatredlist[#self.BossHatredlist]['itemID']]
			if  obj.statusList[4007]==nil then
				atkItemID =self.BossHatredlist[#self.BossHatredlist]['itemID']
				if atkItemID~=self.oldItemID then
					self.prepareSkillAttackNum = 0
				end

				self.oldItemID = atkItemID
				self.autoFightAI.runAI=true
				self:D("SBossInWorld1004:_autoFight(1)")
				--用回bossAI
				return false

			end
		end
		
		if atkItemID~=self.oldItemID then
			self.prepareSkillAttackNum = 0
		end
		self:skillAttack(1,atkItemID)
		--self:D("保卫雅典娜 ",atkItemID,self.itemID)
		self.nextAtkTime = self.world:getGameTime()+1
		self.oldItemID = atkItemID
		return true
	end
	if self.team~="" then
		return false
	end
	return true
end


--- 自动移动chud
-- @return null
function SBossInWorld1004:_autoMove()

	return false
end

return SBossInWorld1004