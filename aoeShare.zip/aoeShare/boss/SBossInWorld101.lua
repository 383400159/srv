local SBossInWorld101 = class("SBossInWorld101", require("gameroomcore.SHeroBase"))

function SBossInWorld101:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld101.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end



return SBossInWorld101