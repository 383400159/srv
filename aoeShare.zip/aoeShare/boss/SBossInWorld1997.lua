local SBossInWorld1997 = class("SBossInWorld1997", require("gameroomcore.SHeroBase"))

function SBossInWorld1997:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld1997.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld1997
