local SBossInWorld3 = class("SBossInWorld3", require("gameroomcore.SHeroBase"))

function SBossInWorld3:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld3.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	--屏蔽巡逻
	self.autoFightAI.noAutoPatrol = true
end


return SBossInWorld3