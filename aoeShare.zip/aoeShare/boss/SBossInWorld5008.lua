local SBossInWorld5008 = class("SBossInWorld5008", require("gameroomcore.SHeroBase"))

function SBossInWorld5008:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld5008.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld5008