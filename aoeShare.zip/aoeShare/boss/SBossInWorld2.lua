local SBossInWorld2 = class("SBossInWorld2", require("gameroomcore.SHeroBase"))

function SBossInWorld2:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld2.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end



return SBossInWorld2