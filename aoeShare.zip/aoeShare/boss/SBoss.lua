
local SBoss
if worldForHero==0 then
	SBoss = class("SBoss", require("gameroomcore.SHeroBase"))
else
	SBoss = class("SBoss", require("gameroom.boss.SBossInWorld"..worldForHero))
end

--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	--print("进来没！！！！！！！！！！！！！！")	


	if loginID==nil then loginID = "" end
	if skinNum==nil then skinNum = 0 end


	self.paths={}						--AI行进路线
	self.attackTarget=nil 	--攻击目标
	self.attribute={}				--英雄属性设置
	self.actorType=0 				--角色类型
	self.posX=12 						--位置X坐标
	self.posY=140 					--位置Y坐标
	self.lastPosX=0 				--上次位置X坐标
	self.lastPosY=0 				--上次位置Y坐标
	self.team =nil 					--队伍
	self.teamOrig = nil 		--原来队伍
	self.world =nil 				--world Obj
	self.parent=nil 				--父类

	self.deadTime=0 							--死亡时间
	self.deadFlag=0 							--死亡状态
	self.dirty=0

	self.debug=false

	self.status=0 -- 0=idle , 1=walk , 2=standby , 3=fight , 4=blockwait , 5=special , 6=dizzy , 7=freeze
	self.statusList={}

	self.syncMsg={}
	self.lastBulletID=0
	self.buffList={}



	self.isVisible=0 -- 1=yes 2=no -1=hidden 0=undeclared
	self.lastIsVisible=0 -- 1=yes 2=no -1=hidden 0=undeclared
	self.isGrass=0 -- 1=yes 2=no 0=undeclared
	self.lastAttackID=0  -- last attack id

	self.lastAttackTime=0 -- keep 3 second

	self.lastTowerPosition=nil
	self.lastTowerID=0

	self.visibleList={}

	self.skeleton=0

	--self.lastStandByAttackTime=0 -- for skill stand by attack = 1

	-- self.initX=0 -- initial positionX
	-- self.initY=0 -- initial positionY
	self.prepareSkillAttackNum=0 -- wait for skill attack, skill order (mode 1-4)
	self.lastBulletPositionX=0 -- skill attack , start from position X 
	self.lastBulletPositionY=0 -- skill attack , start from position Y
	self.lastBulletTarget=0 -- skill attack , start from position Y
	

	self.lastHeroAttack=0 -- last attacked by enemy Hero

	--self.loginID=""

	self.playerObj=nil
	self.playerJson=nil
	self.playerHeroesObj=nil
	self.playerHeroesJson=nil

	self.heroAttack={} -- record the time of last attacked by enemy Hero
	self.bonus={}
	self.bonusType={}

	self.skinNum=skinNum

	self.isSurrender=nil
	self.surrenderOrder=0

	self.lastControlTime=0
	self.lastOfflineTime=0
	self.totalIdleTime=0
	self.maxIdleTime=0

	--self.lastWalkTime =0 
	--self.lastFightTime=0   
	--self.lastSPFightTime=0  
	--self.lastCoolDownTime=0 
	--self.outOfCtlTime=0 
	--self.outOfCtlAllTime=0  

	self.openprint=0	

	--mode1相关参数
	self.mode1order = 1
	self.mode1atktime = 0
	self.mode1type = 0

	--self.pvePower=0
	self.starList={}

	--self.isAuto=false
	self.autoBlocked=false
	--第一次进游戏
	self.beginGame = true

	--boss被嘲讽的仇恨列表
	self.BossHatredlist = {}
	self.oldHatredID = 0

	self.clientInitLoopNum = 0 			--clientInit start=2时的循环次数
	self.clientInitLoopNum3 = 0 		--clientInit start=3时的循环次数
	self.clientInitLoopNum5 = 0 		--clientInit start=5时的循环次数


	if (self.className==nil) then 
		self.className="SBoss" 
	end
 
	self.world = world

	self.skinNum = skinNum

	if loginID~="" then
		self.loginID = loginID
		self.playerJson = {}

	end


	--生命共享id
	--生命共享比例

	SBoss.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

	self.AImode=2

	self.actorType = 2
end 

--- move motion , call every update loop
-- @return null
function SBoss:move() 
	SBoss.super.move(self)

end

--boss免控
function SBoss:addIMMUNECONTROLBUFF()
end

--- init funtion 初始化属性参数
-- @param id int - role id
-- @param posX int - 起始坐标X
-- @param posY int - 起始坐标Y
-- @return null
function SBoss:__init(id,posX,posY)

	self.world:__loadBoss(id)
	self.world:__loadBossSkill(id)
	self.attribute = require("gameroom.attribute.SAttributeBoss").new(id,1,self) --- level 1
	self.initX = posX
	self.initY = posY
	self.prepareSkillAttackNum = 0
	self.lastBulletPositionX = 0
	self.lastBulletPositionY = 0
	self.lastHeroAttack = -1
	self.lastHeroAttackForTower = -1
	-- self.nextREHPMPTime = self.world:getGameTime()

	self:D("itemID:"..self.itemID)
end

--- fight motion,执行攻击动作
-- @param null
-- @return null
function SBoss:fight()

	--清除没用boss嘲讽仇恨列表
	if #self.BossHatredlist>0 then
		for k,v in pairs(self.BossHatredlist) do
			if v['endTime']<self.world:getGameTime() then
				table.remove(self.BossHatredlist,k)
			end
		end
	end
	SBoss.super.fight(self)

end

--- 自动移动chud
-- @return null
function SBoss:_autoMove()
	--body
	-- if self.runMoveAI then
		--self.autoFightAI:autoMove()
	-- end

end
--- 自动释放技能 
-- @return null
function SBoss:_autoFight()
	--print('jaylog boss autoFightAI:',self.autoFightAI.runAI)
	--debuglog("SAI ..... outOfCtlTime:"..self.outOfCtlTime.." gameTime:"..self.world.gameTime.." getGameTime:"..self.world:getGameTime())
	local ret=SBoss.super._autoFight(self)
	--self:D("boss_autoFight",ret,self.AIlastCoolDown,self.lastCoolDownTime,self.autoFightAI.runAI)
	if not ret and self.AIlastCoolDown<self.world:getGameTime() and self.lastCoolDownTime<self.world:getGameTime() and  not self:isDead() and self.autoFightAI.runAI  then
		--self:D("SBossInWorld1004:_autoFight(2)")
		--需要获得自动攻击的item  释放skill的id
		local targetID,skillID,cdTime=self.autoFightAI:execute()
		if targetID>0 then
			self:D("策划SEASON放了什么技能 fenglog checkBOSS roleId:"..self.attribute.roleId.." targetID:"..targetID.." skillID:"..skillID.." cdTime:"..cdTime)
			self:skillAttack(skillID,targetID)
			self.autoFightAI.runMoveAI = false
			self.AIlastATKtoMove = self.world:getGameTime()-0.5
			self.AIlastAutoMove = self.world:getGameTime()
		end
		--boss寻敌cd
		self.AIlastCoolDown = self.world:getGameTime() + cdTime
	end


	if not self:isDead() then
		if self.AIlastATKtoMove+10<self.world:getGameTime() then 
			--self:debuglog("AIlastATKtoMove:"..self.AIlastATKtoMove.." runMoveAI true")
			if	self.attribute.parameterArr['NOMOVEAI']==nil then
				self.autoFightAI.runMoveAI = true
			end
		else
			self.autoFightAI.runMoveAI = false
		end
	end

end

--- 设置技能限制施放时间
-- @param skill table - 角色某一招技能的所有设置值
-- @return null
function SBoss:useCDTime(skill)
	local cooldown = skill.cutTime
	skill.lastCoolDownValue = cooldown

	skill.lastCoolDownTime = self.world:getGameTime() + skill.lastCoolDownValue
	-- debuglog("useCDTime CDTIME:"..skill.parameters.CDTIME )
	self:D("useCDTime lastCoolDownTime:"..skill.lastCoolDownTime )


	if skill.rank==1 and skill.parameters.CDTIME~=nil then
		skill.lastCoolDownValue = skill.parameters.CDTIME
		skill.lastCoolDownTime = self.world:getGameTime() + skill.lastCoolDownValue		
	end

	-- local sk = self.attribute.skills
	-- local gt = self.world:getGameTime()
	-- for i=2,7 do
	-- 	if sk[i] ~=nil then
	-- 		if sk[i].lastCoolDownTime<gt then
	-- 			sk[i].lastCoolDownTime = gt+skill.animationTime
	-- 			--print("增加公共cd..n:",self.attribute.skills[i].lastCoolDownTime)
	-- 		end
	-- 	end
	-- end
end

--- 使用技能伤害，call父类的skillAttack
-- @param mode int - 技能 1-8 rank
-- @param itemID int - 攻擊目標 itemID
-- @param positionX float - 攻擊目標 位置 X
-- @param positionY float - 攻擊目標 位置 Y
-- @param force bool - true ＝ 無視失控, 失控時攻擊目標用
-- @param fromClientSide bool - true ＝ 來自客戶端
-- @return msg table - 返回msg 給client 包括action move skillstatus
function SBoss:skillAttack(mode,itemID,positionX,positionY,force,fromClientSide,nPara,pPara)
	--print("skillAttack........mode :",mode)
	return SBoss.super.skillAttack(self,mode,itemID,positionX,positionY,force,fromClientSide,nPara,pPara)
end

-- --- 复活, 游戏loop
-- -- @param null
-- -- @return null
function SBoss:revive()

end

--{"sk":[ {"s":1 , "l":1 ,"t":1.01 ,"cd":5 },{"s":2 , "l":1 ,"t":1.01 ,"cd":5 } ]}
--- sync skill信息给client端
-- @param delay float - 延迟执行时间
-- @return status table - 格式：{"sk":[ {"s":1 , "l":1 ,"t":1.01 ,"cd":5 },{"s":2 , "l":1 ,"t":1.01 ,"cd":5 } ]}
function SBoss:syncSkill(delay)
	if delay==nil then delay = 0 end
	local status = {sk={i=self.itemID,a={}}}
	local t,cd
	for k,v in pairs(self.attribute.skills) do
		-- print("刷新技能cd lastCoolDownTime:",v.lastCoolDownTime)
		-- print("刷新技能cd getGameTime:",self.world:getGameTime())
		t = v.lastCoolDownTime-self.world:getGameTime()
		--debuglog('jaylog syncSkill parameters:'..self.world.cjson.encode(v.parameters))
		cd = v.parameters.CDTIME
		

		if t<=0 and v.lastCoolDownTime>=0 then
			t = 0.01
			--v.lastCoolDownTime = -1
		elseif t<0 then
			t = 0
		end

		status['sk']['a'][#status['sk']['a']+1] = {d=delay,s=v.rank,t=t,cd=cd}
	end
	self:updateSyncMsg(status)
	return status['sk']['a']
	--return {}
end

--- syn status状态信息给client
-- @param null
-- @return null
function SBoss:syncInfo()
	SBoss.super.syncInfo(self)
	local hatredID = self:getHatredID()
	if hatredID>0 then

		self:D('jaylog change hatredID..'..hatredID)

		self:updateSyncMsg({i={i=self.itemID,ti=hatredID}})
	else
		if self.world.forceUpdate and self.oldHatredID>0 then

			self:D('jaylog player init syn hatredID:'..self.oldHatredID)

			self:updateSyncMsg({i={i=self.itemID,ti=self.oldHatredID}})
		end
	end

end




-- 检查源是否在目标后面
-- x1 int - 源x坐标
-- y1 int - 源y坐标
-- x2 int - 目标x坐标
-- y2 int - 目标y坐标
-- adjust float - 调整值
function SBoss:_checkBehind(x1,y1,x2,y2,adjust) 
	if adjust==nil then adjust=0 end

	if (self.team=="A") then adjust=adjust*-1 end
	if self.world.towerBPos.posY==nil or self.world.towerBPos.posX==nil or self.world.towerAPos.posY==nil or self.world.towerAPos.posX==nil then
		--debuglog('============================================================ found bug '..self.className..self.itemID)
		return true
	end
	local ret=((y1-y2+adjust)*(self.world.towerBPos.posY-self.world.towerAPos.posY)-(self.world.towerAPos.posX-self.world.towerBPos.posX)*(x1-x2))
	----echo "_checkBehind x1,y1,x2,y2 self.team ret : ".(self.team=="A"?ret<0:ret>0)."\n"
	
	return (self.team=="A" and ret<0 or ret>0)

end

-- 暂时无用
function SBoss:getBehindDistance(x,y,d)
	local k = (self.towerAPos.posY-self.towerBPos.posY)/(self.towerAPos.posX-self.towerBPos.posX)
end



--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss:prepareHit(mode,adjTime,buff)  


	local hitValueBoth=SBoss.super.prepareHit(self,mode,adjTime,buff) 



	if hitValueBoth['JZDJ']~=nil and hitValueBoth['JZDJ']>0 then
		self.modeatklist={}
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		self:D("boss释放精准打击........",self.world.cjson.encode(parameters))
		local teamlist = {}
		local visRange = {posX=self.posX,posY=self.posY,radius=(parameters.JZDJDIS/self.world.setting.AdjustAttRange)}
		local dlist = {}
		--TARGETNUMMIN=2;TARGETNUNMAX=5
		local TARGETNUM =  self.world.formula:getRandnum(parameters.TARGETNUMMIN,parameters.TARGETNUNMAX)
		self:D("机器人 TARGETNUM:",TARGETNUM)
		local atknum = TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
					if (d>=0) then 
						dlist[#dlist+1] = obj   
					end
				end
			end
		end
		)

		dlist=table.shuffle(dlist)
		local newDlist = {}
		for i=1,atknum do
			newDlist[#newDlist+1] = dlist[i]
		end

		if #newDlist>0 then
			--debuglog("机器人有目标 dlist:"..#dlist)
			for k,v in pairs(newDlist) do
				local d = self:distance(v.posX,v.posY)
				local FLYTIME = (d*self.world.setting.AdjustAttRange)/skill.bulletSpeed
				local attributes = table.deepcopy(hitValueBoth)
				if parameters.RANGE==nil then
					self:directHurtToDalay(mode,v.itemID,attributes,parameters['HITTIME'..k]+FLYTIME)
				else
					self:directFightAuratoDalay(mode,v.itemID,attributes,{posX=v.posX,posY=v.posY,RANGE=parameters.RANGE},parameters['HITTIME'..k]+FLYTIME) 
				end


				self.modeatklist[#self.modeatklist+1]=v.itemID..","..parameters['HITTIME'..k]..","..FLYTIME
				if parameters.ADDJZDJSTATUS~=nil then
					local obj1 = self.world.allItemList[v.itemID] 
					obj1:addStatusList({s=parameters.ADDJZDJSTATUS,r=self.world:getGameTime(),t=parameters.ADDJZDJSTATUSTIME,i=self.itemID})	
					--self:D("机器人 精准打击 是不是加了:",parameters5.ADDSTATUS2,parameters5.ADDSTATUSTIME2)
				end

			end	
		end

	end

	if hitValueBoth~=nil and hitValueBoth['EMXW']~=nil and hitValueBoth['EMXW']>0   then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		self:D("boss释放噩梦漩涡........",self.world.cjson.encode(parameters))
		local teamlist = {}

		local visRange = {posX=self.posX,posY=self.posY,radius=(parameters.EMXWDIS/self.world.setting.AdjustAttRange)}
		local dlist={}
		local TARGETNUM =  self.world.formula:getRandnum(parameters.TARGETNUMMIN,parameters.TARGETNUNMAX)
		local atknum = TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)

					if (d>=0) then 
						dlist[#dlist+1]={itemID=obj.itemID,DIS=d}  
					end
				end
			end
		end
		)

		dlist=table.shuffle(dlist)
		local newDlist = {}
		for i=1,atknum do
			newDlist[#newDlist+1] = dlist[i]
		end

		--找到目标释放一个群体aoe在目标脚下
		for k,v in pairs(newDlist) do
			local obj  = self.world.allItemList[v.itemID]
			local creatureID=self.world:addCreature(self.world.tostring(parameters.ENEMY),self.teamOrig,obj.posX,obj.posY,self,1,skill.hitTime)

			local obj  = self.world.allItemList[creatureID]
			local lifeTime=parameters.HURTLIFE		
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			attributes['buffParameter'] = hitValueBoth
			attributes['buffParameter']['RANGE'] = parameters.EMXWATKDIS --obj.attribute.width * self.world.setting.AdjustAttRange
			attributes['buffParameter']['buffType'] = 1
			attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
			attributes['buffParameter']['INEVITABLEHIT'] = 1
			if hitValueBoth['EMXWCALLBACK']~=nil then
				attributes['buffParameter']['creatureDirectHurCallBack'] = hitValueBoth['EMXWCALLBACK']
			end 
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,(skill.hitTime+parameters.HURTSTARTTIME))
			obj:addBuff(buff)
			obj:setDeadTime(lifeTime) 
		end
		hitValueBoth = nil
	end

	if hitValueBoth~=nil and hitValueBoth['RANGEEMXW']~=nil and hitValueBoth['RANGEEMXW']>0 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		self:D("jaylog boss释放范围噩梦漩涡........",self.world.cjson.encode(parameters))
		local teamlist = {}

		local visRange = {posX=self.posX,posY=self.posY,radius=(parameters.EMXWDIS/self.world.setting.AdjustAttRange)}
		local dlist={}
		local TARGETNUM =  self.world.formula:getRandnum(parameters.TARGETNUMMIN,parameters.TARGETNUNMAX)
		local atknum = TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)

					if (d>=0) then 
						dlist[#dlist+1]={itemID=obj.itemID,DIS=d}  
					end
				end
			end
		end
		)

		dlist=table.shuffle(dlist)
		local newDlist = {}
		for i=1,atknum do
			newDlist[#newDlist+1] = dlist[i]
		end

		--找到目标释放一个群体aoe在目标脚下
		for k,v in pairs(newDlist) do
			local obj  = self.world.allItemList[v.itemID]
			hitValueBoth['CIRCLE1']['POSX'] = obj.posX
			hitValueBoth['CIRCLE1']['POSY'] = obj.posY
			hitValueBoth['CIRCLE1']['HITTIME'] = skill.hitTime + parameters.HURTSTARTTIME
			hitValueBoth['CIRCLE1']['LIFETIME'] = hitValueBoth['HURTLIFE']
			hitValueBoth['SUMMONCIRCLE'] = hitValueBoth['SUMMONCIRCLEEMXW']
			hitValueBoth['SUMMONPOINT'] = hitValueBoth['SUMMONPOINTEMXW']
			hitValueBoth['SUMMONRING'] = hitValueBoth['SUMMONRINGEMXW']
			self.world:callCreature(hitValueBoth,self)
			if hitValueBoth['autoCreatureIDList']==nil then
				hitValueBoth['autoCreatureIDList'] = {}
			end
			local creatureID=self.world:addCreature(self.world.tostring(parameters.ENEMY),self.teamOrig,obj.posX,obj.posY,self,1,skill.hitTime+parameters.HURTSTARTTIME)
			hitValueBoth['autoCreatureIDList'][#hitValueBoth['autoCreatureIDList']] = creatureID

			local sNum,sDelay = 0,0
			for k1,creatureID in pairs(hitValueBoth['autoCreatureIDList']) do
				sNum = sNum + 1
				if sNum==hitValueBoth['SHOWNUM'] then
					sNum = 0
					sDelay = sDelay + hitValueBoth['SHOWINTERVAL']
				end
				local obj  = self.world.allItemList[creatureID]
				local lifeTime=parameters.HURTLIFE		
				local attributes = {}
				attributes['buffParameter']={}
				attributes['BUFFONLY']=1
				attributes['buffParameter'] = hitValueBoth
				attributes['buffParameter']['RANGE'] = parameters.EMXWATKDIS --obj.attribute.width * self.world.setting.AdjustAttRange
				attributes['buffParameter']['buffType'] = 1
				attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
				attributes['buffParameter']['INEVITABLEHIT'] = 1
				if hitValueBoth['EMXWCALLBACK']~=nil then
					attributes['buffParameter']['creatureDirectHurCallBack'] = hitValueBoth['EMXWCALLBACK']
				end 
				local buff
				if k1==#hitValueBoth['autoCreatureIDList'] then
					buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,(skill.hitTime+parameters.HURTSTARTTIME))
				else
					buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,(skill.hitTime+parameters.HURTSTARTTIME+sDelay))
				end
				obj:addBuff(buff)
				obj:setDeadTime(lifeTime) 
			end
		end
		hitValueBoth = nil
	end

	return hitValueBoth 
end 


--- 這個function 會在 執行前搖時call 當skill.delayCalTime>0
-- @param skill skillobj - skillobj
function SBoss:prepareSkillAttackDelayInit(skill)
	local hitValueBoth = SBoss.super.prepareSkillAttackDelayInit(self,skill)
	local mode=skill.rank

	if hitValueBoth['YJEMXW']~=nil and hitValueBoth['YJEMXW']>0   then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		self:D("boss释放噩梦漩涡........",self.world.cjson.encode(parameters))
		local teamlist = {}

		local visRange = {posX=self.posX,posY=self.posY,radius=(parameters.EMXWDIS/self.world.setting.AdjustAttRange)}
		local dlist={}
		local TARGETNUM =  self.world.formula:getRandnum(parameters.TARGETNUMMIN,parameters.TARGETNUNMAX)
		local atknum = TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)

					if (d>=0) then 
						dlist[#dlist+1]={itemID=obj.itemID,DIS=d}  
					end
				end
			end
		end
		)

		dlist=table.shuffle(dlist)
		local newDlist = {}
		for i=1,atknum do
			newDlist[#newDlist+1] = dlist[i]
		end

		--找到目标释放一个群体aoe在目标脚下
		for k,v in pairs(newDlist) do
			local obj  = self.world.allItemList[v.itemID]
			--加预警时间
			if parameters.YJENEMY~=nil then
				local creatureID = self.world:addCreature(self.world.tostring(parameters.YJENEMY),self.teamOrig,obj.posX,obj.posY,self,1,0)
				local obj  = self.world.allItemList[creatureID]
				obj:setDeadTime(parameters.YJLIFETIME) 
			end	

			local creatureID=self.world:addCreature(self.world.tostring(parameters.ENEMY),self.teamOrig,obj.posX,obj.posY,self,1,skill.hitTime)

			local obj  = self.world.allItemList[creatureID]
			local lifeTime=parameters.HURTLIFE		
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			attributes['buffParameter'] = hitValueBoth
			attributes['buffParameter']['RANGE'] = parameters.EMXWATKDIS --obj.attribute.width * self.world.setting.AdjustAttRange
			attributes['buffParameter']['buffType'] = 1
			attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
			attributes['buffParameter']['INEVITABLEHIT'] = 1
			if hitValueBoth['EMXWCALLBACK']~=nil then
				attributes['buffParameter']['creatureDirectHurCallBack'] = hitValueBoth['EMXWCALLBACK']
			end 
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,(skill.hitTime+parameters.HURTSTARTTIME))
			obj:addBuff(buff)
			obj:setDeadTime(lifeTime) 
		end
		hitValueBoth = nil
	end

	if hitValueBoth~=nil and hitValueBoth['YJRANGEEMXW']~=nil and hitValueBoth['YJRANGEEMXW']>0 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		self:D("jaylog boss释放多个范围噩梦漩涡........",self.world.cjson.encode(parameters))
		local teamlist = {}

		local visRange = {posX=self.posX,posY=self.posY,radius=(parameters.EMXWDIS/self.world.setting.AdjustAttRange)}
		local dlist={}
		local TARGETNUM =  self.world.formula:getRandnum(parameters.TARGETNUMMIN,parameters.TARGETNUNMAX)
		local atknum = TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)

					if (d>=0) then 
						dlist[#dlist+1]={itemID=obj.itemID,DIS=d}  
					end
				end
			end
		end
		)

		dlist=table.shuffle(dlist)
		local newDlist = {}
		for i=1,atknum do
			newDlist[#newDlist+1] = dlist[i]
		end
		self:D('jaylog newDlist:',self.world.cjson.encode(newDlist),TARGETNUM)

		--找到目标释放一个群体aoe在目标脚下
		for k,v in pairs(newDlist) do
			local obj  = self.world.allItemList[v.itemID]
			hitValueBoth['CIRCLE1']['POSX'] = obj.posX
			hitValueBoth['CIRCLE1']['POSY'] = obj.posY
			hitValueBoth['CIRCLE1']['HITTIME'] = skill.hitTime
			hitValueBoth['CIRCLE1']['LIFETIME'] = hitValueBoth['HURTLIFE']
			hitValueBoth['SUMMONCIRCLE'] = hitValueBoth['SUMMONCIRCLEEMXW']
			hitValueBoth['SUMMONPOINT'] = hitValueBoth['SUMMONPOINTEMXW']
			hitValueBoth['SUMMONRING'] = hitValueBoth['SUMMONRINGEMXW']
			-- hitValueBoth['SHOWNUM'] = 0
			self.world:callCreature(hitValueBoth,self)
			if hitValueBoth['autoCreatureIDList']==nil then
				hitValueBoth['autoCreatureIDList'] = {}
			end
			local creatureID=self.world:addCreature(self.world.tostring(parameters.ENEMY),self.teamOrig,obj.posX,obj.posY,self,1,skill.hitTime)
			hitValueBoth['autoCreatureIDList'][#hitValueBoth['autoCreatureIDList']+1] = creatureID

			self:D('jaylog autoCreatureIDList:',self.world.cjson.encode(hitValueBoth['autoCreatureIDList']))
			local sNum,sDelay = 0,0
			for k1,creatureID in pairs(hitValueBoth['autoCreatureIDList']) do
				local obj  = self.world.allItemList[creatureID]
				
				--加预警时间
				sNum = sNum + 1
				if sNum==hitValueBoth['SHOWNUM'] then
					sNum = 0
					sDelay = sDelay + hitValueBoth['SHOWINTERVAL']
				end

				if parameters.YJENEMY~=nil then
					local YJcreatureID
					if k1==#hitValueBoth['autoCreatureIDList'] then
						YJcreatureID = self.world:addCreature(self.world.tostring(parameters.YJENEMY),self.teamOrig,obj.posX,obj.posY,self,1,0)
					else
						YJcreatureID = self.world:addCreature(self.world.tostring(parameters.YJENEMY),self.teamOrig,obj.posX,obj.posY,self,1,sDelay)
					end
					local obj  = self.world.allItemList[YJcreatureID]
					obj:setDeadTime(parameters.YJLIFETIME) 
				end	
				local lifeTime=parameters.HURTLIFE		
				local attributes = {}
				attributes['buffParameter']={}
				attributes['BUFFONLY']=1
				attributes['buffParameter'] = hitValueBoth
				attributes['buffParameter']['RANGE'] = parameters.EMXWATKDIS --obj.attribute.width * self.world.setting.AdjustAttRange
				attributes['buffParameter']['buffType'] = 1
				attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
				attributes['buffParameter']['INEVITABLEHIT'] = 1
				if hitValueBoth['EMXWCALLBACK']~=nil then
					attributes['buffParameter']['creatureDirectHurCallBack'] = hitValueBoth['EMXWCALLBACK']
				end 
				local buff
				if k1==#hitValueBoth['autoCreatureIDList'] then
					buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,(skill.hitTime+parameters.HURTSTARTTIME))
				else
					buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,(skill.hitTime+parameters.HURTSTARTTIME+sDelay))
				end
				obj:addBuff(buff)
				obj:setDeadTime(lifeTime) 
			end
		end
		hitValueBoth = nil
	end
	return hitValueBoth
end

--- 准备攻击前置设置，在prepareHit之前执行，call父类
-- @param mode int - 技能1-7
-- @param itemID int - 目标对象itemID
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SBoss:prepareSkillAttackCustom(mode,itemID,x,y,adjTime,syncMsg)  

	if self.modeatklist~=nil and #self.modeatklist>0 then
		syncMsg['a']['p'] = implode(';',self.modeatklist)
		self.modeatklist = {}
	end
	SBoss.super.prepareSkillAttackCustom(self,mode,itemID,x,y,adjTime,syncMsg)


end 



--- 發動攻擊
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return ret float - 傷害值
function SBoss:hitTarget(itemID,bulletID,mode,hitValue,adjTime)
	
	-- local CRItype = 0
	-- --重置普通攻击
	-- if mode==1 and self.mode1atktime+1.5<=self.world:getGameTime() then
	-- 	self.mode1order = 1
	-- 	self.mode1type  = 0
	-- end

	local ret = SBoss.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	--在自身周围召唤沙暴，弹走所有目标
	if hitValue['HITFLY']~=nil and hitValue['HITFLY']>0 then
		--弹飞所有的目标....BACKWARD=800;BACKWARDSPEED=3000
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		self:D("boss释放击飞.......",self.world.cjson.encode(parameters))

		--弹飞园半径
		local r = parameters.BACKWARD/self.world.setting.AdjustAttRange
		--圆心
		local x = self.posX
		local y = self.posY
		--目标坐标
		local tx = obj.posX
		local ty = obj.posY
		--目标和圆心的距离
		local r1 =self.world.mPow(self.world.mPow(obj.posX-self.posX,2) + self.world.mPow(obj.posY-self.posY,2),0.5)

		--目标偏移位置
		local toX = (tx-x)*r/r1+x
		local toY = (ty-y)*r/r1+y

		ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,toX,toY) 
		--目标到偏移位置的距离
		local d =self.world.mPow(self.world.mPow(obj.posX-toX,2) + self.world.mPow(obj.posY-toY,2),0.5)
		----debuglog("BOSS2A mode 4 posX:"..obj.posX.." posY:"..obj.posY.." toX:"..toX.." toY:"..toY.." d:"..d.." itemID:"..obj.itemID)
		local bulletSpeed = parameters.BACKWARDSPEED
		obj:moveTo(toX,toY,true,5,bulletSpeed,0)
		----debuglog("BOSS2A mode 4 posX:"..obj.posX.." posY:"..obj.posY.." toX:"..toX.." toY:"..toY.." d:"..d.." itemID:"..obj.itemID.." "..self.world.cjson.encode(obj.syncMsg['m']).." "..self.world.cjson.encode(obj.debugPaths))
	end

	--下毒
	if hitValue['POISONHURT']~=nil and hitValue['POISONHURT']>0 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local obj = self.world.allItemList[itemID] 
		self:D("boss释放毒........",self.world.cjson.encode(parameters))
		local lifeTime=parameters.HURTLIFE - parameters.HURTSTARTTIME	
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['INEVITABLEHIT'] = 1
		local fixhurt = 0
		if parameters.POISONEDATKTYPE ==1 then
			--boss攻击
			fixhurt = self.attribute.ATK * hitValue['APADJ'] *0.01
		else
			--最大血量
			fixhurt = obj.attribute.MaxHP * parameters.HURTMAXHP * 0.01
		end
		attributes['buffParameter']['FIXHURT'] =   fixhurt
		attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
		attributes['buffParameter']['buffType'] = 14
		attributes['buffParameter']['Effect'] = -1
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0),attributes,lifeTime,{98},0,self.itemID,obj.itemID,parameters.HURTSTARTTIME)
		--buff.debug = true
		obj:addBuff(buff)
	end

	return ret
end

--- 受傷害計算
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss:hurted(itemID,bulletID,mode,hitValue,adjTime)


	local fromObj = nil
	if itemID>0 then
		fromObj = self.world.allItemList[itemID]
	end

	if itemID>0 and fromObj.attribute.actorType==0 and fromObj.teamOrig~=self.teamOrig then
		self.heroAttack[itemID] =self.world.gameTime
	elseif itemID>0 and fromObj.parent~=nil and fromObj.parent.attribute~=nil and fromObj.parent.attribute.actorType==0 and fromObj.parent.teamOrig~=self.teamOrig then
		self.heroAttack[fromObj.parent.itemID] = self.world.gameTime
	end

	local hurt = SBoss.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)

		-- --计算格挡
	if self.moveShieldTime>0 and self.moveShieldTime>self.world:getGameTime() and  self.shieldSkillTime<self.world:getGameTime() then
		--释放格挡技能
		self:D("格挡  释放格挡技能/////////.......................")
		math.randomseed(os.time()+itemID*1888) 
		--self.world:setRandomSeed()
		local skill = self.attribute.skills[7] 
		local parameters = skill.parameters 
		if self.world.mRandom(0,100)<parameters.COUNTER_RATE then
			self:skillAttack(7,itemID)
			self.shieldSkillTime = self.moveShieldTime
			self:removeSkillAttackMode7()
		end
	end


	return hurt
end

--- 直接傷害
-- @param itemID int - 攻擊方itemID
-- @param mode int - 技能1-7
-- @param hitValueNew table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss:directHurt(itemID,mode,hitValueNew,adjTime)
	local hurt = SBoss.super.directHurt(self,itemID,mode,hitValueNew,adjTime)
	return hurt
end


--- 调整自身HP值
-- @param hp float - 调整的值
-- @param forceSync boolean - 强制syn玩家HP数据到client
-- @param must boolean - 无视任何状态都扣血
-- @return ret boolean - 是否成功调整HP
function SBoss:adjHP(hp,forceSync,must,zz) 
	if forceSync ==nil then forceSync = false end
	if must ==nil then must = false end

	local ret = SBoss.super.adjHP(self,hp,forceSync,must,zz) 
	return ret 
end

--- 由getAttributeAndSync调用，用于组织heroInfo信息
function SBoss:getAttribute(syncMsg)
	if syncMsg==nil then syncMsg = false end

	--debuglog('jaylog start getAttribute')
	local msg = {
		hi = {
			eq7q = self:getCounter('killhero'),
			eq8q = self:getCounter('killed')
		}
	}
	--debuglog('jaylog start call getAttribute'..self.world.cjson.encode(msg))
	if syncMsg then
		self:updateSyncMsg(msg)
		--debuglog('jaylog start syncMsg getAttribute'..self.world.cjson.encode(msg))
	end

	return msg
end


--- 計算傷害
-- @param itemID int - 攻擊方itemID
-- @param hitValue table - 計算參數
-- @return hurt float - 傷害值
function SBoss:calHurted(itemID,hitValue)
	-- --计算格挡
	if self.moveShieldTime>0 and self.moveShieldTime>self.world:getGameTime() then
		--释放格挡技能
		self:D("格挡 释放格挡技能/////////.......................减伤")

		local skill = self.attribute.skills[7] 
		local parameters = skill.parameters 
		hitValue['HURTAD_HURT'] = parameters.HURTAD_HURT
		hitValue['HURTAP_HURT'] = parameters.HURTAP_HURT
		-- self:skillAttack(randsk,self.attackTarget)
	end

	local hurt=SBoss.super.calHurted(self,itemID,hitValue)

	return hurt

end

--- 重新計算所有有效buff
-- @return null
function SBoss:reCalBuff()
	SBoss.super.reCalBuff(self)
	if self.debug  then
	--debuglog("Log2\tID:"..self.itemID.." Team:"..self.team.." Checking ....")
		if self.statusList ~=nil then
		for key,value in pairs(self.statusList) do
			--debuglog("Log2\tID:"..self.itemID.." Team:"..self.team.." Status:"..key.." totalTime:"..value['t'].." remainTime:"..(value['t']-self.world.gameTime-value['r']))
		end
		end
		if self.buffList ~=nil then
		for key,value in pairs(self.buffList) do
			if key ~=nil and value ~=nil then
			--debuglog("Log2\tID:"..self.itemID.." Team:"..self.team.." Buff:"..key.." Detail:"..(value.buffAttribute~=nil and cjson.encode(value.buffAttribute)  or "NULL" ).." Para:"..(value.buffParameter~=nil and  cjson.encode(value.buffParameter) or "NULL"))
			end
		end
		end
	end
end





--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SBoss:goToDead(itemID,mode,adjTime,bonus)
	if mode==nil then mode = 0 end
	if adjTime==nil then adjTime = 0 end
	if bonus==nil then bonus = {} end

	SBoss.super.goToDead(self,itemID,mode,adjTime,bonus)

	--复活时间
	local time = 9999

	self.attackTarget = nil
	if type(adjTime)=="string" then self:D('why is string "'..adjTime..'"') end
	self.deadTime = self.world:getGameTime() + time + adjTime
	if adjTime>1 then adjTime = 1 end
	self:addStatusList({s=9,r=self.world:getGameTime()+adjTime,t=9999,i=self.itemID},adjTime+0.1)
	--死亡倒计时状态
	self:addStatusList({s=981,r=self.world:getGameTime()+adjTime,t=time,i=self.itemID},adjTime+0.1)
	self:moveTo(self.posX,self.posY)

	self:setCounter("killed",1)
	self:getAttributeAndSync()

	local lastAtkId = 0
	local lastAtkTime = 0
	for k,v in pairs(self.heroAttack) do
		if v+10>=self.world:getGameTime() then
			if v>lastAtkTime then
				lastAtkId = k
				lastAtkTime = v
			end
		end
	end
	self:D('jaylog SBoss add killboss:',self.world.cjson.encode(self.heroAttack),' laid:',lastAtkId)
	if lastAtkId~=0 then
		local obj = self.world.allItemList[lastAtkId]
		obj:setCounter("killhero",1)
		obj:setCounter("killboss",1)
		obj:getAttributeAndSync()
		self.world:addSyncMsg({bc={{mid=9,p1=obj.itemID,p2=self.itemID,d=adjTime}}})
	end
end



--- 准备攻击前置设置，在prepareHit之前执行
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
-- function SBoss:prepareSkillAttackCustom(mode,target,x,y,adjtime,syncMsg)
-- 	if (mode==1) then 
-- 		-- self:D("mode1 mode1order : "..self.mode1order)
-- 		-- self:D("mode1 mode1type : "..self.mode1type)
-- 		--重置普通攻击
-- 		if  self.mode1atktime+1.5<=self.world:getGameTime() then
-- 			self.mode1order = 1
-- 			self.mode1type  = 0
-- 		end

-- 		if (self.mode1order>1) then 
-- 			if syncMsg~=nil and syncMsg['a']~=nil then
-- 				syncMsg['a']['p']=self.mode1order-1
-- 				self:D("mode1 prepareSkillAttackCustom syncMsg['a']['p']:"..syncMsg['a']['p'])
-- 				self:D("mode1 prepareSkillAttackCustom 发送第几阶段:"..self.mode1order-1)
-- 			end
-- 		end 
-- 	end 
-- end

-- --- 第7招格挡技能準備攻擊參數
-- -- @param updateMove boolean - 强制移动重算
-- -- @return returnObj obj - 移动信息
-- function SBoss:prepareSkillAttackMode7(updateMove)

-- 	debuglog("格挡call.......")
-- 	if updateMove==nil then updateMove = false end
-- 	if self.prepareSkillAttackNum<=0 then return false end
-- 	local returnObj={}
-- 	--- check target exist ?
-- 	local skill = nil
-- 	if self.attribute.skills[self.prepareSkillAttackNum]~=nil then
-- 		skill = self.attribute.skills[self.prepareSkillAttackNum]
-- 	end
-- 	if skill ~= nil and (self:checkMana(self.prepareSkillAttackNum) or moveShieldTime>self.world:getGameTime()) then 
-- 		if updateMove then
-- 			self:moveCal()
-- 		end
-- 		if self.moveShieldTime<self.world:getGameTime() then
-- 			self:useMana(self.prepareSkillAttackNum)
-- 			self.moveShieldTime = self.world:getGameTime() + 5
-- 			self:addStatusList({s=25,r=self.world:getGameTime(),t=5,i=self.itemID})
-- 		end
-- 		local speed = skill.bulletSpeed
-- 		local s = self:moveTo(self.lastBulletPositionX,self.lastBulletPositionY,true,4,speed)
-- 		local time = 0
-- 		if type(s)=="table" and #s['m']>0 then
-- 			time = s['m'][#s['m']].t
-- 		end
-- 		if type(s)=="table" and (self.AImode==0 or self.autoBlocked) then
-- 			self.syncMsg['m']['zz']=1
-- 			returnObj['m'] = s
-- 		end
-- 		self.prepareSkillAttackNum = 0
-- 		return returnObj
-- 	end
-- 	self.prepareSkillAttackNum = 0
-- 	return false
-- end

--- 第7招格挡技能取消操作
-- @param null
-- @return null
function SBoss:removeSkillAttackMode7()

end


function SBoss:prepareSkillAttack(updateMove,fromClientSide,nPara,pPara)
	return SBoss.super.prepareSkillAttack(self,updateMove,false,nPara,pPara)
end

function SBoss:getHatredID()
	--self.Hatredlist
	--self.BossHatredlist
	local hatredID = 0
	
	
	local list = {}
	for k,v in pairs(self.Hatredlist) do
		-- self:D('jaylog SBoss:getHatredID itemID:',k,' THREAT:',v,self.attribute.roleId)
		local obj = self.world.allItemList[self.world.tonumber(k)]
		if obj~=nil then
			-- local r = self.attribute.VISRNG/self.world.setting.AdjustVisRange
			-- -- local d = self.world.map:distance(self.initX,self.initY,obj.posX,obj.posY) 
			-- local d = self.world.map:distance(self.posX,self.posY,obj.posX,obj.posY) 
			-- self:D('jaylog SBoss:getHatredID r d',obj.attribute.VISRNG,obj.world.setting.AdjustVisRange,r,d,not obj:isDead())
			if not obj:isDead() then-- and r>=d
				list[#list+1] = {itemID=k,THREAT=v}
			end
		end
	end
	-- self:D('jaylog SBoss:getHatredID list:',self.world.cjson.encode(list))
	if #list>0 then
		self.world.tSort(list,function( a1,b1 )
				return a1['THREAT'] > b1['THREAT']
			end)
		-- self:D('jaylog SBoss:getHatredID list2:',self.world.cjson.encode(list))
		hatredID = self.world.tonumber(list[1]['itemID'])
	end
	-- self:D('jaylog SBoss:getHatredID BossHatredlist:',self.world.cjson.encode(self.BossHatredlist))
	if #self.BossHatredlist>0 then
		hatredID = self.world.tonumber(self.BossHatredlist[#self.BossHatredlist]['itemID'])
	end
	--只返回和上一次不一样的目标
	local retID = 0
	-- self:D('jaylog SBoss:getHatredID retID1:',self.oldHatredID,hatredID)
	if self.oldHatredID~=hatredID and hatredID>0 then
		self.oldHatredID = hatredID
		retID = hatredID
	end
	-- self:D('jaylog SBoss:getHatredID retID2:',retID)
	return self.world.tonumber(retID)
end

--- 将task数据发送给前端
-- @param null
-- @return null
function SBoss:activeTaskSyncMsg()
end

--- 领取task奖励时组织数据发送前端
-- @param taskID int - 任务ID
-- @return null
function SBoss:activeTaskRewardSyncMsg(taskID)
end

--- 设置task的自动寻路路线
-- @param taskID string - 任务ID
-- @return null
function SBoss:getTaskPath(taskID)
end

function SBoss:addApiCall(data,ctrl,act)
end

function SBoss:updateInfo()
end

--- call api获取全部task信息
-- @param null
-- @return null
function SBoss:addApiJobGetTask()
end

--- call api更新task信息到API
-- @param null
-- @return null
function SBoss:addApiJobUpdateTask()
end

--- call api获取任务奖励
-- @param taskID int - 任务ID
-- @return null
function SBoss:addApiJobGetGift(taskID)
end

-- call api获取全部counter信息
function SBoss:addApiJobGetCounter()
end

-- update counter
function SBoss:addApiJobUpdateCounter()
end

function SBoss:addApiJobGetProperty()
end

function SBoss:addApiJobGetSkill()
end

--- 设置暫停AI
-- @return null
function SBoss:suspendAI()
end

function SBoss:setAutoFollow(itemID)
end

function SBoss:setAutoMove(taskID)
end

--- Release actor object
-- @return null
function SBoss:release()
	if self.itemID<1000 then
		self:D('jaylog SBoss:release ',self.itemID)
		self.world.playerList[self.itemID] = nil
	end
	SBoss.super.release(self)
end

--- call by all boss class createInit function
-- @return null
function SBoss:callCreateInit()
	local attributes = {}
	local hitValueNew = self:getPrepareHithitValue()
	attributes = hitValueNew
	attributes['BUFFONLY']=1
	attributes['IMMUNECONTROL_RATE'] = 100
	attributes['buffType'] = 3
	attributes['BUFFTIME'] = 99999
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0,99),attributes,99999,{},0,self.itemID,self.itemID,0)
	self:addBuff(buff)
end
function SBoss:createInit()
	self:callCreateInit()
end

return SBoss
