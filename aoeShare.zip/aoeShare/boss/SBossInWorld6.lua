local SBossInWorld6 = class("SBossInWorld6", require("gameroomcore.SHeroBase"))

function SBossInWorld6:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld6.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld6