local SBoss6A = class("SBoss6A", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss6A:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss6A" 
	end 

	SBoss6A.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		--debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
	self.qteCList = {}
	--藏真boss的id
	self.bhzxID = 0
end 


function SBoss6A:createInit()
	self:callCreateInit()
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss6A:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SBoss6A.super.prepareHit(self,mode,adjTime,buff) 
	
	-- if mode==3 then
	-- 	self.modeatklist={}
	-- 	local skill = self.attribute.skills[mode] 
	-- 	local parameters = skill.parameters 
	-- 	local teamlist = {}
	-- 	local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
	-- 	local dlist = {}
	-- 	--TARGETNUMMIN=2;TARGETNUNMAX=5
	-- 	local TARGETNUM =  self.world.formula:getRandnum(parameters.TARGETNUMMIN,parameters.TARGETNUNMAX)
	-- 	self:D("机器人 TARGETNUM:",TARGETNUM)
	-- 	local atknum = TARGETNUM
	-- 	local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
	-- 	function(obj)
	-- 	 	if obj.teamOrig~=self.teamOrig then
	-- 			ok = true
	-- 			if (obj:isDead()) then ok = false end
	-- 			if (atknum<=0) then ok = false end
	-- 			----debuglog('jaylog ok:'..ok)
	-- 			if ok then
	-- 				local d = obj:colliding(visRange,0,0,self.itemID)
	-- 				----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
	-- 				if (d>=0) then 
	-- 					atknum = atknum - 1
	-- 					dlist[#dlist+1] = obj   
	-- 				end
	-- 			end
	-- 		end
	-- 	end
	-- 	)


	-- 	if #dlist<TARGETNUM and #dlist>0 then
	-- 		--所欠的人数
	-- 		local num = TARGETNUM-#dlist
	-- 		--debuglog("机器人有目标 num:"..#dlist)
	-- 		for i=1,num do
	-- 			dlist[#dlist+1]=dlist[1]
	-- 		end
	-- 	end

	-- 	if #dlist>0 then
	-- 		--debuglog("机器人有目标 dlist:"..#dlist)
	-- 		for k,v in pairs(dlist) do
	-- 			local d = self:distance(v.posX,v.posY)
	-- 			local FLYTIME = (d*100)/skill.bulletSpeed
	-- 			local attributes = table.deepcopy(hitValueBoth)
	-- 			attributes['APADJ']=attributes['APADJ2']
	-- 			parameters['HITTIME'..k] = 0.2
	-- 			self:directHurtToDalay(5,v.itemID,attributes,parameters['HITTIME'..k]+FLYTIME)
	-- 			self.modeatklist[#self.modeatklist+1]=v.itemID..","..parameters['HITTIME'..k]..","..FLYTIME
				

	-- 			local obj1 = self.world.allItemList[v.itemID] 
	-- 			-- local skill5 = self.attribute.skills[5] 
	-- 			-- local parameters5 = skill5.parameters 
	-- 			obj1:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID})	
	-- 			--self:D("机器人 精准打击 是不是加了:",parameters5.ADDSTATUS2,parameters5.ADDSTATUSTIME2)

	-- 		end	
	-- 		--debuglog("机器人有目标 :"..self.world.cjson.encode(self.modeatklist))
	-- 	else	
	-- 		--debuglog("机器人没有目标")
	-- 	end

	-- end

	if mode==8 then
		self.mode3list={}
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local teamlist = {}

		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		----debuglog('jaylog useDis:'..skill.useDis..' AdjustAttRange:'..self.world.setting.AdjustAttRange)
		local dlist={}
		--local oldlist={}
		local atknum = parameters.TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				--if (atknum<=0) then ok = false end

				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)

					if (d>=0) then 
						--atknum = atknum - 1
						--dlist[#dlist+1] = obj 
						dlist[#dlist+1]={itemID=obj.itemID,DIS=d}  
					end
				end
			end
		end
		)

		self.world.tSort(dlist,function( a1,b1 )
					return a1['DIS'] > b1['DIS']
				end)
		-- local hlist = parameters.ROLESORT
		-- for k,v in pairs(hlist) do
		-- 	for objk,obj in pairs(oldlist) do
		-- 		if  obj.attribute.roleId==v then
		-- 			dlist[#dlist+1] = obj
		-- 		end
		-- 	end
		-- end
		local newDlist = {}
		newDlist[1]=dlist[#dlist]
		for i=1,atknum-1 do
			newDlist[#newDlist+1]=dlist[i]
		end

		--找到目标释放一个群体aoe在目标脚下
		for k,v in pairs(newDlist) do
			--debuglog(" SBoss2A:prepareHit: duration"..parameters.HURTLIFE..' buffIntervalTime:'..parameters.HURTITNTERVAL)
			local obj  = self.world.allItemList[v.itemID]
			local creatureID=self.world:addCreature(self.world.tostring(parameters.ENEMY),self.teamOrig,obj.posX,obj.posY,self,1,0)

			local obj  = self.world.allItemList[creatureID]
			self.creatureList[#self.creatureList+1]=creatureID  
			local lifeTime=parameters.HURTLIFE		
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			
			attributes['buffParameter'] = hitValueBoth

			attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
			attributes['buffParameter']['creatureDirectHurCallBack'] = "hlszy"

			attributes['buffParameter']['buffType'] = 1
			attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,parameters.HURTSTARTTIME)
			obj:addBuff(buff)
			obj:setDeadTime(lifeTime) 
		end
		
		self:addStatusList({s=parameters.ADDSELFSTATUS,r=self.world:getGameTime(),t=parameters.ADDSELFSTATUSTIME,i=self.itemID})
		hitValueBoth = nil
	end

	--将所有位面外的人拉回来
	if mode==5 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local teamlist = {}

		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		local dlist={}
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if (obj.statusList[4300]==nil) then ok = false end
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
					if (d>=0) then 
						dlist[#dlist+1]=obj
					end
				end
			end
		end
		)
		for k,v in pairs(dlist) do
			self:D("位面攻击启动 纯粹攻击 飞出位面",v.itemID)
			v:moveTo(v.posX-10,v.posY-10,true,2)
			v:removeStatusListNoNext(4300)
		end

	end

	--qte
	-- 奥尔加隆
	-- 1、BOSS会突然闪现消失，同时场上出现1个“崩坏之星”里面，BOSS躲进里面，然后场上接着出现2个相同样子的“崩坏之星”，然后3个“崩坏之星”开始旋转（速度不同，旋转方向不同），结束后3个星体停留在原本的位置（已经打乱）
	-- 2、然后BOSS进行15秒的咏唱
	-- 3、玩家要在此时找出躲在“崩坏之星”里面的BOSS（只有一个有真的BOSS）
	-- 4、如果在15秒内玩家找出BOSS，则咏唱停止；如果找不出则BOSS现身并施放一次宇宙大爆炸
	-- 5、“崩坏之星”设定为需要3个人打才能在15秒内击杀一个
	-- 【玩法提示：找出躲在崩坏之星的BOSS吧！】
	-- 【玩法：记住BOSS躲藏的位置】

	if mode==11 then
		self:D("奥尔加隆 qte")
		self.qteCList = {}
		--随机一个真身
		local r = self.world.formula:getRandnum(1,3)	
		self.bhzxID = r
		local creatureID=self.world:addCreature(self.world.tostring(315),self.teamOrig,self.posX-10,self.posY-10,self,1,0)
		--local obj  = self.world.allItemList[creatureID]
		self.qteCList[#self.qteCList+1]=creatureID  

		local creatureID=self.world:addCreature(self.world.tostring(315),self.teamOrig,self.posX-15,self.posY-15,self,1,0)
		--local obj  = self.world.allItemList[creatureID]
		self.qteCList[#self.qteCList+1]=creatureID  

		local creatureID=self.world:addCreature(self.world.tostring(315),self.teamOrig,self.posX-20,self.posY-20,self,1,0)
		--local obj  = self.world.allItemList[creatureID]
		self.qteCList[#self.qteCList+1]=creatureID  

		local obj  = self.world.allItemList[self.qteCList[self.bhzxID]]
		obj.isboss = true

		self:D("qte 真身是:",r)
		
	end

	if mode==111 then
		local creatureID = self.qteCList[self.bhzxID]
		local obj  = self.world.allItemList[creatureID]
		if obj.isboss~=nil then
			--boss未死
			self:D("qte 不安全")
			self:addStatusList({s=4302,r=self.world:getGameTime(),t=99,i=self.itemID})
		else
			self:D("qte 安全")
			--boss死了
		end
		for k,v in pairs(self.qteCList) do
			local obj  = self.world.allItemList[v]
			if obj~=nil and not obj:isDead() then
				obj.attribute.HP=0
				obj:addStatusList({s=42,r=self.world.gameTime,t=16,i=obj.itemID},2)
				obj:directHurt(obj.itemID,1,{},0)
			end
		end
	end
	
	return hitValueBoth 
end 

--- fight motion , call every update loop
-- @return null
function SBoss6A:fight()
	SBoss6A.super.fight(self) 
	if #self.qteCList>0 then
		local creatureID = self.qteCList[self.bhzxID]
		local obj  = self.world.allItemList[creatureID]
		if obj.isboss==nil or obj:isDead() then
			local skill = self.attribute.skills[11] 
			local parameters = skill.parameters 
			self:removeBuffToID(self:__skillID2buffID(skill.skillID,0))
			self:removeStatusList(83)
			self:D("qte 时间未到安全:",self.bhzxID)
			self.bhzxID = 0
			--boss死了 将其他杀掉
			for k,v in pairs(self.qteCList) do
				local obj  = self.world.allItemList[v]
				if obj~=nil and not obj:isDead() then
					obj.attribute.HP=0
					obj:addStatusList({s=42,r=self.world.gameTime,t=16,i=obj.itemID},2)
					obj:directHurt(obj.itemID,1,{},0)
				end
			end
			self.qteCList = {}
		end
	end
end

--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss6A:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	local ret = SBoss6A.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	if mode==2 then
		local skill = self.attribute.skills[2] 
		local parameters = skill.parameters 
		local obj  = self.world.allItemList[itemID]
		self:D("位面攻击启动")
		--obj:addStatusList({s=4300,r=self.world:getGameTime(),t=15,i=obj.itemID},0)
		obj:addScheduleStatusList(0,{s=4300,t=15},{s=4301,t=15})
	end
	--召唤能量波向前方冲去，然后击中目标造成300%【魔法伤害】，然后从目标身上马上爆发出5个小型能量波，分别追踪另外5个随机目标200%【魔法伤害】
	if mode==6 then
		self.modeatklist={}
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local teamlist = {}
		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		local dlist = {}
		--TARGETNUMMIN=2;TARGETNUNMAX=5
		local TARGETNUM =  self.world.formula:getRandnum(parameters.TARGETNUMMIN,parameters.TARGETNUNMAX)
		self:D("机器人 TARGETNUM:",TARGETNUM)
		local atknum = TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if (atknum<=0) then ok = false end
				if (obj.itemID==itemID) then ok = false end
				----debuglog('jaylog ok:'..ok)
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
					----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
					if (d>=0) then 
						atknum = atknum - 1
						dlist[#dlist+1] = obj   
					end
				end
			end
		end
		)


		if #dlist<TARGETNUM and #dlist>0 then
			--所欠的人数
			local num = TARGETNUM-#dlist
			--debuglog("机器人有目标 num:"..#dlist)
			for i=1,num do
				dlist[#dlist+1]=dlist[1]
			end
		end

		if #dlist>0 then
			--debuglog("机器人有目标 dlist:"..#dlist)
			for k,v in pairs(dlist) do
				local d = self:distance(v.posX,v.posY)
				local FLYTIME = (d*100)/skill.bulletSpeed
				local attributes = table.deepcopy(hitValueBoth)
				attributes['APADJ']=attributes['APADJ2']
				parameters['HITTIME'..k] = 0.2
				self:directHurtToDalay(5,v.itemID,attributes,parameters['HITTIME'..k]+FLYTIME)
				self.modeatklist[#self.modeatklist+1]=v.itemID..","..parameters['HITTIME'..k]..","..FLYTIME
				

				local obj1 = self.world.allItemList[v.itemID] 
				-- local skill5 = self.attribute.skills[5] 
				-- local parameters5 = skill5.parameters 
				obj1:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID})	
				--self:D("机器人 精准打击 是不是加了:",parameters5.ADDSTATUS2,parameters5.ADDSTATUSTIME2)

			end	
			--debuglog("机器人有目标 :"..self.world.cjson.encode(self.modeatklist))
		else	
			--debuglog("机器人没有目标")
		end
	end
	return ret 
end 



return SBoss6A 
