local SBossInWorld3009 = class("SBossInWorld3009", require("gameroomcore.SHeroBase"))

function SBossInWorld3009:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld3009.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld3009