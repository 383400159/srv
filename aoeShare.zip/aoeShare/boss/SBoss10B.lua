local SBoss10B = class("SBoss10B", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss10B:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss10B" 
	end 

	SBoss10B.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		----debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
	--装坐骑的列表
	self.qteCList = {}
end 


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss10B:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SBoss10B.super.prepareHit(self,mode,adjTime,buff) 
	if mode==11 then
		self.qteCList = {}
		--召唤一个吸附怪
		local skill = self.attribute.skills[11] 
		local parameters = skill.parameters 
		local creatureID=self.world:addCreature(self.world.tostring(263),self.teamOrig,self.posX,self.posY,self,1,0)
		local obj  = self.world.allItemList[creatureID]

		local lifeTime=15		--skill.parameters.DEAD
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		--debuglog("SBoss1B:prepareHit------------....hitValueBoth:"..self.world.cjson.encode(hitValueBoth))
		attributes['buffParameter'] = hitValueBoth
		attributes['buffParameter']['FIXHURT'] = 77
		attributes['buffParameter']['ATKPOSX'] = self.posX
		attributes['buffParameter']['ATKPOSY'] = self.posY
		-----debuglog("atkDis:"..parameters.hitTime)
		attributes['buffParameter']['RANGE'] = 10000 --obj.attribute.width * self.world.setting.AdjustAttRange
		attributes['buffParameter']['creatureDirectHurCallBack'] = 'sys'
		----debuglog("jaylog addCreature  creatureID:"..creatureID)
		attributes['buffParameter']['buffType'] = 1
		--attributes['buffParameter']['buffAtleastOnce']=true
		attributes['buffParameter']['buffIntervalTime'] = 3
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,self.itemID,creatureID,0)
		obj:addBuff(buff)
		obj:setDeadTime(lifeTime)
		local tNum = 0
		--召唤鲸鱼🐳
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if ok then
					tNum = tNum + 1
				end
			end
		end
		)


		for i=1,tNum do
			local randlist = self.world.formula:formationPoint(6,20,true)
			local creatureID=self.world:addCreature(self.world.tostring(314),self.teamOrig,self.posX+randlist[i][1],self.posY+randlist[i][2],self,1,0)
			self.qteCList[#self.qteCList+1]=creatureID
			local obj  = self.world.allItemList[creatureID]
			obj:setDeadTime(lifeTime)
			

			local randlist = self.world.formula:formationPoint(6,15,true)
			local creatureID=self.world:addCreature(self.world.tostring(903),self.teamOrig,self.posX+randlist[i][1],self.posY+randlist[i][2],self,1,0)
			local obj1  = self.world.allItemList[creatureID]
			obj1.jyID=obj.itemID
			obj1:setDeadTime(lifeTime)

			--添加状态 用来标示坐骑
			obj:addStatusList({s=4153,r=self.world.gameTime,t=lifeTime,i=self.itemID,p2=obj1.itemID},0)
		end

		--大海全是水 
		self:addStatusList({s=4152,r=self.world.gameTime,t=99999,i=self.itemID,p1=tonumber(self.world.setting.waterDownSpeed),p2=tonumber(self.world.setting.waterLevelMax),p3=tonumber(self.world.setting.waterUpSpeed)},0)
	end

	if mode==111 then
		local isEndNum = 0
		for i,v in ipairs(self.qteCList) do
			local obj  = self.world.allItemList[v]
			if obj.isEnd~=nil then
				isEndNum = isEndNum + 1
			end

		end
		--已经达到上限 
		if #self.qteCList==isEndNum then
			self:D("qte 安全")
		else
			self:addStatusList({s=4151,r=self.world:getGameTime(),t=99,i=self.itemID})
			self:D("qte 不安全 加4151")
		end
		-- local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		-- 	function(obj)
		-- 	 	if obj.teamOrig~=self.teamOrig then
		-- 			ok = true
		-- 			if (obj:isDead()) then ok = false end
		-- 			if ok then
		-- 				obj:removeStatusList(76)
		-- 				obj:removeBUff("DIZZYNOEFFECT",true)
		-- 				obj:moveTo(self.posX,self.posY,false,6)
		-- 			end
		-- 		end
		-- 	end
		-- )

		for i=1,9 do
			local obj  = self.world.allItemList[i]
			if obj~=nil then
				if obj.teamOrig~=self.teamOrig then
					ok = true
					if (obj:isDead()) then ok = false end
					if ok then
						obj:removeStatusList(76)
						obj:removeBUff("DIZZYNOEFFECT",true)
						obj:moveTo(self.posX,self.posY,false,6)
					end
				end
			end
		end
		--大海全是水 清除
		self:removeStatusList(4152)
	end
	return hitValueBoth 
end 



--- fight motion , call every update loop
-- @return null
function SBoss10B:fight()
	SBoss10B.super.fight(self) 
	if #self.qteCList>0 then
		local isEndNum = 0
		for i,v in ipairs(self.qteCList) do
			local obj  = self.world.allItemList[v]
			if obj~=nil and obj.isEnd~=nil then
				isEndNum = isEndNum + 1
			end
		end
		--已经达到上限 提前结束
		if #self.qteCList==isEndNum then
			self:D("qte 安全")
			local skill = self.attribute.skills[11] 
			local parameters = skill.parameters 
			self:removeBuffToID(self:__skillID2buffID(skill.skillID,0))
			self:removeStatusList(83)

			for i=1,9 do
				local obj  = self.world.allItemList[i]
				if obj~=nil then
					if obj.teamOrig~=self.teamOrig then
						ok = true
						if (obj:isDead()) then ok = false end
						if ok then
							obj:removeStatusList(76)
							obj:removeBUff("DIZZYNOEFFECT",true)
							obj:moveTo(self.posX,self.posY,false,6)
						end
					end
				end
			end

		end
	end
	
end



--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SBoss10B:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 

	if hurt>0 and isset(hitValue['creatureDirectHurCallBack']) and hitValue['creatureDirectHurCallBack']=="sys"  then 
		local obj = self.world.allItemList[itemID] 
		local d =self.world.mPow(self.world.mPow(obj.posX-self.posX,2) + self.world.mPow(obj.posY-self.posY,2),0.5)
		--debuglog(itemID.." 2点之间的距离为.......:"..d)
		if d>1 then
			d=2
		else
			d=0
		end

		local toX,toY = self.world.map:getXYLength(obj.posX,obj.posY,hitValue['ATKPOSX'],hitValue['ATKPOSY'],d)
		local ret1

		ret1,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
		--实际距离求速度
		local bulletSpeed = (d/0.5)*100
		obj:moveTo(toX,toY,false,5,bulletSpeed,0)
	end
end



--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss10B:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	



	ret = SBoss10B.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	--ADDSELFSTATUS=4150;ADDSELFSTATUSTIME=999;ABSORDTIME=0.9;INEVITABLEHIT=1
	if mode==4 and hitValue['Effect']~=2 then
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 


		local d =self.world.mPow(self.world.mPow(obj.posX-self.posX,2) + self.world.mPow(obj.posY-self.posY,2),0.5)
		--debuglog(itemID.." 2点之间的距离为.......:"..d)

		if d>1 then
			d=d-1
		end

		local toX,toY = self.world.map:getXYLength(obj.posX,obj.posY,self.posX,self.posY,d)
		local ret1

		ret1,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
		--实际距离求速度
		local sd = d
		local bulletSpeed = (sd/parameters.ABSORDTIME)*100
		--debuglog("飞行时间:"..parameters.ABSORDTIME)
		--debuglog("飞行距离:"..sd)
		--debuglog("飞行速度:"..bulletSpeed)
		obj:moveTo(toX,toY,false,5,bulletSpeed,0)

	end

	if (mode==5 or mode==15)  and hitValue['isOneMode5']==nil then
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local attributes = table.deepcopy(self:getPrepareHithitValue())
		attributes['APADJ']=parameters.APADJ2
		attributes['isOneMode5']=1
		--self:directHurtToDalay(5,itemID,attributes,parameters.HURTDELAY)
		self:directFightAuratoDalay(mode,0,attributes,{posX=obj.posX,posY=obj.posY,RANGE=parameters.HURTRANGE},parameters.HURTDELAY) 
	end

	return ret 
end 

function SBoss10B:createInit()
	self:callCreateInit()
end

return SBoss10B 
