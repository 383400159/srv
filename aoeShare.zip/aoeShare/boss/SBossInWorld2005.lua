local SBossInWorld2005 = class("SBossInWorld2005", require("gameroomcore.SHeroBase"))

function SBossInWorld2005:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld2005.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld2005
