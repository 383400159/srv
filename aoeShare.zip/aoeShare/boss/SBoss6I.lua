local SBoss6I = class("SBoss6I", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss6I:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss6I" 
	end 

	SBoss6I.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		--debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
	self.oldItemID = 0
	--排队释放的技能列表
	self.useSkillList = {}
end 

function SBoss6I:createInit()
	local attributes = {}
	local hitValueNew = self:getPrepareHithitValue()
	attributes = hitValueNew
	attributes['BUFFONLY']=1
	attributes['IMMUNECONTROL_RATE'] = 100
	attributes['buffType'] = 3
	attributes['BUFFTIME'] = 99999
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0,99),attributes,99999,{},0,self.itemID,self.itemID,0)
	self:addBuff(buff)
end


--- 自动释放技能 
-- @return null
function SBoss6I:_autoFight()
	--print('jaylog boss autoFightAI:',self.autoFightAI.runAI)
	--debuglog("SAI ..... outOfCtlTime:"..self.outOfCtlTime.." gameTime:"..self.world.gameTime.." getGameTime:"..self.world:getGameTime())

	if self.AIlastCoolDown<self.world:getGameTime() and self.lastCoolDownTime<self.world:getGameTime() and  not self:isDead() and self.autoFightAI.runAI  then
		self:D("SBossInWorld1004:_autoFight(2)")
		--需要获得自动攻击的item  释放skill的id
		local targetID,skillID,cdTime=self.autoFightAI:execute()
		if targetID>0 then
			if #self.useSkillList>0 then
				skillID=self.useSkillList[1]
				cdTime=0.2
				self:D("保卫雅典娜 堡垒释放特殊技能:",skillID,self.world.cjson.encode(self.useSkillList))
			end
			--self:D("策划SEASON放了什么技能 fenglog checkBOSS roleId:"..self.attribute.roleId.." targetID:"..targetID.." skillID:"..skillID.." cdTime:"..cdTime)
			local retSkillList = self:skillAttack(skillID,targetID)
			if #self.useSkillList>0 and retSkillList~=nil then
				table.remove(self.useSkillList,1)
				self:D("保卫雅典娜 堡垒释放特殊技能成功:",skillID,self.world.cjson.encode(self.useSkillList))
			end
			self:D("策划SEASON放了什么技能 fenglog checkBOSS roleId:"..self.attribute.roleId.." targetID:"..targetID.." skillID:"..skillID.." cdTime:"..cdTime," retSkillList:",self.world.cjson.encode(retSkillList))
			self.autoFightAI.runMoveAI = false
			self.AIlastATKtoMove = self.world:getGameTime()-0.5
			self.AIlastAutoMove = self.world:getGameTime()
		end
		--boss寻敌cd
		self.AIlastCoolDown = self.world:getGameTime() + cdTime
	end


	if not self:isDead() then
		if self.AIlastATKtoMove+10<self.world:getGameTime() then 
			--self:debuglog("AIlastATKtoMove:"..self.AIlastATKtoMove.." runMoveAI true")
			if	self.attribute.parameterArr['NOMOVEAI']==nil then
				self.autoFightAI.runMoveAI = true
			end
		else
			self.autoFightAI.runMoveAI = false
		end
	end

end


function SBoss6I:addSkillList(skillID)
	self.useSkillList[#self.useSkillList+1]=skillID
	self:D("保卫雅典娜 堡垒增加释放特殊技能:",self.world.cjson.encode(self.useSkillList))
end

--REBOUND
--- 發動攻擊
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss6I:hitTarget(itemID,bulletID,mode,hitValue,adjTime)
	--这个boss不会被反弹伤害
	hitValue['NOREBOUND']=1
	local ret = SBoss6I.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime)
	return ret
end



--- 受傷害計算
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss6I:hurted(itemID,bulletID,mode,hitValue,adjTime)
	local ret = 0
 	local obj  = self.world.allItemList[itemID]
 	if obj.team~=self.team then
 		ret = SBoss6I.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
 	end
 	
	
	return ret

end


return SBoss6I 
