local SBossInWorld2001 = class("SBossInWorld2001", require("gameroomcore.SHeroBase"))

function SBossInWorld2001:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld2001.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	--屏蔽巡逻
	self.autoFightAI.noAutoPatrol = true
end


return SBossInWorld2001