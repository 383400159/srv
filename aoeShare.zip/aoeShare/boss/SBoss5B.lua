local SBoss5B = class("SBoss5B", require("gameroom.boss.SBoss")) 
 
--- Constructor 屠夫
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss5B:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss5B" 
	end 

	SBoss5B.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		--debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
end


function SBoss5B:createInit()
	self:callCreateInit()
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss5B:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SBoss5B.super.prepareHit(self,mode,adjTime,buff) 
	--对目标地点丢出爆炸毒液，并造成100%【魔法伤害】，并感染命中目标，目标在5秒后会再次造成一次爆炸，造成200%【魔法伤害】，可无限循环



	return hitValueBoth 
end 


--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss5B:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	local ret = SBoss5B.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	if mode==3 and hitValue['Effect']~=2 and hitValue['Effect']~=5 then
		local obj = self.world.allItemList[itemID] 

		if self.teamOrig~=obj.teamOrig then
			local skill = self.attribute.skills[3] 
			local parameters = skill.parameters 


			local d =self.world.mPow(self.world.mPow(obj.posX-self.posX,2) + self.world.mPow(obj.posY-self.posY,2),0.5)
			if d>1 then
				d=d-1
			end

			local toX,toY = self.world.map:getXYLength(obj.posX,obj.posY,self.posX,self.posY,d)
			local ret1

			ret1,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
			--实际距离求速度
			local sd = d
			parameters.ABSORDTIME=1
			local bulletSpeed = (sd/parameters.ABSORDTIME)*100
			obj:moveTo(toX,toY,false,5,bulletSpeed,0)
		end
	end

	if mode==7 then
		local skill = self.attribute.skills[7] 
		local parameters = skill.parameters 
		local obj  = self.world.allItemList[itemID]
		local lifeTime=0.3		
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		
		attributes['buffParameter'] =  table.deepcopy(self:getPrepareHithitValue())

		attributes['buffParameter']['RANGE'] = parameters.ATKRANGE --obj.attribute.width * self.world.setting.AdjustAttRange
		attributes['buffParameter']['creatureDirectHurCallBack'] = "bzdy".."*"..itemID
		attributes['buffParameter']['FIXHURT'] = self.attribute.ATK*parameters.APADJ2*0.01
		attributes['buffParameter']['buffType'] = 1
		attributes['buffParameter']['buffIntervalTime'] = 5
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,self.itemID,itemID,parameters.ATKINTERVAL)
		obj:addBuff(buff)

	end

	return ret 
end 


--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SBoss5B:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
 

	if isset(hitValue['creatureDirectHurCallBack'])  then 
		local list = string.split(hitValue['creatureDirectHurCallBack'],"*")
		--不毒回自己
		if list[1] == "bzdy" and self.world.tonumber(list[2])~=itemID then
			local skill = self.attribute.skills[7] 
			local parameters = skill.parameters 
			local obj  = self.world.allItemList[itemID]
			local lifeTime=0.3		
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			
			attributes['buffParameter'] =  table.deepcopy(self:getPrepareHithitValue())

			attributes['buffParameter']['RANGE'] = parameters.ATKRANGE --obj.attribute.width * self.world.setting.AdjustAttRange
			attributes['buffParameter']['creatureDirectHurCallBack'] = "bzdy".."*"..itemID
			attributes['buffParameter']['FIXHURT'] = self.attribute.ATK*parameters.APADJ2*0.01
			attributes['buffParameter']['buffType'] = 1
			attributes['buffParameter']['buffIntervalTime'] = 5
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,self.itemID,itemID,parameters.ATKINTERVAL)
			obj:addBuff(buff)
		end
	end
end



return SBoss5B 
