local SBoss1F = class("SBoss1F", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss1F:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss1F" 
	end 

	SBoss1F.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		--debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
	self.creatureList = {}
end 

-- --boss免控
-- function SBoss1F:addIMMUNECONTROLBUFF()
-- 	--IMMUNECONTROL_RATE=100

-- 	self:D("addIMMUNECONTROLBUFF boss itemID:",self.itemID)
-- 	-- --debuglog("boss allItemList:"..self.world.cjson.encode(self.world.allItemList[self.itemID]))
-- 	self:callCreateInit()
-- end


function SBoss1F:xwmq(hitValueBoth)
	local skill = self.attribute.skills[4] 
	local parameters = skill.parameters 
	local teamlist = {}
	--搜敌找到所需要的目标
	-- if ( self.teamOrig=="A")  then
	-- 	teamlist=self.world.itemListFilter.teamB
	-- else
	-- 	teamlist=self.world.itemListFilter.teamA
	-- end
	----debuglog('jaylog teamlist:'..self.world.cjson.encode(teamlist))
	local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
	----debuglog('jaylog useDis:'..skill.useDis..' AdjustAttRange:'..self.world.setting.AdjustAttRange)
	local dlist = {}
	local atknum = parameters.TARGETNUM

	local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
	function(obj)
	 	if obj.teamOrig~=self.teamOrig then
			ok = true
			if (obj:isDead()) then ok = false end
			if (atknum<=0) then ok = false end
			----debuglog('jaylog ok:'..ok)
			if ok then
				local d = obj:colliding(visRange,0,0,self.itemID)
				----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
				if (d>=0) then 
					atknum = atknum - 1
					dlist[#dlist+1] = obj   
				end
			end
		end
	end
	)



	-- local enemy = self:getEnemylist()
	-- for k,obj in pairs(enemy) do
	-- 	----debuglog('jaylog allItemList:'..k..' id:'..obj.itemID..' ot:'..obj.teamOrig..' st:'..self.teamOrig)
	-- 	if obj.teamOrig~=self.teamOrig then
	-- 		ok = true
	-- 		if (obj:isDead()) then ok = false end
	-- 		if (atknum<=0) then ok = false end
	-- 		----debuglog('jaylog ok:'..ok)
	-- 		if ok then
	-- 			local d = obj:colliding(visRange,0,0,self.itemID)
	-- 			----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
	-- 			if (d>=0) then 
	-- 				atknum = atknum - 1
	-- 				dlist[#dlist+1] = obj   
	-- 			end
	-- 		end
	-- 	end
	-- end

	--找到目标释放一个群体aoe在目标脚下
	for k,obj in pairs(dlist) do
		----debuglog('jaylog dlist:'..k)
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		--APADJ=125;DEF_DOWN=50;DEF_DOWN_RATE=100;BUFFTIME=10

		----debuglog("hitTime_:"..skill.hitTime)
		--debuglog("jaylog SBoss1A:prepareHit: duration"..skill.duration..' buffIntervalTime:'..skill.bulletTimeInterval)
		local creatureID=self.world:addCreature(self.world.tostring(263),self.teamOrig,obj.posX,obj.posY,self,1,skill.hitTime)
		local obj  = self.world.allItemList[creatureID]
		self.creatureList[#self.creatureList+1]=creatureID  
		local lifeTime=parameters.HURTLIFE		--skill.parameters.DEAD
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		--debuglog("SBoss1B:prepareHit------------....hitValueBoth:"..self.world.cjson.encode(hitValueBoth))
		attributes['buffParameter'] = hitValueBoth
		--attributes['buffParameter']['FIXHURT'] = 250
		-----debuglog("atkDis:"..parameters.hitTime)
		attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
		attributes['buffParameter']['creatureDirectHurCallBack'] = 'xwmq'
		----debuglog("jaylog addCreature  creatureID:"..creatureID)
		attributes['buffParameter']['buffType'] = 1
		--attributes['buffParameter']['buffAtleastOnce']=true
		attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
		self:D("虚无盲区  ",parameters.HURTLIFE, parameters.HURTITNTERVAL,parameters.HURTSTARTTIME,skill.hitTime)
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,(skill.hitTime+parameters.HURTSTARTTIME))
		obj:addBuff(buff)
		obj:setDeadTime(lifeTime) 
	end
	hitValueBoth = nil
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss1F:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SBoss1F.super.prepareHit(self,mode,adjTime,buff) 

	if mode==1 then
		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters
		self:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID})
	end

	if mode==4 then
		self:xwmq(hitValueBoth)
	end
	
	if mode==5 then		
		hitValueBoth['bulletAttackMode4Passthru'] = false;  --防止穿墙
	end

	if mode==7 then
		self.modeatklist={}
		local skill = self.attribute.skills[7] 
		local parameters = skill.parameters 
		local teamlist = {}
		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		local dlist = {}
		--local oldlist = {}
		local atknum = parameters.TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if (obj.attribute.roleID == 2 or obj.attribute.roleID == 7) then ok = false end
				if (atknum<=0) then ok = false end
				-----debuglog('jaylog ok:'..ok)
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
					----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
					if (d>=0) then 
						--atknum = atknum - 1
						dlist[#dlist+1] = obj   
					end
				end
			end
		end
		)

		for k,v in pairs(dlist) do
			local skill = self.attribute.skills[7] 
			local parameters = skill.parameters 
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1

			attributes['buffParameter'] = hitValueBoth  --self:getPrepareHithitValue()使用默认的空白参数
			attributes['buffParameter']['RANGE'] = skill.atkDis
			--attributes['buffParameter']['APADJ'] = hitValueBoth['APADJ2']
			attributes['buffParameter']['FIXHURT'] = 100
			attributes['buffParameter']['buffType'] = 1
			--attributes['buffParameter']['buffAtleastOnce']=true
			attributes['buffParameter']['buffIntervalTime'] = 50
			self:D("虚无盲区  ",parameters.HURTLIFE, parameters.HURTITNTERVAL,parameters.HURTSTARTTIME,skill.hitTime)
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,parameters.HURTDELAY+5,{99},0,self.itemID,v.itemID,0)
			v:addBuff(buff)
		end
	end

	return hitValueBoth
end

function SBoss1F:prepareSkillAttackCustom(mode,target,x,y,adjTime,syncMsg)  
	SBoss1F.super.prepareSkillAttackCustom(self,mode,target,x,y,adjTime,syncMsg)  
end 

function SBoss1F:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	local ret = SBoss1F.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	if mode==5 then
		self.modeatklist={}
		local skill = self.attribute.skills[5] 
		local parameters = skill.parameters 
		local teamlist = {}
		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		local dlist = {}
		--local oldlist = {}
		--local atknum = parameters.TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				--if (atknum<=0) then ok = false end
				----debuglog('jaylog ok:'..ok)
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
					----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
					if (d>=0) then 
						--atknum = atknum - 1
						dlist[#dlist+1] = obj   
					end
				end
			end
		end
		)

		for k,v in pairs(dlist) do
			local r = parameters.BACKWARD/self.world.setting.AdjustAttRange
			local toX1,toY1 = self.world.map:getXYLength(self.posX,self.posY,v.posX,v.posY,r)
			local ret,toX,toY=self.world.map:findPointStraightLineNearest(v.posX,v.posY,v.posX+toX1,v.posY+toY1) 
			v:moveTo(toX,toY,false,6,skill.bulletSpeed,adjTime) 
		end
	end

	return ret
end

function SBoss1F:createInit()
	self:callCreateInit()
end

return SBoss1F 