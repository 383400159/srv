local SBoss1B = class("SBoss1B", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss1B:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss1B" 
	end 
	self.creatureList = {}
	--boss阶段
	self.bossType = 1

	SBoss1B.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		----debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end		

	--旋转射线
	self.angle1 = 120	
	self.angle2 = 240
	self.angle2 = 360
	self.offsetsAngle = 0
	self.angleSpeed = 0
	self.mode11Time = self.world.gameTime
	self.mode11AtkTime = 0

	--成就参数
	self.blindArea_3005 = 0
	self.deathRay_3005 = 0


	self.deathRay_3005 = 0
	self.doomEye_3005 = 0



end 

--boss免控
function SBoss1B:addIMMUNECONTROLBUFF()
	--IMMUNECONTROL_RATE=100

	self:D("addIMMUNECONTROLBUFF boss itemID:",self.itemID)
	-- --debuglog("boss allItemList:"..self.world.cjson.encode(self.world.allItemList[self.itemID]))
	self:callCreateInit()
end


function SBoss1B:xwmq(hitValueBoth)
	local skill = self.attribute.skills[4] 
	local parameters = skill.parameters 
	local teamlist = {}
	--搜敌找到所需要的目标
	-- if ( self.teamOrig=="A")  then
	-- 	teamlist=self.world.itemListFilter.teamB
	-- else
	-- 	teamlist=self.world.itemListFilter.teamA
	-- end
	----debuglog('jaylog teamlist:'..self.world.cjson.encode(teamlist))
	local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
	----debuglog('jaylog useDis:'..skill.useDis..' AdjustAttRange:'..self.world.setting.AdjustAttRange)
	local dlist = {}
	local atknum = parameters.TARGETNUM

	local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
	function(obj)
	 	if obj.teamOrig~=self.teamOrig then
			ok = true
			if (obj:isDead()) then ok = false end
			if (atknum<=0) then ok = false end
			----debuglog('jaylog ok:'..ok)
			if ok then
				local d = obj:colliding(visRange,0,0,self.itemID)
				----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
				if (d>=0) then 
					atknum = atknum - 1
					dlist[#dlist+1] = obj   
				end
			end
		end
	end
	)



	-- local enemy = self:getEnemylist()
	-- for k,obj in pairs(enemy) do
	-- 	----debuglog('jaylog allItemList:'..k..' id:'..obj.itemID..' ot:'..obj.teamOrig..' st:'..self.teamOrig)
	-- 	if obj.teamOrig~=self.teamOrig then
	-- 		ok = true
	-- 		if (obj:isDead()) then ok = false end
	-- 		if (atknum<=0) then ok = false end
	-- 		----debuglog('jaylog ok:'..ok)
	-- 		if ok then
	-- 			local d = obj:colliding(visRange,0,0,self.itemID)
	-- 			----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
	-- 			if (d>=0) then 
	-- 				atknum = atknum - 1
	-- 				dlist[#dlist+1] = obj   
	-- 			end
	-- 		end
	-- 	end
	-- end

	--找到目标释放一个群体aoe在目标脚下
	for k,obj in pairs(dlist) do
		----debuglog('jaylog dlist:'..k)
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		--APADJ=125;DEF_DOWN=50;DEF_DOWN_RATE=100;BUFFTIME=10

		----debuglog("hitTime_:"..skill.hitTime)
		--debuglog("jaylog SBoss1A:prepareHit: duration"..skill.duration..' buffIntervalTime:'..skill.bulletTimeInterval)
		local creatureID=self.world:addCreature(self.world.tostring(263),self.teamOrig,obj.posX,obj.posY,self,1,skill.hitTime)
		local obj  = self.world.allItemList[creatureID]
		self.creatureList[#self.creatureList+1]=creatureID  
		local lifeTime=parameters.HURTLIFE		--skill.parameters.DEAD
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		--debuglog("SBoss1B:prepareHit------------....hitValueBoth:"..self.world.cjson.encode(hitValueBoth))
		attributes['buffParameter'] = hitValueBoth
		--attributes['buffParameter']['FIXHURT'] = 250
		-----debuglog("atkDis:"..parameters.hitTime)
		attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
		attributes['buffParameter']['creatureDirectHurCallBack'] = 'xwmq'
		----debuglog("jaylog addCreature  creatureID:"..creatureID)
		attributes['buffParameter']['buffType'] = 1
		--attributes['buffParameter']['buffAtleastOnce']=true
		attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
		self:D("虚无盲区  ",parameters.HURTLIFE, parameters.HURTITNTERVAL,parameters.HURTSTARTTIME,skill.hitTime)
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,(skill.hitTime+parameters.HURTSTARTTIME))
		obj:addBuff(buff)
		obj:setDeadTime(lifeTime) 
	end
	hitValueBoth = nil
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss1B:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SBoss1B.super.prepareHit(self,mode,adjTime,buff) 

	if mode==1 then
		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters
		self:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID})
	end

	if mode==4 then
		self:xwmq(hitValueBoth)
	end

	if mode==107 then
		local skill = self.attribute.skills[7] 
		local parameters = skill.parameters 
		local teamlist = {}

		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		----debuglog('jaylog useDis:'..skill.useDis..' AdjustAttRange:'..self.world.setting.AdjustAttRange)
		local dlist = {}
		local atknum = parameters.TARGETNUM

		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if (obj.attribute.roleID==2 or obj.attribute.roleID==7) then ok=false end
				if (atknum<=0) then ok = false end
				----debuglog('jaylog ok:'..ok)
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
					--debuglog('毁灭之眼 is colliding:'..obj.itemID..' d:'..d)
					if (d>=0) then 
						atknum = atknum - 1
						dlist[#dlist+1] = obj   
					end
				end
			end
		end
		)
		

		-- local enemy = self:getEnemylist()
		-- for k,obj in pairs(enemy) do
		-- 	----debuglog('jaylog allItemList:'..k..' id:'..obj.itemID..' ot:'..obj.teamOrig..' st:'..self.teamOrig)
		-- 	if obj.teamOrig~=self.teamOrig then
		-- 		ok = true
		-- 		if (obj:isDead()) then ok = false end
		-- 		if (obj.attribute.roleID==2 or obj.attribute.roleID==7) then ok=false end
		-- 		if (atknum<=0) then ok = false end
		-- 		----debuglog('jaylog ok:'..ok)
		-- 		if ok then
		-- 			local d = obj:colliding(visRange,0,0,self.itemID)
		-- 			----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
		-- 			if (d>=0) then 
		-- 				atknum = atknum - 1
		-- 				dlist[#dlist+1] = obj   
		-- 			end
		-- 		end
		-- 	end
		-- end

		--找到目标释放一个群体aoe在目标脚下
		for k,obj in pairs(dlist) do
			--debuglog("毁灭之眼 打中了谁:"..obj.itemID)
			----debuglog('jaylog dlist:'..k)
			local skill = self.attribute.skills[7] 
			local parameters = skill.parameters 

			local lifeTime=skill.duration		--skill.parameters.DEAD
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			
			attributes['buffParameter'] = hitValueBoth
			--attributes['buffParameter']['FIXHURT'] = 250
			-----debuglog("atkDis:"..parameters.hitTime)
			attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
			----debuglog("jaylog addCreature  creatureID:"..creatureID)
			attributes['buffParameter']['APADJ'] = hitValueBoth['APADJ2']
			attributes['buffParameter']['buffType'] = 1
			--attributes['buffParameter']['buffAtleastOnce']=true
			attributes['buffParameter']['buffIntervalTime'] = 50
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,parameters.HURTDELAY+5,{99},0,self.itemID,obj.itemID,parameters.HURTDELAY)
			obj:addBuff(buff)
			obj:addStatusList({s=parameters.ADDSTATUS2,r=self.world.gameTime,t=parameters.ADDSTATUSTIME2,i=self.itemID})


		end
		self.ismode107 = true
		hitValueBoth = nil
	end

	--BOSS在自己周围召唤3个【虚空祭司】（从身上飞出三团紫色特效，特效落到指定位置后【虚空祭司】出现），【虚空祭司】会为BOSS套上一个反魔法护盾
	--，魔法护盾免疫魔法伤害并对魔法伤害来源造成50%反伤的【魔法伤害】。打死全部【虚空祭司】可以解除魔法盾，【虚空祭司】物理免疫。
	--ADADJ=0;APADJ=0;ADDSTATUS=4077;ADDSTATUSTIME=0.5;REFLECTAP_UPFIX_RATE=100;REFLECTAP_UPFIX=50;IMMUNEAP_RATE=100;BUFFTIME=0.5

	--虚空诅咒 -> 闪现 -> 射线预警 -> 旋转射线；对所有目标标记上一个诅咒，所有玩家的伤害复制（接旋转射线）
	if mode==10 then
		--CLEANSELFSTATUS=4073;ANGLEMAX=160;ANGLEMIN=60;ATTACKINTERVAL=0.2;LIFETIME=5;BACKWARDSPEED2=150
		local skill = self.attribute.skills[11] 
		local parameters = skill.parameters

 		self.offsetsAngle = self.world.formula:getRandnum(0,360)

 		--随机3个角度
		-- self.angle1 = 0
		-- self.angle2 = self.world.formula:getRandnum(parameters.ANGLEMIN,parameters.ANGLEMAX)
		-- self.angle3 = self.angle2+self.world.formula:getRandnum(parameters.ANGLEMIN,(360-self.angle2)*0.5)
		self.mode11Time = self.world.gameTime

		local a1 = self.world.formula:getRandnum(parameters.ANGLEMIN,parameters.ANGLEMAX)
		local a2 = self.world.formula:getRandnum((360-a1)*0.5,parameters.ANGLEMAX)
		local a3 = 360-a1-a2
		--debuglog("虚空射线准备回调 a1:"..a1.." a2:"..a2.." a3:"..a3)
		self.angle1 = 0
		self.angle2 = a1
		self.angle3 = self.angle2+a3
		self.mode11Time = self.world.gameTime

		-- local a1 = self.angle2-self.angle1
		-- local a2 = self.angle3-self.angle2
		-- local a3 = 360-self.angle3
		--计算角速度
		local maxAngle = a1
		if a2>maxAngle then
			maxAngle = a2
		end
		if a3>maxAngle then
			maxAngle = a3
		end


		local a = self:mode11Direction()
		local maxAngle = self.world.formula:getRandnum(parameters.ROTATIONMIN,parameters.ROTATIONMAX)


		self.angleSpeed = maxAngle/parameters.LIFETIME*(a==0 and 1 or -1)
		--self.angleSpeed = 360/parameters.LIFETIME*(a==0 and 1 or -1)
		self.offsetsAngle = self.world.formula:getRandnum(0,360)
		--self.offsetsAngle = 0
		--debuglog("虚空射线准备回调......... maxAngle :"..maxAngle.." angleSpeed:"..self.angleSpeed.." 1:"..(self.offsetsAngle+self.angle1).." 2:"..(self.offsetsAngle+self.angle2).." 3:"..(self.offsetsAngle+self.angle3))

		self:addStatusList({s=4082,r=self.world:getGameTime(),t=parameters.LIFETIME,i=self.itemID,p1=self.mode11Time*100,p2=(self.angleSpeed+360),p3=(self.offsetsAngle+self.angle1)*1000000+(self.offsetsAngle+self.angle2)*1000+(self.offsetsAngle+self.angle3)})
	end



	--虚空诅咒 -> 闪现 -> 射线预警 -> 旋转射线 ；BOSS闪现到中间，在自己周围召唤出3个发射射线的法球，然后法球旋转360度，旋转方向随机。（3个球角度可调）
	if mode==11 or mode==18 then
		--CLEANSELFSTATUS=4073;ANGLEMAX=160;ANGLEMIN=60;ATTACKINTERVAL=0.2;LIFETIME=5;BACKWARDSPEED2=150
		self.mode11Time = self.world.gameTime
		self.mode11AtkTime = self.world.gameTime
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters

		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['buffParameter'] = {}
		attributes['buffParameter']['buffIntervalTime'] = parameters.ATTACKINTERVAL
		local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,parameters.LIFETIME,{mode},0,self.itemID,self.itemID,skill.hitTime) 
 		self:addBuff(buffObj)

		self:addStatusList({s=4081,r=self.world:getGameTime(),t=parameters.LIFETIME,i=self.itemID,p1=self.mode11Time*100,p2=(self.angleSpeed+360),p3=(self.offsetsAngle+self.angle1)*1000000+(self.offsetsAngle+self.angle2)*1000+(self.offsetsAngle+self.angle3)})
		-- --立刻执行一次
		-- mode=111

		--记录AI需要躲避的时间
		self.world.worldQTETime = self.world:getGameTime() + skill.hitTime + parameters.LIFETIME
		--转动方向
		self.world.worldQTEDirection = self.angleSpeed
		--boss释放的坐标
		self.world.BossX = self.posX
		self.world.BossY = self.posY

		self:D("boss 释放旋转射线",self.world.worldQTETime,self.world.worldQTEDirection)
		for k,v in pairs(self.world.itemListFilter.heroList) do
			if v.attribute.actorType==0 and  not v:isAIObj() then
				v:setAutoBlocked(false,(skill.hitTime+parameters.LIFETIME))
			end
		end	
	end

	if mode==111 or mode==118 then
		--debuglog("虚空射线回调中.........")
		--计算一个循环里面可以走的角度
		local skill = self.attribute.skills[mode-100] 
		local parameters = skill.parameters
		local offsetsAngle = self.offsetsAngle + (self.world.gameTime-self.mode11Time)*self.angleSpeed

		for i=1,3 do
			local customize = self.world:createSkillValue()
			customize['attackMode'] = 1
			customize['atkDis'] = 1000000
			customize['bulletSpeed'] = 99999
			customize['targetType'] = 1
			customize['degree'] = self.world.mAbs((self.world.gameTime-self.mode11AtkTime)*self.angleSpeed)
			local toX = self.posX + math.cos(math.rad(self['angle'..i]+offsetsAngle))*100
			local toY = self.posY + math.sin(math.rad(self['angle'..i]+offsetsAngle))*100
			local hitValue=table.deepcopy(hitValueBoth)
			hitValue['mode11Angle'] = self['angle'..i]+offsetsAngle
			hitValue['APADJ'] = hitValue['APADJ2']
			hitValue['creatureDirectHurCallBack'] = 'xwsx'
			local bulletID = self.world:addBullet(mode-100,self.itemID,self.world.gameTime,0,toX,toY,false,hitValue,customize) 
			-- local ac =  math.atan((toY-self.posY)/(toX-self.posX))
			--debuglog("虚空射线 customize:"..self.world.cjson.encode(customize).." toX:"..toX.." toY:"..toY.." posX:"..self.posX.." posY:".." "..self.posY.." bulletID:"..bulletID)
		end
		--debuglog("虚空射线 mode11AtkTime:"..self.mode11AtkTime.." angle:"..self['angle1'].." offsetsAngle:"..offsetsAngle.." gameTime:"..self.world.gameTime.." 差值abs:"..self.world.mAbs((self.world.gameTime-self.mode11AtkTime)))
		self.mode11AtkTime  = self.world.gameTime

	end

	--闪现
	if mode==9 or mode==22 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters
		--debuglog("BOSS2A mode 12  移动到:POSX:"..parameters.POSX.." POSY:"..parameters.POSY) 
		self:moveTo(parameters.POSX,parameters.POSY,true,1)
	end

	if mode==8 then
		local skill = self.attribute.skills[8] 
		local parameters = skill.parameters
		self:addStatusList({s=parameters.ADDSTATUS2,r=self.world:getGameTime(),t=parameters.ADDSTATUSTIME2,i=self.itemID})
	end

	if mode==6 then
		
		if hitValueBoth['autoCreatureIDList']~=nil then
			for k,v in pairs(hitValueBoth['autoCreatureIDList']) do
				local obj  = self.world.allItemList[v]
				obj:addStatusList({s=4080,r=self.world:getGameTime(),t=9999,i=obj.itemID,p1=self.itemID})
				--obj:addStatusList({s=41,r=self.world:getGameTime(),t=9999,i=obj.itemID,p1=self.itemID})
			end
		end
	end

	if mode==13 then
		for k,v in pairs(self.world.allItemList) do
			if not v:isDead() and v.subName=="FLAMEN"  then
				--debuglog("转场清除场上的小怪.....itemID:"..v.itemID)
				v.attribute.HP=0
				v:addStatusList({s=42,r=self.world.gameTime,t=16,i=v.itemID},0.2)
			end  
		end
	end


	-- if mode==14 then
	-- 	local skill = self.attribute.skills[14] 
	-- 	local parameters = skill.parameters 
	-- 	local d1 = self:distance(self.lastBulletPositionX,self.lastBulletPositionY)
	-- 	--local d2 = (d1-self.attribute.width)>0 and (d1-self.attribute.width) or d1
	-- 	local ret,toX,toY = self.world.map:findNearestIdlePoint(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,d1)
	-- 	-- local d = self:distance(toX,toY)
	-- 	-- local FLYSPEED = (d*100)/parameters.FLYTIME
	-- 	-- self:moveTo(toX,toY,false,1,FLYSPEED,skill.hitTime+adjTime)
	-- 	self:moveTo(toX,toY,true,1)
	-- end


	if mode==14 or mode==23 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local d1 = self:distance(self.lastBulletPositionX,self.lastBulletPositionY)
		--local d2 = (d1-self.attribute.width)>0 and (d1-self.attribute.width) or d1
		local ret,toX,toY = self.world.map:findNearestIdlePoint(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,d1)
		-- local d = self:distance(toX,toY)
		-- local FLYSPEED = (d*100)/parameters.FLYTIME
		-- self:moveTo(toX,toY,false,1,FLYSPEED,skill.hitTime+adjTime)
		self.world:D('jaylog SBoss1B mode14 ',self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,toX,toY)
		self:moveTo(toX,toY,true,1)
	end


	return hitValueBoth 
end 

--获得旋转射线方向
function SBoss1B:mode11Direction()
	local a = self.world.formula:getRandnum(0,1)
	return a
end

--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss1B:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 

	-- if mode==7 and self.ismode107~=nil and self.ismode107 then
	-- 	local obj  = self.world.allItemList[creatureID]
	-- 	local skill = self.attribute.skills[7] 
	-- 	local parameters = skill.parameters
	-- 	local attributes = {}
	-- 	attributes['buffParameter']={}
	-- 	attributes['BUFFONLY']=1
	-- 	attributes['buffParameter'] = hitValue
	-- 	--attributes['buffParameter']['FIXHURT'] = 250
	-- 	-----debuglog("atkDis:"..parameters.hitTime)
	-- 	attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
	-- 	----debuglog("jaylog addCreature  creatureID:"..creatureID)
	-- 	attributes['buffParameter']['buffType'] = 1
	-- 	--attributes['buffParameter']['buffAtleastOnce']=true
	-- 	attributes['buffParameter']['buffIntervalTime'] = 6
	-- 	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,7,{99},0,creatureID,creatureID,skill.hitTime)
	-- 	obj:addBuff(buff)
	-- end

		--在自身周围召唤沙暴，弹走所有目标
	if mode==5 or mode==17 then
		--弹飞所有的目标....BACKWARD=800;BACKWARDSPEED=3000
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 

		--弹飞园半径
		local r = parameters.BACKWARD/self.world.setting.AdjustAttRange
		--圆心
		local x = self.posX
		local y = self.posY
		--目标坐标
		local tx = obj.posX
		local ty = obj.posY
		if self.posX==obj.posX and self.posY==obj.posY then
			tx = obj.posX+0.0001
			ty = obj.posY+0.0001
		end
		--目标和圆心的距离
		local r1 =self.world.mPow(self.world.mPow(tx-x,2) + self.world.mPow(ty-y,2),0.5)
		-- local r1 =self.world.mPow(self.world.mPow(obj.posX-self.posX,2) + self.world.mPow(obj.posY-self.posY,2),0.5)

		--目标偏移位置
		local toX = (tx-x)*r/r1+x
		local toY = (ty-y)*r/r1+y

		ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,toX,toY) 
		--目标到偏移位置的距离
		--local d =self.world.mPow(self.world.mPow(obj.posX-toX,2) + self.world.mPow(obj.posY-toY,2),0.5)
		----debuglog("BOSS2A mode 4 posX:"..obj.posX.." posY:"..obj.posY.." toX:"..toX.." toY:"..toY.." d:"..d.." itemID:"..obj.itemID)
		local bulletSpeed = parameters.BACKWARDSPEED2
		obj:moveTo(toX,toY,true,5,bulletSpeed,0)
		----debuglog("BOSS2A mode 4 posX:"..obj.posX.." posY:"..obj.posY.." toX:"..toX.." toY:"..toY.." d:"..d.." itemID:"..obj.itemID.." "..self.world.cjson.encode(obj.syncMsg['m']).." "..self.world.cjson.encode(obj.debugPaths))
	end


	ret = SBoss1B.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime)



	if mode==11 or mode==18 then
		if self.world.gameTime>self.mode11Time then
			--弹飞所有的目标....CLEANSELFSTATUS=4073;ANGLEMAX=160;ANGLEMIN=60;ATTACKINTERVAL=0.2;LIFETIME=5;BACKWARDSPEED2=3000; BACKWARD=150
			local obj = self.world.allItemList[itemID] 
			local skill = self.attribute.skills[mode] 
			local parameters = skill.parameters 

			--弹飞园半径
			local r = parameters.BACKWARD2*0.01
			--圆心
			local x = self.posX
			local y = self.posY
			--目标坐标
			local tx = obj.posX
			local ty = obj.posY
			--目标和圆心的距离
			local r1 =self.world.mPow(self.world.mPow(obj.posX-self.posX,2) + self.world.mPow(obj.posY-self.posY,2),0.5)

			--目标偏移位置
			local toX = (tx-x)*r/r1+tx
			local toY = (ty-y)*r/r1+ty

			ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,toX,toY) 
			--目标到偏移位置的距离
			local d =self.world.mPow(self.world.mPow(obj.posX-toX,2) + self.world.mPow(obj.posY-toY,2),0.5)
			--debuglog("BOSS1B mode 11 posX:"..obj.posX.." posY:"..obj.posY.." toX:"..toX.." toY:"..toY.." d:"..d.." itemID:"..obj.itemID)
			local bulletSpeed = parameters.BACKWARDSPEED2
			obj:moveTo(toX,toY,true,5,bulletSpeed,0)
			obj.nextMoveAITime = self.world:getGameTime()+0.5
		end
	end


	if mode==7 then
		--成就 为什么一直盯着我 
		local obj  = self.world.allItemList[itemID]
		if obj.doomEye_3005==nil then
			obj.doomEye_3005 = 0
		end
		obj.doomEye_3005 = obj.doomEye_3005 + 1
	end

	-- if mode==14 then
	-- 	local obj = self.world.allItemList[itemID] 
	-- 	local skill = self.attribute.skills[14] 
	-- 	local parameters = skill.parameters 


	-- 	local d1 = self:distance(self.lastBulletPositionX,self.lastBulletPositionY)
	-- 	local ret,toX,toY = self.world.map:findNearestIdlePoint(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,d1)
	-- 	self:moveTo(toX,toY,true,1)

	-- 	--弹飞园半径
	-- 	local r = parameters.BACKWARD/self.world.setting.AdjustAttRange
	-- 	--圆心
	-- 	local x = self.posX
	-- 	local y = self.posY
	-- 	--目标坐标
	-- 	local tx = obj.posX
	-- 	local ty = obj.posY
	-- 	--目标和圆心的距离
	-- 	local r1 =self.world.mPow(self.world.mPow(obj.posX-self.posX,2) + self.world.mPow(obj.posY-self.posY,2),0.5)

	-- 	--目标偏移位置
	-- 	local toX = (tx-x)*r/r1+x
	-- 	local toY = (ty-y)*r/r1+y

	-- 	ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,toX,toY) 
		
	-- 	local bulletSpeed = parameters.BACKWARDSPEED2
	-- 	obj:moveTo(toX,toY,true,5,bulletSpeed,0)
	-- end

	return ret 
end 


--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SBoss1B:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	local hurt = SBoss1B.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
	if isset(hitValue['creatureDirectHurCallBack']) and hitValue['creatureDirectHurCallBack']=="xwmq"  then 
		--成就 只有笨蛋才会中啦！
		local obj  = self.world.allItemList[itemID]
		if obj.blindArea_3005==nil then
			obj.blindArea_3005 = 0
		end
		obj.blindArea_3005 = obj.blindArea_3005 + 1
	end
	if isset(hitValue['creatureDirectHurCallBack']) and hitValue['creatureDirectHurCallBack']=="xwsx"  then 
		--成就 看我旋转走位
		local obj  = self.world.allItemList[itemID]
		if obj.deathRay_3005==nil then
			obj.deathRay_3005 = 0
		end
		obj.deathRay_3005 = obj.deathRay_3005 + 1
		if self:isDead() then
			--成就 真的不是我中了！
			obj:setCounter("dieInDeathRay_3005",1)
		end
	end
end

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SBoss1B:goToDead(itemID,mode,adjTime,bonus)
	ret = SBoss1B.super.goToDead(self,itemID,mode,adjTime,bonus) 
	local obj  = self.world.allItemList[itemID]
	--成就 嘿嘿嘿嘿！
	obj:setCounter("lastKill_2002",1)
	local dlist = {}
	local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if ok then
					dlist[#dlist+1] = obj 
					if obj.blindArea_3005==nil then
						obj:setCounter("blindArea_3005",1)
					end
					if obj.deathRay_3005==nil then
						obj:setCounter("deathRay_3005",1)
					end
					if obj.deathRay_3005~=nil and obj.deathRay_3005==3 then
						obj:setCounter("deathRay3_3005",1)
					end
					if obj.doomEye_3005~=nil and obj.doomEye_3005==3 then
						obj:setCounter("doomEye_3005",1)
					end
				end
			end
		end
		)

	
	if #dlist==1 then
		--成就 拯救世界的我
		obj:setCounter("killBossOnlyMeAlive_3005",1)
	end
	--嘿嘿嘿嘿！
	obj:setCounter("lastKill_3005",1)
	return ret
end

return SBoss1B 
