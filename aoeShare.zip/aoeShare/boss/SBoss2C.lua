local SBoss2C = class("SBoss2C", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss2C:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss2C" 
	end 

	SBoss2C.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		----debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
end 

function SBoss2C:goToDead(itemID,mode,adjTime,bonus)  
	SBoss2C.super.goToDead(self,itemID,mode,adjTime,bonus) 
end 



--- move motion , call every update loop
-- @return null
function SBoss2C:move()
	SBoss2C.super.move(self)
end

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SBoss2C:goToDead(itemID,mode,adjTime,bonus)
	ret = SBoss2C.super.goToDead(self,itemID,mode,adjTime,bonus) 

end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss2C:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SBoss2C.super.prepareHit(self,mode,adjTime,buff) 

	if mode==5 then
		local skill = self.attribute.skills[5] 
		local parameters = skill.parameters 
		local d1 = self:distance(self.lastBulletPositionX,self.lastBulletPositionY)
		--local d2 = (d1-self.attribute.width)>0 and (d1-self.attribute.width) or d1
		local ret,toX,toY = self.world.map:findNearestIdlePoint(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,d1)
		local d = self:distance(toX,toY)
		local FLYSPEED = (d*100)/parameters.FLYTIME
		self:moveTo(toX,toY,false,1,FLYSPEED,skill.hitTime+adjTime)
	end


	if mode==4 then
		--ADDSTATUS=35;ADDSTATUSTIME=3;FLYTIME=0.35
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		local d1 = self:distance(self.lastBulletPositionX,self.lastBulletPositionY)
		local atkDis = (d1-parameters.NEARESTUSEDIS/self.world.setting.AdjustAttRange)>0 and (d1-parameters.NEARESTUSEDIS/self.world.setting.AdjustAttRange) or d1

		local toX1,toY1 = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,atkDis)
		local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX1,self.posY+toY1) 
		--local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY)
		--debuglog("伊利丹 大招 posX:"..self.posX.." posY:"..self.posY.." lastBulletPositionX:"..self.lastBulletPositionX.." lastBulletPositionY:"..self.lastBulletPositionY.." toX:"..toX.." toY:"..toY)
		local d = self:distance(toX,toY)
		-- local stopD=parameters.STOPTIME*5
		-- local FLYSPEED = ((d-stopD)*100)/(parameters['FLYTIME']+parameters['DOWNTIME'])
		local FLYSPEED = (d*100)/(parameters['FLYTIME'])

		self:moveTo(toX,toY,false,6,FLYSPEED,skill.hitTime+adjTime)
		--local dealyTime = (d*100)/parameters['FLYSPEED']
		local dealyTime = parameters['FLYTIME']
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['buffParameter'] = {}
		attributes['buffParameter']['buffIntervalTime'] = dealyTime
		local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,dealyTime+0.1,{mode},0,self.itemID,self.itemID,skill.hitTime+adjTime) 
 		self:addBuff(buffObj)
 		--debuglog("伊利丹 大招 d:"..d.."dealyTime:"..dealyTime.." lastBulletPositionX:"..self.lastBulletPositionX.." lastBulletPositionY:"..self.lastBulletPositionY.." posX"..self.posX.." posY:"..self.posY)
		hitValueBoth=nil
		self.mode4time = self.world.gameTime+skill.hitTime

		-- local hitValueNew={}
		-- hitValueNew['ATK_UPFIX_RATE']=parameters.ATK_UPFIX_RATE3 
		-- hitValueNew["ATK_UPFIX"]=parameters.ATK_UPFIX3
		-- hitValueNew["BUFFTIME"]=parameters.BUFFTIME3
		-- self:directHurt(self.itemID,mode,hitValueNew,0) 


		self.lastBulletPositionX = toX
		self.lastBulletPositionY = toY
		return nil
	end

	if mode==104 then
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		if self.world.gameTime>self.mode4time then
			--debuglog("伊利丹 大招 回调")
			local hitValueNew = hitValueBoth
			hitValueNew['skillID'] = 4
			hitValueNew['ADADJ'] = parameters.ADADJ2 
			self:directFightAuratoDalay(4,0,hitValueNew,{posX=self.posX,posY=self.posY,RANGE=skill.atkDis},0) 

		end
		hitValueBoth=nil
	end



	return hitValueBoth 
end 

function SBoss2C:createInit()
	self:callCreateInit()
end
--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss2C:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 

	ret = SBoss2C.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	if mode==3 then
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 
		if (self.attribute.HP/self.attribute.MaxHP)*100<(parameters.BOSSREHPMAX-parameters.BOSSREHP)   then
  			--debuglog("伊利丹 BOSS回血前:"..self.attribute.HP)
			local bossHitValueNew = {}
	 		bossHitValueNew['FIXHURT']  = -self.attribute.MaxHP*parameters.BOSSREHP*0.01
	  		self:directHurt(self.itemID,1,bossHitValueNew,0) 
	  		--debuglog("伊利丹 BOSS回血后:"..self.attribute.HP.." FIXHURT:"..bossHitValueNew['FIXHURT'].." MaxHP:"..self.attribute.MaxHP.." BOSSREHP:"..parameters.BOSSREHP*0.01)
  		end
  		self:addStatusList({s=parameters.ADDSELFSTATUS2,r=self.world.gameTime,t=parameters.ADDSELFSTATUSTIME2,i=self.itemID})
	end

	return ret 
end 

return SBoss2C 
