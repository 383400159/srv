local SBossInWorld8012 = class("SBossInWorld8012", require("gameroomcore.SHeroBase"))

function SBossInWorld8012:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld8012.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SBossInWorld8012