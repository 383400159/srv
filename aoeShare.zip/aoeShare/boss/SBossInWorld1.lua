local SBossInWorld1 = class("SBossInWorld1", require("gameroomcore.SHeroBase"))

function SBossInWorld1:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld1.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SBossInWorld1