local SBossInWorld3010 = class("SBossInWorld3010", require("gameroomcore.SHeroBase"))

function SBossInWorld3010:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld3010.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SBossInWorld3010
