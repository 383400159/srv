local SBossInWorld9001 = class("SBossInWorld9001", require("gameroomcore.SHeroBase"))

function SBossInWorld9001:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld9001.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SBossInWorld9001