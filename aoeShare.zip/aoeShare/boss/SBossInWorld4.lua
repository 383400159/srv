local SBossInWorld4 = class("SBossInWorld4", require("gameroomcore.SHeroBase"))

function SBossInWorld4:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld4.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SBossInWorld4