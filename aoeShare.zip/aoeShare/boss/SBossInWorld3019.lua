local SBossInWorld3019 = class("SBossInWorld3019", require("gameroomcore.SHeroBase"))

function SBossInWorld3019:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld3019.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld3019
