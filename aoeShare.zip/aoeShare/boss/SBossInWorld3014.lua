local SBossInWorld3014 = class("SBossInWorld3014", require("gameroomcore.SHeroBase"))

function SBossInWorld3014:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld3014.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SBossInWorld3014
