local SBossInWorld8009 = class("SBossInWorld8009", require("gameroomcore.SHeroBase"))

function SBossInWorld8009:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld8009.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SBossInWorld8009