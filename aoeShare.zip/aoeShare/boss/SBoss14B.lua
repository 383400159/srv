local SBoss14B = class("SBoss14B", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss14B:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss14B" 
	end 
	self.creatureList = {}
	--boss阶段
	self.bossType = 1

	SBoss14B.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		--debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		debuglog("jaylog SActor actorID jaylog SBoss actorID:"..actorID)
		self.itemID = actorID				--游戏房角色num
	end		
end 

--boss免控
function SBoss14B:addIMMUNECONTROLBUFF()
	--IMMUNECONTROL_RATE=100

	debuglog("addIMMUNECONTROLBUFF boss itemID:"..self.itemID)
	-- debuglog("boss allItemList:"..self.world.cjson.encode(self.world.allItemList[self.itemID]))
	local attributes = {}
	local hitValueNew = self:getPrepareHithitValue()
	attributes = hitValueNew
	attributes['BUFFONLY']=1
	attributes['IMMUNECONTROL_RATE'] = 100
	attributes['buffType'] = 3
	attributes['BUFFTIME'] = 99999
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0,99),attributes,99999,{},0,self.itemID,self.itemID,0)
	self:addBuff(buff)
end



--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss14B:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SBoss14B.super.prepareHit(self,mode,adjTime,buff) 


	if mode==7 then

		local skill = self.attribute.skills[7] 
		local parameters = skill.parameters 
		local teamlist = {}
		--搜敌找到所需要的目标
		-- if ( self.teamOrig=="A")  then
		-- 	teamlist=self.world.itemListFilter.teamB
		-- else
		-- 	teamlist=self.world.itemListFilter.teamA
		-- end
		--debuglog('jaylog teamlist:'..self.world.cjson.encode(teamlist))
		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		--debuglog('jaylog useDis:'..skill.useDis..' AdjustAttRange:'..self.world.setting.AdjustAttRange)
		local dlist = {}
		local atknum = parameters.TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if (atknum<=0) then ok = false end
				--debuglog('jaylog ok:'..ok)
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
					--debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
					if (d>=0) then 
						atknum = atknum - 1
						dlist[#dlist+1] = obj   
					end
				end
			end
		end
		)
		
		-- local enemy = self:getEnemylist()
		-- for k,obj in pairs(enemy) do
		-- 	--debuglog('jaylog allItemList:'..k..' id:'..obj.itemID..' ot:'..obj.teamOrig..' st:'..self.teamOrig)
		-- 	if obj.teamOrig~=self.teamOrig then
		-- 		ok = true
		-- 		if (obj:isDead()) then ok = false end
		-- 		if (atknum<=0) then ok = false end
		-- 		--debuglog('jaylog ok:'..ok)
		-- 		if ok then
		-- 			local d = obj:colliding(visRange,0,0,self.itemID)
		-- 			--debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
		-- 			if (d>=0) then 
		-- 				atknum = atknum - 1
		-- 				dlist[#dlist+1] = obj   
		-- 			end
		-- 		end
		-- 	end
		-- end

		--找到目标释放一个群体aoe在目标脚下
		for k,obj in pairs(dlist) do
			--debuglog('jaylog dlist:'..k)
			local skill = self.attribute.skills[4] 
			local parameters = skill.parameters 
			--APADJ=125;DEF_DOWN=50;DEF_DOWN_RATE=100;BUFFTIME=10

			--debuglog("hitTime_:"..skill.hitTime)
			debuglog("jaylog SBoss1A:prepareHit: duration"..skill.duration..' buffIntervalTime:'..skill.bulletTimeInterval)
			local creatureID=self.world:addCreature(self.world.tostring(263),self.teamOrig,obj.posX,obj.posY,self,1,parameters.ATKDISSHOWDELAY)
			local obj  = self.world.allItemList[creatureID]
			self.creatureList[#self.creatureList+1]=creatureID  
			local lifeTime=skill.duration		--skill.parameters.DEAD
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			debuglog("SBoss4A:prepareHit------------....hitValueBoth:"..self.world.cjson.encode(hitValueBoth))
			attributes['buffParameter'] = hitValueBoth
			--attributes['buffParameter']['FIXHURT'] = 250
			---debuglog("atkDis:"..parameters.hitTime)
			attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
			attributes['buffParameter']['creatureDirectHurCallBack'] = creatureID
			--debuglog("jaylog addCreature  creatureID:"..creatureID)
			attributes['buffParameter']['buffType'] = 1
			--attributes['buffParameter']['buffAtleastOnce']=true
			attributes['buffParameter']['buffIntervalTime'] = skill.bulletTimeInterval
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,creatureID,creatureID,skill.hitTime)
			obj:addBuff(buff)
			obj:setDeadTime(lifeTime) 
		end
		hitValueBoth = nil
	
	end

	return hitValueBoth 
end 


return SBoss14B 