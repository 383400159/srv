local SBossInWorld2003 = class("SBossInWorld2003", require("gameroomcore.SHeroBase"))

function SBossInWorld2003:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld2003.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SBossInWorld2003
