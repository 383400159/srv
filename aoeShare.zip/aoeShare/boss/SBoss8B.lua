local SBoss8B = class("SBoss8B", require("gameroom.boss.SBoss")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss8B:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SBoss8B" 
	end 

	SBoss8B.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
		--debuglog("jaylog SActor actorID jaylog SBoss1 actorID:"..actorID)
	if actorID~=nil then
		self.itemID = actorID				--游戏房角色num
	end
	--缓存无敌斩攻击次序
	self.mode3atklist={}
end 


function SBoss8B:createInit()
	self:callCreateInit()
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SBoss8B:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SBoss8B.super.prepareHit(self,mode,adjTime,buff) 
	--生成攻击列表
	if mode==3 then
		self.mode3atklist={}
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 
		local visRange = {posX=self.posX,posY=self.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		local dlist = {}
		local atknum = parameters.TARGETNUM
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if (atknum<=0) then ok = false end
				if ok then
					local d = obj:colliding(visRange,0,0,self.itemID)
					----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
					if (d>=0) then 
						atknum = atknum - 1
						dlist[#dlist+1] = obj   
					end
				end
			end
		end
		)
		dlist=table.shuffle(dlist)
		self.mode3atklist=dlist
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['buffParameter'] = {}
		attributes['buffParameter']['buffIntervalTime'] = 5
		local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,0.2,{mode},0,self.itemID,self.itemID,parameters.ATTACKINTERVAL) 
 		--buffObj.debug = true
 		self:addBuff(buffObj)
 		self:D("迷惑攻击 mode3atklist:",#self.mode3atklist,self.world:getGameTime())
 		self.AIlastCoolDown = self.world:getGameTime() + 1
	end
	--回调攻击
	if mode==103 then
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 
		local obj = self.mode3atklist[1]
		table.remove(self.mode3atklist,1)
		--闪现到目标身边
		self:moveTo(obj.posX,obj.posY,true,1)
		local attributes = table.deepcopy(hitValueBoth)
		attributes['FIXHURT'] = 9
		attributes['APADJ'] = hitValueBoth['APADJ2']
		self:directHurtToDalay(3,obj.itemID,attributes,0.5)
		local skill9 = self.attribute.skills[9] 
		local parameters9 = skill9.parameters 
		--加状态播特效
		if obj.st4221List==nil then
			obj.st4221List = {}
		end
		obj.st4221List[#obj.st4221List+1]={starTime=self.world.gameTime,t=parameters9.DURATION}
		obj:addStatusList({s=4221,r=self.world.gameTime,t=parameters9.DURATION,i=self.itemID})	

		--继续回调
		if #self.mode3atklist>0 then
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			attributes['buffParameter'] = {}
			attributes['buffParameter']['buffIntervalTime'] = 5
			local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,0.2,{3},0,self.itemID,self.itemID,parameters.ATTACKINTERVAL) 
	 		--buffObj.debug = true
	 		self:addBuff(buffObj)
	 		self:D("迷惑攻击继续回调 mode3atklist itemID:",obj.itemID,#self.mode3atklist,self.world:getGameTime())
			self.AIlastCoolDown = self.world:getGameTime() + 1
		end
		self:D("迷惑攻击回调 mode3atklist itemID:",obj.itemID,#self.mode3atklist,self.world:getGameTime())
	end
	--遁入暗影之中，施放“突袭”
	if mode==5 then
		--self:addStatusList({s=4220,r=self.world:getGameTime(),t=10,i=self.itemID})
	end

	--qte
	-- 1、BOSS进入隐身状态，场景变暗，并在10秒后突袭最远的玩家
	-- 2、玩家前方出现扇形探照灯，玩家通过探照灯寻找BOSS
	-- 3、如果探照灯找到BOSS即可让它显形，并阻止它施放突袭
	-- 4、如果10秒后还没找到BOSS就会对最远距离目标施放突袭
	-- 5、BOSS在隐身状态下，所有玩家都受到心魔效果的影响
	-- 【玩家提示：找出隐身状态下的BOSS！】
	-- 【玩法：尽快找到隐身状态下的BOSS】
	if mode==10 then
		local skill = self.attribute.skills[10] 
		local parameters = skill.parameters 
	end



	return hitValueBoth 
end 


function SBoss8B:removeStatusList( statusNum, adjTime )
	if statusNum==83 then
		self:D("QTE 清除83状态")
		local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if ok then
					obj:removeStatusList(4221)
					obj.st4221List={}
					self:D("QTE 清除4221状态",obj.itemID)
				end
			end
		end
		)
	end
	return SBoss8B.super.removeStatusList(self,statusNum, adjTime)
end

--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss8B:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	local ret = SBoss8B.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	if mode==10 then
		--SADDSELFSTATUSB=83;SADDSELFSTATUSTIMEB=15;STRIGGERSELFSTATUSB=4222;STRIGGERSELFSTATUSTIMEB=999;DURATION=15;CLEANTARGETSTATUS2=4220;CLEANTARGETSTATUS3=83
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[10] 
		local parameters = skill.parameters 
		--加状态播特效
		if obj.st4221List==nil then
			obj.st4221List = {}
		end
		obj.st4221List[#obj.st4221List+1]={starTime=self.world.gameTime,t=parameters.DURATION}
		obj:addStatusList({s=4221,r=self.world.gameTime,t=parameters.DURATION,i=self.itemID})	

		local lifeTime=999999
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['INEVITABLEHIT'] = 1
		attributes['buffParameter']['RANGE'] =500
		-- attributes['buffParameter']['RANGE']=1000
		attributes['buffParameter']['FIXHURT'] =  77
		attributes['buffParameter']['CLEANTARGETSTATUS'] = parameters.CLEANTARGETSTATUS2
		attributes['buffParameter']['SCLEANTARGETSTATUSA'] = parameters.CLEANTARGETSTATUS3
		attributes['buffParameter']['buffIntervalTime'] = 0.3
		attributes['buffParameter']['buffType'] = 1
		attributes['buffParameter']['Effect'] = -1
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(1),attributes,lifeTime,{99},0,obj.itemID,obj.itemID,0)
		--buff.debug = true
		obj:addBuff(buff)

		self:D("QTE 伤害:",itemID)
	end
	
	return ret 
end 


return SBoss8B 
