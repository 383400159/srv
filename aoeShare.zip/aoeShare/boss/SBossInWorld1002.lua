local SBossInWorld1002 = class("SBossInWorld1002", require("gameroomcore.SHeroBase"))

function SBossInWorld1002:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld1002.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end



return SBossInWorld1002