local SBossInWorld1001 = class("SBossInWorld1001", require("gameroomcore.SHeroBase"))

function SBossInWorld1001:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SBossInWorld1001.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end



return SBossInWorld1001