#!/bin/bash
main='formula GameFlow SActor SCounter STask Transfer SSkill SEnergyBoard function SNPC'
enemy='SMonster SSoldier STower'
