local SPotion1 = class("SPotion1", require("gameroom.potion.SPotion"))

local cjson = require( Config.cjson )

function SPotion1:useEquip( obj , x , y)
	if x ==nil then
		x = 0
	end
	if y ==nil then
		y = 0
	end
end


return SPotion1
