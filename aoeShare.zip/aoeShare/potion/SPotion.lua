local SPotion = class("SPotion")

local cjson = require( Config.cjson )

--- Constructor
-- @param id int - roleID
-- @param world object - world object
-- @return null
function SPotion:ctor(id,world)

	if (self.className==nil) then
		self.className="SPotion"
	end

	if id==nil then id=0 end

	self.potionID = 0
	self.name = ''
	self.type = 0
	self.width = 0
	self.parameters = {}
	self:__load(id,world)
end

--- load data
-- @param id int - roleID
-- @param world object - world object
-- @return null
function SPotion:__load(id,world) 
	self.ID = id
	local sql = "select * from potion where potionID = '"..id.."'"
	local data = world:getDBData(sql)
	self:assignAttribute(data[1])
end

--- 注册数据
-- @param data table - 需要注册的数据
-- @return null
function SPotion:assignAttribute(data)
	if data==nil then return nil end
	for key,value in pairs(data) do
		if self[key]~=nil then
			if key=='name' then
				self[key] = value
			else
				self[key] = tonumber(value)
			end
		elseif key=='parameter' then
			local vtable = string.split(value,";")
			local continue = true 
			local vlist
			for k,value2 in pairs(vtable) do
				if strpos(value2,"=")~=nil then
					vlist = string.split(value2,"=")
					self.parameters[vlist[1]] = tonumber(vlist[2])
				end
			end
		end
	end
end


function SPotion:addEquip( obj )

end

function SPotion:removeEquip( obj )

end

function SPotion:useEquip( obj , x , y)
	if x ==nil then
		x = 0
	end
	if y ==nil then
		y = 0
	end
end


function SPotion:prepareHit( obj , mode , adjTime , hitValueBoth )
	
end


function SPotion:hitTargetPrepare( obj , to , bulletID , mode , hitValue , adjTime)
	
end

function SPotion:hitTarget( obj , to , bulletID , mode , hitValue , adjTime , ret)
	
end

function SPotion:hurted( obj , to , bulletID , mode , hitValue , adjTime , hurt )
	
end

function SPotion:fight( obj )
	
end


return SPotion
