#!/bin/bash

cd /var/aoe_test/
./kill.sh
