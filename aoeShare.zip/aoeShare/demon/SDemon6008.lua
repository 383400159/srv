local SDemon6008 = class("SDemon6008", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon6008:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon6008" 
	end
	SDemon6008.super.ctor(self,world,heroObj,skillObj) 
end 


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @param hitValue table - 攻擊參數
-- @return hitValue table - 攻擊參數
function SDemon6008:prepareHit(mode,adjTime,buff,hitValue)
	local ret=SDemon6008.super.prepareHit(self,mode,adjTime,buff,hitValue) 
	local skill = self.heroObj.attribute.skills[mode] 
	local parameters = skill.parameters 
	--CDTIME=5;DIZZY_RATE=100;BUFFTIME=1;BACKWARD2=500;BACKWARDSPEED2=1200
	--ADADJ;ADADJ2
	local hitValueNew = self.heroObj:getPrepareHithitValue()
	
	local creatureID=self.world:addCreature(self.world.tostring(102),self.heroObj.teamOrig,self.heroObj.lastBulletPositionX,self.heroObj.lastBulletPositionY,self.heroObj,1,0)
	local obj  = self.world.allItemList[creatureID]
	local attributes = {} 
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['buffParameter']=hitValueNew
	attributes['buffParameter']['changeMode']=mode
	attributes['buffParameter']['RANGE'] = skill.atkDis
	attributes['buffParameter']['APADJ'] = parameters.ADADJ2

	attributes['buffParameter']['ATKPOSX'] = self.heroObj.posX
	attributes['buffParameter']['ATKPOSY'] = self.heroObj.posY

	attributes['buffParameter']['creatureDirectHurCallBack'] = "hlszy"
	attributes['buffParameter']['buffType'] = 1		
	attributes['buffParameter']['buffIntervalTime'] = 10
	local buff = require("gameroomcore.SBuff").new(self.world,self.heroObj:__skillID2buffID(skill.skillID),attributes,0.5,{99},0,self.heroObj.itemID,obj.itemID,parameters.BUFFTIME)
	--buff.debug = true
	--self:addBuff(buff)
	obj:addBuff(buff)
	obj:setDeadTime(5) 
	return hitValue 
end 

--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon6008:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 

	if isset(hitValue['creatureDirectHurCallBack']) and hitValue['creatureDirectHurCallBack']=="hlszy"  then 
		--弹飞所有的目标....BACKWARD=800;BACKWARDSPEED=3000
		local obj = self.world.allItemList[itemID] 
		local skill = self.heroObj.attribute.skills[mode] 
		local parameters = skill.parameters 

		--弹飞园半径
		local r = parameters.BACKWARD2
		--local r = 10
		--圆心
		local x = hitValue['ATKPOSX']
		local y = hitValue['ATKPOSY']
		--目标坐标
		local tx = obj.posX
		local ty = obj.posY
		--目标和圆心的距离
		local r1 =self.world.mPow(self.world.mPow(obj.posX-hitValue['ATKPOSX'],2) + self.world.mPow(obj.posY-hitValue['ATKPOSY'],2),0.5)

		--目标偏移位置
		local toX = (tx-x)*r/r1+x
		local toY = (ty-y)*r/r1+y

		ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,toX,toY) 
		--目标到偏移位置的距离
		local d =self.world.mPow(self.world.mPow(obj.posX-toX,2) + self.world.mPow(obj.posY-toY,2),0.5)
		----debuglog("BOSS2A mode 4 posX:"..obj.posX.." posY:"..obj.posY.." toX:"..toX.." toY:"..toY.." d:"..d.." itemID:"..obj.itemID)
		local bulletSpeed = parameters.BACKWARDSPEED2
		--local bulletSpeed = 9999
		obj:moveTo(toX,toY,true,5,bulletSpeed,0)
	end
end

--- 發動攻擊後
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon6008:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)
	local ret=SDemon6008.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime,ret) 

	return ret
end 


return SDemon6008 
