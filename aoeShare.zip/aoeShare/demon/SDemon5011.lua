local SDemon5011 = class("SDemon5011", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon5011:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon5011" 
	end
	SDemon5011.super.ctor(self,world,heroObj,skillObj) 
end 

--- 發動攻擊後
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon5011:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)

	local ret=SDemon5011.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime,ret) 

	if hitValue['Effect']~=2 and hitValue['Effect']~=5 then
		self.heroObj:D("魔灵技能 嘲讽ID:",itemID)
		local obj = self.world.allItemList[itemID] 
		if self.heroObj.teamOrig~=obj.teamOrig then
			local skill = self.heroObj.attribute.skills[mode] 
			local parameters = skill.parameters 


			local d =self.world.mPow(self.world.mPow(obj.posX-self.heroObj.posX,2) + self.world.mPow(obj.posY-self.heroObj.posY,2),0.5)

			if d>1 then
				d=d-1
			end

			local toX,toY = self.world.map:getXYLength(obj.posX,obj.posY,self.heroObj.posX,self.heroObj.posY,d)
			local ret1
	
			ret1,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
			--实际距离求速度
			local sd = d
			--local bulletSpeed = (sd/parameters.ABSORDTIME)*100
			local bulletSpeed = 9999
			obj:moveTo(toX,toY,false,5,bulletSpeed,0)


			local attributes = {}
			attributes['OUTCTL_RATE'] = 100 
			if obj.attribute.actorType==1 then
				attributes['BUFFTIME'] = parameters.BUFFTIME2
			else
				attributes['BUFFTIME'] = parameters.BUFFTIME3
			end
			self.heroObj:D("嘲讽晕多久",attributes['BUFFTIME'],self.world.cjson.encode(parameters))
			--ADADJ=300;HURTTRANSFERSP=1000;CDTIME=10;OUTCTL_RATE2=100;BUFFTIME2=2;BUFFTIME3=5
			local buff = require("gameroomcore.SBuff").new(self.world,obj:__skillID2buffID(0),attributes,attributes['BUFFTIME'],{},0,obj.itemID,obj.itemID)
			obj:addBuff(buff)

			obj.attackTarget = self.heroObj.itemID

			--增加打boss的特殊效果
			if obj.attribute.actorType==2 then
				obj.BossHatredlist[#obj.BossHatredlist+1]={itemID=self.heroObj.itemID,endTime=self.world:getGameTime()+parameters.BUFFTIME3} 
				obj:addStatusMsg({s=44,r=parameters.BUFFTIME3,t=self.world:getGameTime()+parameters.BUFFTIME3,i=obj.itemID})
			end
		
			-- 复制最高的仇恨值作为自己的仇恨值
			if not self.world.empty(obj.Hatredlist) then
				local maxHatred = 0
				for k,v in pairs(obj.Hatredlist) do
					if maxHatred<v then
						maxHatred=v
					end
				end
				obj.Hatredlist[""..self.heroObj.itemID] = maxHatred
			end
		end
	end


	return ret
end 

return SDemon5011 