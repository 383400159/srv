local SDemon6007 = class("SDemon6007", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon6007:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon6007" 
	end
	SDemon6007.super.ctor(self,world,heroObj,skillObj) 
end 

--- 發動攻擊後
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon6007:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)


	local ret=SDemon6007.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime,ret) 
	local skill = self.heroObj.attribute.skills[mode] 
	local parameters = skill.parameters 
	local hitValueNew = hitValue
	hitValueNew['skillID'] = mode
	hitValueNew['APADJ'] = hitValue['APADJ2']
	hitValueNew['DATKP'] = '6007'
	-- hitValueNew['FIXHURT'] = 888
	self.heroObj:D("SDemon6007 hitValueNew:",self.world.cjson.encode(hitValueNew))
	self.heroObj:directFightAuratoDalay(mode,0,hitValueNew,{posX=self.heroObj.posX,posY=self.heroObj.posY,RANGE=skill.atkDis},5) 

	return ret
end 

return SDemon6007 
