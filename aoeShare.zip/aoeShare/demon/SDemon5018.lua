local SDemon5018 = class("SDemon5018", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon5018:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon5018" 
	end
	SDemon5018.super.ctor(self,world,heroObj,skillObj) 
end 

--- 發動攻擊後
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon5018:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)



	local ret=SDemon5018.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime,ret) 

	return ret
end 

return SDemon5018 