local SDemon6005 = class("SDemon6005", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon6005:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon6005" 
	end
	SDemon6005.super.ctor(self,world,heroObj,skillObj) 
end 


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @param hitValue table - 攻擊參數
-- @return hitValue table - 攻擊參數
function SDemon6005:prepareHit(mode,adjTime,buff,hitValue)
	local ret=SDemon6005.super.prepareHit(self,mode,adjTime,buff,hitValue) 
	local skill = self.heroObj.attribute.skills[mode] 
	local parameters = skill.parameters 

	local attributes = table.deepcopy(self.heroObj:getPrepareHithitValue())
	attributes['SILIENCE_RATE'] = 100
	attributes['Effect'] = -1
	attributes['BUFFTIME'] = 5
	self.heroObj:directHurtToDalay(mode,self.heroObj.itemID,attributes,0)
	self.heroObj:addStatusList({s=73,r=self.world:getGameTime(),t=5,i=self.heroObj.itemID},0)


	local lifeTime=6	
	local attributes = {}
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['buffParameter'] = table.deepcopy(self.heroObj:getPrepareHithitValue())
	attributes['buffParameter']['RANGE'] = 500 --obj.attribute.width * self.world.setting.AdjustAttRange
	attributes['buffParameter']['buffType'] = 1
	attributes['buffParameter']['FIXHURT'] = 77
	attributes['buffParameter']['buffIntervalTime'] = 5
	attributes['buffParameter']['INEVITABLEHIT'] = 1
	
	local buff = require("gameroomcore.SBuff").new(self.world,self.heroObj:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,self.heroObj.itemID,self.heroObj.itemID,5)
	self.heroObj:addBuff(buff)

	return hitValue 
end 



return SDemon6005 
