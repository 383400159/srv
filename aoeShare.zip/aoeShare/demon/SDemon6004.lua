local SDemon6004 = class("SDemon6004", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon6004:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon6004" 
	end
	SDemon6004.super.ctor(self,world,heroObj,skillObj) 
end 



return SDemon6004 
