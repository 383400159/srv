local SDemon6002 = class("SDemon6002", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon6002:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon6002" 
	end
	SDemon6002.super.ctor(self,world,heroObj,skillObj) 
end 


return SDemon6002 
