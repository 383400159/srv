local SDemon6003 = class("SDemon6003", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon6003:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon6003" 
	end
	SDemon6003.super.ctor(self,world,heroObj,skillObj) 
end 


--- 發動攻擊後
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon6003:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)
	local ret=SDemon6003.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime,ret) 
	--将击中的人拉到身前
	local obj  = self.world.allItemList[itemID]
	-- local toX,toY = self.world.map:getXYLength(self.heroObj.posX,self.heroObj.posY,obj.posX,obj.posY,obj.attribute.width)
	-- obj:moveTo(self.heroObj.posX+toX,self.heroObj.posY+toY,true,0,10000)
	local skill = self.heroObj.attribute.skills[mode] 
	local parameters = skill.parameters 


	local d =self.world.mPow(self.world.mPow(obj.posX-self.heroObj.posX,2) + self.world.mPow(obj.posY-self.heroObj.posY,2),0.5)
	if d>1 then
		d=d-0.5
	end

	local toX,toY = self.world.map:getXYLength(obj.posX,obj.posY,self.heroObj.posX,self.heroObj.posY,d)
	local ret1

	ret1,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
	--实际距离求速度
	local sd = d
	-- parameters.ABSORDTIME=1
	local bulletSpeed = (sd/parameters.ABSORDTIME)*100
	obj:moveTo(toX,toY,false,5,bulletSpeed,0)
	return ret
end 



return SDemon6003 
