local SDemon6009 = class("SDemon6009", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon6009:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon6009" 
	end
	SDemon6009.super.ctor(self,world,heroObj,skillObj) 
end 


return SDemon6009 
