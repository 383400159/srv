local SDemon6010 = class("SDemon6010", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon6010:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon6010" 
	end
	SDemon6010.super.ctor(self,world,heroObj,skillObj) 
end 


--- 發動攻擊前
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
function SDemon6010:hitTargetPrepare(itemID,bulletID,mode,hitValue,adjTime)
	local obj  = self.world.allItemList[itemID]
	local skill = self.heroObj.attribute.skills[mode] 
	local parameters = skill.parameters 
	if obj.attribute.HP/obj.attribute.MaxHP < parameters.SECKILLHP*0.01 and obj.attribute.actorType~=2 then
		hitValue['FIXHURT'] = obj.attribute.HP + 1000000
	end

	return hitValue
end 



--- 發動攻擊後
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon6010:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)
	local ret=SDemon6010.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime,ret) 
	return ret
end 


return SDemon6010 
