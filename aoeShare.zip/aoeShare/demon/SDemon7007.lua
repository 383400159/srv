local SDemon7007 = class("SDemon7007", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon7007:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon7007" 
	end
	SDemon7007.super.ctor(self,world,heroObj,skillObj) 
	--缓存无敌斩攻击次序
	self.mode3atklist={}
end 

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @param hitValue table - 攻擊參數
-- @return hitValue table - 攻擊參數
function SDemon7007:prepareHit(mode,adjTime,buff,hitValue)
	local ret=SDemon7007.super.prepareHit(self,mode,adjTime,buff,hitValue) 
	--生成攻击列表
	if mode<100 then
		self.mode3atklist={}
		local skill = self.heroObj.attribute.skills[mode] 
		local parameters = skill.parameters 
		local visRange = {posX=self.heroObj.posX,posY=self.heroObj.posY,radius=(skill.useDis/self.world.setting.AdjustAttRange)}
		local dlist = {}
		local atknum = parameters.TARGETNUM
		--local atknum = 10
		local enemy = self.world:runTargetTypeFilter(1,self.heroObj.team,self.heroObj.itemID,{},
		function(obj)
		 	if obj.teamOrig~=self.heroObj.teamOrig then
				ok = true
				if (obj:isDead()) then ok = false end
				if (atknum<=0) then ok = false end
				if ok then
					local d = obj:colliding(visRange,0,0,self.heroObj.itemID)
					----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
					if (d>=0) then 
						atknum = atknum - 1
						dlist[#dlist+1] = obj   
					end
				end
			end
		end
		)
		dlist=table.shuffle(dlist)
		self.mode3atklist=dlist
		if #self.mode3atklist>0 then
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			attributes['buffParameter'] = {}
			attributes['buffParameter']['buffIntervalTime'] = 5
			attributes['buffParameter']['buffType'] = 5
			--local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,0.2,{mode},0,self.heroObj.itemID,self.heroObj.itemID,parameters.ATTACKINTERVAL) 
			local buffObj=require("gameroomcore.SBuff").new(self.world,self.heroObj:__skillID2buffID(skill.skillID),attributes,0.1,{mode},0,self.heroObj.itemID,self.heroObj.itemID,parameters.JUMPINTERVAL) 
			--buffObj.debug = true
			self.heroObj:addBuff(buffObj)
			self.heroObj:D("迷惑攻击 mode3atklist:",#self.mode3atklist,self.world:getGameTime())
			self.heroObj.AIlastCoolDown = self.world:getGameTime() + 1
		end
	end
	--回调攻击
	if mode>100 then
		local skill = self.heroObj.attribute.skills[mode-100] 
		local parameters = skill.parameters 
		local obj = self.mode3atklist[1]
		table.remove(self.mode3atklist,1)
		--闪现到目标身边
		local randlist = self.world.formula:formationPoint(6,obj.attribute.width,true)
		local id = self.world.formula:getRandnum(1,#randlist)
		self.heroObj:moveTo(obj.posX+randlist[id][1],obj.posY+randlist[id][2],true,1)

		local attributes = table.deepcopy(self.heroObj:getPrepareHithitValue())
		attributes['ADADJ'] = parameters.ADADJ2
		attributes['DATKP'] = '7007'
		self.heroObj:directHurtToDalay(mode-100,obj.itemID,attributes,0)


		local attributes = table.deepcopy(self.heroObj:getPrepareHithitValue())
		attributes['BLEED_HURT'] = parameters.BLEED_HURT2
		attributes['BLEED_HURT_RATE'] = parameters.BLEED_HURT_RATE2
		attributes['BUFFTIME'] = parameters.BUFFTIME2
		self.heroObj:directHurtToDalay(mode-100,obj.itemID,attributes,parameters.BLINKDELAY)

		--继续回调
		if #self.mode3atklist>0 then
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			attributes['buffParameter'] = {}
			attributes['buffParameter']['buffIntervalTime'] = 5
			attributes['buffParameter']['buffType'] = 5
			--local buffObj=require("gameroomcore.SBuff").new(self.world,self.heroObj:__skillID2buffID(skill.skillID,0),attributes,0.2,{3},0,self.heroObj.itemID,self.heroObj.itemID,parameters.ATTACKINTERVAL) 
	 		local buffObj=require("gameroomcore.SBuff").new(self.world,self.heroObj:__skillID2buffID(skill.skillID),attributes,0.1,{mode-100},0,self.heroObj.itemID,self.heroObj.itemID,parameters.JUMPINTERVAL)
	 		--buffObj.debug = true
	 		self.heroObj:addBuff(buffObj)
	 		self.heroObj:D("迷惑攻击继续回调 mode3atklist itemID:",obj.itemID,#self.mode3atklist,self.world:getGameTime())
			self.heroObj.AIlastCoolDown = self.world:getGameTime() + 1
		end
		self.heroObj:D("迷惑攻击回调 mode3atklist itemID:",obj.itemID,#self.mode3atklist,self.world:getGameTime())
	end



	return hitValue 
end 




return SDemon7007 