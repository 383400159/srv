local SDemon7005 = class("SDemon7005", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon7005:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon7005" 
	end
	SDemon7005.super.ctor(self,world,heroObj,skillObj) 
end 


return SDemon7005 
