local SDemon5010 = class("SDemon5010", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon5010:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon5010" 
	end
	SDemon5010.super.ctor(self,world,heroObj,skillObj) 
end 



return SDemon5010 