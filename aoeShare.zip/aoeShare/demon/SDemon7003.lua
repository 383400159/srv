local SDemon7003 = class("SDemon7003", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon7003:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon7003" 
	end
	self.mode3list={}
	self.modeatklist={}
	SDemon7003.super.ctor(self,world,heroObj,skillObj) 
	self.targetList = {}
end 

--在目标范围召唤虫洞造成持续每秒%sBB魔法伤害，降低移动速度%sBB，敌方在虫洞内停留超过%s秒后将会眩晕%s秒，虫洞%s秒后自动爆炸造成%sBB魔法伤害。
--MSPD_DOWNFIX_RATE=100;REINJUREDTIME=3;DIZZY_RATE=100;BUFFTIME=3;DELAYTIME=10


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @param hitValue table - 攻擊參數
-- @return hitValue table - 攻擊參數
function SDemon7003:prepareHit(mode,adjTime,buff,hitValue)
		local ret=SDemon7003.super.prepareHit(self,mode,adjTime,buff,hitValue) 
		local skill = self.heroObj.attribute.skills[mode] 
		local parameters = skill.parameters 

		self.heroObj:D("SDemon7003 prepareHit")
		self.mode3list={}

		--找到目标释放一个群体aoe在目标脚下
		local creatureID=self.world:addCreature(self.world.tostring(111),self.heroObj.teamOrig,self.heroObj.lastBulletPositionX,self.heroObj.lastBulletPositionY,self.heroObj,1,0)

		local obj  = self.world.allItemList[creatureID]

		--local lifeTime=parameters.HURTLIFE	
		local lifeTime=parameters.DELAYTIME	
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		
		attributes['buffParameter'] = {}
		attributes['buffParameter']['changeMode']=mode
		attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
		attributes['buffParameter']['creatureDirectHurCallBack'] = "hlszy"
		attributes['buffParameter']['buffChangeHurtMode'] = mode
		attributes['buffParameter']['DATKP'] = "7003"
		-- attributes['buffParameter']['FIXHURT'] = 2
		attributes['buffParameter']['APADJ'] = parameters.APADJ2
		attributes['buffParameter']['MSPD_DOWNFIX_RATE'] = parameters.MSPD_DOWNFIX_RATE2
		attributes['buffParameter']['MSPD_DOWNFIX'] = parameters.MSPD_DOWNFIX2
		attributes['buffParameter']['buffType'] = 1
		--attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
		attributes['buffParameter']['buffIntervalTime'] = 1
		local buff = require("gameroomcore.SBuff").new(self.world,self.heroObj:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,self.heroObj.itemID,creatureID,skill.hitTime)
		buff.debug = true
		obj:addBuff(buff)
		obj:setDeadTime(lifeTime) 
		

		local hitValueNew = table.deepcopy(self.heroObj:getPrepareHithitValue())
		hitValueNew['skillID'] = mode
		hitValueNew['APADJ'] = parameters.APADJ3
		-- hitValueNew['FIXHURT'] = 7
		self.heroObj:directFightAuratoDalay(mode,0,hitValueNew,{posX=self.heroObj.posX,posY=self.heroObj.posY,RANGE=skill.atkDis},lifeTime) 

		--self.heroObj:addStatusList({s=parameters.ADDSELFSTATUS,r=self.world:getGameTime(),t=parameters.ADDSELFSTATUSTIME,i=self.heroObj.itemID})

	return hitValue 
end 


--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon7003:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	local hurt = SDemon7003.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
	if isset(hitValue['creatureDirectHurCallBack']) and hitValue['creatureDirectHurCallBack']=="hlszy"  then 
		self.heroObj:D("流沙 回调.........击中了:",itemID)
		local skill = self.heroObj.attribute.skills[mode] 
		local parameters = skill.parameters 

		self.mode3list[""..itemID] = (self.mode3list[""..itemID]==nil and 0 or self.mode3list[""..itemID]) + 1 
		--停留时间超多少秒
		--debuglog("BOSS2A mode 3 mode3list Num:"..self.mode3list[""..itemID].." itemID:"..itemID)
		if self.mode3list[""..itemID]==parameters.REINJUREDTIME2 then
			local hitValueNew = table.deepcopy(self.heroObj:getPrepareHithitValue())
			
			hitValueNew['INEVITABLEHIT']=1
			hitValueNew['DIZZY_RATE'] = parameters.DIZZY_RATE2 
			hitValueNew['BUFFTIME'] = parameters.BUFFTIME2 
		

			self.heroObj:directHurtToDalay(mode,itemID,hitValueNew,0)
		end
	end
end


--- 發動攻擊後
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
-- function SDemon7003:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)
-- 	local ret=SDemon7003.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime,ret) 

-- 	local skill = self.skillObj
-- 	local parameters = skill.parameters 

-- 	--增加被攻击人的数量
-- 	if self.targetList[""..itemID]==nil then self.targetList[""..itemID]=0 end
-- 	self.targetList[""..itemID] = self.targetList[""..itemID]+1
-- 	--触发晕眩
-- 	if self.targetList[""..itemID]>=parameters.REINJUREDTIME2 then
-- 		-- local obj  = self.world.allItemList[itemID]
-- 		-- local attributes = {}
-- 		-- attributes['DIZZY_RATE'] = parameters.DIZZY_RATE2
-- 		-- attributes['BUFFTIME'] = parameters.BUFFTIME2
-- 		-- local bufftime =parameters.BUFFTIME2
-- 		-- local buff = require("gameroomcore.SBuff").new(self.world,self.heroObj:__skillID2buffID(skill.skillID,0),attributes,bufftime,{},0,self.heroObj.itemID,self.heroObj.itemID,0)
-- 		-- obj:addBuff(buff)

-- 		local hitValueNew = {}
-- 		hitValueNew['DIZZY_RATE']  = parameters.DIZZY_RATE2
-- 		hitValueNew['BUFFTIME']  = parameters.BUFFTIME2
-- 		self.world.allItemList[itemID]:directHurt(self.heroObj.itemID,mode,hitValueNew,0) 
-- 	end

-- 	return ret
-- end 



return SDemon7003 
