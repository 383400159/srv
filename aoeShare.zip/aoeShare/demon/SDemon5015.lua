local SDemon5015 = class("SDemon5015", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon5015:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon5015" 
	end
	SDemon5015.super.ctor(self,world,heroObj,skillObj) 
end 

--- 發動攻擊後
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon5015:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)

	local ret=SDemon5015.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime,ret) 
	--CDTIME=5;ABSORDTIME=0.3;BLASTHURTTIME=0.5;APADJ2
	if hitValue['Effect']~=2 and hitValue['Effect']~=5 then
		local obj = self.world.allItemList[itemID] 
		if self.heroObj.teamOrig~=obj.teamOrig then
			local skill = self.heroObj.attribute.skills[mode] 
			local parameters = skill.parameters 


			local d =self.world.mPow(self.world.mPow(obj.posX-self.heroObj.posX,2) + self.world.mPow(obj.posY-self.heroObj.posY,2),0.5)

			if d>1 then
				d=d-1
			end

			local toX,toY = self.world.map:getXYLength(obj.posX,obj.posY,self.heroObj.posX,self.heroObj.posY,d)
			local ret1
	
			ret1,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
			--实际距离求速度
			local sd = d
			local bulletSpeed = (sd/parameters.ABSORDTIME)*100
			--local bulletSpeed = 9999
			obj:moveTo(toX,toY,false,5,bulletSpeed,0)
			local hitValueNew = table.deepcopy(self.heroObj:getPrepareHithitValue())
			hitValueNew['APADJ']= parameters.APADJ2 
			hitValueNew['DATKP'] = ""..5015
			self.heroObj:directHurtToDalay(mode,obj.itemID,hitValueNew,parameters.BLASTHURTTIME)
			--self.heroObj:directHurtToDalay(3,obj.itemID,hitValueNew,parameters.ABSORDTIME)
		end
	end


	return ret
end 

return SDemon5015 