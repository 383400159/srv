local SDemon5003 = class("SDemon5003", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon5003:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon5003" 
	end
	SDemon5003.super.ctor(self,world,heroObj,skillObj) 
end 

--- 發動攻擊後
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon5003:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)


	local ret = 0


	local obj = self.world.allItemList[itemID] 
	local skill = self.skillObj
	local parameters = skill.parameters 		
	--debuglog("parameters:..."..self.world.cjson.encode(parameters))
	local attackRange = {posX=obj.posX,posY=obj.posY,radius=parameters.EXPLODERANGE/self.world.setting.AdjustAttRange} 

	local hitValueNew = self.heroObj:getPrepareHithitValue()
	
	hitValueNew['skillID'] = mode
	hitValueNew['ADADJ'] = parameters.ADADJ2 + (hitValueNew['ADADJ']~=nil and hitValueNew['ADADJ'] or 0)
	hitValueNew['DATKP'] = ""..5003
	local bullet = require("gameroomcore.SBullet").new(self.world,mode,self.heroObj.itemID,0.2,0,obj.posX,obj.posY)
	bullet.attr.ignoreID = {itemID}
	bullet:directFightAura(mode,attackRange,hitValueNew,bullet.attr.angle,0) 
	bullet:setDead() 
	hitValue['DATKP'] = ""..5003
	if hitValue['ADADJ']==0 then
		hitValue['ADADJ'] = parameters.ADADJ2
	end
	obj:addStatusList({s=8002,r=self.world:getGameTime(),t=1,i=self.heroObj.itemID},0)
	local ret=SDemon5003.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime,ret) 

	return ret
end 

return SDemon5003 