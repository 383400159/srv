local SDemon0 = class("SDemon0", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon0:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon0" 
	end
	SDemon0.super.ctor(self,world,heroObj,skillObj) 
end 

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @param hitValue table - 攻擊參數
-- @return hitValue table - 攻擊參數
function SDemon0:prepareHit(mode,adjTime,buff,hitValue)
	local ret=SDemon0.super.prepareHit(self,mode,adjTime,buff,hitValue) 
	return hitValue 
end 

--- 發動攻擊前
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
function SDemon0:hitTargetPrepare(itemID,bulletID,mode,hitValue,adjTime)
	return hitValue
end 

--- 發動攻擊後
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon0:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)
	local ret=SDemon0.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime,ret) 

	return ret
end 


--- 准备攻击前置设置，在prepareHit之前执行，call父类
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SDemon0:prepareSkillAttackCustom(mode,target,x,y,adjTime,syncMsg)
end 


return SDemon0 