local SDemon5013 = class("SDemon5013", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon5013:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon5013" 
	end
	SDemon5013.super.ctor(self,world,heroObj,skillObj) 
end 

-- --- 發動攻擊後
-- -- @param itemID int - 受傷害方itemID
-- -- @param bulletID int - 子彈ID
-- -- @param mode int - 技能1-7
-- -- @param hitValue table - 計算參數
-- -- @param adjTime float - 調整時間
-- -- @param hurt float - 傷害值
-- function SDemon5013:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)


-- 	local ret = 0


-- 	local obj = self.world.allItemList[itemID] 
-- 	local skill = self.skillObj
-- 	local parameters = skill.parameters 		
-- 	--debuglog("parameters:..."..self.world.cjson.encode(parameters))
-- 	local attackRange = {posX=obj.posX,posY=obj.posY,radius=parameters.EXPLODERANGE/self.world.setting.AdjustAttRange} 

-- 	local hitValueNew = self.heroObj:getPrepareHithitValue()
	
-- 	hitValueNew['skillID'] = mode
-- 	hitValueNew['APADJ'] = parameters.APADJ2 + (hitValueNew['APADJ']~=nil and hitValueNew['APADJ'] or 0)
-- 	local bullet = require("gameroomcore.SBullet").new(self.world,mode,self.heroObj.itemID,0.2,0,obj.posX,obj.posY)
-- 	bullet.attr.ignoreID = {itemID}
-- 	bullet:directFightAura(1,attackRange,hitValueNew,bullet.attr.angle,0) 
-- 	bullet:setDead() 
-- 	hitValue['DATKP'] = ""..5013
-- 	if hitValue['APADJ']==0 then
-- 		hitValue['APADJ'] = parameters.APADJ2
-- 	end
-- 	obj:addStatusList({s=8002,r=self.world:getGameTime(),t=1,i=self.heroObj.itemID},0)
-- 	local ret=SDemon5013.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime,ret) 

-- 	return ret
-- end 

return SDemon5013 