local SDemon5009 = class("SDemon5009", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon5009:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon5009" 
	end
	SDemon5009.super.ctor(self,world,heroObj,skillObj) 
end 



return SDemon5009 