local SDemon7002 = class("SDemon7002", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon7002:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon7002" 
	end
	SDemon7002.super.ctor(self,world,heroObj,skillObj) 
end 


return SDemon7002 
