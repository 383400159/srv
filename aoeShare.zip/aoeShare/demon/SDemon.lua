local SDemon = class("SDemon") 
 
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon" 
	end
	self.heroObj = heroObj
	self.world = self.heroObj.world
	self.skillObj = skillObj
end 

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @param hitValue table - 攻擊參數
-- @return hitValue table - 攻擊參數
function SDemon:prepareHit(mode,adjTime,buff,hitValue)
	return hitValue 
end 

--- 發動攻擊前
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
function SDemon:hitTargetPrepare(itemID,bulletID,mode,hitValue,adjTime)
end 

--- 發動攻擊後
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)
	return ret
end 


--- 准备攻击前置设置，在prepareHit之前执行，call父类
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SDemon:prepareSkillAttackCustom(mode,target,x,y,adjTime,syncMsg)
end 

--- 直接傷害callBack
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
-- @return null
function SDemon:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt)

end



return SDemon 
