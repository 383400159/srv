local SDemon5004 = class("SDemon5004", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon5004:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon5004" 
	end
	SDemon5004.super.ctor(self,world,heroObj,skillObj) 
end 


return SDemon5004 