local SDemon5016 = class("SDemon5016", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon5016:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon5016" 
	end
	SDemon5016.super.ctor(self,world,heroObj,skillObj) 
end 


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @param hitValue table - 攻擊參數
-- @return hitValue table - 攻擊參數
function SDemon5016:prepareHit(mode,adjTime,buff,hitValue)
	local ret=SDemon5016.super.prepareHit(self,mode,adjTime,buff,hitValue) 

	local skill = self.heroObj.attribute.skills[mode] 
	local parameters = skill.parameters 

	local hitValueNew = self.heroObj:getPrepareHithitValue()
	--CDTIME=5;DIZZY_RATE=100;BUFFTIME=3;APADJ2
	local creatureID=self.world:addCreature(self.world.tostring(parameters.ENEMY),self.heroObj.teamOrig,self.heroObj.lastBulletPositionX,self.heroObj.lastBulletPositionY,self.heroObj,1,0)
	local obj  = self.world.allItemList[creatureID]
	local attributes = {} 
	local lifetime = parameters.BUFFTIME2
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['buffParameter']=hitValueNew
	attributes['buffParameter']['changeMode']=mode
	attributes['buffParameter']['RANGE'] = skill.atkDis
	--attributes['buffParameter']['FIXHURT'] = -8
	attributes['buffParameter']['FIXREHP'] = self.world.mAbs(hitValue['APADJ2']*self.heroObj.attribute.ATK*0.01)
	attributes['buffParameter']['DATKP'] = "5016"
	attributes['buffParameter']['buffType'] = 14		
	attributes['buffParameter']['buffIntervalTime'] = skill.bulletTimeInterval
	local buff = require("gameroomcore.SBuff").new(self.world,self.heroObj:__skillID2buffID(skill.skillID),attributes,lifetime,{99},0,self.heroObj.itemID,obj.itemID,skill.hitTime)
	--buff.debug = true
	--self:addBuff(buff)
	obj:addBuff(buff)
	obj:setDeadTime(lifetime) 
	

	return hitValue 
end 


--- 發動攻擊後
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon5016:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)

	local ret=SDemon5016.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime,ret) 


	return ret
end 

return SDemon5016 