local SDemon7001 = class("SDemon7001", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon7001:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon7001" 
	end
	SDemon7001.super.ctor(self,world,heroObj,skillObj) 
end 

--让自身范围内敌方目标马上进入睡眠%s秒，咏唱%s秒后复活自身范围所有友方目标并恢复%sBB魔法伤害生命值。
--CDTIME=120;SLEEP_RATE=100;BUFFTIME=5;DELAYTIME=2;REVIVE_RATE=100;APADJ2=100


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @param hitValue table - 攻擊參數
-- @return hitValue table - 攻擊參數
function SDemon7001:prepareHit(mode,adjTime,buff,hitValue)
	local ret=SDemon7001.super.prepareHit(self,mode,adjTime,buff,hitValue) 
	--debuglog("SDemon7001:prepareHit..................... mode:"..mode)
	--复活友方并恢复生命
	-- if mode>100 then
	-- 	--debuglog("SDemon7001:prepareHit.....................")
	-- 	--获得队友列表
	-- 	if (self.heroObj.teamOrig=="A") then
	-- 		teamlist=self.world.itemListFilter.heroTeamAList
	-- 	else
	-- 		teamlist=self.world.itemListFilter.heroTeamBList
	-- 	end

	-- 	local visRange={posX=self.heroObj.posX,posY=self.heroObj.posY,radius=skill.atkDis/self.world.setting.AdjustVisRange}
	-- 	local targetList = {}
	-- 	--获得身边的死亡队友数量
	-- 	for k,value in pairs(teamlist) do
	-- 		ok = true
	-- 		if (not value:isDead()) then ok =false end
	-- 		if (value.itemID==self.heroObj.itemID) then ok =false end
	-- 		if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
	-- 		if ok then
	-- 			local d = value:colliding(visRange,0,0,self.heroObj.itemID)
	-- 			if d>=0 and n==false then
	-- 				targetList[#targetList+1] = value
	-- 			end
	-- 		end
	-- 	end

	-- 	--复活队友
	-- 	for k,v in pairs(targetList) do
	-- 		v.deadTime=0
	-- 		v.attribute.HP=self.attribute.MaxHP*parameters.REVIVEHP2*0.01+self.world.mAbs(hitValue['APADJ2']*hitValue['ATK']*0.01)
	-- 	end

	-- end
	local skill = self.skillObj
	local parameters = skill.parameters 
	local hitValueNew = table.deepcopy(self.heroObj:getPrepareHithitValue())
	hitValueNew['FIXREHP'] = self.heroObj.attribute.ATK * parameters.APADJ2 * 0.01 
	self.heroObj:directFightAuratoDalay(mode,self.heroObj.itemID,hitValueNew,{posX=self.heroObj.posX,posY=self.heroObj.posY,RANGE=skill.atkDis},skill.hitTime) 
	return hitValue 
end 



return SDemon7001 

