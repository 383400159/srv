local SDemon5017 = class("SDemon5017", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon5017:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon5017" 
	end
	SDemon5017.super.ctor(self,world,heroObj,skillObj) 
end 

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @param hitValue table - 攻擊參數
-- @return hitValue table - 攻擊參數
function SDemon5017:prepareHit(mode,adjTime,buff,hitValue)
	local ret=SDemon5017.super.prepareHit(self,mode,adjTime,buff,hitValue) 

	local toX,toY = self.world.map:getXYLength(self.heroObj.posX,self.heroObj.posY,self.heroObj.lastBulletPositionX,self.heroObj.lastBulletPositionY,100/self.world.setting.AdjustAttRange)
	local ret
	ret,toX,toY=self.world.map:findPointStraightLineNearest(self.heroObj.posX,self.heroObj.posY,self.heroObj.posX+toX,self.heroObj.posY+toY) 

	local CWID=self.world:addCreature(self.world.tostring(803),self.heroObj.teamOrig,toX,toY,self.heroObj,1,0)
	local obj = self.world.allItemList[CWID] 
	--obj.AIlastMoveTime = self.world:getGameTime()+0.2
	obj:setSubName("moling5017")
	obj.nextSkillID = 2
	obj.atkID = self.heroObj.lastBulletTarget
	obj.atkX = self.heroObj.lastBulletPositionX
	obj.atkY = self.heroObj.lastBulletPositionY
	--obj:setDeadTime(5) 
	

	return hitValue 
end 

--- 准备攻击前置设置，在prepareHit之前执行，call父类
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SDemon5017:prepareSkillAttackCustom(mode,target,x,y,adjTime,syncMsg)
	local ret=SDemon5017.super.prepareHit(self,mode,target,x,y,adjTime,syncMsg) 



	-- self.mode2time = self.world:getGameTime()+adjTime
	-- self.mode2bulletID = self.heroObj.lastBulletID
	return ret
end 

--- 發動攻擊後
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon5017:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)


	local ret=SDemon5017.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime,ret) 


	-- if ret>0 then
	-- 	local skill = self.heroObj.attribute.skills[mode] 
	-- 	local parameters = skill.parameters 
	-- 	if self.world:getGameTime()>(self.mode2time+0.1) then
	-- 		local obj = self.world.allItemList[itemID] 
			
	-- 		local toX,toY = self.world.map:getXYLength(self.heroObj.posX,self.heroObj.posY,obj.posX,obj.posY,300/self.world.setting.AdjustAttRange)
	-- 		local isToX,isToY = toX,toY
	-- 		local ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
	
	-- 		obj:moveTo(toX,toY,false,5,1500,0.5)
	-- 		local attributes = table.deepcopy(self.heroObj:getPrepareHithitValue())
	-- 		attributes['DIZZY_RATE'] = 100
	-- 		attributes['Effect'] = -1
	-- 		attributes['BUFFTIME'] = 0.5
	-- 		self.heroObj:directHurtToDalay(mode,obj.itemID,attributes,0)
	-- 		self.world.bulletList[self.mode2bulletID]:setDead()
		

	-- 		local attackRange = {posX=obj.posX,posY=obj.posY,radius=100/self.world.setting.AdjustAttRange} 

	-- 		local hitValueNew = self.heroObj:getPrepareHithitValue()
	-- 		hitValueNew['changeMode']=mode
	-- 		hitValueNew['FIXHURT'] = 11
	-- 		hitValueNew['isToX'] = isToX
	-- 		hitValueNew['isToY'] = isToY
	-- 		local bullet = require("gameroomcore.SBullet").new(self.world,3,self.heroObj.itemID,0.2,0,obj.posX,obj.posY)
	-- 		bullet.attr.ignoreID = {itemID}
	-- 		bullet:directFightAura(1,attackRange,hitValueNew,bullet.attr.angle,0) 
	-- 		bullet:setDead() 

	-- 	end
	-- end

	return ret
end 


--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon5017:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	local hurt = SDemon5017.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
	-- local obj = self.world.allItemList[itemID]
	-- --local toX,toY = self.world.map:getXYLength(self.heroObj.posX,self.heroObj.posY,obj.posX,obj.posY,300/self.world.setting.AdjustAttRange)
	-- local ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+hitValue['isToX'],obj.posY+hitValue['isToY']) 

	-- obj:moveTo(toX,toY,false,5,1500,0.5)
	-- local attributes = table.deepcopy(self.heroObj:getPrepareHithitValue())
	-- attributes['DIZZY_RATE'] = 100
	-- attributes['Effect'] = -1
	-- attributes['BUFFTIME'] = 0.5
	-- self.heroObj:directHurtToDalay(mode,obj.itemID,attributes,0)

end

return SDemon5017 