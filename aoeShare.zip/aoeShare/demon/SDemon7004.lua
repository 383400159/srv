local SDemon7004 = class("SDemon7004", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon7004:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon7004" 
	end
	SDemon7004.super.ctor(self,world,heroObj,skillObj) 
end 


return SDemon7004 
