local SDemon5012 = class("SDemon5012", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon5012:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon5012" 
	end
	SDemon5012.super.ctor(self,world,heroObj,skillObj) 
end 

--- 發動攻擊後
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon5012:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)

	SDemon5012.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime,ret) 
	if ret>0 then
		--清楚仇恨
		self.heroObj:D("魔灵技能 清楚仇恨ID:",itemID)
		local obj = self.world.allItemList[itemID] 
		obj.Hatredlist[""..self.heroObj.itemID] = 0
	end

	return ret
end 

return SDemon5012 