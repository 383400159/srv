local SDemon6001 = class("SDemon6001", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon6001:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon6001" 
	end
	debuglog("SDemon6001....................")
	SDemon6001.super.ctor(self,world,heroObj,skillObj) 
end 

--- 發動攻擊後
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon6001:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)
	debuglog("SDemon6001 hitTarget....................")
	local skill = self.skillObj
	local parameters = skill.parameters 		
	local x=self.heroObj.posX 
	local y=self.heroObj.posY 
	local attackRange = {posX=x,posY=y,radius=(skill.atkDis)/self.world.setting.AdjustAttRange} 
	local hitValueNew=hitValue
	hitValueNew['skillID'] = 4
	hitValueNew['ADADJ'] = parameters.APADJ2
	-- hitValueNew['BLEED_HURTFIX_RATE'] = parameters.BLEED_HURTFIX_RATE2
	-- hitValueNew['BUFFTIME'] = parameters.BUFFTIME2
	hitValueNew['Effect'] = 98
	--hitValueNew = {skillID=6,ADADJ=parameters.ADADJ2,BLEED_HURTFIX_RATE=parameters.BLEED_HURTFIX_RATE2,BUFFTIME=parameters.BUFFTIME2} 
	local bullet = require("gameroomcore.SBullet").new(self.world,4,self.heroObj.itemID,0.2,0,self.heroObj.lastBulletPositionX,self.heroObj.lastBulletPositionY) 
	--bullet.attr.debug = true
	bullet:directFightAura(1,attackRange,hitValueNew,nil,skill.degree)
	for k,v in pairs(bullet.attr.hitID) do

		local obj = self.world.allItemList[v] 
		local skill = self.heroObj.attribute.skills[4] 
		local parameters = skill.parameters 
		
		local toX,toY = self.world.map:getXYLength(self.heroObj.posX,self.heroObj.posY,obj.posX,obj.posY,500/self.world.setting.AdjustAttRange)
		local ret
		ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
		obj:moveTo(toX,toY,false,5,parameters.BACKWARDSPEED,0) 
	end
	bullet:setDead()

	local ret=SDemon6001.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime,ret) 

	return ret
end 



return SDemon6001 
