local SDemon5007 = class("SDemon5007", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon5007:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon5007" 
	end
	SDemon5007.super.ctor(self,world,heroObj,skillObj) 
end 

--- 發動攻擊後
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon5007:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)


	local ret=SDemon5007.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime,ret) 

	if ret>0 then
		local skill = self.heroObj.attribute.skills[mode] 
		local parameters = skill.parameters 
		--CDTIME=5;CONVERHPTIME=1;CONVERHP
		self.heroObj:D("魔灵技能 吸血:",ret)
		local hitValueNew = table.deepcopy(self.heroObj:getPrepareHithitValue())
		hitValueNew['FIXHURT']= -ret * parameters.CONVERHP
		hitValueNew['DATKP'] = '5007'
		self.heroObj:directHurtToDalay(mode,self.heroObj.itemID,hitValueNew,parameters.CONVERHPTIME)
	end
	return ret
end 

return SDemon5007 