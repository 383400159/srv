local SDemon7006 = class("SDemon7006", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon7006:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon7006" 
	end
	SDemon7006.super.ctor(self,world,heroObj,skillObj) 
	--求撞中的人数
	self.atkNum = 0
	--当前的伤害值APADJ
	self.APADJ = 0
end 


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @param hitValue table - 攻擊參數
-- @return hitValue table - 攻擊參數
function SDemon7006:prepareHit(mode,adjTime,buff,hitValue)
	local ret=SDemon7006.super.prepareHit(self,mode,adjTime,buff,hitValue) 
	local skill = self.heroObj.attribute.skills[mode] 
	local parameters = skill.parameters 

	randlist = self.world.formula:formationPoint(6,1,true)
	----debuglog("hitTime_:"..skill.hitTime)
	--debuglog("jaylog SBoss4A:prepareHit: duration"..skill.duration..' buffIntervalTime:'..skill.bulletTimeInterval)
	local id = self.world.formula:getRandnum(1,#randlist)
	local creatureID=self.world:addCreature(self.world.tostring(978),self.heroObj.teamOrig,self.heroObj.posX+randlist[id][1],self.heroObj.posY+randlist[id][2],self.heroObj,1,0)
	local obj  = self.world.allItemList[creatureID]
	obj.autoFightAI.nextPosX = self.heroObj.lastBulletPositionX
	obj.autoFightAI.nextPosY = self.heroObj.lastBulletPositionY	
	local attributes = {}
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['buffParameter'] =  table.deepcopy(self.heroObj:getPrepareHithitValue())
	-- attributes['buffParameter']['APADJ'] = parameters.APADJ2
	attributes['buffParameter']['DIZZY_RATE'] =parameters.DIZZY_RATE2
	attributes['buffParameter']['BUFFTIME'] = parameters.BUFFTIME2
	-- attributes['buffParameter']['FIXHURT'] = 250
	-----debuglog("atkDis:"..parameters.hitTime)
	attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
	attributes['buffParameter']['creatureDirectHurCallBack'] = creatureID
	----debuglog("jaylog addCreature  creatureID:"..creatureID)
	attributes['buffParameter']['buffType'] = 1
	--attributes['buffParameter']['buffAtleastOnce']=true
	attributes['buffParameter']['buffIntervalTime'] = skill.buffIntervalTime
	local buff = require("gameroomcore.SBuff").new(self.world,self.heroObj:__skillID2buffID(skill.skillID,0),attributes,9999,{99},0,self.heroObj.itemID,creatureID,skill.hitTime)
	obj:addBuff(buff)


	self.APADJ  = parameters.APADJ2
	
	return hitValue 
end 

--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon7006:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	local hurt = SDemon7006.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
	if isset(hitValue['creatureDirectHurCallBack']) and hitValue['creatureDirectHurCallBack']=="hlszy"  then 
		self.heroObj:D("流沙 回调.........击中了:",itemID)
		local skill = self.heroObj.attribute.skills[mode] 
		local parameters = skill.parameters 
		local hitValueNew = table.deepcopy(self.heroObj:getPrepareHithitValue())
		hitValueNew['INEVITABLEHIT']=1
		hitValueNew['APADJ'] = self.APADJ
		hitValueNew['DATKP'] = '7006'
		self.APADJ = self.APADJ * (1-parameters.DECREASEHURT)
		self.heroObj:directHurtToDalay(mode,itemID,hitValueNew,0)

	end
end


return SDemon7006 