local SDemon5001 = class("SDemon5001", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon5001:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon5001" 
	end
	--存储玩家被击中的数量
	self.mode3list={}
	self.modeatklist={}
	SDemon5001.super.ctor(self,world,heroObj,skillObj) 
end 

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @param hitValue table - 攻擊參數
-- @return hitValue table - 攻擊參數
function SDemon5001:prepareHit(mode,adjTime,buff,hitValue)
		local ret=SDemon5001.super.prepareHit(self,mode,adjTime,buff,hitValue) 
		local skill = self.heroObj.attribute.skills[mode] 
		local parameters = skill.parameters 
		--HURTLIFE=4.5;HURTSTARTTIME=2;HURTITNTERVAL=0.5;ENEMY=277
		--CDTIME=5;DIZZY_RATE2=100;BUFFTIME2=3
		self.heroObj:D("SDemon5001 prepareHit")
		self.mode3list={}

		--找到目标释放一个群体aoe在目标脚下
		local creatureID=self.world:addCreature(self.world.tostring(parameters.ENEMY),self.heroObj.teamOrig,self.heroObj.lastBulletPositionX,self.heroObj.lastBulletPositionY,self.heroObj,1,0)

		local obj  = self.world.allItemList[creatureID]

		local lifeTime=parameters.HURTLIFE	
		-- local lifeTime=5	
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		
		attributes['buffParameter'] = {}
		attributes['buffParameter']['changeMode']=mode
		attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
		attributes['buffParameter']['creatureDirectHurCallBack'] = "hlszy"
		attributes['buffParameter']['buffChangeHurtMode'] = mode
		attributes['buffParameter']['DATKP'] = "5001"
		attributes['buffParameter']['FIXHURT'] = 2
		attributes['buffParameter']['buffType'] = 1
		--attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
		attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
		local buff = require("gameroomcore.SBuff").new(self.world,self.heroObj:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,self.heroObj.itemID,creatureID,parameters.HURTSTARTTIME)
		buff.debug = true
		obj:addBuff(buff)
		obj:setDeadTime(lifeTime) 
		

		--self.heroObj:addStatusList({s=parameters.ADDSELFSTATUS,r=self.world:getGameTime(),t=parameters.ADDSELFSTATUSTIME,i=self.heroObj.itemID})

	return hitValue 
end 


--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SDemon5001:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	local hurt = SDemon5001.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
	if isset(hitValue['creatureDirectHurCallBack']) and hitValue['creatureDirectHurCallBack']=="hlszy"  then 
		self.heroObj:D("流沙 回调.........击中了:",itemID)
		local skill = self.heroObj.attribute.skills[mode] 
		local parameters = skill.parameters 

		self.mode3list[""..itemID] = (self.mode3list[""..itemID]==nil and 0 or self.mode3list[""..itemID]) + 1 
		--停留时间超多少秒
		--debuglog("BOSS2A mode 3 mode3list Num:"..self.mode3list[""..itemID].." itemID:"..itemID)
		if self.mode3list[""..itemID]==4 then
			local hitValueNew = table.deepcopy(self.heroObj:getPrepareHithitValue())
			
			hitValueNew['INEVITABLEHIT']=1
			hitValueNew['DIZZY_RATE'] = parameters.DIZZY_RATE2 
			hitValueNew['BUFFTIME'] = parameters.BUFFTIME2 
		

			self.heroObj:directHurtToDalay(mode,itemID,hitValueNew,0)
		end
	end
end


return SDemon5001 