local SDemon5014 = class("SDemon5014", require("gameroom.demon.SDemon"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SDemon5014:ctor(world,heroObj,skillObj) 
	if (self.className==nil) then 
		self.className = "SDemon5014" 
	end
	SDemon5014.super.ctor(self,world,heroObj,skillObj) 
end 


return SDemon5014 