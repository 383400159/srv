local GameFlow = class("GameFlow")

--- Constructor
-- @param world object - world object
-- @return null
function GameFlow:ctor(world)
	if self.className==nil then
		self.className = 'GameFlow'
	end
	self.world = world
	-- self.world:D('jaylog in gameflow ctor')
end

--- 检查流程条件
-- @param condition table - 条件table
-- @param extraConditionIn table - 条件的附加参数
-- @return boolean
function GameFlow:checkCondition(conditon,extraConditionIn)
	-- self.world:D('jaylog GameFlow:checkCondition conditon:',self.world.cjson.encode(conditon),' extra:',self.world.cjson.encode(extraConditionIn),' part:',self.partType,' subPart:',self.partSubType,self.world.partStartTime,self.world.partMoveEndTime,self.world.gameTime)
	local extraCondition = self.world.tDeepcopy(extraConditionIn)
	for k,v in pairs(conditon) do
		if self.world.sFind(v,'NOCONDITION')~=nil then
			return true
		end
		if self.world.allItemList[1]~=nil and self.world.allItemList[1].attribute.school==1 then
			for cgK,cgV in pairs(extraCondition) do
				if self.world.sFind(cgK,'_YH')~=nil then
					local nameArr = self.world.sSplit(cgK,'_')
					-- self.world:D('jaylog changeConParam 1:',nameArr[1],cgK)
					extraCondition[nameArr[1]] = extraCondition[cgK]
				end
			end
		end
		if self.world.allItemList[1]~=nil and self.world.allItemList[1].attribute.school==2 then
			for cgK,cgV in pairs(extraCondition) do
				if self.world.sFind(cgK,'_NP')~=nil then
					local nameArr = self.world.sSplit(cgK,'_')
					-- self.world:D('jaylog changeConParam 2:',nameArr[1],cgK)
					extraCondition[nameArr[1]] = extraCondition[cgK]
				end
			end
		end
		-- 坐标除以2
		-- self.world:D('jaylog checkCondition start POSITION:',self.world.cjson.encode(extraCondition['POSITION']),self.world.cjson.encode(extraCondition['POSITIONS']))
		if extraCondition['POSITION']~=nil then
			for pk,pv in pairs(extraCondition['POSITION']) do
				if pk<3 then
					extraCondition['POSITION'][pk] = pv*0.5
				end
			end
		end
		if extraCondition['POSITIONS']~=nil then
			for pk,pv in pairs(extraCondition['POSITIONS']) do
				for psk,psv in pairs(pv) do
					if psk<3 then
						extraCondition['POSITIONS'][pk][psk] = psv*0.5
					end
				end
			end
		end
		if extraCondition['RADIUS']~=nil then
			for pk,pv in pairs(extraCondition['RADIUS']) do
				extraCondition['RADIUS'][pk] = pv*0.5
			end
		end
		-- self.world:D('jaylog checkCondition end POSITION:',self.world.cjson.encode(extraCondition['POSITION']),self.world.cjson.encode(extraCondition['POSITIONS']))
		if self.world.sFind(v,'TRIGGER')~=nil or self.world.sFind(v,'ROLEHP')~=nil then
			--self.world:debuglog('jaylog GameFlow:checkCondition k:'..k..' v:'..self.world.cjson.encode(v))
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v=='TRIGGERCIRCLE' and v1.actorType==0 then
					if extraCondition['SUBNAME']~=nil then
						if v1.subName==extraCondition['SUBNAME'][1] then
							local distance = self.world.map:distance(v1.posX,v1.posY,extraCondition['POSITION'][1],extraCondition['POSITION'][2])
							-- self.world:D('jaylog TRIGGERCIRCLE ',distance,self.world.cjson.encode(extraCondition['RADIUS']),v1.attribute.roleId,v1.itemID,v1.posX,v1.posY,self.world.cjson.encode(extraCondition['POSITION']))
							if distance<extraCondition['RADIUS'][1] then
								return true
							end
						end
					elseif extraCondition['ITEMID']~=nil then
						if v1.itemID==extraCondition['ITEMID'][1] then
							local distance = self.world.map:distance(v1.posX,v1.posY,extraCondition['POSITION'][1],extraCondition['POSITION'][2])
							-- self.world:D('jaylog TRIGGERCIRCLE ',distance,self.world.cjson.encode(extraCondition['RADIUS']),v1.attribute.roleId,v1.itemID,v1.posX,v1.posY,self.world.cjson.encode(extraCondition['POSITION']))
							if distance<extraCondition['RADIUS'][1] then
								return true
							end
						end
					else
						local distance = self.world.map:distance(v1.posX,v1.posY,extraCondition['POSITION'][1],extraCondition['POSITION'][2])
						-- self.world:D('jaylog TRIGGERCIRCLE ',distance,self.world.cjson.encode(extraCondition['RADIUS']))
						if distance<extraCondition['RADIUS'][1] then
							return true
						end
					end
				elseif self.world.sFind(v,'TRIGGER')~=nil and v1.actorType==0 then
					local sx = extraCondition['POSITIONS'][1][1]
					local sy = extraCondition['POSITIONS'][1][2]
					local ex = extraCondition['POSITIONS'][2][1]
					local ey = extraCondition['POSITIONS'][2][2]
					if extraCondition['POSITIONS'][1][1]>extraCondition['POSITIONS'][2][1] then
						sx = extraCondition['POSITIONS'][2][1]
						ex = extraCondition['POSITIONS'][1][1]
					end
					if extraCondition['POSITIONS'][1][2]>extraCondition['POSITIONS'][2][2] then
						sy = extraCondition['POSITIONS'][2][2]
						ey = extraCondition['POSITIONS'][1][2]
					end
					if self.world.sFind(v,'ALL')~=nil then
						if sx>v1.posX or v1.posX>ex and sy>v1.posY or v1.posY>ey then
							-- self.world:D('jaylog GameFlow:checkCondition All position: sx:'..sx..' '..v1.posX..' ex:'..ex..' sy:'..sy..' '..v1.posY..' ey:'..ey)
							return false
						end
					elseif extraCondition['SUBNAME']~=nil then
						if v1.subName==extraCondition['SUBNAME'][1] then
							if sx<=v1.posX and v1.posX<=ex and sy<=v1.posY and v1.posY<=ey then
								return true
							end
						end
					elseif extraCondition['ITEMID']~=nil then
						if v1.itemID==extraCondition['ITEMID'][1] then
							if sx<=v1.posX and v1.posX<=ex and sy<=v1.posY and v1.posY<=ey then
								return true
							end
						end
					else
						-- self.world:D('jaylog GameFlow:checkCondition notAll position: sx:',sx,v1.posX,' ex:',ex,' sy:',sy,v1.posY,' ey:',ey,'itemID:',v1.itemID)
						if sx<=v1.posX and v1.posX<=ex and sy<=v1.posY and v1.posY<=ey then
							return true
						end
					end
				end
				if self.world.sFind(v,'ROLEHP')~=nil then
					if extraCondition['SUBNAME'][1]==v1.subName then
						if self.world.sFind(v,'LESS') then
							if v1.attribute.HP<=(v1.attribute.MaxHP*extraCondition['NUM'][1]*0.01) then
								return true
							end
						end
						if self.world.sFind(v,'MORE') then
							if v1.attribute.HP>=(v1.attribute.MaxHP*extraCondition['NUM'][1]*0.01) then
								return true
							end
						end
					end
				end
			end
			for k1,v1 in pairs(self.world.itemListFilter.soldierList) do
				if v=='TRIGGERCIRCLE' then
					if extraCondition['SUBNAME']~=nil then
						if v1.subName==extraCondition['SUBNAME'][1] then
							local distance = self.world.map:distance(v1.posX,v1.posY,extraCondition['POSITION'][1],extraCondition['POSITION'][2])
							self.world:D('jaylog TRIGGERCIRCLE ',distance,self.world.cjson.encode(extraCondition['RADIUS']),v1.attribute.roleId,v1.itemID,v1.posX,v1.posY,self.world.cjson.encode(extraCondition['POSITION']))
							if distance<extraCondition['RADIUS'][1] then
								return true
							end
						end
					elseif extraCondition['ITEMID']~=nil then
						if v1.itemID==extraCondition['ITEMID'][1] then
							local distance = self.world.map:distance(v1.posX,v1.posY,extraCondition['POSITION'][1],extraCondition['POSITION'][2])
							self.world:D('jaylog TRIGGERCIRCLE ',distance,self.world.cjson.encode(extraCondition['RADIUS']),v1.attribute.roleId,v1.itemID,v1.posX,v1.posY,self.world.cjson.encode(extraCondition['POSITION']))
							if distance<extraCondition['RADIUS'][1] then
								return true
							end
						end
					end
				elseif self.world.sFind(v,'TRIGGER')~=nil then
					local sx = extraCondition['POSITIONS'][1][1]
					local sy = extraCondition['POSITIONS'][1][2]
					local ex = extraCondition['POSITIONS'][2][1]
					local ey = extraCondition['POSITIONS'][2][2]
					if extraCondition['POSITIONS'][1][1]>extraCondition['POSITIONS'][2][1] then
						sx = extraCondition['POSITIONS'][2][1]
						ex = extraCondition['POSITIONS'][1][1]
					end
					if extraCondition['POSITIONS'][1][2]>extraCondition['POSITIONS'][2][2] then
						sy = extraCondition['POSITIONS'][2][2]
						ey = extraCondition['POSITIONS'][1][2]
					end
					if extraCondition['SUBNAME']~=nil then
						if v1.subName==extraCondition['SUBNAME'][1] then
							if sx<=v1.posX and v1.posX<=ex and sy<=v1.posY and v1.posY<=ey then
								return true
							end
						end
					elseif extraCondition['ITEMID']~=nil then
						if v1.itemID==extraCondition['ITEMID'][1] then
							if sx<=v1.posX and v1.posX<=ex and sy<=v1.posY and v1.posY<=ey then
								return true
							end
						end
					end
				end
				if self.world.sFind(v,'ROLEHP')~=nil then
					if extraCondition['SUBNAME'][1]==v1.subName then
						if self.world.sFind(v,'LESS') then
							if v1.attribute.HP<=(v1.attribute.MaxHP*extraCondition['NUM'][1]*0.01) then
								return true
							end
						end
						if self.world.sFind(v,'MORE') then
							if v1.attribute.HP>=(v1.attribute.MaxHP*extraCondition['NUM'][1]*0.01) then
								return true
							end
						end
					end
				end
			end
			if self.world.sFind(v,'TRIGGER')~=nil and self.world.sFind(v,'ALL')~=nil then
				return true
			end
		end
		if self.world.sFind(v,'ROLESHP')~=nil then
			local hp1 = 9999999
			local hp2 = 9999999
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.subName==extraCondition['SUBNAME'][1] then
					hp1 = v1.attribute.HP
				end
				if v1.subName==extraCondition['SUBNAME'][2] then
					hp2 = v1.attribute.HP
				end
			end
			if hp1<=extraCondition['NUM'][1] and hp2<=extraCondition['NUM'][1] then
				return true
			else
				return false
			end
		end
		if self.world.sFind(v,'KILL')~=nil then
			if self.world.sFind(v,'NOBEFIGHT')~=nil then
				for k,v in pairs(self.world.itemListFilter.noBeFightList) do
					if v.subName==extraCondition['SUBNAME'][1] and not v:isDead() then
						self.world:D('jaylog KILLNOBEFIGHT 1 not dead ',v.subName,v.itemID,v.attribute.roleId)
						return false
					end
					if extraCondition['SUBNAME'][2]~=nil then
						for k1,v1 in pairs(extraCondition['SUBNAME']) do
							if k1~=1 then
								if v.subName==v1 and not v:isDead() then
									self.world:D('jaylog KILLNOBEFIGHT 2 not dead ',v.subName,v.itemID,v.attribute.roleId)
									return false
								end
							end
						end
					end
				end
			elseif v=='KILLCOUNT' then
				local totalNum = 0
				-- self.world:D('jaylog KILLCOUNT SUBNAME:',self.world.cjson.encode(extraCondition['SUBNAME']))
				for k1,v1 in pairs(extraCondition['SUBNAME']) do
					if self.world.subNameDeadCounter[v1]~=nil then
						-- self.world:D('jaylog KILLCOUNT:',v1,self.world.subNameDeadCounter[v1])
						totalNum = totalNum + self.world.subNameDeadCounter[v1]
					end
				end
				if totalNum>=extraCondition['NUM'][1] then
					return true
				else
					return false
				end
			else
				--self.world:debuglog('jaylog GameFlow:checkCondition k:'..k..' v:'..self.world.cjson.encode(v))
				-- for k1,v1 in pairs(self.monsterGroup) do
				-- 	if self.world.itemListFilter.soldierList[v1]~=nil and not self.world.itemListFilter.soldierList[v1]:isDead() then
				-- 		return false
				-- 	end
				-- end
				--debuglog('jaylog KILL start time:'..self.world.gameTime)
				for k,v in pairs(self.world.itemListFilter.heroList) do
					if v.subName==extraCondition['SUBNAME'][1] and not v:isDead() then
						self.world:D('jaylog KILLED 1 not dead ',v.subName,v.itemID,v.attribute.roleId)
						return false
					end
					if extraCondition['SUBNAME'][2]~=nil then
						for k1,v1 in pairs(extraCondition['SUBNAME']) do
							if k1~=1 then
								if v.subName==v1 and not v:isDead() then
									self.world:D('jaylog KILLED 2 not dead ',v.subName,v.itemID,v.attribute.roleId)
									return false
								end
							end
						end
					end
				end
				if self.world.sFind(v,'REAL')~=nil then
					for k,v in pairs(self.world.itemListFilter.soldierList) do
						if v.subName==extraCondition['SUBNAME'][1] and not v.isRelease then
							return false
						end
						if extraCondition['SUBNAME'][2]~=nil then
							for k1,v1 in pairs(extraCondition['SUBNAME']) do
								if k1~=1 then
									if v.subName==v1 and not v.isRelease then
										return false
									end
								end
							end
						end
					end
				else
					for k,v in pairs(self.world.itemListFilter.soldierList) do
						if v.subName==extraCondition['SUBNAME'][1] and not v:isDead() then
							self.world:D('jaylog KILLED 3 not dead ',v.subName,v.itemID,v.attribute.roleId)
							return false
						end
						if extraCondition['SUBNAME'][2]~=nil then
							for k1,v1 in pairs(extraCondition['SUBNAME']) do
								if k1~=1 then
									if v.subName==v1 and not v:isDead() then
										self.world:D('jaylog KILLED 4 not dead ',v.subName,v.itemID,v.attribute.roleId)
										return false
									end
								end
							end
						end
					end
				end
				--debuglog('jaylog KILL end time:'..self.world.gameTime)
			end
			return true
		end
		if v=='INSITELESS' then
			local num = 0
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.subName==extraCondition['SUBNAME'][1] and not v1:isDead() then
					num = num + 1
				end
			end
			for k1,v1 in pairs(self.world.itemListFilter.soldierList) do
				if v1.subName==extraCondition['SUBNAME'][1] and not v1:isDead() then
					num = num + 1
				end
			end
			if num<extraCondition['NUM'][1] then
				return true
			else
				return false
			end
		end
		if v=='HITMORE' then
			local num = 0
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if extraCondition['SUBNAME']~=nil and v1.subName==extraCondition['SUBNAME'][1] then
					self.world:D('jaylog HITMORE subName',extraCondition['SUBNAME'][1],self.world.cjson.encode(v1.stepCounter),self.world.partType,self.world.partSubType)
					num = num + self.world.tonumber(v1.stepCounter[extraCondition['MODE'][1]])
				end
				if extraCondition['ITEMID']~=nil and v1.itemID==extraCondition['ITEMID'][1] then
					self.world:D('jaylog HITMORE itemID',extraCondition['ITEMID'][1],self.world.cjson.encode(v1.stepCounter),self.world.partType,self.world.partSubType)
					num = num + self.world.tonumber(v1.stepCounter[extraCondition['MODE'][1]])
				end
			end
			self.world:D('jaylog HITMORE ',num,extraCondition['NUM'][1],self.world.partType,self.world.partSubType)
			if num>=extraCondition['NUM'][1] then
				return true
			else
				return false
			end
		end
		if v=='EXISTSTATUS' then
			self.world:D('jaylog EXISTSTATUS 1 ',self.world.cjson.encode(extraCondition))
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if extraCondition['SUBNAME']~=nil and v1.subName==extraCondition['SUBNAME'][1] then
					if v1.statusList[extraCondition['ID'][1]]~=nil then
						return true
					end
				end
				if extraCondition['ITEMID']~=nil and v1.itemID==extraCondition['ITEMID'][1] then
					if v1.statusList[extraCondition['ID'][1]]~=nil then
						self.world:D('jaylog EXISTSTATUS 2 ',self.world.cjson.encode(extraCondition))
						return true
					end
				end
			end
			self.world:D('jaylog EXISTSTATUS 3 ',self.world.cjson.encode(extraCondition))
			return false
		end
		if self.world.sFind(v,'GAMETIME')~=nil then
			if extraCondition['NUM'][1]<self.world.gameTime then
				return true
			else
				return false
			end
		end
		if self.world.sFind(v,'LOGINONLINE')~=nil then
			local num = 0
			for k,v in pairs(self.world.itemListFilter.heroList) do
				if v.actorType==0 and v.parent==nil and self.world.playerList[k]~=nil and self.world.playerList[k]['online'] then
					num = num + 1
				end
			end
			if extraCondition['NUM'][1]<=num then
				return true
			else
				return false
			end
		end
		if self.world.sFind(v,'LOGINALLONLINE')~=nil then
			local num = 0
			for k,v in pairs(self.world.itemListFilter.heroList) do
				if v.actorType==0 and v.parent==nil and self.world.playerList[k]~=nil and self.world.playerList[k]['online'] then
					num = num + 1
				end
			end
			if (self.world.gameRoomSetting['maxPlayer']+self.world.gameRoomSetting['AIMaxPlayer'])<=num then
				return true
			else
				return false
			end
		end
		if self.world.sFind(v,'GUIDESTEP')~=nil then
			local roleId = self.world.tonumber(self.world.itemListFilter.heroList[1].attribute.roleId)
			if extraCondition['NUM'][roleId]~=nil then
				extraCondition['NUM'][1] = extraCondition['NUM'][roleId]
			end
			if self.world.guideStep==extraCondition['NUM'][1] then
				return true
			else
				return false
			end
		end
		if v=='FINISHTASK' then
			for k,v in pairs(self.world.itemListFilter.heroList) do
				if v.actorType==0 and not v:isAIObj() then
					self.world:D('jaylog FINISHTASK taskList:',self.world.cjson.encode(v.taskObj.taskList),self.world.worldNum)
					for k1,v1 in pairs(v.taskObj.taskList) do
						if self.world.tonumber(k1)>0 then
							for k2,v2 in pairs(v1) do
								for k3,v3 in pairs(v2['tasks']) do
									-- self.world:D('jaylog k3',k3,'gameWin_'..self.world.worldNum,' finish:',v2['finish'])
									if k3=='gameWin_'..self.world.worldNum and self.world.tonumber(v2['finish'])==2 then
										return true
									end
								end
							end
						end
					end
				end
			end
			return false
		end
		if self.world.sFind(v,'HEROSP')~=nil then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.actorType==0 and ((extraCondition['SUBNAME']~=nil and v1.subName==extraCondition['SUBNAME'][1]) or (extraCondition['ITEMID']~=nil and v1.itemID==extraCondition['ITEMID'][1])) then
					if self.world.sFind(v,'MORE')~=nil then
						if v1.SP>=extraCondition['NUM'][1] then
							return true
						end
					end
					if self.world.sFind(v,'LESS')~=nil then
						if v1.SP<=extraCondition['NUM'][1] then
							return true
						end
					end
				end
			end
			return false
		end
		if self.world.sFind(v,'RUNEXTRACHECK')~=nil then
			--self.world:debuglog('jaylog GameFlow:checkCondition runExtraCheck')
			return self.world:runExtraCheck()
		end
	end
end

-- function GameFlow:runExtraCheck()
-- 	return true
-- end

--- 执行流程的动作
-- @param parameter table - 执行触发KEY
-- @param extraParamIn table - 执行的内容
-- @return parameter table - 返回未执行完的触发KEY
function GameFlow:excuteParam(parameter,extraParamIn)
	self.world:D('jaylog GameFlow:excuteParam param:',self.world.cjson.encode(parameter),' extra:',self.world.cjson.encode(extraParamIn))
	local extraParam = self.world.tDeepcopy(extraParamIn)
	for k,v in pairs(parameter) do
		local flow = {}
		-- 如有永恒或涅槃数据，转换永恒或涅槃数据
		if self.world.allItemList[1]~=nil and self.world.allItemList[1].attribute.school==1 then
			for cgK,cgV in pairs(extraParam) do
				if self.world.sFind(cgK,'_YH')~=nil then
					local nameArr = self.world.sSplit(cgK,'_')
					-- self.world:D('jaylog changeParam 1:',nameArr[1],cgK)
					extraParam[nameArr[1]] = extraParam[cgK]
				end
			end
		end
		if self.world.allItemList[1]~=nil and self.world.allItemList[1].attribute.school==2 then
			for cgK,cgV in pairs(extraParam) do
				if self.world.sFind(cgK,'_NP')~=nil then
					local nameArr = self.world.sSplit(cgK,'_')
					-- self.world:D('jaylog changeParam 2:',nameArr[1],cgK)
					extraParam[nameArr[1]] = extraParam[cgK]
				end
			end
		end
		if extraParam['MATCHKEY']~=nil then
			for k1,v1 in pairs(extraParam['MATCHKEY']) do
				local ID = self.world.itemListFilter.heroList[1].attribute.roleId
				local matchData = self:getMatchData(ID,self.world.mapModel)
				self.world:D('jaylog MATCHKEY matchData:',self.world.cjson.encode(matchData))
				if matchData~=nil and not empty(matchData) and v1~='0' then
					if extraParam['ID']~=nil then
						extraParam['ID'][k1] = matchData[extraParam['MATCHKEY'][k1]]['ID']
					end
					if extraParam['CHANGENAME']~=nil then
						extraParam['CHANGENAME'][k1] = matchData[extraParam['MATCHKEY'][k1]]['NAME']
					end
					if extraParam['ROLEID']~=nil then
						extraParam['ROLEID'][k1] = matchData[extraParam['MATCHKEY'][k1]]['ID']
					end
				end
			end
		end
		-- 防止漏填ID
		if extraParam['IDNEAR']~=nil then
			extraParam['ID'] = extraParam['IDNEAR']
		end
		if extraParam['IDFAR']~=nil then
			extraParam['ID'] = extraParam['IDFAR']
		end
		-- 坐标除以2
		if extraParam['POSITION']~=nil then
			for pk,pv in pairs(extraParam['POSITION']) do
				if pk<3 then
					extraParam['POSITION'][pk] = pv*0.5
				end
			end
		end
		if extraParam['POSITIONOFFSET']~=nil then
			for pk,pv in pairs(extraParam['POSITIONOFFSET']) do
				if pk<3 then
					extraParam['POSITIONOFFSET'][pk] = pv*0.5
				end
			end
		end
		if extraParam['POSITIONS']~=nil then
			for pk,pv in pairs(extraParam['POSITIONS']) do
				for psk,psv in pairs(pv) do
					if psk<3 then
						extraParam['POSITIONS'][pk][psk] = psv*0.5
					end
				end
			end
		end
		if extraParam['POSITIONTO']~=nil then
			for pk,pv in pairs(extraParam['POSITIONTO']) do
				if pk<3 then
					extraParam['POSITIONTO'][pk] = pv*0.5
				end
			end
		end
		if extraParam['POSITIONSTO']~=nil then
			for pk,pv in pairs(extraParam['POSITIONSTO']) do
				for psk,psv in pairs(pv) do
					if psk<3 then
						extraParam['POSITIONSTO'][pk][psk] = psv*0.5
					end
				end
			end
		end
		if extraParam['TRANSPOSITIONSET']~=nil then
			for pk,pv in pairs(extraParam['TRANSPOSITIONSET']) do
				for psk,psv in pairs(pv) do
					if psk~=1 then
						extraParam['TRANSPOSITIONSET'][pk][psk] = psv*0.5
					end
				end
			end
		end
		if extraParam['AUTOTRANSPOSITIONSET']~=nil then
			for pk,pv in pairs(extraParam['AUTOTRANSPOSITIONSET']) do
				for psk,psv in pairs(pv) do
					extraParam['AUTOTRANSPOSITIONSET'][pk][psk] = psv*0.5
				end
			end
		end
		if extraParam['TRANSPOSITIONMOVE']~=nil then
			for pk,pv in pairs(extraParam['TRANSPOSITIONMOVE']) do
				extraParam['TRANSPOSITIONMOVE'][pk] = pv*0.5
			end
		end
		for i=1,10 do
			if extraParam['CIRCLE'..i]~=nil then
				if extraParam['CIRCLE'..i]['POSX']~=nil then
					extraParam['CIRCLE'..i]['POSX'] = extraParam['CIRCLE'..i]['POSX']*0.5
				end
				if extraParam['CIRCLE'..i]['POSY']~=nil then
					extraParam['CIRCLE'..i]['POSY'] = extraParam['CIRCLE'..i]['POSY']*0.5
				end
			end
		end
		if extraParam['RADIUS']~=nil then
			for pk,pv in pairs(extraParam['RADIUS']) do
				extraParam['RADIUS'][pk] = pv*0.5
			end
		end
		if self.world.sFind(v,'NEW')~=nil then
			--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v))
			if extraParam['ID']~=nil then
				local noAI = 0
				if self.world.sFind(v,'NOAI')~=nil then
					noAI = 1
				end
				if extraParam['ID'][1]>99 and extraParam['ID'][1]<1000 then
					local blockLen = 0 		--长度
					local blockWidth = 0 	--角度
					local pos = {}
					--if self.world.sFind(v,'BLOCK')~=nil then
					if self.world.sFind(v,'MULTI')~=nil then
						local blockPos = {{},{}}
						if extraParam['POSITIONS'][1][1]<extraParam['POSITIONS'][2][1] then
							blockPos[1][1] = extraParam['POSITIONS'][1][1]
							blockPos[2][1] = extraParam['POSITIONS'][2][1]
						else
							blockPos[1][1] = extraParam['POSITIONS'][2][1]
							blockPos[2][1] = extraParam['POSITIONS'][1][1]
						end
						if extraParam['POSITIONS'][1][2]<extraParam['POSITIONS'][2][2] then
							blockPos[1][2] = extraParam['POSITIONS'][1][2]
							blockPos[2][2] = extraParam['POSITIONS'][2][2]
						else
							blockPos[1][2] = extraParam['POSITIONS'][2][2]
							blockPos[2][2] = extraParam['POSITIONS'][1][2]
						end
						pos[#pos+1] = {{blockPos[1][1],blockPos[1][2]},{blockPos[1][1],blockPos[2][2]}}
						pos[#pos+1] = {{blockPos[1][1],blockPos[1][2]},{blockPos[2][1],blockPos[1][2]}}
						pos[#pos+1] = {{blockPos[2][1],blockPos[1][2]},{blockPos[2][1],blockPos[2][2]}}
						pos[#pos+1] = {{blockPos[1][1],blockPos[2][2]},{blockPos[2][1],blockPos[1][2]}}
					else
						pos[#pos+1] = extraParam['POSITIONS']
					end
					if #pos>0 then
						-- self.world:D('jaylog NEWMULTIBLOCK pos:',self.world.cjson.encode(pos))
						for posk,posv in pairs(pos) do
							extraParam['POSITIONS'] = posv
							if extraParam['POSITIONS']~=nil then	
								local x = 0
								local y = 0
								if extraParam['POSITIONS'][1][1]==extraParam['POSITIONS'][2][1] then
									blockLen = self.world.mAbs(extraParam['POSITIONS'][2][2]-extraParam['POSITIONS'][1][2])
									blockWidth = 90
									x = extraParam['POSITIONS'][1][1]
									if extraParam['POSITIONS'][2][2]>extraParam['POSITIONS'][1][2] then
										y = blockLen*0.5+extraParam['POSITIONS'][1][2]
									else
										y = blockLen*0.5+extraParam['POSITIONS'][2][2]
									end
									self.world:D('jaylog GameFlow:excuteParam blockLen:',blockLen,'blockWidth',blockWidth)
								end
								if extraParam['POSITIONS'][1][2]==extraParam['POSITIONS'][2][2] then
									blockLen = self.world.mAbs(extraParam['POSITIONS'][2][1]-extraParam['POSITIONS'][1][1])
									blockWidth = 0
									if extraParam['POSITIONS'][2][1]>extraParam['POSITIONS'][1][1] then
										x = blockLen*0.5+extraParam['POSITIONS'][1][1]
									else
										x = blockLen*0.5+extraParam['POSITIONS'][2][1]
									end
									y = extraParam['POSITIONS'][1][2]
									self.world:D('jaylog GameFlow:excuteParam blockLen:',blockLen,'blockWidth',blockWidth)
								end
								if extraParam['POSITIONS'][1][1]~=extraParam['POSITIONS'][2][1] and extraParam['POSITIONS'][1][2]~=extraParam['POSITIONS'][2][2] then 
									blockLen = self.world.mPow(self.world.mPow(extraParam['POSITIONS'][2][1]-extraParam['POSITIONS'][1][1],2)+self.world.mPow(extraParam['POSITIONS'][2][2]-extraParam['POSITIONS'][1][2],2),0.5)
									x = (extraParam['POSITIONS'][1][1]+extraParam['POSITIONS'][2][1])*0.5
									y = (extraParam['POSITIONS'][1][2]+extraParam['POSITIONS'][2][2])*0.5
									-- blockWidth = self.world:getAngle(extraParam['POSITIONS'][1][1],extraParam['POSITIONS'][1][2],extraParam['POSITIONS'][2][1],extraParam['POSITIONS'][2][2])
									blockWidth = self.world.mDeg(self.world.mAtan2((extraParam['POSITIONS'][2][2]-extraParam['POSITIONS'][1][2]),(extraParam['POSITIONS'][2][1]-extraParam['POSITIONS'][1][1])))
									self.world:D('jaylog GameFlow:excuteParam blockLen:',blockLen,'blockWidth',blockWidth)
								end
								if extraParam['OFFSET']~=nil then
									blockWidth = blockWidth + 180
								end
								extraParam['POSITION'] = {x,y}
							end
							--end
							if #extraParam['ID']>1 then
								if (self.world.itemListFilter.heroList[1].attribute.roleId>=3 and self.world.itemListFilter.heroList[1].attribute.roleId<=5) or (self.world.itemListFilter.heroList[1].attribute.roleId>=8 and self.world.itemListFilter.heroList[1].attribute.roleId<=10) then
									extraParam['ID'][1] = extraParam['ID'][2]
								end
							end
							-- self.world:D('jaylog NEWMULTIBLOCK addMonster:',extraParam['ID'][1],extraParam['POSITION'][1],extraParam['POSITION'][2])
							local monsterID,monsterObj
							local team = ''
							if extraParam['TEAM']~=nil then
								team = extraParam['TEAM'][1]
							end
							if extraParam['ISCREATURE']~=nil or extraParam['DELAY']~=nil or extraParam['LIFETIME']~=nil then
								local adjtime = 0
								if extraParam['DELAY']~=nil then
									adjtime = extraParam['DELAY'][1]
								end
								local lifetime = 0
								if extraParam['LIFETIME']~=nil then
									lifetime = extraParam['LIFETIME'][1]
								end
								monsterID = self.world:addCreature(self.world.tostring(extraParam['ID'][1]),team,extraParam['POSITION'][1],extraParam['POSITION'][2],nil,1,adjtime)
								monsterObj = self.world.allItemList[monsterID]
								if lifetime~=0 then
									monsterObj:setDeadTime(lifetime+adjtime)
								end
							else
								monsterID = self.world:addMonster(self.world.tostring(extraParam['ID'][1]),extraParam['POSITION'][1],extraParam['POSITION'][2],nil,1,team)
								monsterObj = self.world.allItemList[monsterID]
							end
							-- debuglog('jaylog stopAI 11 ')
							if noAI==1 then
								-- debuglog('jaylog stopAI 1 '..noAI..monsterID..v)
								monsterObj.autoFightAI.runAI = false
								monsterObj.autoFightAI.runMoveAI = false
								monsterObj.autoFightAI.noAutoPatrol = true
							end
							if blockLen~=0 then
								monsterObj:setBlockLenWidth(blockLen,blockWidth)
							end
							if extraParam['SUBNAME']~=nil then
								monsterObj:setSubName(extraParam['SUBNAME'][1])
							end
						end
					else
						if self.world.sFind(v,'BYROLETYPE')~=nil then
							local pRoleID = self.world.itemListFilter.heroList[1].attribute.roleId
							if pRoleID==1 or pRoleID==2 or pRoleID==6 or pRoleID==7 then
								extraParam['ID'] = extraParam['IDNEAR']
							else
								extraParam['ID'] = extraParam['IDFAR']
							end
						end
						local monsterID,monsterObj
						local team = ''
						if extraParam['TEAM']~=nil then
							team = extraParam['TEAM'][1]
						end
						if extraParam['ISCREATURE']~=nil or extraParam['DELAY']~=nil or extraParam['LIFETIME']~=nil then
							local adjtime = 0
							if extraParam['DELAY']~=nil then
								adjtime = extraParam['DELAY'][1]
							end
							local lifetime = 0
							if extraParam['LIFETIME']~=nil then
								lifetime = extraParam['LIFETIME'][1]
							end
							monsterID = self.world:addCreature(self.world.tostring(extraParam['ID'][1]),team,extraParam['POSITION'][1],extraParam['POSITION'][2],nil,1,0)
							monsterObj = self.world.allItemList[monsterID]
							if lifetime~=0 then
								monsterObj:setDeadTime(lifetime+adjtime)
							end
						else
							monsterID = self.world:addMonster(self.world.tostring(extraParam['ID'][1]),extraParam['POSITION'][1],extraParam['POSITION'][2],nil,1,team)
							monsterObj = self.world.allItemList[monsterID]
						end
						-- debuglog('jaylog stopAI 22 ')
						if noAI==1 then
							-- debuglog('jaylog stopAI 2 '..noAI..monsterID..v)
							monsterObj.autoFightAI.runAI = false
							monsterObj.autoFightAI.runMoveAI = false
							monsterObj.autoFightAI.noAutoPatrol = true
						end
						if extraParam['POSITION'][3]~=nil then
							monsterObj.attribute.STANDPOINT = extraParam['POSITION'][3]
							monsterObj.syncMsg['i']['jd'] = extraParam['POSITION'][3]
						end
						if extraParam['SUBNAME']~=nil then
							monsterObj:setSubName(extraParam['SUBNAME'][1])
						end
					end
					--self.monsterGroup[#self.monsterGroup] = monster.itemID
					
					parameter[k] = nil
				end
				if extraParam['ID'][1]>1000 and extraParam['ID'][1]<9999 then
					local name = extraParam['SUBNAME'][1]
					if extraParam['CHANGENAME']~=nil then
						name = extraParam['CHANGENAME'][1]
					end
					local team = ''
					if extraParam['TEAM']~=nil then
						team = extraParam['TEAM'][1]
					end
					local boss = self.world:addBoss(extraParam['ID'][1],team,name,extraParam['POSITION'][1],extraParam['POSITION'][2],extraParam['SKINNO'][1])
					-- debuglog('jaylog stopAI 33 ')
					if noAI==1 then
						-- debuglog('jaylog stopAI 3 '..noAI..boss.itemID..v)
						boss.autoFightAI.runAI = false
						boss.autoFightAI.runMoveAI = false
						boss.autoFightAI.noAutoPatrol = true
					end
					if extraParam['POSITION'][3]~=nil then
						boss.attribute.STANDPOINT = extraParam['POSITION'][3]
						boss.syncMsg['i']['jd'] = extraParam['POSITION'][3]
					end
					if extraParam['SUBNAME']~=nil then
						boss:setSubName(extraParam['SUBNAME'][1])
					end
					parameter[k] = nil
				end
				if extraParam['ID'][1]>20000 then
					local npcID = self.world:addNPC(self.world.tostring(extraParam['ID'][1]),'',extraParam['POSITION'][1],extraParam['POSITION'][2],nil,1)
					local npcObj = self.world.allItemList[npcID]
					-- debuglog('jaylog stopAI 44 ')
					if noAI==1 then
						-- debuglog('jaylog stopAI 4 '..noAI..npcID..v)
						npcObj.autoFightAI.runAI = false
						npcObj.autoFightAI.runMoveAI = false
						npcObj.autoFightAI.noAutoPatrol = true
					end
					if extraParam['POSITION'][3]~=nil then
						npcObj.attribute.STANDPOINT = extraParam['POSITION'][3]
						npcObj.syncMsg['i']['jd'] = extraParam['POSITION'][3]
					end
					if extraParam['SUBNAME']~=nil then
						self.world.allItemList[npcID]:setSubName(extraParam['SUBNAME'][1])
					end
					npcObj:addTaskBuff()
					parameter[k] = nil
				end
			end
			if self.world.sFind(v,'GROUP')~=nil then
				local noAI = 0
				if self.world.sFind(v,'NOAI')~=nil then
					noAI = 1
				end
				if self.world.sFind(v,'EXTRA')~=nil then
					self.world:callCreature(extraParam,nil,true,noAI)
				else
					self.world:callCreature(extraParam,nil,nil,noAI)
				end
				parameter[k] = nil
			end
			if self.world.sFind(v,'BLOCK')~=nil then
				local team = 0
				if extraParam['TEAM']~=nil then
					if extraParam['TEAM'][1]=='A' then
						team = 1
					end
					if extraParam['TEAM'][1]=='B' then
						team = 2
					end
					if extraParam['TEAM'][1]=='BOSS' then
						team = 3
					end
				end
				if v=='NEWMULTIBLOCK' then
					local blockPos = {{},{}}
					if extraParam['POSITIONS'][1][1]<extraParam['POSITIONS'][2][1] then
						blockPos[1][1] = extraParam['POSITIONS'][1][1]
						blockPos[2][1] = extraParam['POSITIONS'][2][1]
					else
						blockPos[1][1] = extraParam['POSITIONS'][2][1]
						blockPos[2][1] = extraParam['POSITIONS'][1][1]
					end
					if extraParam['POSITIONS'][1][2]<extraParam['POSITIONS'][2][2] then
						blockPos[1][2] = extraParam['POSITIONS'][1][2]
						blockPos[2][2] = extraParam['POSITIONS'][2][2]
					else
						blockPos[1][2] = extraParam['POSITIONS'][2][2]
						blockPos[2][2] = extraParam['POSITIONS'][1][2]
					end
					-- self.world:D('jaylog GameFlow:excuteParam NEWMULTIBLOCK ',blockPos[1][1],blockPos[1][2],blockPos[1][1],blockPos[2][2],extraParam['TIMELEN'][1],99991)
					self.world.map:addTmpBlockByLine(blockPos[1][1],blockPos[1][2],blockPos[1][1],blockPos[2][2],extraParam['TIMELEN'][1],99991,team)
					self.world.map:addTmpBlockByLine(blockPos[1][1]-1,blockPos[1][2]-1,blockPos[1][1]-1,blockPos[2][2]+1,extraParam['TIMELEN'][1],99981,team)
					-- self.world:D('jaylog GameFlow:excuteParam NEWMULTIBLOCK ',blockPos[1][1],blockPos[1][2],blockPos[2][1],blockPos[1][2],extraParam['TIMELEN'][1],99992)
					self.world.map:addTmpBlockByLine(blockPos[1][1],blockPos[1][2],blockPos[2][1],blockPos[1][2],extraParam['TIMELEN'][1],99992,team)
					self.world.map:addTmpBlockByLine(blockPos[1][1]-1,blockPos[1][2]-1,blockPos[2][1]+1,blockPos[1][2]-1,extraParam['TIMELEN'][1],99982,team)
					-- self.world:D('jaylog GameFlow:excuteParam NEWMULTIBLOCK ',blockPos[2][1],blockPos[1][2],blockPos[2][1],blockPos[2][2],extraParam['TIMELEN'][1],99993)
					self.world.map:addTmpBlockByLine(blockPos[2][1],blockPos[1][2],blockPos[2][1],blockPos[2][2],extraParam['TIMELEN'][1],99993,team)
					self.world.map:addTmpBlockByLine(blockPos[2][1]+1,blockPos[1][2]-1,blockPos[2][1]+1,blockPos[2][2]+1,extraParam['TIMELEN'][1],99983,team)
					-- self.world:D('jaylog GameFlow:excuteParam NEWMULTIBLOCK ',blockPos[1][1],blockPos[2][2],blockPos[2][1],blockPos[1][2],extraParam['TIMELEN'][1],99994)
					self.world.map:addTmpBlockByLine(blockPos[1][1],blockPos[2][2],blockPos[2][1],blockPos[2][2],extraParam['TIMELEN'][1],99994,team)
					self.world.map:addTmpBlockByLine(blockPos[1][1]-1,blockPos[2][2]+1,blockPos[2][1]+1,blockPos[2][2]+1,extraParam['TIMELEN'][1],99984,team)
				else
					-- self.world:D('jaylog GameFlow:excuteParam SINGLEBLOCK ',extraParam['POSITIONS'][1][1],extraParam['POSITIONS'][2][2],extraParam['POSITIONS'][2][1],extraParam['POSITIONS'][1][2],extraParam['TIMELEN'][1],extraParam['BLOCKID'][1])
					self.world.map:addTmpBlockByLine(extraParam['POSITIONS'][1][1],extraParam['POSITIONS'][1][2],extraParam['POSITIONS'][2][1],extraParam['POSITIONS'][2][2],extraParam['TIMELEN'][1],extraParam['BLOCKID'][1],team)
					if extraParam['POSITIONS'][1][1]==extraParam['POSITIONS'][2][1] then
						self.world.map:addTmpBlockByLine(extraParam['POSITIONS'][1][1],extraParam['POSITIONS'][1][2]+1,extraParam['POSITIONS'][2][1],extraParam['POSITIONS'][2][2]+1,extraParam['TIMELEN'][1],extraParam['BLOCKID'][1],team)
					elseif extraParam['POSITIONS'][1][2]==extraParam['POSITIONS'][2][2] then
						self.world.map:addTmpBlockByLine(extraParam['POSITIONS'][1][1]+1,extraParam['POSITIONS'][1][2],extraParam['POSITIONS'][2][1]+1,extraParam['POSITIONS'][2][2],extraParam['TIMELEN'][1],extraParam['BLOCKID'][1],team)
					else
						for i=1,6 do
							local toX,toY = self.world.map:getXYLengthCross(extraParam['POSITIONS'][1][1],extraParam['POSITIONS'][1][2],extraParam['POSITIONS'][2][1],extraParam['POSITIONS'][2][2],0.3*i)
							self.world.map:addTmpBlockByLine(extraParam['POSITIONS'][1][1]+toX,extraParam['POSITIONS'][1][2]+toY,extraParam['POSITIONS'][2][1]+toX,extraParam['POSITIONS'][2][2]+toY,extraParam['TIMELEN'][1],extraParam['BLOCKID'][1],team)
							self.world.map:addTmpBlockByLine(extraParam['POSITIONS'][1][1]-toX,extraParam['POSITIONS'][1][2]-toY,extraParam['POSITIONS'][2][1]-toX,extraParam['POSITIONS'][2][2]-toY,extraParam['TIMELEN'][1],extraParam['BLOCKID'][1],team)
							self.world:D('xiao ming ming block +',i,extraParam['POSITIONS'][1][1]+toX,extraParam['POSITIONS'][1][2]+toY,extraParam['POSITIONS'][2][1]+toX,extraParam['POSITIONS'][2][2]+toY)
							self.world:D('xiao ming ming block -',i,extraParam['POSITIONS'][1][1]-toX,extraParam['POSITIONS'][1][2]-toY,extraParam['POSITIONS'][2][1]-toX,extraParam['POSITIONS'][2][2]-toY)
						end
					end
					-- 创建墙的时候将宠物拉回主人身边
					local obj = self.world.itemListFilter.heroList[1]
					if obj.attribute.roleId==5 or obj.attribute.roleId==10 then
						if obj.CWID~=nil and obj.CWID~=0 then
							local toX,toY = self.world.formula:getRandomCirclePoint(obj.posX,obj.posY,250/self.world.setting.AdjustAttRange,true)
							local ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,toX,toY) 
							self.world.allItemList[obj.CWID]:moveTo(toX,toY,true,1,99999)
						end
					end
				end
				parameter[k] = nil
			end
			if self.world.sFind(v,'OTHER')~=nil then
				local obj = self.world.itemListFilter.heroList[1]
				local idx2 = 1
				if obj.attribute.roleId<6 then
					for i=1,5 do
						if i~=obj.attribute.roleId then
							local idx = self.world:getHeroItemID()
							local id = i<10 and '0'..i or i
							--local playerInfo = self.world:memcacheGet('aoeOther'..self.world.mapModel..id..'01'..'Json')
							local playerInfo = self.world:getAIData(self.world.mapModel,i,extraParam['LEVEL'][1],obj.team)
							self.world:D('jaylog excuteParam playerInfo:',playerInfo,'aoeOther'..self.world.mapModel..id..'Json')
							self.world.playerList[idx] = {}
							self.world.playerList[idx]['playerJson'] = self.world.tDeepcopy(self.world.cjson.decode(playerInfo))
							self.world.playerList[idx]['i'] = idx
							self.world.playerList[idx]['id'] = self.world.playerList[idx]['playerJson']['Player']['loginID']
							self.world.playerList[idx]['p'] = self.world.playerList[idx]['playerJson']['Player']['playerID']
							self.world:D('jaylog addHero ',i,obj.team,self.world.playerList[idx]['id'],extraParam['POSITIONS'][idx2][1],extraParam['POSITIONS'][idx2][2],nil,idx)
							local hero = self.world:addHero(i,obj.team,self.world.playerList[idx]['id'],extraParam['POSITIONS'][idx2][1],extraParam['POSITIONS'][idx2][2],nil,idx,true,true)
							--self.world.itemListFilter.heroList[idx]:setAuto(true)
							if extraParam['SUBNAME']~=nil then
								hero:setSubName(extraParam['SUBNAME'][1])
							end
							local result=hero:getAllInfo(0,true)
							hero:updateSyncMsg({i=result})
							-- if obj.attribute.roleId>=3 and obj.attribute.roleId<=5 and idx2==3 then
							-- 	idx2 = idx2 + 2
							-- else
								idx2 = idx2 + 1
							-- end
						end
					end
				else
					for i=6,10 do
						if i~=obj.attribute.roleId then
							local idx = self.world:getHeroItemID()
							local id = i<10 and '0'..i or i
							--local playerInfo = self.world:memcacheGet('aoeOther'..self.world.mapModel..id..'01'..'Json')
							local playerInfo = self.world:getAIData(self.world.mapModel,i,extraParam['LEVEL'][1],obj.team)
							self.world:D('jaylog excuteParam playerInfo:',playerInfo,'aoeOther'..self.world.mapModel..id..'01'..'Json')
							self.world.playerList[idx] = {}
							self.world.playerList[idx]['playerJson'] = self.world.tDeepcopy(self.world.cjson.decode(playerInfo))
							self.world.playerList[idx]['i'] = idx
							self.world.playerList[idx]['id'] = self.world.playerList[idx]['playerJson']['Player']['loginID']
							self.world.playerList[idx]['p'] = self.world.playerList[idx]['playerJson']['Player']['playerID']
							-- 临时处理 start
							-- if i>5 then
							-- 	i = i - 5
							-- 	self.world.playerList[idx]['playerJson']['Player']['roleId'] = i
							-- end
							-- 临时处理 end
							local hero = self.world:addHero(i,obj.team,self.world.playerList[idx]['id'],extraParam['POSITIONS'][idx2][1],extraParam['POSITIONS'][idx2][2],nil,idx,true,true)
							--self.world.itemListFilter.heroList[idx]:setAuto(true)
							if extraParam['SUBNAME']~=nil then
								hero:setSubName(extraParam['SUBNAME'][1])
							end
							local result=hero:getAllInfo(0,true)
							hero:updateSyncMsg({i=result})
							-- if obj.attribute.roleId>=8 and obj.attribute.roleId<=10 and idx2==3 then
							-- 	idx2 = idx2 + 2
							-- else
								idx2 = idx2 + 1
							-- end
						end
					end
				end
				-- self.world:syncGameInfoOnece()
				-- for k,v in pairs(self.world.itemListFilter.heroList) do
				-- 	self.world:D('jaylog heroList:',k,v.attribute.roleId)
				-- end
				parameter[k] = nil
			end
			if self.world.sFind(v,'AIHERO')~=nil then
				local idx = self.world:getHeroItemID()
				local num = extraParam['ID'][1]
				local id = '01'
				if num<10 then
					id = '0'..num
				else
					id = ''..num
				end
				--local playerInfo = self.world:memcacheGet('aoeOther'..self.world.mapModel..id..'01'..'Json')
				--local playerInfo = self.world:memcacheGet('aoeOther9001'..id..'01'..'Json')
				local team = 'A'
				if extraParam['TEAM']~=nil then
					team = extraParam['TEAM'][1]
				end
				local playerInfo = self.world:getAIData(self.world.mapModel,num,extraParam['LEVEL'][1],team)
				self.world:D('jaylog NEWAI excuteParam playerInfo:',playerInfo,'aoeOther'..self.world.mapModel..id..'01Json')
				self.world.playerList[idx] = {}
				self.world.playerList[idx]['playerJson'] = self.world.tDeepcopy(self.world.cjson.decode(playerInfo))
				self.world.playerList[idx]['i'] = idx
				self.world.playerList[idx]['t'] = team
				if extraParam['CHANGENAME']~=nil then
					self.world.playerList[idx]['id'] = extraParam['CHANGENAME'][1]
					self.world.playerList[idx]['playerJson']['Player']['loginID'] = extraParam['CHANGENAME'][1]
				else
					self.world.playerList[idx]['id'] = self.world.playerList[idx]['playerJson']['Player']['loginID']
				end
				self.world.playerList[idx]['p'] = self.world.playerList[idx]['playerJson']['Player']['playerID']
				--self.addHero(self,i,obj.team,obj.loginID..i,obj.initX+i,obj.initY,nil,idx)
				local aiteam = self.world.playerList[idx]['t']
				-- 临时处理 start
				-- if num>5 then
				-- 	num = num - 5
				-- 	self.world.playerList[idx]['playerJson']['Player']['roleId'] = num
				-- end
				-- 临时处理 end
				local hero = self.world:addHero(num,aiteam,self.world.playerList[idx]['id'],extraParam['POSITION'][1],extraParam['POSITION'][2],nil,idx,true,true)
				if extraParam['POSITION'][3]~=nil then
					hero.attribute.STANDPOINT = extraParam['POSITION'][3]
					hero.syncMsg['i']['jd'] = extraParam['POSITION'][3]
				end
				--self.world.itemListFilter.heroList[idx]:setAuto(true)
				if extraParam['SUBNAME']~=nil then
					hero:setSubName(extraParam['SUBNAME'][1])
				end
				if self.world.sFind(v,'NOAVATAR')~=nil then
					hero.isSmallAI = true
					hero.attribute.loginIDNotShow = 1
					hero.attribute.bloodNotShow = 1
				else
					self.world:syncGameInfoOnece()
				end
				-- 临时处理 start
				-- if aiteam=='B' then
				-- 	hero.onlySimpleAttack = true
				-- end
				-- 临时处理 end
				local result=hero:getAllInfo(0,true)
				hero:updateSyncMsg({i=result})
				parameter[k] = nil
			end
		end
		if v=='SYNTEAMHEADER' then
			self.world:syncGameInfoOnece()
			parameter[k] = nil
		end
		if v=='MOVEOTHER' then
			local idx = 2
			if extraParam['ROLEIDS']~=nil and extraParam['POSITIONS']~=nil then
				local ids = {}
				if self.world.tonumber(self.world.itemListFilter.heroList[1].attribute.roleId)<6 then
					ids = extraParam['ROLEIDS'][1]
				else
					ids = extraParam['ROLEIDS'][2]
				end
				for k1,v1 in pairs(ids) do
					for k2,v2 in pairs(self.world.itemListFilter.heroList) do
						if v2.actorType==0 and k2~=1 and v2.parent==nil then
							if self.world.tonumber(v2.attribute.roleId)==v1 or self.world.tonumber(v2.attribute.roleId)==(v1-5) or self.world.tonumber(v2.attribute.roleId)==(v1+5) then
								local ret = v2:moveTo(extraParam['POSITIONS'][idx][1],extraParam['POSITIONS'][idx][2],true,1,99999)
								self.world:D('jaylog MOVEOTHER ',self.world.cjson.encode(ret))
								if idx==3 then
									idx = 1
								elseif idx==1 then
									idx = 4
								else
									idx = idx + 1
								end
							end
						end
					end
				end
			end
			parameter[k] = nil
		end
		if self.world.sFind(v,'GAMEOVER')~=nil then
			--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v))
			for k1,v1 in pairs(self.world.itemListFilter.soldierList) do
				v1.attribute.HP = 0
				v1:directHurt(v1.itemID,1,{},0)
			end
			self.world.gameFlag['isGameOver'] = true
			parameter[k] = nil
		end
		if self.world.sFind(v,'SETGAMESTART')~=nil then
			self.world.gameStartTime = self.world.gameTime
			if self.world.roomStartTime==0 then
				self.world:addSyncMsg({game={gst=self.world.gameStartTime,gss=1}})
				self.world.roomStartTime = self.world.gameTime
			end
			parameter[k] = nil
		end
		if self.world.sFind(v,'SETREMAINTIME')~=nil then
			self.world.gameRemainStartTime = self.world.gameTime
			self.world.gameRemainTime = extraParam['NUM'][1]
			parameter[k] = nil
		end
		if v=='SETROOMSTART' then
			self.world.gameStartTime = self.world.gameTime
			if self.world.roomStartTime==0 then
				self.world:addSyncMsg({game={gst=self.world.gameStartTime,gss=1}})
				self.world.roomStartTime = self.world.gameTime
			end
			parameter[k] = nil
		end
		if self.world.sFind(v,'SHOWDIALOG')~=nil then
			self.world:addSyncMsg({gameinfo={{stage=self.world.worldNum,bossID=extraParam['ID'][1],step=extraParam['STEP'][1],mType=1}}})
			parameter[k] = nil
		end
		if self.world.sFind(v,'SHOWCARTOON')~=nil then
			if extraParam['STEP']~=nil then
				self.world:addSyncMsg({gameinfo={{step=extraParam['STEP'][1],mType=2}}})
			end
			if extraParam['STEPS']~=nil then
				if self.world.playerList[1]['playerJson']['Player']['school']==1 then
					self.world:addSyncMsg({gameinfo={{step=extraParam['STEPS'][1][1],mType=2}}})
				else
					self.world:addSyncMsg({gameinfo={{step=extraParam['STEPS'][2][1],mType=2}}})
				end
			end
			parameter[k] = nil
		end
		if self.world.sFind(v,'SETGUIDEOLDSTEP')~=nil then
			local loginTime1 = self.world.callBack:getServerTime()
			local roleId = self.world.tonumber(self.world.itemListFilter.heroList[1].attribute.roleId)
			if extraParam['STEP'][roleId]~=nil then
				extraParam['STEP'][1] = extraParam['STEP'][roleId]
			end
			self.world.guideStepNext = extraParam['STEP'][1]
			self.world.guideStepSetAutoBlock = true
			local msg = {flow={}}
			for msgk,msgv in pairs(self.world.itemListFilter.heroList) do
				if msgv.actorType==0 and not msgv:isAIObj() then
					msg['flow'][#msg['flow']+1] = {i=msgk,step=extraParam['STEP'][1]}
				end
			end
			local id,id2 = 0,0
			if extraParam['SUBNAME']~=nil then
				local tid = {}
				for sgdsk,sgdsv in pairs(extraParam['SUBNAME']) do
					for gdsk,gdsv in pairs(self.world.allItemList) do
						if extraParam['SUBNAME'][sgdsk]~='0' and gdsv.subName==extraParam['SUBNAME'][sgdsk] then
							id = gdsv.itemID
						end
						if extraParam['ROLEID']~=nil and extraParam['ROLEID'][sgdsk]~=0 and self.world.tonumber(gdsv.attribute.roleId)==extraParam['ROLEID'][sgdsk] then
							id2 = gdsv.itemID
						end
					end
					if id2~=0 then
						tid[#tid+1] = id2
					else
						tid[#tid+1] = id
					end
				end
				local oldFlowMsg = ''
				local oldParam,oldNum = {},{}
				local addNum = 0
				local tidStr = ''
				if self.world.syncMsg['flow']~=nil then
					oldFlowMsg = self.world.syncMsg['flow'][#self.world.syncMsg['flow']]
					if oldFlowMsg['param']~='step=ok' then
						tidStr = oldFlowMsg['param']
						oldParam = self.world.sSplit(oldFlowMsg['param'],',')
						oldNum = self.world.sSplit(oldParam[#oldParam],'=')
						addNum = self.world.tonumber(self.world.sSub(oldNum[1],4,4))
					end
				end
				for tidk,tidv in pairs(tid) do
					if tidStr=='' then
						tidStr = 'tid'..(tidk+addNum)..'='..tidv
					else
						tidStr = tidStr..','..'tid'..(tidk+addNum)..'='..tidv
					end
				end
				tidStr = tidStr..',num='..(#tid+addNum)
				for msgk,msgv in pairs(msg['flow']) do
					msg['flow'][msgk]['param']=tidStr
				end
			end
			if extraParam['ROLEIDS']~=nil then
				local idx = 1
				local tid = {}
				local rid = {}
				local tidstr = ''
				if self.world.tonumber(self.world.itemListFilter.heroList[1].attribute.roleId)<6 then
					rid = extraParam['ROLEIDS'][1]
				else
					rid = extraParam['ROLEIDS'][2]
				end
				for ridk,ridv in pairs(rid) do
					for gdsk,gdsv in pairs(self.world.itemListFilter.heroList) do
						if gdsk~=1 and gdsv.actorType==0 and gdsv.parent==nil then
							-- self.world:D('jaylog SETGUIDEOLDSTEP ',self.world.cjson.encode(tid),implode(',',tid),gdsv.attribute.roleId,ridv)
							if self.world.tonumber(gdsv.attribute.roleId)==ridv or self.world.tonumber(gdsv.attribute.roleId)==(ridv+5) or self.world.tonumber(gdsv.attribute.roleId)==(ridv-5) then
								tid[idx] = gdsk
								if tidstr=='' then
									tidstr = 'tid'..idx..'='..gdsk
								else
									tidstr = tidstr..',tid'..idx..'='..gdsk
								end
								idx = idx + 1
							end
						end
					end
				end
				for msgk,msgv in pairs(msg['flow']) do
					msg['flow'][msgk]['param']=tidstr
				end
			end
			self.world:addSyncMsg(msg)
			-- 停所有角色的AI
			for k1,v1 in pairs(self.world.allItemList) do
				-- self.world:D('jaylog startStop AI ',v1.actorType,v1.attribute.roleId,v1.loginID)
				if v1.actorType==0 then
					-- self.world:D('jaylog startStop 2 AI ',v1.actorType,v1.attribute.roleId,v1.loginID)
					if v1:isAIObj() then
						v1:setAuto(false)
					else
						v1:setAutoBlocked(false)
					end
				else
					v1.autoFightAI.runAI = false
					v1.autoFightAI.runMoveAI = false
					v1.autoFightAI.noAutoPatrol = true
				end
			end
			self.world:D('jaylog SETGUIDEOLDSTEP ',self.world.cjson.encode(msg),self.world.cjson.encode(self.world.syncMsg))
			local loginTime2 = self.world.callBack:getServerTime()
			-- self.world:DC('jaylog SETGUIDEOLDSTEP ',self.world.mFloor((loginTime2-loginTime1)*10000)/10000,loginTime1,loginTime2)
			parameter[k] = nil
		end
		if self.world.sFind(v,'ADDCOUNTMSG')~=nil then
			if extraParam['STAGE']~=nil then
				self.world:addSyncMsg({gameinfo={{stage=extraParam['STAGE'][1],mType=1}}})
			else
				self.world:addSyncMsg({gameinfo={{stage=999,mType=1}}})
			end
			-- if self.world.mapModel=='1005' then
			-- 	for k1,v1 in pairs(self.world.itemListFilter.heroList) do
			-- 		self.world:D('jaylog ADDCOUNTMSG skillDeamon:',self.world.cjson.encode(self.world.playerList[k1]['playerJson']['skillDemon']))
			-- 		if v1.actorType==0 and v1.parent==nil and self.world.playerList[k1]['playerJson']['skillDemon']~=nil and self.world.tNums(self.world.playerList[k1]['playerJson']['skillDemon'])~=0 then
			-- 			local status=v1.statusList[88]
			-- 			if status~=nil then
			-- 				v1:addStatusList({zz=3,s=88,r=self.world.gameTime,t=99999,p1=status['p1'],p2=status['p2'],p3=12})
			-- 			end
			-- 		end
			-- 	end
			-- end
			parameter[k] = nil
		end
		if self.world.sFind(v,'SETUIID')~=nil then
			local bossList = {}
			for k,v in pairs(self.world.allItemList) do
				--if self.world.sFind(v.subName,'BOSS')~=nil then
					--bossList[self.world.tonumber(self.sSub(v.subName,5))] = v.itemID
				--end
				if extraParam['SUBNAME']~=nil and v.subName==extraParam['SUBNAME'][1] then
					if extraParam['ROLEID']~=nil then
						if self.world.tonumber(v.attribute.roleId)==extraParam['ROLEID'][1] then
							bossList[1] = v.itemID
						end
					else
						bossList[1] = v.itemID
					end
				end
				if extraParam['SUBNAME1']~=nil and v.subName==extraParam['SUBNAME1'][1] then
					if extraParam['ROLEID1']~=nil then
						if self.world.tonumber(v.attribute.roleId)==extraParam['ROLEID1'][1] then
							bossList[2] = v.itemID
						end
					else
						bossList[2] = v.itemID
					end
				end
				if extraParam['SUBNAME2']~=nil and v.subName==extraParam['SUBNAME2'][1] then
					if extraParam['ROLEID2']~=nil then
						if self.world.tonumber(v.attribute.roleId)==extraParam['ROLEID2'][1] then
							bossList[3] = v.itemID
						end
					else
						bossList[3] = v.itemID
					end
				end
				if extraParam['SUBNAME3']~=nil and v.subName==extraParam['SUBNAME3'][1] then
					if extraParam['ROLEID3']~=nil then
						if self.world.tonumber(v.attribute.roleId)==extraParam['ROLEID3'][1] then
							bossList[4] = v.itemID
						end
					else
						bossList[4] = v.itemID
					end
				end
			end
			-- local maxnum = self.tMaxn(bossList)
			-- for i=1,maxnum do
			-- 	if bossList[i]==nil then
			-- 		bossList[i] = 0
			-- 	end
			-- end
			if extraParam['SUBNAME']~=nil or extraParam['SUBNAME1']~=nil or extraParam['SUBNAME2']~=nil or extraParam['SUBNAME3']~=nil then
				self.world.UIID = extraParam['ID'][1]
				self.world.UIBoss = bossList
				if extraParam['STEP']~=nil then
					self.world.UIStep = extraParam['STEP'][1]
				end
			end
			self.world:addSyncMsg({gameinfo={{part=extraParam['ID'][1],partBoss=bossList,step=self.world.UIStep,mType=3}}})
			parameter[k] = nil
		end
		if self.world.sFind(v,'SETHEROUIID')~=nil then
			local bossList = {}
			for k,v in pairs(self.world.allItemList) do
				if extraParam['SUBNAME']~=nil and v.subName==extraParam['SUBNAME'][1] then
					if extraParam['ROLEID']~=nil then
						if self.world.tonumber(v.attribute.roleId)==extraParam['ROLEID'][1] then
							bossList[1] = v.itemID
						end
					else
						bossList[1] = v.itemID
					end
				end
				if extraParam['SUBNAME1']~=nil and v.subName==extraParam['SUBNAME1'][1] then
					if extraParam['ROLEID1']~=nil then
						if self.world.tonumber(v.attribute.roleId)==extraParam['ROLEID1'][1] then
							bossList[2] = v.itemID
						end
					else
						bossList[2] = v.itemID
					end
				end
				if extraParam['SUBNAME2']~=nil and v.subName==extraParam['SUBNAME2'][1] then
					if extraParam['ROLEID2']~=nil then
						if self.world.tonumber(v.attribute.roleId)==extraParam['ROLEID2'][1] then
							bossList[3] = v.itemID
						end
					else
						bossList[3] = v.itemID
					end
				end
				if extraParam['SUBNAME3']~=nil and v.subName==extraParam['SUBNAME3'][1] then
					if extraParam['ROLEID3']~=nil then
						if self.world.tonumber(v.attribute.roleId)==extraParam['ROLEID3'][1] then
							bossList[4] = v.itemID
						end
					else
						bossList[4] = v.itemID
					end
				end
			end
			self.world:addSyncMsg({gameinfo={{part=extraParam['ID'][1],mType=3}}})
			parameter[k] = nil
		end
		if self.world.sFind(v,'CLEANUIID')~=nil then
			self.world.UIID = 0
			self.world.UIBoss = {}
			self.world.UIStep = 0
			self.world:addSyncMsg({gameinfo={{part=3,mType=3}}})
			parameter[k] = nil
		end
		if self.world.sFind(v,'SETTIPS')~=nil then
			self.world:addSyncMsg({gameinfo={{part=5,step=extraParam['ID'][1],mType=3}}})
			parameter[k] = nil
		end
		if self.world.sFind(v,'SETNPCTIPS')~=nil then
			self.world:addSyncMsg({gameinfo={{part=10,step=extraParam['STEP'][1],mType=3}}})
			parameter[k] = nil
		end
		if self.world.sFind(v,'SETCLOSENPCTIPS')~=nil then
			self.world:addSyncMsg({gameinfo={{part=14,mType=3}}})
			parameter[k] = nil
		end
		if self.world.sFind(v,'SETBGM')~=nil then
			self.world:addSyncMsg({gameinfo={{part=12,step=extraParam['ID'][1],mType=3}}})
			parameter[k] = nil
		end
		if self.world.sFind(v,'SETTASKTIPS')~=nil then
			self.world:addSyncMsg({gameinfo={{part=13,step=extraParam['ID'][1],mType=3}}})
			parameter[k] = nil
		end
		if v=='STOPAI' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if self.world.sFind(v1.subName,'BOSS')~=nil then
					v1.autoFightAI.runAI = false
					v1.autoFightAI.runMoveAI = false
					v1.autoFightAI.noAutoPatrol = true
				end
				if v1.actorType==0 then
					if v1.CWID~=nil and v1.CWID>0 then
						local obj = self.world.allItemList[v1.CWID]
						obj.autoFightAI.runAI = false
						obj.autoFightAI.runMoveAI = false
						obj.autoFightAI.noAutoPatrol = true
					end
				end
			end
			for k1,v1 in pairs(self.world.itemListFilter.soldierList) do
				v1.autoFightAI.runAI = false
				v1.autoFightAI.runMoveAI = false
				v1.autoFightAI.noAutoPatrol = true
			end
			parameter[k] = nil
		end
		if v=='STARTAI' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if self.world.sFind(v1.subName,'BOSS')~=nil then
					v1.autoFightAI.runAI = true
					v1.autoFightAI.runMoveAI = true
					v1.autoFightAI.noAutoPatrol = false
				end
				if v1.actorType==0 then
					if v1.CWID~=nil and v1.CWID>0 then
						local obj = self.world.allItemList[v1.CWID]
						obj.autoFightAI.runAI = true
						obj.autoFightAI.runMoveAI = true
						obj.autoFightAI.noAutoPatrol = false
					end
				end
			end
			for k1,v1 in pairs(self.world.itemListFilter.soldierList) do
				v1.autoFightAI.runAI = true
				v1.autoFightAI.runMoveAI = true
				v1.autoFightAI.noAutoPatrol = false
			end
			parameter[k] = nil
		end
		if v=='STOPENEMYAI' then
			for k1,v1 in pairs(self.world.itemListFilter.soldierList) do
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					v1.autoFightAI.runAI = false
					v1.autoFightAI.runMoveAI = false
					v1.autoFightAI.noAutoPatrol = true
				end
			end
			parameter[k] = nil
		end
		if v=='STARTENEMYAI' then
			for k1,v1 in pairs(self.world.itemListFilter.soldierList) do
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					v1.autoFightAI.runAI = true
					v1.autoFightAI.runMoveAI = true
					v1.autoFightAI.noAutoPatrol = false
				end
			end
			parameter[k] = nil
		end
		if v=='STOPBOSSAI' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if self.world.sFind(v1.subName,'BOSS')~=nil then
					self.world:D('jaylog excuteParam:STOPBOSSAI ',v1.subName)
					v1.autoFightAI.runAI = false
					v1.autoFightAI.runMoveAI = false
					v1.autoFightAI.noAutoPatrol = true
				end
			end
			parameter[k] = nil
		end
		if v=='STARTBOSSAI' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if self.world.sFind(v1.subName,'BOSS')~=nil then
					v1.autoFightAI.runAI = true
					v1.autoFightAI.runMoveAI = true
					v1.autoFightAI.noAutoPatrol = false
				end
				if v1.actorType==0 then
					if v1.CWID~=nil and v1.CWID>0 then
						local obj = self.world.allItemList[v1.CWID]
						obj.autoFightAI.runAI = true
						obj.autoFightAI.runMoveAI = true
						obj.autoFightAI.noAutoPatrol = false
					end
				end
			end
			parameter[k] = nil
		end
		if v=='STARTHEROAI' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.actorType==0 then
					if extraParam['SUBNAME']~=nil then
						for k2,v2 in pairs(extraParam['SUBNAME']) do
							if v1.subName==v2 then
								v1:setAuto(true)
							end
						end
					elseif extraParam['SUBNAME']==nil and extraParam['ITEMID']==nil and v1:isAIObj() then
						v1:setAuto(true)
					end
				end
				if v1.actorType==0 and extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					v1:setAuto(true)
				end
				if v1.actorType==0 and not v1:isAIObj() then
					v1:setAutoBlocked(true)
				end
				if v1.actorType==0 then
					if v1.CWID~=nil and v1.CWID>0 then
						local obj = self.world.allItemList[v1.CWID]
						obj.autoFightAI.runAI = true
						obj.autoFightAI.runMoveAI = true
						obj.autoFightAI.noAutoPatrol = false
					end
				end
			end
			parameter[k] = nil
		end
		if v=='STOPHEROAI' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.actorType==0 then
					if extraParam['SUBNAME']~=nil then
						for k2,v2 in pairs(extraParam['SUBNAME']) do
							if v1.subName==v2 then
								v1:setAuto(false)
								-- self.world.itemListFilter.heroList[1]:setAutoBlocked(false)
							end
						end
					elseif extraParam['SUBNAME']==nil and extraParam['ITEMID']==nil and v1:isAIObj() then
						v1:setAuto(false)
					end
				end
				if v1.actorType==0 and extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					v1:setAuto(false)
				end
			end
			parameter[k] = nil
		end
		if v=='STARTALLAI' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.actorType==0 and v1:isAIObj() then
					v1:setAuto(true)
				end
				if v1.actorType==0 and not v1:isAIObj() then
					v1:setAutoBlocked(true)
				end
				if self.world.sFind(v1.subName,'BOSS')~=nil then
					v1.autoFightAI.runAI = true
					v1.autoFightAI.runMoveAI = true
					v1.autoFightAI.noAutoPatrol = false
				end
				if v1.actorType==0 then
					if v1.CWID~=nil and v1.CWID>0 then
						local obj = self.world.allItemList[v1.CWID]
						obj.autoFightAI.runAI = true
						obj.autoFightAI.runMoveAI = true
						obj.autoFightAI.noAutoPatrol = false
					end
				end
			end
			for k1,v1 in pairs(self.world.itemListFilter.soldierList) do
				v1.autoFightAI.runAI = true
				v1.autoFightAI.runMoveAI = true
				v1.autoFightAI.noAutoPatrol = false
			end
			parameter[k] = nil
		end
		if v=='STOPALLAI' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.actorType==0 and v1:isAIObj() then
					v1:setAuto(false)
				end
				if v1.actorType==0 and not v1:isAIObj() then
					v1:setAutoBlocked(false)
				end
				if self.world.sFind(v1.subName,'BOSS')~=nil then
					v1.autoFightAI.runAI = false
					v1.autoFightAI.runMoveAI = false
					v1.autoFightAI.noAutoPatrol = true
				end
				if v1.actorType==0 then
					if v1.CWID~=nil and v1.CWID>0 then
						local obj = self.world.allItemList[v1.CWID]
						obj.autoFightAI.runAI = false
						obj.autoFightAI.runMoveAI = false
						obj.autoFightAI.noAutoPatrol = true
					end
				end
			end
			for k1,v1 in pairs(self.world.itemListFilter.soldierList) do
				v1.autoFightAI.runAI = false
				v1.autoFightAI.runMoveAI = false
				v1.autoFightAI.noAutoPatrol = true
			end
			parameter[k] = nil
		end
		if v=='STARTHEROAINOPLAYER' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.actorType==0 and v1:isAIObj() then
					v1:setAuto(true)
				end
				if v1.actorType==0 and not v1:isAIObj() then
					v1:setAutoBlocked(true)
				end
				if v1.actorType==0 then
					if v1.CWID~=nil and v1.CWID>0 then
						local obj = self.world.allItemList[v1.CWID]
						obj.autoFightAI.runAI = true
						obj.autoFightAI.runMoveAI = true
						obj.autoFightAI.noAutoPatrol = false
					end
				end
			end
			parameter[k] = nil
		end
		if v=='STOPHEROAINOPLAYER' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.actorType==0 and v1:isAIObj() then
					v1:setAuto(false)
				end
			end
			parameter[k] = nil
		end
		if v=='STARTAIHEROAIALL' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.actorType==0 and v1:isAIObj() then
					v1:setAuto(true)
				end
				if v1.actorType==0 and not v1:isAIObj() then
					v1:setAutoBlocked(true)
				end
				if v1.actorType==0 then
					if v1.CWID~=nil and v1.CWID>0 then
						local obj = self.world.allItemList[v1.CWID]
						obj.autoFightAI.runAI = true
						obj.autoFightAI.runMoveAI = true
						obj.autoFightAI.noAutoPatrol = false
					end
				end
			end
			parameter[k] = nil
		end
		if v=='STOPAIHEROAIALL' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.actorType==0 and v1:isAIObj() then
					v1:setAuto(false)
				end
			end
			parameter[k] = nil
		end
		if v=='OUTOFCTRL' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.actorType==0 then
					-- v1:setOutOfCtlAllTime(self.world.gameTime + extraParam['TIMELEN'][1])
					local attributes = {}
					attributes['OUTCTL_RATE'] = 100
					attributes['BUFFTIME'] = extraParam['TIMELEN'][1]
					local buff = require("gameroomcore.SBuff").new(self.world,v1:__skillID2buffID(0),attributes,attributes['BUFFTIME'],{},0,v1.itemID,v1.itemID)
					v1:addBuff(buff)
					v1:moveTo(v1.posX,v1.posY,false,11)
				end
			end
			parameter[k] = nil
		end
		if v=='CLEANOUTOFCTRL' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.actorType==0 then
					v1:removeBUff('OUTCTL')
					-- v1:setOutOfCtlAllTime(self.world.gameTime)
				end
			end
			parameter[k] = nil
		end
		if v=='ADDHEROSPALL' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.actorType==0 then
					self.world:D('jaylog ADDHEROSPALL ',v1.attribute.roleId,v1.maxSP)
					if self.world.tonumber(v1.attribute.roleId)==4 or self.world.tonumber(v1.attribute.roleId)==9 then
						v1:adjSP('a',v1.maxSP/2)
						v1:adjSP('b',v1.maxSP/2)
					-- elseif self.world.tonumber(v1.attribute.roleId)==2 or self.world.tonumber(v1.attribute.roleId)==7 then
					-- elseif self.world.tonumber(v1.attribute.roleId)==2 then
					else
						for k2,v2 in pairs({70,66,64,60}) do
							if v1.statusList[v2]~=nil then
								v1:removeStatusList(v2)
								for k3,v3 in pairs(v1.syncMsg['s']) do
									if v3['s']==v2 then
										v1.syncMsg['s'][k3] = nil
									end
								end
							end
						end
						v1:adjSP(v1.maxSP,true)
					end
				end
			end
			parameter[k] = nil
		end
		if v=='ADDHEROSP' then
			if extraParam['SUBNAME']~=nil then
				for k1,v1 in pairs(self.world.itemListFilter.heroList) do
					if v1.actorType==0 and extraParam['SUBNAME'][1]==v1.subName then
						self.world:D('jaylog ADDHEROSP ',v1.attribute.roleId,v1.maxSP)
						if self.world.tonumber(v1.attribute.roleId)==4 or self.world.tonumber(v1.attribute.roleId)==9 then
							v1:adjSP('a',v1.maxSP/2)
							v1:adjSP('b',v1.maxSP/2)
						-- elseif self.world.tonumber(v1.attribute.roleId)==2 or self.world.tonumber(v1.attribute.roleId)==7 then
						-- elseif self.world.tonumber(v1.attribute.roleId)==2 then
						else
							for k2,v2 in pairs({70,66,64,60}) do
								if v1.statusList[v2]~=nil then
									v1:removeStatusList(v2)
									for k3,v3 in pairs(v1.syncMsg['s']) do
										if v3['s']==v2 then
											v1.syncMsg['s'][k3] = nil
										end
									end
								end
							end
							v1:adjSP(v1.maxSP,true)
						end
					end
				end
			end
			parameter[k] = nil
		end
		if v=='SETROOMCHAT' then
			if extraParam['SUBNAME']~=nil then
				for kt,vt in pairs(extraParam['SUBNAME']) do
					for k1,v1 in pairs(self.world.allItemList) do
						self.world:D('jaylog SETROOMCHAT 1 ',v1.subName,vt)
						if (v1.actorType==0 and v1.subName==vt and v1.parent==nil) or (v1.actorType~=0 and v1.subName==vt) then
							local msg = self.world:loadRoomChat(extraParam['ID'][kt])
							local delay = 0
							if extraParam['DELAY']~=nil and extraParam['DELAY'][kt]~=nil then
								delay = extraParam['DELAY'][kt]
							end
							local rc = {{i=k1,m=msg,t=v1.teamOrig,id=extraParam['ID'][kt]..'',d=delay}}
							self.world:D('jaylog SETROOMCHAT 2 ',self.world.cjson.encode(rc))
							self.world:addSyncMsg({rc=rc})
						end
					end
				end
			end
			parameter[k] = nil
		end
		if v=='SETCDTIME' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.actorType==0 and extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					v1.attribute.skills[extraParam['ID'][1]].lastCoolDownTime = self.world:getGameTime() + extraParam['TIMELEN'][1]
					v1:syncSkill(0)
					self.world:D('jaylog SETCDTIME ',v1.attribute.roleId)
				end
			end
			parameter[k] = nil
		end
		if v=='SETCHANGEPARTSP' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					v1.changePartSP = v1.maxSP*extraParam['NUM'][1]*0.01
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					v1.changePartSP = v1.maxSP*extraParam['NUM'][1]*0.01
				end
			end
			parameter[k] = nil
		end
		if v=='TELEPORT' then
			for k1,v1 in pairs(self.world.allItemList) do
				if extraParam['SUBNAME']~=nil then
					for k2,v2 in pairs(extraParam['SUBNAME']) do
						if v1.subName==v2 then
							--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
							local mtmsg
							if extraParam['POSITIONS']~=nil then
								mtmsg = v1:moveTo(extraParam['POSITIONS'][k2][1],extraParam['POSITIONS'][k2][2],true,1,99999)
							else
								mtmsg = v1:moveTo(extraParam['POSITION'][1],extraParam['POSITION'][2],true,1,99999)
							end
							--self.world:debuglog('jaylog GameFlow:excuteParam MOVE heroList moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths),' moveToEndTime:',v1.moveToEndTime)
							if self.world.partMoveEndTime<v1.moveToEndTime then
								self.world.partMoveEndTime = v1.moveToEndTime
							end
						end
					end
				end
				if extraParam['ITEMID']~=nil then
					for k2,v2 in pairs(extraParam['ITEMID']) do
						if v1.itemID==v2 then
							--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
							local mtmsg
							if extraParam['POSITIONS']~=nil then
								mtmsg = v1:moveTo(extraParam['POSITIONS'][k2][1],extraParam['POSITIONS'][k2][2],true,1,99999)
							else
								mtmsg = v1:moveTo(extraParam['POSITION'][1],extraParam['POSITION'][2],true,1,99999)
							end
							--self.world:debuglog('jaylog GameFlow:excuteParam MOVE heroList moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths),' moveToEndTime:',v1.moveToEndTime)
							if self.world.partMoveEndTime<v1.moveToEndTime then
								self.world.partMoveEndTime = v1.moveToEndTime
							end
						end
					end
				end
			end
			parameter[k] = nil
		end
		if v=='STOPAUTORESET' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					v1.mode4autoReset = false
					v1.mode4atkNum = 1
					v1.mode4atkTime = 0
					v1:syncSkill(0)
					v1:removeStatusList(95)
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					v1.mode4autoReset = false
					v1.mode4atkNum = 1
					v1.mode4atkTime = 0
					v1:syncSkill(0)
					v1:removeStatusList(95)
				end
			end
			parameter[k] = nil
		end
		if v=='STARTAUTORESET' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					v1.mode4autoReset = true
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					v1.mode4autoReset = true
				end
			end
			parameter[k] = nil
		end
		if v=='STARTPVPPICKUP' then
			self.world.gameFlag['pvpPickUp'] = true
			parameter[k] = nil
		end
		if v=='STOPPVPPICKUP' then
			self.world.gameFlag['pvpPickUp'] = false
			parameter[k] = nil
		end
		if v=='STARTCOUNTER' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					v1.stepCounterStart = true
					v1.stepCounter = {}
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					v1.stepCounterStart = true
					v1.stepCounter = {}
				end
			end
			parameter[k] = nil
		end
		if v=='STOPCOUNTER' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					v1.stepCounterStart = false
					v1.stepCounter = {}
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					v1.stepCounterStart = false
					v1.stepCounter = {}
				end
			end
			parameter[k] = nil
		end
		if v=='STOPSKILL' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.actorType==0 and not v1:isAIObj() then
					-- local bulletObj = self.world.bulletList[v1.lastBulletID]
					v1.lastBulletID = 0
					v1.lastCoolDownTime = self.world.gameTime
					for k2,v2 in pairs(v1.attribute.skills) do
						v2.lastCoolDownTime = self.world.gameTime
					end
					v1:syncSkill(0)
				end
			end
			parameter[k] = nil
		end
		if v=='SETPVPTAKETIME' then
			self.world.gameFlag['pvpTakeTime'] = extraParam['TIMELEN'][1]
			parameter[k] = nil
		end
		if v=='STOPCOLLECTION' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					v1:removeSkillAttackMode9()
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					v1:removeSkillAttackMode9()
				end
			end
			parameter[k] = nil
		end
		if v=='STARTAUTOCREATEHEROAI' then
			local intXYlist,tolist = {},{}
			if extraParam['POSITION']~=nil then
				if intXYlist[#intXYlist+1]==nil then
					intXYlist[#intXYlist+1] = {}
				end
				intXYlist[#intXYlist][1] = extraParam['POSITION'][1]
				intXYlist[#intXYlist][2] = extraParam['POSITION'][2]
				intXYlist[#intXYlist][3] = 1
			else
				for k1,v1 in pairs(extraParam['POSITIONS']) do
					if intXYlist[#intXYlist+1]==nil then
						intXYlist[#intXYlist+1] = {}
					end
					intXYlist[#intXYlist][1] = v1[1]
					intXYlist[#intXYlist][2] = v1[2]
					intXYlist[#intXYlist][3] = k1
				end
			end
			if extraParam['POSITIONTO']~=nil then
				if tolist[#tolist+1]==nil then
					tolist[#tolist+1] = {}
				end
				tolist[#tolist][1] = extraParam['POSITIONTO'][1]
				tolist[#tolist][2] = extraParam['POSITIONTO'][2]
				tolist[#tolist][3] = 1
			else
				for k1,v1 in pairs(extraParam['POSITIONSTO']) do
					if tolist[#tolist+1]==nil then
						tolist[#tolist+1] = {}
					end
					tolist[#tolist][1] = v1[1]
					tolist[#tolist][2] = v1[2]
					tolist[#tolist][3] = k1
				end
			end
			self.world:setAutoCreateHeroAISetting(extraParam['TEAM'][1],true,extraParam['NUM'][1],extraParam['CDTIME'][1],intXYlist,extraParam['RADIUS'][1],extraParam['SUBNAME'][1],tolist,extraParam['LEVEL'][1])
			parameter[k] = nil
		end
		if v=='STOPAUTOCREATEHEROAI' then
			self.world:setAutoCreateHeroAISetting(extraParam['TEAM'][1],false)
			parameter[k] = nil
		end
		if v=='CREATEAIHEROONECE' then
			local intXYlist,tolist = {},{}
			if extraParam['POSITION']~=nil then
				if intXYlist[#intXYlist+1]==nil then
					intXYlist[#intXYlist+1] = {}
				end
				intXYlist[#intXYlist][1] = extraParam['POSITION'][1]
				intXYlist[#intXYlist][2] = extraParam['POSITION'][2]
				intXYlist[#intXYlist][3] = 1
			else
				for k1,v1 in pairs(extraParam['POSITIONS']) do
					if intXYlist[#intXYlist+1]==nil then
						intXYlist[#intXYlist+1] = {}
					end
					intXYlist[#intXYlist][1] = v1[1]
					intXYlist[#intXYlist][2] = v1[2]
					intXYlist[#intXYlist][3] = k1
				end
			end
			if extraParam['POSITIONTO']~=nil then
				if tolist[#tolist+1]==nil then
					tolist[#tolist+1] = {}
				end
				tolist[#tolist][1] = extraParam['POSITIONTO'][1]
				tolist[#tolist][2] = extraParam['POSITIONTO'][2]
				tolist[#tolist][3] = 1
			else
				for k1,v1 in pairs(extraParam['POSITIONSTO']) do
					if tolist[#tolist+1]==nil then
						tolist[#tolist+1] = {}
					end
					tolist[#tolist][1] = v1[1]
					tolist[#tolist][2] = v1[2]
					tolist[#tolist][3] = k1
				end
			end
			self:createAIHeroOnece(extraParam['TEAM'][1],true,extraParam['NUM'][1],0,intXYlist,extraParam['RADIUS'][1],extraParam['SUBNAME'][1],tolist,extraParam['LEVEL'][1])
			parameter[k] = nil
		end
		if v=='STARTAUTOCREATEENEMY' then
			local intXYlist,tolist = {},{}
			if extraParam['POSITION']~=nil then
				if intXYlist[#intXYlist+1]==nil then
					intXYlist[#intXYlist+1] = {}
				end
				intXYlist[#intXYlist][1] = extraParam['POSITION'][1]
				intXYlist[#intXYlist][2] = extraParam['POSITION'][2]
				intXYlist[#intXYlist][3] = 1
			else
				for k1,v1 in pairs(extraParam['POSITIONS']) do
					if intXYlist[#intXYlist+1]==nil then
						intXYlist[#intXYlist+1] = {}
					end
					intXYlist[#intXYlist][1] = v1[1]
					intXYlist[#intXYlist][2] = v1[2]
					intXYlist[#intXYlist][3] = k1
				end
			end
			if extraParam['POSITIONTO']~=nil then
				if tolist[#tolist+1]==nil then
					tolist[#tolist+1] = {}
				end
				tolist[#tolist][1] = extraParam['POSITIONTO'][1]
				tolist[#tolist][2] = extraParam['POSITIONTO'][2]
				tolist[#tolist][3] = 1
			else
				for k1,v1 in pairs(extraParam['POSITIONSTO']) do
					if tolist[#tolist+1]==nil then
						tolist[#tolist+1] = {}
					end
					tolist[#tolist][1] = v1[1]
					tolist[#tolist][2] = v1[2]
					tolist[#tolist][3] = k1
				end
			end
			self.world:setAutoCreateEnemyAISetting(extraParam['ROLEID'][1],extraParam['TEAM'][1],true,extraParam['NUM'][1],extraParam['CDTIME'][1],intXYlist,extraParam['RADIUS'][1],extraParam['SUBNAME'][1],tolist)
			parameter[k] = nil
		end
		if v=='STOPAUTOCREATEENEMY' then
			self.world:setAutoCreateEnemyAISetting(extraParam['ROLEID'][1],extraParam['TEAM'][1],false)
			parameter[k] = nil
		end
		if v=='CREATEENEMYONECE' then
			local intXYlist,tolist = {},{}
			if extraParam['POSITION']~=nil then
				if intXYlist[#intXYlist+1]==nil then
					intXYlist[#intXYlist+1] = {}
				end
				intXYlist[#intXYlist][1] = extraParam['POSITION'][1]
				intXYlist[#intXYlist][2] = extraParam['POSITION'][2]
				intXYlist[#intXYlist][3] = 1
			else
				for k1,v1 in pairs(extraParam['POSITIONS']) do
					if intXYlist[#intXYlist+1]==nil then
						intXYlist[#intXYlist+1] = {}
					end
					intXYlist[#intXYlist][1] = v1[1]
					intXYlist[#intXYlist][2] = v1[2]
					intXYlist[#intXYlist][3] = k1
				end
			end
			if extraParam['POSITIONTO']~=nil then
				if tolist[#tolist+1]==nil then
					tolist[#tolist+1] = {}
				end
				tolist[#tolist][1] = extraParam['POSITIONTO'][1]
				tolist[#tolist][2] = extraParam['POSITIONTO'][2]
				tolist[#tolist][3] = 1
			else
				for k1,v1 in pairs(extraParam['POSITIONSTO']) do
					if tolist[#tolist+1]==nil then
						tolist[#tolist+1] = {}
					end
					tolist[#tolist][1] = v1[1]
					tolist[#tolist][2] = v1[2]
					tolist[#tolist][3] = k1
				end
			end
			self:createEnemyOnece(extraParam['ROLEID'][1],extraParam['TEAM'][1],true,extraParam['NUM'][1],0,intXYlist,extraParam['RADIUS'][1],extraParam['SUBNAME'][1],tolist)
			parameter[k] = nil
		end
		if v=='ADDTARGETTIPS' then
			local targetID,targetRole = 0,0
			for k1,v1 in pairs(self.world.allItemList) do
				if v1.subName==extraParam['SUBNAMETO'][1] then
					targetID = v1.itemID
					targetRole = v1.attribute.roleId
				end
			end
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					v1:addStatusList({zz=3,i=v1.itemID,s=984,r=self.world.gameTime,t=9999,p1=targetRole,p2=self.world.tonumber(self.world.setting['takeFireTime']),p3=targetID})
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					v1:addStatusList({zz=3,i=v1.itemID,s=984,r=self.world.gameTime,t=9999,p1=targetRole,p2=self.world.tonumber(self.world.setting['takeFireTime']),p3=targetID})
				end
			end
			parameter[k] = nil
		end
		if v=='ADDTARGETPOINT' then
			local targetID = 0
			for k1,v1 in pairs(self.world.allItemList) do
				if v1.subName==extraParam['SUBNAMETO'][1] then
					targetID = v1.itemID
				end
			end
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					v1:addStatusList({zz=3,i=v1.itemID,s=extraParam['ID'][1],r=self.world.gameTime,t=9999,p1=targetID})
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					v1:addStatusList({zz=3,i=v1.itemID,s=extraParam['ID'][1],r=self.world.gameTime,t=9999,p1=targetID})
				end
			end
			parameter[k] = nil
		end
		if v=='SETAUTOTOPOS' then
			for k1,v1 in pairs(self.world.allItemList) do
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					v1.autoToPos = true
					v1.autoToPosX = extraParam['POSITION'][1]
					v1.autoToPosY = extraParam['POSITION'][2]
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					v1.autoToPos = true
					v1.autoToPosX = extraParam['POSITION'][1]
					v1.autoToPosY = extraParam['POSITION'][2]
				end
			end
			parameter[k] = nil
		end
		if v=='STOPHEROREVIVE' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if extraParam['SUBNAME']~=nil then
					for k2,v2 in pairs(extraParam['SUBNAME']) do
						if v1.subName==v2 then
							v1.canRevive = false
						end
					end
				end
				if extraParam['ITEMID']~=nil then
					for k2,v2 in pairs(extraParam['ITEMID']) do
						if v1.subName==v2 then
							v1.canRevive = false
						end
					end
				end
			end
			parameter[k] = nil
		end
		if v=='STARTHEROREVIVE' then
			if self.world.gameFlag['pvpHeroReviveDelayStart'] then
				if self.world.gameFlag['pvpHeroAReviveDelay']~=0 then
					self.world.gameFlag['pvpHeroAReviveTime'] = self.world.gameTime - self.world.gameFlag['pvpHeroAReviveDelay']
				end
				if self.world.gameFlag['pvpHeroBReviveDelay']~=0 then
					self.world.gameFlag['pvpHeroBReviveTime'] = self.world.gameTime - self.world.gameFlag['pvpHeroBReviveDelay']
				end
			end
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if extraParam['SUBNAME']~=nil then
					for k2,v2 in pairs(extraParam['SUBNAME']) do
						if v1.subName==v2 then
							v1.canRevive = true
							if v1:isDead() and self.world.gameFlag['pvpHeroReviveDelayStart'] and self.world.gameFlag['pvpHero'..v1.team..'ReviveDelay']~=0 then
								v1.deadTime = self.world.gameFlag['pvpHero'..v1.team..'ReviveTime'] + self.world.gameFlag['pvpHero'..v1.team..'ReviveDelay']
								self.world.gameFlag['pvpHero'..v1.team..'ReviveTime'] = v1.deadTime
								self.world:D('jaylog STARTHEROREVIVE deadTime:',v1.deadTime,self.world.gameTime)
							end
						end
					end
				end
				if extraParam['ITEMID']~=nil then
					for k2,v2 in pairs(extraParam['ITEMID']) do
						if v1.subName==v2 then
							v1.canRevive = true
							if v1:isDead() and self.world.gameFlag['pvpHeroReviveDelayStart'] and self.world.gameFlag['pvpHero'..v1.team..'ReviveDelay']~=0 then
								v1.deadTime = self.world.gameFlag['pvpHero'..v1.team..'ReviveTime'] + self.world.gameFlag['pvpHero'..v1.team..'ReviveDelay']
								self.world.gameFlag['pvpHero'..v1.team..'ReviveTime'] = v1.deadTime
							end
						end
					end
				end
			end
			parameter[k] = nil
		end
		if v=='SETHEROREVIVEDELAY' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					v1.deadDelayTime = extraParam['TIMELEN'][1]
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					v1.deadDelayTime = extraParam['TIMELEN'][1]
				end
			end
			parameter[k] = nil
		end
		if v=='STARTPVPHEROREVIVEDELAY' then
			self.world.gameFlag.pvpHeroReviveDelayStart = true
			parameter[k] = nil
		end
		if v=='STOPPVPHEROREVIVEDELAY' then
			self.world.gameFlag.pvpHeroReviveDelayStart = false
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				v1.deadTime = v1.deadTime - self.world.gameFlag['pvpHero'..v1.team..'ReviveDelay']
			end
			parameter[k] = nil
		end
		if v=='SETPVPHEROREVIVEDELAY' then
			self.world.gameFlag['pvpHero'..extraParam['TEAM'][1]..'ReviveDelay'] = extraParam['TIMELEN'][1]
			parameter[k] = nil
		end
		if v=='MOVEAI' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if v1.actorType==0 and v1:isAIObj() and not v1:isDead() then
					local toX,toY = self.world.formula:getRandomCirclePoint(extraParam['POSITION'][1],extraParam['POSITION'][2],extraParam['RADIUS'][1])
					v1:moveTo(toX,toY)
				end
			end
			parameter[k] = nil
		end
		if v=='ADDNPCBUFF' then
			for k1,v1 in pairs(self.world.itemListFilter.noBeFightList) do
				if v1.subName==extraParam['SUBNAME'][1] then
					local lifeTime=99999
					local attributes = {}
					attributes['buffParameter']={}
					attributes['BUFFONLY']=1
					attributes['INEVITABLEHIT'] = 1
					attributes['buffParameter']['RANGE'] = extraParam['RADIUS'][1]
					attributes['buffParameter']['creatureDirectHurCallBack'] = self.itemID
					attributes['buffParameter']['buffIntervalTime'] = 0.5
					attributes['buffParameter']['buffType'] = 1
					attributes['buffParameter']['Effect'] = -1
					attributes['BUFFTIME'] = 99999
					local buff = require("gameroomcore.SBuff").new(self.world,v1:__skillID2buffID(0),attributes,lifeTime,{99},0,v1.itemID,v1.itemID,0.1)
					v1:addBuff(buff)
				end
			end
			parameter[k] = nil
		end
		if v=='CLEANSTATUS' then
			if extraParam['SUBNAME']~=nil then
				for k1,v1 in pairs(extraParam['SUBNAME']) do
					for k2,v2 in pairs(self.world.allItemList) do
						if v1==v2.subName then
							v2:removeStatusList(extraParam['ID'][1])
						end
					end
				end
			end
			if extraParam['ITEMID']~=nil then
				for k1,v1 in pairs(extraParam['ITEMID']) do
					for k2,v2 in pairs(self.world.itemListFilter.heroList) do
						if v1==v2.itemID then
							v2:removeStatusList(extraParam['ID'][1])
						end
					end
				end
			end
			parameter[k] = nil
		end
		if v=='SETATKTARGET' then
			local frList = {}
			local toList = {}
			local timelen = 0
			if extraParam['TIMELEN']~=nil then
				timelen = extraParam['TIMELEN'][1]
			end
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					frList[#frList+1] = k1
				end
				if extraParam['SUBNAMETO']~=nil and v1.subName==extraParam['SUBNAMETO'][1] then
					toList[#toList+1] = k1
				end
			end
			for k1,v1 in pairs(self.world.itemListFilter.soldierList) do
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					frList[#frList+1] = k1
				end
				if extraParam['SUBNAMETO']~=nil and v1.subName==extraParam['SUBNAMETO'][1] then
					toList[#toList+1] = k1
				end
			end
			local toIdx = swlf.world.formula:getRandnum(1,#toList)
			local toID = toList[toIdx]
			for k1,v1 in pairs(frList) do
				self.world.allItemList[k1]:setAITagretID(true,toID,timelen)
			end
			parameter[k] = nil
		end
		if v=='CLEANATKTARGET' then
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					self.world.allItemList[k1]:setAITagretID(false)
				end
			end
			for k1,v1 in pairs(self.world.itemListFilter.soldierList) do
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					self.world.allItemList[k1]:setAITagretID(false)
				end
			end
			parameter[k] = nil
		end
		if v=='STARTKILLCOUNT' then
			for k1,v1 in pairs(extraParam['SUBNAME']) do
				self.world:D('jaylog STARTKILLCOUNT:',v1,self.world.subNameDeadCounter[v1])
				self.world.subNameDeadCounter[v1] = 0
			end
			parameter[k] = nil
		end
		if v=='STARTAUTOFOLLOW' then
			local toID = 0
			if extraParam['SUBNAMETO']~=nil then
				for k1,v1 in pairs(self.world.itemListFilter.heroList) do
					if v1.subName==extraParam['SUBNAMETO'][1] then
						toID = v1.itemID
					end
				end
			end
			for k1,v1 in pairs(extraParam['SUBNAME']) do
				for k2,v2 in pairs(self.world.itemListFilter.heroList) do
					if v2.subName==v1 then
						if toID~=0 then
							v1:setAutoFollow(toID)
						else
							v1:setAutoFollow()
						end
					end
				end
			end
			parameter[k] = nil
		end
		if v=='STOPAUTOFOLLOW' then
			for k1,v1 in pairs(extraParam['SUBNAME']) do
				for k2,v2 in pairs(self.world.itemListFilter.heroList) do
					if v2.subName==v1 then
						v1:setAutoFollow()
					end
				end
			end
			parameter[k] = nil
		end
		for k1,v1 in pairs(self.world.itemListFilter.heroList) do
			if self.world.sFind(v,'SETCHANGEPARTHP')~=nil then
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' v1id:'..v1.itemID..' ext:'..self.world.cjson.encode(extraParam))
					v1.changePartHP = v1.attribute.MaxHP*extraParam['NUM'][1]*0.01-1
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' v1id:'..v1.itemID..' ext:'..self.world.cjson.encode(extraParam))
					v1.changePartHP = v1.attribute.MaxHP*extraParam['NUM'][1]*0.01-1
				end
				parameter[k] = nil
			end
			if self.world.sFind(v,'SETAICHANGEPARTHP')~=nil then
				if v1.actorType==0 and v1:isAIObj() then
					v1.changePartHP = v1.attribute.MaxHP*extraParam['NUM'][1]*0.01-1
				end
				parameter[k] = nil
			end
			if self.world.sFind(v,'SETBOSSPART')~=nil then
				if v1.subName==extraParam['SUBNAME'][1] then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' v1id:'..v1.itemID..' ext:'..self.world.cjson.encode(extraParam))
					v1.attribute.partType = extraParam['NUM'][1]
					v1.attribute.partTypeStartTime = self.world.gameTime
					parameter[k] = nil
				end
			end
			if v=='MOVE' then
				self.world:D('jaylog GameFlow:excuteParam endTime:',v1.moveToEndTime,' gt:',self.world.gameTime,v1.subName,v1.itemID)
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] and v1.moveToEndTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) and v1.lastCoolDownTime<self.world.gameTime then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
					local mtmsg
					if extraParam['POSITION']~=nil then
						mtmsg = v1:moveTo(extraParam['POSITION'][1],extraParam['POSITION'][2],false,7)
					end
					if extraParam['POSITIONOFFSET']~=nil then
						mtmsg = v1:moveTo(v1.posX+extraParam['POSITIONOFFSET'][1],v1.posY+extraParam['POSITIONOFFSET'][2],false,7)
					end
					if v1.actorType==0 then
						v1:setAutoBlocked(false,(v1.moveToEndTime-self.world:getGameTime())+0.1)
					end
					self.world:D('jaylog GameFlow:excuteParam MOVE heroList moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths))
					parameter[k] = nil
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] and v1.moveToEndTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) and v1.lastCoolDownTime<self.world.gameTime then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
					local mtmsg
					if extraParam['POSITION']~=nil then
						mtmsg = v1:moveTo(extraParam['POSITION'][1],extraParam['POSITION'][2],false,7)
					end
					if extraParam['POSITIONOFFSET']~=nil then
						mtmsg = v1:moveTo(v1.posX+extraParam['POSITIONOFFSET'][1],v1.posY+extraParam['POSITIONOFFSET'][2],false,7)
					end
					if v1.actorType==0 then
						v1:setAutoBlocked(false,(v1.moveToEndTime-self.world:getGameTime())+0.1)
					end
					self.world:D('jaylog GameFlow:excuteParam MOVE heroList moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths))
					parameter[k] = nil
				end
			end
			if v=='MOVETO' then
				-- if v1.subName==extraParam['SUBNAME'][1] then
				-- 	--self.world:debuglog('jaylog GameFlow:excuteParam endTime:',v1.moveToEndTime,' gt:',self.world.gameTime,' ls:',v1.lastSkill,' lcd:',v1.lastCoolDownTime)
				-- end
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] and v1.moveToEndTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) and v1.lastCoolDownTime<self.world.gameTime then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
					local mtmsg
					if extraParam['POSITION']~=nil then
						mtmsg = v1:moveTo(extraParam['POSITION'][1],extraParam['POSITION'][2],false,7)
						self.world:debuglog('jaylog GameFlow:excuteParam HERO MOVE heroList moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths),' moveToEndTime:',v1.moveToEndTime)
					end
					if extraParam['POSITIONOFFSET']~=nil then
						mtmsg = v1:moveTo(v1.posX+extraParam['POSITIONOFFSET'][1],v1.posY+extraParam['POSITIONOFFSET'][2],false,7)
					end
					if self.world.partMoveEndTime<v1.moveToEndTime then
						self.world.partMoveEndTime = v1.moveToEndTime
					end
					parameter[k] = nil
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] and v1.moveToEndTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) and v1.lastCoolDownTime<self.world.gameTime then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
					local mtmsg
					if extraParam['POSITION']~=nil then
						mtmsg = v1:moveTo(extraParam['POSITION'][1],extraParam['POSITION'][2],false,7)
						self.world:debuglog('jaylog GameFlow:excuteParam HERO MOVE heroList moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths),' moveToEndTime:',v1.moveToEndTime)
					end
					if extraParam['POSITIONOFFSET']~=nil then
						mtmsg = v1:moveTo(v1.posX+extraParam['POSITIONOFFSET'][1],v1.posY+extraParam['POSITIONOFFSET'][2],false,7)
					end
					if self.world.partMoveEndTime<v1.moveToEndTime then
						self.world.partMoveEndTime = v1.moveToEndTime
					end
					parameter[k] = nil
				end
			end
			-- if v=='TELEPORT' then
			-- 	--self.world:debuglog('jaylog GameFlow:excuteParam endTime:'..v1.moveToEndTime..' gt:'..self.world.gameTime)
			-- 	for k2,v2 in pairs(extraParam['SUBNAME']) do
			-- 		local subName = v2
			-- 		if v1.subName==v2 and v1.moveToEndTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) and v1.lastCoolDownTime<self.world.gameTime then
			-- 			--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
			-- 			local mtmsg = v1:moveTo(extraParam['POSITIONS'][k2][1],extraParam['POSITIONS'][k2][2],true,1,99999)
			-- 			--self.world:debuglog('jaylog GameFlow:excuteParam MOVE heroList moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths),' moveToEndTime:',v1.moveToEndTime)
			-- 			if self.world.partMoveEndTime<v1.moveToEndTime then
			-- 				self.world.partMoveEndTime = v1.moveToEndTime
			-- 			end
			-- 			parameter[k] = nil
			-- 		end
			-- 	end
			-- end
			if v=='SETHEROAISKILLID' then
				--用于数据策划房
				self.world.heroNeedSkillID = extraParam['ID'][1]
				parameter[k] = nil
			end
			if v=='SETHEROAISKILLTIME' then
				--用于数据策划房
				self.world.heroNeedSkillTime = extraParam['NUM'][1]*0.01
				parameter[k] = nil
			end
			if v=='CASTSKILL' then
				-- self.world:debuglog('jaylog GameFlow:excuteParam CASTSKILL ',v1.subName,extraParam['SUBNAME'][1],v1.moveToEndTime,self.world.gameTime,v1.lastCoolDownTime,self.world.gameTime,v1.lastSkill)
				if v1.subName==extraParam['SUBNAME'][1] and v1.moveToEndTime<self.world.gameTime and v1.lastCoolDownTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) then
					v1.lastSkill = v1:skillAttack(extraParam['ID'][1],k1)
					self.world:D('jaylog GameFlow:excuteParam CASTSKILL k:',k,' v:',self.world.cjson.encode(v),' ext:',self.world.cjson.encode(extraParam),' lastSkill:',self.world.cjson.encode(v1.lastSkill))
					if v1.lastSkill~=nil then
						v1.lastSkill = 0
						parameter[k] = nil
					end
				end
				if self.world.sFind(extraParam['SUBNAME'][1],'HERO')~=nil then
					if k1==self.world.tonumber(self.sSub(extraParam['SUBNAME'][1],6)) and v1.moveToEndTime<self.world.gameTime and v1.lastCoolDownTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) then
						v1.lastSkill = v1:skillAttack(extraParam['ID'][1],k1)
						if v1.lastSkill~=nil then
							v1.lastSkill = 0
							parameter[k] = nil
						end
					end
				end
			end
			if v=='CASTSKILLTARGET' then
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] and v1.moveToEndTime<self.world.gameTime and v1.lastCoolDownTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) then
					if extraParam['TARGETSUBNAME']~=nil then
						local targetID = k1
						for k2,v2 in pairs(self.world.allItemList) do
							if v2.subName==extraParam['TARGETSUBNAME'][1] then
								targetID = k2
							end
						end
						v1.lastSkill = v1:skillAttack(extraParam['ID'][1],targetID)
					elseif extraParam['ITEMID']~=nil then
						v1.lastSkill = v1:skillAttack(extraParam['ID'][1],extraParam['ITEMID'][1])
					elseif extraParam['POSITION']~=nil then
						v1.lastSkill = v1:skillAttack(extraParam['ID'][1],0,extraParam['POSITION'][1],extraParam['POSITION'][2])
					else
						v1.lastSkill = v1:skillAttack(extraParam['ID'][1],k1)
					end
					self.world:D('jaylog GameFlow:excuteParam CASTSKILLTARGET k:',k,' v:',self.world.cjson.encode(v),' ext:',self.world.cjson.encode(extraParam),' lastSkill:',self.world.cjson.encode(v1.lastSkill))
					if v1.lastSkill~=nil then
						v1.lastSkill = 0
						parameter[k] = nil
					end
				end
				if self.world.sFind(extraParam['SUBNAME'][1],'HERO')~=nil then
					if k1==self.world.tonumber(self.sSub(extraParam['SUBNAME'][1],5)) and v1.moveToEndTime<self.world.gameTime and v1.lastCoolDownTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) then
						v1.lastSkill = v1:skillAttack(extraParam['ID'][1],extraParam['ITEMID'][1])
						if v1.lastSkill~=nil then
							v1.lastSkill = 0
							parameter[k] = nil
						end
					end
				end
			end
			if self.world.sFind(v,'ADDSTATUS')~=nil then
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' heroList'..' ext:'..self.world.cjson.encode(extraParam))
					local data = {s=extraParam['ID'][1],t=extraParam['TIMELEN'][1]}
					if extraParam['PARAM1']~=nil then
						data['p1'] = extraParam['PARAM1'][1]
					end
					if extraParam['PARAM2']~=nil then
						data['p2'] = extraParam['PARAM2'][1]
					end
					if extraParam['PARAM3']~=nil then
						data['p3'] = extraParam['PARAM3'][1]
					end
					if extraParam['PARAM4']~=nil then
						data['p4'] = extraParam['PARAM4'][1]
					end
					if extraParam['PARAM5']~=nil then
						data['p5'] = extraParam['PARAM5'][1]
					end
					if extraParam['PARAM6']~=nil then
						data['p6'] = extraParam['PARAM6'][1]
					end
					if extraParam['CAMERAMODE']~=nil then
						data['p1'] = extraParam['CAMERAMODE'][1]
					end
					v1:addStatusList(data)
					if data['s']==88 then
						if v1.actorType==0 and not v1:isAIObj() then
							local num = 0
							if 8>self.world.sLen(data['p1']) then
								num = data['p1'] + 100000000
							end
							local idx = 1
							for i=9,2,-1 do
								v1.attribute.baseTable['SKILLOPEN'][idx] = self.world.tonumber(self.world.sSub(num,i,i))
								v1.attribute['SKILLOPEN'][idx] = self.world.tonumber(self.world.sSub(num,i,i))
								idx = idx + 1
							end
							if data['p3']~=nil and self.world.sSub(data['p3'],1,1)=='1' then
								self.world.playerList[v1.itemID]['playerJson']['Player']['dmOpen'] = 1
							end
							if data['p3']~=nil and self.world.sSub(data['p3'],2,2)=='1' then
								self.world.playerList[v1.itemID]['playerJson']['Player']['aiOpen'] = 1
							end
						end
					end
					parameter[k] = nil
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					local data = {s=extraParam['ID'][1],t=extraParam['TIMELEN'][1]}
					if extraParam['PARAM1']~=nil then
						data['p1'] = extraParam['PARAM1'][1]
					end
					if extraParam['PARAM2']~=nil then
						data['p2'] = extraParam['PARAM2'][1]
					end
					if extraParam['PARAM3']~=nil then
						data['p3'] = extraParam['PARAM3'][1]
					end
					if extraParam['PARAM4']~=nil then
						data['p4'] = extraParam['PARAM4'][1]
					end
					if extraParam['PARAM5']~=nil then
						data['p5'] = extraParam['PARAM5'][1]
					end
					if extraParam['PARAM6']~=nil then
						data['p6'] = extraParam['PARAM6'][1]
					end
					if extraParam['CAMERAMODE']~=nil then
						data['p1'] = extraParam['CAMERAMODE'][1]
					end
					v1:addStatusList(data)
					if data['s']==88 then
						if v1.actorType==0 and not v1:isAIObj() then
							local num = 0
							if 8>self.world.sLen(data['p1']) then
								num = data['p1'] + 100000000
							end
							local idx = 1
							for i=9,2,-1 do
								v1.attribute.baseTable['SKILLOPEN'][idx] = self.world.tonumber(self.world.sSub(num,i,i))
								v1.attribute['SKILLOPEN'][idx] = self.world.tonumber(self.world.sSub(num,i,i))
								idx = idx + 1
							end
							if data['p3']~=nil and self.world.sSub(data['p3'],1,1)=='1' then
								self.world.playerList[v1.itemID]['playerJson']['Player']['dmOpen'] = 1
							end
							if data['p3']~=nil and self.world.sSub(data['p3'],2,2)=='1' then
								self.world.playerList[v1.itemID]['playerJson']['Player']['aiOpen'] = 1
							end
						end
					end
					parameter[k] = nil
				end
			end
			-- if self.world.sFind(v,'CLEANSTATUS')~=nil then
			-- 	if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
			-- 		--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' heroList'..' ext:'..self.world.cjson.encode(extraParam))
			-- 		v1:removeStatusList(extraParam['ID'][1])
			-- 		parameter[k] = nil
			-- 	end
			-- 	if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
			-- 		--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' heroList'..' ext:'..self.world.cjson.encode(extraParam))
			-- 		v1:removeStatusList(extraParam['ID'][1])
			-- 		parameter[k] = nil
			-- 	end
			-- end
			if self.world.sFind(v,'CLEANBUFF')~=nil then
				if extraParam['TEAM']~=nil then
					if v1.teamOrig==extraParam['TEAM'][1] and v1.actorType==0 then
						--self.world:debuglog('jaylog GameFlow:excuteParam TEAM k:'..k..' v:'..self.world.cjson.encode(v)..' heroList'..' ext:'..self.world.cjson.encode(extraParam))
						v1:removeBUff(extraParam['BUFFNAME'][1])
						parameter[k] = nil
					end
				end
				if extraParam['SUBNAME']~=nil then
					if v1.subName==extraParam['SUBNAME'][1] then
						--self.world:debuglog('jaylog GameFlow:excuteParam SUBNAME k:'..k..' v:'..self.world.cjson.encode(v)..' heroList'..' ext:'..self.world.cjson.encode(extraParam))
						v1:removeBUff(extraParam['BUFFNAME'][1])
						parameter[k] = nil
					end
				end
				if extraParam['ITEMID']~=nil then
					if v1.itemID==extraParam['ITEMID'][1] then
						--self.world:debuglog('jaylog GameFlow:excuteParam SUBNAME k:'..k..' v:'..self.world.cjson.encode(v)..' heroList'..' ext:'..self.world.cjson.encode(extraParam))
						v1:removeBUff(extraParam['BUFFNAME'][1])
						parameter[k] = nil
					end
				end
			end
			if self.world.sFind(v,'ADDBUFF')~=nil then
				if extraParam['TEAM']~=nil then
					if v1.teamOrig==extraParam['TEAM'][1] and v1.actorType==0 then
						local attributes = {}
						local name = extraParam['BUFFNAME'][1]..'_RATE'
						attributes[name] = 100
						local duration = 9999
						if extraParam['TIMELEN']~=nil then
							duration = extraParam['TIMELEN'][1]
						end
						local buff = require("gameroomcore.SBuff").new(self.world,v1:__skillID2buffID(1),attributes,duration,{},0,v1.itemID,v1.itemID)
						v1:addBuff(buff)
						parameter[k] = nil
					end
				end
				if extraParam['SUBNAME']~=nil then
					if v1.subName==extraParam['SUBNAME'][1] then
						local attributes = {}
						local name = extraParam['BUFFNAME'][1]..'_RATE'
						attributes[name] = 100
						local duration = 9999
						if extraParam['TIMELEN']~=nil then
							duration = extraParam['TIMELEN'][1]
						end
						local buff = require("gameroomcore.SBuff").new(self.world,v1:__skillID2buffID(1),attributes,duration,{},0,v1.itemID,v1.itemID)
						v1:addBuff(buff)
						parameter[k] = nil
					end
				end
				if extraParam['ITEMID']~=nil then
					if v1.itemID==extraParam['ITEMID'][1] then
						local attributes = {}
						local name = extraParam['BUFFNAME'][1]..'_RATE'
						attributes[name] = 100
						local duration = 9999
						if extraParam['TIMELEN']~=nil then
							duration = extraParam['TIMELEN'][1]
						end
						local buff = require("gameroomcore.SBuff").new(self.world,v1:__skillID2buffID(1),attributes,duration,{},0,v1.itemID,v1.itemID)
						v1:addBuff(buff)
						parameter[k] = nil
					end
				end
			end
			if self.world.sFind(v,'CHANGESKIN')~=nil then
				if extraParam['SUBNAME']~=nil then
					if v1.subName==extraParam['SUBNAME'][1] then
						v1.skinNum = extraParam['SKINNO'][1]
						local result = v1:getAllInfo()
						v1:updateSyncMsg({i=result})
						parameter[k] = nil
					end
				end
			end
			if self.world.sFind(v,'RUNGUIDESTEP')~=nil then
				if extraParam['TEAM']~=nil and v1.teamOrig==extraParam['TEAM'][1] and v1.actorType==0 then
					flow[#flow+1]={i=v1.itemID,step=extraParam['STEP'][1]}
					parameter[k] = nil
				end
				if extraParam['ROLEID']~=nil and v1.actorType==0 then
					if v1.attribute.roleId==extraParam['ROLEID'][1] then
						flow[#flow+1]={i=v1.itemID,step=extraParam['STEP'][1]}
						parameter[k] = nil
					end
				end
			end
			if self.world.sFind(v,'GOCITY')~=nil then
				if v1.actorType==0 and v1.itemID==1 then
					-- self.world.itemListFilter.heroList[1]:addApiCall({},'default','refreshPlayerJsonObj')
					-- local finishapi = self.world.webapiurl..'default/refreshPlayerJsonObj'
					-- local url=finishapi..'/?Version=0.0.2&session='..self.world.playerList[v1.itemID]['s']
					-- local webresult=self.world:file_get_contents(url)
					-- self.world:D('jaylog webresult ',webresult)
					self.world.gameFlag['winTeam'] = 'A'
					local newArray = self.world:genGameOverData()
					if self.world.playerList[v1.itemID]['playerJson']['Player']['school']==1 then
						newArray[self.world.sFormat(self.world.playerList[v1.itemID]['p'])]['toX'] = extraParam['POSITIONS'][1][1]
						newArray[self.world.sFormat(self.world.playerList[v1.itemID]['p'])]['toY'] = extraParam['POSITIONS'][1][2]
					else
						newArray[self.world.sFormat(self.world.playerList[v1.itemID]['p'])]['toX'] = extraParam['POSITIONS'][2][1]
						newArray[self.world.sFormat(self.world.playerList[v1.itemID]['p'])]['toY'] = extraParam['POSITIONS'][2][2]
					end
					local gameID = self.world:memcacheGet('gameID'..self.world.playerList[v1.itemID]['p'])
					local finishapi = self.world.webapiurl..'pve/finishGame'
					local finishapi2 = self.world.webapiurl2..'pve/finishGame'
					if self.world.gameRoomSetting.ISLOCAL==1 then
						gameID = self.world.gameID
						finishapi = self.world.webapiurl..'pve/finishGameRoom'
						finishapi2 = self.world.webapiurl2..'pve/finishGameRoom'
					end
					if gameID==nil then
						gameID = 0
					end
					local url=finishapi..'/?data='..string.urlencode(self.world.cjson.encode(newArray))..'&Version=0.0.2&session='..self.world.playerList[v1.itemID]['s']..'&gameID='..gameID
					local webresult=self.world:file_get_contents(url)
					if (webresult==false) then
						url=finishapi2..'/?data='..string.urlencode(self.world.cjson.encode(newArray))..'&Version=0.0.2&session='..self.world.playerList[v1.itemID]['s']..'&gameID='..gameID
						webresult=self.world:file_get_contents(url)
					end
					self.world:D('jaylog webresult2 ',webresult)
					if self.world.playerList[v1.itemID]['playerJson']['Player']['school']==1 then
						local roomID = 3001
						self.world:redirectRoom(v1.itemID,10,roomID,nil,extraParam['POSITIONS'][1][1],extraParam['POSITIONS'][1][2])
					else
						local roomID = 3071
						self.world:redirectRoom(v1.itemID,60,roomID,nil,extraParam['POSITIONS'][2][1],extraParam['POSITIONS'][2][2])
					end
					parameter[k] = nil
				end
			end
			if self.world.sFind(v,'GOYW')~=nil then
				if v1.actorType==0 and not v1:isAIObj() then
					-- local newArray = {tKey='gameWin_'..self.world.worldNum,num=1,fromMap=fromMap,port=self.world.gameRoomInfoAll[fromMap]['port'],seqNo=self.world.gameTime}
					self.world.gameFlag['winTeam'] = 'A'
					local newArray = self.world:genGameOverData()
					if extraParam['POSITION']~=nil then
						newArray[self.world.sFormat(self.world.playerList[v1.itemID]['p'])]['toX'] = extraParam['POSITION'][1]
						newArray[self.world.sFormat(self.world.playerList[v1.itemID]['p'])]['toY'] = extraParam['POSITION'][2]
					else
						newArray[self.world.sFormat(self.world.playerList[v1.itemID]['p'])]['toX'] = v1.posX
						newArray[self.world.sFormat(self.world.playerList[v1.itemID]['p'])]['toY'] = v1.posY
					end
					if extraParam['TOMAP']~=nil then
						newArray[self.world.sFormat(self.world.playerList[v1.itemID]['p'])]['toMap'] = extraParam['TOMAP'][1]
					end
					local gameID = self.world:memcacheGet('gameID'..self.world.playerList[v1.itemID]['p'])
					local finishapi = self.world.webapiurl..'pve/finishGame'
					local finishapi2 = self.world.webapiurl2..'pve/finishGame'
					if self.world.gameRoomSetting.ISLOCAL==1 then
						gameID = self.world.gameID
						finishapi = self.world.webapiurl..'pve/finishGameRoom'
						finishapi2 = self.world.webapiurl2..'pve/finishGameRoom'
					end
					if gameID==nil then
						gameID = 0
					end
					local url=''
					if self.world.gameRoomSetting.ISLOCAL==1 then
						url = finishapi..'/?data='..string.urlencode(string.base64encode(self.world.cjson.encode(newArray)))..'&Version=0.0.2&session='..self.world.playerList[v1.itemID]['s']..'&gameID='..gameID
					else
						url = finishapi..'/?data='..string.urlencode(self.world.cjson.encode(newArray))..'&Version=0.0.2&session='..self.world.playerList[v1.itemID]['s']..'&gameID='..gameID
					end
					local webresult=self.world:file_get_contents(url)
					if (webresult==false) then
						if self.world.gameRoomSetting.ISLOCAL==1 then
							url=finishapi2..'/?data='..string.urlencode(string.base64encode(self.world.cjson.encode(newArray)))..'&Version=0.0.2&session='..self.world.playerList[v1.itemID]['s']..'&gameID='..gameID
						else
							url=finishapi2..'/?data='..string.urlencode(self.world.cjson.encode(newArray))..'&Version=0.0.2&session='..self.world.playerList[v1.itemID]['s']..'&gameID='..gameID
						end
						webresult=self.world:file_get_contents(url)
					end
					self.world:D('jaylog before GOYW call url:',url,' result:',webresult)
					--self.world:debuglog('jaylog GOYW ',v1.itemID,self.world.playerList[v1.itemID]['fm'],self.world.cjson.encode(self.gameRoomInfoAll[105]),v1.initX,v1.initY)
					local fromMap = self.world.tonumber(self.world.playerList[v1.itemID]['fm'])
					if extraParam['TOMAP']~=nil then
						fromMap = extraParam['TOMAP'][1]
					end
					if extraParam['POSITION']~=nil then
						self.world:redirectRoom(v1.itemID,fromMap,self.world.gameRoomInfoAll[fromMap]['port'],nil,extraParam['POSITION'][1],extraParam['POSITION'][2],nil,false,true)
					else
						self.world:redirectRoom(v1.itemID,fromMap,self.world.gameRoomInfoAll[fromMap]['port'],nil,v1.posX,v1.posY,nil,false,true)
					end
					self.world.gameFlag['isGameOverTime'] = self.world.gameTime + 0.5
					parameter[k] = nil
				end
			end
			if self.world.sFind(v,'UPDATETASK')~=nil then
				if v1.actorType==0 and not v1:isAIObj() and self.world.gameRoomSetting.ISLOCAL~=1 then
					-- self.world:D('jaylog UPDATETASK ',self.world.cjson.encode(self.world.playerList[v1.itemID]))
					-- local fromMap = self.world.tonumber(self.world.playerList[v1.itemID]['fm'])
					-- v1:addApiCall({tKey='gameWin_'..self.world.worldNum,num=1,fromMap=fromMap,port=self.world.gameRoomInfoAll[fromMap]['port'],seqNo=self.world.gameTime},'task','trigerCounter')
				end
				parameter[k] = nil
			end
			if v=='CLOSEAI' then
				if extraParam['SUBNAME']~=nil then
					for k2,v2 in pairs(extraParam['SUBNAME']) do
						if v1.subName==v2 then
							if v1.actorType==0 then
								-- self.world:removeItem(v1)
								self.world.playerList[v1.itemID]['online'] = false
								self.world.playerList[v1.itemID]['offLineTime'] = self.world.gameTime - self.world.gameRoomSetting.offlineRemoveWaitTime
							end
						end
					end
					parameter[k] = nil
				end
			end
			if v=='CLOSEACTOR' then
				if extraParam['SUBNAME']~=nil then
					for k2,v2 in pairs(extraParam['SUBNAME']) do
						if v1.subName==v2 then
							-- self.world:D('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' soldierList'..' ext:'..self.world.cjson.encode(extraParam))
							v1.attribute.HP = 0
							v1:directHurt(v1.itemID,1,{},0)
						end
					end
					parameter[k] = nil
				end
				if extraParam['ITEMID']~=nil then
					if v1.subName==extraParam['ITEMID'][1] then
						-- self.world:D('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' soldierList'..' ext:'..self.world.cjson.encode(extraParam))
						v1.attribute.HP = 0
						v1:directHurt(v1.itemID,1,{},0)
						parameter[k] = nil
					end
				end
			end
		end
		for k1,v1 in pairs(self.world.itemListFilter.soldierList) do
			if self.world.sFind(v,'SETCHANGEPARTHP')~=nil then
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' v1id:'..v1.itemID..' ext:'..self.world.cjson.encode(extraParam))
					v1.changePartHP = v1.attribute.MaxHP*extraParam['NUM'][1]*0.01-1
				end
				parameter[k] = nil
			end
			if self.world.sFind(v,'ADDSTATUS')~=nil then
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' soldierList'..' ext:'..self.world.cjson.encode(extraParam))
					local data = {s=extraParam['ID'][1],t=extraParam['TIMELEN'][1]}
					if extraParam['PARAM1']~=nil then
						data['p1'] = extraParam['PARAM1'][1]
					end
					if extraParam['PARAM2']~=nil then
						data['p2'] = extraParam['PARAM2'][1]
					end
					if extraParam['PARAM3']~=nil then
						data['p3'] = extraParam['PARAM3'][1]
					end
					if extraParam['PARAM4']~=nil then
						data['p4'] = extraParam['PARAM4'][1]
					end
					if extraParam['PARAM5']~=nil then
						data['p5'] = extraParam['PARAM5'][1]
					end
					if extraParam['PARAM6']~=nil then
						data['p6'] = extraParam['PARAM6'][1]
					end
					if extraParam['CAMERAMODE']~=nil then
						data['p1'] = extraParam['CAMERAMODE'][1]
					end
					v1:addStatusList(data)
					parameter[k] = nil
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' soldierList'..' ext:'..self.world.cjson.encode(extraParam))
					local data = {s=extraParam['ID'][1],t=extraParam['TIMELEN'][1]}
					if extraParam['PARAM1']~=nil then
						data['p1'] = extraParam['PARAM1'][1]
					end
					if extraParam['PARAM2']~=nil then
						data['p2'] = extraParam['PARAM2'][1]
					end
					if extraParam['PARAM3']~=nil then
						data['p3'] = extraParam['PARAM3'][1]
					end
					if extraParam['PARAM4']~=nil then
						data['p4'] = extraParam['PARAM4'][1]
					end
					if extraParam['PARAM5']~=nil then
						data['p5'] = extraParam['PARAM5'][1]
					end
					if extraParam['PARAM6']~=nil then
						data['p6'] = extraParam['PARAM6'][1]
					end
					if extraParam['CAMERAMODE']~=nil then
						data['p1'] = extraParam['CAMERAMODE'][1]
					end
					v1:addStatusList(data)
					parameter[k] = nil
				end
			end
			-- if self.world.sFind(v,'CLEANSTATUS')~=nil then
			-- 	if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
			-- 		--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' soldierList'..' ext:'..self.world.cjson.encode(extraParam))
			-- 		v1:removeStatusList(extraParam['ID'][1])
			-- 		parameter[k] = nil
			-- 	end
			-- 	if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
			-- 		--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' heroList'..' ext:'..self.world.cjson.encode(extraParam))
			-- 		v1:removeStatusList(extraParam['ID'][1])
			-- 		parameter[k] = nil
			-- 	end
			-- end
			if self.world.sFind(v,'CLEANBUFF')~=nil then
				if extraParam['TEAM']~=nil then
					if v1.teamOrig==extraParam['TEAM'][1] and v1.actorType==0 then
						--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' soldierList'..' ext:'..self.world.cjson.encode(extraParam))
						v1:removeBUff(extraParam['BUFFNAME'][1])
						parameter[k] = nil
					end
				end
				if extraParam['SUBNAME']~=nil then
					if v1.subName==extraParam['SUBNAME'][1] then
						--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' soldierList'..' ext:'..self.world.cjson.encode(extraParam))
						v1:removeBUff(extraParam['BUFFNAME'][1])
						parameter[k] = nil
					end
				end
				if extraParam['ITEMID']~=nil then
					if v1.itemID==extraParam['ITEMID'][1] then
						--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' soldierList'..' ext:'..self.world.cjson.encode(extraParam))
						v1:removeBUff(extraParam['BUFFNAME'][1])
						parameter[k] = nil
					end
				end
			end
			if self.world.sFind(v,'ADDBUFF')~=nil then
				-- if extraParam['TEAM']~=nil then
				-- 	if v1.teamOrig==extraParam['TEAM'][1] and v1.actorType==0 then
				-- 		local attributes = {}
				-- 		local name = extraParam['BUFFNAME'][1]..'_RATE'
				-- 		attributes[name] = 100
				-- 		local buff = require("gameroomcore.SBuff").new(self,v1:__skillID2buffID(1),attributes,1,{},0,v1.itemID,v1.itemID)
				-- 		v1:addBuff(buff)
				-- 		parameter[k] = nil
				-- 	end
				-- end
				if extraParam['SUBNAME']~=nil then
					if v1.subName==extraParam['SUBNAME'][1] then
						local attributes = {}
						local name = extraParam['BUFFNAME'][1]..'_RATE'
						attributes[name] = 100
						local duration = 9999
						if extraParam['TIMELEN']~=nil then
							duration = extraParam['TIMELEN'][1]
						end
						local buff = require("gameroomcore.SBuff").new(self.world,v1:__skillID2buffID(1),attributes,duration,{},0,v1.itemID,v1.itemID)
						v1:addBuff(buff)
						parameter[k] = nil
					end
				end
				if extraParam['ITEMID']~=nil then
					if v1.itemID==extraParam['ITEMID'][1] then
						local attributes = {}
						local name = extraParam['BUFFNAME'][1]..'_RATE'
						attributes[name] = 100
						local duration = 9999
						if extraParam['TIMELEN']~=nil then
							duration = extraParam['TIMELEN'][1]
						end
						local buff = require("gameroomcore.SBuff").new(self.world,v1:__skillID2buffID(1),attributes,duration,{},0,v1.itemID,v1.itemID)
						v1:addBuff(buff)
						parameter[k] = nil
					end
				end
			end
			if self.world.sFind(v,'CLOSE')~=nil then
				if extraParam['SUBNAME']~=nil then
					for k2,v2 in pairs(extraParam['SUBNAME']) do
						if v1.subName==v2 then
							-- self.world:D('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' soldierList'..' ext:'..self.world.cjson.encode(extraParam))
							v1.attribute.HP = 0
							v1:directHurt(v1.itemID,1,{},0)
						end
					end
					parameter[k] = nil
				end
				if self.world.sFind(v,'BLOCK')~=nil then
					self.world.map:removeTmpBlockByLine(extraParam['BLOCKID'][1])
					parameter[k] = nil
				end
			end
			if self.world.sFind(v,'CHANGESKIN')~=nil then
				if extraParam['SUBNAME']~=nil then
					if v1.subName==extraParam['SUBNAME'][1] then
						v1.skinNum = extraParam['SKINNO'][1]
						local result = v1:getAllInfo()
						v1:updateSyncMsg({i=result})
						parameter[k] = nil
					end
				end
			end
			if v=='MOVE' then
				--self.world:debuglog('jaylog GameFlow:excuteParam soldierList endTime:',v1.moveToEndTime,' gt:',self.world.gameTime,' ls:',v1.lastSkill,' lcd:',v1.lastCoolDownTime)
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] and v1.moveToEndTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) and v1.lastCoolDownTime<self.world.gameTime then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
					local mtmsg
					if extraParam['POSITION']~=nil then
						mtmsg = v1:moveTo(extraParam['POSITION'][1],extraParam['POSITION'][2],false,7)
					end
					if extraParam['POSITIONOFFSET']~=nil then
						mtmsg = v1:moveTo(v1.posX+extraParam['POSITIONOFFSET'][1],v1.posY+extraParam['POSITIONOFFSET'][2],false,7)
					end
					--self.world:debuglog('jaylog GameFlow:excuteParam soldierList syncMsg',self.world.cjson.encode(v1.syncMsg),' moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths))
					parameter[k] = nil
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] and v1.moveToEndTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) and v1.lastCoolDownTime<self.world.gameTime then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
					local mtmsg
					if extraParam['POSITION']~=nil then
						mtmsg = v1:moveTo(extraParam['POSITION'][1],extraParam['POSITION'][2],false,7)
					end
					if extraParam['POSITIONOFFSET']~=nil then
						mtmsg = v1:moveTo(v1.posX+extraParam['POSITIONOFFSET'][1],v1.posY+extraParam['POSITIONOFFSET'][2],false,7)
					end
					--self.world:debuglog('jaylog GameFlow:excuteParam soldierList syncMsg',self.world.cjson.encode(v1.syncMsg),' moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths))
					parameter[k] = nil
				end
			end
			if v=='MOVETO' then
				--self.world:debuglog('jaylog GameFlow:excuteParam endTime:'..v1.moveToEndTime..' gt:'..self.world.gameTime)
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] and v1.moveToEndTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) and v1.lastCoolDownTime<self.world.gameTime then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
					local mtmsg
					if extraParam['POSITION']~=nil then
						mtmsg = v1:moveTo(extraParam['POSITION'][1],extraParam['POSITION'][2],false,7)
					end
					if extraParam['POSITIONOFFSET']~=nil then
						mtmsg = v1:moveTo(v1.posX+extraParam['POSITIONOFFSET'][1],v1.posY+extraParam['POSITIONOFFSET'][2],false,7)
					end
					self.world:debuglog('jaylog GameFlow:excuteParam soldier MOVE heroList moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths),' moveToEndTime:',v1.moveToEndTime)
					if self.world.partMoveEndTime<v1.moveToEndTime then
						self.world.partMoveEndTime = v1.moveToEndTime
					end
					parameter[k] = nil
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] and v1.moveToEndTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) and v1.lastCoolDownTime<self.world.gameTime then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
					local mtmsg
					if extraParam['POSITION']~=nil then
						mtmsg = v1:moveTo(extraParam['POSITION'][1],extraParam['POSITION'][2],false,7)
					end
					if extraParam['POSITIONOFFSET']~=nil then
						mtmsg = v1:moveTo(v1.posX+extraParam['POSITIONOFFSET'][1],v1.posY+extraParam['POSITIONOFFSET'][2],false,7)
					end
					self.world:debuglog('jaylog GameFlow:excuteParam soldier MOVE heroList moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths),' moveToEndTime:',v1.moveToEndTime)
					if self.world.partMoveEndTime<v1.moveToEndTime then
						self.world.partMoveEndTime = v1.moveToEndTime
					end
					parameter[k] = nil
				end
			end
			-- if v=='TELEPORT' then
			-- 	--self.world:debuglog('jaylog GameFlow:excuteParam endTime:'..v1.moveToEndTime..' gt:'..self.world.gameTime)
			-- 	for k2,v2 in pairs(extraParam['SUBNAME']) do
			-- 		local subName = v2
			-- 		if v1.subName==v2 and v1.moveToEndTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) and v1.lastCoolDownTime<self.world.gameTime then
			-- 			--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
			-- 			local mtmsg = v1:moveTo(extraParam['POSITIONS'][k2][1],extraParam['POSITIONS'][k2][2],true,1,99999)
			-- 			--self.world:debuglog('jaylog GameFlow:excuteParam MOVE heroList moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths),' moveToEndTime:',v1.moveToEndTime)
			-- 			if self.world.partMoveEndTime<v1.moveToEndTime then
			-- 				self.world.partMoveEndTime = v1.moveToEndTime
			-- 			end
			-- 			parameter[k] = nil
			-- 		end
			-- 	end
			-- end
		end
		for k1,v1 in pairs(self.world.itemListFilter.noBeFightList) do
			if self.world.sFind(v,'ADDSTATUS')~=nil then
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' soldierList'..' ext:'..self.world.cjson.encode(extraParam))
					local data = {s=extraParam['ID'][1],t=extraParam['TIMELEN'][1]}
					if extraParam['PARAM1']~=nil then
						data['p1'] = extraParam['PARAM1'][1]
					end
					if extraParam['PARAM2']~=nil then
						data['p2'] = extraParam['PARAM2'][1]
					end
					if extraParam['PARAM3']~=nil then
						data['p3'] = extraParam['PARAM3'][1]
					end
					if extraParam['PARAM4']~=nil then
						data['p4'] = extraParam['PARAM4'][1]
					end
					if extraParam['PARAM5']~=nil then
						data['p5'] = extraParam['PARAM5'][1]
					end
					if extraParam['PARAM6']~=nil then
						data['p6'] = extraParam['PARAM6'][1]
					end
					if extraParam['CAMERAMODE']~=nil then
						data['p1'] = extraParam['CAMERAMODE'][1]
					end
					v1:addStatusList(data)
					parameter[k] = nil
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' soldierList'..' ext:'..self.world.cjson.encode(extraParam))
					local data = {s=extraParam['ID'][1],t=extraParam['TIMELEN'][1]}
					if extraParam['PARAM1']~=nil then
						data['p1'] = extraParam['PARAM1'][1]
					end
					if extraParam['PARAM2']~=nil then
						data['p2'] = extraParam['PARAM2'][1]
					end
					if extraParam['PARAM3']~=nil then
						data['p3'] = extraParam['PARAM3'][1]
					end
					if extraParam['PARAM4']~=nil then
						data['p4'] = extraParam['PARAM4'][1]
					end
					if extraParam['PARAM5']~=nil then
						data['p5'] = extraParam['PARAM5'][1]
					end
					if extraParam['PARAM6']~=nil then
						data['p6'] = extraParam['PARAM6'][1]
					end
					if extraParam['CAMERAMODE']~=nil then
						data['p1'] = extraParam['CAMERAMODE'][1]
					end
					v1:addStatusList(data)
					parameter[k] = nil
				end
			end
			-- if self.world.sFind(v,'CLEANSTATUS')~=nil then
			-- 	if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] then
			-- 		--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' soldierList'..' ext:'..self.world.cjson.encode(extraParam))
			-- 		v1:removeStatusList(extraParam['ID'][1])
			-- 		parameter[k] = nil
			-- 	end
			-- 	if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] then
			-- 		--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' soldierList'..' ext:'..self.world.cjson.encode(extraParam))
			-- 		v1:removeStatusList(extraParam['ID'][1])
			-- 		parameter[k] = nil
			-- 	end
			-- end
			if self.world.sFind(v,'CLEANBUFF')~=nil then
				-- if extraParam['TEAM']~=nil then
				-- 	if v1.teamOrig==extraParam['TEAM'][1] then
				-- 		--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' soldierList'..' ext:'..self.world.cjson.encode(extraParam))
				-- 		v1:removeBUff(extraParam['BUFFNAME'][1])
				-- 		parameter[k] = nil
				-- 	end
				-- end
				if extraParam['SUBNAME']~=nil then
					if v1.subName==extraParam['SUBNAME'][1] then
						--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' soldierList'..' ext:'..self.world.cjson.encode(extraParam))
						v1:removeBUff(extraParam['BUFFNAME'][1])
						parameter[k] = nil
					end
				end
				if extraParam['ITEMID']~=nil then
					if v1.itemID==extraParam['ITEMID'][1] then
						--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' soldierList'..' ext:'..self.world.cjson.encode(extraParam))
						v1:removeBUff(extraParam['BUFFNAME'][1])
						parameter[k] = nil
					end
				end
			end
			if self.world.sFind(v,'ADDBUFF')~=nil then
				if extraParam['TEAM']~=nil then
					if v1.teamOrig==extraParam['TEAM'][1] then
						local attributes = {}
						local name = extraParam['BUFFNAME'][1]..'_RATE'
						attributes[name] = 100
						local duration = 9999
						if extraParam['TIMELEN']~=nil then
							duration = extraParam['TIMELEN'][1]
						end
						local buff = require("gameroomcore.SBuff").new(self.world,v1:__skillID2buffID(1),attributes,duration,{},0,v1.itemID,v1.itemID)
						v1:addBuff(buff)
						parameter[k] = nil
					end
				end
				if extraParam['SUBNAME']~=nil then
					if v1.subName==extraParam['SUBNAME'][1] then
						local attributes = {}
						local name = extraParam['BUFFNAME'][1]..'_RATE'
						attributes[name] = 100
						local duration = 9999
						if extraParam['TIMELEN']~=nil then
							duration = extraParam['TIMELEN'][1]
						end
						local buff = require("gameroomcore.SBuff").new(self.world,v1:__skillID2buffID(1),attributes,duration,{},0,v1.itemID,v1.itemID)
						v1:addBuff(buff)
						parameter[k] = nil
					end
				end
				if extraParam['ITEMID']~=nil then
					if v1.itemID==extraParam['ITEMID'][1] then
						local attributes = {}
						local name = extraParam['BUFFNAME'][1]..'_RATE'
						attributes[name] = 100
						local duration = 9999
						if extraParam['TIMELEN']~=nil then
							duration = extraParam['TIMELEN'][1]
						end
						local buff = require("gameroomcore.SBuff").new(self.world,v1:__skillID2buffID(1),attributes,duration,{},0,v1.itemID,v1.itemID)
						v1:addBuff(buff)
						parameter[k] = nil
					end
				end
			end
			if self.world.sFind(v,'CLOSE')~=nil then
				if extraParam['SUBNAME']~=nil then
					for k2,v2 in pairs(extraParam['SUBNAME']) do
						if v1.subName==v2 then
							-- self.world:D('jaylog GameFlow:excuteParam k:'..k1..' v:'..self.world.cjson.encode(v)..' noBeFightList'..' ext:'..self.world.cjson.encode(extraParam))
							v1.attribute.HP = 0
							v1:directHurt(v1.itemID,1,{},0)
							if self.world.sFind(v,'BLOCK')~=nil then
								self.world.map:removeTmpBlockByLine(extraParam['BLOCKID'][1])
							end
						end
					end
					parameter[k] = nil
				else
					if self.world.sFind(v,'BLOCK')~=nil then
						self.world.map:removeTmpBlockByLine(extraParam['BLOCKID'][1])
						parameter[k] = nil
					end
				end
			end
			if self.world.sFind(v,'CHANGESKIN')~=nil then
				if extraParam['SUBNAME']~=nil then
					if v1.subName==extraParam['SUBNAME'][1] then
						v1.skinNum = extraParam['SKINNO'][1]
						local result = v1:getAllInfo()
						v1:updateSyncMsg({i=result})
						parameter[k] = nil
					end
				end
			end
			if v=='MOVE' then
				--self.world:debuglog('jaylog GameFlow:excuteParam noBeFightList endTime:',v1.moveToEndTime,' gt:',self.world.gameTime,' ls:',v1.lastSkill,' lcd:',v1.lastCoolDownTime)
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] and v1.moveToEndTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) and v1.lastCoolDownTime<self.world.gameTime then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
					local mtmsg
					if extraParam['POSITION']~=nil then
						mtmsg = v1:moveTo(extraParam['POSITION'][1],extraParam['POSITION'][2],false,7)
					end
					if extraParam['POSITIONOFFSET']~=nil then
						mtmsg = v1:moveTo(v1.posX+extraParam['POSITIONOFFSET'][1],v1.posY+extraParam['POSITIONOFFSET'][2],false,7)
					end
					--self.world:debuglog('jaylog GameFlow:excuteParam noBeFightList syncMsg',self.world.cjson.encode(v1.syncMsg),' debugPaths',self.world.cjson.encode(v1.debugPaths),' moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths))
					parameter[k] = nil
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] and v1.moveToEndTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) and v1.lastCoolDownTime<self.world.gameTime then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
					local mtmsg
					if extraParam['POSITION']~=nil then
						mtmsg = v1:moveTo(extraParam['POSITION'][1],extraParam['POSITION'][2],false,7)
					end
					if extraParam['POSITIONOFFSET']~=nil then
						mtmsg = v1:moveTo(v1.posX+extraParam['POSITIONOFFSET'][1],v1.posY+extraParam['POSITIONOFFSET'][2],false,7)
					end
					--self.world:debuglog('jaylog GameFlow:excuteParam noBeFightList syncMsg',self.world.cjson.encode(v1.syncMsg),' debugPaths',self.world.cjson.encode(v1.debugPaths),' moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths))
					parameter[k] = nil
				end
			end
			if v=='MOVETO' then
				--self.world:debuglog('jaylog GameFlow:excuteParam endTime:'..v1.moveToEndTime..' gt:'..self.world.gameTime)
				if extraParam['SUBNAME']~=nil and v1.subName==extraParam['SUBNAME'][1] and v1.moveToEndTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) and v1.lastCoolDownTime<self.world.gameTime then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
					local mtmsg
					if extraParam['POSITION']~=nil then
						mtmsg = v1:moveTo(extraParam['POSITION'][1],extraParam['POSITION'][2],false,7)
					end
					if extraParam['POSITIONOFFSET']~=nil then
						mtmsg = v1:moveTo(v1.posX+extraParam['POSITIONOFFSET'][1],v1.posY+extraParam['POSITIONOFFSET'][2],false,7)
					end
					--self.world:debuglog('jaylog GameFlow:excuteParam noBeFightList MOVE heroList moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths),' moveToEndTime:',v1.moveToEndTime)
					if self.world.partMoveEndTime<v1.moveToEndTime then
						self.world.partMoveEndTime = v1.moveToEndTime
					end
					parameter[k] = nil
				end
				if extraParam['ITEMID']~=nil and v1.itemID==extraParam['ITEMID'][1] and v1.moveToEndTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) and v1.lastCoolDownTime<self.world.gameTime then
					--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
					local mtmsg
					if extraParam['POSITION']~=nil then
						mtmsg = v1:moveTo(extraParam['POSITION'][1],extraParam['POSITION'][2],false,7)
					end
					if extraParam['POSITIONOFFSET']~=nil then
						mtmsg = v1:moveTo(v1.posX+extraParam['POSITIONOFFSET'][1],v1.posY+extraParam['POSITIONOFFSET'][2],false,7)
					end
					--self.world:debuglog('jaylog GameFlow:excuteParam noBeFightList MOVE heroList moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths),' moveToEndTime:',v1.moveToEndTime)
					if self.world.partMoveEndTime<v1.moveToEndTime then
						self.world.partMoveEndTime = v1.moveToEndTime
					end
					parameter[k] = nil
				end
			end
			-- if v=='TELEPORT' then
			-- 	--self.world:debuglog('jaylog GameFlow:excuteParam endTime:'..v1.moveToEndTime..' gt:'..self.world.gameTime)
			-- 	for k2,v2 in pairs(extraParam['SUBNAME']) do
			-- 		local subName = v2
			-- 		if v1.subName==v2 and v1.moveToEndTime<self.world.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) and v1.lastCoolDownTime<self.world.gameTime then
			-- 			--self.world:debuglog('jaylog GameFlow:excuteParam k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
			-- 			local mtmsg = v1:moveTo(extraParam['POSITIONS'][k2][1],extraParam['POSITIONS'][k2][2],true,1,99999)
			-- 			--self.world:debuglog('jaylog GameFlow:excuteParam MOVE heroList moveToRet:',self.world.cjson.encode(mtmsg),' paths:',self.world.cjson.encode(v1.paths),' moveToEndTime:',v1.moveToEndTime)
			-- 			if self.world.partMoveEndTime<v1.moveToEndTime then
			-- 				self.world.partMoveEndTime = v1.moveToEndTime
			-- 			end
			-- 			parameter[k] = nil
			-- 		end
			-- 	end
			-- end
		end
		if self.world.sFind(v,'RUNFUNC')~=nil then
			local ret = false
			if extraParam['AUTOTRANSPOSITIONSET']~=nil then
				extraParam['TRANSPOSITIONSET'] = {}
				local tx = extraParam['AUTOTRANSPOSITIONSET'][1][1]-extraParam['AUTOTRANSPOSITIONSET'][2][1]
				local ty = extraParam['AUTOTRANSPOSITIONSET'][1][2]-extraParam['AUTOTRANSPOSITIONSET'][2][2]
				local x1 = extraParam['AUTOTRANSPOSITIONSET'][1][1]
				local y1 = extraParam['AUTOTRANSPOSITIONSET'][1][2]
				local x4 = extraParam['AUTOTRANSPOSITIONSET'][2][1]
				local y4 = extraParam['AUTOTRANSPOSITIONSET'][2][2]
				local x2,y2,x3,y3 = 0,0,0,0
				local bw,lw = 2,3
				if tx~=0 then
					x2 = x1 - bw	--tx*0.5
					y2 = y1 - lw
					x3 = x1 - bw	--tx*0.5
					y3 = y1 + lw
				end
				if ty~=0 then
					x2 = x1 - lw	--3
					y2 = y1 - bw	--ty*0.5
					x3 = x1 + lw	--3
					y3 = y1 - bw	--ty*0.5
				end
				extraParam['TRANSPOSITIONSET'][1] = {1,x1,y1}
				extraParam['TRANSPOSITIONSET'][2] = {2,x2,y2}
				extraParam['TRANSPOSITIONSET'][3] = {3,x3,y3}
				for i=1,3 do
					for j=1,2 do
						local num = i+3*j
						local preNum = num-3
						extraParam['TRANSPOSITIONSET'][num] = {extraParam['TRANSPOSITIONSET'][preNum][1]+3,extraParam['TRANSPOSITIONSET'][preNum][2]+tx,extraParam['TRANSPOSITIONSET'][preNum][3]+ty}
					end
				end
				if extraParam['TRANSPOSITIONORDER']==nil then
					extraParam['TRANSPOSITIONORDER'] = {2,1,3,5,4,7,6,8,10,9}
				end
			end
			if self.world.sFind(v,'TRANSPOSITION')~=nil then
				--self.world:debuglog('jaylog GameFlow:excuteParam TRANSPOSITION k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
				ret = self:runTransposition(extraParam['TRANSPOSITIONSET'],extraParam['TRANSPOSITIONORDER'],extraParam['TRANSPOSITIONMOVE'],extraParam['SETBYORDER'])
			end
			if self.world.sFind(v,'TRANSSIGLE')~=nil then
				--self.world:debuglog('jaylog GameFlow:excuteParam TRANSPOSITION k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
				ret = self:runTransSigle(extraParam['TRANSPOSITIONSET'],extraParam['TRANSPOSITIONORDER'],extraParam['TRANSPOSITIONMOVE'])
			end
			if self.world.sFind(v,'EXTRAFUNC')~=nil then
				--self.world:debuglog('jaylog GameFlow:excuteParam EXTRAFUNC k:'..k..' v:'..self.world.cjson.encode(v)..' ext:'..self.world.cjson.encode(extraParam))
				ret = self.world:runExtraParam(extraParam)
			end
			if ret then
				parameter[k] = nil
			end
		end
		if self.world.sFind(v,'RUNGUIDESTEP')~=nil then
			self.world:addSyncMsg({flow=flow})
			parameter[k] = nil
		end
		if self.world.sFind(v,'CLOSE')~=nil then
			-- 如果没有可以CLOSE的角色则将参数清空，完成此步
			parameter[k] = nil
		end
	end
	self.world:D('jaylog GameFlow:excuteParam ret param:',self.world.cjson.encode(parameter))
	return parameter
end

--- 流程方法，按位置排列并移动指定距离
-- @param linePosition table - 位置点集，ex:[{顺序号,x,y},{顺序号,x,y},...]
-- @param lineOrder table - 角色位置顺序，ex:[[roleID,roleID,roleID],[roleID,roleID,roleID]]
-- @param lineMoveDis table - 角色到达位置点集后偏移量，ex:[x,y]
-- @param setByOrder table - 是否直接按lineOrder的顺序将角色填到点内
-- @return stepNo int - 执行到的步骤1或2
function GameFlow:runTransposition(linePosition,lineOrder,lineMoveDis,setByOrder)
	-- set line order
	local setLineOrder = {}
	local itemOrder = {}
	local team = self.world.itemListFilter.heroList[1].teamOrig
	if self.world.tNums(lineOrder)~=2 then
		setLineOrder = lineOrder
	else
		if self.world.itemListFilter.heroList[1].attribute.roleId<6 then
			setLineOrder = lineOrder[1]
		else
			setLineOrder = lineOrder[2]
		end
	end
	for k,v in pairs(setLineOrder) do
		for k1,v1 in pairs(self.world.itemListFilter.heroList) do
			if not v1:isDead() and (v1.attribute.roleId==v or v1.attribute.roleId==(v-5) or v1.attribute.roleId==(v+5) ) and v1.teamOrig==team then
				if setByOrder~=nil then
					itemOrder[v1.itemID] = k
				else
					if v1.attribute.roleId==v then
						itemOrder[v1.itemID] = table.nums(itemOrder)+1
					end
				end
			end
		end
	end
	-- start move
	if lineMoveDis==nil then
		for k,v in pairs(linePosition) do
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if itemOrder[v1.itemID]==v[1] then
					-- self.world:D('jaylog runTransposition moveTo 1 ',v1.loginID,v1.posX,v1.posY,v[2],v[3])
					v1:moveTo(v[2],v[3],true,1,99999)
				end
			end
		end
	else
		for k,v in pairs(linePosition) do
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if itemOrder[v1.itemID]==v[1] then
					-- self.world:D('jaylog runTransposition moveTo 7 ',v1.loginID,v1.posX,v1.posY,v[2]+lineMoveDis[1],v[3]+lineMoveDis[2])
					v1:moveTo(v[2]+lineMoveDis[1],v[3]+lineMoveDis[2],true,7)
				end
			end
		end
	end
	return true
end

--- 流程方法，单一玩家按位置排列并移动指定距离
-- @param linePosition table - 位置点集，ex:[{顺序号,x,y},{顺序号,x,y},...]
-- @param lineOrder table - 角色位置顺序，ex:[[roleID,roleID,roleID],[roleID,roleID,roleID]]
-- @param lineMoveDis table - 角色到达位置点集后偏移量，ex:[x,y]
-- @return stepNo int - 执行到的步骤1或2
function GameFlow:runTransSigle(linePosition,lineOrder,lineMoveDis)
	-- set line order
	local setLineOrder = {}
	local itemOrder = {}
	if self.world.tNums(lineOrder)~=2 then
		setLineOrder = lineOrder
	else
		if self.world.itemListFilter.heroList[1].attribute.roleId<6 then
			setLineOrder = lineOrder[1]
		else
			setLineOrder = lineOrder[2]
		end
	end
	for k,v in pairs(setLineOrder) do
		for k1,v1 in pairs(self.world.itemListFilter.heroList) do
			if k1==1 and not v1:isDead() and v1.attribute.roleId==v then
				itemOrder[v1.itemID] = table.nums(itemOrder)+1
			end
		end
	end
	-- start move
	if lineMoveDis==nil then
		for k,v in pairs(linePosition) do
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if itemOrder[v1.itemID]==v[1] then
					v1:moveTo(v[2],v[3],true,1,99999)
				end
			end
		end
	else
		for k,v in pairs(linePosition) do
			for k1,v1 in pairs(self.world.itemListFilter.heroList) do
				if itemOrder[v1.itemID]==v[1] then
					v1:moveTo(v[2]+lineMoveDis[1],v[3]+lineMoveDis[2],true,7)
				end
			end
		end
	end
	return true
end

--- 流程方法，单一玩家按位置排列并移动指定距离
-- @param roleID integer - 自身角色ID
-- @param worldNum integer - 所在world的NUM
-- @return result table - 返回MATCHKEY对应的ID,NAME table,ex:{K1={ID1=1,NAME1=ABC}}
function GameFlow:getMatchData(roleID,worldNum)
	local result = {}
	local sql = "select * from flow_changeRole where world='"..worldNum.."' and roleID='"..roleID.."'"
	local data = self.world:getDBData(sql)
	if data==nil or empty(data) or self.world.tNums(data)==0 then
		sql = "select * from flow_changeRole where world='"..worldNum.."' and roleID='1'"
		data = self.world:getDBData(sql)
	end
	for k,v in pairs(data) do
		for i=1,10 do
			if v['M'..i]~='' then
				if result[v['M'..i]]==nil then
					result[v['M'..i]] = {}
				end
				result[v['M'..i]]['ID'] = self.world.tonumber(v['ID'..i])
				result[v['M'..i]]['NAME'] = v['NAME'..i]
			end
		end
	end
	return result
end

--- 生成队伍AI
-- @param team str - 队team
-- @param auto bool - 开启或者关闭
-- @param addNum int - 保持数量
-- @param cd int - 补充间隔 一个个出
-- @param intXYlist table - 出生点 格式 {{313.7/2,298.2/2,1},{313.7/2,298.2/2,2}}
-- @param initR int - 出生点随机落下的半径
-- @param subName str - 别名
-- @param tolist table - 寻路点 {{173.7/2,403.8/2},{173.7/2,403.8/2}}
-- @param level int - 级别
-- @param school int - 阵型 1=永恒，2=涅槃
-- @return null
function GameFlow:createAIHeroOnece(team,auto,addNum,cd,intXYlist,initR,subName,tolist,level,school)
	for i=1,addNum do
		local toX,toY = self.world.formula:getRandomCirclePoint(0,0,initR)
		local r
		if school==1 then
			r = self.world.formula:getRandnum(1,5)
		else
			r = self.world.formula:getRandnum(6,10)
		end
		local randNum = self.world.formula:getRandnum(1,#intXYlist)
		local obj=self.world:createHeroAI(r,level,team,nil,intXYlist[randNum][1]+toX,intXYlist[randNum][2]+toY)
		obj:setSubName(subName) 
		obj:moveTo(tolist[intXYlist[1][3]][1]+toX,tolist[intXYlist[1][3]][2]+toY,false,10)
		obj:addStatusList({s=76,r=self.gameTime,t=(obj.moveToEndTime-self.world.gameTime),i=obj.itemID},0)
		obj:setAutoBlocked(false,obj.moveToEndTime-self.world.gameTime)
		obj.isSmallAI = true
		obj.attribute.loginIDNotShow = 1
		obj.attribute.bloodNotShow = 1
		local result=obj:getAllInfo(0,true)
		obj:updateSyncMsg({i=result})
	end
end

--- 一次生成多只怪
-- @param roleID int - 角色ID
-- @param team str - 队team
-- @param auto bool - 开启或者关闭
-- @param addNum int - 保持数量
-- @param cd int - 补充间隔 一个个出
-- @param intXYlist table - 出生点 格式 {{313.7/2,298.2/2,1},{313.7/2,298.2/2,2}}
-- @param initR int - 出生点随机落下的半径
-- @param subName str - 别名
-- @param tolist table - 寻路点 {{173.7/2,403.8/2},{173.7/2,403.8/2}}
-- @return null
function GameFlow:createEnemyOnece(roleID,team,auto,addNum,cd,intXYlist,initR,subName,tolist)
	for i=1,addNum do
		local toX,toY = self.world.formula:getRandomCirclePoint(0,0,initR)
		local randNum = self.world.formula:getRandnum(1,#intXYlist)
		local objID = self.world:addCreature(roleID,team,intXYlist[randNum][1]+toX,intXYlist[randNum][2]+toY,nil,1)
		local obj = self.world.allItemList[objID]
		obj:setSubName(subName) 
		obj:moveTo(tolist[intXYlist[1][3]][1]+toX,tolist[intXYlist[1][3]][2]+toY,false,10)
		obj:addStatusList({s=76,r=self.world.gameTime,t=(obj.moveToEndTime-self.world.gameTime),i=obj.itemID},0)
		obj.AIlastCoolDown = self.world:getGameTime() + (obj.moveToEndTime-self.world.gameTime)+0.5 
	end
end

return GameFlow
