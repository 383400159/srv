#!/bin/bash

ps aux |grep 'main 280' |grep -v grep | awk '{print "kill "$2}'|sh
ps aux |grep 'main 281' |grep -v grep | awk '{print "kill "$2}'|sh

/var/aoe/MasterGame.sh
