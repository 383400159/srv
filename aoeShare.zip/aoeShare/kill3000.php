<?php
$memcacheObj=new Memcache;
$memcacheObj->connect('localhost',19800);
$memcacheObj->set('aoeRestart',1);

?>
