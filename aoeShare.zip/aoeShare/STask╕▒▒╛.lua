local STask = class("STask")
-- local json = require("json")
function STask:ctor(obj)
	if self.className == nil  then
		self.className = "STask"
	end	
	self.apiTaskList = {}
	self.updateTaskList = {}
	self.heroObj = obj
	self.world = self.heroObj.world
	self.checkList = {}
	--self.checkNPCList = self.heroObj.checkNPCList
	self:__init()
end


function STask:__init()
	--self.taskList = self.heroObj.taskList
	self.heroObj:D("feng task itemID:",self.heroObj.itemID,"  STask:__init")
end

--- 重新拆分任务用于一次完成多个任务
--- 重新拆分任务用于一次完成多个任务
-- @param null
-- @return null
function STask:refreshList()
	-- if 	self.taskList==nil then
	-- 	self.taskList = {}
	-- end
	if empty(self.taskList) then
		self.taskList = table.deepcopy(self.apiTaskList)	
		--转换task转格式
		self:taskToFontbp(self.taskList)		
	else
		--除了第一次更新 其他全部已game房为准
		--self.taskList = self.apiTaskList
		self.heroObj:D("feng task itemID:",self.heroObj.itemID," 非第一次更新 ")
		-- if not empty(self.updateTaskList) then
		-- 	for k,v in pairs(self.updateTaskList) do
		-- 		if v['operation']=="del" then
		-- 			self.heroObj:D("feng task 非第一次更新  删除",v["taskType"],k)
		-- 			self.taskList[""..v["taskType"]][k]=nil
		-- 		else
		-- 			if self.taskList[""..v["taskType"]]==nil then
		-- 				self.taskList[""..v["taskType"]]={}
		-- 			end
		-- 			self.heroObj:D("feng task 非第一次更新  添加",v["taskType"],k)
		-- 			self.taskList[""..v["taskType"]][k]=self.apiTaskList[""..v["taskType"]][k]
		-- 		end
		-- 	end
		-- end
		local delList={}
		local addList={}
		for k,v in pairs(self.taskList) do
			--game房有 api无 删除
			if self.apiTaskList[k]==nil then
				delList[#delList+1]={key1=k}
			end
			--比较第2层
			if self.apiTaskList[k]~=nil then
				for k1,v1 in pairs(v) do
					--game房有 api无 删除
					if self.apiTaskList[k][k1]==nil then
						delList[#delList+1]={key1=k,key2=k1}
					end		
				end
			end
		end

		for k,v in pairs(self.apiTaskList) do
			--game无 api有 添加
			if self.taskList[k]==nil then
				addList[#addList+1]={key1=k}
			end
			--比较第2层
			if self.taskList[k]~=nil then
				for k1,v1 in pairs(v) do
					--game无 api有 添加
					if self.taskList[k][k1]==nil then
						addList[#addList+1]={key1=k,key2=k1}
					end		
				end
			end
		end


		self.heroObj:D("feng task itemID:",self.heroObj.itemID," 数据对比 delList:",self.world.cjson.encode(delList))
		self.heroObj:D("feng task itemID:",self.heroObj.itemID," 数据对比 addList:",self.world.cjson.encode(addList))
		self.heroObj:D("feng task itemID:",self.heroObj.itemID," 数据对比 旧的数据列表:",self.world.cjson.encode(self.taskList))
		self.heroObj:D("feng task itemID:",self.heroObj.itemID," 数据对比 apiTaskList的数据列表:",self.world.cjson.encode(self.apiTaskList))
		--这个列表用来反馈给前端用的增删
		local deladdList = {}
		for k,v in pairs(delList) do
			if self.world.tNums(v)>1 and self.taskList[v.key1][v.key2]~=nil then
				deladdList[v.key1]={}
				deladdList[v.key1][v.key2]=table.deepcopy(self.taskList[v.key1][v.key2])
				deladdList[v.key1][v.key2]['adtype'] = 1
				self.taskList[v.key1][v.key2]=nil
			else
				deladdList[v.key1]=table.deepcopy(self.taskList[v.key1])
				for ka,va in pairs(deladdList[v.key1]) do
					va['adtype']=1
				end
				self.taskList[v.key1]=nil
			end

		end

		for k,v in pairs(addList) do
			if self.world.tNums(v)>1 then
				deladdList[v.key1]={}
				deladdList[v.key1][v.key2]=table.deepcopy(self.apiTaskList[v.key1][v.key2])
				deladdList[v.key1][v.key2]['adtype'] = 0
				self.taskList[v.key1][v.key2]=table.deepcopy(self.apiTaskList[v.key1][v.key2])
			else
				deladdList[v.key1]=table.deepcopy(self.apiTaskList[v.key1])
				for ka,va in pairs(deladdList[v.key1]) do
					va['adtype']=0
				end
				self.taskList[v.key1]=table.deepcopy(self.apiTaskList[v.key1])
			end
		end	

		self.heroObj:D("feng task itemID:",self.heroObj.itemID," 数据对比 新的数据列表:",self.world.cjson.encode(self.taskList))	
		self.heroObj:D("feng task itemID:",self.heroObj.itemID," 数据对比 Fontbp的数据列表:",self.world.cjson.encode(deladdList))	
		self:taskToFontbp(deladdList)
	end
	-- STask:refreshList taskList:	{"1":{"1":{"startTime":-1,"extraNextID":"0","taskID":1,"finish":0,"mapID":"10","history":0,"rewardID":"10001","taskType":"1","extra":{"TASKGUT":"t_20004_0","POPUI":"UIInputName","TASKCHAT":"t_20004_1"},"reduceID":"0","getGift":0,"tasks":{"api_name_1":{"X":87,"num":1,"finish":0,"type":["api_name_1"],"progress":0,"Y":198}},"nextID":"20","condType":"and"}},"3":{"70004":{"startTime":-1,"extra":{},"condType":"and","history":0,"rewardID":"14","taskType":"3","getGift":0,"extraNextID":"0","taskID":70004,"finish":0,"mapID":"105","dailyTaskExtra":"0","taskLevel":"2","reduceID":"1","tasks":{"npc_20003":{"X":30,"num":1,"finish":0,"type":["npc_20003"],"progress":0,"Y":85}},"nextID":"0","dailyTaskRing":3}}}	 
	-- updateTaskList:	{"70005":{"taskType":1,"operation":"del"},"70004":{"taskType":3,"operation":"add"}}

	self.checkList = {}
	self.checkNPCList = {}
	self.heroObj:D("feng task itemID:",self.heroObj.itemID," STask:refreshList taskList:",self.world.cjson.encode(self.taskList)," updateTaskList:",self.world.cjson.encode(self.updateTaskList))
	
	for tk1,tv1 in pairs(self.taskList) do
		if self.world.tonumber(tk1)>0 then
		for tk,tv in pairs(tv1) do
			local taskType = tv['taskType']
			for key,val in pairs(tv['tasks']) do

				if tv['finish']~=2 and (tv['notDo']==nil or tv['notDo']==0) then
					local tlist = string.split(key,"_")
					if tlist[1]=="GE" then
						--将type返回world里面拿最新值刷新
						--self.heroObj:D("将type返回world里面拿最新值刷新 key:"..key)
						-- local newtype = self.taskObj.world:getGE(val['type'])
						-- --替换为最新的GE=>em_1,2,3,4等等
						-- val['type'] = newtype
					end
					--self.counter = table.deepcopy(self.oldCounter)
					-- local tlist = string.split(val['type'],"_")
					-- local tIDlist = string.split(tlist[2],",")
					--将事件做key 来判断是否触发任务
					--self.heroObj:D("根据事件触发任务 type:",tv['taskType'],self.world.cjson.encode(val['type']))

					for k,v in pairs(val['type']) do
						if self.checkList[v]==nil then
							self.checkList[v] = {}
							if strpos(v,"npc")~=nil or strpos(v,"game")~=nil or strpos(v,"api")~=nil or strpos(v,"boss")~=nil then
								self.checkNPCList[v] = {}
							end
						end
						
						local OPERATEUIID = 0
						--追寻到分任务
						if strpos(v,"npc")~=nil or strpos(v,"game")~=nil or strpos(v,"api")~=nil or strpos(v,"boss")~=nil then
							--总ID*分ID*extra  COLLECTTIME=5	
							local COLLECTTIME = 0
							local REDIRECT = 0
							local NPCID = 0
							local TASKGUT = 0
							local POPUI = 0
							local OPERATEID = 0
							local extralist = tv['extra']
							for extrak,extrav in pairs(extralist) do
								if extrak=="COLLECTTIME" then
									COLLECTTIME = self.world.tonumber(extrav) 
								end
								if extrak=="REDIRECT" then
									REDIRECT = self.world.tonumber(extrav)
								end
								if extrak=="NPCID" then
									NPCID = self.world.tonumber(extrav)
								end
								if extrak=="TASKGUT" then
									TASKGUT = 1
								end
								if extrak=="POPUI" then
									POPUI = 1
								end
								if extrak=="OPERATEID" then
									OPERATEID = self.world.tonumber(extrav)
								end
								if extrak=="OPERATEUIID" then
									OPERATEUIID = self.world.tonumber(extrav)
								end
							end
							self.world:D('jaylog STask:refreshList ',tk,key,COLLECTTIME,REDIRECT,NPCID,TASKGUT,POPUI,OPERATEID,OPERATEUIID,tv['taskID'])
							self.checkNPCList[v][taskType]=tk.."*"..key.."*"..taskType.."*"..REDIRECT.."*"..NPCID.."*"..COLLECTTIME.."*"..TASKGUT.."*"..POPUI.."*"..OPERATEID.."*"..OPERATEUIID.."*"..tv['taskID']
							--self.checkNPCList[v][taskType]=tk.."*"..key.."*"..COLLECTTIME.."*"..REDIRECT.."*"..NPCID
						end
						self.heroObj:D("task tk:",tk," key:",key)
						self.checkList[v][#self.checkList[v]+1]=tk.."*"..key.."*"..taskType.."*"..tv['taskID'].."*"..OPERATEUIID
					end
				end
			end

		end
		end
	end
	self.heroObj:D("feng task itemID:",self.heroObj.itemID," 根据事件触发任务 checkNPCList:",self.world.cjson.encode(self.checkNPCList))
	--Npc任务事件一次只出现一个 已主线为主
	for k,v in pairs(self.checkNPCList) do
		self.checkList[k]={}
		-- self.checkList[k][1]=v[1]
		for i=1,8 do
			if v[""..i]~=nil  then
				self.checkList[k][1]=v[""..i]
				self.heroObj:D("feng task itemID:",self.heroObj.itemID," Npc任务事件一次只出现一个 这次占优的是:",i,k)
				break
			end
		end
	end

	--AI优先攻击任务怪
	for k,v in pairs(self.checkList) do
		local taskIDlist = string.split(k,"_")
		if taskIDlist[1]=='enemy' then
			self.heroObj.atkTaskList[taskIDlist[2]]=1
		end
	end

	self.heroObj:D("feng task itemID:",self.heroObj.itemID," 根据事件触发任务 checkList:",self.world.cjson.encode(self.checkList)," AI优先攻击任务怪:",self.world.cjson.encode(self.heroObj.atkTaskList))

end

--转换task转格式
function STask:taskToFontbp(taskList)
	--创建一个个前端的fontbp
	local newTaskList = {}
	for k,v in pairs(taskList) do
		for k1,v1 in pairs(v) do
			
			local t={
				zz=1,
				i = self.heroObj.itemID,
				taskID = k,
				taskType = k1,
			}
			for k2,v2 in pairs(v1) do
				t[k2]=v2
			end
		
			local newTasks = {}
			for k3,v3 in pairs(t['tasks']) do
				local t1 = v3
				t1['tsType'] = k3
				t1['type'] = nil
				newTasks[#newTasks+1]=t1
			end
			t['tasks'] = newTasks
			newTaskList[#newTaskList+1] = t
		end
	end

	for k,v in pairs(newTaskList) do
		v["extra"]=nil
		v["extraNextID"]=nil
		v["mapID"]=nil
		v["history"]=nil
		v["condType"]=nil
		v["redirectMap"]=nil
		v["isGameRoom"]=nil
		v["needParam"]=nil
		v["nextID"]=nil
		v["reduceID"]=nil
		v["rewardID"]=nil
	end

 	self.heroObj:D("feng task itemID:",self.heroObj.itemID," newTaskList:",self.world.cjson.encode(newTaskList))

 	return newTaskList
end

--- 任务操作接口 用于介入数据
-- @param eventKey string - 任务key
-- @param addValue int - 加值 
function STask:execute(eventKey,addValue)
	--从checkList里面找出触发该条件的所有任务

	if self.checkList[eventKey] == nil then 
		self.heroObj:D("feng task itemID:",self.heroObj.itemID," 并没该事件的任务在身 eventKey:",eventKey)
		return nil 
	else
		self.heroObj:D("feng task itemID:",self.heroObj.itemID," 任务在身 eventKey:",eventKey)
	end

	self.heroObj:D("feng task itemID:",self.heroObj.itemID," 任务在身 execute checkList:",self.world.cjson.encode(self.checkList))
	
	for k,taskID in pairs(self.checkList[eventKey]) do
		--涉及的任务id
		local taskIDlist = string.split(taskID,"*")
		self:calculateEvent(taskIDlist,eventKey,addValue)
	end

end

--- 任务操作接口 用于结算任务
-- @param taskIDlist table - task内部list
-- @param eventKey string - 任务key
-- @param addValue int - 加值 
function STask:calculateEvent(taskIDlist,eventKey,addValue)
	self.heroObj:D("-------------------------------------------------------------------")
	self.heroObj:D("feng task itemID:",self.heroObj.itemID," STask:calculateEvent key:",taskIDlist[1]," key1:",taskIDlist[2])
	self.heroObj:D("feng task itemID:",self.heroObj.itemID," 进行前  taskList:",self.world.cjson.encode(self.taskList[taskIDlist[3]][taskIDlist[1]]['tasks'][taskIDlist[2]]))	
	--先做累计值
	if self.world.tonumber(taskIDlist[5])==0 then
		self.taskList[taskIDlist[3]][taskIDlist[1]]['tasks'][taskIDlist[2]]['progress'] = self.taskList[taskIDlist[3]][taskIDlist[1]]['tasks'][taskIDlist[2]]['progress'] + addValue
	end
	--获得and or状态
	local condType = self.taskList[taskIDlist[3]][taskIDlist[1]]['condType']
	--是否重新累计
	local history = self.taskList[taskIDlist[3]][taskIDlist[1]]['history']

	local finNum = 1
	--判断分进度是否完成
	for k,v in pairs(self.taskList[taskIDlist[3]][taskIDlist[1]]['tasks']) do
		if v['progress']>=v['num'] then
			v['finish'] = 1
			v['progress'] = v['num']
			self.heroObj:D("feng task itemID:",self.heroObj.itemID,"  该分任务结束 key:",k)
			if condType=="and" then
				finNum=finNum*1
			else
				finNum=finNum+10
			end
		else
			if condType=="and" then
				finNum=finNum*0
			else
				finNum=finNum-1
			end
		end
	end

	--self.heroObj:D("feng task finish:",self.taskList[taskIDlist[3]][taskIDlist[1]]["finish"])
	--rGet指的是 每次采集都弹奖励
	if self.taskList[taskIDlist[3]][taskIDlist[1]]["finish"]~=1  then
		if finNum>=1 then
			self.taskList[taskIDlist[3]][taskIDlist[1]]["finish"]=1
			self.heroObj:D("feng task itemID:",self.heroObj.itemID," 该总任务已结束 key:",taskIDlist[1]," taskList:",self.world.cjson.encode(self.taskList[taskIDlist[3]][taskIDlist[1]]))
			--self.heroObj:activeTaskSyncMsg(taskIDlist[1])
			--call world 返回成功完成任务 
			self.heroObj:moveTo(self.heroObj.posX,self.heroObj.posY,false,11)
			self.heroObj:setAutoMove()
			self.heroObj:addApiJobUpdateTask()
			if self.taskList[taskIDlist[3]][taskIDlist[1]]["taskGift"]~=nil then
				local taskTable = {}
				if self.taskList[taskIDlist[3]][taskIDlist[1]]["rGet"]~=nil then
					-- self.heroObj:activeSyncMsg(self.world.cjson.encode({errcode=0,mes='',data={rGet=self.taskList[taskIDlist[3]][taskIDlist[1]]["rGet"]}}))
					taskTable['rGet'] = self.taskList[taskIDlist[3]][taskIDlist[1]]["rGet"]
				end
				taskTable['taskGift'] = self.taskList[taskIDlist[3]][taskIDlist[1]]["taskGift"]
				-- self.heroObj:activeTaskSyncMsg("taskGift",self.taskList[taskIDlist[3]][taskIDlist[1]]["taskGift"])
				self.heroObj:activeTaskSyncMsg(taskTable)
			end
			--self.heroObj:setAuto(false)
			--self.heroObj:addApiJobGetGift(taskIDlist[1])
			--新结构
			self.heroObj:activeTaskUpdateSyncMsg(taskIDlist[3])
		else
			self.heroObj:D("feng task itemID:",self.heroObj.itemID,"  发送数据去前台 ")
			--作一个数据给前端
			local taskUpdate = {
				zz = 1,
				i=self.heroObj.itemID ,
				taskType = taskIDlist[3] ,
				taskID = taskIDlist[1] ,
				tsType = taskIDlist[2] ,
				progress = self.taskList[taskIDlist[3]][taskIDlist[1]]['tasks'][taskIDlist[2]]['progress'] ,
			}
			self.heroObj:D("feng task itemID 作一个数据给前端:",self.heroObj.itemID,self.world.cjson.encode(taskUpdate))

			--self:updateSyncMsg({taskUpdate={taskUpdate}})

			local taskTable = {}
			if self.taskList[taskIDlist[3]][taskIDlist[1]]["rGet"]~=nil then
				taskTable = {rGet=self.taskList[taskIDlist[3]][taskIDlist[1]]["rGet"]}
			end
			self.heroObj:activeTaskSyncMsg(taskTable)
		end
	end

	-- if self.taskList[taskIDlist[3]][taskIDlist[1]]["rGet"]~=nil then
	-- 	self.heroObj:activeTaskSyncMsg("rGet",self.taskList[taskIDlist[3]][taskIDlist[1]]["rGet"])
	-- 	if self.taskList[taskIDlist[3]][taskIDlist[1]]["taskGift"]~=nil then
	-- 		self.heroObj:activeTaskSyncMsg("taskGift",self.taskList[taskIDlist[3]][taskIDlist[1]]["taskGift"])
	-- 	end
	-- end
	
	self.heroObj:D("feng task itemID:",self.heroObj.itemID," 完成  taskList:",self.world.cjson.encode(self.taskList[taskIDlist[3]][taskIDlist[1]]['tasks'][taskIDlist[2]]))	
	self.heroObj:D("feng task itemID:",self.heroObj.itemID," -------------------------------------------------------------------\n")
	--判断分进度是否完成
	-- if self.taskList[taskIDlist[1]]['tasks'][taskIDlist[2]]['progress']>=self.taskList[taskIDlist[1]]['tasks'][taskIDlist[2]]['num'] then
	-- 	self.taskList[taskIDlist[1]]['tasks'][taskIDlist[2]]['finish'] = 1
	-- end

end

function STask:setMemcache()
	self.heroObj.world:memcacheLocalSet(string.base64encode("task_"..self.heroObj.world.playerList[self.heroObj.itemID]['id']),self.heroObj.world.cjson.encode(self.taskList))
end


function STask:getMemcache()
	self.taskList = self.heroObj.world.cjson.decode(self.heroObj.world:memcacheLocalGet(string.base64encode("task_"..self.heroObj.world.playerList[self.heroObj.itemID]['id'])))
end


return STask