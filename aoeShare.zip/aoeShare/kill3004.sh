#!/bin/bash

/home/aoeShare/sync.sh

#if [ "$1" != "" ];then

#ps aux |grep 3000 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3004 |grep "main" |awk '{print "sudo kill "$2}' |sh

sleep 1

sudo /var/aoe/MasterGame-now.sh

#else
#/usr/bin/php /home/aoeShare/kill3000.php
#fi
