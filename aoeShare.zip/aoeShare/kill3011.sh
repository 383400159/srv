#!/bin/bash

#/home/aoeShare/sync.sh

ps aux |grep 3011 |grep "main" |awk '{print "sudo kill -9 "$2}' |sh

sleep 1

sudo /var/aoe_pvp2test/MasterGame.sh
