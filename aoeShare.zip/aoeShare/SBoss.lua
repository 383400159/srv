--require "gameroom.functions"
--require "gameroom.Config"
-- local cjson = require( Config.cjson )
local SBoss = class("SBoss", require("gameroom.boss.SBossInWorld"..worldForHero))

--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SBoss:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	--print("进来没！！！！！！！！！！！！！！")	


	if loginID==nil then loginID = "" end
	if skinNum==nil then skinNum = 0 end


	self.paths={}						--AI行进路线
	self.attackTarget=nil 	--攻击目标
	self.attribute={}				--英雄属性设置
	self.actorType=0 				--角色类型
	self.posX=12 						--位置X坐标
	self.posY=140 					--位置Y坐标
	self.lastPosX=0 				--上次位置X坐标
	self.lastPosY=0 				--上次位置Y坐标
	self.team =nil 					--队伍
	self.teamOrig = nil 		--原来队伍
	self.world =nil 				--world Obj
	self.parent=nil 				--父类

	self.deadTime=0 							--死亡时间
	self.deadFlag=0 							--死亡状态
	self.dirty=0

	self.debug=false

	self.status=0 -- 0=idle , 1=walk , 2=standby , 3=fight , 4=blockwait , 5=special , 6=dizzy , 7=freeze
	self.statusList={}

	self.syncMsg={}
	self.lastBulletID=0
	self.buffList={}



	self.isVisible=0 -- 1=yes 2=no -1=hidden 0=undeclared
	self.lastIsVisible=0 -- 1=yes 2=no -1=hidden 0=undeclared
	self.isGrass=0 -- 1=yes 2=no 0=undeclared
	self.lastAttackID=0  -- last attack id

	self.lastAttackTime=0 -- keep 3 second

	self.lastTowerPosition=nil
	self.lastTowerID=0

	self.visibleList={}

	self.skeleton=0

	--self.lastStandByAttackTime=0 -- for skill stand by attack = 1

	-- self.initX=0 -- initial positionX
	-- self.initY=0 -- initial positionY
	self.prepareSkillAttackNum=0 -- wait for skill attack, skill order (mode 1-4)
	self.lastBulletPositionX=0 -- skill attack , start from position X 
	self.lastBulletPositionY=0 -- skill attack , start from position Y
	self.lastBulletTarget=0 -- skill attack , start from position Y
	

	self.lastHeroAttack=0 -- last attacked by enemy Hero

	--self.loginID=""

	self.playerObj=nil
	self.playerJson=nil
	self.playerHeroesObj=nil
	self.playerHeroesJson=nil

	self.heroAttack={} -- record the time of last attacked by enemy Hero
	self.bonus={}
	self.bonusType={}

	self.skinNum=skinNum

	self.isSurrender=nil
	self.surrenderOrder=0

	self.lastControlTime=0
	self.lastOfflineTime=0
	self.totalIdleTime=0
	self.maxIdleTime=0

	--self.lastWalkTime =0 
	--self.lastFightTime=0   
	--self.lastSPFightTime=0  
	--self.lastCoolDownTime=0 
	--self.outOfCtlTime=0 
	--self.outOfCtlAllTime=0  

	self.openprint=0	

	--mode1相关参数
	self.mode1order = 1
	self.mode1atktime = 0
	self.mode1type = 0

	--self.pvePower=0
	self.starList={}

	--self.isAuto=false
	self.autoBlocked=false
	--第一次进游戏
	self.beginGame = true

	--boss被嘲讽的仇恨列表
	self.BossHatredlist = {}
	self.oldHatredID = 0


	if (self.className==nil) then 
		self.className="SBoss" 
	end
 
	self.world = world

	self.skinNum = skinNum

	if loginID~="" then
		self.loginID = loginID
		self.playerJson = {}

	end


	--生命共享id
	--生命共享比例

	SBoss.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

	self.AImode=2

	self.actorType = 2
end 

--- move motion , call every update loop
-- @return null
function SBoss:move() 
	SBoss.super.move(self)

end

--boss免控
function SBoss:addIMMUNECONTROLBUFF()
end

--- init funtion 初始化属性参数
-- @param id int - role id
-- @param posX int - 起始坐标X
-- @param posY int - 起始坐标Y
-- @return null
function SBoss:__init(id,posX,posY)

	self.world:__loadBoss(id)
	self.world:__loadBossSkill(id)
	self.attribute = require("gameroom.SAttributeBoss").new(id,1,self) --- level 1
	self.initX = posX
	self.initY = posY
	self.prepareSkillAttackNum = 0
	self.lastBulletPositionX = 0
	self.lastBulletPositionY = 0
	self.lastHeroAttack = -1
	self.lastHeroAttackForTower = -1
	-- self.nextREHPMPTime = self.world:getGameTime()

	debuglog("itemID:"..self.itemID)
end

--- fight motion,执行攻击动作
-- @param null
-- @return null
function SBoss:fight()

	--清除没用boss嘲讽仇恨列表
	if #self.BossHatredlist>0 then
		for k,v in pairs(self.BossHatredlist) do
			if v['endTime']<self.world:getGameTime() then
				table.remove(self.BossHatredlist,k)
			end
		end
	end
	SBoss.super.fight(self)

end

--- 自动移动chud
-- @return null
function SBoss:_autoMove()
	--body
	-- if self.runMoveAI then
		--self.autoFightAI:autoMove()
	-- end

end
--- 自动释放技能 
-- @return null
function SBoss:_autoFight()
	self.world:debuglog('jaylog boss autoFightAI:',self.autoFightAI.runAI)
	self.world:debuglog("SAI ..... outOfCtlTime:"..self.outOfCtlTime,self.AIlastCoolDown,self.lastCoolDownTime," gameTime:"..self.world.gameTime.." getGameTime:"..self.world:getGameTime())
	if self.AIlastCoolDown<self.world:getGameTime() and self.lastCoolDownTime<self.world:getGameTime() and  not self:isDead() and self.autoFightAI.runAI  then

		--需要获得自动攻击的item  释放skill的id
		local targetID,skillID,cdTime=self.autoFightAI:execute()
		if targetID>0 then
			self:debuglog("策划SEASON放了什么技能 fenglog checkBOSS roleId:"..self.attribute.roleId.." targetID:"..targetID.." skillID:"..skillID.." cdTime:"..cdTime)
			self:skillAttack(skillID,targetID)
			self.autoFightAI.runMoveAI = false
			self.AIlastATKtoMove = self.world:getGameTime()-0.5
			self.AIlastAutoMove = self.world:getGameTime()
		end
		--boss寻敌cd
		self.AIlastCoolDown = self.world:getGameTime() + cdTime
	end


	if not self:isDead() then
		if self.AIlastATKtoMove+10<self.world:getGameTime() then 
			--self:debuglog("AIlastATKtoMove:"..self.AIlastATKtoMove.." runMoveAI true")
			if	self.attribute.parameterArr['NOMOVEAI']==nil then
				self.autoFightAI.runMoveAI = true
			end
		else
			self.autoFightAI.runMoveAI = false
		end
	end

end

--- 设置技能限制施放时间
-- @param skill table - 角色某一招技能的所有设置值
-- @return null
function SBoss:useCDTime(skill)
	local cooldown = skill.cutTime
	skill.lastCoolDownValue = cooldown

	skill.lastCoolDownTime = self.world:getGameTime() + skill.lastCoolDownValue
	-- debuglog("useCDTime CDTIME:"..skill.parameters.CDTIME )
	debuglog("useCDTime lastCoolDownTime:"..skill.lastCoolDownTime )
	local sk = self.attribute.skills
	local gt = self.world:getGameTime()
	for i=2,7 do
		if sk[i] ~=nil then
			if sk[i].lastCoolDownTime<gt then
				sk[i].lastCoolDownTime = gt+skill.animationTime
				--print("增加公共cd..n:",self.attribute.skills[i].lastCoolDownTime)
			end
		end
	end
end

--- 使用技能伤害，call父类的skillAttack
-- @param mode int - 技能 1-8 rank
-- @param itemID int - 攻擊目標 itemID
-- @param positionX float - 攻擊目標 位置 X
-- @param positionY float - 攻擊目標 位置 Y
-- @param force bool - true ＝ 無視失控, 失控時攻擊目標用
-- @param fromClientSide bool - true ＝ 來自客戶端
-- @return msg table - 返回msg 給client 包括action move skillstatus
function SBoss:skillAttack(mode,itemID,positionX,positionY,force,fromClientSide,nPara,pPara)
	--print("skillAttack........mode :",mode)
	return SBoss.super.skillAttack(self,mode,itemID,positionX,positionY,force,fromClientSide,nPara,pPara)
end

-- --- 复活, 游戏loop
-- -- @param null
-- -- @return null
function SBoss:revive()

end

--{"sk":[ {"s":1 , "l":1 ,"t":1.01 ,"cd":5 },{"s":2 , "l":1 ,"t":1.01 ,"cd":5 } ]}
--- sync skill信息给client端
-- @param delay float - 延迟执行时间
-- @return status table - 格式：{"sk":[ {"s":1 , "l":1 ,"t":1.01 ,"cd":5 },{"s":2 , "l":1 ,"t":1.01 ,"cd":5 } ]}
function SBoss:syncSkill(delay)
	if delay==nil then delay = 0 end
	local status = {sk={i=self.itemID,a={}}}
	local t,cd
	for k,v in pairs(self.attribute.skills) do
		-- print("刷新技能cd lastCoolDownTime:",v.lastCoolDownTime)
		-- print("刷新技能cd getGameTime:",self.world:getGameTime())
		t = v.lastCoolDownTime-self.world:getGameTime()
		--debuglog('jaylog syncSkill parameters:'..self.world.cjson.encode(v.parameters))
		cd = v.parameters.CDTIME
		

		if t<=0 and v.lastCoolDownTime>=0 then
			t = 0.01
			--v.lastCoolDownTime = -1
		elseif t<0 then
			t = 0
		end

		status['sk']['a'][#status['sk']['a']+1] = {d=delay,s=v.rank,t=t,cd=cd}
	end
	self:updateSyncMsg(status)
	return status['sk']['a']
	--return {}
end

--- syn status状态信息给client
-- @param null
-- @return null
function SBoss:syncInfo()
	SBoss.super.syncInfo(self)
	local hatredID = self:getHatredID()
	if hatredID>0 then
		debuglog('jaylog change hatredID..'..hatredID)
		self:updateSyncMsg({i={i=self.itemID,ti=hatredID}})
	else
		if self.world.forceUpdate and self.oldHatredID>0 then
			debuglog('jaylog player init syn hatredID:'..self.oldHatredID)
			self:updateSyncMsg({i={i=self.itemID,ti=self.oldHatredID}})
		end
	end

end




-- 检查源是否在目标后面
-- x1 int - 源x坐标
-- y1 int - 源y坐标
-- x2 int - 目标x坐标
-- y2 int - 目标y坐标
-- adjust float - 调整值
function SBoss:_checkBehind(x1,y1,x2,y2,adjust) 
	if adjust==nil then adjust=0 end

	if (self.team=="A") then adjust=adjust*-1 end
	if self.world.towerBPos.posY==nil or self.world.towerBPos.posX==nil or self.world.towerAPos.posY==nil or self.world.towerAPos.posX==nil then
		--debuglog('============================================================ found bug '..self.className..self.itemID)
		return true
	end
	local ret=((y1-y2+adjust)*(self.world.towerBPos.posY-self.world.towerAPos.posY)-(self.world.towerAPos.posX-self.world.towerBPos.posX)*(x1-x2))
	----echo "_checkBehind x1,y1,x2,y2 self.team ret : ".(self.team=="A"?ret<0:ret>0)."\n"
	
	return (self.team=="A" and ret<0 or ret>0)

end

-- 暂时无用
function SBoss:getBehindDistance(x,y,d)
	local k = (self.towerAPos.posY-self.towerBPos.posY)/(self.towerAPos.posX-self.towerBPos.posX)
end



--- 發動攻擊
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return ret float - 傷害值
function SBoss:hitTarget(itemID,bulletID,mode,hitValue,adjTime)
	
	local CRItype = 0
	--重置普通攻击
	if mode==1 and self.mode1atktime+1.5<=self.world:getGameTime() then
		self.mode1order = 1
		self.mode1type  = 0
	end

	if mode==1 and false then
		--debuglog("SBoss:hitTarget hitValue:"..self.world.cjson.encode(hitValue))
		-- local carom = self.attribute.skills[mode].carom
		-- local carom_interval = self.attribute.skills[mode].carom_interval
		--print("carom:",carom)
		--print("carom_interval:",carom_interval)
		local caromlist = self.attribute.skills[mode].carom
		--print("caromlist :",self.world.cjson.encode(caromlist))	
		
		if caromlist[self.mode1order]==nil then
			--阶段上限
			self.mode1order = 1
			self.mode1type = 0
		end
		
		local caromCrilist = string.split(caromlist[self.mode1order],",")
		--print("caromCrilist :",self.world.cjson.encode(caromCrilist))	
		--获得间隔时间
		local caromitvlist = self.attribute.skills[mode].carom_interval
		local caromitvtimelist = string.splitNumber(caromitvlist[self.mode1order],",")
		--print("caromitvtimelist :",self.world.cjson.encode(caromitvtimelist))	
		local atknum =  #caromCrilist

		local mode1delaytime = 0
		for i=1,atknum do
			--print("mode1 打几下,atknum:",atknum)
			CRItype = self.world.tonumber(caromCrilist[i])
			hitValue['SEPARATE'] = 100/atknum
			--print("mode1 打几下,hitValue['SEPARATE']:",hitValue['SEPARATE'])
			--计算普通攻击伤害
			--self.world:setRandomSeed()
			local CRIhurt = self.world.formula:modeCriHurt(CRItype)
			hitValue['CRIhurt'] = CRIhurt 
			mode1delaytime = caromitvtimelist[i]
			--print("mode1 打几下,mode1delaytime:",mode1delaytime)
			ret = SBoss.super.hitTarget(self,itemID,bulletID,mode,hitValue,mode1delaytime)
		end

		if caromlist[self.mode1order]~=nil then
			--切换阶段 阶段+1
			if  caromlist[self.mode1order+1]~=nil then
				self.mode1type = self.world.tonumber(caromCrilist[1])
				self.mode1order = self.mode1order + 1
			else	
				self.mode1order = 1
				self.mode1type = 0
			end
		end

		--print("mode1 self.mode1order :",self.mode1order)
		self.mode1atktime = self.world:getGameTime()
	else
		if self.attribute.skills[mode]~=nil then
		 
		end
	end
	


	
	ret = SBoss.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 





	return ret
end

--- 受傷害計算
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss:hurted(itemID,bulletID,mode,hitValue,adjTime)


	local fromObj = nil
	if itemID>0 then
		fromObj = self.world.allItemList[itemID]
	end

	if itemID>0 and fromObj.attribute.actorType==0 and fromObj.teamOrig~=self.teamOrig then
		self.heroAttack[itemID] =self.world.gameTime
	elseif itemID>0 and fromObj.parent~=nil and fromObj.parent.attribute~=nil and fromObj.parent.attribute.actorType==0 and fromObj.parent.teamOrig~=self.teamOrig then
		self.heroAttack[fromObj.parent.itemID] = self.world.gameTime
	end

	local hurt = SBoss.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)

		-- --计算格挡
	if self.moveShieldTime>0 and self.moveShieldTime>self.world:getGameTime() and  self.shieldSkillTime<self.world:getGameTime() then
		--释放格挡技能
		debuglog("格挡  释放格挡技能/////////.......................")
		math.randomseed(os.time()+itemID*1888) 
		--self.world:setRandomSeed()
		local skill = self.attribute.skills[7] 
		local parameters = skill.parameters 
		if self.world.mRandom(0,100)<parameters.COUNTER_RATE then
			self:skillAttack(7,itemID)
			self.shieldSkillTime = self.moveShieldTime
			self:removeSkillAttackMode7()
		end
	end


	return hurt
end

--- 直接傷害
-- @param itemID int - 攻擊方itemID
-- @param mode int - 技能1-7
-- @param hitValueNew table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SBoss:directHurt(itemID,mode,hitValueNew,adjTime)
	local hurt = SBoss.super.directHurt(self,itemID,mode,hitValueNew,adjTime)
	return hurt
end


--- 调整自身HP值
-- @param hp float - 调整的值
-- @param forceSync boolean - 强制syn玩家HP数据到client
-- @param must boolean - 无视任何状态都扣血
-- @return ret boolean - 是否成功调整HP
function SBoss:adjHP(hp,forceSync,must) 
	if forceSync ==nil then forceSync = false end
	if must ==nil then must = false end

	local ret = SBoss.super.adjHP(self,hp,forceSync,must) 
	return ret 
end

--- 由getAttributeAndSync调用，用于组织heroInfo信息
function SBoss:getAttribute(syncMsg)
	if syncMsg==nil then syncMsg = false end

	--debuglog('jaylog start getAttribute')
	local msg = {
		hi = {
			eq7q = self:getCounter('killhero'),
			eq8q = self:getCounter('killed')
		}
	}
	--debuglog('jaylog start call getAttribute'..self.world.cjson.encode(msg))
	if syncMsg then
		self:updateSyncMsg(msg)
		--debuglog('jaylog start syncMsg getAttribute'..self.world.cjson.encode(msg))
	end

	return msg
end


--- 計算傷害
-- @param itemID int - 攻擊方itemID
-- @param hitValue table - 計算參數
-- @return hurt float - 傷害值
function SBoss:calHurted(itemID,hitValue)
	-- --计算格挡
	if self.moveShieldTime>0 and self.moveShieldTime>self.world:getGameTime() then
		--释放格挡技能
		debuglog("格挡 释放格挡技能/////////.......................减伤")

		local skill = self.attribute.skills[7] 
		local parameters = skill.parameters 
		hitValue['HURTAD_HURT'] = parameters.HURTAD_HURT
		hitValue['HURTAP_HURT'] = parameters.HURTAP_HURT
		-- self:skillAttack(randsk,self.attackTarget)
	end

	local hurt=SBoss.super.calHurted(self,itemID,hitValue)

	return hurt

end

--- 重新計算所有有效buff
-- @return null
function SBoss:reCalBuff()
	SBoss.super.reCalBuff(self)
	if self.debug  then
	--debuglog("Log2\tID:"..self.itemID.." Team:"..self.team.." Checking ....")
		if self.statusList ~=nil then
		for key,value in pairs(self.statusList) do
			--debuglog("Log2\tID:"..self.itemID.." Team:"..self.team.." Status:"..key.." totalTime:"..value['t'].." remainTime:"..(value['t']-self.world.gameTime-value['r']))
		end
		end
		if self.buffList ~=nil then
		for key,value in pairs(self.buffList) do
			if key ~=nil and value ~=nil then
			--debuglog("Log2\tID:"..self.itemID.." Team:"..self.team.." Buff:"..key.." Detail:"..(value.buffAttribute~=nil and cjson.encode(value.buffAttribute)  or "NULL" ).." Para:"..(value.buffParameter~=nil and  cjson.encode(value.buffParameter) or "NULL"))
			end
		end
		end
	end
end





--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SBoss:goToDead(itemID,mode,adjTime,bonus)
	if mode==nil then mode = 0 end
	if adjTime==nil then adjTime = 0 end
	if bonus==nil then bonus = {} end

	SBoss.super.goToDead(self,itemID,mode,adjTime,bonus)

	--复活时间
	local time = 9999

	self.attackTarget = nil
	if type(adjTime)=="string" then debuglog('why is string "'..adjTime..'"') end
	self.deadTime = self.world:getGameTime() + time + adjTime
	if adjTime>1 then adjTime = 1 end
	self:addStatusList({s=9,r=self.world:getGameTime()+adjTime,t=time,i=self.itemID},adjTime)
	self:moveTo(self.posX,self.posY)

	self:setCounter("killed",1)
	self:getAttributeAndSync()

	local lastAtkId = 0
	local lastAtkTime = 0
	for k,v in pairs(self.heroAttack) do
		if v+10>=self.world:getGameTime() then
			if v>lastAtkTime then
				lastAtkId = k
				lastAtkTime = v
			end
		end
	end
	self.world:debuglog('jaylog SBoss add killboss:',self.world.cjson.encode(self.heroAttack),' laid:',lastAtkId)
	if lastAtkId~=0 then
		local obj = self.world.allItemList[lastAtkId]
		obj:setCounter("killhero",1)
		obj:setCounter("killboss",1)
		obj:getAttributeAndSync()
		self.world:addSyncMsg({bc={{mid=9,p1=obj.itemID,p2=self.itemID,d=adjTime}}})
	end
end



--- 准备攻击前置设置，在prepareHit之前执行
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SBoss:prepareSkillAttackCustom(mode,target,x,y,adjtime,syncMsg)
	if (mode==1) then 
		debuglog("mode1 mode1order : "..self.mode1order)
		debuglog("mode1 mode1type : "..self.mode1type)
		--重置普通攻击
		if  self.mode1atktime+1.5<=self.world:getGameTime() then
			self.mode1order = 1
			self.mode1type  = 0
		end

		if (self.mode1order>1) then 
			if syncMsg~=nil and syncMsg['a']~=nil then
				syncMsg['a']['p']=self.mode1order-1
				debuglog("mode1 prepareSkillAttackCustom syncMsg['a']['p']:"..syncMsg['a']['p'])
				debuglog("mode1 prepareSkillAttackCustom 发送第几阶段:"..self.mode1order-1)
			end
		end 
	end 
end

--- 第7招格挡技能取消操作
-- @param null
-- @return null
function SBoss:removeSkillAttackMode7()

end


function SBoss:prepareSkillAttack(updateMove,fromClientSide,nPara,pPara)
	return SBoss.super.prepareSkillAttack(self,updateMove,false,nPara,pPara)
end

function SBoss:getHatredID()
	--self.Hatredlist
	--self.BossHatredlist
	local hatredID = 0
	
	
	local list = {}
	for k,v in pairs(self.Hatredlist) do
		--debuglog('jaylog SBoss:getHatredID itemID:'..k..' THREAT:'..v)
		local obj = self.world.allItemList[self.world.tonumber(k)]
		if obj~=nil then
			local r = obj.attribute.VISRNG/obj.world.setting.AdjustVisRange
			local d = self.world.map:distance(self.initX,self.initY,obj.posX,obj.posY) 
			if not obj:isDead() and r>=d then
				list[#list+1] = {itemID=k,THREAT=v}
			end
		end
	end
	if #list>0 then
		self.world.tSort(list,function( a1,b1 )
				return a1['THREAT'] > b1['THREAT']
			end)
		hatredID = self.world.tonumber(list[1]['itemID'])
	end

	if #self.BossHatredlist>0 then
		hatredID = self.world.tonumber(self.BossHatredlist[#self.BossHatredlist]['itemID'])
	end
	--只返回和上一次不一样的目标
	local retID = 0
	if self.oldHatredID~=hatredID and hatredID>0 then
		self.oldHatredID = hatredID
		retID = hatredID
	end

	return self.world.tonumber(retID)
end

--- 将task数据发送给前端
-- @param null
-- @return null
function SBoss:activeTaskSyncMsg()
end

--- 领取task奖励时组织数据发送前端
-- @param taskID int - 任务ID
-- @return null
function SBoss:activeTaskRewardSyncMsg(taskID)
end

--- 设置task的自动寻路路线
-- @param taskID string - 任务ID
-- @return null
function SBoss:getTaskPath(taskID)
end

function SBoss:addApiCall(data,ctrl,act)
end

function SBoss:updateInfo()
end

--- call api获取全部task信息
-- @param null
-- @return null
function SBoss:addApiJobGetTask()
end

--- call api更新task信息到API
-- @param null
-- @return null
function SBoss:addApiJobUpdateTask()
end

--- call api获取任务奖励
-- @param taskID int - 任务ID
-- @return null
function SBoss:addApiJobGetGift(taskID)
end

-- call api获取全部counter信息
function SBoss:addApiJobGetCounter()
end

-- update counter
function SBoss:addApiJobUpdateCounter()
end

--
function SBoss:addApiJobGetProperty()
end

function SBoss:addApiJobGetSkill()
end

--- 设置暫停AI
-- @return null
function SBoss:suspendAI()
end

function SBoss:setAutoFollow(itemID)
end

function SBoss:setAutoMove(taskID)
end

--- Release actor object
-- @return null
function SBoss:release()
	if self.itemID<1000 then
		self.world:debuglog('jaylog SBoss:release ',self.itemID)
		self.world.playerList[self.itemID] = nil
	end
	SBoss.super.release(self)
end

return SBoss
