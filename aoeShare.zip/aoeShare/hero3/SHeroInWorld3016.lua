local SHeroInWorld3016 = class("SHeroInWorld3016", require("gameroomcore.SHeroBase"))

function SHeroInWorld3016:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld3016.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	debuglog("SHeroInWorld3016:ctor........")
end


function SHeroInWorld3016:skillAttackMode9CallBack(roleId,itemID,atkP)
	self:D("挖矿 回调",roleId,itemID)
	local obj = self.world.allItemList[itemID]
	if  obj~=nil and not obj:isDead() and obj.isEnd==nil and  self.world.tonumber(atkP)>0 then
		self:D("挖矿 成功",roleId,itemID,atkP)
		obj.isEnd = atkP
		local attributes = table.deepcopy(self:getPrepareHithitValue())
		attributes['FIXHURT'] = 8
		self:directHurtToDalay(1,self.itemID,attributes,0)
		--刷新boss显示列表
		local bossObj = self:getBossObj()
		bossObj:syncQTE()
	end
end


function SHeroInWorld3016:getBossObj()
	local obj = self.world:getObjBySubName("BOSS1",self.world.itemListFilter.heroList)
	return obj
end

return SHeroInWorld3016
