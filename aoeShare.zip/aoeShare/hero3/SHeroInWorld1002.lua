local SHeroInWorld1002 = class("SHeroInWorld1002", require("gameroomcore.SHeroBase"))

function SHeroInWorld1002:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld1002.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


--- 复活, 游戏loop
-- @param null
-- @return null
function SHeroInWorld1002:revive()
end

--- 角色死亡,call 父类
function SHeroInWorld1002:goToDead(itemID,mode,adjTime,bonus)  
	SHeroInWorld1002.super.goToDead(self,itemID,mode,adjTime,bonus) 
	self.world.gameCounter['points'..self.team] = self.world.gameCounter['points'..self.team] - 1
	self.world:syncPointsInfo()
end 

function SHeroInWorld1002:prepareSkillAttackMode7(updateMove)
	return nil
end

return SHeroInWorld1002