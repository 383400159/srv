local SHero6 = class("SHero6", require("gameroom.hero.SHero")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @param actorID int - 游戏房玩家序号ID
-- @return null
function SHero6:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SHero6" 
	end 

	--愤怒值
	self.SP = 0
	--愤怒最大值
	self.maxSP = 9
	--旋风斩消耗5愤怒值进行特殊攻击 对出血敌人造成吸血伤害
	self.hurtDrainLifeMode = 0
	--大招消耗5愤怒点 让目标流血
	self.addFIXHURTMode = 0
	--停止恢复愤怒值时间
	self.nextStopAddSPTime = 0
	--下次恢复愤怒值时间
	self.nextAddSPTime = 0
	--一次恢复多少愤怒值
	self.addSPNum = 0


	self.mode4EmemyNum = 0
	SHero6.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end 



--- init funtion 初始化属性参数
-- @param id int - role id
-- @param posX int - 起始坐标X
-- @param posY int - 起始坐标Y
-- @return null
function SHero6:__init(id,posX,posY)
	SHero6.super.__init(self,id,posX,posY) 
	self.maxSP=self.attribute.parameterArr.MAXSP

	self:addStatusList({zz=3,s=69,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.maxSP},0.5)
	self:addStatusList({zz=3,s=70,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.maxSP,p3=0},0.5)

end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SHero6:prepareHit(mode,adjTime,buff)  

	local hitValueBoth=SHero6.super.prepareHit(self,mode,adjTime,buff) 
	if (mode==2) then
		hitValueBoth['bulletAttackMode4Passthru'] = false;  --防止穿墙
	end

	if mode==4 then
	   self.mode4EmemyNum = 0
	end

	if mode==5 then
		local  skill = self.attribute.skills[5]
		local parameters = skill.parameters
		local hitValueNew={}
		hitValueNew['ALLHURT_UP_RATE']=100
		hitValueNew["ALLHURT_UP"]=40
		hitValueNew['FIXHURT'] = 8
		hitValueNew["BUFFTIME"]=parameters.BUFFTIME2
		self:directHurtToDalay(5,self.itemID,hitValueNew,0)

	end
	return hitValueBoth 
end 


--- 發動攻擊,call父-类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero6:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	local ret = SHero6.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	if mode==4 then 
		local  skill = self.attribute.skills[4]
		local parameters = skill.parameters
		self:D("4技能当前招怪数量 ,",self.mode4EmemyNum)
		if self.mode4EmemyNum == 0 then
			local creatureID=self.world:addCreature(self.world.tostring(108),self.teamOrig,self.lastBulletPositionX,self.lastBulletPositionY,self,1,0)
	    	local obj  = self.world.allItemList[creatureID]
			obj:setDeadTime(5) 
			self.mode4EmemyNum = self.mode4EmemyNum + 1
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1

			attributes['buffParameter'] = hitValue  --self:getPrepareHithitValue()使用默认的空白参数
			--attributes['buffParameter']['FIXHURT'] = 8  ---固定伤害
			attributes['buffParameter']['RANGE'] = skill.atkDis
			attributes['buffParameter']['buffType'] = 1
			attributes['buffParameter']['ADADJ'] = 25
			attributes['buffParameter']['DIZZY_RATE'] = 100
			attributes['buffParameter']['BUFFTIME'] = 2
			attributes['buffParameter']['buffIntervalTime'] = parameters.HURTITNTERVAL
			attributes['buffParameter']['creatureDirectHurCallBack'] = 'tpID1'
			self:D("虚无盲区  ",parameters.HURTLIFE, parameters.HURTITNTERVAL,parameters.HURTSTARTTIME,skill.hitTime)
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,5,{99},0,self.itemID,creatureID,0)
			obj:addBuff(buff)
		end
    end

    if mode==5 then
		local  skill = self.attribute.skills[5]
		local parameters = skill.parameters
		local hitValueNew = self:getPrepareHithitValue()
		hitValueNew['changeMode']=mode
		hitValueNew['skillID'] = 5
		hitValueNew['ADADJ'] = 50
		-- hitValueNew['FIXHURT'] = 8
		self:directFightAuratoDalay(5+100,0,hitValueNew,{posX=self.posX,posY=self.posY,RANGE=1000},0)
		
	end
	return ret 
end 


--- 受傷害計算,调用SActor的hurted
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero6:hurted(itemID,bulletID,mode,hitValue,adjTime)
	local hurt = SHero6.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
	return hurt
end

--- 准备攻击前置设置，在prepareHit之后执行，call父类
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SHero6:prepareSkillAttackCustom(mode,target,x,y,adjTime,syncMsg)  
	SHero6.super.prepareSkillAttackCustom(self,mode,target,x,y,adjTime,syncMsg)  
	if mode==2 then
		local  skill = self.attribute.skills[2]
		local toX1,toY1 = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,skill.atkDis/self.world.setting.AdjustAttRange)
		local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX1,self.posY+toY1) 
		self:moveTo(toX,toY,false,6,skill.bulletSpeed,adjTime) 
	end
end 

function SHero6:checkMana(mode)
	return SHero6.super.checkMana(self,mode) 	
end



--- 设置技能限制施放时间
-- @param skill table - 角色某一招技能的所有设置值
-- @return null
function SHero6:useCDTime(skill)
	local ret = SHero6.super.useCDTime(self,skill)
	return ret
end

--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SHero6:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 

	----debuglog("天平回调  前 ....... 击中itemID:"..itemID.." creatureDirectHurCallBack:"..hitValue['creatureDirectHurCallBack'])
	--假设101是左天平
	--debuglog("天平回调 gameTime:"..self.world.gameTime.." mode7time:"..self.mode7time)
	if isset(hitValue['creatureDirectHurCallBack']) and hitValue['creatureDirectHurCallBack']=="tpID1" then --and in_array(hitValue['creatureDirectHurCallBack'],self.creatureList)) then
		self:D("4技能当前招怪数量 进入伤害回调")
	end
end


return SHero6 
