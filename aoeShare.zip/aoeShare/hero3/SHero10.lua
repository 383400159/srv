local SHero10 = class("SHero10", require("gameroom.hero.SHero")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @param actorID int - 游戏房玩家序号ID
-- @return null
function SHero10:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	if (self.className==nil) then 
		self.className = "SHero10" 
	end 

	--箭魂
	self.SP=0
	--箭魂上限
	self.maxSP=100
	--普通攻击模式
	self.atkMode=1
	--宠物分身持续时间
	self.mode5BBSkinTime = 9999999
	--分身ID
	self.CWID = 0
	--指挥bb攻击目标
	self.BBTAGID = 0
	self.BBTAGNEXTTIME = 0

	SHero10.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end 

--- init funtion 初始化属性参数
-- @param id int - role id
-- @param posX int - 起始坐标X
-- @param posY int - 起始坐标Y
-- @return null
function SHero10:__init(id,posX,posY)
	SHero10.super.__init(self,id,posX,posY) 
	self.maxSP=self.attribute.parameterArr.MAXSP
	self:addStatusList({zz=3,s=71,r=self.world:getGameTime(),t=999999,i=self.itemID,p1=self.maxSP,zz=3},0.5)
	self:addStatusList({zz=3,s=60,r=self.world:getGameTime(),t=999999,i=self.itemID,p1=self.SP,p2=1 ,p3=1},0.5)
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SHero10:prepareHit(mode,adjTime,buff)  
	--指哪打哪 给bb用
	if self.lastBulletTarget~=nil and self.lastBulletTarget>0 then
		local obj = self.world.allItemList[self.lastBulletTarget] 	
		if obj~=nil and obj.teamOrig~=self.teamOrig and not obj:isDead() then
			self.BBTAGID = self.lastBulletTarget
			self.BBTAGNEXTTIME = self.world:getGameTime()
		end
	end 

	local hitValueBoth=SHero10.super.prepareHit(self,mode,adjTime,buff) 

	if mode==11 then
		hitValueBoth['bulletAttackMode4ExtendDistance'] = 100
	end

	if mode==4 then
		--NEARESTUSEDIS=200;PETRANGE=600;PETINTERVAL=1;PETDURATION=5
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		local obj = self.world.allItemList[self.CWID] 	
		obj:clearSkillAttack() 
		obj.mode4PosX = self.lastBulletPositionX
		obj.mode4PosY = self.lastBulletPositionY
		obj.lastCoolDownTime = self.world:getGameTime() 
		obj.checkOverLapTime = self.world:getGameTime() 
		obj.attribute.skills[4].lastCoolDownValue = self.world:getGameTime()
		obj.nextSkillID = 4
		self.lastAttackID = self.lastBulletTarget
		self.lastAttackTime = self.world:getGameTime()

		-- local attributes = table.deepcopy(self:getPrepareHithitValue())
		-- attributes['OUTCTL_RATE'] = 100
		-- attributes['BUFFTIME'] = parameters.PETDURATION
		-- obj:directHurtToDalay(4,obj.itemID,attributes,0)
		--obj:moveTo(self.lastBulletPositionX,self.lastBulletPositionY,true,1)

		--加移速
		local hitValueNew={}
		hitValueNew['MSPD_UP_RATE']=parameters.MSPD_UP_RATE2
		hitValueNew["MSPD_UP"]=parameters.MSPD_UP2
		hitValueNew["BUFFTIME"]=parameters.BUFFTIME2
		self:directHurt(self.itemID,mode,hitValueNew,0) 	
		self:useSP(parameters.USESOULNUM)
	end
	--给宠物加ATK提升buff
	if mode==5 then
		local skill = self.attribute.skills[5] 
		local parameters = skill.parameters 
		local obj = self.world.allItemList[self.CWID] 
		local hitValueNew={}
		hitValueNew['ALLHURT_UP_RATE']=parameters.ALLHURT_UP_RATE2
		hitValueNew["ALLHURT_UP"]=parameters.ALLHURT_UP2
		hitValueNew["BUFFTIME"]=parameters.BUFFTIME2
		self:directHurtToDalay(5,self.itemID,hitValueNew,0)
		obj:directHurtToDalay(5,obj.itemID,hitValueNew,0)

		self:addStatusList({s=94,r=self.world:getGameTime(),t=parameters.BUFFTIME2,i=self.itemID},0)
		obj:addStatusList({s=94,r=self.world:getGameTime(),t=parameters.BUFFTIME2,i=self.itemID},0)
		--更新皮肤....
		-- obj.skinNum = 1
		-- obj:__getAllInfo(0,true)
		-- self.mode5BBSkinTime = self.world:getGameTime() + parameters.BUFFTIME2
		hitValueBoth['BUFFTIME'] = parameters.BUFFTIME2
	end

	return hitValueBoth 
end 

--创建一个bb
function SHero10:initBB()
	local skill = self.attribute.skills[12] 
	local parameters = skill.parameters 
	
	--local toX,toY = self.world.formula:getRandomCirclePoint(self.posX,self.posY,parameters.SPLITRANGE/self.world.setting.AdjustAttRange,true)
	local toX,toY = self.world.formula:getRandomCirclePoint(self.posX,self.posY,parameters.SPLITRANGE/self.world.setting.AdjustAttRange,true)
	local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,toX,toY) 

	self.world:D('jaylog SHero10 ',toX,toY,self.posX,self.posY,self.world.cjson.encode(parameters))
	local CWID=self.world:addCreature(self.world.tostring(802),self.teamOrig,toX,toY,self,1,0)
	local obj = self.world.allItemList[CWID] 
	obj:setDoubleMode(parameters.MAXDIS,parameters.MIXDIS,parameters.FOLLOWDIS)
	obj.AIlastMoveTime = self.world:getGameTime()+0.2
	obj:setSubName("lierenchognwu")
	self.CWID = CWID
	-- obj:setDeadTime(999999) 
	self.world:D("新弓箭召唤bb..........",CWID,obj:isDead())
end

--- 设置技能限制施放时间
-- @param skill table - 角色某一招技能的所有设置值
-- @return null
function SHero10:useCDTime(skill)
	SHero10.super.useCDTime(self,skill)
end

--- move motion , call every update loop
-- @return null
function SHero10:move()
	if self.CWID == 0 then
		self:initBB()
	end
	SHero10.super.move(self)
end

--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero10:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	
	local ret = 0
	if mode==3 then
		--CDTIME=9;ADJSOULNUM=5;ADJSOULKILL=1;EXPLODERANGE=500
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 

		local attackRange = {posX=obj.posX,posY=obj.posY,radius=parameters.EXPLODERANGE/self.world.setting.AdjustAttRange} 

		local hitValueNew = self:getPrepareHithitValue()
		debuglog("parameters:..."..self.world.cjson.encode(parameters))
		hitValueNew['changeMode']=mode
		hitValueNew['skillID'] = 3
		hitValueNew['ADADJ'] = parameters.ADADJ 
		hitValueNew['FIXHURT'] = 8
		hitValueNew['mode3HurtX'] = obj.posX
		hitValueNew['mode3HurtY'] = obj.posY
		hitValueNew['mode3HurtR'] = parameters.EXPLODERANGE/self.world.setting.AdjustAttRange
		local bullet = require("gameroomcore.SBullet").new(self.world,3,self.itemID,0.2,0,obj.posX,obj.posY)
		bullet.attr.ignoreID = {itemID}
		bullet:directFightAura(1,attackRange,hitValueNew,bullet.attr.angle,0) 
		bullet:setDead() 

		-- local hitValueNew = self:getPrepareHithitValue()
		-- hitValueNew['changeMode']=mode
		-- hitValueNew['skillID'] = 3
		-- hitValueNew['ADADJ'] = parameters.ADADJ 
		-- -- hitValueNew['FIXHURT'] = 8
		-- self:directFightAuratoDalay(3,0,hitValueNew,{posX=obj.posX,posY=obj.posY,RANGE=parameters.EXPLODERANGE},0)

		hitValue['attackZXP'] = "1"
		-- if hitValue['ADADJ']==0 then
		-- 	hitValue['ADADJ'] = parameters.ADADJ
		-- end
		self:adjSP(parameters.ADJSOULNUM)

		local r = parameters.BACKWARD/self.world.setting.AdjustAttRange
		toX,toY = self.world.map:getXYLength(self.posX,self.posY,obj.posX,obj.posY,r) 
		local ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
		obj:moveTo(toX,toY,true,5,parameters.BACKWARDSPEED,parameters.BACKWARDDELAY)

	end

	ret = ret + SHero10.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	if ret>0 and (mode==1 or mode==2 or mode==3) then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local obj = self.world.allItemList[itemID] 
		if obj:isDead() then
			self:adjSP(parameters.ADJSOULKILL)
		else
			self:adjSP(parameters.ADJSOULNUM)
		end
	end


	--2号散射击飞
	if ret>0 and mode==2 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local obj = self.world.allItemList[itemID] 
		--弹飞园半径
		local r = parameters.BACKWARD/self.world.setting.AdjustAttRange
		toX,toY = self.world.map:getXYLength(self.posX,self.posY,obj.posX,obj.posY,r) 
		ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
		obj:moveTo(toX,toY,true,5,parameters.BACKWARDSPEED,parameters.BACKWARDDELAY)
	end


	return ret 
end 



--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SHero10:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	SHero10.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
	self:D("爆炸回调:",hurt,mode,itemID,self.itemID)
	if hurt>0 and mode==3 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local obj = self.world.allItemList[itemID] 
		self:adjSP(parameters.ADJSOULKILL)

		--弹飞园半径
		local r = parameters.BACKWARD/self.world.setting.AdjustAttRange
		local toX,toY = self.world.map:getXYLength(hitValue['mode3HurtX'],hitValue['mode3HurtY'],obj.posX,obj.posY,r) 
		ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
		obj:moveTo(toX,toY,true,5,parameters.BACKWARDSPEED,parameters.BACKWARDDELAY)
	end

	if isset(hitValue['creatureDirectHurCallBack']) and hitValue['creatureDirectHurCallBack']=='lierenBBMode4' then
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		local obj = self.world.allItemList[itemID] 
		local BBobj = self.world.allItemList[self.CWID] 
		--弹飞园半径
		local r = parameters.BACKWARD/self.world.setting.AdjustAttRange
		local toX,toY = self.world.map:getXYLength(BBobj.posX,BBobj.posY,obj.posX,obj.posY,r) 
		ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
		obj:moveTo(toX,toY,true,5,parameters.BACKWARDSPEED,parameters.BACKWARDDELAY)
	end
end


--- 受傷害計算,调用SActor的hurted
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero10:hurted(itemID,bulletID,mode,hitValue,adjTime)
	if self.CWID~=nil and self.CWID>0 and not self.world.allItemList[self.CWID].runAI then
		local obj = self.world.allItemList[self.CWID]
		obj.autoFightAI.runAI = true
		obj.autoFightAI.runMoveAI = true
		obj.autoFightAI.noAutoPatrol = false
	end
	local hurt = SHero10.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
	return hurt
end


--- 使用技能伤害，call父类的skillAttack
-- @param mode int - 技能 1-8 rank
-- @param itemID int - 攻擊目標 itemID
-- @param positionX float - 攻擊目標 位置 X
-- @param positionY float - 攻擊目標 位置 Y
-- @param force bool - true ＝ 無視失控, 失控時攻擊目標用
-- @param fromClientSide bool - true ＝ 來自客戶端
-- @return msg table - 返回msg 給client 包括action move skillstatus
function SHero10:skillAttack(mode,itemID,positionX,positionY,force,fromClientSide,nPara,pPara)
	if self.CWID~=nil and self.CWID>0 and not self.world.allItemList[self.CWID].runAI then
		local obj = self.world.allItemList[self.CWID]
		obj.autoFightAI.runAI = true
		obj.autoFightAI.runMoveAI = true
		obj.autoFightAI.noAutoPatrol = false
	end
	return SHero10.super.skillAttack(self,mode,itemID,positionX,positionY,force,fromClientSide,nPara,pPara)
end


function SHero10:prepareSkillAttackMode7(updateMove)
	return SHero10.super.prepareSkillAttackMode7(self,updateMove)
end

function SHero10:checkMana(mode)
	if mode==4  then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		
		self:D("愤怒 ",self.world.cjson.encode(parameters))
		if self.SP<parameters.USESOULNUM then
			return false
		end
	end
	return SHero10.super.checkMana(self,mode) 	
end



-- --- 自动移动chud
-- -- @return null
-- function SHero10:_autoMove()
-- 	if self.doubleMode==0 then
-- 		SHero10.super._autoMove(self)
-- 	else
-- 		if not self.autoBlocked and self.AIlastMoveTime < self.world:getGameTime() and  not self:isDead()  and self.statusList[4007]==nil then
-- 			self.autoFightAI:autoMoveToFollowed(self.moveMaxDis,self.moveMinDis)
-- 			--self.AIlastMoveTime = self.moveToEndTime
-- 		end
-- 	end

-- end

-- --自动攻击用来重载
-- function SHero10:_autoFightToHero()
-- 	--需要获得自动攻击的item  释放skill的id
-- 	local targetID,skillID,cdTime

-- 	if self.parent~=nil then
-- 		targetID,skillID,cdTime=self.autoFightAI:autoFighTotHero({})

-- 		if targetID>0 then
-- 			----debuglog("SHero:_autoFight 进去之前 lastCoolDownTime:"..self.lastCoolDownTime.." gameTime:"..self.world.gameTime.." ret:"..self.world.cjson.encode(ret).."第几下:"..self.mode1order)
-- 			ret = self:skillAttack(skillID,targetID)
-- 			self.AIlastATKTime = self.world:getGameTime()+cdTime
-- 			--防止放完技能立刻回头不好的体验
-- 			self.AIlastMoveTime = self.world:getGameTime() + 0.2
-- 			----("SHero:_autoFight lastCoolDownTime:"..self.lastCoolDownTime.." gameTime:"..self.world.gameTime.." ret:"..self.world.cjson.encode(ret).."第几下:"..self.mode1order)
-- 		end
-- 	else
-- 		skillID=SHero10.super._autoFightToHero(self)
-- 	end
-- 	return skillID
-- end

function SHero10:adjSP(sp,force)

	self.SP = math.round(self.SP + sp, 1)
	if self.SP>self.maxSP then self.SP = self.maxSP end
	if self.SP>self.changePartSP then self.SP=self.changePartSP end
	
	if self.SP<1 then 
		self.SP = 0 
	end
	self:D("新弓箭手 增加sp:",sp,"总:",self.SP)
		--3变4
	self:addStatusList({zz=3,s=60,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.SP,p2=(self:checkMana(4) and 0 or 1) ,p3=(self:checkMana(5) and 0 or 1)},0)
end

function SHero10:useSP(sp)

	self.SP = math.round(self.SP - sp, 1)

	if self.SP<1 then 
		self.SP = 0 
	end
	self:D("新弓箭手 使用sp:",sp,"总:",self.SP)
		--3变4
	self:addStatusList({zz=3,s=60,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.SP,p2=(self:checkMana(4) and 0 or 1) ,p3=(self:checkMana(5) and 0 or 1)},0)
end


function SHero10:syncInfo()
	--恢复bb皮肤
	-- if self.world:getGameTime()>self.mode5BBSkinTime then
	-- 	self.mode5BBSkinTime = 999999
	-- 	local obj = self.world.allItemList[self.CWID] 
	-- 	obj.skinNum = 0
	-- 	obj:__getAllInfo(0,true)
	-- end
	SHero10.super.syncInfo(self)
end



--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SHero10:goToDead(itemID,mode,adjTime,bonus)
	--玩家死了以后分身也死
	if self.CWID>0 then
		local obj = self.world.allItemList[self.CWID] 
		if obj~=nil and  not obj:isDead() then
			obj.parent.CWID = 0
			obj.attribute.HP=0
			obj:directHurt(obj.itemID,0,{finalFixHurt=0},0)
			obj:addStatusList({s=42,r=self.world.gameTime,t=9999999,i=obj.itemID},0.2)
			--obj.world:removeItem(obj)
			
		end
	end
	SHero10.super.goToDead(self,itemID,mode,adjTime,bonus)
end

return SHero10 