local SHero8 = class("SHero8", require("gameroom.hero.SHero")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @param actorID int - 游戏房玩家序号ID
-- @return null
-- function SHero8:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

-- 	if (self.className==nil) then 
-- 		self.className = "SHero8" 
-- 	end 
-- 	--debuglog('jaylog SHero8:ctor before super')
-- 	SHero8.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
-- 	--debuglog('jaylog SHero8:ctor after super')
-- end 


--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @param actorID int - 游戏房玩家序号ID
-- @return null
function SHero8:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SHero8" 
	end 
	--愤怒值
	self.SP = 0
	--愤怒最大值
	self.maxSP = 9
	SHero8.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	--记录奥术飞弹的增强层数
	self.skillANum = 0
	--下次增加飞弹层数的时间
	self.nextSkillATime = 0
	--记录分身
	self.creatureIDList = {}
	--分身模式 0不是分身 1是分身
	self.doubleMode=0
	--分身父itemID
	self.parent=nil
	--分身持续时间
	self.DEAD=0
	--分身出现时间
	self.createTime=0
	--分身生成顺序
	self.createNum=0
	--分身移动距离
	self.moveMaxDis = 0
	self.moveMinDis = 0
	self.followDis = 0

	--流星火雨攻击次数
	self.skillCNum = 0
	--流星火雨伤害间隔
	self.skillCINTERVALTIME = 0
	--火雨底座
	self.hyID = 0
	--下一个回调时间
	self.nextSkillCTime = 0
	--SKillA总层数
	self.MAGICMAX = 0

	--AI释放奥术蛋开始类型
	self.mode2AItype = 0
	--下次切换AI行为时间
	self.mode2AINextTime = 0

end 

function SHero8:_autoFightSkillToHero()
	local targetID,skillID,cdTime
	local heroSkillList = self.attribute.AIRoleSetting['normalSkillList']
	local newSkillList = {}
	--重载掉法师第一招
	if self.mode2AItype~=0 then
		for k,v in pairs(heroSkillList) do
			if v~=2 then
				newSkillList[#newSkillList+1]=v
			end
		end
	else
		newSkillList = heroSkillList
	end
	if self.onlySimpleAttack~=nil and self.onlySimpleAttack then
		targetID,skillID,cdTime=self.autoFightAI:autoFightToHero({})
	else
		targetID,skillID,cdTime=self.autoFightAI:autoFightToHero(newSkillList)
	end
	return targetID,skillID,cdTime
end



--- init funtion 初始化属性参数
-- @param id int - role id
-- @param posX int - 起始坐标X
-- @param posY int - 起始坐标Y
-- @return null
function SHero8:__init(id,posX,posY)
	SHero8.super.__init(self,id,posX,posY) 
	self.maxSP=self.attribute.parameterArr.MAXSP
	local skill = self.attribute.skills[2] 
	local parameters = skill.parameters 
	self:addStatusList({zz=3,s=63,r=self.world:getGameTime(),t=999999,i=self.itemID,p1=self.maxSP,p2=parameters.MAGICMAX,zz=3},0.5)
	self:addStatusList({zz=3,s=64,r=self.world:getGameTime(),t=999999,i=self.itemID,p1=self.SP,p2=self.skillANum,p3=1},0.5)
end

--- fight motion , call every update loop
-- @return null
function SHero8:fight()
	SHero8.super.fight(self) 
	if self.MAGICMAX==0 then
		local skill = self.attribute.skills[2] 
		local parameters = skill.parameters 
		self.MAGICMAX = parameters.MAGICMAX
	end
	if self.world:getGameTime()>self.nextSkillATime and self.skillANum<self.MAGICMAX and  (self.attribute.SKILLOPEN[2]==nil or self.attribute.SKILLOPEN[2]==1)  then
		-- SkillA:每3秒自动充能一层(上限4层)
		self.skillANum = self.skillANum + 1
		self.nextSkillATime = self.world:getGameTime() + 3 
		self:D("魔法师 SkillA:",self.skillANum,self.nextSkillATime)
		self:addStatusList({zz=3,s=64,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.SP,p2=self.skillANum,p3=(self:checkMana(4) and 0 or 1)},0)
	end
end


--- move motion , call every update loop
-- @return null
function SHero8:move() 

	-- if self.paths~=nil and #self.paths>0  then
	-- 	--清除回调流星回调
	-- 	if self.nextSkillCTime>self.world:getGameTime() then
	-- 		local skill = self.attribute.skills[4] 
	-- 		local parameters = skill.parameters 
	-- 		self:removeBuffToID(self:__skillID2buffID(skill.skillID,0))
	-- 		self:D("流星火雨 移动清除回调.....")
	-- 	end
	-- end
	if self.parent~=nil and self.mode5list['toX']~=nil and self.mode5move and self.world:getGameTime()>self.mode5movetime  then
		self.mode5move=false
		self:moveTo(self.mode5list['toX'],self.mode5list['toY'],false,6,self.mode5list['SPLITSPEED'],0)
	end
	SHero8.super.move(self)
end


--- 第7招上馬取消
-- @param null
-- @return null
function SHero8:removeSkillAttackMode7()
	SHero8.super.removeSkillAttackMode7(self)
	--清除回调流星回调
	-- if self.nextSkillCTime>self.world:getGameTime() then
	-- 	local skill = self.attribute.skills[4] 
	-- 	local parameters = skill.parameters 
	-- 	self:removeBuffToID(self:__skillID2buffID(skill.skillID,0))
	-- 	self:D("流星火雨 removeSkillAttackMode7清除回调.....")
	-- end
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SHero8:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SHero8.super.prepareHit(self,mode,adjTime,buff) 

	if (mode==2 or mode==3 or mode==4 or mode==5) and self.parent~=nil then
		hitValueBoth=nil
		return nil
	end


	if mode==2 or mode==10 then
		local skill = self.attribute.skills[2] 
		local parameters = skill.parameters 
		--SkillA:每3秒自动充能一层(上限4层),释放技能时消耗已充能完成的所有层数,每层充能额外提升20%伤害, 当叠满4层时伤害提升100%(0%、20%、40%、60%、100%)。CD:5秒
		if self.skillANum>0 then
			if mode==10 then
				hitValueBoth['APADJ'] = parameters.APADJ
				self.attribute.skills[2].lastCoolDownTime = self.world:getGameTime() + parameters.CDTIME
				self:syncSkill(0)
			end
			hitValueBoth['APADJ'] = hitValueBoth['APADJ'] * (1+parameters['MAGICAP'..self.skillANum]*0.01) 
			self.skillANum = 0
			self.nextSkillATime = self.world:getGameTime()+3
			self:addStatusList({zz=3,s=64,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.SP,p2=self.skillANum,p3=(self:checkMana(4) and 0 or 1)},0)
		end
	end

	--冰晶攻击2次伤害(目标爆伤1次后,延迟1秒爆破范围)第一击击中目标时获得5点法力值,爆破伤害每个 目标获得1点法力值。CD:9秒【一次攻击击中多个目标可重复堆叠】
	if mode==3 then
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 
		local creatureID=self.world:addCreature(self.world.tostring(102),self.teamOrig,self.lastBulletPositionX,self.lastBulletPositionY,self,1,1)
		local obj  = self.world.allItemList[creatureID]
		local lifeTime=4	
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		-- attributes['buffParameter'] = hitValueBoth
		attributes['buffParameter'] = table.deepcopy(self:getPrepareHithitValue())
		attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
		attributes['buffParameter']['buffType'] = 1
		attributes['buffParameter']['buffIntervalTime'] = 5
		attributes['buffParameter']['changeMode']=mode
		-- attributes['buffParameter']['FIXHURT'] = 8
		attributes['buffParameter']['APADJ'] = parameters.APADJ
		attributes['buffParameter']['creatureDirectHurCallBack'] = "BJ"
 		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,self.itemID,creatureID,parameters.DELAYTIME2)
		obj:addBuff(buff)
		obj:setDeadTime(lifeTime) 
	end

	if mode==5 then
		--杀掉之前的分身
		if #self.creatureIDList>0 then
			for k,v in pairs(self.creatureIDList) do
				local obj = self.world.allItemList[v] 
				-- obj.DEAD = 0.01
				if obj~=nil and  not obj:isDead() then
					obj.attribute.HP=0
					obj:directHurt(obj.itemID,0,{finalFixHurt=0},0)
					obj.deadTime = self.world:getGameTime()+9999999
					obj:addStatusList({s=42,r=self.world.gameTime,t=9999999,i=obj.itemID},0.2)
					--obj.world:removeItem(obj)
					obj.world.playerList[obj.itemID]['online'] = false
					obj.world.playerList[obj.itemID]['offLineTime']=self.world.gameTime-self.world.gameRoomSetting.offlineRemoveWaitTime
				end		
			end
			self.creatureIDList = {}
		end

		local skill = self.attribute.skills[5] 
		local parameters = skill.parameters 
		local randlist = self.world.formula:formationPoint(parameters.AVATARNUM,parameters.SPLITRANGE/self.world.setting.AdjustAttRange,true)
		for i=1,parameters.AVATARNUM do
			local idx = self.world:getHeroItemID()
			--local playerInfo = self.world:memcacheGet('aoeOther5Json')
			local playerInfo = self.playerJson
			self.world:D('jaylog excuteParam playerInfo:',playerInfo)
			self.world.playerList[idx] = self.world.tDeepcopy(self.world.playerList[self.itemID])
			self.world.playerList[idx]['i'] = idx
			self.world.playerList[idx]['id'] = self.world.playerList[self.itemID]['id'].."分身"
			self.world.playerList[idx]['p'] = self.world.playerList[self.itemID]['p']*10000+5
			self.world.playerList[idx]['playerJson'] = playerInfo

			--self.addHero(self,i,obj.team,obj.loginID..i,obj.initX+i,obj.initY,nil,idx)
			
			--local toX,toY = self.world.formula:getRandomCirclePoint(self.posX,self.posY,parameters.SPLITRANGE/self.world.setting.AdjustAttRange,true)
			local toX,toY = self.posX+randlist[i][1],self.posY+randlist[i][2]
			local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,toX,toY) 

			self.world:D('jaylog SHero8 ',toX,toY,self.posX,self.posY)
			local hero = self.world:addHero(self.attribute.roleId,self.team,self.loginID.."分身",self.posX,self.posY,101,idx)
			hero.mode5move=true
			hero.mode5list={toX=toX,toY=toY,SPLITSPEED=parameters.SPLITSPEED}
			hero.mode5movetime = self.world:getGameTime()+0.2
			hero.createNum=i

			if self.attribute.roleId==5 then
				hero:addStatusList({s=986,r=self.world.gameTime,t=parameters.AVATARTIME,i=hero.itemID,p1=self.itemID},0)
			else
				hero:addStatusList({s=985,r=self.world.gameTime,t=parameters.AVATARTIME,i=hero.itemID,p1=self.itemID},0)
			end
			hero:addStatusList({zz=3,s=76,r=self.world.gameTime,t=999,i=hero.itemID,p1=self.itemID},0)
			hero.AIlastMoveTime = self.world:getGameTime()+0.5
			--self.world.itemListFilter.heroList[idx]:setAuto(true)
			--AVATARAREAMAX=500;AVATARAREAMIX=200;ROLEBUFFSKILLA_RATE=100;AVATARHP=50000;AVATARINHERIT=100;AVATARDEF=0;AVATARMDEF=0;CDTIME=15;USESOULNUM=100;AVATARTIME=10
			--function SHero8:setDoubleMode(obj,deadtime,maxDis,minDis,AVATARDEF,AVATARMDEF,AVATARHP,AVATARINHERIT)
			hero:setDoubleMode(self,parameters.AVATARTIME,parameters.AVATARAREAMAX,parameters.AVATARAREAMIX,parameters.FOLLOWDIS,100,100,100,100)
			self:D("新弓箭手 召唤分身")
			self.creatureIDList[#self.creatureIDList+1] =  hero.itemID
		end
	end

	if mode==4 then
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		self.skillCINTERVALTIME = 0
		self.skillDURATION = 0

		if self.SP>=30 then
			self.skillCINTERVALTIME = parameters.INTERVALTIME1	
			self.skillDURATION = parameters.DURATION1
		end
		if self.SP>=60 then
			self.skillCINTERVALTIME = parameters.INTERVALTIME2
			self.skillDURATION = parameters.DURATION2
		end
		if self.SP>=90 then
			self.skillCINTERVALTIME = parameters.INTERVALTIME3
			self.skillDURATION = parameters.DURATION3
		end

		self:D("法师 流星火雨",self.skillCINTERVALTIME,self.skillDURATION,self.SP)
		local creatureID=self.world:addCreature(self.world.tostring(977),self.teamOrig,self.lastBulletPositionX,self.lastBulletPositionY,self,1,0)
		self.hyID = creatureID
		local obj  = self.world.allItemList[creatureID]
		local lifeTime= self.skillDURATION + skill.hitTime
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		-- attributes['buffParameter'] = hitValueBoth
		attributes['buffParameter'] = table.deepcopy(self:getPrepareHithitValue())
		attributes['buffParameter']['RANGE'] = skill.atkDis --obj.attribute.width * self.world.setting.AdjustAttRange
		attributes['buffParameter']['buffType'] = 1
		attributes['buffParameter']['buffIntervalTime'] = self.skillCINTERVALTIME
		attributes['buffParameter']['changeMode']=mode
		-- attributes['buffParameter']['FIXHURT'] = 8
		attributes['buffParameter']['APADJ'] = parameters.APADJ2
 		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,self.skillDURATION-self.skillCINTERVALTIME,{99},0,self.itemID,creatureID,skill.hitTime)
		obj:addBuff(buff)
		obj:setDeadTime(lifeTime) 
		obj:addStatusList({s=89,r=self.world.gameTime,t=self.skillDURATION,i=self.itemID,p1=self.itemID,p2=4,p3=self.skillCINTERVALTIME*100},0)
		self:useSP(self.SP)
	end

	-- if mode==4 then
	-- 	local skill = self.attribute.skills[4] 
	-- 	local parameters = skill.parameters 
	-- 	self.skillCNum = 0
	-- 	self.skillCINTERVALTIME = 0
	-- 	--做一次范围伤害并回调
	-- 	local hitValueNew = self:getPrepareHithitValue()
	-- 	--hitValueNew['FIXHURT'] = 88
	-- 	hitValueNew['APADJ'] = parameters.APADJ2
	-- 	self:directFightAuratoDalay(4,0,hitValueNew,{posX=self.lastBulletPositionX,posY=self.lastBulletPositionY,RANGE=skill.atkDis},0)

	-- 	if self.SP>=30 then
	-- 		self.skillCINTERVALTIME = parameters.INTERVALTIME1	
	-- 	end
	-- 	if self.SP>=60 then
	-- 		self.skillCINTERVALTIME = parameters.INTERVALTIME2
	-- 	end
	-- 	if self.SP>=90 then
	-- 		self.skillCINTERVALTIME = parameters.INTERVALTIME3
	-- 	end
	-- 	self.skillCNum = parameters.DURATION/self.skillCINTERVALTIME

	-- 	self:D("流星火雨第一次伤害:",self.skillCNum,self.SP)
	-- 	self.skillCNum = self.skillCNum - 1
	-- 	if self.skillCNum>0 then
	-- 		local attributes = {}
	-- 		attributes['buffParameter']={}
	-- 		attributes['BUFFONLY']=1
	-- 		attributes['buffParameter'] = {}
	-- 		attributes['buffParameter']['buffIntervalTime'] = 5
	-- 		attributes['buffParameter']['buffType'] = 5
	-- 		local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,0.1,{mode},0,self.itemID,self.itemID,self.skillCINTERVALTIME) 
	-- 		self:addBuff(buffObj)
	-- 		self.nextSkillCTime = self.world:getGameTime() + self.skillCINTERVALTIME
	-- 		self:D("流星火雨第一次伤害并回调:",self.skillCNum,self.SP,self.nextSkillCTime,self.world:getGameTime())
	-- 	end
	-- end

	-- if mode==4 then
	-- 	local skill = self.attribute.skills[4] 
	-- 	local parameters = skill.parameters 
	-- 	self.skillCNum = 0

	-- 	--做一次范围伤害并回调
	-- 	local hitValueNew = self:getPrepareHithitValue()
	-- 	--hitValueNew['FIXHURT'] = 88
	-- 	hitValueNew['APADJ'] = parameters.APADJ2
	-- 	self:directFightAuratoDalay(4,0,hitValueNew,{posX=self.lastBulletPositionX,posY=self.lastBulletPositionY,RANGE=skill.atkDis},0)
	-- 	local  ishd = false
	-- 	if self.skillCNum%parameters.KILLSPROLL==0 then
	-- 		if self.SP>=parameters.KILLSPNUM then
	-- 			self:useSP(parameters.KILLSPNUM)
	-- 			ishd = true
	-- 		else
	-- 			ishd = false
	-- 		end
	-- 	else
	-- 		ishd = true
	-- 	end
	-- 	self:D("流星火雨第一次伤害:",self.skillCNum,self.SP)
	-- 	self.skillCNum = self.skillCNum + 1
	-- 	if ishd then
	-- 		local attributes = {}
	-- 		attributes['buffParameter']={}
	-- 		attributes['BUFFONLY']=1
	-- 		attributes['buffParameter'] = {}
	-- 		attributes['buffParameter']['buffIntervalTime'] = 5
	-- 		attributes['buffParameter']['buffType'] = 5
	-- 		local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,0.1,{mode},0,self.itemID,self.itemID,parameters.INTERVALTIME) 
	-- 		self:addBuff(buffObj)
	-- 		self.nextSkillCTime = self.world:getGameTime() + parameters.INTERVALTIME
	-- 		self:D("流星火雨第一次伤害并回调:",self.skillCNum,self.SP,self.nextSkillCTime,self.world:getGameTime())
	-- 	end
	-- end

	-- if mode==104 then
	-- 	local skill = self.attribute.skills[4] 
	-- 	local parameters = skill.parameters 

	-- 	--范围伤害并回调
	-- 	local hitValueNew = self:getPrepareHithitValue()
	-- 	hitValueNew['FIXHURT'] = 88
	-- 	self:directFightAuratoDalay(4,0,hitValueNew,{posX=self.lastBulletPositionX,posY=self.lastBulletPositionY,RANGE=skill.atkDis},0)
	-- 	self:D("流星火雨回调伤害:",self.skillCNum,self.SP)
	-- 	self.skillCNum = self.skillCNum - 1
	-- 	if self.skillCNum>0 then
	-- 		local attributes = {}
	-- 		attributes['buffParameter']={}
	-- 		attributes['BUFFONLY']=1
	-- 		attributes['buffParameter'] = {}
	-- 		attributes['buffParameter']['buffIntervalTime'] = 5
	-- 		attributes['buffParameter']['buffType'] = 5
	-- 		local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,0.1,{mode-100},0,self.itemID,self.itemID,self.skillCINTERVALTIME) 
	-- 		self:addBuff(buffObj)
	-- 		self.nextSkillCTime = self.world:getGameTime() + self.skillCINTERVALTIME
	-- 		self:D("流星火雨回调伤害并回调:",self.skillCNum,self.SP,self.nextSkillCTime,self.world:getGameTime())
	-- 	end

	-- end

	-- if mode==104 then
	-- 	local skill = self.attribute.skills[4] 
	-- 	local parameters = skill.parameters 

	-- 	--范围伤害并回调
	-- 	local hitValueNew = self:getPrepareHithitValue()
	-- 	hitValueNew['FIXHURT'] = 88
	-- 	self:directFightAuratoDalay(4,0,hitValueNew,{posX=self.lastBulletPositionX,posY=self.lastBulletPositionY,RANGE=skill.atkDis},0)
	-- 	local  ishd = false
	-- 	if self.skillCNum%3==0 then
	-- 		if self.SP>=30 then
	-- 			self:useSP(30)
	-- 			ishd = true
	-- 		else
	-- 			ishd = false
	-- 		end
	-- 	else
	-- 		ishd = true
	-- 	end
	-- 	self:D("流星火雨回调伤害:",self.skillCNum,self.SP)
	-- 	self.skillCNum = self.skillCNum + 1
	-- 	if ishd then
	-- 		local attributes = {}
	-- 		attributes['buffParameter']={}
	-- 		attributes['BUFFONLY']=1
	-- 		attributes['buffParameter'] = {}
	-- 		attributes['buffParameter']['buffIntervalTime'] = 5
	-- 		attributes['buffParameter']['buffType'] = 5
	-- 		local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,0.1,{mode-100},0,self.itemID,self.itemID,1) 
	-- 		self:addBuff(buffObj)
	-- 		self.nextSkillCTime = self.world:getGameTime() + 1
	-- 		self:D("流星火雨回调伤害并回调:",self.skillCNum,self.SP,self.nextSkillCTime,self.world:getGameTime())
	-- 	end

	-- end


	return hitValueBoth 
end 

--- 使用技能伤害，call父类的skillAttack
-- @param mode int - 技能 1-8 rank
-- @param itemID int - 攻擊目標 itemID
-- @param positionX float - 攻擊目標 位置 X
-- @param positionY float - 攻擊目標 位置 Y
-- @param force bool - true ＝ 無視失控, 失控時攻擊目標用
-- @param fromClientSide bool - true ＝ 來自客戶端
-- @return msg table - 返回msg 給client 包括action move skillstatus
function SHero8:skillAttack(mode,itemID,positionX,positionY,force,fromClientSide,nPara,pPara)
	--普通攻击切换模式 普通攻击:修改为直线攻击,触碰单目标后消失(类单体伤害)。每次攻击成功击中目标,获得1点箭魂,击杀目标获得3点。
	if mode==2 and self.skillANum==self.MAGICMAX  then
		mode=10
		self:D("法师 切换2号攻击为:",mode)
	end

	return SHero8.super.skillAttack(self,mode,itemID,positionX,positionY,force,fromClientSide,nPara,pPara)
end


---设置分身模式
function SHero8:setDoubleMode(obj,deadtime,maxDis,minDis,followDis,AVATARDEF,AVATARMDEF,AVATARHP,AVATARINHERIT)
	--AVATARHP=50000;AVATARINHERIT=100;AVATARDEF=0;AVATARMDEF=0;CDTIME=15;USESOULNUM=100;AVATARTIME=10
	--AVATARAREAMAX=500;AVATARAREAMIX=200;ROLEBUFFSKILLA_RATE=100
	self:D("新弓箭手 AVATARHP",AVATARHP,deadtime)
	self.doubleMode=1
	self.parent=obj
	self.createTime = self.world:getGameTime()
	self.DEAD=deadtime 
	self.moveMaxDis = maxDis/self.world.setting.AdjustAttRange
	self.moveMinDis = minDis/self.world.setting.AdjustAttRange
	self.followDis = followDis/self.world.setting.AdjustAttRange

	self.attribute.DEF=self.parent.attribute.DEF*AVATARDEF*0.01
	self.attribute.MDEF=self.parent.attribute.MDEF*AVATARMDEF*0.01
	self.attribute.HP=AVATARHP
	self.attribute.MaxHP=AVATARHP
	self.attribute.baseTable.MaxHP=AVATARHP
	self.attribute.ATK=self.parent.attribute.ATK*AVATARINHERIT*0.01
	self.attribute.HIT=self.parent.attribute.HIT*AVATARINHERIT*0.01
	self.attribute.DODGE=self.parent.attribute.DODGE*AVATARINHERIT*0.01
	self.attribute.CRI=self.parent.attribute.CRI*AVATARINHERIT*0.01

	-- self:updateSyncMsg({h={{i=self.itemID,t=0,d=0,h=1,hp=self.attribute.MaxHP,hpe=0,ti=self.itemID,m=1,s=0}}})
	self:setAuto(true)

	local result=self:getAllInfo(0,true)
	self:updateSyncMsg({i=result})
end


--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero8:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	
	if mode==1 then
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters 

		local attackRange = {posX=obj.posX,posY=obj.posY,radius=parameters.EXPLODERANGE/self.world.setting.AdjustAttRange} 

		local hitValueNew = self:getPrepareHithitValue()
		--debuglog("parameters:..."..self.world.cjson.encode(parameters))
		hitValueNew['skillID'] = 1
		hitValueNew['APADJ'] = parameters.APADJ
		
		local bullet = require("gameroomcore.SBullet").new(self.world,1,self.itemID,0.2,0,obj.posX,obj.posY)
		bullet.attr.ignoreID = {itemID}
		bullet:directFightAura(1,attackRange,hitValueNew,bullet.attr.angle,0) 
		bullet:setDead() 
		hitValue['attackZXP'] = "1"

	end

	if mode==2 or mode==10 then
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[2] 
		local parameters = skill.parameters 

		local attackRange = {posX=obj.posX,posY=obj.posY,radius=parameters.EXPLODERANGE/self.world.setting.AdjustAttRange} 

		local hitValueNew = self:getPrepareHithitValue()
		--debuglog("parameters:..."..self.world.cjson.encode(parameters))
		hitValueNew['skillID'] = 1
		hitValueNew['APADJ'] = parameters.APADJ
		
		local bullet = require("gameroomcore.SBullet").new(self.world,1,self.itemID,0.2,0,obj.posX,obj.posY)
		bullet.attr.ignoreID = {itemID}
		bullet:directFightAura(1,attackRange,hitValueNew,bullet.attr.angle,0) 
		bullet:setDead() 
		hitValue['attackZXP'] = "1"
	end

	local ret = SHero8.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	
	
	if  mode==1 and ret>0 then
		--普通攻击效果,击中目标恢复1点法力值,暴击获得2点【一次攻击击中多个目标可获得多次】
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		if hitValue['Effect'] == 1 then
			self:adjSP(parameters.ADJMAGICCRI)
		else
			self:adjSP(parameters.ADJMAGICNUM)
		end
	end

	if mode==3 and ret>0 then
		--ADJMAGICNUM=5;ADJMAGICCRI=1
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		self:adjSP(parameters.ADJMAGICNUM)
	end

	return ret 
end 

--- 設定為已死亡
-- @return null
-- function SBullet:setDead()

--- 直接傷害callBack
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
-- @return null
function SHero8:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt)
	SHero8.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
	if hitValue['creatureDirectHurCallBack']~=nil and hitValue['creatureDirectHurCallBack']=="BJ" then --and in_array(hitValue['creatureDirectHurCallBack'],self.creatureList)) then
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 
		self:adjSP(parameters.ADJMAGICCRI)
	end
end


--- 受傷害計算
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero8:hurted(itemID,bulletID,mode,hitValue,adjTime)
	
	local ret = SHero8.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
	return ret 	
end

function SHero8:checkMana(mode)

	if mode==4  then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		
		self:D("愤怒 ",self.world.cjson.encode(parameters))
		if self.SP<parameters.USEMIXSP then
			return false
		end
	end

	return SHero8.super.checkMana(self,mode) 	
end

--- 自动移动chud
-- @return null
-- function SHero8:_autoMove()
-- 	-- --debuglog("SHero:_autoMove")
-- 	local moveRet=self.autoFightAI:autoMoveToAlerted()
-- 	local ret=SHero8.super._autoMove(self)
-- 	if not ret and not self.autoBlocked and self.AIlastMoveTime < self.world:getGameTime() and  not self:isDead() and not moveRet and self.statusList[4007]==nil then
		
-- 		self.autoFightAI:autoMoveToHero()
-- 		self.AIlastMoveTime = self.moveToEndTime

-- 	end
-- 	return ret
-- end


--- 自动移动chud
-- @return null
function SHero8:_autoMove()
	if self.doubleMode==0 then
		SHero8.super._autoMove(self)
	else
		if not self.autoBlocked and self.AIlastMoveTime < self.world:getGameTime() and  not self:isDead()  and self.statusList[4007]==nil then
			local moveMaxDis = self.moveMaxDis
			if self.atkID==0 then
				moveMaxDis = self.followDis
			end
			self.autoFightAI:autoMoveToFollowed(moveMaxDis,self.moveMinDis,self.createNum)
			--self.AIlastMoveTime = self.moveToEndTime
		end
	end

end

--自动攻击用来重载
function SHero8:_autoFightToHero()
	--需要获得自动攻击的item  释放skill的id
	local targetID,skillID,cdTime

	if self.parent~=nil then	
		--设置bb攻击itemID
		--被打保护
		self.skillAType = 1
		if self.parent.lastHurtAllID~=nil and self.parent.lastHurtAllID>0 and (self.parent.lastHurtAllTime+10)>self.world:getGameTime() then
			local obj = self.world.allItemList[self.parent.lastHurtAllID] 
			if obj~=nil and not obj:isDead() and obj.attribute.HP>0 then
				if obj.attribute.parameterArr['NOBEFIGHT']==nil then
					self.atkID = self.parent.lastHurtAllID
				else
					self.atkID = obj.parent.itemID
				end
				self:D("法师BB 主人被打保护:",self.parent.lastHurtAllID,self.parent.lastHurtAllTime,self.world:getGameTime(),obj.attribute.HP)
			end
			
		end		
		--攻击出战
		if self.parent.lastAttackID~=nil and self.parent.lastAttackID>0 and (self.parent.lastAttackTime+10)>self.world:getGameTime() then
			local obj = self.world.allItemList[self.parent.lastAttackID] 
			if obj~=nil and not obj:isDead() and obj.attribute.HP>0 then
				if obj.attribute.parameterArr['NOBEFIGHT']==nil then
					self.atkID = self.parent.lastAttackID
				else
					self.atkID = obj.parent.itemID
				end
				self:D("法师BB 攻击出战:",self.parent.lastAttackID,self.parent.lastAttackTime,self.world:getGameTime(),obj.attribute.HP)
			end
		end

		--获得父类攻击的目标
		local obj = self.world.allItemList[self.atkID] 
		if obj~=nil and not obj:isDead() and obj.attribute.HP>0 then
			local d = self:distance(obj.posX,obj.posY)
			self:D("法师BB 攻击目标:",obj.itemID,d,self.moveMaxDis,obj.attribute.HP)
			if d<self.moveMaxDis then
				self:D("法师BB 攻击目标true:",obj.itemID)
				local pre = self.prepareSkillAttackNum
				local ret = self:skillAttack(self.skillAType ,obj.itemID)	
				self.world:D(pre,self.prepareSkillAttackNum,self.world.cjson.encode(ret))
				local retskill = self:skillAttack(self.skillAType ,obj.itemID)	
				self.skillAType = 1
			end
		else
			self.atkID = 0
		end

		if self.atkID==0 then
			targetID,skillID,cdTime=self.autoFightAI:autoFightToHero({})
			if targetID>0 then
				----debuglog("SHero:_autoFight 进去之前 lastCoolDownTime:"..self.lastCoolDownTime.." gameTime:"..self.world.gameTime.." ret:"..self.world.cjson.encode(ret).."第几下:"..self.mode1order)
				ret = self:skillAttack(skillID,targetID)
				self.AIlastATKTime = self.world:getGameTime()+cdTime
				--防止放完技能立刻回头不好的体验
				self.AIlastMoveTime = self.world:getGameTime() + 0.2
				----("SHero:_autoFight lastCoolDownTime:"..self.lastCoolDownTime.." gameTime:"..self.world.gameTime.." ret:"..self.world.cjson.encode(ret).."第几下:"..self.mode1order)
			end
		end
		
	else
		if self.world.heroNeedSkillID~=nil and self.world.heroNeedSkillID>0 then
			ret = true
		else
			ret = false
			if (self.teamOrig=="A") then
				teamlist=self.world.itemListFilter.heroTeamAList
			else
				teamlist=self.world.itemListFilter.heroTeamBList
			end

			local skill2 = self.attribute.skills[2]  
	  
			--刷新AI4行为
			if self.world:getGameTime()>self.mode2AINextTime  then
				self.mode2AItype = self.world.formula:getRandnum(0,4)
				self.mode2AINextTime = self.world:getGameTime() + 60
			end

			self:D("法师AI套路 参数:",self.mode2AItype,self.SP,self.mode2AINextTime)

			if (self.attribute.SKILLOPEN[2]==nil or self.attribute.SKILLOPEN[2]==1)  and skill2.lastCoolDownTime<self.world:getGameTime()  and self.skillANum>=self.mode2AItype then
				local targetList = {}
				local visRange={posX=self.posX,posY=self.posY,radius=skill2.useDis/self.world.setting.AdjustVisRange}
				local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
				function(value)
				 	ok = true
					if (value:isDead()) then ok =false end
					if (value.attribute.HP<=0) then ok =false end
					if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
					if ok  then
						local d = value:colliding(visRange,0,0,self.itemID)
						if d>=0 then
							targetList[#targetList+1] = {d=d,id=value.itemID}
						end
					end
				end
				)
				self:D("法师AI套路 可选目标 targetList:",self.world.cjson.encode(targetList))
				if #targetList>0 then
					self.world.tSort(targetList,function( a1,b1 )
											return a1['d'] < b1['d']
										end)
					ret = self:skillAttack(2,targetList[1]['id'])
				end
			end

			if self.mode2AItype==0 then
				ret = false
			end

		end
		

		if not ret then
			skillID = SHero8.super._autoFightToHero(self) 
		end
	end
	return skillID
end



function SHero8:adjSP(sp,force)

	self.SP = math.round(self.SP + sp, 1)
	if self.SP>self.maxSP then self.SP = self.maxSP end
	if self.SP>self.changePartSP then self.SP=self.changePartSP end

	if self.SP<1 then 
		self.SP = 0 
	end
	self:addStatusList({zz=3,s=64,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.SP,p2=self.skillANum,p3=(self:checkMana(4) and 0 or 1)},0)
	self:D("单次增加愤怒值:",sp,"总愤怒值:",self.SP)
end

function SHero8:useSP(sp)

	self.SP = math.round(self.SP - sp, 1)

	if self.SP<1 then 
		self.SP = 0 
	end
	self:addStatusList({zz=3,s=64,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.SP,p2=self.skillANum,p3=(self:checkMana(4) and 0 or 1)},0)
	self:D("单次使用愤怒值:",sp,"总愤怒值:",self.SP)
end


--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SHero8:goToDead(itemID,mode,adjTime,bonus)
	--玩家死了以后分身也死
	if #self.creatureIDList>0 then
		for k,v in pairs(self.creatureIDList) do
			local obj = self.world.allItemList[v] 
			-- obj.DEAD = 0.01
			if obj~=nil and  not obj:isDead() then
				obj.attribute.HP=0
				obj:directHurt(obj.itemID,0,{finalFixHurt=0},0)
				obj.deadTime = self.world:getGameTime()+9999999
				obj:addStatusList({s=42,r=self.world.gameTime,t=9999999,i=obj.itemID},0.2)
				--obj.world:removeItem(obj)
				obj.world.playerList[obj.itemID]['online'] = false
				obj.world.playerList[obj.itemID]['offLineTime']=self.world.gameTime-self.world.gameRoomSetting.offlineRemoveWaitTime
			end		
		end
		self.creatureIDList = {}
	end

	--杀掉火雨
	if self.hyID>0 then
		local obj  = self.world.allItemList[self.hyID]
		if obj~=nil and not obj:isDead() then
			obj.attribute.HP=0
			obj:directHurt(obj.itemID,0,{finalFixHurt=0},0)
			obj.deadTime = self.world:getGameTime()+9999999
			obj:addStatusList({s=42,r=self.world.gameTime,t=9999999,i=obj.itemID},0.2)
		end
	end
	
	SHero8.super.goToDead(self,itemID,mode,adjTime,bonus)
end

function SHero8:syncInfo()
	SHero8.super.syncInfo(self)
	--分身自杀
	if self.DEAD>0 then
		if (self.createTime+self.DEAD<=self.world.gameTime or (self.parent~=nil and self.parent:isDead())) then
			self.parent.creatureID = 0
			self.attribute.HP=0
			self:directHurt(self.itemID,0,{finalFixHurt=0},0)
			self.deadTime = self.world:getGameTime()+9999999
			self:addStatusList({s=42,r=self.world.gameTime,t=9999999,i=self.itemID},0.2)
			self.world:removeItem(self)
		end
	end

end


--- 第7招上馬和下馬
-- @param updateMove boolean - 强制移动重算
-- @return returnObj obj - 移动信息
function SHero8:prepareSkillAttackMode7(updateMove)
	if self.parent==nil then
		SHero8.super.prepareSkillAttackMode7(self,updateMove)
	end
end


return SHero8 
