#!/bin/bash

#ps aux |grep 'main 286' |grep -v grep | awk '{print "kill "$2}'|sh
#ps aux |grep 'main 287' |grep -v grep | awk '{print "kill "$2}'|sh

#/var/aoe_fb/MasterGame.sh
