#!/bin/bash

/home/aoeShare/sync.sh

ps aux |grep 3006 |grep "main" |awk '{print "sudo kill "$2}' |sh

sleep 1

sudo /var/aoe/MasterGame-now.sh
