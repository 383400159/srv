--所有非英雄
--local SNPC = class("SNPC" ,require("gameroom.hero.SHeroInWorld"..worldForHero))
local SNPC = class("SNPC" ,require("gameroomcore.SHeroBase"))

-- class Enemy extends BaseActor {

--- Constructor
-- @param world object - world object
-- @param id int - enemyID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param level int - enemy起始级别
-- @return null
function SNPC:ctor(world,id,team,posX,posY,level)
	if self.className==nil then
		self.className="SNPC"
	end

	SNPC.super.ctor(self,world,id,team,posX,posY,level)

	self.lastFoundTargetTime=0	--上次寻敌时间
	self.checkMoveOverLapTime=0	--上次检查移动碰撞时间
	-- jay test
	self.outOfCtlTime = 0	-- 失控時間，但可以自動攻擊，SActor已有
	self.outOfCtlAllTime = 0	-- 全失控時間，SActor已有
	
	self.invincibleTime = 0		-- 無敵時間  — 可以用buff 取代，SActor已有

	self.lastCoolDownTime = 0		-- 所有動作的CD時間，SActor已有

	-- 传送门标记传送到的地图和room port
	self.toMap = 0
	self.toRoomID = 0
	self.toMapX = 0
	self.toMapY = 0
	-- 怪类型
	self.actorType = 3

	self.AImode = 1

	self.autoFightAI.runMoveAI = false
	--self:__init(id,posX,posY,level)
end -- end of SNPC:ctor()

--- init funtion 初始化属性参数
-- @param id int - enemy id
-- @param posX int - 起始坐标X
-- @param posY int - 起始坐标Y
-- @param level int - 起始级别
-- @return null
function SNPC:__init(id,posX,posY,level)
	self.world:__loadNPC(id)
	-- self:D('jaylog start __init.....'..self.world.cjson.encode(self.world.enemyAll[id]))
	self.attribute=require("gameroom.attribute.SAttributeNPC").new(id,level,self)
	self.attribute.roleId = id
end

function SNPC:addTaskBuff()
	if self.attribute~=nil then
		self:D("SNPC attribute is not nil")
	end

	local attributes = {}
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['buffParameter']['INEVITABLEHIT'] = 1
	attributes['buffParameter']['RANGE'] = self.attribute.width * self.world.setting.AdjustAttRange
	attributes['buffParameter']['creatureDirectHurCallBack'] = self.itemID
	--self:D("jaylog addCreature  creatureID:"..creatureID)
	attributes['buffParameter']['buffType'] = 4			--parameters.PASSNUM
	local intervalTime = 0.3
	if self.attribute.parameterArr["ISWF"]==1 then
		intervalTime = 0.1
	end
	attributes['buffParameter']['buffIntervalTime'] = intervalTime
	attributes['BUFFTIME'] = 99999
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0),attributes,999999,{99},0,self.itemID,self.itemID,0.1)
	-- buff.debug = true
	self:addBuff(buff)

end
--- fight motion,enemy执行攻击动作,子类重新定义逻辑
-- @param null
-- @return null
function SNPC:fight() 
	return SNPC.super.fight(self)
end

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SNPC:goToDead(itemID,mode,adjTime,bonus) 
	if(  mode == nil )then
		mode =0
	end
	SNPC.super.goToDead(self,itemID,mode,adjTime,bonus)

end -- end of SNPC:goToDead

function SNPC:__findTarget() 
	--
end

function SNPC:_autoMove()
	--body
end



function SNPC:_checkBehind(x1,y1,x2,y2,adjust)
	if adjust==nil then adjust = 0 end
	if self.team=="A" then adjust = adjust * -1 end
	if self.world.towerBPos.posY==nil or self.world.towerBPos.posX==nil or self.world.towerAPos.posY==nil or self.world.towerAPos.posX==nil then
		self:D('============================================================ found bug '..self.className..self.itemID)
		return true
	end
	local ret = ((y1-y2+adjust)*(self.world.towerBPos.posY-self.world.towerAPos.posY)-(self.world.towerAPos.posX-self.world.towerBPos.posX)*(x1-x2))
	return self.team=="A" and ret<0 or ret>0
end


-- 广播信息
--- 廣播 同步角色 all info,调用SActor的__getAllInfo
-- @param adjTime float - 調整時間
-- @param isReturn bool - 直接返回結果, 不廣播
-- @return infoMsg table - 角色info
-- function SNPC:__getAllInfo(adjTime,rReturn) 
	-- if adjTime==nil then adjTime = 0 end
	-- if(rReturn == nil) then
	-- 	rReturn = false
	-- end
	-- if (rReturn == false) then
	-- 	return nil
	-- end
	
	-- return SNPC.super.__getAllInfo(self,adjTime,rReturn)
-- end

--- 广播同步角色，__getAllInfo的简称，用于公共调用
-- @param null
-- @return infoMsg table - 角色info
function SNPC:getAllInfo(adjtime) 
		return self:__getAllInfo(adjtime,true)
end


function SNPC:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	local obj = self.world.allItemList[itemID]
	if obj~=nil then
		-- SNPC.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
		if self.world.gameRoomSetting['ISYW']==1 then
			if obj.actorType==0 and not self.world.playerList[obj.itemID]['online'] then
				return nil
			end
			if obj.taskObj.checkNPCList~=nil then
				-- self.world:D("SNPC directHurtCallBack itemID:"..itemID)
				self.world:D("SNPC directHurtCallBack checkNPCList:",self.world.cjson.encode(obj.taskObj.checkNPCList),self.attribute.roleId)
			end
			if obj.taskObj.checkNPCList~=nil then
				-- self:D("SNPC directHurtCallBack itemID:"..itemID)
				for k,v in pairs(obj.taskObj.checkNPCList) do
					local tlist = string.split(k,"_")
					local NPCtaskStr = ""
					--获得最高层次的NPC任务
					for i=1,8 do
						if v[""..i]~=nil  then
							NPCtaskStr=v[""..i]
							i=9
						end
					end

					local TaskIDlist = string.split(NPCtaskStr,"*")
					-- self.world:D("SNPC  TaskIDlist:",self.world.cjson.encode(TaskIDlist),self.world.cjson.encode(tlist),self.attribute.roleId)
					if tlist[1]=="npc" and  self.world.tonumber(tlist[2])==self.attribute.roleId then
						-- self.world:D("SNPC  tlist:",self.world.cjson.encode(tlist))
						--self.world:D("SNPC  taskObj taskList:",self.world.cjson.encode(obj.taskObj.taskList))
						--s 未定 p1=NPC.ID p2=预留放时间 
						if self.world.tonumber(TaskIDlist[6])>0 or self.world.tonumber(TaskIDlist[9])>0 then
							--if obj.autoMoveStartCollect and self.world.tonumber(TaskIDlist[9])==0 then
							--	obj.counterObj:setCounter("npc_"..tlist[2],1)
							--else
							-- self.world:D('SNPC taskList ',self.world.cjson.encode(obj.taskObj.taskList[TaskIDlist[3]][TaskIDlist[1]]))
							-- self.world:D('jaylog SNPC:directHurtCallBack statusList:',obj.itemID,self.world.cjson.encode(obj.statusList[999]),self.world.cjson.encode(obj.statusList[41]),self.world.cjson.encode(obj.statusListRemoved[41]))
							if obj.taskObj.taskList[TaskIDlist[3]][TaskIDlist[1]]['finish']==0 and obj.statusListRemoved[41]==nil and obj.statusList[41]==nil then
								obj:addStatusList({zz=3,s=999,r=self.world.gameTime,t=0.5,p1=self.world.tonumber(tlist[2]),p2=self.world.tonumber(TaskIDlist[6]),p3=self.world.tonumber(TaskIDlist[11]),p4=self.world.tonumber(TaskIDlist[9]),p5=self.world.tonumber(TaskIDlist[10]),p6=0})	--,p6=self.world.tonumber(TaskIDlist[11])
								-- obj:addStatusList({s=999,r=self.world.gameTime,t=1,p1=self.world.tonumber(tlist[2]),p2=999,p4=self.world.tonumber(TaskIDlist[9]),p5=1,p6=self.world.tonumber(TaskIDlist[1])})
								obj:addStatusList({zz=3,s=607,r=self.world.gameTime,t=0.5,p1=self.itemID})
							end
							--end
						else
							-- obj:addStatusList({s=998,r=self.world.gameTime,t=1,p1=self.world.tonumber(tlist[2]),p2=self.world.tonumber(TaskIDlist[3])})
							obj.counterObj:setCounter("npc_"..tlist[2],1)
						end
						if self.world.tonumber(TaskIDlist[7])>0 or self.world.tonumber(TaskIDlist[8])>0 then
							if obj.actorType==0 then
								local responce = self.world.cjson.encode({errcode=0,mes='',data={taskGut={taskID=TaskIDlist[11],taskType=TaskIDlist[3]}}})
								obj:activeSyncMsg(responce)
							end
						end
						--等对接 现在直接完成
						--obj.counterObj:setCounter("npc_"..tlist[2],1)
					end
					if (tlist[1]=='api' or tlist[1]=='boss') and self.world.tonumber(TaskIDlist[5])==self.world.tonumber(self.attribute.roleId) then
						if self.world.tonumber(TaskIDlist[7])>0 or self.world.tonumber(TaskIDlist[8])>0 then
							if obj.actorType==0 then
								local responce = self.world.cjson.encode({errcode=0,mes='',data={taskGut={taskID=TaskIDlist[11],taskType=TaskIDlist[3]}}})
								obj:activeSyncMsg(responce)
							end
						end
					end
					if self.world.sFind(tlist[1],'game')~=nil then
						-- self.world:D('jaylog SNPC:directHurtCallBack game NPC check ',self.world.tonumber(TaskIDlist[4]),self.world.tonumber(TaskIDlist[5]),self.attribute.roleId,obj:getCustomTeamID(),obj:getWaitQueue(),obj.lastTaskRedirectTime,self.world.gameTime)
						if self.world.tonumber(TaskIDlist[4])>0 and self.world.tonumber(TaskIDlist[5])>0 and self.world.tonumber(TaskIDlist[5])==self.world.tonumber(self.attribute.roleId) and obj:getCustomTeamID()==0 and obj:getWaitQueue()==0 and obj.lastTaskRedirectTime<self.world.gameTime then
							obj:updateInfo()
							-- self.world:memcacheSet('gameID'..self.world.playerList[itemID]['p'],self.world.formula:getRandnum(10000,99999)..self.world.playerList[itemID]['p'])
							-- self.world:D('jaylog start set losePos:',self.world.cjson.encode({mapMode=self.world.mapModel,X=obj.initX,Y=obj.initY}))
							self.world:memcacheSet('losePos'..self.world.playerList[itemID]['p'],self.world.cjson.encode({mapMode=self.world.mapModel,X=obj.initX,Y=obj.initY}))
							-- local gameID = self.world:memcacheGet('gameID'..self.world.playerList[itemID]['p'])
							local roomID,roomStart,roomEnd = 0,2970,2990
							-- if self.world.gameRoomSetting['ISUAT']==1 then
							-- 	roomStart = roomStart - 300
							-- 	roomEnd = roomEnd - 300
							-- end
							roomStart = roomStart - self.world.tonumber(self.world.Config.roomIDAdd)
							roomEnd = roomEnd - self.world.tonumber(self.world.Config.roomIDAdd)
							roomID = self.world:findEmptyRoomPort(roomStart,roomEnd,self.world.tonumber(TaskIDlist[4]))
							-- local attributes = {}
							-- attributes['STOPMOVE_RATE'] = 100
							-- attributes['BUFFTIME'] = 9999
							-- local buff = require("gameroomcore.SBuff").new(self.world,obj:__skillID2buffID(1),attributes,9999,{},0,obj.itemID,obj.itemID)
							-- obj:addBuff(buff)
							obj:moveTo(obj.targetPosition.x,obj.targetPosition.y,true,7,1,0)
							-- self.world:D('jaylog SNPC roomID ',roomID)
							-- 取消自动寻路状态
							obj:removeStatusList(996)
							local toX,toY = self.posX,self.posY
							if TaskIDlist[12]~=nil and TaskIDlist[12]~="0" and TaskIDlist[13]~=nil and TaskIDlist[13]~="0" then
								toX = self.world.tonumber(TaskIDlist[12])
								toY = self.world.tonumber(TaskIDlist[13])
							end
							self.world:redirectRoom(itemID,self.world.tonumber(TaskIDlist[4]),roomID,nil,toX,toY,nil,true,false,true)
							obj.lastTaskRedirectTime = self.world.gameTime + 10
						end
					end
				end
			end
			-- if self.world.tonumber(self.attribute.roleId)==21003 and self.itemID~=itemID then
			-- 	local obj = self.world.allItemList[itemID]
			-- 	self.world:memcacheSet('gameID'..self.world.playerList[itemID]['p'],self.world.formula:getRandnum(10000,99999)..self.world.playerList[itemID]['p'])
			-- 	local gameID = self.world:memcacheGet('gameID'..self.world.playerList[itemID]['p'])
			-- 	local roomID = self.world:findEmptyRoomPort(3200,3210,7001)
			-- 	self.world:redirectRoom(itemID,7001,roomID,nil,self.posX,self.posY,gameID)
			-- 	obj.lastTaskRedirectTime = self.world.gameTime + 10
			-- end
			if hitValue['creatureDirectHurCallBack']~=nil and hitValue['creatureDirectHurCallBack']~=itemID then
				--self:D('jaylog SNPC:directHurtCallBack in cID ',hitValue['creatureDirectHurCallBack'],' itemID ',itemID,' toMap:',self.toMap,' toRoomID:',self.toRoomID)
				--传送门回调start
				if self.toMap~=0 and hitValue['isTransitDoor']~=nil then
					if self.world.allItemList[itemID].actorType==0 then
						if self.world.allItemList[itemID]:isAIObj() then
							self.world.playerList[itemID]['online'] = false
							self.world.playerList[itemID]['offLineTime']=self.world.gameTime-self.world.gameRoomSetting.offlineRemoveWaitTime
						else
							if self.world.allItemList[itemID].redirectRoomTime<self.world.gameTime then
								--self:D('jaylog SNPC:directHurtCallBack actorType 0')
								self.world.allItemList[itemID].redirectRoomTime = self.world.gameTime + 5
								if self.world.gameRoomSetting['ISYW']==1 then
									self.world.allItemList[itemID]:updateEquipLose()
								end
								self.world:redirectRoom(itemID,self.toMap,self.toRoomID,nil,self.toMapX,self.toMapY)
							end
						end
					end
				end
				--传送门回调end
				if hitValue['isSafeRange']~=nil then
					-- if obj.statusList[73]==nil then
					-- 	obj:updateSyncMsg({bc={{zz=3,mid=100,i=obj.itemID}}})
					-- end
					obj:addStatusList({s=73,r=self.world.gameTime,t=0.5,i=obj.itemID,zz=3})
				end
			end
		end
	end
end

function SNPC:setDeadTime(time) 
	self.attribute.parameterArr["DEAD"]=time
end



return SNPC
