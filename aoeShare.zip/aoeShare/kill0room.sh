#!/bin/bash

echo 'start'
/home/aoeShare/sync.sh
ps aux |grep main | grep ' 0 '
ps aux |grep main | grep ' 0 ' |awk '{print "kill -9 "$2}' | sh
echo 'end'
ps aux |grep main | grep ' 0 '
