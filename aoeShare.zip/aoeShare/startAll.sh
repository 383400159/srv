#!/bin/bash
#cd /home/aoeShare/
folder=`ls -1 /var/ |grep 'aoe' |grep -v 'aoe_test'`

date
for name in ${folder}
do
echo "test:"$name
#ls -1 *.lua | awk -v var=$name '{ print "luajit -bg " $1 " /var/"var"/gameroom/" $1 } ' | sh
echo /var/$name/MasterGame.sh
/var/$name/MasterGame.sh
done

date
chown feng.staff /home/aoeShare/*
chmod 770 /home/aoeShare/*
chown feng.staff /var/aoe*/gameroom/*
chmod 770 /var/aoe*/gameroom/*

date
#if [ "$1"="nokill" ];then
#echo nokill
#else
#ps aux |grep 'main 3' | grep -v grep | awk '{print "kill -9 "$2 }'|sh
#fi
#date
