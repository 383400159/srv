#!/bin/bash

ps aux |grep 'main 30' |awk '{if(($12>3000 && $12<3019) || ($12>3070 && $12<3099)) print "kill "$2}' | sh
