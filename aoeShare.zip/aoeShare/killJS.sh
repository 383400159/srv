#!/bin/bash

ps aux |grep 'main 282' |grep -v grep | awk '{print "kill "$2}'|sh
ps aux |grep 'main 283' |grep -v grep | awk '{print "kill "$2}'|sh

/var/aoe_js/MasterGame.sh
