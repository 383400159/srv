#!/bin/bash

#/home/aoeShare/sync.sh

ps aux |grep 3001 |grep "main" |awk '{print "sudo kill "$2}' |sh

sleep 1

sudo /var/aoe_w5test/MasterGame.sh
