
local SEnergyBoard = class("SEnergyBoard")


function SEnergyBoard:ctor(parent,ids)
	self.energyBoardList = {}
	self.gameTime = 0
	if parent==nil then return end
	self.parent = parent
	self.world = parent.world

	self.offsetItemID = self.parent.itemID * 1000000
	self.parent:D("fenglog 猫女 offsetItemID:",self.offsetItemID)
	if ids==nil or table.nums(ids)==0 then return end
	self:__load(ids)
end	

--加载db数据
function SEnergyBoard:__load(ids)
	local data = {}
	for k,v in pairs(ids) do
		self:__assignAttribute(k,v['parameter'],v['angelKey'],v['parameter']['CDTIME'],parameterextra,v['angelID'])
	end
end

--- reload 圣靈數據
-- @param ids table - playerList[itemID]['playerJson']['energyData']
-- @return nil
function SEnergyBoard:reload(ids)
	local list = {}
	for k,v in pairs(ids) do
		if list[""..k]~=nil then
			self.energyBoardList[""..k].parameter = v['parameter']
			self.energyBoardList[""..k].CDTIME = v['parameter']['CDTIME']
		else
			self:__assignAttribute(k,v['parameter'],v['angelKey'],v['parameter']['CDTIME'],parameterextra,v['angelID'])
		end
		list[""..k] = 1
	end
	for k,v in pairs(self.energyBoardList) do
		local newID = 1+500+(self.parent.world.tonumber(k)-1)*2
		if list[""..k]==nil then
			self.parent:removeStatusList(newID)
			self.energyBoardList[k] = nil
		end
	end
end


--加载喵女list
function SEnergyBoard:__assignAttribute(id,parameter,parametername,CDTIME,parameterextra,parameterid)
	if parameterextra==nil then parameterextra={} end
	self.energyBoardList[""..id]={name=parametername,parameter=parameter,parameterextra=parameterextra,lastUpdateTime=0,CDTIME=CDTIME,eid=parameterid}
end

function SEnergyBoard:updateStatus()
	for k,v in pairs(self.energyBoardList) do
		local newID = 1+500+(self.parent.world.tonumber(k)-1)*2
		if self.parent.statusList[newID]==nil then
			local d = 0
			if self.parent.world.gameTime<5 then
				d = 0.5
			end
			self.parent:D("fenglog 触发猫女2 lastUpdateTime:",v['lastUpdateTime']," CDTIME:",v['CDTIME']," gameTime:",self.parent.world.gameTime)
			if v['lastUpdateTime']==0 or v['lastUpdateTime']+v['CDTIME']<=self.parent.world.gameTime then
				self.parent:D("fenglog 触发猫女2 k:",(newID)," 已经cd好了")
				self.parent:addStatusList({s=newID,r=self.parent.world.gameTime,t=9999,i=self.parent.itemID,p1=1},d)
			else
				self.parent:D("fenglog 触发猫女2 k:",(newID)," 已经cd中")
				self.parent:addStatusList({s=newID,r=self.parent.world.gameTime,t=v['CDTIME']-(self.parent.world.gameTime-v['lastUpdateTime']),i=self.parent.itemID,p1=2,p2=v['lastUpdateTime']},d)
			end
		end
	end
end

function SEnergyBoard:run(name,extrPara)
	self.parent:D("fenglog 触发猫女 name:",name)
	if extrPara==nil then extrPara = {} end
	if self.parent==nil or table.nums(self.energyBoardList)==0 then return 0 end
	self.parent:D("fenglog 触发猫女1 energyBoardList:",self.world.cjson.encode(self.energyBoardList))
	local matchEB = {}
	self.gameTime = self.parent.world.gameTime
	--赛选足够条件的
	for k,v in pairs(self.energyBoardList) do
		if v['name']==name and (v['lastUpdateTime']==0 or v['lastUpdateTime']+v['CDTIME']<self.gameTime) then
			matchEB[#matchEB+1] = k
		end
	end
	local ret = 0
	for x,k in pairs(matchEB) do
		if name=="TRIGGERLOWER_HP" then
			print("触发猫女2 matchEB:",self.world.cjson.encode(matchEB))
			ret = ret + self:_TRIGGERLOWER_HP(k,self.energyBoardList[k],extrPara)
		end
		
		if name=="BITE" then
			ret = ret + self:_BITE(k,self.energyBoardList[k],extrPara)
		end

		if name=="IRON" then
			ret = ret + self:_IRON(k,self.energyBoardList[k],extrPara)
		end
	end
	return ret
end

function SEnergyBoard:_TRIGGERLOWER_HP(key,energyBoard,extrPara)
	--self.parent:D("fenglog 触发猫女 _TRIGGERLOWER_HP1")
	if self.parent.statusList[501]~=nil and (self.parent.statusList[501]['p1']==nil or self.parent.statusList[501]['p1']=="") then
		--self.parent:D("fenglog 触发猫女 _TRIGGERLOWER_HP2")
	else 
		--self.parent:D("fenglog 触发猫女 _TRIGGERLOWER_HP3")
		--能源板计算
		if extrPara["HP"]/extrPara["MaxHP"]<energyBoard['parameter']['TRIGGERLOWERHP']*0.01  then
			self.parent:D("fenglog 触发猫女2 _TRIGGERLOWER_HP3 触发不死")
			self.energyBoardList[key]['lastUpdateTime'] = self.world.gameTime + energyBoard['parameter']['BUFFTIME']
			self.parent:removeStatusList(501)
			self.parent:addStatusList({s=501,r=self.world.gameTime,t=energyBoard['parameter']['BUFFTIME'],i=self.parent.itemID,p1=3})
			self.parent:addStatusList({s=502,r=self.world.gameTime,t=energyBoard['parameter']['BUFFTIME'],i=self.parent.itemID})
			local attributes = {}
			--self.parent:D("fenglog 触发猫女 energyBoard:"..self.world.cjson.encode(energyBoard))
			attributes['NODEAD_RATE'] = energyBoard['parameter']['NODEAD_RATE']
			attributes['BUFFTIME'] = energyBoard['parameter']['BUFFTIME']
			local bufftime = energyBoard['parameter']['BUFFTIME']
			--self.parent:D("fenglog 触发猫女 attributes:"..self.world.cjson.encode(attributes))
			local buff = require("gameroomcore.SBuff").new(self.world,501+self.offsetItemID,attributes,bufftime,{},0,self.parent.itemID,self.parent.itemID,0)
			self.parent:addBuff(buff)
			--self.parent:D("fenglog 猫女不死  添加时间:"..self.world.gameTime.." BUFFTIME:"..bufftime)
		end
	end

	ret = 0
	return ret

end

--反噬
function SEnergyBoard:_BITE(key,energyBoard,extrPara)

	if self.parent.statusList[503]~=nil and (self.parent.statusList[503]['p1']==nil or self.parent.statusList[503]['p1']=="") then
	
	else 

		local rand = self.world.formula:getRandnum(1,100)
		if rand<energyBoard['parameter']['BITE_RATE'] then
			self.parent:D("fenglog 触发猫女2 _BITE 触发反噬")
			self.energyBoardList[key]['lastUpdateTime'] = self.world.gameTime + energyBoard['parameter']['BUFFTIME']
			self.parent:removeStatusList(503)
			self.parent:addStatusList({s=503,r=self.world.gameTime,t=energyBoard['parameter']['BUFFTIME'],i=self.parent.itemID,p1=3})
			self.parent:addStatusList({s=504,r=self.world.gameTime,t=energyBoard['parameter']['BUFFTIME'],i=self.parent.itemID})
			local attributes = {}
			attributes['REBOUND_UPFIX'] = energyBoard['parameter']['REBOUNSD_BITEHURT']
			attributes['REBOUND_UPFIX_RATE'] = 100
			local bufftime = energyBoard['parameter']['BUFFTIME']
			local buff = require("gameroomcore.SBuff").new(self.world,503+self.offsetItemID,attributes,bufftime,{},0,self.parent.itemID,self.parent.itemID,0)
			self.parent:addBuff(buff)
		end
	end

	ret = 0
	return ret

end

--铁卫
function SEnergyBoard:_IRON(key,energyBoard,extrPara)
	if self.parent.statusList[505]~=nil and (self.parent.statusList[505]['p1']==nil or self.parent.statusList[505]['p1']=="") then
	
	else 

		local rand = self.world.formula:getRandnum(1,100)
		if rand<energyBoard['parameter']['IRON_RATE'] then
			self.parent:D("fenglog 触发猫女2 _IRON 触发铁卫")
			self.energyBoardList[key]['lastUpdateTime'] = self.world.gameTime + energyBoard['parameter']['BUFFTIME']
			self.parent:removeStatusList(505)
			self.parent:addStatusList({s=505,r=self.world.gameTime,t=energyBoard['parameter']['BUFFTIME'],i=self.parent.itemID,p1=3})
			self.parent:addStatusList({s=506,r=self.world.gameTime,t=energyBoard['parameter']['BUFFTIME'],i=self.parent.itemID})
			local attributes = {}
			attributes['IMMUNEAD_RATE'] = energyBoard['parameter']['IMMUNEAD_RATE']
			attributes['BUFFTIME'] = energyBoard['parameter']['BUFFTIME']
			local bufftime = energyBoard['parameter']['BUFFTIME']
			local buff = require("gameroomcore.SBuff").new(self.world,505+self.offsetItemID,attributes,bufftime,{},0,self.parent.itemID,self.parent.itemID,0)
			self.parent:addBuff(buff)
		end
	end

	ret = 0
	return ret

end



-- function SEnergyBoard:_BONUS(key,energyBoard,parameter)
-- 	-- print("_BONUS",self.world.cjson.encode(parameter))
-- 	-- print("_BONUS statusList",self.world.cjson.encode(self.parent.statusList))
-- 	-- print("_BONUS energyBoard",self.world.cjson.encode(energyBoard))
-- 	if self.parent.statusList[801]~=nil and (self.parent.statusList[801]['p1']==nil or self.parent.statusList[801]['p1']=="") then
-- 		return energyBoard['BONUS']
-- 	elseif parameter['check']==1 then
-- 		local rate = math.random(0,99)
-- 		if energyBoard['RATE']>rate and (self.parent.statusList[801]==nil or (self.parent.statusList[801]['p1']~=nil and self.parent.statusList[801]['p1']==1)) then
-- 			self.parent:removeStatusList(801)
-- 			self.energyBoardList[key]['lastUpdateTime'] = self.gameTime + energyBoard['BUFFTIME']
-- 			self.parent:addStatusList({s=801,r=self.gameTime,t=energyBoard['BUFFTIME'],i=self.parent.itemID})
-- 			return energyBoard['BONUS']
-- 		end
-- 	end
-- 	return 0
-- end

-- function SEnergyBoard:_HEALINGITEM(key,energyBoard,parameter)
-- 	self.energyBoardList[key]['lastUpdateTime'] = self.gameTime
-- 	self.parent:removeStatusList(802)
-- 	self.parent:addStatusList({s=802,r=self.gameTime,t=parameter['time'],i=self.parent.itemID})
-- 	return energyBoard['HEALINGITEM']
-- end

-- function SEnergyBoard:_REHPMAX(key,energyBoard,parameter)
-- 	if self.parent.statusList[803]~=nil and (self.parent.statusList[803]['p1']==nil or self.parent.statusList[803]['p1']=="") then
-- 		return energyBoard['REHPMAX']
-- 	else
-- 		if parameter['check']==1 and (self.parent.statusList[803]==nil or (self.parent.statusList[803]['p1']~=nil and self.parent.statusList[803]['p1']==1)) then
-- 			self.parent:removeStatusList(803)
-- 			self.energyBoardList[key]['lastUpdateTime'] = self.gameTime + energyBoard['BUFFTIME']
-- 			self.parent:addStatusList({s=803,r=self.gameTime,t=energyBoard['BUFFTIME'],i=self.parent.itemID})
-- 			return energyBoard['REHPMAX']
-- 		end
-- 	end
-- 	return 0
-- end

-- function SEnergyBoard:_REHPTOWER(key,energyBoard,parameter)
-- 	if parameter['check']==0 and self.parent.statusList[804]~=nil and (self.parent.statusList[804]['p1']==nil or self.parent.statusList[804]['p1']=="") then
-- 		return energyBoard['REHPTOWER']
-- 	else
-- 		if parameter['check']==1 and (self.parent.statusList[804]==nil or (self.parent.statusList[804]['p1']~=nil and self.parent.statusList[804]['p1']==1)) then
-- 			self.parent:removeStatusList(804)
-- 			self.energyBoardList[key]['lastUpdateTime'] = self.gameTime + energyBoard['BUFFTIME']
-- 			self.parent:addStatusList({s=804,r=self.gameTime,t=energyBoard['BUFFTIME'],i=self.parent.itemID})
-- 			return energyBoard['REHPTOWER']
-- 		end
-- 		if parameter['check']==2 and (self.parent.statusList[804]==nil or (self.parent.statusList[804]['p1']~=nil and self.parent.statusList[804]['p1']==1)) then
-- 				return 1
-- 		end
-- 	end
	
-- 	return 0
-- end

-- function SEnergyBoard:_ATTACKAPADJ(key,energyBoard,parameter)

-- 	if parameter['check']==0 and  self.parent~=nil and self.parent.statusList~=nil and self.parent.statusList[805]~=nil and (self.parent.statusList[805]['p1']==nil or self.parent.statusList[805]['p1']=="") then
		
-- 		return energyBoard['ATTACKAPADJ']
-- 	else
-- 		-- print("_ATTACKAPADJ  parameter",self.parent.world.cjson.encode(parameter))
-- 		--if parameter['check']==1 and (self.parent.statusList[805]==nil or (self.parent.statusList[805]['p1']~=nil and self.parent.statusList[805]['p1']==1)) then
-- 		if parameter['check']==1 and  self.parent~=nil and self.parent.statusList~=nil and (self.parent.statusList[805]==nil or (self.parent.statusList[805]~=nil and self.parent.statusList[805]['p1']~=nil and self.parent.statusList[805]['p1']==1)) then
-- 			self.parent:removeStatusList(805)
-- 			self.energyBoardList[key]['lastUpdateTime'] = self.gameTime + energyBoard['BUFFTIME']
-- 			self.parent:addStatusList({s=805,r=self.gameTime,t=energyBoard['BUFFTIME'],i=self.parent.itemID})
			
-- 			return energyBoard['ATTACKAPADJ']
-- 		end
-- 	end

-- 	return 0
-- end

-- function SEnergyBoard:_KILLCRI(key,energyBoard,parameter)
-- 	self.energyBoardList[key]['lastUpdateTime'] = self.gameTime
-- 	local buffAttr = {}
-- 	buffAttr['CRI'] = energyBoard['KILLCRI']
-- 	local bufftime = energyBoard['KILLCRITIME']
-- 	self.parent:removeStatusList(806)
-- 	local buff = require("gameroomcore.SBuff").new(self.parent.world,806+self.parent.itemID*1000,buffAttr,bufftime,{},0,self.parent.itemID,self.parent.itemID,0)
-- 	self.parent:addBuff(buff)
-- 	return 0
-- end

-- function SEnergyBoard:_LOWHP(key,energyBoard,parameter)
-- 	if parameter['hppercent']>0 and parameter['hppercent']<=energyBoard['LOWHP'] then
-- 		self.energyBoardList[key]['lastUpdateTime'] = self.gameTime
-- 		local buffAttr = {}
-- 		buffAttr['EXTRAHP'] = energyBoard['LOWHPEXTRA']
-- 		local bufftime = energyBoard['LOWHPTIME']
-- 		self.parent:removeStatusList(807)
-- 		local buff = require("gameroomcore.SBuff").new(self.parent.world,807+self.parent.itemID*1000,buffAttr,bufftime,{},0,self.parent.itemID,self.parent.itemID,0)
-- 		self.parent:addBuff(buff)
-- 		return energyBoard['LOWHPEXTRA']
-- 	end
-- 	return 0
-- end

-- function SEnergyBoard:_GRASSHURTPERCENT(key,energyBoard,parameter)
-- 	self.energyBoardList[key]['lastUpdateTime'] = self.gameTime
-- 	local buffAttr = {}
-- 	buffAttr['HURTPERCENTBUFF'] = energyBoard['GRASSHURTPERCENT']
-- 	local bufftime = energyBoard['GRASSHURTPERCENTTIME']
-- 	self.parent:removeStatusList(808)
-- 	local buff = require("gameroomcore.SBuff").new(self.parent.world,808+self.parent.itemID*1000,buffAttr,bufftime,{},0,self.parent.itemID,self.parent.itemID,0)
-- 	self.parent:addBuff(buff)
-- 	return 0
-- end

-- function SEnergyBoard:_DEADHPEXTRA(key,energyBoard,parameter)
-- 	if self.parent.statusList[809]==nil or (self.parent.statusList[809]['p1']~=nil and self.parent.statusList[809]['p1']==1) then
-- 		self.energyBoardList[key]['lastUpdateTime'] = self.gameTime
-- 		self.parent:removeStatusList(809)
-- 		self.parent:addStatusList({s=809,r=self.gameTime,t=energyBoard['CDTIME'],i=self.parent.itemID,p1=2})
-- 		local buffAttr = {}
-- 		buffAttr['EXTRAHP'] = energyBoard['DEADHPEXTRA']
-- 		buffAttr['buffParameter'] = {}
-- 		buffAttr['buffParameter']['statusparameter'] = {p1=3}
-- 		local bufftime = energyBoard['DEADHPTIME']
-- 		local buff = require("gameroomcore.SBuff").new(self.parent.world,809+self.parent.itemID*1000,buffAttr,bufftime,{},0,self.parent.itemID,self.parent.itemID,0)
-- 		local enemy
-- 		if self.parent.teamOrig=="B" then
-- 			enemy = self.parent.world.heroTeamBList
-- 		else
-- 			enemy = self.parent.world.heroTeamAList
-- 		end
-- 		local heroes = {}
-- 		for k,v in pairs(enemy) do
-- 			if v.itemID~=self.parent.itemID and not v:isDead() then
-- 				heroes[#heroes+1] = v.itemID
-- 			end
-- 		end
-- 		if #heroes>0 then
-- 			local rand = math.random(1,#heroes)
-- 			if self.parent.world.allItemList[rand] ~=nil then
-- 				self.parent.world.allItemList[rand]:addBuff(buff)
-- 			else
-- 				print(".lua  _DEADHPEXTRA 的对象为nil")
-- 			end
-- 		end
-- 		return energyBoard['DEADHPEXTRA']
-- 	end
-- 	return 0
-- end

-- function SEnergyBoard:_DIZZYHURT(key,energyBoard,parameter)
-- 	if self.parent.statusList[810]==nil or (self.parent.statusList[810]['p1']~=nil and self.parent.statusList[810]['p1']==1) then
-- 		self.energyBoardList[key]['lastUpdateTime'] = self.gameTime + energyBoard['DIZZYHURTTIME']
-- 		local buffAttr = {}
-- 		buffAttr['HURT'] = energyBoard['DIZZYHURT']
-- 		local bufftime = energyBoard['DIZZYHURTTIME']
-- 		self.parent:removeStatusList(810)
-- 		local buff = require("gameroomcore.SBuff").new(self.parent.world,810+self.parent.itemID*1000,buffAttr,bufftime,{},0,self.parent.itemID,self.parent.itemID,0)
-- 		self.parent:addBuff(buff)
-- 	end
-- 	return 0
-- end

-- function SEnergyBoard:_REHPBUFFREMP(key,energyBoard,parameter)
-- 	if self.parent.statusList[811]==nil or (self.parent.statusList[811]['p1']~=nil and self.parent.statusList[811]['p1']==1) then
-- 		self.energyBoardList[key]['lastUpdateTime'] = self.gameTime + energyBoard['BUFFTIME']
-- 		local buffAttr = {}
-- 		buffAttr['REMP'] = self.parent.attribute.REMP * energyBoard['REHPBUFFREMP'] / 100
-- 		local bufftime = energyBoard['BUFFTIME']
-- 		self.parent:removeStatusList(811)
-- 		local buff = require("gameroomcore.SBuff").new(self.parent.world,811+self.parent.itemID*1000,buffAttr,bufftime,{},0,self.parent.itemID,self.parent.itemID,0)
-- 		self.parent:addBuff(buff)
-- 	end
-- 	return 0
-- end

-- function SEnergyBoard:_DEADDEHURT(key,energyBoard,parameter)
-- 	if self.parent.statusList[812]==nil or (self.parent.statusList[812]['p1']~=nil and self.parent.statusList[812]['p1']==1) then
-- 		self.energyBoardList[key]['lastUpdateTime'] = self.gameTime
-- 		self.parent:removeStatusList(812)
-- 		self.parent:addStatusList({s=812,r=self.gameTime,t=energyBoard['CDTIME'],i=self.parent.itemID,p1=2})
-- 		local x = self.parent.posX
-- 		local y = self.parent.posY
-- 		local attackRange = {posX=x,posY=y,radius=energyBoard['RANGE']/self.parent.world.setting.AdjustAttRange}
-- 		local atype = 1
-- 		local hitValueNew = {}
-- 		local bullet = require("gameroomcore.SBullet").new(self.parent.world,0,self.parent.itemID,0,self.parent.itemID,x,y,true)
-- 		bullet:directFightAura(atype,attackRange,hitValueNew,0,0,self.parent.itemID)
-- 		local buffAttr = {HURT=-energyBoard['DEADDEHURT']}
-- 		buffAttr['buffParameter'] = {}
-- 		buffAttr['buffParameter']['statusparameter'] = {p1=3}
-- 		local bufftime = energyBoard['DEADDEHURTTIME']
-- 		for k,v in pairs(bullet.ignoreID) do
-- 			local buff = require("gameroomcore.SBuff").new(self.parent.world,812+self.parent.itemID*1000,buffAttr,bufftime,{},0,self.parent.itemID,v,0)
-- 			self.parent.world.allItemList[v]:addBuff(buff)
-- 		end
-- 		bullet:setDead()
-- 	end
-- 	return 0
-- end

-- function SEnergyBoard:_DEFTOWER(key,energyBoard,parameter)
-- 	if self.parent.statusList[813]==nil or (self.parent.statusList[813]['p1']~=nil and self.parent.statusList[813]['p1']==1) then
-- 		if parameter['check']==2 then
-- 			return 1
-- 		elseif parameter['check']==1 then
-- 			self.energyBoardList[key]['lastUpdateTime'] = self.gameTime + energyBoard['DEFTOWERTIME']
-- 			local buffAttr = {}
-- 			buffAttr['DEF'] = energyBoard['DEFTOWER']
-- 			local bufftime = energyBoard['DEFTOWERTIME']
-- 			self.parent:removeStatusList(813)
-- 			local buff = require("gameroomcore.SBuff").new(self.parent.world,813+self.parent.itemID*1000,buffAttr,bufftime,{},0,self.parent.itemID,self.parent.itemID,0)
-- 			self.parent:addBuff(buff)
-- 			return 1
-- 		end
-- 	end
-- 	return 0
-- end

-- function SEnergyBoard:_LOWHPNOCTLDEBUFF(key,energyBoard,parameter)
-- 	if self.parent.statusList[814]==nil or (self.parent.statusList[814]['p1']~=nil and self.parent.statusList[814]['p1']==1) then
-- 		if parameter['hppercent']>0 and parameter['hppercent']<=energyBoard['LOWHPNOCTLDEBUFF'] then
-- 			self.energyBoardList[key]['lastUpdateTime'] = self.gameTime + energyBoard['LOWHPTIME']
-- 			local buffAttr = {}
-- 			local bufftime = energyBoard['LOWHPTIME']
-- 			self.parent:removeStatusList(814)
-- 			local buff = require("gameroomcore.SBuff").new(self.parent.world,814+self.parent.itemID*1000,buffAttr,bufftime,{},0,self.parent.itemID,self.parent.itemID,0)
-- 			self.parent:addBuff(buff)
-- 			return energyBoard['LOWHPTIME']
-- 		end
-- 	end
-- 	return 0
-- end

return SEnergyBoard
