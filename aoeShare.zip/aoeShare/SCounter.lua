local SCounter = class("SCounter")

function SCounter:ctor(obj)
	if self.className == nil  then
		self.className = "SCounter"
	end
	self.heroObj = obj
	self.oldCounter = {}
	self.counter = {}
	self.taskObj = obj.taskObj
	self.cacheCounter = {}	
	--self:__init()
end

function SCounter:setOldCounter(counter)
	self.oldCounter = counter
	self.counter = table.deepcopy(self.oldCounter)
end
-- function SCounter:__init()
-- 	--self.oldCounter = db:getCounter()
-- 	self.counter = table.deepcopy(self.oldCounter)
-- end

--- 取得某遊戲統計
-- @param eventKey string - 名稱
-- @return counter int - 數值
function SCounter:getCounter(eventKey)
	if self.counter[eventKey]==nil then
		return 0
	end
	return self.counter[eventKey]
end

--- 累加某遊戲統計 
-- @param eventKey string - 名稱
-- @param addValue int - 加值 預設+1
-- @return counter int - 數值
function SCounter:setCounter(eventKey,addValue)
	if addValue==nil then addValue = 1 end
	if self.counter[eventKey]==nil then self.counter[eventKey] = 0 end
	self.counter[eventKey] = self.counter[eventKey] + addValue

	--将数值导入并在任务系统中进行
	self.taskObj:execute(eventKey,addValue)

	--保存数据去db
	self:saveCacheCounter(eventKey,addValue)
end

function SCounter:saveCacheCounter(eventKey,addValue)
	self.cacheCounter[#self.cacheCounter+1]={
		eventKey=eventKey,
		addValue=addValue,
	}
	self.heroObj:D("SCounter:saveCounter eventKey",eventKey," addValue:",addValue)
end

function SCounter:getCacheCounter()
	local ret = table.deepcopy(self.cacheCounter)
	return ret
end

function SCounter:deleteCacheCounter()
	self.cacheCounter={}
end

function SCounter:getAllCounter()
	-- body
	return self.counter
end


function SCounter:setMemcache()
	self.heroObj.world:memcacheLocalSet(string.base64encode("counter_"..self.heroObj.world.playerList[self.heroObj.itemID]['id']),self.heroObj.world.cjson.encode(self.counter))
end


function SCounter:getMemcache()
	self.oldCounter = self.heroObj.world.cjson.decode(self.heroObj.world:memcacheLocalGet(string.base64encode("counter_"..self.heroObj.world.playerList[self.heroObj.itemID]['id'])))
	self:setOldCounter(self.oldCounter)
end


return SCounter