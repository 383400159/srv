#!/bin/bash
cd /home/aoeShare/
ls -1 *.lua | awk '{ print "luajit -bg " $1 " /var/aoe_yw/gameroom/" $1 } ' | sh
ls -1 */*.lua | awk '{ print "luajit -bg " $1 " /var/aoe_yw/gameroom/" $1 } ' | sh

cd /var/aoe_yw/
echo aoe_yw$1
./kill.sh $1
