local Transfer = class("Transfer")

function Transfer:ctor(world)
	if self.className==nil then
		self.className = 'Transfer'
	end
	--debuglog('jaylog in transfer ctor')
	self.world = world
	self.mapDoor = {}
	self.stackArr = {}
	self.pathArr = {}
	self.relationArr = {}
	self:_load()
end

function Transfer:_load()
	if self.world.gameRoomSetting['ISYW']==0 then
		return nil
	end
	local sql = "select * from transfer"
	local data = self.world:getDBData(sql)
	local mapTransfer = {}
	local relation = {}
	for k,v in pairs(data) do
		if mapTransfer[""..v['mapID1']]==nil then
			mapTransfer[""..v['mapID1']] = {}
		end
		if mapTransfer[""..v['mapID1']][""..v['mapID2']]==nil then
			mapTransfer[""..v['mapID1']][""..v['mapID2']] = {}
		end
		--mapTransfer[v['mapID1']][#mapTransfer[v['mapID1']]+1] = {
		mapTransfer[""..v['mapID1']][""..v['mapID2']] = {
			X=v['x1'],
			Y=v['y1'],
			toMap=v['mapID2'],
			toX=v['x2'],
			toY=v['y2'],
			tranWidth=v['tranWidth'],
			safeWidth=v['safeWidth'],
			safeRadian=v['safeRadian'],
			safeRadian1=v['safeRadian1'],
			safeNum=v['safeNum'],
		}
		if relation[""..v['mapID1']]==nil then
			relation[""..v['mapID1']] = {}
		end
		relation[""..v['mapID1']][#relation[""..v['mapID1']]+1] = ""..v['mapID2']
	end
	self.mapDoor = table.deepcopy(mapTransfer)
	self.relationArr = table.deepcopy(relation)
	self.world:D('jaylog Transfer:_load',self.world.cjson.encode(mapTransfer),self.world.cjson.encode(relation))
end

function Transfer:getMapDoor(map)
	if self.mapDoor[""..map]==nil then
		return {}
	else
		return self.mapDoor[""..map]
	end
end

function Transfer:inMapDoor(circle,map)
	local mapPoint = self:getMapDoor(map)
	for k,v in pairs(mapPoint) do
		if self.world.map:containPoint(circle,x,y) then
			return true
		end
	end
	return false
end

function Transfer:getMapPath(mapID1,mapID2,lastMapID,num)
	local mapDoor = self:getMapDoor(mapID1)
	--print(mapID1,mapID2,lastMapID,num)
	if self.world.tonumber(mapID1)==self.world.tonumber(mapID2) then
		--print('return:',mapID2)
		return mapID2,num
	end
	local preStr = ''
	local preNum = 0
	local tmpStr = ''
	local tmpNum = 0
	for k,v in pairs(mapDoor) do
		--print('jaylog in mapDoor:',self.world.cjson.encode(mapDoor))
		--if string.find(preStr,v)==nil then
		if self.world.tonumber(k)==self.world.tonumber(mapID2) then
			return mapID1..'-'..mapID2, preNum
		end
		if self.world.tonumber(k)~=self.world.tonumber(lastMapID) then
			--print('jaylog inarr:',mapID1,mapID2,num,k,tmpStr)
			tmpStr,tmpNum = self:getMapPath(k,mapID2,mapID1,num+1)
			if ( preNum==0 or preNum>tmpNum) then
				preNum = tmpNum
				preStr = tmpStr
			end
		end
	end
	self.world:D('jaylog getMapPath:',mapID1 ..'-'.. preStr, preNum)
	return mapID1 ..'-'.. preStr, preNum
end

function Transfer:getRelationNodes(mapID,i)
	--self.world:D('jaylog Transfer:getRelationNodes ',mapID,i,self.world.cjson.encode(self.relationArr[""..mapID]))
	if self.relationArr[""..mapID]~=nil then
		return self.relationArr[""..mapID][i]
	else
		return nil
	end
end

function Transfer:isNodeInStack(mapID)
	for k,v in pairs(self.stackArr) do
		if self.world.tonumber(v)==self.world.tonumber(mapID) then
			return true
		end
	end
	return false
end

function Transfer:savePath()
	if not empty(self.stackArr) then
		local stackStr = ''
		--self.world:D('jaylog Transfer:savePath ',self.world.cjson.encode(self.stackArr))
		for k,v in pairs(self.stackArr) do
			if stackStr=='' then
				stackStr = v
			else
				stackStr = stackStr..'-'..v
			end
		end
		self.pathArr[#self.pathArr+1] = stackStr
	end
end

function Transfer:getPaths(curNode,preNode,startNode,endNode)
	local nNode
	--self.world:D('jaylog Transfer:getPaths ',curNode,preNode,startNode,endNode)
	if curNode~=nil and curNode~=0 and preNode~=nil and preNode~=0 and tonumber(curNode)==tonumber(preNode) then
		--self.world:D('jaylog zero')
		return false
	end
	if curNode~=nil and curNode~=0 then
		local i = 1
		self.stackArr[#self.stackArr+1] = curNode
		--self.world:D('jaylog Transfer:getPaths stackArr:',self.world.cjson.encode(self.stackArr))
		if tonumber(curNode)==tonumber(endNode) then
			--self.world:D('jaylog one')
			self:savePath()
			return true
		else
			nNode = self:getRelationNodes(curNode,i)
			--self.world:D('jaylog two ',nNode,curNode,i)
			while(nNode~=nil and nNode~=0)
			do
				--self.world:D('jaylog three')
				local goOn = true
				if preNode~=nil and preNode~=0 and (tonumber(nNode)==tonumber(startNode) or tonumber(nNode)==tonumber(preNode) or self:isNodeInStack(nNode)) then
					i = i + 1
					if i>=#self.relationArr[""..curNode]+1 then
						--self.world:D('jaylog four')
						nNode = 0
					else
						--self.world:D('jaylog five')
						nNode = self:getRelationNodes(curNode,i)
					end
					goOn = false
				end
				--self.world:D('jaylog fiveAfter ',nNode,curNode,startNode,endNode)
				if goOn and self:getPaths(nNode,curNode,startNode,endNode) then
					--self.world:D('jaylog six')
					self.stackArr[#self.stackArr] = nil
				end
				if goOn then
					i = i + 1
				end
				--self.world:D('jaylog sixAfter ',self.world.cjson.encode(goOn),i)
				if goOn then
					--self.world:D('jaylog seven pre ',i,curNode,self.world.cjson.encode(self.relationArr))
					if i>=#self.relationArr[""..curNode]+1 then
						--self.world:D('jaylog seven')
						nNode = 0
					else
						--self.world:D('jaylog eight')
						nNode = self:getRelationNodes(curNode,i)
					end
				end
			end
			--self.world:D('jaylog nine ',self.world.cjson.encode(self.stackArr),' cnt:',#self.stackArr)
			self.stackArr[#self.stackArr] = nil
			return false
		end
	else
		return false
	end
end

function Transfer:getMapPathDetail(mapID1,mapID2,X,Y,toX,toY,itemID)
	--local pathStr,pathNum = self:getMapPath(mapID1,mapID2,mapID1,1)
	self.stackArr = {}
	self.pathArr = {}
	self:getPaths(mapID1,0,mapID1,mapID2)
	local pathStr = ''
	for k,v in pairs(self.pathArr) do
		if self.world.sLen(v)<self.world.sLen(pathStr) or pathStr=='' then
			pathStr = v
		end
	end
	self.world:D('jaylog pathStr:',pathStr,self.world.cjson.encode(self.pathArr))
	local path = string.split(pathStr,'-')
	self.world:D('jaylog Transfer:getMapPathDetail path '..self.world.cjson.encode(path))
	local pathPoint = {}
	for i=1,#path do
		if i~=#path then
			local mapDoor = self:getMapDoor(path[i])
			self.world:D('jaylog pathPoint:path ',i,' ',path[i],' ',path[i+1])
			pathPoint[path[i]] = {toX=mapDoor[path[i+1]]['X'],toY=mapDoor[path[i+1]]['Y']}
		else
			pathPoint[path[#path]] = {toX=toX,toY=toY,isLast=1}
		end
	end
	self.world.allItemList[itemID].movePath = table.deepcopy(pathPoint)
	self.world:D('jaylog Transfer:getMapPathDetail pathPoint '..self.world.cjson.encode(pathPoint))
	return pathPoint
end

--保存自动寻路Cache
function Transfer:savePathCache(itemID)
	local loginid = self.world.playerList[itemID]['id']
	local playerID = self.world.playerList[itemID]['p']
	self.world:D('jaylog Transfer:savePathCache ','movePath'..playerID,string.base64encode(loginid))
	self.world:memcacheLocalSet('movePath'..playerID,self.world.cjson.encode(self.world.allItemList[itemID].movePath))
end

--保存自动寻路Cache
function Transfer:getPathCache(itemID)
	local loginid = self.world.playerList[itemID]['id']
	local playerID = self.world.playerList[itemID]['p']
	local pathStr = self.world:memcacheLocalGet('movePath'..playerID,string.base64encode(loginid))
	self.world:D('jaylog Transfer:getPathCache ','movePath'..playerID,pathStr)
	self.world.allItemList[itemID].movePath = self.world.cjson.decode(pathStr)
end

return Transfer
