#!/bin/bash
cd /home/aoeShare/
ls -1 *.lua | awk '{ print "luajit -bg " $1 " /var/aoe_gvb/gameroom/" $1 } ' | sh
ls -1 */*.lua | awk '{ print "luajit -bg " $1 " /var/aoe_gvb/gameroom/" $1 } ' | sh

cd /var/aoe_gvb/
./kill.sh $1
