local SEquipCounter = class("SEquipCounter")

function SEquipCounter:ctor(obj)
	if self.className == nil  then
		self.className = "SEquipCounter"
	end
	self.heroObj = obj
	self.counter = {}
	self.syncCounter = {}
end

--- 取得某遊戲統計
-- @param eventKey string - 名稱
-- @return counter int - 數值
function SEquipCounter:getCounter(eventKey)
	if self.counter[eventKey]==nil then
		return 0
	end
	return self.counter[eventKey]
end

--- 累加某遊戲統計 
-- @param eventKey string - 名稱
-- @param addValue int - 加值 預設+1
-- @return counter int - 數值
function SEquipCounter:setCounter(eventKey,addValue)
	if addValue==nil then addValue = 1 end
	if self.counter[eventKey]==nil then self.counter[eventKey] = 0 end
	self.counter[eventKey] = self.counter[eventKey] + addValue
end

--- 获取用于传给接口的syncCounter
-- @param null
-- @return syncCounter table - syncCounter数据
function SEquipCounter:getSyncCounter()
	self.syncCounter = {}
	for k,v in pairs(self.counter) do
		self.syncCounter[k] = v
	end
	return self.syncCounter
end

--- 获取counter
-- @param null
-- @return counter table - counter数据
function SEquipCounter:getAllCounter()
	return self.counter
end


function SEquipCounter:setMemcache()
	self.heroObj.world:memcacheLocalSet("equipCounter_"..self.heroObj.world.playerList[self.heroObj.itemID]['p'],self.heroObj.world.cjson.encode(self.counter))
end

function SEquipCounter:getMemcache()
	self.oldCounter = self.heroObj.world.cjson.decode(self.heroObj.world:memcacheLocalGet("equipCounter_"..self.heroObj.world.playerList[self.heroObj.itemID]['p']))
	self:setOldCounter(self.oldCounter)
end

--- 重置counter
-- @param null
-- @return null
function SEquipCounter:resetCounter()
	for k,v in pairs(self.counter) do
		self.counter[k] = 0
	end
end

--- 检测是否有counter数
-- @param null
-- @return null
function SEquipCounter:existCounter()
	for k,v in pairs(self.counter) do
		if v>0 then
			return true
		end
	end
	return false
end

--- 刷新equipCounter内容,用于跳房刷新数据
-- @param equipCounter table - 新的counter列表
-- @return null
function  SEquipCounter:refreshList(equipCounter)
	if equipCounter==nil then
		equipCounter = {}
	end
	if not empty(equipCounter) then
		self:resetCounter()
		for k,v in pairs(equipCounter) do
			self.counter[k] = v
		end
	end
end

return SEquipCounter