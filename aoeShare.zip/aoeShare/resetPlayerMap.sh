#!/bin/bash

echo "update player_status set X=0,Y=0" | mysql aoe
/home/aoeShare/cleanMemcache-skill-aoe.sh
