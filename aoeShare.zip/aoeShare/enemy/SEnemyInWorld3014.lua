local SEnemyInWorld3014 = class("SEnemyInWorld3014", require("gameroomcore.SHeroBase"))

function SEnemyInWorld3014:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld3014.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end


return SEnemyInWorld3014
