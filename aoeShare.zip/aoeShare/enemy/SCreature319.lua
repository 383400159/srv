local SCreature319 = class("SCreature319", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature319:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature319" 
	end 

	SCreature319.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end 

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SCreature319:prepareHit(mode,adjTime,buff)  
	if mode==2 then
		local skill = self.attribute.skills[2] 
		local parameters = skill.parameters 
		self:addStatusList({s=96,r=self.world.gameTime,t=99999,i=self.itemID},skill.hitTime)
	end
	local hitValueBoth=SCreature319.super.prepareHit(self,mode,adjTime,buff) 
	return hitValueBoth 
end 

--- 准备攻击前置设置，在prepareHit之后执行，call父类
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SCreature319:prepareSkillAttackCustom(mode,target,x,y,adjTime,syncMsg)  
	SCreature319.super.prepareSkillAttackCustom(self,mode,target,x,y,adjTime,syncMsg)  
end 
--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SCreature319:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	debuglog("野猪撞人:"..itemID.." "..mode)
	if mode==3 then
		self:removeStatusList(96)
		self:removeBUff("MSPD")
	end
	local ret = SCreature319.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	if ret>0 and mode==3 then
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 
		
		local toX,toY = self.world.map:getXYLength(self.posX,self.posY,obj.posX,obj.posY,parameters.BACKWARD/self.world.setting.AdjustAttRange)
		ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
		obj:moveTo(toX,toY,false,5,parameters.BACKWARDSPEED,0) 	
	end
	return ret 
end 

return SCreature319 