local SCreature754 = class("SCreature754", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature754:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature754" 
	end 
	debuglog("SCreature754:ctor")
	SCreature754.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end 


function SCreature754:fight() 
	SCreature754.super.fight(self)
	
	if self.attribute.MaxHP==self.attribute.HP then
		local r = 1000/self.world.setting.AdjustAttRange
		toX,toY = self.world.map:getXYLength(self.initX,self.initY,341.7/2,408.3/2,r) 
		local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.initX,self.initY,self.initX+toX,self.initY+toY) 
		--self:skillAttack(1,1)
		--debuglog("原地攻击.......")
		self:skillAttack(1,0,toX,toY)

	end
end


return SCreature754