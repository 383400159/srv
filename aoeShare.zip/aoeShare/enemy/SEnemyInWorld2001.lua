local SEnemyInWorld2001 = class("SEnemyInWorld2001", require("gameroomcore.SHeroBase"))

function SEnemyInWorld2001:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld2001.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.sharedID = 0
	self.sharedproHP = 1
end


--- 角色死亡,call 父类
function SEnemyInWorld2001:goToDead(itemID,mode,adjTime,bonus)  
	SEnemyInWorld2001.super.goToDead(self,itemID,mode,adjTime,bonus) 
end 

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SEnemyInWorld2001:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SEnemyInWorld2001.super.prepareHit(self,mode,adjTime,buff) 
	return hitValueBoth 
end 


--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SEnemyInWorld2001:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	ret = SEnemyInWorld2001.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	return ret 
end

--- 准备攻击前置设置，在prepareHit之前执行，call父类
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SEnemyInWorld2001:prepareSkillAttackCustom(mode,target,x,y,adjTime,syncMsg)  
	SEnemyInWorld2001.super.prepareSkillAttackCustom(self,mode,target,x,y,adjTime,syncMsg)  
end 

--- 受傷害計算,调用SActor的hurted
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SEnemyInWorld2001:hurted(itemID,bulletID,mode,hitValue,adjTime)

	local hurt = SEnemyInWorld2001.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
		--共享生命	
	-- if self.sharedID>0 then
	-- 	local obj = self.world.allItemList[self.sharedID] 
	-- 	obj:adjHP(-hurt*self.sharedproHP)
	-- end
	return hurt
end


--设置共享生命id 
-- function SEnemyInWorld2001:setShared(id,hppro)
-- 	if hppro==nil then hppro=1 end
-- 	self.sharedID = id
-- 	self.sharedproHP = hppro
-- end



--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SEnemyInWorld2001:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	local hurt = SEnemyInWorld2001.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
end

return SEnemyInWorld2001