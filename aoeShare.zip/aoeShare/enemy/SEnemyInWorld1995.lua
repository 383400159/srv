local SEnemyInWorld1995 = class("SEnemyInWorld1995", require("gameroomcore.SHeroBase"))

function SEnemyInWorld1995:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld1995.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end


return SEnemyInWorld1995
