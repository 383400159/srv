local SCreature503 = class("SCreature503", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature503:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature503" 
	end 

	SCreature503.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end 



function SCreature503:createInit()

	local skill = self.attribute.skills[2] 
	local parameters = skill.parameters 

	local lifeTime=0.5
	local attributes = {}
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['INEVITABLEHIT'] = 1
	attributes['buffParameter']['RANGE'] = skill.atkDis
	--attributes['buffParameter']['INEVITABLEHIT'] = 1
	attributes['buffParameter']['creatureDirectHurCallBack'] = self.itemID
	attributes['buffParameter']['buffIntervalTime'] = 0.3
	attributes['buffParameter']['buffType'] = 4
	attributes['buffParameter']['Effect'] = -1

	for k,v in pairs(parameters) do
		attributes['buffParameter'][k]=v
	end

	attributes['BUFFTIME'] = 0.5
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0),attributes,lifeTime,{99},0,self.itemID,self.itemID,0)
	--buff.debug = true
	self:addBuff(buff)

end

return SCreature503