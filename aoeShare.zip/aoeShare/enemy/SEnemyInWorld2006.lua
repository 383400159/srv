local SEnemyInWorld2006 = class("SEnemyInWorld2006", require("gameroomcore.SHeroBase"))

function SEnemyInWorld2006:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld2006.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end


return SEnemyInWorld2006
