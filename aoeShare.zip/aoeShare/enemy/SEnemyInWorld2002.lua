local SEnemyInWorld2002 = class("SEnemyInWorld2002", require("gameroomcore.SHeroBase"))

function SEnemyInWorld2002:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld2002.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end

return SEnemyInWorld2002