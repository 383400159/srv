local SCreature290 = class("SCreature290", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature290:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature290" 
	end 

	SCreature290.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)	
end 


function SCreature290:createInit()
 	debuglog("创建290.........")
	-- local skill = self.attribute.skills[5] 
	-- local parameters = skill.parameters 
	local skill = self.attribute.skills[2] 
	local parameters = skill.parameters 

	local lifeTime=999999
	local attributes = {}
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['INEVITABLEHIT'] = 1
	attributes['buffParameter']['RANGE'] =skill.atkDis
	-- attributes['buffParameter']['RANGE']=1000
	attributes['buffParameter']['FIXHURT'] =  7
	attributes['buffParameter']['CLEANTARGETSTATUS'] = parameters.CLEANTARGETSTATUS
	attributes['buffParameter']['buffIntervalTime'] = 0.3
	attributes['buffParameter']['buffType'] = 1
	attributes['buffParameter']['Effect'] = -1
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(1),attributes,lifeTime,{99},0,self.itemID,self.itemID,0)
	--buff.debug = true
	self:addBuff(buff)
end



return SCreature290 
