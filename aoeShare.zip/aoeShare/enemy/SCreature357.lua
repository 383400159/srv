local SCreature357 = class("SCreature357", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature357:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature357" 
	end 

	SCreature357.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.isNum = 0
end 


function SCreature357:move() 
	SCreature357.super.move(self)
end




return SCreature357 