local SCreature802 = class("SCreature802", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature802:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature802" 
	end 

	SCreature802.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.skillAType = 1
	self.nextSkillID = 0 
	self.moveMaxDis = 0
	self.moveMinDis = 0
	self.followDis = 0
	self.atkID = 0
	--切换宠物左右位置时间
	self.autoMoveType = 1
	self.autoMoveTypeTime = 0
end 

--- 自动移动chud
-- @return null
function SCreature802:_autoMove()

	if not self.autoBlocked and self.AIlastMoveTime < self.world:getGameTime() and  not self:isDead()  and self.statusList[4007]==nil then
		local moveMaxDis = self.moveMaxDis
		if self.atkID==0 then
			moveMaxDis = self.followDis
		end
		--每隔一段时间切换主人的左右边
		if self.autoMoveTypeTime<self.world:getGameTime() then
			self.autoMoveTypeTime = self.world:getGameTime() + 180
			if self.autoMoveType==1 then
				self.autoMoveType=2
			else
				self.autoMoveType=1
			end
		end

		local ret = self.autoFightAI:autoMoveToFollowed(moveMaxDis,self.moveMinDis,self.autoMoveType)
		if ret then
			self.atkID = 0
			self.world:D("弓箭手BB 脱离重设:"..self.parent.itemID,self.world:getGameTime())
		end	
	end


end

--- 自动释放技能 
-- @return null
function SCreature802:_autoFight()
	self.world:D("弓箭手BB 开启runAI0:"..self.parent.itemID)
	if  self.autoFightAI.runAI then
		self.world:D("弓箭手BB 开启runAI:"..self.parent.itemID,self.parent.lastHurtAllID,self.parent.lastHurtAllTime,self.parent.lastAttackID,self.parent.lastAttackTime,self.parent.BBTAGID,self.parent.BBTAGNEXTTIME,self.world:getGameTime())
		--设置bb攻击itemID
		--被打保护
		if self.parent.lastHurtAllID~=nil and self.parent.lastHurtAllID>0 and (self.parent.lastHurtAllTime+10)>self.world:getGameTime() then
			self.world:D("弓箭手BB 开启runAI2:"..self.parent.itemID)
			local obj = self.world.allItemList[self.parent.lastHurtAllID] 
			if obj~=nil and not obj:isDead() and obj.attribute.HP>0 then
				if obj.attribute.parameterArr['NOBEFIGHT']==nil then
					self.atkID = self.parent.lastHurtAllID
				else
					if obj.parent~=nil then
						self.atkID = obj.parent.itemID
					end
				end
				self.world:D("弓箭手BB 主人被打保护:"..self.parent.itemID,self.parent.lastHurtAllID,self.parent.lastHurtAllTime,self.world:getGameTime(),obj.attribute.HP)
			end
			
		end		
		--攻击出战 击中人
		if self.parent.lastAttackID~=nil and self.parent.lastAttackID>0 and (self.parent.lastAttackTime+10)>self.world:getGameTime() then
			self.world:D("弓箭手BB 开启runAI3:"..self.parent.itemID)
			local obj = self.world.allItemList[self.parent.lastAttackID] 
			if obj~=nil and not obj:isDead() and obj.attribute.HP>0 then
				if obj.attribute.parameterArr['NOBEFIGHT']==nil then
					self.atkID = self.parent.lastAttackID
				else
					self.atkID = obj.parent.itemID
				end
				self.world:D("弓箭手BB 攻击出战:"..self.parent.itemID,self.parent.lastAttackID,self.parent.lastAttackTime,self.world:getGameTime(),obj.attribute.HP)
			end
		end
		--攻击出战 预攻击
		if self.parent.BBTAGID~=nil and self.parent.BBTAGID>0 and (self.parent.BBTAGNEXTTIME+10)>self.world:getGameTime() then
			self.world:D("弓箭手BB 开启runAI:4"..self.parent.itemID)
			local obj = self.world.allItemList[self.parent.BBTAGID] 
			if obj~=nil and not obj:isDead() and obj.attribute.HP>0 then
				if obj.attribute.parameterArr['NOBEFIGHT']==nil then
					self.atkID = self.parent.BBTAGID
				else
					self.atkID = obj.parent.itemID
				end
				self.world:D("弓箭手BB 攻击出战:"..self.parent.itemID,self.parent.BBTAGID,self.parent.BBTAGNEXTTIME,self.world:getGameTime(),obj.attribute.HP)
			end
		end

		--获得父类攻击的目标
		local obj = self.world.allItemList[self.atkID] 
		if self.nextSkillID~=nil and self.nextSkillID>0    then
		--if self.nextSkillID~=nil and self.nextSkillID>0 and obj~=nil and not obj:isDead() and obj.attribute.HP>0   then
			--self:clearSkillAttack() 
			self.world:D("弓箭手BB  释放技能old:"..self.parent.itemID,self.nextSkillID)
			local pre = self.prepareSkillAttackNum
			local ret = self:skillAttack(self.nextSkillID)	
			self.world:D("弓箭手BB skillAttack4:"..self.parent.itemID,pre,self.prepareSkillAttackNum,self.world.cjson.encode(ret))
			--skillAttack=
			self.world:D("弓箭手BB  释放技能:"..self.parent.itemID,self.nextSkillID)
			return 0
		end

		if obj~=nil and not obj:isDead() and obj.attribute.HP>0 then
			local d = self.parent:distance(obj.posX,obj.posY)
			--self.world:D("弓箭手BB 攻击目标:",obj.itemID,d,self.moveMaxDis,obj.attribute.HP)
			self.world:D("弓箭手BB 开启runAI5:"..self.parent.itemID)
			if d<self.moveMaxDis then
				self.world:D("弓箭手BB 攻击目标true:"..self.parent.itemID,obj.itemID,d,(self.attribute.skills[5].useDis/self.world.setting.AdjustAttRange-1),self.attribute.skills[5].lastCoolDownTime,self.world:getGameTime())
				local pre,ret
				pre = self.prepareSkillAttackNum
				local skill = self.attribute.skills[5] 
				local parameters = skill.parameters 
				if self.attribute.skills[5].lastCoolDownTime<self.world:getGameTime() and d>parameters.PETJUMPMIX/self.world.setting.AdjustAttRange and d<parameters.PETJUMPMAX/self.world.setting.AdjustAttRange then
					ret = self:skillAttack(5,obj.itemID)	
				else
					ret = self:skillAttack(self.skillAType ,obj.itemID)	
				end
				
				self.world:D("弓箭手BB skillAttack:"..self.parent.itemID,obj.itemID,pre,self.prepareSkillAttackNum,self.world.cjson.encode(ret),self.posX,self.posY,obj.posX,obj.posY)

				-- self:skillAttack(self.skillAType ,obj.itemID)	
				-- self.skillAType = 1
				if self.skillAType==3 then
					self.skillAType = 1
				else
					self.skillAType = self.skillAType + 1
				end
			end
		else
			self.atkID = 0
		end
	end
	
end
--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SCreature802:prepareHit(mode,adjTime,buff)  
	debuglog("宝宝放了什么技能:"..mode)
	local hitValueBoth=SCreature802.super.prepareHit(self,mode,adjTime,buff) 
	return hitValueBoth 
end 


--- 准备攻击前置设置，在prepareHit之后执行，call父类
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SCreature802:prepareSkillAttackCustom(mode,target,x,y,adjTime,syncMsg)  


	if (mode==5 ) then 
		--print("prepareHit 飞飞飞........ x y tox toy distance ",self.posX,toX,self.posY,toY,skill.atkDis/self.world.setting.AdjustAttRange)
		local skill = self.attribute.skills[5] 
		local parameters = skill.parameters 
		local obj = self.world.allItemList[self.atkID] 
		if obj~=nil then
			local d = self:distance(obj.posX,obj.posY)
			if d>(obj.attribute.width+self.attribute.width) then
				d = d-obj.attribute.width-self.attribute.width
			else
				d = 0
				if d>obj.attribute.width then
					d = d-obj.attribute.width
				end
				if d>self.attribute.width then
					d = d-self.attribute.width
				end

			end
			local toX,toY = self.world.map:getXYLength(self.posX,self.posY,obj.posX,obj.posY,d)
			local ret
			ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX,self.posY+toY) 
			self:D("prepareHit 飞飞飞........ x tox y toy distance ",self.posX,toX,self.posY,toY,(d/parameters.PETJUMPTIME)*self.world.setting.AdjustAttRange)
			self:moveTo(toX,toY,false,6,(d/parameters.PETJUMPTIME)*self.world.setting.AdjustAttRange,0) 

			syncMsg['a']['x'] = toX
			syncMsg['a']['y'] = toY

			local hitValueNew = self.parent:getPrepareHithitValue()
			hitValueNew['ADADJ'] = parameters.ADADJ2
			-- hitValueNew['DIZZY_RATE'] = 100
			-- hitValueNew['BUFFTIME'] = 2
			hitValueNew['INEVITABLEHIT']=1
			self.parent:directFightAuratoDalay(mode,obj.itemID,hitValueNew,{posX=obj.posX,posY=obj.posY,RANGE=skill.atkDis},parameters.PETJUMPTIME)

		end
	end

	if mode==4 then
		self.nextSkillID = 0
		local eskill = self.attribute.skills[4] 
		local eparameters = eskill.parameters
		local skill = self.parent.attribute.skills[4] 
		local parameters = skill.parameters 
		local obj = self.world.allItemList[self.atkID] 
		--NEARESTUSEDIS=200;PETRANGE=600;PETINTERVAL=0.5;PETDURATION=2
		local lifeTime=parameters.PETDURATION - 0.1
		local attributes = {}
		attributes['buffParameter']= self:getPrepareHithitValue()
		attributes['BUFFONLY']=1
		-- attributes['INEVITABLEHIT'] = 1
		attributes['buffParameter']['RANGE'] = parameters.PETRANGE
		-- attributes['buffParameter']['DIZZY_RATE'] =   100
		-- attributes['buffParameter']['BUFFTIME'] =   0.3
		-- attributes['buffParameter']['FIXHURT'] =   8
		attributes['buffParameter']['creatureDirectHurCallBack'] = "lierenBBMode4"
		attributes['buffParameter']['ADADJ'] = parameters.ADADJ2
		attributes['buffParameter']['buffIntervalTime'] = parameters.PETINTERVAL
		attributes['buffParameter']['buffType'] = 1
		-- attributes['buffParameter']['Effect'] = -1
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,self.parent.itemID,self.itemID,skill.hitTime)
		--buff.debug = true
		self:addBuff(buff)

		local d = self:distance(self.mode4PosX,self.mode4PosY)
		local objwith = 0
		if obj~=nil then
			objwith = obj.attribute.width
		end
		if d>(self.attribute.width+objwith) then
			d = d-self.attribute.width-objwith
		else
			d = 0
		end
		local toX,toY = self.world.map:getXYLength(self.posX,self.posY,self.mode4PosX,self.mode4PosY,d)
		local ret
		ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX,self.posY+toY) 
		self:D("prepareHit 飞飞飞........ x tox y toy distance ",self.posX,toX,self.posY,toY,(d/eparameters.PETJUMPTIME)*self.world.setting.AdjustAttRange)
		self:moveTo(toX,toY,false,6,(d/eparameters.PETJUMPTIME)*self.world.setting.AdjustAttRange,eskill.hitTime) 

		syncMsg['a']['x'] = toX
		syncMsg['a']['y'] = toY


		--self:moveTo(self.mode4PosX,self.mode4PosY,false,6,600,0) 
	end

	SCreature802.super.prepareSkillAttackCustom(self,mode,target,x,y,adjTime,syncMsg)  
end 



--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SCreature802:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	local ret = SCreature802.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	return ret 
end 


---设置分身模式
function SCreature802:setDoubleMode(maxDis,minDis,followDis)
	--AVATARHP=50000;AVATARINHERIT=100;AVATARDEF=0;AVATARMDEF=0;CDTIME=15;USESOULNUM=100;AVATARTIME=10
	--AVATARAREAMAX=500;AVATARAREAMIX=200;ROLEBUFFSKILLA_RATE=100


	self.moveMaxDis = maxDis/self.world.setting.AdjustAttRange
	self.moveMinDis = minDis/self.world.setting.AdjustAttRange
	self.followDis = followDis/self.world.setting.AdjustAttRange

	self.attribute.ATK=self.parent.attribute.ATK
	self.attribute.baseTable.ATK=self.parent.attribute.ATK
	self.attribute.MSPD=self.parent.attribute.MSPD
	self.attribute.baseTable.MSPD=self.parent.attribute.MSPD
	self.attribute.HIT=self.parent.attribute.HIT
	self.attribute.baseTable.HIT=self.parent.attribute.HIT
	

	self:updateSyncMsg({h={{i=self.itemID,t=0,d=0,h=1,hp=self.attribute.MaxHP,hpe=0,ti=self.itemID,m=1,s=0}}})
	self.autoFightAI.runAI = true

	local result=self:getAllInfo(0,true)
	self:updateSyncMsg({i=result})
end




return SCreature802 