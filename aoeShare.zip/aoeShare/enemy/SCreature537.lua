local SCreature537 = class("SCreature537", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature537:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature537" 
	end 

	SCreature537.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	--在XX秒内 有多少个一起采集召唤神龙
	self.nextSLTime = 0
	self.SLNum = 0
	self.SLList= {}

end 


-- 受傷害計算,调用SActor的hurted
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SCreature537:hurted(itemID,bulletID,mode,hitValue,adjTime)
	local hurt = SCreature537.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
	return hurt
end


function SCreature537:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	--self.world:debuglog('jaylog SCreature537:directHurtCallBack')
	--SCreature537.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
	local obj = self.world.allItemList[itemID]
	if obj.actorType==0 and (obj.nextSLTime==nil or obj.nextSLTime<self.world:getGameTime())  then
		self:D("给目标加采集状态:",itemID)
		--obj:addStatusList({s=999,r=self.world.gameTime,t=0.5,p1=self.world.tonumber(self.attribute.roleId),p2=3,p3=self.world.tonumber(self.itemID)})
		self:SLCallBack(itemID)
	end
end

function SCreature537:createInit()
	local lifeTime=99999
	local attributes = {}
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['INEVITABLEHIT'] = 1
	attributes['buffParameter']['RANGE'] = self.attribute.width * self.world.setting.AdjustAttRange+300
	--attributes['buffParameter']['INEVITABLEHIT'] = 1
	attributes['buffParameter']['creatureDirectHurCallBack'] = self.itemID
	attributes['buffParameter']['buffIntervalTime'] = 0.3
	attributes['buffParameter']['buffType'] = 0
	attributes['buffParameter']['Effect'] = -1
	attributes['BUFFTIME'] = 99999
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0),attributes,lifeTime,{99},0,self.itemID,self.itemID,0.1)
	--buff.debug = true
	self:addBuff(buff)

	self:D("抢矿加采集buff。。。。。。。。。。。。。。。。。。。。。。。。 ",self.itemID)
end


function SCreature537:SLCallBack(itemID)
	if self.nextSLTime<self.world:getGameTime() then
		self.nextSLTime = self.nextSLTime + 10 
		self.SLNum = 0
		for k,v in pairs(self.SLList) do
			if v~=nil then
				--重置
				v.nextSLTime = self.world:getGameTime()
			end
		end
		self.SLList = {}
	end

	local obj = self.world.allItemList[itemID]
	obj.nextSLTime = self.world:getGameTime() + 10
	self.SLList[#self.SLList+1] = obj
	self.SLNum = self.SLNum + 1
end



function SCreature537:move() 
	SCreature537.super.move(self)
	if self.SLNum>0 then
		--召唤神龙
		-- local creatureID=self.world:addCreature(self.world.tostring(108),self.teamOrig,self.posX,self.posY,nil,1,0)
		local id = self.world.formula:getRandnum(8001,8007)
		self.world:addBoss(id,self.SLList[1].team,self.SLList[1].loginID,self.SLList[1].posX,self.SLList[1].posY,0,self.SLList[1].itemID)
		self.SLNum = 0
		self.SLList = {}
	end

end


return SCreature537