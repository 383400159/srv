local SCreature310 = class("SCreature310", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature310:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature310" 
	end 

	SCreature310.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

	self.energyNum = 0	
	self.canMove = false
	self.reduceTime = 0
end 

--- 計算傷害
-- @param itemID int - 攻擊方itemID
-- @param hitValue table - 計算參數
-- @return hurt float - 傷害值
function SCreature310:calHurted(itemID,hitValue)
	if self.world.allItemList[itemID].actorType==0 then
		self.energyNum = self.energyNum + 3
		self.world:D('jaylog SCreature310 hurted add energyNum',self.energyNum,self.itemID)
	end
	
	local hurt = SCreature310.super.calHurted(self,itemID,hitValue)
	hurt = 0
	return hurt
end

function SCreature310:move()
	if self.energyNum>10 and self.energyNum<20 then
		self.canMove = true
	else
		self.canMove = false
	end
	if self.energyNum~=0 and self.reduceTime+1<self.world.gameTime then
		self.energyNum = self.energyNum - 1
		self.reduceTime = self.world.gameTime
	end
	-- self.energyNum = self.energyNum - 1
	return SCreature310.super.move(self)
end

return SCreature310 