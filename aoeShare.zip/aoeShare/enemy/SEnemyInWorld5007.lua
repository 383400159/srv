local SEnemyInWorld5007 = class("SEnemyInWorld5007", require("gameroomcore.SHeroBase"))

function SEnemyInWorld5007:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld5007.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end


return SEnemyInWorld5007
