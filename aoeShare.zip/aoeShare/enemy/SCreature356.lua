local SCreature356 = class("SCreature356", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature356:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature356" 
	end 

	SCreature356.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.isNum = 0
	self.iszb = 0
	self.bzTime = 0
end 


function SCreature356:move() 
	SCreature356.super.move(self)
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SCreature356:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SCreature356.super.prepareHit(self,mode,adjTime,buff) 

	if self.iszb==0 and mode==1 then
		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters 

		--self.bzTime = self.world:getGameTime() + 8
		self:addStatusList({s=608,r=self.world.gameTime,t=8,i=self.itemID},0)

		local lifeTime=parameters.BOOMTIME+1		--skill.parameters.DEAD
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['buffParameter'] = hitValueBoth
		attributes['buffParameter']['RANGE'] = skill.atkDis 
		attributes['buffParameter']['ADADJ'] = hitValueBoth['ADADJ2']
		attributes['buffParameter']['APADJ'] = hitValueBoth['APADJ2']
		attributes['buffParameter']['creatureDirectHurCallBack'] = 'zb'
		attributes['buffParameter']['buffType'] = 1
	
		attributes['buffParameter']['buffIntervalTime'] = 99
		--self:D("虚无盲区  ",parameters.HURTLIFE, parameters.HURTITNTERVAL,parameters.HURTSTARTTIME,skill.hitTime)
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{99},0,self.itemID,self.lastBulletTarget,parameters.BOOMTIME)
		self:addBuff(buff)

		self:D("爆炸怪 挂buff在身上",self.itemID)
		hitValueBoth = nil
		self.iszb=1
	end

	return hitValueBoth 
end 


--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SCreature356:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	local hurt = SCreature356.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
	self:D("爆炸怪 自杀1",self.itemID,hitValue['creatureDirectHurCallBack'])
	if isset(hitValue['creatureDirectHurCallBack']) and hitValue['creatureDirectHurCallBack']=="zb"  then 
		self:D("爆炸怪 自杀",self.itemID)
		self.attribute.HP=0
		self:addStatusList({s=42,r=self.world.gameTime,t=16,i=self.itemID},0)
		self:directHurt(self.itemID,1,{},0)
	end

end


--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SCreature356:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	local hurt = SCreature356.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	-- if mode==1 and self.iszb then
	-- 	self.attribute.HP=0
	-- 	self:addStatusList({s=42,r=self.world.gameTime,t=16,i=self.itemID},2)
	-- 	self:directHurt(self.itemID,1,{},0)

	-- end
	

	return hurt
end



return SCreature356 