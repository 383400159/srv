local SEnemyInWorld2005 = class("SEnemyInWorld2005", require("gameroomcore.SHeroBase"))

function SEnemyInWorld2005:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld2005.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end


return SEnemyInWorld2005
