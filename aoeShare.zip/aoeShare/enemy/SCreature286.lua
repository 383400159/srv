local SCreature286 = class("SCreature286", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature286:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature286" 
	end 

	SCreature286.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)	
end 


function SCreature286:createInit()
	self.AIlastCoolDown = self.world.gameTime + 1
end

--- 計算傷害
-- @param itemID int - 攻擊方itemID
-- @param hitValue table - 計算參數
-- @return hurt float - 傷害值
function SCreature286:calHurted(itemID,hitValue)
	
	local hurt = SCreature286.super.calHurted(self,itemID,hitValue) 
	if hurt>1 then
		--debuglog("金色虫 减免伤害 hurt:"..hurt.." 当前血量:"..self.attribute.HP.." 死亡:"..(self:isDead() and "是" or "否"))
		hurt = 1
	end
	return hurt

end

function SCreature286:getBossObj()
	local obj = self.world:getObjBySubName("BOSS1",self.world.itemListFilter.heroList)
	return obj
end



--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SCreature286:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	local hurt = SCreature286.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	local obj  = self.world.allItemList[itemID]
	self:D("一粒蛋影魔召唤  被隐魔攻击  添加状态4116:",obj.itemID)
	if obj.st4116List==nil then
		obj.st4116List = {}
	end

	local skill = self.attribute.skills[1] 
	local parameters = skill.parameters 
	--HURTTIME=9;HURTINTERVAL=1;HURT=10

	obj.st4116List[#obj.st4116List+1]={starTime=self.world.gameTime,t=parameters.HURTTIME,hp=self.attribute.HP}
	obj:addStatusList({s=4116,r=self.world.gameTime,t=parameters.HURTTIME,i=self.itemID})	

	self.attribute.HP=0
	self:addStatusList({s=42,r=self.world.gameTime,t=16,i=self.itemID},2)

	return hurt
end

return SCreature286 
