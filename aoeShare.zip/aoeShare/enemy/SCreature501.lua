local SCreature501 = class("SCreature501", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature501:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature501" 
	end 

	SCreature501.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end 


function SCreature501:createInit()
	local lifeTime=99999
	local attributes = {}
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['INEVITABLEHIT'] = 1
	attributes['buffParameter']['RANGE'] = self.attribute.width * self.world.setting.AdjustAttRange+300
	--attributes['buffParameter']['INEVITABLEHIT'] = 1
	attributes['buffParameter']['creatureDirectHurCallBack'] = self.itemID
	attributes['buffParameter']['buffIntervalTime'] = 0.3
	attributes['buffParameter']['buffType'] = 0
	attributes['buffParameter']['Effect'] = -1
	attributes['BUFFTIME'] = 99999
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0),attributes,lifeTime,{99},0,self.itemID,self.itemID,0.1)
	--buff.debug = true
	self:addBuff(buff)

	self:D("抢矿加采集buff。。。。。。。。。。。。。。。。。。。。。。。。 ",self.itemID)
end

return SCreature501