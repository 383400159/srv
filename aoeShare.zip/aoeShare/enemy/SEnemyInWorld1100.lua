local SEnemyInWorld1100 = class("SEnemyInWorld1100", require("gameroomcore.SHeroBase"))

function SEnemyInWorld1100:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld1100.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SEnemyInWorld1100