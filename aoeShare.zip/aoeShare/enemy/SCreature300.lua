local SCreature300 = class("SCreature300", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature300:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature300" 
	end 

	SCreature300.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)	
end 


function SCreature300:createInit()
	local skill = self.attribute.skills[3] 
	local parameters = skill.parameters 
	local lifeTime=999999
	local attributes = {}
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['INEVITABLEHIT'] = 1
	-- attributes['buffParameter']['RANGE']=1000
	attributes['buffParameter']['RANGE'] = parameters.ATKRANGE
	attributes['buffParameter']['ATK'] = self.attribute.ATK
	attributes['buffParameter']['APADJ'] = parameters.APADJ

	-- attributes['buffParameter']['FIXHURT'] =   8
	attributes['buffParameter']['buffIntervalTime'] = parameters.ATKINTERVAL
	attributes['buffParameter']['buffType'] = 1
	attributes['buffParameter']['Effect'] = -1
	attributes['BUFFTIME'] = 0.5
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(1),attributes,lifeTime,{99},0,self.itemID,self.itemID,0)
	--buff.debug = true
	self:addBuff(buff)
end


--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SCreature300:goToDead(itemID,mode,adjTime,bonus)
	-- self:skillAttack(2)
	local skill = self.attribute.skills[2] 
	local parameters = skill.parameters 
	local hitValueNew = self:getPrepareHithitValue()
	hitValueNew['skillID'] = 2
	for k,v in pairs(parameters) do
		hitValueNew[k] = v
	end
	self:directFightAuratoDalay(2,0,hitValueNew,{posX=self.posX,posY=self.posY,RANGE=skill.atkDis},0) 
	ret = SCreature300.super.goToDead(self,itemID,mode,adjTime,bonus) 
end

return SCreature300 
