local SCreature266 = class("SCreature266", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature266:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature266" 
	end 

	SCreature266.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end 



--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SCreature266:goToDead(itemID,mode,adjTime,bonus)
	ret = SCreature266.super.goToDead(self,itemID,mode,adjTime,bonus) 
	--生成金甲虫 269
	local creatureID=self.world:addCreature(self.world.tostring(269),self.teamOrig,self.posX,self.posY,self,1,0)
	debuglog("SCreature266 召唤金甲虫")
	local Cobj  = self.world.allItemList[creatureID]
	Cobj:setSubName("worm")
	Cobj.Hatredlist = table.deepcopy(self.Hatredlist)
	local num = self.world.formula:getRandnum(2,4)
	--local num = self.world.formula:getRandnum(0,1)
	for i=1,num do
		debuglog("SCreature266 召唤黑甲虫")
		local creatureID=self.world:addCreature(self.world.tostring(268),self.teamOrig,self.posX,self.posY,self,1,0)
		local Cobj  = self.world.allItemList[creatureID]
		Cobj:setSubName("worm")
		Cobj.Hatredlist = table.deepcopy(self.Hatredlist)
	end
end





return SCreature266 