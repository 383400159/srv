local SCreature146 = class("SCreature146", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature146:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature146" 
	end 
	--死亡次数
	self.goToDeadTimes = 0
	
	SCreature146.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

	self.isRelease = false

end 

--重载木乃伊
function SCreature146:goToDead(itemID,mode,adjTime,bonus)  
	if mode==nil then mode = 0 end
	if adjTime==nil then adjTime = 0 end
	if bonus==nil then bonus = {} end

	
	local obj  = self.world.allItemList[itemID]
	-- SCreature146.super.goToDead(self,itemID,mode,adjTime,bonus)

	--复活时间self.className="World1"
	local time=50
	
	if obj.attribute.roleId==4 or  obj.attribute.roleId==9 then
		--time = -15
		time = 99999
		self:addStatusList({s=42,r=self.world.gameTime,t=16,i=self.itemID},0.2)
		self.isRelease = true
	else
		time = self.attribute.parameterArr["RELIVETIME"]
		self.isRelease = false
	end

	self.attackTarget = nil

	self.deadTime = self.world:getGameTime() + time + adjTime
	if adjTime>1 then adjTime = 1 end
	self:addStatusList({s=9,r=self.world:getGameTime()+adjTime,t=time,i=self.itemID},adjTime)
	self:moveTo(self.posX,self.posY)


	--记录死亡次数
	self.goToDeadTimes = self.goToDeadTimes + 1
	self:D("木乃伊 死亡 time:",time," goToDeadTimes:",self.goToDeadTimes,' deadTime:',self.deadTime,self.itemID)
end 

--- 复活, 游戏loop
-- @param null
-- @return null
function SCreature146:revive()
	--self:D("fenglog 木乃伊 死亡 revive1:")
	if self.deadTime<=self.world:getGameTime() and not self.isRelease then
		self:D("fenglog 木乃伊 死亡 revive2:")
		self:removeStatusList(9)
		self.towerComplete = 0
		if table.nums(self.buffList)>0 then
			local recal = false
			local skillID = 0
			for k,v in pairs(self.buffList) do
				skillID = v.buffID%1000000
				if skillID<990000 then
					self.buffList[k].isRemove = 1
					local statusNum = self:__buffID2StatusNum(v.buffID,v.buffParameter['statusnum'])
					if self.statusList[statusNum]~=nil and v.buffID>10000 then
						self:removeStatusList(statusNum)
					end
					recal = true
				end
			end
			if recal then
				self:reCalBuff()
			end
		end
		--计算复活的血量
		local scale = 1-self.goToDeadTimes*self.attribute.parameterArr["RELIVEHPREDUCE"]*0.01
		
		if scale<self.attribute.parameterArr["RELIVEHPMIN"]*0.01 then
			scale = self.attribute.parameterArr["RELIVEHPMIN"]*0.01
		end	
		self:D("fenglog 木乃伊 ：scale："..scale)
		self:D("fenglog 木乃伊 getMaxHP:"..self.attribute:getMaxHP())
		self.attribute.HP = self.attribute:getMaxHP() * scale
		self.attribute.MP = self.attribute:getMaxMP() * scale
		self:D("fenglog 木乃伊 HP:"..self.attribute.HP)

		-- self.posX = self.initX
		-- self.posY = self.initY

		self:__findingZone()
		self.skeleton = 0
		self.lastWalkTime = self.world:getGameTime()
		self.invincibleTime = self.world:getGameTime() + 1.5
		self:moveTo(self.posX,self.posY,true,1)
		self.syncMsg['m']['d']=0.05
		--self.syncMsg['m']=nil
		self.attackTarget = nil
		self.prepareSkillAttackNum = 0
		self.status = 0
		self:setCounter('revive')
		self:__getInfo()
		self:syncStatus()

		local result=self:getAllInfo(0,true)
		result['s'] = 1
		self:updateSyncMsg({i=result})
		self:D("fenglog 木乃伊 result:"..self.world.cjson.encode(result))
--		self:D("fenglog 血条bug revive .......itemID:"..self.itemID.." revive ..getMaxMP:"..self.attribute:getMaxMP())
	end

end





return SCreature146 