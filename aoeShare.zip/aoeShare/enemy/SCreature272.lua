local SCreature272 = class("SCreature272", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature272:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature272" 
	end 
	self.DELAYTIME = 0
	self.atkmode = 0 
	SCreature272.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end 




--- move motion , call every update loop
-- @return null
function SCreature272:move()

	if (self.createTime+self.DELAYTIME)<self.world:getGameTime() and self.atkmode==0 then
		self:skillAttack(2,self.itemID)
		self.atkmode=1
	end
	
	SCreature272.super.move(self) 
end


--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SCreature272:goToDead(itemID,mode,adjTime,bonus)
	--self.world:debuglog('jaylog SCreature272:goToDead skillAttack 3')
	if itemID~=self.itemID then
		local hitValue = self:prepareHit(3,0,false)
		if hitValue['ADDATTACK']~=nil then
			local skill = self.attribute.skills[3]
			hitValue['MODE'] = 3
			hitValue['BULLETSPEED'] = skill.bulletSpeed
		end
		--self.world:debuglog('jaylog SCreature272:goToDead skillAttack 3 hitValue:',self.world.cjson.encode(hitValue))
		self.world:callCreature(hitValue,self)
	end
	ret = SCreature272.super.goToDead(self,itemID,mode,adjTime,bonus) 
	return ret
end


function SCreature272:createInit()
	
end

function SCreature272:callCreature(hitValue,mode)
	if mode==3 then
		--self.world:debuglog('jaylog SCreature272:callCreature ',self.world.cjson.encode(hitValue),mode)
	end
end

return SCreature272