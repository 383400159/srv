local SCreature547 = class("SCreature547", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature547:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature547" 
	end 

	SCreature547.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end 


-- 受傷害計算,调用SActor的hurted
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SCreature547:hurted(itemID,bulletID,mode,hitValue,adjTime)
	local hurt = SCreature547.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
	-- if itemID~=self.itemID then
	-- 	self.world:D('xiaomalog test1')
	-- 	local hitValueNew={}
	-- 	hitValueNew["STOPMOVE_RATE"]=100
	-- 	hitValueNew["BUFFTIME"]=1
	-- 	self:directHurt(self.itemID,mode,hitValueNew,0) 
	-- 	self.world:D('xiaomalog test')
	-- end
	self.world:addSyncMsg({gameinfo={{part=11,step=800804,mType=3}}})
	return hurt
end


return SCreature547