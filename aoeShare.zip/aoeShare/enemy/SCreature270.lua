local SCreature270 = class("SCreature270", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature270:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature270" 
	end 

	SCreature270.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end 


--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SCreature270:goToDead(itemID,mode,adjTime,bonus)
	ret = SCreature270.super.goToDead(self,itemID,mode,adjTime,bonus) 
	--生成黑甲虫 268
	local num = self.world.formula:getRandnum(0,4)
	--local num = self.world.formula:getRandnum(0,1)
	for i=1,num do
		local creatureID = self.world:addCreature(self.world.tostring(268),self.teamOrig,self.posX,self.posY,self,1,0)
		local Cobj  = self.world.allItemList[creatureID]
		Cobj:setSubName("worm")
		Cobj.Hatredlist = table.deepcopy(self.Hatredlist)
	end

end





return SCreature270 