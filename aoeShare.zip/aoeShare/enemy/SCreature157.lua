local SCreature157 = class("SCreature157", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature157:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature157" 
	end 

	SCreature157.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end 




--- 自动移动chud
-- @return null
function SCreature157:_autoMove()
	
	if self.AIlastAutoMove<self.world.gameTime and self.world.gameTime>0 and  not self:isDead() and self.world.gameTime>self.outOfCtlAllTime then
		--巡逻模式
		local ROLLDESTROYTIME= self.autoFightAI:autoPatrol1()
		self.world:debuglog("闪电球死亡.................. ROLLDESTROYTIME:",ROLLDESTROYTIME)
		if (ROLLDESTROYTIME>=self.attribute.parameterArr["ROLLDESTROYTIME"]) then
			self.attribute.HP=0
			self.world:debuglog("闪电球死亡.................. itemID:",self.itemID)
			self:addStatusList({s=42,r=self.world.gameTime,t=16,i=self.itemID},0.2)
		end

	end
end



return SCreature157 