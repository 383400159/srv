local SCreature301 = class("SCreature301", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature301:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature301" 
	end 

	SCreature301.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)	
end 

--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SCreature301:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	ret = SCreature301.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	self.attribute.HP=0
	self:addStatusList({s=42,r=self.world.gameTime,t=16,i=self.itemID},1)
	return ret 
end 

return SCreature301 
