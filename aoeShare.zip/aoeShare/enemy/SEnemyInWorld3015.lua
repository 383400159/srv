local SEnemyInWorld3015 = class("SEnemyInWorld3015", require("gameroomcore.SHeroBase"))

function SEnemyInWorld3015:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld3015.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end


return SEnemyInWorld3015
