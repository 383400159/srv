local SEnemyInWorld3016 = class("SEnemyInWorld3016", require("gameroomcore.SHeroBase"))

function SEnemyInWorld3016:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld3016.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end


return SEnemyInWorld3016
