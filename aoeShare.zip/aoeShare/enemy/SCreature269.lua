local SCreature269 = class("SCreature269", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature269:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature269" 
	end 

	SCreature269.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)	
end 



--- 計算傷害
-- @param itemID int - 攻擊方itemID
-- @param hitValue table - 計算參數
-- @return hurt float - 傷害值
function SCreature269:calHurted(itemID,hitValue)
	
	local hurt = SCreature269.super.calHurted(self,itemID,hitValue) 
	if hurt>1 then
		debuglog("金色虫 减免伤害 hurt:"..hurt.." 当前血量:"..self.attribute.HP.." 死亡:"..(self:isDead() and "是" or "否"))
		hurt = 1
	end
	return hurt

end

--- 受傷害計算
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SCreature269:hurted(itemID,bulletID,mode,hitValue,adjTime)
	self.Hatredlist = {}
	debuglog("SCreature269 hurted Hatredlist:"..self.world.cjson.encode(self.Hatredlist))
	local hurt = SCreature269.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
	self.Hatredlist[""..itemID]=99999
	debuglog("SCreature269 hurted Hatredlist:"..self.world.cjson.encode(self.Hatredlist))
	return hurt
end


return SCreature269 
