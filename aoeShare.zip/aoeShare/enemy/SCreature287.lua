local SCreature287 = class("SCreature287", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature287:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature287" 
	end 

	SCreature287.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)	
end 


function SCreature287:createInit()
	self.AIlastCoolDown = self.world.gameTime + 1
end

--- 計算傷害
-- @param itemID int - 攻擊方itemID
-- @param hitValue table - 計算參數
-- @return hurt float - 傷害值
function SCreature287:calHurted(itemID,hitValue)
	
	local hurt = SCreature287.super.calHurted(self,itemID,hitValue) 
	if hurt>1 then
		--debuglog("金色虫 减免伤害 hurt:"..hurt.." 当前血量:"..self.attribute.HP.." 死亡:"..(self:isDead() and "是" or "否"))
		hurt = 1
	end
	return hurt

end


--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SCreature287:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	local obj  = self.world.allItemList[itemID]
	hitValue['FIXHURT'] = obj.attribute.MaxHP+10
	local hurt = SCreature287.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	self.attribute.HP=0
	self:addStatusList({s=42,r=self.world.gameTime,t=16,i=self.itemID},2)
	self:directHurt(self.itemID,1,{},0)
	-- local obj  = self.world.allItemList[itemID]
	-- self:D("一粒蛋影魔召唤  被隐魔攻击  添加状态4116:",obj.itemID)
	-- if obj.st4116List==nil then
	-- 	obj.st4116List = {}
	-- end
	-- obj.st4116List[#obj.st4116List+1]={starTime=self.world.gameTime,t=10,hp=self.attribute.HP}
	-- obj:addStatusList({s=4116,r=self.world.gameTime,t=10,i=self.itemID})	

	-- self.attribute.HP=0
	-- self:addStatusList({s=42,r=self.world.gameTime,t=16,i=self.itemID},0.2)

	return hurt
end


return SCreature287 
