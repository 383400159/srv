local SEnemyInWorld3017 = class("SEnemyInWorld3017", require("gameroomcore.SHeroBase"))

function SEnemyInWorld3017:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld3017.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end


return SEnemyInWorld3017
