--require "gameroom.functions"
--require "gameroom.Config"

-- local cjson = require( Config.cjson )

local SMonster = class("SMonster" , require("gameroom.enemy.SEnemy"))
-- class Monster extends Enemy {
function SMonster:ctor(world,id,team,posX,posY,level)
		if( self.className == nil )then
			self.className = "SMonster"
		end
		SMonster.super.ctor(self,world,id,team,posX,posY,level)
		self.initX = posX  --  initial positionX
		self.initY = posY --  initial positionY
		self.lastIdleTime=0	--	上次空闲时间点
		self.monsterGroup=""	-- 怪物的分组，不等于team
		self.buffCoolDownA=0	-- 
		self.startREHPMPtime = 0	--开始回血的时间
		self.inInitXY = false	--是否在出生点
		self.toMap = 0
		self.toRoomID = 0
		self.flagType = ''
end

--- Initialize monster object (attribute enemy skill ...)
-- @param id int - actor ID
-- @param x int - position x
-- @param y int - position y
-- @return null
function SMonster:__init(id,posX,posY,level) 
	SMonster.super.__init(self,id,posX,posY,level)
	self.initX=posX
	self.initY=posY
end

--- 執行移動，调用SActor的moveTo
-- @param x float - position x
-- @param y float - position y
-- @param force bool - 強制執行, 不論是否已到達
-- @param center bool -  0 - 正常, 1 - 閃現 , 2 - 跳至 , 3 - 滾動, 4=擋移動, 5=擊飛, 6=技能移动
-- @param MSPDfix float - 速度
-- @return moveMsg table - 移動訊息
function SMonster:moveTo(x,y,force,mode,speed,adjTime)
	if( force == nil) then
		force = false
	end
	if( mode == nil) then
		mode = 0
	end
	if( speed == nil) then
		speed = 0
	end

	-- 不可移动
	if (isset(self.attribute.parameterArr,"NOMOVE") and self.attribute.parameterArr["NOMOVE"]==1) then
		return nil
	end
	local ret = SMonster.super.moveTo(self,x,y,force,mode,speed,adjTime)
	return ret
end

-- 移动
--- move motion , call every update loop
-- @return null
function SMonster:move() 
	SMonster.super.move(self)
end

-- 死
--- 進入死亡狀態,call actor的goToDead
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SMonster:goToDead(itemID,mode,adjTime,bonus) 
	if( mode == nil )then
		mode = 0
	end
	SMonster.super.goToDead(self,itemID,mode,adjTime,bonus)


	local targetObj = self.world.allItemList[itemID]
	self.attribute.killByPlayerID = itemID
	
	-- 经验＋砖石 ，remark by kevin ,start
	if (targetObj.attribute.ActorType==0) then
		targetObj:setCounter('killmonster')
	end
end

--- 受傷害計算,调用SActor的hurted
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SMonster:hurted(itemID,bulletID,mode,hitValue,adjTime) 
	local hurt = SMonster.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)

	return hurt
end

-- 攻击
--- fight motion , call every update loop, 主要通过父类的__soldierFight执行攻击
-- @return null
function SMonster:fight() 
	SMonster.super.fight(self)
end


--攻击以后的callback
function SMonster:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	if ( hitValue['creatureDirectHurCallBack'] ~= nil) then
		--debuglog('jaylog SMonster:directHurtCallBack in cID '..hitValue['creatureDirectHurCallBack']..' itemID '..itemID..' toMap:'..self.toMap..' toRoomID:'..self.toRoomID)
		--传送门回调start
		if self.toMap~=0 and hitValue['creatureDirectHurCallBack']~=itemID then
			if self.world.allItemList[itemID].actorType==0 and self.world.allItemList[itemID].redirectRoomTime<self.world.gameTime then
				debuglog('jaylog SMonster:directHurtCallBack actorType 0')
				self.world.allItemList[itemID].redirectRoomTime = self.world.gameTime + 5
				self.world:redirectRoom(itemID,self.toMap,self.toRoomID)
			end
		end
		--传送门回调end
	end
	SMonster.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
end

return SMonster
