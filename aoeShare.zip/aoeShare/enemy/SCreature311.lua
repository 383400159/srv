local SCreature311 = class("SCreature311", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature311:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature311" 
	end 

	SCreature311.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

	self.energyNum = 0	
	self.lastHurtTime = {}
end 

--- 計算傷害
-- @param itemID int - 攻擊方itemID
-- @param hitValue table - 計算參數
-- @return hurt float - 傷害值
function SCreature311:calHurted(itemID,hitValue)
	if self.world.allItemList[itemID].actorType==0 then
		self.world:D('jaylog SCreature311 hurted add energyNum',self.itemID)
		local num = 0
		for k,v in pairs(self.lastHurtTime) do
			if (v+1)<self.world:getGameTime() then
				num = num + 1
			end
		end
		self.energyNum = self.energyNum + num
		self.lastHurtTime[itemID] = self.world:getGameTime()
	end
	if self.energyNum==10 then
		self.world:D('jaylog SCreature311 hurted add parent energyNum',self.parent.itemID)
		self.parent:setEnergy(1)
	end
	local hurt = SCreature311.super.calHurted(self,itemID,hitValue)
	hurt = 0
	return hurt
end

return SCreature311 