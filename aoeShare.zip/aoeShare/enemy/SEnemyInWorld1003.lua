local SEnemyInWorld1003 = class("SEnemyInWorld1003", require("gameroomcore.SHeroBase"))

function SEnemyInWorld1003:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld1003.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end



--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SEnemyInWorld1003:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	local ret = SEnemyInWorld1003.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	if ret>0 then
		local obj  = self.world.allItemList[itemID]
		--obj.statusList[999] = nil
		if obj.statusList[41]~=nil then
			obj:removeStatusList(999)
		end
		obj:removeSkillAttackMode9()
		self:D("挖矿  取消挖矿状态:",obj.itemID)
	end
	return ret 
end


return SEnemyInWorld1003