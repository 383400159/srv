local SCreature151 = class("SCreature151", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature151:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature151" 
	end 
	SCreature151.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end 

--boss免控
function SCreature151:addIMMUNECONTROLBUFF()
	--IMMUNECONTROL_RATE=100

	self:D("addIMMUNECONTROLBUFF boss itemID:"..self.itemID)
	-- self:D("boss allItemList:"..self.world.cjson.encode(self.world.allItemList[self.itemID]))
	local attributes = {}
	local hitValueNew = self:getPrepareHithitValue()
	attributes = hitValueNew
	attributes['BUFFONLY']=1
	attributes['IMMUNECONTROL_RATE'] = 100
	attributes['buffType'] = 3
	attributes['BUFFTIME'] = 99999
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0,99),attributes,99999,{},0,self.itemID,self.itemID,0)
	self:addBuff(buff)
end


--- 子彈完結callback
-- @param bulletID int - 子彈ID
-- @return null
function SCreature151:endBullet(bulletID)
	self.attribute.HP=0
	self:addStatusList({s=42,r=self.world.gameTime,t=16,i=self.itemID},0.2)
	self:D("黑白球  死亡151")
end


return SCreature151 