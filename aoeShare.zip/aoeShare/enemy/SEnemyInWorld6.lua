local SEnemyInWorld6 = class("SEnemyInWorld6", require("gameroomcore.SHeroBase"))

function SEnemyInWorld6:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld6.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end



return SEnemyInWorld6