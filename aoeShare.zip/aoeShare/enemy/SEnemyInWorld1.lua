local SEnemyInWorld1 = class("SEnemyInWorld1", require("gameroomcore.SHeroBase"))

function SEnemyInWorld1:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld1.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SEnemyInWorld1