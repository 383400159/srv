local SEnemyInWorld8007 = class("SEnemyInWorld8007", require("gameroomcore.SHeroBase"))

function SEnemyInWorld8007:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld8007.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SEnemyInWorld8007