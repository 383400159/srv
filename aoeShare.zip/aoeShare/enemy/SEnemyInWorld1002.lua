 local SEnemyInWorld1002 = class("SEnemyInWorld1002", require("gameroomcore.SHeroBase"))

function SEnemyInWorld1002:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld1002.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SEnemyInWorld1002