local SCreature156 = class("SCreature156", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature156:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature156" 
	end 

	SCreature156.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	-- if actorID~=nil then
	-- 	debuglog("jaylog SActor actorID jaylog SBoss actorID:"..actorID)
	-- 	self.itemID = actorID				--游戏房角色num
	-- end		
end 


function SCreature156:goToDead(itemID,mode,adjTime,bonus)  
	SCreature156.super.goToDead(self,itemID,mode,adjTime,bonus) 
end 



--- move motion , call every update loop
-- @return null
function SCreature156:move()
	SCreature156.super.move(self)



	local targetList = {}
	local visRange={posX=self.posX,posY=self.posY,radius=500/self.world.setting.AdjustVisRange}

	local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
	function(obj)
	 	ok = true
		if (not value:isDead()) then ok =false end
		if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
		if ok and (value.attribute.HP/value.attribute.MaxHP)<1 then
			local d = value:colliding(visRange,0,0,self.itemID)
			if d>=0 then
				targetList[#targetList+1] = value
			end
		end
	end
	)

	-- local enemy = self:getEnemylist()
	-- for k,value in pairs(enemy) do
	-- 	ok = true
	-- 	if (not value:isDead()) then ok =false end
	-- 	if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
	-- 	if ok and (value.attribute.HP/value.attribute.MaxHP)<1 then
	-- 		local d = value:colliding(visRange,0,0,self.itemID)
	-- 		if d>=0 then
	-- 			targetList[#targetList+1] = value
	-- 		end
	-- 	end
	-- end

	--添加一个状态给前面
	self:addStatusList({s=129,r=self.world:getGameTime(),t=time,i=self.itemID,p1=#targetList})

end


return SCreature156 