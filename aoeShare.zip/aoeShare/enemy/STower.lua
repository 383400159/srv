
local STower = class("STower" , require("gameroom.enemy.SEnemy"))


function STower:ctor(world,id,team,posX,posY,level)
	if( self.className == nil ) then
		self.className = "STower"
	end	
	STower.super.ctor(self,world,id,team,posX,posY,level)

	self.lastHitCount = 0	
	self.lastHitTarget = nil
	self.heroAttackList={}	
	self.lastAttackTimeTower = 0
	self.heroAttack={}  --  record the time of last attacked by enemy Hero
	self.towerGroup=""
	self.heroAttackMode=false

	debuglog("塔的坐标 塔ID:"..self.itemID.." x:"..self.posX.." Y:"..self.posY)
end


function STower:__init(id,posX,posY,level) 
	STower.super.__init(self,id,posX,posY,level)
	self.attribute.parent=self
end

function STower:move() 

end

function STower:fight() 
	local attRange=self:getAttRange()
	local heroList=table.deepcopy(self:__protectHero())
	local newHeroAttackList={}
	local distance = 0
	local runThisTime = true
	local t = 0
	local newHeroAttackList1={}
	local newHeroAttackList2={}
	local hurtTime = 0
	local hitValueBoth = 0
	if (table.nums(self.heroAttackList)> 0 ) then
		for i=1, #self.heroAttackList do
			if ( self.world.allItemList[self.heroAttackList[i]].className == "SMonster" 
				or self.world.allItemList[self.heroAttackList[i]]:colliding(attRange,0,0,self.itemID)<0 
				or self.world.allItemList[self.heroAttackList[i]]:isDead() 
				or isset(self.world.allItemList[self.heroAttackList[i]].statusList,173)) then

			else
				newHeroAttackList[#newHeroAttackList+1]=self.heroAttackList[i]
			end
		end
	end
	--print('STower heroList  :' .. self.world.cjson.encode(heroList ) )
	self.heroAttackList=newHeroAttackList
	if (table.nums(heroList)>0 ) then
		for kkkk,value in pairs(heroList) do  
			runThisTime = true
			if ( self.world.allItemList[value].calssName=="SMonster") then
				runThisTime = false
			end
			if (isset(self.world.allItemList[value].statusList, 173)) then
				runThisTime = false
			end
			if (in_array(value,self.heroAttackList) == false) then
				t = self.world.allItemList[value]:colliding(attRange,0,0,self.itemID)
				if (t>=0 and self.world.allItemList[value]:isDead() == false) then
					distance = t
					if( self.heroAttackList == nil )then
						self.heroAttackList = {}
					end
					if (table.nums(self.heroAttackList) == 0 ) then
						self.heroAttackList[#self.heroAttackList + 1]=value
					end
				end
			end
		end
	end
	-- local distance
	if (table.nums(self.heroAttackList)>0) then
		newHeroAttackList1={}
		newHeroAttackList2={}
		for kkkk2,value in pairs(self.heroAttackList) do
			if (value<200) then
				newHeroAttackList1[#newHeroAttackList1 + 1]=value
			else
				newHeroAttackList2[#newHeroAttackList2 + 1]=value
			end
		end
		--print('STower newHeroAttackList1  :' .. self.world.cjson.encode(newHeroAttackList1 ) )
		--print('STower newHeroAttackList2  :' .. self.world.cjson.encode(newHeroAttackList2 ) )
		self.heroAttackList = newHeroAttackList1 
		table.merge(self.heroAttackList,newHeroAttackList2)
		--print('STower heroAttackList  :' .. self.world.cjson.encode(self.heroAttackList ) )
		self.attackTarget=self.world.tonumber(self.heroAttackList[1])
	else
		if (self.attackTarget ~= nil) then
			if (self.world.allItemList[self.attackTarget]:isDead() or isset(self.world.allItemList[self.attackTarget].statusList, 173 )) then
				self.attackTarget=nil
			else
				distance = self.world.allItemList[self.attackTarget]:colliding(attRange,0,0,self.itemID)
				if (distance<0) then
					self.attackTarget=nil
				end
			end
		end
	end
	if (self.lastFightTime+(self.world.setting.attackSpeedBase/(self.attribute.ASPD+self.attribute.buffAttribute.ASPD+self.attribute.ASPDE))*100<=self.world.gameTime) then
		if (self.attackTarget == nil) then
			distance = self:__findTarget()
		end

		if (self.attackTarget ~= nil) then
			if (self.heroAttackMode and self.world.allItemList[self.attackTarget].attribute.actorType==1) then
				self.heroAttackMode=false
			end
			if (self.lastHitTarget==self.attackTarget and (self.heroAttackMode or self.world.allItemList[self.attackTarget].attribute.actorType==1)) then
				self.lastHitCount = self.lastHitCount + 1
			else
				self.lastHitCount=0
			end

			if (self.lastHitCount>6) then
				self.lastHitCount=6
			end
			hurtTime = self.world.gameTime + self.attribute.HitTime / (self.attribute.ASPDR/100) --  出招時間
			hurtTime = hurtTime + math.round((distance / self.attribute.BulletSpeed)*self.world.setting.walkingSpeed,2)
			hitValueBoth = self:prepareHit(0,0)
			self.world:addBullet(0,self.itemID,self.world.gameTime + self.attribute.HitTime / (self.attribute.ASPDR/100),
				self.world.allItemList[self.attackTarget].itemID,self.world.allItemList[self.attackTarget].posX,
				self.world.allItemList[self.attackTarget].posY,false,hitValueBoth)
			self.lastFightTime=self.world.gameTime
			-- self.syncMsg['a'][]=array('i'=>self.itemID,'m'=>0,'t'=>(0),'ti'=>self.attackTarget,'ht'=>hurtTime-self.world.gameTime)
			local tmpMsg = {}
			tmpMsg = {i=self.itemID,m=0,t=(0),ti=self.attackTarget,ht=hurtTime - self.world.gameTime }
			self:updateSyncMsg({a={tmpMsg}})
			if (self.world.allItemList[self.attackTarget].attribute.actorType==0 and self.world.allItemList[self.attackTarget].team ~= self.team) then
				self.heroAttack[self.attackTarget]=self.world.gameTime
			end

			self.dirty=true
			self.lastHitTarget=self.attackTarget
			if (self.world.allItemList[self.attackTarget].attribute.actorType==1 and (self.world.allItemList[self.attackTarget].attribute.ID==25 or self.world.allItemList[self.attackTarget].attribute.ID==26)) then
				self.attackTarget=nil
			end
-- 		end
	-- else
		end

	end


-- 	STower.super.fight(self)
end -- end of function STower:fight()

function STower:goToDead(itemID,mode,adjTime,bonus) 
	if( mode == nil) then
		mode = 0
	end

	STower.super.goToDead(self,itemID,mode,adjTime,bonus)
	self.deadTime=-1



	local lastHero=0
	local lastHeroTime=0
	for key,value in pairs(self.heroAttack) do
		if (value+3>=self.world.gameTime and lastHeroTime<value) then
			lastHero=key
			lastHeroTime=value
			itemID=key
		end
	end
	if (self.world.allItemList[itemID].attribute.actorType==0) then

		-- self.syncMsg['bc'][]=array('zz'=>2,'mid'=>29,'p1'=>self.world.allItemList[itemID].loginID,'p2'=>self.attribute.Name,'t'=>self.team,'d'=>adjTime+1)
		-- self.syncMsg['bc'][]=array('zz'=>2,'mid'=>31,'p1'=>self.world.allItemList[itemID].loginID,'p2'=>self.attribute.Name,'t'=>self.team=="A"?"B":"A",'d'=>adjTime+1)

		local tmpMsg = {}
		tmpMsg = {zz=2,mid=29,p1=self.world.allItemList[itemID].loginID,p2=self.attribute.Name,t=self.team,d=adjTime+1}
		self:updateSyncMsg({bc={tmpMsg}})
		local tmpTeamFlag = "A"
		if( self.team=="A" ) then
			tmpTeamFlag = "B"
		else
			tmpTeamFlag = "A"
		end
		local tmpMsg = {}
		tmpMsg = {zz=2,mid=31,p1=self.world.allItemList[itemID].loginID,p2=self.attribute.Name,t=tmpTeamFlag,d=adjTime+1}
		self:updateSyncMsg({bc={tmpMsg}})

		if (self.attribute.ID==13 or self.attribute.ID==14 or self.attribute.ID==103 or self.attribute.ID==104) then
			self.world.allItemList[itemID]:setCounter('killbase')
		else
			self.world.allItemList[itemID]:setCounter('killtower')
		end
		self.world.allItemList[itemID]:setCounter('killenemy_'..self.attribute.ID)

	else
		-- self.syncMsg['bc'][]=array('zz'=>2,'mid'=>30,'p1'=>itemID,'p2'=>self.attribute.Name,'t'=>self.team,'d'=>adjTime)
		-- self.syncMsg['bc'][]=array('zz'=>2,'mid'=>32,'p1'=>itemID,'p2'=>self.attribute.Name,'t'=>self.team=="A"?"B":"A",'d'=>adjTime)
		local tmpMsg = {}
		tmpMsg = {zz=2,mid=30,p1=itemID,p2=self.attribute.Name,t=self.team,d=adjTime}
		self:updateSyncMsg({bc={tmpMsg}})
		local tmpTeamFlag = "A"
		if( self.team=="A" ) then
			tmpTeamFlag = "B"
		else
			tmpTeamFlag = "A"
		end
		local tmpMsg = {}
		tmpMsg = {zz=2,mid=32,p1=itemID,p2=self.attribute.Name,t=tmpTeamFlag,d=adjTime}
		self:updateSyncMsg({bc={tmpMsg}})

	end

	
	local targetObj=self.world.allItemList[itemID]
	local bonusTy="STower"
	local bonusArrAll = ""
	local bonusName = ""
	local heroes
	local bonusGroup = ""
	if (self.world.is3V3 and self.world.isTraining and lastHero>0 and (self.attribute.ID>=11 and self.attribute.ID<=12) and (targetObj.bonusType[bonusType]==nil or targetObj.bonusType[bonusType]<1)) then
		bonusName="tower_"
		if (self.world.needSameGuild and (self.world.mapSize==2 or self.world.mapSize==9)) then
				bonusArrAll=self.world.jackpotEnemy[bonusName.."guild"]
		elseif (self.world.is3V3 and (self.world.mapSize==3 or self.world.mapSize==10)) then
				bonusArrAll=self.world.jackpotEnemy[bonusName.."2V2"]
		elseif (self.world.is3V3 and (self.world.mapSize==9)) then
				bonusArrAll=self.world.jackpotEnemy[bonusName.."5V5"]
		elseif (self.world.is3V3 and (self.world.mapSize==2 or self.world.mapSize==9)) then
				bonusArrAll=self.world.jackpotEnemy[bonusName.."3V3"]
		end
		-- team 伍索引(会受buff影响)
		if (self.world.allItemList[itemID].team=="A") then
			heroes=self.world.heroTeamAList
		else
			heroes=self.world.heroTeamBList
		end
		-- 爆塔玩家若受反间buff影响，不计算获得
		if( self.world.allItemList[itemID].team==self.world.allItemList[itemID].teamOrig ) then

			bonusGroup = bonusTy .. self.world.allItemList[itemID].teamOrig 
			self:calculateBonus(targetObj,heroes,bonusGroup,bonusTy,bonusArrAll,bonus) 
		end
		if self.world.gameModel~=11 then
			-- 同队队员计算物品获得
			--print("爆塔掉落物品  1")
			for kkkk,heroobj in pairs(heroes) do
				--print("爆塔掉落物品  2")
				local runOnce = true
				while ( runOnce )  do
					--print("爆塔掉落物品  3")
					runOnce = false
					if heroobj.bonusType ==nil then heroobj.bonusType = {} end
					heroobj.bonusType[bonusTy]=(heroobj.bonusType[bonusTy]==nil and 0 or heroobj.bonusType[bonusTy]) +1
					local bonusArr=bonusArrAll[heroobj.attribute.classes]
					if (#bonusArr==0) then
						break
					end
					--print("爆塔掉落物品  4")
					local bonusList={}
					local totalRate=0
					local bonusFinal = {ID = 0}
					for kkkk3,vvv in pairs(bonusArr) do
						bonusList[#bonusList + 1]={ID=vvv['itemID'],Rate=totalRate,qty=vvv['amount'],JID=vvv['id']}
						totalRate=totalRate + vvv['Rate']
					end
					local k=0
					--print("爆塔掉落物品  5")
					repeat
						local rand = math.random(1,totalRate)
						local i=1
						while (( i<= #bonusList) and rand > bonusList[i]['Rate'] ) do
							bonusFinal = bonusList[i]
							i=i+1
						end
						k=k+1
					until ((bonusFinal['ID']>0 
							and (heroobj.bonus[""..bonusFinal['ID']]~=nil or ( self.world.allItemList[itemID].playerJson["HeroPieces"][bonusFinal['ID']]~=nil and self.world.allItemList[itemID].playerJson["HeroPieces"][bonusFinal['ID']]==0) ) 
							and k<5 ) == false) -- while > until
					--print("爆塔掉落物品  6")
					if (k>=5) then
						bonusFinal['ID']=0
					end

					if (bonusFinal['ID']>0) then
						--print("爆塔掉落物品  7")
						if( bonus == nil ) then
							local bonus = {}
						end
						bonus[""..heroobj.itemID]=bonusFinal['ID']
						local qty=bonusFinal['qty'][math.random( 1, #bonusFinal['qty'])]
						if (heroobj.bonus[""..bonusFinal['ID']]~=nil) then
							--print("爆塔掉落物品  8")
							heroobj.bonus[""..bonusFinal['ID']]=heroobj.bonus[""..bonusFinal['ID']] + qty
						else
							--print("爆塔掉落物品  9")
							heroobj.bonus[""..bonusFinal['ID']]=qty
						end
--print( " ==  == == bonus target team "..heroobj.itemID.." rand "..cjson.encode(heroobj.bonus).." "..cjson.encode(bonusList).."\n")
					end
				end -- end while ( runOnce )  do

			end -- for for kkkk,heroobj in pairs(heroes) do
		end
	end -- end of if (self.world.is3V3 and self.world.isTraining and 

	local heroes
	local expgain={}
	local extra=0

	if (self.team=="A") then
		heroes=self.world.heroTeamBList
	else
		heroes=self.world.heroTeamAList
	end

	if (self.attribute.ExpGain>0) then
		for kkkk4,value in pairs(heroes) do
			if (isset(expgain ,value.itemID )) then
				expgain[value.itemID] = expgain[value.itemID]+ math.round(self.attribute.ExpGain)
			else
				expgain[value.itemID] = math.round(self.attribute.ExpGain)
			end
			self.world.allItemList[value.itemID]:addExp(expgain[value.itemID],adjTime)
		end
	end
	goldgain={}
	if (self.attribute.GoldGain>0) then
		for kkkk5,value in pairs(heroes) do
					extra=0
			if (isset(self.heroAttack,value.itemID) and self.heroAttack[value.itemID]+10 >= self.world.gameTime) then
				extra=self.world.setting.COINtower
			end
			if (goldgain[""..value.itemID]~=nil) then
				goldgain[""..value.itemID]=goldgain[""..value.itemID]+math.round(self.attribute.GoldGain+extra)
			else
				goldgain[""..value.itemID]=math.round(self.attribute.GoldGain+extra)
			end
			self.world.allItemList[value.itemID]:addGold(goldgain[""..value.itemID],adjTime)
		end
	end
end



function STower:__findTarget() 

	local attRange=self:getAttRange()
	local enemy
	if (self.team=="A") then
		enemy = self.world.teamB
	else	
		enemy = self.world.teamA
	end
	local shortDistance = 999999999
	for kkk,value in pairs( enemy ) do
		local isContinue = true
		if (value:isDead() )  then
			isContinue = false
		end
		if ( value.className=="SMonster") then
			isContinue = false
		end
		if (isset( value.attribute.parameterArr, "NOFIGHT") and value.attribute.parameterArr["NOFIGHT"]==1) then
			isContinue = false
		end
		if (value.invincibleTime>self.world.gameTime) then
			isContinue = false
		end
		if (isset(value.statusList,173)) then 
			isContinue = false
		end
		if ( isContinue ) then
			local d = value:colliding(attRange,0,0,self.itemID)
			if (d >= 0) then
				if (value.attribute.actorType==1 and (value.attribute.ID==25 or value.attribute.ID==26)) then
					d=d+20000
				elseif (value.attribute.actorType==1 and (value.attribute.ID==29)) then
					d=d+10000
				elseif (value.attribute.actorType==0) then
					d=d+10000
				elseif (value.attribute.ID ~= 5 and value.attribute.ID ~= 6) then
					d=d+5000
				end
				if (d<shortDistance) then
					shortDistance=d
					self.attackTarget=value.itemID
				end
			end
		end
	end
	return shortDistance
end

function STower:adjHP(hp, forceSync  , must ,zz) 
	if( forceSync == nil) then
		forceSync = false
	end
	if( must == nil ) then
		must = false
	end

	if (hp<0) then
		return STower.super.adjHP(self, hp,forceSync,must,zz)
	end

	return false
end

function STower:calHurted(itemID,hitValue) 

	if (hitValue['APFIX'] >= -99999) then
		hitValue['APFIX']=0
	end
	hitValue['isCRI']=false
	return STower.super.calHurted(self,itemID,hitValue)
end

function STower:hurted(itemID,bulletID,mode,hitValue,adjTime) 

	local towers
	if (self.team=="A") then
		towers=self.world.towerAList
	else
		towers=self.world.towerBList
	end


	local deadTower={}
	for kkkk ,obj in pairs(towers) do
		local isContinue = true;
		-- print("STower 总部不能攻击 self.towerGroup", self.towerGroup)
		-- print("STower 总部不能攻击 obj.towerGroup", obj.towerGroup)
		if (self.towerGroup ~= "" and obj.towerGroup ~= "" and obj.towerGroup ~= self.towerGroup) then
			isContinue = false
		end

		if( isContinue )then	
			if (obj:isDead()) then
				--print("STower set "..obj.attribute.ID.." 为1")
				deadTower[""..(obj.attribute.ID)]=1
			elseif (deadTower[""..(obj.attribute.ID)]==nil) then
				--print("STower set "..obj.attribute.ID.." 为0")
				deadTower[""..(obj.attribute.ID)]=0
			end
		end
	end -- end of for
	if (table.nums(deadTower) > 0 ) then 
		for key,v in pairs (deadTower) do
			if ( v==0 and self.world.tonumber(key)<self.attribute.ID) then
				-- print("STower 总部不能攻击 key", key)
				-- print("STower 总部不能攻击 attribute.ID", self.attribute.ID)
				-- print("STower 总部不能攻击 deadTower", self.world.cjson.encode(deadTower))
				return 0
			end
		end
	end

	if (self.world.allItemList[itemID].attribute.actorType==0 and self.world.allItemList[itemID].teamOrig ~= self.team) then
		self.heroAttack[itemID]=self.world.gameTime
		self.heroAttackMode=true
	end

	if (self.lastAttackTimeTower<self.world.gameTime-8) then
		if (self.attribute.ID<13)  then
			-- self.syncMsg['bc'][]=array('zz'=>2,'mid'=>28,'t'=>self.team,'d'=>adjTime)
			local tmpMsg = {}
			tmpMsg = {zz=2,mid=28,t=self.team,d=adjTime}
			self:updateSyncMsg({bc={tmpMsg}})
		else
			-- self.syncMsg['bc'][]=array('zz'=>2,'mid'=>35,'t'=>self.team,'d'=>adjTime)
			local tmpMsg = {}
			tmpMsg = {zz=2,mid=35,t=self.team,d=adjTime}
			self:updateSyncMsg({bc={tmpMsg}})
		end
	end
	self.lastAttackTimeTower=self.world.gameTime

	local hurt = STower.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
	return hurt
end

function STower:prepareHit(mode,adjTime,buff) 
	if( buff == nil ) then
		buff = false
	end
	local hitValueBoth = STower.super.prepareHit(self,mode,adjTime,buff)
	local attRange=self:getAttRange()
	local found=false
	local enemy
	if (self.team=="A") then
		enemy = self.world.teamB
	else	
		enemy = self.world.teamA
	end
	for kkk,value in pairs(enemy) do
		local isContinue = true

		if (value:isDead()) then
			isContinue = false
		end
		if (value.className ~= "SSoldier") then
			isContinue = false
		end
		if( isContinue ) then
			local d = value:colliding(attRange,0,0,self.itemID)
			if (d >= 0) then
				found=true
				break
			end
		end
	end
	local rate
	if (found or (self.world.levelAIHigh == false and self.world.is3V3 == false)) then
		rate=self.world.setting.towerContHit1
		if (self.attribute.buffAttribute.ASPD>0) then
			self.attribute.buffAttribute.ASPD=0
		end
	else
		rate=self.world.setting.towerContHit2
		if (self.attribute.ID>=13 and self.attribute.ID<=14) then
-- 				hitValueBoth['E']['isCRI']=true
			if (isset(self.attribute.parameterArr["ASPDNOSOLDIER"]) and self.attribute.parameterArr["ASPDNOSOLDIER"]>0) then
				self.attribute.buffAttribute.ASPD=self.attribute.parameterArr["ASPDNOSOLDIER"]
			end
		end
	end
	hitValueBoth['E']['ADADJ'] = (1+self.lastHitCount*rate/100)*100
	return hitValueBoth
end

function STower:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	return STower.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime)
end

function STower:addBuff(buff) 
	buff:release()
	return	nil		
end

function STower:__getAllInfo(adjtime,rReturn) 
	if adjtime==nil then adjtime = 0 end
	if (rReturn == nil or rReturn == false) then
		return nil
	end
	return STower.super.__getAllInfo(self,0,rReturn)
end

function STower:getAllInfo() 
	return self:__getAllInfo(0,true)
end



return STower
