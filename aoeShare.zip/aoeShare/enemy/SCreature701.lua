local SCreature701 = class("SCreature701", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature701:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature701" 
	end 

	SCreature701.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.parentMode = 0
	self.parentID = 0
end 


function SCreature701:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	SCreature701.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
	
	local obj = self.world.allItemList[itemID]
	self.world:D('jaylog SCreature701:directHurtCallBack',obj.statusList[620])
	--obj:addStatusList({zz=3,i=obj.itemID,s=999,r=self.world.gameTime,t=9999,p1=701,p2=self.world.tonumber(self.world.setting['takeFireTime']),p3=targetID,p4=dist})
	-- self.world:D('jaylog SCreature701:directHurtCallBack obj:',obj.actorType,obj.teamOrig,self.teamOrig)
	if obj.parent==nil and self.teamOrig~=obj.teamOrig and obj.statusList[620]==nil and obj.statusList[41]==nil then
		obj:addStatusList({zz=3,i=obj.itemID,s=999,r=self.world.gameTime,t=0.5,p2=10,p3=50330,p4=3})
	end
	
end

function SCreature701:createInit()
	self.world:D('xiaomalog test1')
	local lifeTime=99999
	local attributes = {}
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['INEVITABLEHIT'] = 1
	attributes['buffParameter']['RANGE'] = self.attribute.width * self.world.setting.AdjustAttRange
	--attributes['buffParameter']['INEVITABLEHIT'] = 1
	attributes['buffParameter']['creatureDirectHurCallBack'] = self.itemID
	attributes['buffParameter']['buffIntervalTime'] = 0.3
	-- attributes['buffParameter']['INVICINBLE_RATE'] = 100
	-- attributes['buffParameter']['BUFFTIME'] = 99999
	attributes['buffParameter']['buffType'] = 1
	attributes['buffParameter']['Effect'] = -1

	attributes['BUFFTIME'] = 99999
	-- self.world:D('jaylog SCreature701:createInit addBuff ',self.attribute.width)
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0),attributes,lifeTime,{99},0,self.itemID,self.itemID,0.1)
	-- buff.debug = true
	self:addBuff(buff)

	self.world:D('xiaomalog test')
end

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SCreature701:goToDead(itemID,mode,adjTime,bonus)
	if self.parentID>0 then
		local obj = self.world.allItemList[self.parentID]
		local skill = obj.attribute.skills[self.parentMode] 
		local parameters = skill.parameters 
		local existEnemy = false
		for k1,v1 in pairs(self.world.allItemList) do
			if self.world.tonumber(v1.attribute.roleId)==701 and not v1:isDead() then
				existEnemy = true
				break
			end
		end
		if not existEnemy then
			self.world:D('jaylog SCreature701 not existEnemy removeStatusList 83')
			obj:removeBuffToID(obj:__skillID2buffID(skill.skillID,0))
			obj:removeStatusList(41)
			obj:removeStatusList(83)
			obj:addStatusList({s=982,r=self.world:getGameTime(),t=1})
			obj:setCoolDownTime(self.world:getGameTime())
			obj.modeStartAI = self.world:getGameTime()
			for k,v in pairs(self.world.itemListFilter.heroList) do
				if v.actorType==0 and not v:isAIObj() then
	 	 			v:setAutoBlocked(true)
	 	 		end
			end
		end
	end
	local obj = self.world.allItemList[itemID]
	obj:removeStatusList(999)
	SCreature701.super.goToDead(self,itemID,mode,adjTime,bonus)
end



return SCreature701