local SEnemyInWorld103 = class("SEnemyInWorld103", require("gameroomcore.SHeroBase"))

function SEnemyInWorld103:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld103.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SEnemyInWorld103