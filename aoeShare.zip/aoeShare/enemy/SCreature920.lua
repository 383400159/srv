local SCreature920 = class("SCreature920",  require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature920:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature920" 
	end 

	SCreature920.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end 

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SCreature920:goToDead(itemID,mode,adjTime,bonus)
	SCreature920.super.goToDead(self,itemID,mode,adjTime,bonus)  
	self.world:D('jaylog SCreature920:goToDead',self.world.gameFlag['goToSiteItemID'])
	self.world.gameFlag['goToSiteItemID'] = 0
end

return SCreature920 
