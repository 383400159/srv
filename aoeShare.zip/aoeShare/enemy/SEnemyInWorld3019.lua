local SEnemyInWorld3019 = class("SEnemyInWorld3019", require("gameroomcore.SHeroBase"))

function SEnemyInWorld3019:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld3019.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end


return SEnemyInWorld3019
