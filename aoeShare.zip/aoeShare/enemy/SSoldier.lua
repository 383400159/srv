--require "gameroom.functions"
--require "gameroom.Config"

-- local cjson = require( Config.cjson )

local SSoldier = class("SSoldier" ,require("gameroom.enemy.SEnemy"))

function SSoldier:ctor(world,id,team,posX,posY,level)
		if( self.className == nil ) then
			self.className = "SSoldier"
		end
		SSoldier.super.ctor(self,world,id,team,posX,posY,level)
		self.towerList={}
		self.towerComplete=1
		self.towerAttack=0
end


function SSoldier:setTowerList(towerList) 
	self.towerList=towerList
end

function SSoldier:move() 
	SSoldier.super.move(self)
	-- local breaker = 1 
	-- if (table.nums(self.paths) == 0 and table.nums(self.towerList) > 0 and self.attackTarget == nil 
	-- 	and self.checkOverLapTime<self.world.gameTime and self.lastCoolDownTime<self.world.gameTime) then

	-- 	while (isset(self.towerList ,self.world.tonumber(self.towerComplete) ) and breaker >= 1 ) do

	-- 		--   次级运行权
	-- 		breaker = 2

	-- 		local towerList = self.towerList[self.world.tonumber(self.towerComplete)]

	-- 		local towers
	-- 	--	if ( not self:_checkBehind(self.posX,self.posY,towerList.posX,towerList.posY) ) then
	-- 		if true then
	-- 			if (self.team=="A") then
	-- 				towers=self.world.towerBList
	-- 			else
	-- 				towers=self.world.towerAList
	-- 			end

	-- 			for kkkk ,obj in pairs (towers) do
	-- 				if( breaker >= 2 ) then
	-- 					if (math.abs(towerList.posX - obj.posX)<8 and math.abs(towerList.posY-obj.posY)<8 and not obj:isDead()) then
	-- 						if( self.towerComplete == nil )then
	-- 							self.towerComplete = 1
	-- 						end
	-- 						self.towerComplete = self.towerComplete - 1
	-- 						self.towerAttack=obj.itemID
	-- 						breaker = 0 -- break 2层
	-- 						break 
	-- 					end
	-- 				end
	-- 			end
	-- 			if( breaker >= 1 ) then
	-- 				self.towerComplete = self.towerComplete +1
	-- 			end
	-- 		else
	-- 			break
	-- 		end
	-- 	end
	-- 	if self.towerComplete<1 then self.towerComplete = 1 end
	-- 	if (isset(self.towerList ,self.towerComplete )) then
	-- 		local towerList = self.towerList[self.towerComplete]
	-- 		self:moveTo(towerList.posX,towerList.posY)
	-- 	end
	-- else
	-- end
end

function SSoldier:fight() 
	SSoldier.super.fight(self)
end

function SSoldier:goToDead(itemID,adjTime,expgain,goldgain,bonus,mode) 
	if( mode == nil )then
		mode = 0 
	end

	SSoldier.super.goToDead(self,itemID,adjTime,expgain,goldgain,bonus,mode)
end

function SSoldier:__findTarget() 

end 


function SSoldier:calHurted(itemID,hitValue) 
	return SSoldier.super.calHurted(self , itemID, hitValue)
end

function SSoldier:hurted(itemID,bulletID,mode,hitValue,adjTime) 
	local hurt = SSoldier.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
	if (self.attackTarget == nil and hurt>0 and itemID>0 
		and (isset(hitValue,'Effect') == false or hitValue['Effect']==1 or hitValue['Effect']==9)) then
		local visRange=self:getVisRange()
		if (isset(self.world.allItemList[itemID].statusList,37) == false
			and self.world.allItemList[itemID]:colliding(visRange,0,0,self.itemID)>=0 and self.world.allItemList[itemID].team ~= self.team) then
			self.attackTarget=itemID
			self.lastFoundTargetTime=self.world.gameTime
		end
	end
	return hurt
end

function SSoldier:prepareHit(mode,adjTime,buff) 
	if( buff == nil ) then
		buff = false
	end
	local hitValueBoth = SSoldier.super.prepareHit(self ,mode,adjTime,buff)
	return hitValueBoth
end

function SSoldier:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	return SSoldier.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime)
end



return SSoldier
