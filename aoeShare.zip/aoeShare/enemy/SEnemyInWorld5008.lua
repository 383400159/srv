local SEnemyInWorld5008 = class("SEnemyInWorld5008", require("gameroomcore.SHeroBase"))

function SEnemyInWorld5008:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld5008.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SEnemyInWorld5008