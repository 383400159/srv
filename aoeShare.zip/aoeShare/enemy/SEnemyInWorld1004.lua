local SEnemyInWorld1004 = class("SEnemyInWorld1004", require("gameroomcore.SHeroBase"))

function SEnemyInWorld1004:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld1004.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.nextAtkTime = 0
	self.oldItemID = 0
end


---自动攻击..........
--返回true代表执行world的AI false执行AI
function SEnemyInWorld1004:_autoFight()
	--self:D("保卫雅典娜 _autoFight ")
	if self.team=="" and self.world:getGameTime()>self.nextAtkTime then
		
		local atkItemID = self.world.baseID
		if self.lastHurtItemID>0  then
			local obj = self.world.allItemList[self.lastHurtItemID]
			local lastTime = 10
			if not obj:isDead() and (self.lastHurtTime+lastTime)>self.world:getGameTime() then
				atkItemID =self.lastHurtItemID
			end
		end
		
		if atkItemID~=self.oldItemID then
			self.prepareSkillAttackNum = 0
		end
		self:skillAttack(1,atkItemID)
		--self:D("保卫雅典娜 ",atkItemID,self.itemID)
		self.nextAtkTime = self.world:getGameTime()+1
		self.oldItemID = atkItemID
		return true
	end
	return true
end


--- 自动移动chud
-- @return null
function SEnemyInWorld1004:_autoMove()

	return true
end


return SEnemyInWorld1004