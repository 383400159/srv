local SCreature803 = class("SCreature803",  require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature803:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature803" 
	end 
	self.mode2bulletID = 0
	self.mode2oldX = 0
	self.mode2oldY = 0
	--子弹结束
	self.mode2bulletEndTime = 0
	self.nextSkillID = 0
	SCreature803.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end 

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SCreature803:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SCreature803.super.prepareHit(self,mode,adjTime,buff) 
	debuglog("猪撞人.......放技能 prepareHit")
	if (mode==2 or mode==4) then
		hitValueBoth['bulletAttackMode4Passthru'] = false
	end
	return hitValueBoth 
end 

function SCreature803:_autoMove()

end

function SCreature803:_autoFight()

end

--- 准备攻击前置设置，在prepareHit之后执行，call父类
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SCreature803:prepareSkillAttackCustom(mode,target,x,y,adjTime,syncMsg)  
	if (mode==2 or mode==4) then 
		debuglog("猪撞人.......放技能 prepareSkillAttackCustom")
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 

		local toX,toY = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,(skill.atkDis-parameters.MOVECUT)/self.world.setting.AdjustAttRange)
		local ret
		self:D("prepareHit 飞飞飞........ x tox y toy distance ",self.posX,toX,self.posY,toY,skill.atkDis/self.world.setting.AdjustAttRange)
		ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX,self.posY+toY) 
		self.mode2oldX = self.posX
		self.mode2oldY = self.posY
		local delaytime =parameters.MOVECUT/skill.bulletSpeed
		self.mode2time = self.world:getGameTime()+adjTime+delaytime
		local d =self.world.mPow(self.world.mPow(toX-self.posX,2) + self.world.mPow(toY-self.posY,2),0.5)

		self:moveTo(toX,toY,false,6,skill.bulletSpeed,adjTime+delaytime) 
		syncMsg['a']['x'] = toX
		syncMsg['a']['y'] = toY
		self.mode2bulletID = self.lastBulletID
		self.mode2bulletEndTime = 0
		self:D("野猪飞飞飞XX:",d,d*self.world.setting.AdjustAttRange/skill.bulletSpeed,self.moveToEndTime,self.world:getGameTime(),delaytime,adjTime)
		self:D("野猪飞飞飞:",d*self.world.setting.AdjustAttRange/skill.bulletSpeed,(self.moveToEndTime-self.world:getGameTime()),self.world:getGameTime(),adjTime)
		self:addStatusList({s=parameters.ADDSELFSTATUS2,r=self.world:getGameTime(),t=(d*self.world.setting.AdjustAttRange/skill.bulletSpeed)-(adjTime+delaytime),i=self.itemID},adjTime+delaytime)
		self:addStatusList({s=4331,r=self.world:getGameTime(),t=(self.moveToEndTime-self.world:getGameTime())+parameters.CUTTIME2,i=self.itemID},0)
	end
	--SELFSTATUSA=83;SADDSELFSTATUSTIMEA=2;ADDSELFSTATUS2=97;ADDSELFSTATUSTIME2=9999;IGNOREHITTIME=0.1;MOVECUT=300;BACKWARD=500;BACKWARDSPEED=1500;HITTIME2=0.25;CUTTIME2=2.8;HITTHICKNESS=100
	SCreature803.super.prepareSkillAttackCustom(self,mode,target,x,y,adjTime,syncMsg)  
end 

--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SCreature803:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	local ret = SCreature803.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	if ret>0 and (mode==2 or mode==4) then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		if self.world:getGameTime()>(self.mode2time+parameters.IGNOREHITTIME) then
			local obj = self.world.allItemList[itemID] 
			
			--local toX,toY = self.world.map:getXYLength(self.posX,self.posY,obj.posX,obj.posY,parameters.BACKWARD/self.world.setting.AdjustAttRange)
			local toX,toY = self.world.map:getXYLength(self.mode2oldX,self.mode2oldY,self.posX,self.posY,parameters.BACKWARD/self.world.setting.AdjustAttRange)
			ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
			local toX1,toY1 = self.world.map:getXYLength(self.mode2oldX,self.mode2oldY,self.posX,self.posY,(self.world:getGameTime()-self.mode2time)*skill.bulletSpeed/self.world.setting.AdjustAttRange)
			ret1,toX1,toY1=self.world.map:findPointStraightLineNearest(self.mode2oldX,self.mode2oldY,self.mode2oldX+toX1,self.mode2oldY+toY1) 
			--obj:moveTo(toX,toY,false,5,parameters.BACKWARDSPEED,0) 	
			self:moveTo(toX1,toY1,true,1)
			self:removeStatusList(parameters.ADDSELFSTATUS2) 	
			self:addStatusList({s=parameters.ADDSELFSTATUS2,r=self.world:getGameTime(),t=0.01,i=self.itemID},0)
			self:D("野猪飞飞飞: 停掉移动")
			if self.mode2bulletEndTime==0 then
				self.mode2bulletEndTime = self.world:getGameTime() + parameters.HITTHICKNESS/skill.bulletSpeed
				obj:moveTo(toX,toY,false,5,parameters.BACKWARDSPEED,(parameters.HITTIME2 + parameters.HITTHICKNESS/skill.bulletSpeed))
				local attributes = table.deepcopy(self:getPrepareHithitValue())
				attributes['DIZZY_RATE'] = 100
				attributes['Effect'] = -1
				attributes['BUFFTIME'] = (parameters.HITTIME2 + parameters.HITTHICKNESS/skill.bulletSpeed) 
				self:directHurtToDalay(mode,obj.itemID,attributes,0)
			else
				obj:moveTo(toX,toY,false,5,parameters.BACKWARDSPEED,parameters.HITTIME2)
				local attributes = table.deepcopy(self:getPrepareHithitValue())
				attributes['DIZZY_RATE'] = 100
				attributes['Effect'] = -1
				attributes['BUFFTIME'] = parameters.HITTIME2
				self:directHurtToDalay(mode,obj.itemID,attributes,0)
			end
		end
	end
	return ret 
end 




--- fight motion,执行攻击动作
-- @param null
-- @return null
function SCreature803:move()
	if self.mode2bulletEndTime>0 and self.world:getGameTime()>self.mode2bulletEndTime then
		if self.world.bulletList[self.mode2bulletID]~=nil then
			self.world.bulletList[self.mode2bulletID]:setDead()
		end
		self.mode2bulletEndTime = 0
	end

	--获得父类攻击的目标
	if self.nextSkillID~=nil and self.nextSkillID>0    then
		local ret = self:skillAttack(self.nextSkillID,0,self.atkX,self.atkY)	
		debuglog("猪撞人......."..self.world.cjson.encode(ret))
		if ret~=nil and ret~=false then
			self.nextSkillID = 0
		end
		return 0
	end
	SCreature803.super.move(self)
end


--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SCreature803:goToDead(itemID,mode,adjTime,bonus)
	SCreature803.super.goToDead(self,itemID,mode,adjTime,bonus)  
end

return SCreature803 
