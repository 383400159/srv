local SCreature285 = class("SCreature285", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature285:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature285" 
	end 

	self.lastMoveTime = 0
	self.nextSkillTime = 0
	SCreature285.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)	
end 

function SCreature285:createInit()
	local skill = self.attribute.skills[4] 
	local parameters = skill.parameters 

	local lifeTime=999999
	local attributes = {}
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['INEVITABLEHIT'] = 1
	attributes['buffParameter']['RANGE'] = parameters.RANGE
	-- attributes['buffParameter']['FIXHURT'] =   7
	attributes['buffParameter']['ADDSTATUS'] =   parameters.ADDSTATUS
	attributes['buffParameter']['ADDSTATUSTIME'] = parameters.ADDSTATUSTIME
	attributes['buffParameter']['buffIntervalTime'] = 0.3
	attributes['buffParameter']['buffType'] = 14
	attributes['buffParameter']['Effect'] = -1
	attributes['BUFFTIME'] = 0.5
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0),attributes,lifeTime,{99},0,self.itemID,self.itemID,0)
	--buff.debug = true
	self:addBuff(buff)


	local skill = self.attribute.skills[5] 
	local parameters = skill.parameters 
	local lifeTime=999999
	local attributes = {}
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['INEVITABLEHIT'] = 1
	attributes['buffParameter']['RANGE'] = parameters.RANGE
	-- attributes['buffParameter']['FIXHURT'] =   8
	attributes['buffParameter']['ADDSTATUS'] = parameters.ADDSTATUS
	attributes['buffParameter']['ADDSTATUSTIME'] = parameters.ADDSTATUSTIME
	attributes['buffParameter']['buffIntervalTime'] = 0.3
	attributes['buffParameter']['buffType'] = 1
	attributes['buffParameter']['Effect'] = -1
	attributes['BUFFTIME'] = 0.5
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(1),attributes,lifeTime,{99},0,self.itemID,self.itemID,0)
	--buff.debug = true
	self:addBuff(buff)

end

--- move motion , call every update loop
-- @return null
function SCreature285:move() 
	if self.lastMoveTime == 0 then
		self.lastMoveTime = self.createTime
	end

	if self.paths~=nil and #self.paths>0  then
		self.lastMoveTime = self.world:getGameTime()
	end

	if (self.world:getGameTime()-self.lastMoveTime)>3 and self.world:getGameTime()>self.nextSkillTime then
		self:D("怪长久未动 放技能",self,lastMoveTime,self.world:getGameTime())
		self.nextSkillTime = self.world:getGameTime()+15
		self:addStatusList({s=4119,r=self.world.gameTime,t=99,i=self.itemID})
	end
	SCreature285.super.move(self)
end



return SCreature285 
