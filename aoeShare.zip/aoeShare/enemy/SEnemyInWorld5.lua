local SEnemyInWorld5 = class("SEnemyInWorld5", require("gameroomcore.SHeroBase"))

function SEnemyInWorld5:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld5.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SEnemyInWorld5