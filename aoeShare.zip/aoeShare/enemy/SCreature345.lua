local SCreature345 = class("SCreature345", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature345:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature345" 
	end 

	SCreature345.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.nextTime = 0
	--world:D("SCreature345:ctor...........")
end 


function SCreature345:move() 
	SCreature345.super.move(self)
	--self.world:D("SCreature345:move...........")
	if self.nextTime>self.world:getGameTime() then
		local r = 1000/self.world.setting.AdjustAttRange
		toX,toY = self.world.map:getXYLength(self.posX,self.posY,self.endPosX,self.endPosY,r) 
		local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX,self.posY+toY) 
		self:skillAttack(1,0,toX,toY)
		self.nextTime = 0
		-- local creatureID=self.world:addCreature(self.world.tostring(180),"",self.posX,self.posY,nil,1,0)
		-- local obj  = self.world.allItemList[creatureID]
		-- obj:setDeadTime(1) 
		self.world:D("激活陷阱怪 攻击",self.itemID,self.world:getGameTime())
	end

end

return SCreature345 