local SCreature502 = class("SCreature502", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature502:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature502" 
	end 

	SCreature502.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end 



function SCreature502:createInit()
	local attributes = {}
	attributes['IMMUNEAD_RATE'] = 100 
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0),attributes,9999,{},0,self.itemID,self.itemID)
	self:addBuff(buff)
end

return SCreature502