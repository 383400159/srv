local SCreature970 = class("SCreature970", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature970:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature970" 
	end 

	SCreature970.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	--陷阱组
	self.xjlist = {}
	--下次召唤的时间
	self.nextTime = 0
	world:D("SCreature345:ctor...........")
	
end 


function SCreature970:move() 
	SCreature970.super.move(self)
	
	local r = 1000/self.world.setting.AdjustAttRange
	toX,toY = self.world.map:getXYLength(self.posX,self.posY,self.endPosX,self.endPosY,r) 
	local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX,self.posY+toY) 
	self:skillAttack(1,0,toX,toY)

end

--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SCreature970:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	local ret = SCreature970.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	if  self.world:getGameTime()>self.nextTime then
		--生成一个陷阱怪
		-- local creatureID=self.world:addCreature(self.world.tostring(345),"",313.7/2,405.4/2,nil,1,0)
		-- local obj  = self.world.allItemList[creatureID]
		-- obj:setDeadTime(5) 
		self.world:D("激活陷阱怪")
		for k,v in pairs(self.xjlist) do
			v.nextTime = self.world:getGameTime() + v.nextCD
			self.world:D("激活陷阱怪",v.itemID,v.nextTime,self.world:getGameTime())
		end
		self.nextTime = self.world:getGameTime() + self.nextCD
	end
	return ret 
end 



return SCreature970 