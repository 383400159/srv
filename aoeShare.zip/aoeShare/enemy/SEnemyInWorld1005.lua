local SEnemyInWorld1005 = class("SEnemyInWorld1005", require("gameroomcore.SHeroBase"))

function SEnemyInWorld1005:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld1005.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.pickBackTime = 0
end




--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SEnemyInWorld1005:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	local hurt = SEnemyInWorld1005.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
	if ( hitValue['creatureDirectHurCallBack'] ~= nil) then
		----debuglog('jaylog SMonster:directHurtCallBack itemID:'..self.itemID..' fAid:'..self.world.gameFlag['flag'..self.flagType..'ID']..' flagType:'..self.flagType..' roleId:'..self.attribute.roleId..' targetItemID:'..itemID)
		--水晶回调start
		if self.world.gameFlag['flag'..self.flagType..'ID']~=nil and self.world.gameFlag['flag'..self.flagType..'ID']==self.itemID and hitValue['creatureDirectHurCallBack']~=itemID then
			local obj = self.world.allItemList[itemID]
			if obj.actorType==0 and obj.statusList[37]~=nil and self.attribute.roleId==self.world.setting['energyBType'] then
				self.world.gameCounter['points'..obj.team] = self.world.gameCounter['points'..obj.team] + self.world.tonumber(self.world.setting['enemy_energy'])
				obj:setCounter('getFlag')
				--self.world.gameFlag['getFlagAID'] = 0
				obj:updateSyncMsg({bc={{mid=53,p1=obj.itemID}}})
				obj:removeStatusList(37)
				obj:removeBuffToID(obj.energyBuffID)
				-- 加状态到水晶台用于延迟重生
				local tableObj = self.world.allItemList[self.world.gameFlag['flagTableAID']]
				--debuglog('jaylog SEnemyInWorld1005:directHurtCallBack add 991 status A')
				tableObj:addStatusList({s=991,r=self.world.gameTime,t=self.world.tonumber(self.world.setting['energyTime1']),p1=1})
				--self.world:addMonster(self.world.setting['energyAType'],self.world.setting['energyACoordinateX'],self.world.setting['energyACoordinateY'],'A',1,'')
				if self.world.gameCounter['points'..obj.team]>=self.world.tonumber(self.world.setting['win_energy']) then
					self.world.gameFlag['isGameOver'] = true
					self.world.gameFlag['winTeam'] = obj.team
				elseif (self.world.gameCounter['points'..obj.team]+self.world.tonumber(self.world.setting['enemy_energy']))>=self.world.tonumber(self.world.setting['win_energy']) then
					--debuglog('jaylog SHeroInWorld2:goToDead bc60 id:'..itemID)
					obj:updateSyncMsg({bc={{zz=3,mid=60,i=obj.itemID}}})
				end
				self.world:syncPointsInfo()
				--debuglog('jaylog SMonster:directHurtCallBack getFlagA to energyB objTeam:'..obj.team..' points'..obj.team..':'..self.world.gameCounter['points'..obj.team])
			end
			if obj.actorType==0 and obj.statusList[51]~=nil and self.attribute.roleId==self.world.setting['energyAType'] then
				self.world.gameCounter['points'..obj.team] = self.world.gameCounter['points'..obj.team] + self.world.tonumber(self.world.setting['enemy_energy'])
				obj:setCounter('getFlag')
				--self.world.gameFlag['getFlagBID'] = 0
				obj:updateSyncMsg({bc={{mid=54,p1=obj.itemID}}})
				obj:removeStatusList(51)
				obj:removeBuffToID(obj.energyBuffID)
				local tableObj = self.world.allItemList[self.world.gameFlag['flagTableBID']]
				--debuglog('jaylog SEnemyInWorld1005:directHurtCallBack add 991 status B')
				tableObj:addStatusList({s=991,r=self.world.gameTime,t=self.world.tonumber(self.world.setting['energyTime2']),p1=2})
				--self.world:addMonster(self.world.setting['energyBType'],self.world.setting['energyBCoordinateX'],self.world.setting['energyBCoordinateY'],'B',1,'')
				if self.world.gameCounter['points'..obj.team]>=self.world.tonumber(self.world.setting['win_energy']) then
					self.world.gameFlag['isGameOver'] = true
					self.world.gameFlag['winTeam'] = obj.team
				elseif (self.world.gameCounter['points'..obj.team]+self.world.tonumber(self.world.setting['enemy_energy']))>=self.world.tonumber(self.world.setting['win_energy']) then
					--debuglog('jaylog SHeroInWorld2:goToDead bc60 id:'..itemID)
					obj:updateSyncMsg({bc={{zz=3,mid=60,i=obj.itemID}}})
				end
				self.world:syncPointsInfo()
				--debuglog('jaylog SMonster:directHurtCallBack getFlagB to energyA objTeam:'..obj.team..' points'..obj.team..':'..self.world.gameCounter['points'..obj.team])
			end
			-- and obj.statusList[41]==nil
			if obj.actorType==0 and obj.statusList[37]==nil and obj.statusList[51]==nil and ((self.attribute.roleId==self.world.setting['energyAPick']) or (self.attribute.roleId==self.world.setting['energyBPick']) or (self.attribute.roleId==self.world.setting['energy'..self.flagType..'Type'] and self.flagType~=obj.teamOrig)) then
				--debuglog('jaylog SMonster:directHurtCallBack add status 999 p1:'..self.attribute.roleId..' p2:'..self.world.setting['TakeTime'])
				if self.pickBackTime>0 then
					self.pickBackTime = self.pickBackTime + 3
				end
				obj:addStatusList({zz=3,s=999,r=self.world.gameTime,t=0.5,p1=self.world.tonumber(self.attribute.roleId),p2=self.world.tonumber(self.world.setting['TakeTime']),p3=self.world.tonumber(self.itemID)})
			end
		end
		--水晶回调end
	end
end

function SEnemyInWorld1005:move()
	SEnemyInWorld1005.super.move(self)
	--超时无人捡就自动回到原点
	if self.pickBackTime>0 and self.pickBackTime<self.world.gameTime then
		--debuglog('jaylog SHeroInWorld2:move:'..self.pickBackTime..' gameTime:'..self.world.gameTime..' id:'..self.world.setting['energy'..self.flagType..'Type']..' x:'..self.world.setting['energy'..self.flagType..'CoordinateX']..' y:'..self.world.setting['energy'..self.flagType..'CoordinateY'])
		self.world:addMonster(self.world.setting['energy'..self.flagType..'Type'],self.world.setting['energy'..self.flagType..'CoordinateX'],self.world.setting['energy'..self.flagType..'CoordinateY'],self.flagType,1,'')
		self.attribute.HP = 0
		self.pickBackTime = 0
		self:directHurt(self.itemID,1,{},0)
		self:updateSyncMsg({bc={{zz=2,mid=61,t=self.flagType}}})
		if self.flagType=='A' then
			self:updateSyncMsg({bc={{zz=2,mid=62,t='B'}}})
		else
			self:updateSyncMsg({bc={{zz=2,mid=62,t='A'}}})
		end
	end
end

function SEnemyInWorld1005:processCallBack(teamNo)
	if teamNo==1 then
		team = 'A'
	else
		team = 'B'
	end
	--debuglog('jaylog SEnemyInWorld1005:processRebirth bc58 '..team)
	self:updateSyncMsg({bc={{zz=2,mid=58,t=team}}})
	if team=='A' then
		--debuglog('jaylog SEnemyInWorld1005:processRebirth bc59 teamB')
		self:updateSyncMsg({bc={{zz=2,mid=59,t='B'}}})
	else
		--debuglog('jaylog SEnemyInWorld1005:processRebirth bc59 teamA')
		self:updateSyncMsg({bc={{zz=2,mid=59,t='A'}}})
	end
	self.world:addMonster(self.world.setting['energy'..team..'Type'],self.world.setting['energy'..team..'CoordinateX'],self.world.setting['energy'..team..'CoordinateY'],team,1,'')
end

return SEnemyInWorld1005