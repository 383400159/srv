local SCreature289 = class("SCreature289", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature289:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature289" 
	end 

	SCreature289.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)	
end 


function SCreature289:createInit()

	-- local skill = self.attribute.skills[5] 
	-- local parameters = skill.parameters 
	-- local lifeTime=999999
	-- local attributes = {}
	-- attributes['buffParameter']={}
	-- attributes['BUFFONLY']=1
	-- attributes['INEVITABLEHIT'] = 1
	-- --attributes['buffParameter']['RANGE'] = parameters.RANGE
	-- attributes['buffParameter']['RANGE']=1000
	-- attributes['buffParameter']['FIXHURT'] =   8
	-- --attributes['buffParameter']['ADDSTATUS'] = parameters.ADDSTATUS
	-- --attributes['buffParameter']['ADDSTATUSTIME'] = parameters.ADDSTATUSTIME
	-- attributes['buffParameter']['buffIntervalTime'] = 0.3
	-- attributes['buffParameter']['buffType'] = 1
	-- attributes['buffParameter']['Effect'] = -1
	-- attributes['BUFFTIME'] = 0.5
	-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(1),attributes,lifeTime,{99},0,self.itemID,self.itemID,0)
	-- --buff.debug = true
	-- self:addBuff(buff)
end

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SCreature289:goToDead(itemID,mode,adjTime,bonus)
	local skill = self.attribute.skills[2] 
	local parameters = skill.parameters 
	local creatureID = self.world:addCreature(self.world.tostring(parameters.ENEMY),self.teamOrig,self.posX,self.posY,self.parent,1,parameters.DELAY)
	local obj = self.world.allItemList[creatureID] 
	obj:setDeadTime(parameters.LIFETIME) 	
	-- self:skillAttack(2)
	ret = SCreature289.super.goToDead(self,itemID,mode,adjTime,bonus) 
end


return SCreature289 
