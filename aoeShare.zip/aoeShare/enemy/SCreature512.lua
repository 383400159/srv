local SCreature512 = class("SCreature512", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature512:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature512" 
	end 

	SCreature512.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end 



function SCreature512:createInit()
	local attributes = {}
	attributes['REBOUND_UPFIX'] = 100
	attributes['REBOUND_UPFIX_RATE'] = 100
	attributes['BUFFTIME'] = 9999
	local bufftime = 9999
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0),attributes,9999,{},0,self.itemID,self.itemID,0)
	self:addBuff(buff)
end


--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SCreature512:goToDead(itemID,mode,adjTime,bonus)
	local obj  = self.world.allItemList[itemID]
	local attributes = {}
	attributes['ATK_UP'] = 100 
	attributes['ATK_UP_RATE'] = 100 
	attributes['BUFFTIME'] = 5
	local buff = require("gameroomcore.SBuff").new(self.world,obj:__skillID2buffID(0),attributes,5,{},0,obj.itemID,obj.itemID)
	obj:addBuff(buff)
	SCreature512.super.goToDead(self,itemID,mode,adjTime,bonus)
end


return SCreature512