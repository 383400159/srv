local SEnemyInWorld4 = class("SEnemyInWorld4", require("gameroomcore.SHeroBase"))

function SEnemyInWorld4:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld4.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SEnemyInWorld4