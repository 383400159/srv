local SCreature753 = class("SCreature753", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature753:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature753" 
	end 

	SCreature753.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.nextTime = 0
	self.nextBuffTime = 0
end 

function SCreature753:move() 
	SCreature753.super.move(self)

	if self.world:getGameTime()>self.nextTime then
		local poslist = {{311.7,81.7},{323.9,84.4},{358.8,85},{370.4,83.6}}
		local r = self.world.formula:getRandnum(1,4)
		self:skillAttack(1,0,poslist[r][1]/2,poslist[r][2]/2)
		local r1 = self.world.formula:getRandnum(2,5)
		self.nextTime = self.world:getGameTime() + r1
		self.world:D("投石车 攻击",self.itemID,self.world:getGameTime())
	end

end


--- 受傷害計算,调用SActor的hurted
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SCreature753:hurted(itemID,bulletID,mode,hitValue,adjTime)
	hitValue['FIXREHP'] = 0
	local hurt = SCreature753.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
	return hurt
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SCreature753:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SCreature753.super.prepareHit(self,mode,adjTime,buff) 
	if mode==1 then
		local hitValueNew={}
		local r = self.world.formula:getRandnum(30,60)
		self:D("大炮的cd 减少:"..r)
		hitValueNew['BOSSREDUCECD_DOWN'] = r
		hitValueNew['BOSSREDUCECD_DOWN_RATE'] = 100
		hitValueNew['BUFFTIME'] = 30
		self:directHurt(self.itemID,mode,hitValueNew,0) 	
	end
	return hitValueBoth 
end 


return SCreature753