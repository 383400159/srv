local SCreature510 = class("SCreature510", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature510:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature510" 
	end 

	SCreature510.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end 

--- 計算傷害
-- @param itemID int - 攻擊方itemID
-- @param hitValue table - 計算參數
-- @return hurt float - 傷害值
function SCreature510:calHurted(itemID,hitValue)
	local ret = SCreature510.super.calHurted(self,itemID,hitValue)
	if ret>self.attribute.HP then
		local obj  = self.world.allItemList[itemID]
		if obj.attribute.roleId%5~=4 then
			if self.attribute.HP>0 then
				ret = self.attribute.HP-1
			end 
		end
	end

	return ret
end

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SCreature510:goToDead(itemID,mode,adjTime,bonus)
	local obj  = self.world.allItemList[itemID]
	local attributes = {}
	attributes['IMMUNEAP_RATE'] = 100 
	local buff = require("gameroomcore.SBuff").new(self.world,obj:__skillID2buffID(0),attributes,5,{},0,obj.itemID,obj.itemID)
	obj:addBuff(buff)
	SCreature510.super.goToDead(self,itemID,mode,adjTime,bonus)
end


return SCreature510