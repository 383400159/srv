 local SEnemyInWorld101 = class("SEnemyInWorld101", require("gameroomcore.SHeroBase"))

function SEnemyInWorld101:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld101.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SEnemyInWorld101