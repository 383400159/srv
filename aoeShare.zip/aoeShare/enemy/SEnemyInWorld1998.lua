local SEnemyInWorld1998 = class("SEnemyInWorld1998", require("gameroomcore.SHeroBase"))

function SEnemyInWorld1998:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld1998.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end


return SEnemyInWorld1998
