local SCreature273 = class("SCreature273", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature273:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature273" 
	end 

	SCreature273.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.parentMode = 0
	self.parentID = 0
end 


function SCreature273:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	-- self.world:debuglog('jaylog SCreature273:directHurtCallBack',self.world.cjson.encode(self.statusList[4101]),self.itemID,itemID)
	SCreature273.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
	if self.statusList[4101]~=nil and self.itemID~=itemID then
		local obj = self.world.allItemList[itemID]
		-- self.world:D('jaylog SCreature273:directHurtCallBack obj:',obj.actorType,obj.teamOrig,self.teamOrig)
		if obj.actorType==0 and obj.parent==nil and self.teamOrig~=obj.teamOrig then
			-- obj:addStatusList({zz=3,s=999,r=self.world.gameTime,t=0.5,p1=self.world.tonumber(self.attribute.roleId),p2=self.world.tonumber(self.world.setting['takeFireTime']),p3=self.world.tonumber(self.itemID)})
			-- self.world:D('jaylog SCreature273:directHurtCallBack statusList:',self.world.cjson.encode(obj.statusList[100]))
			self.world:D('jaylog SCreature273:directHurtCallBack hitValue:',self.world.cjson.encode(hitValue),itemID,self.itemID,self:isDead(),self.attribute.HP,self.world.cjson.encode(obj.statusList[100]),self.world.cjson.encode(obj.statusList[984]))
			if hitValue['isCheckChange']~=nil and obj.statusList[100]==nil then
				if obj.statusList[984]~=nil then
					local dist = obj:distance(self.posX,self.posY)
					local targetID = self.itemID
					if (obj.statusList[984]['p3']~=targetID and dist<obj.statusList[984]['p4']) or (obj.statusList[984]['p3']==targetID) then
						obj:removeStatusList(984)
						obj:addStatusList({zz=3,i=obj.itemID,s=984,r=self.world.gameTime,t=9999,p1=273,p2=self.world.tonumber(self.world.setting['takeFireTime']),p3=targetID,p4=dist})
						self.world:D('jaylog SCreature273:directHurtCallBack statusList 1:',self.world.cjson.encode(obj.statusList[984]))
					end
				-- else
				-- 	local dist = obj:distance(self.posX,self.posY)
	 		-- 		local targetID = self.itemID
	 		-- 		obj:addStatusList({zz=3,i=obj.itemID,s=984,r=self.world.gameTime,t=9999,p1=273,p2=self.world.tonumber(self.world.setting['takeFireTime']),p3=targetID,p4=dist})
	 		-- 		self.world:D('jaylog SCreature273:directHurtCallBack statusList 2:',self.world.cjson.encode(obj.statusList[984]))
				end
				if obj.statusList[984]==nil then
					local dist = obj:distance(self.posX,self.posY)
					local targetID = self.itemID
					obj:addStatusList({zz=3,i=obj.itemID,s=984,r=self.world.gameTime,t=9999,p1=273,p2=self.world.tonumber(self.world.setting['takeFireTime']),p3=targetID,p4=dist})
				end
			end
			if hitValue['isPickUp']~=nil and obj.canPickUp then-- and self.statusList[4104]~=nil
				if obj.statusList[100]==nil and obj.statusListRemoved[100]==nil then
					self.world:D('jaylog SCreature273:directHurtCallBack ',itemID,self.itemID,self.world.cjson.encode(obj.statusList[100]))
					obj:skillAttack(9)
					obj.startMode9 = self.itemID
					self.world:D('jaylog SCreature273:directHurtCallBack end ',itemID,self.itemID,self.world.cjson.encode(obj.statusList[100]))
				end
			end
		end
	end
end

function SCreature273:createInit()
	local lifeTime=99999
	local attributes = {}
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['INEVITABLEHIT'] = 1
	attributes['buffParameter']={isPickUp=1}
	attributes['buffParameter']['RANGE'] = self.attribute.width * self.world.setting.AdjustAttRange
	--attributes['buffParameter']['INEVITABLEHIT'] = 1
	attributes['buffParameter']['creatureDirectHurCallBack'] = self.itemID
	attributes['buffParameter']['buffIntervalTime'] = 0.5
	attributes['buffParameter']['buffType'] = 1
	attributes['buffParameter']['Effect'] = -1

	attributes['BUFFTIME'] = 99999
	-- self.world:D('jaylog SCreature273:createInit addBuff ',self.attribute.width)
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0),attributes,lifeTime,{99},0,self.itemID,self.itemID,0.1)
	-- buff.debug = true
	self:addBuff(buff)

	local lifeTime=99999
	local attributes = {}
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['INEVITABLEHIT'] = 1
	attributes['buffParameter']={isCheckChange=1}
	attributes['buffParameter']['RANGE'] = self.attribute.parameterArr['NEARCHECKDIS']
	--attributes['buffParameter']['INEVITABLEHIT'] = 1
	attributes['buffParameter']['creatureDirectHurCallBack'] = self.itemID
	attributes['buffParameter']['buffIntervalTime'] = 0.5
	attributes['buffParameter']['buffType'] = 1
	attributes['buffParameter']['Effect'] = -1
	attributes['BUFFTIME'] = 99999
	-- self.world:D('jaylog SCreature273:createInit addBuff ',self.attribute.width)
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0),attributes,lifeTime,{99},0,self.itemID,self.itemID,0.1)
	-- buff.debug = true
	self:addBuff(buff)
end

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SCreature273:goToDead(itemID,mode,adjTime,bonus)
	if self.parentID>0 then
		local obj = self.world.allItemList[self.parentID]
		local skill = obj.attribute.skills[self.parentMode] 
		local parameters = skill.parameters 
		local existEnemy = false
		for k1,v1 in pairs(self.world.allItemList) do
			if self.world.tonumber(v1.attribute.roleId)==273 and not v1:isDead() then
				existEnemy = true
				break
			end
		end
		if not existEnemy then
			self.world:D('jaylog SCreature273 not existEnemy removeStatusList 83')
			obj:removeBuffToID(obj:__skillID2buffID(skill.skillID,0))
			obj:removeStatusList(41)
			obj:removeStatusList(83)
			obj:addStatusList({s=982,r=self.world:getGameTime(),t=1})
			obj:setCoolDownTime(self.world:getGameTime())
			obj.modeStartAI = self.world:getGameTime()
			for k,v in pairs(self.world.itemListFilter.heroList) do
				if v.actorType==0 and not v:isAIObj() then
	 	 			v:setAutoBlocked(true)
	 	 		end
			end
		end
	end
	SCreature273.super.goToDead(self,itemID,mode,adjTime,bonus)
end

return SCreature273