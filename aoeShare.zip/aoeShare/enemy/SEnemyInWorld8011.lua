local SEnemyInWorld8011 = class("SEnemyInWorld8011", require("gameroomcore.SHeroBase"))

function SEnemyInWorld8011:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld8011.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

--- 檢查角色info是否需要同步, 及做相應處理
-- @return null
function SEnemyInWorld8011:syncInfo()
	local ret = SEnemyInWorld8011.super.syncInfo(self)
	if self.attribute.roleId=='904' and self.lastSyncTime<self.world:getGameTime() and (self.lastSyncHP~=self.attribute.HP or self.lastSyncMP~=self.attribute.MP) then
		self:getInfo()
		self.lastSyncHP = self.attribute.HP
		self.lastSyncMP = self.attribute.MP
		self.lastSyncTime = self.world:getGameTime() + 1
	end
	return ret
end

function SEnemyInWorld8011:adjHP(hp,forceSync,must,zz) 
	if self.attribute.roleId=='904' and hp>0 then
		hp = 0
	end
	return SEnemyInWorld8011.super.adjHP(self,hp,forceSync,must,zz)
end

return SEnemyInWorld8011