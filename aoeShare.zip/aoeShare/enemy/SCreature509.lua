local SCreature509 = class("SCreature509", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature509:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature509" 
	end 
	SCreature509.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self:D("保卫雅典娜 SCreature509 0")

end 

--- 計算傷害
-- @param itemID int - 攻擊方itemID
-- @param hitValue table - 計算參數
-- @return hurt float - 傷害值
function SCreature509:calHurted(itemID,hitValue)
	local ret = SCreature509.super.calHurted(self,itemID,hitValue)
	self:D("保卫雅典娜 这怪不能被杀死 0",ret,self.attribute.HP)
	if ret>self.attribute.HP then
		self:D("保卫雅典娜 这怪不能被杀死",ret,self.attribute.HP)
		local obj  = self.world.allItemList[itemID]
		if obj.attribute.roleId%5~=2 then
			if self.attribute.HP>0 then
				ret = self.attribute.HP-1
				self:D("保卫雅典娜 这怪不能被杀死 减少伤害",ret,self.attribute.HP)
			end 
		end
	end

	return ret
end

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SCreature509:goToDead(itemID,mode,adjTime,bonus)
	local obj  = self.world.allItemList[itemID]
	self:D("保卫雅典娜 这怪不能被杀死 击杀怪以后加buff",obj.attribute.roleId)
	local attributes = {}
	attributes['REBOUND_UPFIX'] = 100
	attributes['REBOUND_UPFIX_RATE'] = 100
	attributes['BUFFTIME'] = 5
	local buff = require("gameroomcore.SBuff").new(self.world,obj:__skillID2buffID(0),attributes,5,{},0,obj.itemID,obj.itemID,0)
	obj:addBuff(buff)
	SCreature509.super.goToDead(self,itemID,mode,adjTime,bonus)
end

return SCreature509