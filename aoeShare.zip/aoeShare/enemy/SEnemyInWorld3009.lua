local SEnemyInWorld3009 = class("SEnemyInWorld3009", require("gameroomcore.SHeroBase"))

function SEnemyInWorld3009:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld3009.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SEnemyInWorld3009