local SEnemyInWorld2007 = class("SEnemyInWorld2007", require("gameroomcore.SHeroBase"))

function SEnemyInWorld2007:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld2007.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end


return SEnemyInWorld2007
