local SEnemy
if worldForHero==0 then
	SEnemy = class("SEnemy" ,require("gameroomcore.SHeroBase"))
else
	SEnemy = class("SEnemy" ,require("gameroom.enemy.SEnemyInWorld"..worldForHero))
end

--- Constructor
-- @param world object - world object
-- @param id int - enemyID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param level int - enemy起始级别
-- @return null
function SEnemy:ctor(world,id,team,posX,posY,level)
	if self.className==nil then
		self.className="SEnemy"
	end

	SEnemy.super.ctor(self,world,id,team,posX,posY,level)

	-- self.lastFoundTargetTime=0	--上次寻敌时间
	-- self.checkMoveOverLapTime=0	--上次检查移动碰撞时间
	-- self.outOfCtlTime = 0	-- 失控時間，但可以自動攻擊，SActor已有
	-- self.outOfCtlAllTime = 0	-- 全失控時間，SActor已有
	-- self.invincibleTime = 0		-- 無敵時間  — 可以用buff 取代，SActor已有
	-- self.lastCoolDownTime = 0		-- 所有動作的CD時間，SActor已有
	-- 怪类型
	self.actorType = 1

	self.AImode = 1
end 

--- init funtion 初始化属性参数
-- @param id int - enemy id
-- @param posX int - 起始坐标X
-- @param posY int - 起始坐标Y
-- @param level int - 起始级别
-- @return null
function SEnemy:__init(id,posX,posY,level)
	self.world:__loadEnemy(id)
	self.world:__loadEnemySkill(id)
	--self:D('jaylog start __init.....'..self.world.cjson.encode(self.world.enemyAll[id]))
	self.attribute=require("gameroom.attribute.SAttributeEnemy").new(id,level,self)
	self.attribute.roleId = id

end

--- fight motion,enemy执行攻击动作,子类重新定义逻辑
-- @param null
-- @return null
function SEnemy:fight() 
	return SEnemy.super.fight(self)
end

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SEnemy:goToDead(itemID,mode,adjTime,bonus) 
	if(  mode == nil )then
		mode =0
	end
	--木桩死后不release
	if self.attribute.roleId==113 then
		self.deadTime = self.world:getGameTime() + 9999
	end
	SEnemy.super.goToDead(self,itemID,mode,adjTime,bonus)
	self.isRelease = true

end -- end of SEnemy:goToDead

function SEnemy:__findTarget() 
	--
end

--- 设置技能限制施放时间
-- @param skill table - 角色某一招技能的所有设置值
-- @return null
function SEnemy:useCDTime(skill)
	self:D("SEnemy useCDTime:",skill.rank)
	if skill.parameters.CDTIME==nil then
		return nil
	end
	--判断是否要走扣CD流程
	local cooldown = 0
	----debuglog(" skill :"..self.world.cjson.encode(skill['parameters']))
	cooldown = skill.parameters.CDTIME
	

	skill.lastCoolDownValue = cooldown
	skill.lastCoolDownTime = self.world:getGameTime() + skill.lastCoolDownValue
	self:D("SEnemy useCDTime1:",skill.rank,skill.lastCoolDownTime,self.world:getGameTime(),skill.lastCoolDownValue)
end

--- 自动释放技能 
-- @return null
function SEnemy:_autoFight()
	--self:D("146_autoFight roleId:"..self.attribute.roleId.." runAI:"..(self.autoFightAI.runAI and "true" or "false").." isDead:"..(self:isDead() and " true" or "false").." AIlastCoolDown:"..self.AIlastCoolDown.." gameTime:"..self.world.gameTime )
	local ret=SEnemy.super._autoFight(self)
	--self:D("146_autoFight roleId:",self.attribute.roleId,ret,self.autoFightAI.runAI)
	if not ret and self.AIlastCoolDown<self.world.gameTime and not self:isDead() and self.autoFightAI.runAI then
		--需要获得自动攻击的item  释放skill的id
		--self:D("146_autoFight 1")
		--local oldtime = self.world.callBack:getServerTime()
		local targetID,skillID,cdTime=self.autoFightAI:execute()
		--local newtime = self.world.callBack:getServerTime()
		--self:D("_autoFight time :"..(oldtime-newtime).." itemID:"..self.itemID)
		if self.world.tonumber(targetID)>0 then
			self:D("策划SEASON放了什么技能 fenglog checkEnemy roleId:",self.attribute.roleId," targetID:",targetID," skillID:",skillID," cdTime:",cdTime)
			--self:D("SAI targetID:"..targetID)
			self:skillAttack(skillID,self.world.tonumber(targetID))
			--self:D("_autoFight self.prepareSkillAttackNum:"..self.prepareSkillAttackNum)
			self.autoFightAI.runMoveAI = false
			self.AIlastATKtoMove = self.world:getGameTime()-0.5
			self.AIlastAutoMove = self.world:getGameTime()
			--假设是鬼爪移动过程中是无敌的
			if self.attribute.roleId=="109" or self.attribute.roleId=="166"  then
				self:MoveAddINVICINBLE()
			end
		end
		--boss寻敌cd
		self.AIlastCoolDown = self.world:getGameTime() + cdTime

	end

	if not self:isDead() then
		-- if self.AIlastATKtoMove+10<self.world:getGameTime() and self.AIlastATKtoMove+12>self.world:getGameTime() then 
		-- 	self.autoFightAI.forceLost = true
		-- end
		if self.AIlastATKtoMove+10<self.world:getGameTime() then 
			---self:D("AIlastATKtoMove:"..self.AIlastATKtoMove.." runMoveAI true")
			
			if	self.attribute.parameterArr['NOMOVEAI']==nil then
				self.autoFightAI.runMoveAI = true
			end
		else
			self.autoFightAI.runMoveAI = false
		end
	end
end

--- 潜入地下的怪在地下无敌
-- @return null
function SEnemy:MoveAddINVICINBLE()
	if self.paths~=nil and #self.paths>0 then
		local t = self.paths[#self.paths].t - self.world.gameTime
		self:D("鬼爪添加无敌...........t:",t)
		local attributes = {}
		attributes['INVICINBLE_RATE'] = 100 
		attributes['Effect'] = -1
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0),attributes,t,{},0,self.itemID,self.itemID)
		self:addBuff(buff)
		--self:addStatusList({s=76,r=self.world.gameTime,t=t,i=self.itemID})	
	end
end

--- 自动移动chud
-- @return null
function SEnemy:_autoMove()
	--body


	local ret=SEnemy.super._autoMove(self)
	if not ret then
		self.autoFightAI:autoMove()
	end
	--假设是鬼爪移动过程中是无敌的
	--self:D("保卫雅典娜 SEnemy_autoMove")
	local needINVICINBLE = false
	for k,v in pairs(self.world.gameRoomSetting.moveEnemyINVICINBLE) do
		if self.attribute.roleId==v then
			needINVICINBLE = true
		end
	end
	if not ret and needINVICINBLE then -- and self.attribute.roleId=="109" or self.attribute.roleId=="114" then
		self:MoveAddINVICINBLE()
	end
end

-- function SEnemy:skillAttackAI(mode,itemID,x,y)
-- 	if itemID ==nil then
-- 		itemID = 0
-- 	end
-- 	if x ==nil then
-- 		x = 0
-- 	end
-- 	if y ==nil then
-- 		y =0
-- 	end
-- 	--self:D("SBoss:skillAttackAI mode=" .. mode .. " itemID="..itemID.." x="..x .." y="..y)
-- 	return itemID,x,y

-- end --  SBoss:skillAttackAI
-- -- end



-- function SEnemy:__protectHero() 
	
-- 	return {}
-- end -- 	function SEnemy:__protectHero() 

-- function SEnemy:_checkBehind(x1,y1,x2,y2,adjust)
-- 	if adjust==nil then adjust = 0 end
-- 	if self.team=="A" then adjust = adjust * -1 end
-- 	if self.world.towerBPos.posY==nil or self.world.towerBPos.posX==nil or self.world.towerAPos.posY==nil or self.world.towerAPos.posX==nil then
-- 		self:D('============================================================ found bug '..self.className..self.itemID)
-- 		return true
-- 	end
-- 	local ret = ((y1-y2+adjust)*(self.world.towerBPos.posY-self.world.towerAPos.posY)-(self.world.towerAPos.posX-self.world.towerBPos.posX)*(x1-x2))
-- 	return self.team=="A" and ret<0 or ret>0
-- end

--- 計算傷害
-- @param itemID int - 攻擊方itemID
-- @param hitValue table - 計算參數
-- @return hurt float - 傷害值
function SEnemy:calHurted(itemID,hitValue) 
	return SEnemy.super.calHurted(self,itemID,hitValue)
end

-- 受伤
--- 受傷害計算,调用SActor的hurted
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SEnemy:hurted(itemID,bulletID,mode,hitValue,adjTime) 
	if self.attribute.parameterArr['NOBECURE']~=nil and self.attribute.parameterArr['NOBECURE']==1 then
		hitValue['FIXREHP'] = 0
	end

	return SEnemy.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
end

-- 准备打人
--- 準備攻擊參數，调用SActor的prepareHit
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SEnemy:prepareHit(mode,adjTime,buff) 
	if( buff == nil)then
		buff = false
	end

	local hitValueBoth = SEnemy.super.prepareHit(self,mode,adjTime,buff)
	return hitValueBoth
end

-- 打人
--- 發動攻擊,调用SActor的hitTarget
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SEnemy:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 

	local hurt =  SEnemy.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime)
	--攻击人以后消失
	if hurt>0 and hitValue['HITDEAD']~=nil and hitValue['HITDEAD']>0 then
		self:D("小怪自杀........")
		self.attribute.HP=0
		self:addStatusList({s=42,r=self.world.gameTime,t=16,i=self.itemID},2)
		self:directHurt(self.itemID,1,{},0)
	end

	return hurt
end

-- 广播信息
--- 廣播 同步角色 all info,调用SActor的__getAllInfo
-- @param adjTime float - 調整時間
-- @param isReturn bool - 直接返回結果, 不廣播
-- @return infoMsg table - 角色info
function SEnemy:__getAllInfo(adjTime,rReturn) 
	if adjTime==nil then adjTime = 0 end
	if(rReturn == nil) then
		rReturn = false
	end
	if (rReturn == false) then
		return nil
	end
	
	local result = self:__getInfo(adjTime,isReturn)
	result['i'] = self.itemID
	result['t'] = self.teamOrig
	if self.attribute.roleIdChange~=99999 then
		result['a'] = self.world.tonumber(self.attribute.roleIdChange)
	else
		result['a'] = self.world.tonumber(self.attribute.roleId)
	end
	if self.attribute.actorTypeChange~=99999 then
		result['at'] = self.attribute.actorTypeChange
	else
		result['at'] = self.attribute.actorType
	end
	result['mhp'] = self.attribute:getMaxHP()
	result['x'] = self.posX
	result['y'] = self.posY
	result['l'] = self.attribute.level
	result['d'] = adjTime
	result['si'] = self.skinNum
	result['mz'] = self.mapZone
	if self.blockLen~=0 then
		result['bl'] = self.blockLen
	end
	if self.blockWidth~=0 then
		result['bw'] = self.blockWidth
	end
	if self.attribute.STANDPOINT>0 then
		result['jd'] = self.attribute.STANDPOINT
	end
	if self.parent~=nil then
		result['ti'] = self.parent.itemID
	end
	local infoType = 0
	if self.attribute.loginIDNotShow~=0 or self.attribute.bloodNotShow~=0 then
		infoType = self.attribute.loginIDNotShow + self.attribute.bloodNotShow*10
	end
	result['v'] = infoType
	if isReturn then
		return result
	end
	self:updateSyncMsg({i=result})
	return result
end

--- 广播同步角色，__getAllInfo的简称，用于公共调用
-- @param null
-- @return infoMsg table - 角色info
function SEnemy:getAllInfo(adjtime) 
		return self:__getAllInfo(adjtime,true)
end

--- 同步角色info
-- @param adjTime float - 調整時間
-- @param isReturn bool - 直接返回結果, 不廣播
-- @return infoMsg table - 角色info
function SEnemy:__getInfo(adjTime,isReturn)
	-- local result = {i=self.itemID,hp=self.world.mFloor(self.attribute.HP),hpe=self.world.mFloor(self.attribute.HPEXTRA),mp=self.world.mFloor(self.attribute.MP),
	local result = {i=self.itemID,hp=self.world.mFloor(self.attribute.HP),s=(self:isDead() and 9 or 0),d=adjTime}
	--self:D('jaylog __getInfo : '..self.world.cjson.encode(isReturn)..' '..self.world.cjson.encode(result))
	if isReturn then
		return result
	end
	self:updateSyncMsg({i=result})
	return result	
end

-- bonus 返回获奖情况
function SEnemy:calculateBonus(targetObj,myTeamHeroes,bonusGroup,bonusType,bonusArrAll,bonus)
		
end

-- ---检查最近的敌人
-- -- @param to
-- function SEnemy:_checkNear()
-- 	--local enemy = self.itemListFilter.heroList
-- 	local enemy = self.world.allItemList
-- 	local range = self:getVisRange()
-- 	local toX,toY = self.initX,self.initY
-- 	local len,oldlen = 0,0
-- 	local attackID = 0
-- 	for k,v in pairs(enemy) do
-- 		self:D('jaylog sTeam:'..self.team..' tgTeam:'..v.team..' id:'..self.itemID..' '..v.itemID)
-- 		if v.team~=self.team then
-- 			oldlen = len
-- 			local pos = v.nextPosition
-- 			len = self.world.map:distance(pos.x,pos.y,self.posX,self.posY,v.itemID,self.itemID)
-- 			self:D('jaylog oldlen:'..oldlen..' len:'..len)
-- 			if oldlen>=len or oldlen==0 then
-- 				toX,toY = pos.x,pos.y
-- 				targetID = v.itemID
-- 			end
-- 		end
-- 	end
-- 	return toX,toY,targetID
-- end

-- --攻击
-- function SEnemy:goToFight()
-- 	if self.attackTarget~=nil then
-- 		if self.world.allItemList[self.attackTarget]==nil then
-- 			self.attackTarget = nil
-- 		end
-- 	end
-- 	if self.attackTarget~=nil then
-- 		local targetObj = self.world.allItemList[self.attackTarget]
-- 		local pos = targetObj.nextPosition
-- 		local range = self:getVisRange()
-- 		local distance = targetObj:colliding(range,0,0,self.itemID)
-- 		if distance>=0 and self.lastCoolDownTime<=self.world.gameTime then
-- 			if math.mod(self.world.gameTime,5)==0 then
-- 				self:D('jaylog colliding targetID:'..self.attackTarget..' x:'..targetObj.posX..' y:'..targetObj.posY..' selfID:'..self.itemID)
-- 			end
-- 			--self:skillAttack(1,targetObj.itemID,targetObj.posY,targetObj.posY)
-- 			local hitTime = 100 / (self.attribute.ASPD)-- 出招時間
-- 			local hurtTime = math.round( ( ( distance - targetObj.attribute.width ) / 300)*self.world.setting.walkingSpeed,2)
-- 			local randsk=self.world.formula:getRandnum(1,4)
-- 			local hitValueBoth = self:prepareHit(randsk,0)
-- 			self:D('jaylog goToFight hitValue : '..self.world.cjson.encode(hitValueBoth)..' HP:'..self.attribute.HP..' MAXHP:'..self.attribute.MaxHP)
-- 			self.lastBulletID = self.world:addBullet(1,self.itemID,hitTime+self.world.gameTime,self.attackTarget,targetObj.posX,targetObj.posY,false,hitValueBoth)
			
-- 			if( self.syncMsg['a'] == nil )then
-- 				self.syncMsg['a'] = {}
-- 			end
-- 			self.syncMsg['a'][#self.syncMsg['a'] + 1]={i=self.itemID,m=randsk,t=(0),ti=self.attackTarget,ht=hurtTime+hitTime,sx=self.posX,sy=self.posY,x=targetObj.posX,y=targetObj.posY}
				
-- 			self.dirty=true
-- 			if (self.status ~= 9) then
-- 				self.status=3
-- 			end
-- 			self.lastCoolDownTime=self.world.gameTime + hitTime
-- 			self:moveTo(self.posX,self.posY)
-- 			self.syncMsg['m'] = nil
-- 			self.lastFightTime=self.world.gameTime
-- 			self.lastFoundTargetTime=self.world.gameTime
-- 			if targetObj:isDead() then
-- 				self.attackTarget = nil
-- 			end
-- 		else
-- 			if self.world.mMod(self.world.gameTime,5)==0 then
-- 				self:D('jaylog not colliding targetID:'..self.attackTarget..' moveTo:x '..pos.x..' y '..pos.y..' selfID:'..self.itemID)
-- 			end
-- 			self:moveTo(pos.x,pos.y)
-- 		end
-- 	end
-- end

-- --逃跑
-- function SEnemy:escapeNow()
-- 	if self.attribute.HP<500 then
-- 		self.attackTarget = nil
-- 		self:moveTo(self.initX,self.initY)
-- 	end
-- end

-- --巡逻
-- function SEnemy:searchTarget()
-- 	if self.attribute.roleId==104 then
-- 		if self.attackTarget==nil then
-- 			local toX,toY,targetID = self:_checkNear()
-- 			self:D('jaylog searchTarget:toX'..toX..' toY'..toY..' id:'..self.itemID..' toID:'..targetID)
-- 			self:moveTo(toX,toY)
-- 			self.attackTarget = targetID
-- 		else
-- 			self:goToFight()
-- 		end
-- 	end
-- end

--- 复活, 游戏loop
-- @param null
-- @return null
function SEnemy:revive()
end


function SEnemy:createInit()
	if self.attribute.parameterArr['IMMUNEAD']~=nil or self.attribute.parameterArr['IMMUNEAP']~=nil or self.attribute.parameterArr['IMMUNECONTROL']~=nil then
		local attributes = {}
		local hitValueNew = self:getPrepareHithitValue()
		attributes = hitValueNew
		attributes['BUFFONLY']=1
		if self.attribute.parameterArr['IMMUNECONTROL']~=nil then
			attributes['IMMUNECONTROL_RATE'] = 100
		end
		if self.attribute.parameterArr['IMMUNEAD']~=nil then
			attributes['IMMUNEAD_RATE'] = 100 
		end
		if self.attribute.parameterArr['IMMUNEAP']~=nil then
			attributes['IMMUNEAP_RATE'] = 100 
		end
		attributes['buffType'] = 3
		attributes['BUFFTIME'] = 99999
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0,99),attributes,99999,{},0,self.itemID,self.itemID,0)
		self:addBuff(buff)
	end
end
return SEnemy
