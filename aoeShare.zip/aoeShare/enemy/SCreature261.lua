local SCreature261 = class("SCreature261", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature261:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature261" 
	end 

	SCreature261.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end 

--boss免控
function SCreature261:addIMMUNECONTROLBUFF()
	--IMMUNECONTROL_RATE=100

	--debuglog("addIMMUNECONTROLBUFF boss itemID:"..self.itemID)
	-- --debuglog("boss allItemList:"..self.world.cjson.encode(self.world.allItemList[self.itemID]))
	local attributes = {}
	local hitValueNew = self:getPrepareHithitValue()
	attributes = hitValueNew
	attributes['BUFFONLY']=1
	attributes['IMMUNECONTROL_RATE'] = 100
	attributes['buffType'] = 3
	attributes['BUFFTIME'] = 99999
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0,99),attributes,99999,{},0,self.itemID,self.itemID,0)
	self:addBuff(buff)
end

function SCreature261:init()
	local attributes = {}
	attributes['IMMUNEAD_RATE'] = 100 
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,9999,{},0,self.itemID,self.itemID,0.1)
	self:addBuff(buff)
end


--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SCreature261:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	if mode==1 then
		debuglog("虚空给boss加魔免和反弹")
		local obj  = self.world.allItemList[self.parent.itemID]
		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters
		--加魔免buff
		-- local attributes = {}
		-- attributes['IMMUNEAP_RATE'] = 100 
		-- --ADADJ=0;APADJ=0;ADDSTATUS=4077;ADDSTATUSTIME=0.5;REFLECTAP_UPFIX_RATE=100;REFLECTAP_UPFIX=50;IMMUNEAP_RATE=100;BUFFTIME=0.5
		-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,parameters.BUFFTIME,{},0,self.itemID,self.itemID,0.1)
		-- obj:addBuff(buff)

		local hitValueNew = hitValue
		self.parent:directHurtToDalay(mode,self.parent.itemID,hitValueNew,0)
  		--self.parent:directHurt(self.parent.itemID,mode,hitValueNew,0) 
	end
	--ret = SCreature261.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	return ret 
end 



return SCreature261 