local SEnemyInWorld3018 = class("SEnemyInWorld3018", require("gameroomcore.SHeroBase"))

function SEnemyInWorld3018:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld3018.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end


return SEnemyInWorld3018
