local SCreature303 = class("SCreature303", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature303:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature303" 
	end 

	SCreature303.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)	
end 

function SCreature303:createInit()
	local skill = self.attribute.skills[1] 
	local parameters = skill.parameters 
	local lifeTime=999999
	local attributes = {}
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['INEVITABLEHIT'] = 1
	-- attributes['buffParameter']['RANGE']=1000
	attributes['buffParameter']['RANGE'] = parameters.RANGE
	attributes['buffParameter']['ADDSTATUS'] = 4282
	attributes['buffParameter']['ADDSTATUSTIME'] = 0.3
	--attributes['buffParameter']['FIXHURT'] =   8
	attributes['buffParameter']['buffIntervalTime'] = 0.2
	attributes['buffParameter']['buffType'] = 1
	attributes['buffParameter']['Effect'] = -1
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(1),attributes,lifeTime,{99},0,self.itemID,self.itemID,0)
	--buff.debug = true
	self:addBuff(buff)
end


--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SCreature303:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	ret = SCreature303.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	return ret 
end 

return SCreature303 
