local SEnemyInWorld9001 = class("SEnemyInWorld9001", require("gameroomcore.SHeroBase"))

function SEnemyInWorld9001:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld9001.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SEnemyInWorld9001