local SCreature = class("SCreature" , require("gameroom.enemy.SSoldier"))

	function SCreature:ctor(world,id,team,posX,posY,level)
		if( self.className == nil ) then
			self.className = "SCreature"
		end
		self.createTime=0
		self.lastFollowTime=0
		
		SCreature.super.ctor(self,world,id,team,posX,posY,level)
	    self.initX = posX --  initial positionX
	    self.initY = posY --  initial positionY
	-- print( "我的在 ctor ...... createTime "..id .." .. " ..self.world.gameTime .. "\n")
	end

	function SCreature:__init(id,posX,posY,level) 
		SCreature.super.__init(self,id,posX,posY,level)
		self.attribute.parent=self
		--		self.nextPosition = require("Position").new(posX,posY)
		--		self.nextPositionForFight = self.nextPosition
		--		self.targetPosition = self.nextPosition
		self.createTime = self.world.gameTime
		self:D("boss2 小怪创建时间 itemID:"..self.attribute.roleId.." createTime:"..self.createTime)
	-- print( "我的在 ...... createTime "..id .." .. " ..self.world.gameTime .. "\n")
	end

	--- 设置父类 可设可不设
	-- @param time int - 设置死亡时间
	-- @return null
	function SCreature:setDeadTime(time) 
	-- print( "我的在 ...... DeadTime "..id .." .. " ..time.. "\n")
		self.attribute.parameterArr["DEAD"]=time
	end
	--- 设置父类 可设可不设
	-- @param parent obj - 父类的obj
	-- @return null
	function SCreature:setParent(parent) 
		-- self:D("我的父亲是: " .. parent.itemID)
		self.parent=parent
	end

	function SCreature:fastMove() 
	
	end


	function SCreature:move() 

		SCreature.super.move(self)
		--self:D("SCreature parameterArr"..self.world.cjson.encode(self.attribute.parameterArr))
		if self.attribute.parameterArr["DEAD"]~=nil then
			if (self.createTime+self.attribute.parameterArr["DEAD"]<=self.world.gameTime or (self.parent~=nil and self.parent:isDead())) then
				self.world:D("boss2 小怪死亡时间 itemID:"..self.attribute.roleId.." gameTime:"..self.world.gameTime.." DEAD:"..self.attribute.parameterArr["DEAD"])
				self.attribute.HP=0
				self:directHurt(self.itemID,0,{finalFixHurt=0},0)
				self:D("set SCreature itemID:"..self.itemID.." DEAD roleID:"..self.attribute.roleId)
			end
		end

		if (self.createTime>self.world.gameTime) then
			return nil
		end
		if ( (self.attribute.parameterArr["NOMOVE"] ~= nil ) and  self.world.tonumber(self.attribute.parameterArr["NOMOVE"])==1) then
			--self:D("SCreature。。。。。不允许移动。。。。。。。。。。。")
			return nil
		end

	end


	function SCreature:goToDead(itemID,adjTime,expgain,goldgain,bonus,mode)
		if(mode == nil) then
			mode = 0 
		end 
		if ( self.attribute.parameterArr["SYNCPARENTHP"] ~= nil) then
			self.parent:directHurt(itemID,0,{finalFixHurt=1},0)
		end
		self:D("召唤物 goToDead"..self.itemID)
		SCreature.super.goToDead(self,itemID,adjTime,expgain,goldgain,bonus,mode)
	end


	function SCreature:adjHP(hp,forceSync,must,zz) 
		if( forceSync == nil )then
			forceSync = false
		end
		if ( must == nil) then
			must = false
		end

		if ( self.attribute.parameterArr["SYNCPARENTHP"] ~= nil  and must == false) then
			return self.parent:adjHP(hp,forceSync,must,zz)
		else
			if(self.attribute.HP+hp <=1 and self.parent~=nil and isset(self.parent.statusList[249])) then
				self.attribute.HP = 1
			return nil
			end
			return SCreature.super.adjHP(self,hp,forceSync,must,zz)
		end
	end


	function SCreature:hurted(itemID,bulletID,mode,hitValue,adjTime) 
		if self.attribute.parameterArr['NOBEFIGHT']~=nil and self.itemID~=itemID then
			self:D("NOBEFIGHT..............禁止被攻击")
			return 0
		end

		local hurt = SCreature.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
		if ( self.attribute.parameterArr["SYNCPARENTHP"] ~= nil ) then
			self.parent:directHurt(itemID,0,{finalFixHurt=0,BUFFONLY=true},0)
		end
		return hurt
	end

	function SCreature:fight() 
		if (self.createTime+1>self.world.gameTime) then
		 	return nil
		 end
		if (self.lastFollowTime==self.world.gameTime) then
			return nil
		end
		if ( self.attribute.parameterArr["NOFIGHT"] == nil or self.world.tonumber(self.attribute.parameterArr["NOFIGHT"]) ~= 1) then

			SCreature.super.fight(self)
		end 

	end
	--攻击以后的callback
	function SCreature:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 

		if ( hitValue['addStatus'] ~= nil and itemID<=100) then
	
			self:addStatusList({s=hitValue['addStatus'],r=self.world.gameTime+adjTime,t=0.5,i=self.itemID},adjTime)
		end
		if ( hitValue['creatureDirectHurCallBack'] ~= nil and self.parent ~= nil) then
			if self.parent~=nil and self.parent.statusList[4007]~=nil then
				--self:D('jaylog now start 4007')
				-- if self:parentColliding() then
				-- 	--self:D('jaylog parent colliding creatrue')
				-- 	self.parent:setShared(0)
				-- 	self.parent:removeStatusList(4007)
				-- 	self.parent:addStatusList({s=4008,r=self.world.gameTime,t=1},0.2)
				-- 	self.parent:removeStatusList(4010)
				-- 	self.parent:removeBUff('INVICINBLE')
				-- 	self.parent.moveStopTime = self.world.gameTime + 1
				-- 	self:addStatusList({s=42,r=self.world:getGameTime(),t=999},0)
				-- 	self.attribute.HP = 0
				-- 	self:directHurt(self.itemID,1,{},0)
				-- end
				--self:D('jaylog SCreature:directHurtCallBack itemID',itemID,'parentID',self.parent.itemID	,' roleId',self.attribute.roleId)
				if itemID==self.parent.itemID then
					self:D('jaylog SCreature:directHurtCallBack compose')
					self.parent:setShared(0)
					self:setShared(0)
					self.parent:removeStatusList(4007)
					self.parent.AIlastMoveTime = self.world.gameTime+2
					self.parent:addStatusList({s=4008,r=self.world.gameTime,t=1},0.2)
					self.parent:removeStatusList(4010)
					self.parent:removeBUff('INVICINBLE')
					self.parent:moveTo(self.posX,self.posY,true,1,999999)
					self.parent.moveStopTime = self.world.gameTime + 1
					self:addStatusList({s=42,r=self.world:getGameTime(),t=999},0)
					self.attribute.HP = 0
					self:directHurt(self.itemID,1,{},0)
				end
			else
				self.parent:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt)
			end
		end

		

	end

	function SCreature:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
        local ret = SCreature.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime)
		-- if (ret>0 and (itemID>=200 or itemID<100) and self.attribute.parameterArr["REHPHURT"] ~= nil and self.attribute.parameterArr["REHPHURT"]>0) then
		-- 	local hitValueNew = {fixHurt = ret*self.attribute.parameterArr["REHPHURT"]/100}
		-- 	self.parent:directHurt(self.parent.itemID,0,hitValueNew,adjTime)
		-- end
		return ret
	end

	function SCreature:getSyncMsg()
		-- local ret = table.deepcopy(self.syncMsg)
		local ret = self.syncMsg
		self.syncMsg = {}
		self.dirty = false
		return ret
	end

	--- 是否与父类对碰
	function SCreature:parentColliding()
		local range = self:getCircle()
		local distance = self.parent:colliding(range,0,0,self.itemID)
		if distance<0 then
			return false
		else
			return true
		end
	end

	function SCreature:createInit()
		if self.attribute.parameterArr['IMMUNEAD']~=nil or self.attribute.parameterArr['IMMUNEAP']~=nil or self.attribute.parameterArr['IMMUNECONTROL']~=nil then
			local attributes = {}
			local hitValueNew = self:getPrepareHithitValue()
			attributes = hitValueNew
			attributes['BUFFONLY']=1
			if self.attribute.parameterArr['IMMUNECONTROL']~=nil then
				attributes['IMMUNECONTROL_RATE'] = 100
			end
			if self.attribute.parameterArr['IMMUNEAD']~=nil then
				attributes['IMMUNEAD_RATE'] = 100 
			end
			if self.attribute.parameterArr['IMMUNEAP']~=nil then
				attributes['IMMUNEAP_RATE'] = 100 
			end
			attributes['buffType'] = 3
			attributes['BUFFTIME'] = 99999
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0,99),attributes,99999,{},0,self.itemID,self.itemID,0)
			self:addBuff(buff)
		end
	end


return SCreature
