local SCreature764 = class("SCreature764", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature764:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature764" 
	end 

	SCreature764.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.nextBuffTime = 0
end 

--- 受傷害計算,调用SActor的hurted
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SCreature764:hurted(itemID,bulletID,mode,hitValue,adjTime)
	hitValue['FIXREHP'] = 0
	local hurt = SCreature764.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
	return hurt
end

function SCreature764:move() 
	SCreature764.super.move(self)
	if self.world:getGameTime()>self.nextBuffTime then
		local hitValueNew={}
		local r = self.world.formula:getRandnum(30,60)
		self:D("大炮的cd 减少:"..r)
		hitValueNew['BOSSREDUCECD_DOWN'] = r
		hitValueNew['BOSSREDUCECD_DOWN_RATE'] = 100
		hitValueNew['BUFFTIME'] = 30
		self:directHurt(self.itemID,mode,hitValueNew,0) 	
		self.nextBuffTime = self.world:getGameTime() + 10
	end
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SCreature764:prepareHit(mode,adjTime,buff) 
	if mode==1 then
		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters 

		local d =self.world.mPow(self.world.mPow(self.posX-self.lastBulletPositionX,2) + self.world.mPow(self.posY-self.lastBulletPositionY,2),0.5)
		self.prepareSKVar['interval']  = d*100/parameters.PARABOLABULLETSPEED  + skill.hitTime
		self:D("大炮的飞行时间 :"..self.prepareSKVar['interval'])
	end 
	local hitValueBoth=SCreature764.super.prepareHit(self,mode,adjTime,buff) 
	
	return hitValueBoth 
end 


return SCreature764