local SNPC32011 = class("SNPC32011", require("gameroom.SNPC")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SNPC32011:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SNPC32011" 
	end 

	SNPC32011.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	-- self.world:D('jaylog SNPC32011 ctor')
end 


function SNPC32011:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	-- local obj = self.world.allItemList[itemID]
	-- if obj~=nil and self.statusList[620]==nil and obj.itemID==1 and obj.statusListRemoved[41]==nil and obj.statusList[41]==nil then
	-- 	-- self.world:D('jaylog SNPC32011 directHurtCallBack ',itemID)
	-- 	obj:addStatusList({zz=3,i=self.itemID,s=999,r=self.world.gameTime,t=0.5,p1=self.world.tonumber(self.attribute.roleId),p2=5,p3=self.itemID})
	-- 	obj:addStatusList({zz=3,s=607,r=self.world.gameTime,t=0.5,p1=self.itemID})
	-- end

	SNPC32011.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
	if self.itemID~=itemID then
		local obj = self.world.allItemList[itemID]
		-- self.world:D('jaylog SNPC32011:directHurtCallBack obj:',obj.itemID,obj.actorType,obj.teamOrig,self.teamOrig)
		if obj.actorType==0 and obj.parent==nil and not obj:isAIObj() and self.teamOrig~=obj.teamOrig and obj.statusList[4422]==nil then
			-- obj:addStatusList({zz=3,s=999,r=self.world.gameTime,t=0.5,p1=self.world.tonumber(self.attribute.roleId),p2=self.world.tonumber(self.world.setting['takeFireTime']),p3=self.world.tonumber(self.itemID)})
			-- self.world:D('jaylog SNPC32011:directHurtCallBack statusList:',self.world.cjson.encode(obj.statusList[100]))
			-- self.world:D('jaylog SNPC32011:directHurtCallBack hitValue:',obj.canPickUp,self.world.cjson.encode(hitValue),itemID,self.itemID,self:isDead(),self.attribute.HP,self.world.cjson.encode(obj.statusList[100]),self.world.cjson.encode(obj.statusList[984]))
			if hitValue['isPickUp']==nil and not obj.canPickUp and obj.statusList[100]==nil and obj.statusListRemoved[100]==nil then
				if obj.statusList[984]==nil then
					obj:addStatusList({zz=3,i=obj.itemID,s=984,r=self.world.gameTime,t=9999,p1=self.world.tonumber(self.attribute.roleId),p2=self.world.tonumber(self.world.setting['takeFireTime']),p3=self.itemID,p4=15,p5=1})
				end
			end
			if hitValue['isPickUp']~=nil and obj.canPickUp then-- and self.statusList[4104]~=nil
				if obj.statusList[100]==nil and obj.statusListRemoved[100]==nil then
					-- self.world:D('jaylog SNPC32011:directHurtCallBack ',itemID,self.itemID,self.world.cjson.encode(obj.statusList[100]))
					obj:skillAttack(9)
					-- self.world:D('jaylog SNPC32011:directHurtCallBack end ',itemID,self.itemID,self.world.cjson.encode(obj.statusList[100]))
				end
			end
		end
	end
end

function SNPC32011:createInit()
	-- -- self.world:D('jaylog SNPC32011 createInit ',self.itemID)
	-- local attributes = {}
	-- attributes['buffParameter']={}
	-- attributes['BUFFONLY']=1
	-- attributes['buffParameter']['INEVITABLEHIT'] = 1
	-- attributes['buffParameter']['RANGE'] = self.attribute.width * self.world.setting.AdjustAttRange
	-- attributes['buffParameter']['creatureDirectHurCallBack'] = self.itemID
	-- attributes['buffParameter']['buffType'] = 1
	-- local intervalTime = 0.3
	-- attributes['buffParameter']['buffIntervalTime'] = intervalTime
	-- attributes['BUFFTIME'] = 99999
	-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0),attributes,999999,{99},0,self.itemID,self.itemID,0.1)
	-- -- buff.debug = true
	-- self:addBuff(buff)

	local lifeTime=99999
	local attributes = {}
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['INEVITABLEHIT'] = 1
	attributes['buffParameter']={isPickUp=1}
	attributes['buffParameter']['RANGE'] = self.attribute.width * self.world.setting.AdjustAttRange
	--attributes['buffParameter']['INEVITABLEHIT'] = 1
	attributes['buffParameter']['creatureDirectHurCallBack'] = self.itemID
	attributes['buffParameter']['buffIntervalTime'] = 0.5
	attributes['buffParameter']['buffType'] = 1
	attributes['buffParameter']['Effect'] = -1

	attributes['BUFFTIME'] = 99999
	-- self.world:D('jaylog SNPC32011:createInit addBuff ',self.attribute.width)
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0),attributes,lifeTime,{99},0,self.itemID,self.itemID,0.1)
	-- buff.debug = true
	self:addBuff(buff)
end

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SNPC32011:goToDead(itemID,mode,adjTime,bonus)
	SNPC32011.super.goToDead(self,itemID,mode,adjTime,bonus)
end



return SNPC32011