local SCreature159 = class("SCreature159", require("gameroom.enemy.SCreature")) 

--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature159:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature159" 
	end 
	----debuglog("天平 特殊处理 SCreature159")
	SCreature159.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end 


--- move motion , call every update loop
-- @return null
function SCreature159:move()
	SCreature159.super.move(self)

	
	local targetListZ = {}
	local targetListY = {}
	--self.world.setting

	local Aset=string.splitNumber(self.world.setting.balanceAreaA,',')
	local Bset=string.splitNumber(self.world.setting.balanceAreaB,',')
	--左天平
	local visRangeZ={posX=Aset[1],posY=Aset[2],radius=Aset[3]}
	--右天平
	local visRangeY={posX=Bset[1],posY=Bset[2],radius=Bset[3]}


	local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
	function(value)
	 	ok = true
		if (value:isDead()) then ok =false end
		if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
		if ok then
			--local d = value:colliding(visRange,0,0,self.itemID)
			local dz = self.world.map:containPoint(visRangeZ,value.posX,value.posY)
			local dy = self.world.map:containPoint(visRangeY,value.posX,value.posY)
			----debuglog("天平 碰撞身旁 itemID:"..value.itemID.." posX:"..value.posX.." posY:"..value.posY.." self posX:"..visRangeZ.posX.." self posY:"..visRangeZ.posY)
			if dz then
				targetListZ[#targetListZ+1] = value.itemID
			end
			if dy then
				targetListY[#targetListY+1] = value.itemID
			end
			if dz or dy then
				debuglog("重刷4016:"..value.itemID)
				local status = value.statusList[4016]
				if status~=nil then
					value:addStatusList({zz=3,i=status['i'],s=4016,r=self.world:getGameTime(),t=9999,p1=status['p1'],p2=status['p2'],p5=1,p4=22})
				end
			else
				-- local status = value.statusList[4016]
				-- value:addStatusList({zz=3,i=status['i'],s=4016,r=self.world:getGameTime(),t=9999,p1=status['p1'],p2=status['p2'],p5=0})
			end
		end
	end
	)

	----debuglog("天平 回调  enList:"..self.world.cjson.encode(enList))
	-- local enemy = self:getEnemylist()
	-- for k,value in pairs(enemy) do
	-- 	----debuglog("天平 回调  k:"..k)
	-- 	ok = true
	-- 	if (value:isDead()) then ok =false end
	-- 	if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
	-- 	if ok then
	-- 		--local d = value:colliding(visRange,0,0,self.itemID)
	-- 		local dz = self.world.map:containPoint(visRangeZ,value.posX,value.posY)
	-- 		local dy = self.world.map:containPoint(visRangeY,value.posX,value.posY)
	-- 		----debuglog("天平 碰撞身旁 itemID:"..value.itemID.." posX:"..value.posX.." posY:"..value.posY.." self posX:"..visRangeZ.posX.." self posY:"..visRangeZ.posY)
	-- 		if dz then
	-- 			targetListZ[#targetListZ+1] = value.itemID
	-- 		end
	-- 		if dy then
	-- 			targetListY[#targetListY+1] = value.itemID
	-- 		end
	-- 	end
	-- end
	--APADJ=80;ADDSTATUS=4026;ADDSTATUSTIME=999;CLEANSELFSTATUS=4024;ADDSTATUS2=41;ADDSTATUSTIME2=7.8;;DIZZYDELAY=0;DIZZY_RATE2=100;BUFFTIME2=5
	--debuglog("天平 回调 move Z:"..self.world.cjson.encode(targetListZ).." Y:"..self.world.cjson.encode(targetListY))
	--天平重与轻 1左重 2平 3右重
	local  retID = 1
	if #targetListZ==#targetListY then
		retID=2
	end
	if #targetListZ>#targetListY then
		retID=3
	end
	if #targetListZ<#targetListY then
		retID=1
	end
	self.world.tpZNum = #targetListZ
	self.world.tpYNum = #targetListY
	--debuglog("天平 特殊处理  retID:"..retID)
	--添加一个状态给前面
	self:addStatusList({s=4028,r=self.world:getGameTime(),t=20,i=self.itemID,p1=retID,p2=#targetListZ,p3=#targetListY})
end


return SCreature159 