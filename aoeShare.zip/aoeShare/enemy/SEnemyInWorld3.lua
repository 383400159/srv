local SEnemyInWorld3 = class("SEnemyInWorld3", require("gameroomcore.SHeroBase"))

function SEnemyInWorld3:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld3.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SEnemyInWorld3