local SCreature903 = class("SCreature903", require("gameroom.enemy.SCreature")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @return null
function SCreature903:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SCreature903" 
	end 

	SCreature903.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end 

function SCreature903:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	--self.world:debuglog('jaylog SCreature903:directHurtCallBack')
	SCreature903.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
	local obj = self.world.allItemList[itemID]
	if obj.actorType==0 and self.isEnd==nil then
		obj:addStatusList({s=999,r=self.world.gameTime,t=0.5,p1=self.world.tonumber(self.attribute.roleId),p2=0.01,p3=self.world.tonumber(self.itemID)})
	end
end

function SCreature903:createInit()
	local lifeTime=99999
	local attributes = {}
	attributes['buffParameter']={}
	attributes['BUFFONLY']=1
	attributes['INEVITABLEHIT'] = 1
	attributes['buffParameter']['RANGE'] = self.attribute.width * self.world.setting.AdjustAttRange+300
	--attributes['buffParameter']['INEVITABLEHIT'] = 1
	attributes['buffParameter']['creatureDirectHurCallBack'] = self.itemID
	attributes['buffParameter']['buffIntervalTime'] = 0.3
	attributes['buffParameter']['buffType'] = 0
	attributes['buffParameter']['Effect'] = -1
	attributes['BUFFTIME'] = 99999
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0),attributes,lifeTime,{99},0,self.itemID,self.itemID,0.1)
	--buff.debug = true
	self:addBuff(buff)

	self:D("抢矿加采集buff。。。。。。。。。。。。。。。。。。。。。。。。 ",self.itemID)
end

return SCreature903 