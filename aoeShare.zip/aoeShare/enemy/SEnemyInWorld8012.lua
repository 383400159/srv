local SEnemyInWorld8012 = class("SEnemyInWorld8012", require("gameroomcore.SHeroBase"))

function SEnemyInWorld8012:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld8012.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SEnemyInWorld8012