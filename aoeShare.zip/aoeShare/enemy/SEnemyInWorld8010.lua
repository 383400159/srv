local SEnemyInWorld8010 = class("SEnemyInWorld8010", require("gameroomcore.SHeroBase"))

function SEnemyInWorld8010:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SEnemyInWorld8010.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SEnemyInWorld8010