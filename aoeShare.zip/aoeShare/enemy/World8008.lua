local World8008 = class("World8008",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World8008:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World8008"
	end
	self:D('jaylog World8008:ctor ',gamePort,' ',gameID)
	
	worldForHero = 0
	World8008.super.ctor(self,gamePort,gameID,callBack)
	worldForHero = 0
	self.biaocheID = 0
	self.biaocheDeadDelay = 0
end

--- RUNNING中 gameOver 检查
-- @return result bool - 是否gameOver
function World8008:gameOverCheck()
	local result = false
	if self.biaocheID==0 then
		for k,obj in pairs(self.allItemList) do
			if obj.subName=="biaoche" then
				self.biaocheID = k
				break
			end
		end
	end
	if self.biaocheID==0 then
		return result
	end
	if self.biaocheDeadDelay==0 and (self.itemListFilter.heroList[1]:isDead() or self.allItemList[self.biaocheID]:isDead()) then
		self.biaocheDeadDelay = self.gameTime + 3
	end
	self:D('jaylog World8008-biaocheID:',self.biaocheID)
	if not self.gameFlag['isGameOver'] and (self.gameFlag['isGameOverTime']==nil or self.gameFlag['isGameOverTime']==0) and (self.biaocheDeadDelay~=0 and self.biaocheDeadDelay<self.gameTime) then
		self:addSyncMsg({game={part=13,step=2,mType=3}})
		local obj = self.itemListFilter.heroList[1]
		local fromMap = self.tonumber(self.playerList[1]['fm'])
		local x,y = 0,0
		if self.playerList[1]['fmX']~=nil and self.playerList[1]['fmX']~=0 then
			x = self.playerList[1]['fmX']
		end
		if self.playerList[1]['fmY']~=nil and self.playerList[1]['fmY']~=0 then
			y = self.playerList[1]['fmY']
		end

		self.gameFlag['winTeam'] = 'B'
		local newArray = self:genGameOverData()
		newArray[self.sFormat(self.playerList[obj.itemID]['p'])]['toX'] = x
		newArray[self.sFormat(self.playerList[obj.itemID]['p'])]['toY'] = y
		local gameID = self:memcacheGet('gameID'..self.playerList[obj.itemID]['p'])
		local finishapi = self.webapiurl..'pve/finishGame'
		local finishapi2 = self.webapiurl2..'pve/finishGame'
		if self.gameRoomSetting.ISLOCAL==1 then
			gameID = self.gameID
			finishapi = self.webapiurl..'pve/finishGameRoom'
			finishapi2 = self.webapiurl2..'pve/finishGameRoom'
		end
		local url=finishapi..'/?data='..string.urlencode(self.cjson.encode(newArray))..'&Version=0.0.2&session='..self.playerList[obj.itemID]['s']..'&gameID='..gameID
		local webresult=self:file_get_contents(url)
		if (webresult==false) then
			url=finishapi2..'/?data='..string.urlencode(self.cjson.encode(newArray))..'&Version=0.0.2&session='..self.playerList[obj.itemID]['s']..'&gameID='..gameID
			webresult=self:file_get_contents(url)
		end
		self:D('jaylog before GOYW call url:',url,' result:',webresult)

		self:redirectRoom(obj.itemID,fromMap,self.gameRoomInfoAll[fromMap]['port'],nil,x,y,nil,false,true)
		self.gameFlag['isGameOverTime'] = self.gameTime + 0.5
		self:D('jaylog World8008:gameOverCheck ',self.gameFlag['isGameOver'],self.gameFlag['isGameOverTime'],self.gameTime)
	end

	if self.status~=self.GAMEOVER and not self.gameFlag['isGameOver'] and self.gameFlag['isGameOverTime']>0 and self.gameFlag['isGameOverTime']<self.gameTime then
		self:D('jaylog World8008:gameOverCheck mark result true',self.gameFlag['isGameOver'],self.gameFlag['isGameOverTime'],self.gameTime)
		result = true
	end

	if self.status~=self.GAMEOVER and self.gameFlag['isGameOver'] then
		result = true
		if self.gameRoomSetting['ISGVB']==1 and self.gameRoomSetting['teamMode']==2 then
			self.gameFlag['winTeam'] = 'A'
		end
	end

	-- result = World8008.super.gameOverCheck(self)

	return result
end

--- 玩家断线后设置玩家离线
-- @param data table - clinent发送的数据
-- @return data table - 原数据返回
function World8008:logout(data)
	World8008.super.logout(self,data)
	self.gameFlag['isGameOverTime'] = self.gameTime + 15
	self:D('jaylog World8008:logout set isGameOverTime',self.gameTime,self.gameFlag['isGameOverTime'])
end

--- 玩家登录或重连时执行
-- @param data table - client发送的数据
-- @return data table - 原数据返回
function World8008:login(data)
	self.gameFlag['isGameOverTime'] = 0
	World8008.super.login(self,data)
	self:D('jaylog World8008:login reset isGameOverTime',self.gameTime,self.gameFlag['isGameOverTime'])
end

return World8008