local SHero1 = class("SHero1", require("gameroom.hero.SHero")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @param actorID int - 游戏房玩家序号ID
-- @return null
function SHero1:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SHero1" 
	end 

	self.mode4time = 0

	self.mode3bulletid = 0	--3号技能子弹ID
	self.mode3x = 0					--3号技能施放坐标X
	self.mode3y = 0					--3号技能施放坐标Y

	--需要4变5
	self.mode5time = 0
	self.mode5in1time = 0


	self.mode2time = 0
	self.mode2x = 0--记录2号技能的落点
	self.mode2y = 0
	self.modeold2x = 0 --记录2号发技能的起点
	self.modeold2y = 0 --记录2号发技能的起点

	self.mode1bool = false
	self:D("旧的狂战士初始化")
	--self:D('jaylog SHero1:ctor before super')
	SHero1.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	--self:D('jaylog SHero1:ctor after super')
end 


--重载AI
function SHero1:_autoFightToHero()

	--需要判断队友是否没血了
	--获得队友列表
	  	--阿文用来替换ai攻击
	if self.world.heroNeedSkillID~=nil and self.world.heroNeedSkillID>0 then
	 
		ret = true
	else
		ret = false
		if (self.teamOrig=="A") then
			teamlist=self.world.itemListFilter.heroTeamAList
		else
			teamlist=self.world.itemListFilter.heroTeamBList
		end

		local skill2 = self.attribute.skills[2]  
		local skill5 = self.attribute.skills[5]  
		
		--原地扫描附近队友
		if skill2.lastCoolDownTime<self.world:getGameTime() and self.world.gameRoomSetting.ISGVB==1 then
			--需要救援的列表
			local targetList = {}
			local visRange={posX=self.posX,posY=self.posY,radius=skill2.atkDis/self.world.setting.AdjustVisRange}

			for k,value in pairs(teamlist) do
				ok = true
				if (not value:isDead()) then ok =false end
				if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
				if ok and (value.attribute.HP/value.attribute.MaxHP)<0.8 then
					local d = value:colliding(visRange,0,0,self.itemID)
					--判断他最近被击中过
					if d>=0 and self.lastAttackTime+2>self.world:getGameTime() then
						targetList[#targetList+1] ={itemID=value.itemID,hprate=value.attribute.HP/value.attribute.MaxHP} 
					end
				end
			end
			--赛选出最优的几个队友
			--self:D(" skill3 AI targetList:"..self.world.cjson.encode(targetList))
			if #targetList>0 then

				self.world.tSort(targetList,function( a1,b1 )
								return a1['hprate'] < b1['hprate']
							end)

				local protectionID = targetList[1]['itemID']
				local obj = self.world.allItemList[protectionID] 
				--击中最近攻击队友的目标
				ret = self:skillAttack(2,obj.lastAttackID)
			end
		end

		if skill5.lastCoolDownTime<self.world:getGameTime() then

			
			local targetList = {}
			local visRange={posX=self.posX,posY=self.posY,radius=1000/self.world.setting.AdjustVisRange}

			local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
			function(value)
			 	ok = true
				if (value:isDead()) then ok =false end
				if (value.attribute.HP<=0) then ok =false end
				if (value.attribute.actorType~=0) then ok =false end
				if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
				if ok  then
					local d = value:colliding(visRange,0,0,self.itemID)
					if d>=0 then
						targetList[#targetList+1] = {id=value.itemID}
					end
				end
			end
			)

			-- local enemy = self:getEnemylist()
			-- for k,value in pairs(enemy) do
			-- 	ok = true
			-- 	if (value:isDead()) then ok =false end
			-- 	if (value.attribute.HP<=0) then ok =false end
			-- 	if (value.attribute.actorType~=0) then ok =false end
			-- 	if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
			-- 	if ok  then
			-- 		local d = value:colliding(visRange,0,0,self.itemID)
			-- 		if d>=0 then
			-- 			targetList[#targetList+1] = {id=value.itemID}
			-- 		end
			-- 	end
			-- end

			local hprate=self.attribute.HP/self.attribute.MaxHP
			if hprate>0.4 and #targetList>0 then
				ret = self:skillAttack(5,self.itemID)
			end
		end


	end
	

	if not ret then
		local retSkillID=SHero1.super._autoFightToHero(self) 
		if retSkillID==3 then
			self.AIlastATKTime = self.world.gameTime
		end
	end
end



--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SHero1:prepareHit(mode,adjTime,buff)  




	if (mode==3) then
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 

		local attributes = {}
		attributes['CRI_UPFIX_RATE'] = parameters.CRI_UPFIX_RATE2
		attributes['CRI_UPFIX'] = parameters.CRI_UPFIX2
		attributes['BUFFTIME'] = parameters.BUFFTIME2
		-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,parameters.BUFFTIME2,{},0,self.itemID,self.itemID,0)
		local buff = self.world:createBuff(self:__skillID2buffID(skill.skillID,0),attributes,parameters.BUFFTIME2,{},0,self.itemID,self.itemID,0)
		self:addBuff(buff)
	end

	
	-- if (mode==4) then
	-- 	self.mode4x = self.lastBulletPositionX 
	-- 	self.mode4y = self.lastBulletPositionY 
	-- 	self.mode4times = 0
	-- 	self:D("记录4号子弹......")

	-- 	local skill = self.attribute.skills[4] 
	-- 	local parameters = skill.parameters 	
	-- 	local attributes = {}
	-- 	attributes['ATK_UPFIX_RATE'] = parameters.ATK_UPFIX_RATE2
	-- 	attributes['ATK_UPFIX'] = parameters.ATK_UPFIX2
	-- 	attributes['BUFFTIME'] = parameters.BUFFTIME2
	-- 	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,parameters.BUFFTIME2,{},0,self.itemID,self.itemID,0)
	-- 	self:addBuff(buff)
	-- end

	-- if (mode==104) then
	-- 	mode = 4
	-- 	self.mode4times = self.mode4times + 1
	-- 	if self.mode4times==5 then
	-- 		local skill = self.attribute.skills[4] 
	-- 		local parameters = skill.parameters 		
	-- 		local x=self.posX 
	-- 		local y=self.posY 
	-- 		local attackRange = {posX=x,posY=y,radius=(parameters.ATKDIS_UPFIX3+skill.atkDis)/self.world.setting.AdjustAttRange} 
	-- 		local hitValueNew=SHero1.super.prepareHit(self,mode,adjTime,buff) 
	-- 		hitValueNew['skillID'] = 4
	-- 		hitValueNew['ADADJ'] = parameters.ADADJ3
	-- 		-- hitValueNew['BLEED_HURTFIX_RATE'] = parameters.BLEED_HURTFIX_RATE2
	-- 		-- hitValueNew['BUFFTIME'] = parameters.BUFFTIME2
	-- 		hitValueNew['Effect'] = 98
	-- 		--hitValueNew = {skillID=6,ADADJ=parameters.ADADJ2,BLEED_HURTFIX_RATE=parameters.BLEED_HURTFIX_RATE2,BUFFTIME=parameters.BUFFTIME2} 
	-- 		local bullet = require("gameroomcore.SBullet").new(self.world,4,self.itemID,0.2,0,self.mode4x,self.mode4y) 
	-- 		bullet.attr.debug = true
	-- 		bullet:directFightAura(1,attackRange,hitValueNew,nil,skill.degree)
	-- 		for k,v in pairs(bullet.attr.hitID) do

	-- 			local obj = self.world.allItemList[v] 
	-- 			local skill = self.attribute.skills[4] 
	-- 			local parameters = skill.parameters 
				
	-- 			local toX,toY = self.world.map:getXYLength(self.posX,self.posY,obj.posX,obj.posY,parameters.BACKWARD/self.world.setting.AdjustAttRange)
	-- 			local ret
	-- 			ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
	-- 			obj:moveTo(toX,toY,false,5,parameters.BACKWARDSPEED,0) 
	-- 		end
	-- 		bullet:setDead()
	-- 		return nil
	-- 	end
	-- end


	local hitValueBoth=SHero1.super.prepareHit(self,mode,adjTime,buff) 

	if (mode==2) then
		hitValueBoth['bulletAttackMode4Passthru'] = false;
	end

	if mode==4 then
		--NEARESTUSEDIS=200;FLYTIME=0.35;STOPTIME=0.15;DOWNTIME=0.1
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		local d1 = self:distance(self.lastBulletPositionX,self.lastBulletPositionY)
		local atkDis = (d1-parameters.NEARESTUSEDIS/self.world.setting.AdjustAttRange)>0 and (d1-parameters.NEARESTUSEDIS/self.world.setting.AdjustAttRange) or d1

		local toX1,toY1 = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,atkDis)
		local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX1,self.posY+toY1) 
		--local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY)
		self:D("狂战士 大招 posX:"..self.posX.." posY:"..self.posY.." lastBulletPositionX:"..self.lastBulletPositionX.." lastBulletPositionY:"..self.lastBulletPositionY.." toX:"..toX.." toY:"..toY)
		local d = self:distance(toX,toY)
		-- local stopD=parameters.STOPTIME*5
		-- local FLYSPEED = ((d-stopD)*100)/(parameters['FLYTIME']+parameters['DOWNTIME'])
		local FLYSPEED = (d*100)/(parameters['FLYTIME'])
		-- --第一段
		-- local toXfly1,toYfly1 = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,FLYSPEED*parameters['FLYTIME']/self.world.setting.AdjustAttRange)
		-- local ret,toXfly,toYfly=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toXfly1,self.posY+toYfly1)
		-- self:moveTo(toXfly,toYfly,false,6,FLYSPEED,skill.hitTime)

		-- --第二段
		-- local toXstop1,toYstop1 = self.world.map:getXYLength(toXfly,toYfly,self.lastBulletPositionX,self.lastBulletPositionY,stopD)
		-- local ret,toXstop,toYstop=self.world.map:findPointStraightLineNearest(toXfly,toYfly,toXfly+toXstop1,toYfly+toYstop1)
		-- self:moveTo(toXstop,toYstop,false,6,5*100,skill.hitTime+parameters['FLYTIME'])

		-- --第3段
		-- local toXdown1,toYdown1 = self.world.map:getXYLength(toXstop,toYstop,self.lastBulletPositionX,self.lastBulletPositionY,d-stopD-(FLYSPEED*parameters['FLYTIME']/self.world.setting.AdjustAttRange))
		-- local ret,toXdown,toYdown=self.world.map:findPointStraightLineNearest(toXstop,toYstop,toXstop+toXdown1,toYstop+toYdown1)
		-- self:moveTo(toXdown,toYdown,false,6,FLYSPEED,skill.hitTime+parameters['FLYTIME']+parameters['STOPTIME'])

		self:moveTo(toX,toY,false,6,FLYSPEED,skill.hitTime)
		--local dealyTime = (d*100)/parameters['FLYSPEED']
		--local dealyTime = skill.hitTime+parameters['FLYTIME']
		local dealyTime = skill.hitTime+parameters['FLYTIME']
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['buffParameter'] = {}
		attributes['buffParameter']['buffIntervalTime'] = dealyTime
		-- local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,dealyTime+0.1,{mode},0,self.itemID,self.itemID,skill.hitTime) 
		local buffObj=self.world:createBuff(self:__skillID2buffID(skill.skillID,0),attributes,dealyTime+0.1,{mode},0,self.itemID,self.itemID,skill.hitTime) 
 		self:addBuff(buffObj)
 		self:D("狂战士 大招 d:"..d.."dealyTime:"..dealyTime.." lastBulletPositionX:"..self.lastBulletPositionX.." lastBulletPositionY:"..self.lastBulletPositionY.." posX"..self.posX.." posY:"..self.posY)
		hitValueBoth=nil
		self.mode4time = self.world.gameTime+skill.hitTime

		local hitValueNew={}
		hitValueNew['ATK_UPFIX_RATE']=parameters.ATK_UPFIX_RATE3 
		hitValueNew["ATK_UPFIX"]=parameters.ATK_UPFIX3
		hitValueNew["BUFFTIME"]=parameters.BUFFTIME3
		self:directHurt(self.itemID,mode,hitValueNew,0) 


		self.lastBulletPositionX = toX
		self.lastBulletPositionY = toY
		return nil
	end

	if mode==104 then
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		hitValueBoth=nil
		if self.world.gameTime>self.mode4time then
			self:D("狂战士 大招 回调")
			local hitValueNew = self:getPrepareHithitValue()
			hitValueNew['skillID'] = 4
			hitValueNew['ADADJ'] = parameters.ADADJ2 
			self:directFightAuratoDalay(4,0,hitValueNew,{posX=self.posX,posY=self.posY,RANGE=skill.atkDis},0) 

		end
	end

	-- if (mode==3) then
	-- 	local skill = self.attribute.skills[3] 
	-- 	local parameters = skill.parameters
	-- 	if parameters['BACKSHIFT']~=nil then 
	-- 		hitValueBoth['bulletAttackMode4ExtendDistance'] = -self.world.tonumber(parameters['BACKSHIFT'])
	-- 	else
	-- 		hitValueBoth['bulletAttackMode4ExtendDistance'] = -math.floor(skill.atkDis/2)
	-- 	end
	-- end

	--需要4变5
	-- if self.mode5time>self.world:getGameTime() and itemID~=self.itemID then
	-- 	local skill = self.attribute.skills[5] 
	-- 	local parameters = skill.parameters 
	-- 	-- hitValueBoth['BLEED_HURTFIX_RATE'] = parameters.BLEED_HURTFIX_RATE2
	-- 	-- --self:D("OLD hitValueBoth['BLEED_HURTFIX']:"..hitValueBoth['BLEED_HURTFIX'])
	-- 	-- self:D("OLD parameters.BLEED_HURTFIX2:"..parameters.BLEED_HURTFIX2)
	-- 	-- hitValueBoth['BLEED_HURTFIX'] = (hitValueBoth['BLEED_HURTFIX']~=nil and  hitValueBoth['BLEED_HURTFIX'] or 0)  + parameters.BLEED_HURTFIX2
	-- 	-- self:D("hitValueBoth['BLEED_HURTFIX']:"..hitValueBoth['BLEED_HURTFIX'])

	-- 	if mode==2 then
	-- 		self:D("红毛添加晕眩bubuff parameters:"..self.world.cjson.encode(parameters))
	-- 		self:D("红毛添加晕眩bubuff DIZZY_RATE:"..parameters.DIZZY_RATE2)
	-- 		hitValueBoth['DIZZY_RATE'] = parameters.DIZZY_RATE2 + hitValueBoth['DIZZY_RATE'] 
	-- 	end
	-- 	if mode==3 then
	-- 		--VAMPIREAD2=50;VAMPIREAD_RATE2=0,3,6,9,12,16,19,22,26,29,33,37,40,44,48,52,58,64,70,80,90
	-- 		hitValueBoth['VAMPIREAD_RATE'] = parameters.VAMPIREAD_RATE2
	-- 		hitValueBoth['VAMPIREAD'] = parameters.VAMPIREAD2 
	-- 	end
	-- 	if mode==4 then
	-- 		--BLEED_HURTFIX_RATE2=0,3,6,9,12,16,19,22,26,29,33,37,40,44,48,52,58,64,70,80,90;BLEED_HURTFIX2=0,11,23,35,47,59,72,84,97,110,124,137,151,165,180,194,216,239,263,299,338;BUFFTIME2=3
	-- 		hitValueBoth['BLEED_HURTFIX_RATE'] = parameters.BLEED_HURTFIX_RATE2 
	-- 		hitValueBoth['BLEED_HURTFIX'] = parameters.BLEED_HURTFIX2 
	-- 		if parameters.BUFFTIME4>hitValueBoth['BUFFTIME'] then
	-- 			hitValueBoth['BUFFTIME'] = parameters.BUFFTIME4
	-- 		end
	-- 	end

	-- 	if mode==2 or mode==3 or mode==4 then
	-- 		self.mode5time=self.world:getGameTime()
	-- 	end
	-- end

	-- if self.mode5in1time>self.world:getGameTime() and itemID~=self.itemID then
	-- 	if mode==1 then
	-- 		--BLEED_HURTFIX_RATE2=0,3,5,8,11,14,17,20,23,26,29,32,36,39,42,46,51,56,62,70,80
	-- 		local skill = self.attribute.skills[5] 
	-- 		local parameters = skill.parameters 
	-- 		hitValueBoth['BLEED_HURTFIX_RATE'] = parameters.BLEED_HURTFIX_RATE2
	-- 	end
	-- end

	--需要4变5
	if (mode==5) then
		--APADJ=0;ADADJ=0;ATK_UP=10;LOSSHP_HURT=8;BUFFTIME=7;BLEED_HURTFIX_RATE2=100;BLEED_HURTFIX2=17;BUFFTIME2=3;CDTIME=20
		--APADJ=0;ADADJ=0;ATK_UP=25;LOSSHP_HURT_RATE=100;LOSSHP_HURT=8;BUFFTIME=7;BLEED_HURTFIX_RATE2=100;BLEED_HURTFIX2=17;BUFFTIME2=7;CDTIME=20
		local skill = self.attribute.skills[5] 
		local parameters = skill.parameters 
		self.mode5time = self.world:getGameTime() + parameters.BUFFTIME
		self.mode5in1time = self.world:getGameTime() + parameters.BUFFTIME
	end

	--之前的5不要
	-- if mode==5 then
	-- 	--APADJ=0;ADADJ=150;DEF_UP2=35;IMMUNECONTROL_RATE2=100;BUFFTIME2=5;CDTIME=30
	-- 	local skill = self.attribute.skills[5] 
	-- 	local parameters = skill.parameters 
	-- 	local attributes = {}
	-- 	attributes['DEF_UP'] = parameters.DEF_UP2
	-- 	attributes['IMMUNECONTROL_RATE'] = parameters.IMMUNECONTROL_RATE2
	-- 	attributes['BUFFTIME'] = parameters.BUFFTIME2
	-- 	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,parameters.BUFFTIME2,{},0,self.itemID,self.itemID,0)
	-- 	self:addBuff(buff)
	-- end

	if mode==1 then
		self.mode1bool = true
	end

	return hitValueBoth 
end 


--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero1:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 

	if mode==7 then
		local skill = self.attribute.skills[7] 
		local parameters = skill.parameters 
		--释放血剑斩，对目标造成%sBB物理伤害，并使对方100%持续%s秒出血。AAAA冷却：%s 秒
		--HURTAD_HURT=30;HURTAP_HURT=30;BUFFTIME=10;COUNTER_RATE=10;APADJ2=0;ADADJ2=150;BLEED_HURTFIX2=30;BUFFTIME2=5;CDTIME=30
		self:D("格挡   触发格挡攻击...........")
		hitValue['APADJ'] = hitValue['APADJ']+parameters.APADJ2
		hitValue['ADADJ'] = hitValue['ADADJ']+parameters.ADADJ2
		hitValue['BLEED_HURTFIX'] = hitValue['BLEED_HURTFIX']+parameters.BLEED_HURTFIX2
		hitValue['BUFFTIME'] = parameters.BUFFTIME2
	end


	if mode==1 and self.mode1bool then
		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters 
		local attributes = {}
		attributes['CRI_UPFIX_RATE'] = parameters['CRI_UPFIX_RATE2']
		attributes['CRI_UPFIX'] = parameters['CRI_UPFIX2'] 
		-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,parameters['BUFFTIME2'],{},0,self.itemID,self.itemID,0.1)
		local buff = self.world:createBuff(self:__skillID2buffID(skill.skillID),attributes,parameters['BUFFTIME2'],{},0,self.itemID,self.itemID,0.1)
		self:addBuff(buff)
		self.mode1bool = false

	end

	ret = SHero1.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	if mode==2 and hitValue['Effect']~=2 then
		--print("prepareHit 飞飞飞........ x y tox toy distance ",self.posX,toX,self.posY,toY,skill.atkDis/self.world.setting.AdjustAttRange)
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[2] 
		local parameters = skill.parameters 
		
		--local d = obj:distance(self.mode2x,self.mode2y)

		--self.world.mPow(dm2-self.world.mPow(d1,2),0.5)
		--面对平行距离X,Y差SGameMap:getXYLengthCross
		--local toPX,toPY = self.world.map:getXYLength(self.modeold2x,self.modeold2y,self.mode2x,self.mode2y,d)

		-- --斜率
		-- local k = (self.posY-self.lastBulletPositionY)/(self.posX-self.lastBulletPositionX)
		-- local b = obj.posY-k*obj.posX

		-- self:D("hitTarget 飞飞飞 d:"..(skill.atkDis-parameters.MOVECUT-(self.world:getGameTime()-self.mode2time)*skill.bulletSpeed))
		-- self:D("hitTarget 飞飞飞 oldd:"..(skill.atkDis-parameters.MOVECUT))
		-- self:D("hitTarget 飞飞飞 getGameTime:"..self.world:getGameTime())
		-- self:D("hitTarget 飞飞飞 mode2time:"..self.mode2time)
		--local toX,toY = self.world.map:getXYLength(self.modeold2x,self.modeold2y,self.lastBulletPositionX,self.lastBulletPositionY,(skill.atkDis-parameters.MOVECUT-(self.world:getGameTime()-self.mode2time)*skill.bulletSpeed)/self.world.setting.AdjustAttRange)

		-- local toX,toY = self.world.map:getXYLength(self.modeold2x,self.modeold2y,self.lastBulletPositionX,self.lastBulletPositionY,(skill.atkDis-(self.world:getGameTime()-self.mode2time-adjTime)*skill.bulletSpeed)/self.world.setting.AdjustAttRange)
		local d = obj:distance(self.mode2x,self.mode2y)+self.attribute.width
		local toX,toY = self.world.map:getXYLength(self.modeold2x,self.modeold2y,self.mode2x,self.mode2y,d)
		-- local ret
		-- toX = self.mode2x
		-- toY = self.mode2y 
		--print("hitTarget 飞飞飞........ x tox y toy distance ",obj.posX,toX,obj.posY,toY,(skill.atkDis-parameters.MOVECUT)/self.world.setting.AdjustAttRange+1)
		ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 

		obj:moveTo(toX,toY,false,5,skill.bulletSpeed,0) 

	end
	

	return ret 
end 

--- 准备攻击前置设置，在prepareHit之后执行，call父类
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SHero1:prepareSkillAttackCustom(mode,target,x,y,adjTime,syncMsg)  
	
	if mode==4  then
		syncMsg['a']['x'] = self.lastBulletPositionX
		syncMsg['a']['y'] = self.lastBulletPositionY
		self:D("狂战士大战:".." syncMsg:"..self.world.cjson.encode(syncMsg))
	end

	if (mode==2 ) then 
		--print("prepareHit 飞飞飞........ x y tox toy distance ",self.posX,toX,self.posY,toY,skill.atkDis/self.world.setting.AdjustAttRange)
		local skill = self.attribute.skills[2] 
		local parameters = skill.parameters 

		local toX,toY = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,(skill.atkDis-parameters.MOVECUT)/self.world.setting.AdjustAttRange)
		local ret
		self:D("prepareHit 飞飞飞........ x tox y toy distance ",self.posX,toX,self.posY,toY,(skill.atkDis-parameters.MOVECUT)/self.world.setting.AdjustAttRange)
		ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX,self.posY+toY) 

		local delaytime = parameters.COLLISIONBULLETHITTIME
		self.mode2time = self.world:getGameTime()+adjTime+delaytime
		self.modeold2x = self.posX
		self.modeold2y = self.posY
		self:D('============= hero rush itemid ox oy x y ',self.itemID,self.modeold2x,self.modeold2y,toX,toY)
		self:moveTo(toX,toY,false,6,skill.bulletSpeed,adjTime+delaytime) 
		self.mode2x = toX
		self.mode2y = toY
		local attributes = {}
		attributes['IMMUNECONTROL_RATE'] = 100
		--attributes['IMMUNECONTROL'] = self.moveToEndTime
		attributes['BUFFTIME'] = 0.2
		-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,0.2,{},0,self.itemID,self.itemID,adjTime)
		local buff = self.world:createBuff(self:__skillID2buffID(skill.skillID,0),attributes,0.2,{},0,self.itemID,self.itemID,adjTime)
		self:addBuff(buff)

	end



	SHero1.super.prepareSkillAttackCustom(self,mode,target,x,y,adjTime,syncMsg)  
end 


--- 自动移动chud
-- @return null
function SHero1:_autoMove()
	-- self:D("SHero:_autoMove")
	local ret=SHero1.super._autoMove(self)
	local moveRet=self.autoFightAI:autoMoveToAlerted()

	if not ret and not self.autoBlocked and self.AIlastMoveTime < self.world:getGameTime() and  not self:isDead() and not moveRet and self.statusList[4007]==nil then
		
		local gt = self.world:getGameTime()


		if self.autoFightAI.nextMoveTargetTime>gt then
			self:D("狂战士 放autoMoveToATKHero nextMoveTargetTime:"..self.autoFightAI.nextMoveTargetTime.." gameTime:"..self.world.gameTime)
			self.autoFightAI:autoMoveToATKHero()
		else
			self:D("狂战士 放autoMoveToHero")
			self.autoFightAI:autoMoveToHero()
		end

		self.AIlastMoveTime = self.moveToEndTime
	end
	
	return ret
end

return SHero1 
