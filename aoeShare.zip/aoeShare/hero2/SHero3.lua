local SHero3 = class("SHero3", require("gameroom.hero.SHero")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @param actorID int - 游戏房玩家序号ID
-- @return null
function SHero3:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SHero3" 
	end 
	self.mode2type = 0
	self.mode5time = 0
	self.mode5in1time = 0

	self.creatureList = {}

	self.mode1bool = false
	
	--5号技能增强其他技能
	self.mode5inAllTime = 0

	SHero3.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end	


--重载AI
function SHero3:_autoFightToHero()
	SHero3.super._autoFightToHero(self) 
end


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SHero3:prepareHit(mode,adjTime,buff)  

	local hitValueBoth=SHero3.super.prepareHit(self,mode,adjTime,buff) 

	--3变2
	-- if (mode==2) then 
	-- 	self.creatureList = {}
	-- 	local skill = self.attribute.skills[2] 
	-- 	local parameters = skill.parameters 
	-- 	--生成小火堆🔥🔥🔥🔥🔥
	-- 	local toX,toY = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,skill.useDis/self.world.setting.AdjustAttRange)
	-- 	--面对平行距离X,Y差SGameMap:getXYLengthCross
	-- 	local toPX,toPY = self.world.map:getXYLengthCross(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,self.attribute.width)

	-- 	for i=-2,2 do
	-- 		local creatureID=self.world:addCreature(self.world.tostring(100+7-self.world.mAbs(i)),self.teamOrig,self.posX+toX+toPX*i,self.posY+toY+toPY*i,self,1,adjTime)  
	-- 		local obj  = self.world.allItemList[creatureID]
	-- 		self.creatureList[#self.creatureList+1]=creatureID  
	-- 		local lifeTime=skill.parameters.DEAD
	-- 		local attributes = {}
	-- 		attributes['buffParameter']={}
	-- 		attributes['BUFFONLY']=1
	-- 		attributes['buffParameter'] = table.deepcopy(hitValueBoth)
	-- 		--attributes['buffParameter']['FIXHURT'] = 250
	-- 		attributes['buffParameter']['RANGE'] = obj.attribute.width * self.world.setting.AdjustAttRange
	-- 		attributes['buffParameter']['creatureDirectHurCallBack'] = creatureID
	-- 		--debuglog("addCreature  creatureID:"..creatureID)
	-- 		attributes['buffParameter']['buffType'] = 1
	-- 		attributes['buffParameter']['buffIntervalTime'] = 0.2
	-- 		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{9},0,creatureID,creatureID,0.5)
	-- 		obj:addBuff(buff)
	-- 		obj:setDeadTime(lifeTime) 
	-- 	end	
	-- 	hitValueBoth = nil
	-- end
	-- local skill = self.attribute.skills[5]
	-- local parameters = skill.parameters
	-- if (mode==5) then
	-- 	self.mode5time = self.world:getGameTime() + parameters.BUFFTIME
	-- 	self.mode5in1time = self.world:getGameTime() + parameters.BUFFTIME
	-- 	hitValueBoth['bulletIsDebug']=true
	-- end

	-- if self.mode5time>self.world:getGameTime() then
	-- 	if (mode==2) then
	-- 		if (hitValueBoth['BURN_HURTFIX_RATE']==nil) then
	-- 			hitValueBoth['BURN_HURTFIX'] = 0
	-- 		end
	-- 		hitValueBoth['BURN_HURTFIX_RATE'] = parameters.BURN_HURTFIX_RATE2 + hitValueBoth['BURN_HURTFIX_RATE']
	-- 	end

	-- 	if (mode==3) then
	-- 		if (hitValueBoth['FROZEN_RATE']==nil) then
	-- 			hitValueBoth['FROZEN_RATE'] = 0
	-- 		end
	-- 		hitValueBoth['FROZEN_RATE'] = parameters.FROZEN_RATE2 + hitValueBoth['FROZEN_RATE'];
	-- 	end

	-- 	if (mode==4) then
	-- 		if (hitValueBoth['DIZZY_RATE']==nil) then
	-- 			hitValueBoth['DIZZY_RATE'] = 0
	-- 		end
	-- 		hitValueBoth['DIZZY_RATE'] = parameters.DIZZY_RATE2 + hitValueBoth['DIZZY_RATE'];
	-- 	end

	-- 	if (mode==2 or mode==3 or mode==4) then
	-- 		self.mode5time = self.world:getGameTime()
	-- 	end
	-- end

	-- if self.mode5in1time>self.world:getGameTime() and itemID~=self.itemID then
	-- 	if mode==1 then
	-- 		--BLEED_HURTFIX_RATE2=0,3,5,8,11,14,17,20,23,26,29,32,36,39,42,46,51,56,62,70,80
	-- 		local skill = self.attribute.skills[5] 
	-- 		local parameters = skill.parameters 
	-- 		hitValueBoth['MDEF_DOWN_RATE'] = parameters.MDEF_DOWN_RATE2
	-- 	end
	-- end

	-- if (mode==2) then
	-- 	self.creatureList = {}
	-- 	local skill = self.attribute.skills[2]
	-- 	local parameters = skill.parameters
	-- 	local distance = parameters.FIREDISTANCESHIFT1
	-- 	--debuglog('jaylog skill parameters : '..self.world.cjson.encode(skill.parameters)..' '..distance)
	-- 	local adjTime = parameters.FIRETIMESHIFT1
	-- 	--local lastAddTime = 0
	-- 	local toX,toY,num = 0,0,0
	-- 	for i=1,4 do
	-- 		--lastAddTime = self.world:getGameTime()
	-- 		--debuglog('jaylog distance : '..distance)
	-- 		if i==2 then
	-- 			distance = parameters.FIREDISTANCESHIFT2
	-- 			adjTime = parameters.FIRETIMESHIFT2
	-- 		elseif i==3 then
	-- 			distance = parameters.FIREDISTANCESHIFT3
	-- 			adjTime = parameters.FIRETIMESHIFT3
	-- 		elseif i==4 then
	-- 			distance = parameters.FIREDISTANCESHIFT4
	-- 			adjTime = parameters.FIRETIMESHIFT4
	-- 		end
	-- 		--debuglog('jaylog distance now : '..distance)
	-- 		toX,toY = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,distance/100)
	-- 		----debuglog('jaylog addCreature X:'..toX..' Y:'..toY..' i:'..i)
	-- 		num = self.world.formula:getRandnum(1,3)
	-- 		--debuglog('jaylog randNum:'..num)
	-- 		local creatureID = self.world:addCreature(self.world.tostring(104+num),self.teamOrig,self.posX+toX,self.posY+toY,self,1,adjTime)
	-- 		local obj  = self.world.allItemList[creatureID]
	-- 		self.creatureList[#self.creatureList+1]=creatureID
	-- 		local lifeTime=skill.parameters.DEAD
	-- 		local attributes = {}
	-- 		attributes['buffParameter']={}
	-- 		attributes['BUFFONLY']=1
	-- 		attributes['buffParameter'] = table.deepcopy(hitValueBoth)
	-- 		--attributes['buffParameter']['FIXHURT'] = 250
	-- 		attributes['buffParameter']['RANGE'] = parameters.FIRERADIUS  --obj.attribute.width * self.world.setting.AdjustAttRange
	-- 		attributes['buffParameter']['creatureDirectHurCallBack'] = creatureID
	-- 		--debuglog("addCreature  creatureID:"..creatureID)
	-- 		attributes['buffParameter']['buffType'] = 1
	-- 		attributes['buffParameter']['buffIntervalTime'] = 0.2
	-- 		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,lifeTime,{9},0,creatureID,creatureID,0.5)
	-- 		obj:addBuff(buff)
	-- 		obj:setDeadTime(lifeTime)
	-- 	end
	-- 	hitValueBoth = nil
	-- 	return hitValueBoth
	-- end

	if self.mode5inAllTime>self.world:getGameTime() then
		local skill = self.attribute.skills[5] 
		local parameters = skill.parameters
		--debuglog("法师buff增强 old APADJ:"..hitValueBoth['APADJ'])
		if hitValueBoth['APADJ']~=nil then
			hitValueBoth['APADJ'] = hitValueBoth['APADJ'] * parameters.DAMAGE_MULTIPLE/100
		else
			hitValueBoth['APADJ'] = parameters.APADJ2
		end
		--debuglog("法师buff增强 NEW APADJ:"..hitValueBoth['APADJ'])
		self.mode5inAllTime = 0
	end

	--4变5
	if mode==5 then
		local skill = self.attribute.skills[5] 
		local parameters = skill.parameters 
		-- local statusArray = {s=1000+skill.skillID,r=self.world:getGameTime(),t=parameters.BUFFTIME,i=self.itemID}
		-- self:addStatusList(statusArray,adjTime)
		self.mode5inAllTime = self.world:getGameTime() + parameters.BUFFTIME
	end

	if mode==1 then
		self.mode1bool = true
	end

	return hitValueBoth 
end 

--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero3:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 

	----debuglog('jaylog SHero3:hitTarget '..self.world.cjson.encode(hitValue))
	--HURTAD_HURT=30;HURTAP_HURT=30;BUFFTIME=10;COUNTER_RATE=10;APADJ2=100;ADADJ2=0;BACKWARD2=200;CDTIME=30
	if mode==7 then
		local obj = self.world.allItemList[itemID]
		local skill = self.attribute.skills[7] 
		local parameters = skill.parameters 

		local toX,toY = self.world.map:getXYLength(obj.posX,obj.posY,self.lastBulletPositionX,self.lastBulletPositionY,(parameters.BACKWARD2)/self.world.setting.AdjustAttRange)
		local ret
		--print("prepareHit 飞飞飞........ x tox y toy distance ",self.posX,toX,self.posY,toY,(skill.atkDis-parameters.MOVECUT)/self.world.setting.AdjustAttRange)
		ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 

		obj:moveTo(toX,toY,false,6,skill.bulletSpeed,adjTime+skill.hitTime) 
	end

	if mode==1 and self.mode1bool then
		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters 
		local attributes = {}
		attributes['CRI_UPFIX_RATE'] = parameters['CRI_UPFIX_RATE2']
		attributes['CRI_UPFIX'] = parameters['CRI_UPFIX2'] 
		-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,parameters['BUFFTIME2'],{},0,self.itemID,self.itemID,0.1)
		local buff = self.world:createBuff(self:__skillID2buffID(skill.skillID),attributes,parameters['BUFFTIME2'],{},0,self.itemID,self.itemID,0.1)
		self:addBuff(buff)
		self.mode1bool = false

	end

	ret = SHero3.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	return ret 
end 


--- 自动移动chud
-- @return null
function SHero3:_autoMove()
	-- --debuglog("SHero:_autoMove")
	local moveRet=self.autoFightAI:autoMoveToAlerted()
	local ret=SHero3.super._autoMove(self)
	if not ret and not self.autoBlocked and self.AIlastMoveTime < self.world:getGameTime() and  not self:isDead() and not moveRet and self.statusList[4007]==nil then
		
		self.autoFightAI:autoMoveToHero()
		self.AIlastMoveTime = self.moveToEndTime

	end
	return ret
end


return SHero3 
