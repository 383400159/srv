local SHero4 = class("SHero4", require("gameroom.hero.SHero")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @param actorID int - 游戏房玩家序号ID
-- @return null
function SHero4:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SHero4" 
	end 
	--4变5
	self.mode5time = 0
	self.mode5in1time = 0
	--反击时间
	self.mode5timefj = 0

	self.mode7time = 0
	--天启者天赋减cd次数
	self.CDTIMECLEARFIXNUM=0

	self.mode1bool = false
	----debuglog('jaylog SHero4:ctor before super')
	SHero4.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	----debuglog('jaylog SHero4:ctor after super')
end 



--重载AI
function SHero4:_autoFightToHero()

	--需要判断队友是否没血了
	--获得队友列表
	if self.world.heroNeedSkillID~=nil and self.world.heroNeedSkillID>0 then
		ret = true
	else

		ret = false
		if (self.teamOrig=="A") then
			teamlist=self.world.itemListFilter.heroTeamAList
		else
			teamlist=self.world.itemListFilter.heroTeamBList
		end
		local skill4 = self.attribute.skills[4]
		local skill3 = self.attribute.skills[3]  
		
		--原地扫描附近队友
		if skill3.lastCoolDownTime<self.world:getGameTime() then
			--需要回复的列表
			local targetList = {}
			local visRange={posX=self.posX,posY=self.posY,radius=skill3.atkDis/self.world.setting.AdjustVisRange}

			for k,value in pairs(teamlist) do
				ok = true
				if (value:isDead()) then ok =false end
				if (value.attribute.HP<=0) then ok =false end
				if (value.attribute.actorType~=0) then ok =false end
				if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
				if ok and (value.attribute.HP/value.attribute.MaxHP)<0.8 then
					local d = value:colliding(visRange,0,0,self.itemID)
					if d>=0 then
						targetList[#targetList+1] = {id=value.itemID,hpScale=(value.attribute.HP/value.attribute.MaxHP)*100}
					end
				end
			end
			--debuglog("奶爸AI mode3 AI targetList:"..self.world.cjson.encode(targetList))
			-- if #targetList>0 then
			-- 	self.world.tSort(targetList,function( a1,b1 )
			-- 						return a1['hpScale'] < b1['hpScale']
			-- 					end)
			-- 	-- ret = self:skillAttack(3,self.itemID)
			-- 	local obj1 = self.world.allItemList[targetList[1]['id']]
			-- 	ret = self:skillAttack(4,0,obj1.posX,obj1.posY,false,true)
			-- end
			

			--赛选出最优的几个队友
			----debuglog(" skill3 AI targetList:"..self.world.cjson.encode(targetList))
			if #targetList>0 or (self.attribute.HP/self.attribute.MaxHP)<0.8 then
				ret = self:skillAttack(3,self.itemID)
			end
		end


		--远程甩技能回血
		if skill4.lastCoolDownTime<self.world:getGameTime() and self.world.gameRoomSetting.ISGVB==1 then
			--需要回复的列表
			local targetList = {}
			for k,value in pairs(teamlist) do
				ok = true
				if (value:isDead()) then ok =false end
				if (value.attribute.HP<=0) then ok =false end
				if (value.attribute.actorType~=0) then ok =false end
				if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
				if ok and (value.attribute.HP/value.attribute.MaxHP)<0.7 then
					targetList[#targetList+1]={id=value.itemID,hpScale=(value.attribute.HP/value.attribute.MaxHP)*100}
				end
			end
			--debuglog("奶爸AI AI targetList:"..self.world.cjson.encode(targetList))
			--赛选出最优的几个队友
			local dislist = {}
			if #targetList>0 then
				--根据生命比例选择第一优先目标
				self.world.tSort(targetList,function( a1,b1 )
									return a1['hpScale'] < b1['hpScale']
								end)
				--debuglog("奶爸AI targetList:"..self.world.cjson.encode(targetList))
				local obj1 = self.world.allItemList[targetList[1]['id']] 
				for i=2,#targetList do
					local obj2 = self.world.allItemList[targetList[i]['id']] 
					local d = self.world.mPow(self.world.mPow(obj1.posX-obj2.posX,2) + self.world.mPow(obj1.posY-obj2.posY,2),0.5)	
					if d<(skill4.atkDis/self.world.setting.AdjustVisRange) and (obj2.attribute.HP/obj2.attribute.MaxHP)<0.7 then
						dislist[#dislist+1] ={id=targetList[i]['id'],DIS=d} 
					end
				end	
				self.world.tSort(dislist,function( a1,b1 )
									return a1['DIS'] < b1['DIS']
								end)
				--根据距离选择最佳投放点
				if #dislist>0 then
					local obj3 = self.world.allItemList[dislist[1]['id']] 
					--debuglog("奶爸AI 加血  主联ID:"..obj1.itemID.." 共联ID:"..dislist[1]['id'].." posX:"..obj1.posX.." posY:"..obj1.posY.." posX1:"..obj3.posX.." posY1:"..obj3.posY)
					ret = self:skillAttack(4,0,(obj3.posX+obj1.posX)/2,(obj3.posY+obj1.posY)/2,false,true)
					--ret = self:skillAttack(4,targetList[1]['id'])
				else
					--debuglog("奶爸AI 加血  非共联ID:"..obj1.itemID.." posX:"..obj1.posX.." posY:"..obj1.posY)
					ret = self:skillAttack(4,obj1.itemID)
				end

			end
		end

	end

	if not ret then
		SHero4.super._autoFightToHero(self) 
	end
end


--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SHero4:goToDead(itemID,mode,adjTime,bonus)  
	SHero4.super.goToDead(self,itemID,mode,adjTime,bonus) 
end 

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SHero4:prepareHit(mode,adjTime,buff)  


	self.CDTIMECLEARFIXNUM = 0
	local hitValueBoth=SHero4.super.prepareHit(self,mode,adjTime,buff) 
	--4变5
	--ADADJ=0;APADJ=0;REBOUND_HURT_RATE2=10;REBOUND_HURT2=50;BUFFTIME2=5;CDTIME=20
	if mode==5 then
		local skill = self.attribute.skills[5] 
		local parameters = skill.parameters
		self.mode5timefj = parameters.BUFFTIME + self.world:getGameTime()
		-- self.mode5time = parameters.BUFFTIME2 + self.world:getGameTime()
		-- self.mode5in1time = parameters.BUFFTIME2 + self.world:getGameTime()

	end

	--HURTAD_HURT=30;HURTAP_HURT=30;BUFFTIME=10;COUNTER_RATE=10;ADADJ2=0;APADJ2=0;HURTAD_HURT2=100;HURTAD_HURT_RATE2=100;BUFFTIME2=5;CDTIME=30
	if mode==7 then
		local skill = self.attribute.skills[7] 
		local parameters = skill.parameters
		local attributes = {}
		attributes['HURTAD_HURT'] = parameters.HURTAD_HURT2
		attributes['HURTAD_HURT_RATE'] = parameters.HURTAD_HURT_RATE2
		attributes['HURTAP_HURT'] = parameters.HURTAP_HURT2
		attributes['HURTAP_HURT_RATE'] = parameters.HURTAP_HURT_RATE2
		attributes['BUFFTIME'] = parameters.BUFFTIME2
		-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,parameters.BUFFTIME2,{},0,self.itemID,self.itemID,0)
		local buff = self.world:createBuff(self:__skillID2buffID(skill.skillID,0),attributes,parameters.BUFFTIME2,{},0,self.itemID,self.itemID,0)
		self:addBuff(buff)
	end

	-- if self.mode5time>self.world:getGameTime() and itemID~=self.itemID then
	-- 	local skill = self.attribute.skills[5] 
	-- 	local parameters = skill.parameters 
	
	-- 	if mode==2 then
	-- 		--SILIENCE_RATE2=0,3,5,8,11,14,17,20,23,26,29,32,36,39,42,46,51,56,62,71,80;BUFFTIME3=3
	-- 		if parameters.SILIENCE_RATE2>hitValueBoth['SILIENCE_RATE'] then
	-- 			hitValueBoth['SILIENCE_RATE'] = parameters.SILIENCE_RATE2
	-- 		end
	-- 		if parameters.BUFFTIME3>hitValueBoth['BUFFTIME'] then
	-- 			hitValueBoth['BUFFTIME'] = parameters.BUFFTIME3
	-- 		end
	-- 	end
	-- 	if mode==3 then
	-- 		--SHIELD_UPFIX_RATE2=0,100;SHIELD_UPFIX2=0,27,55,83,112,142,172,202,233,265,297,330,363,397,431,466,518,574,632,718,810;BUFFTIME4=5
	-- 		----debuglog("SHIELDSHIELDSHIELDSHIELDSHIELD....:"..parameters.SHIELD2)
	-- 		hitValueBoth['SHIELD_UPFIX'] = parameters.SHIELD_UPFIX2 + (hitValueBoth['SHIELD_UPFIX']~=nil and hitValueBoth['SHIELD_UPFIX'] or 0)
	-- 		if parameters.SHIELD_UPFIX_RATE2>hitValueBoth['SHIELD_UPFIX_RATE'] then
	-- 			hitValueBoth['SHIELD_UPFIX_RATE'] = parameters.SHIELD_UPFIX_RATE2
	-- 		end
	-- 		if parameters.BUFFTIME4>hitValueBoth['BUFFTIME'] then
	-- 			hitValueBoth['BUFFTIME'] = parameters.BUFFTIME4
	-- 		end
	-- 	end
		-- if mode==4 then
		-- 	--APADJ2=0,17,34,51,69,87,106,125,144,163,183,203,224,245,266,287,320,354,390,443,500;SENSE_RATE2=0,100;BUFFTIME5=3
		-- 	--debuglog("添加一个群体aoe...........0")
		-- 	local skill4 = self.attribute.skills[4] 
		-- 	local parameters4 = skill4.parameters 
		-- 	local skill = self.attribute.skills[5] 
		-- 	local parameters = skill.parameters 

		-- 	local attackRange = {posX=self.lastBulletPositionX,posY=self.lastBulletPositionY,radius=skill4.atkDis/self.world.setting.AdjustAttRange} 

		-- 	local hitValueNew = self:getPrepareHithitValue()
		-- 	--debuglog("parameters:..."..self.world.cjson.encode(parameters))
		-- 	hitValueNew['skillID'] = 4
		-- 	hitValueNew['APADJ'] = parameters4.APADJ3 + parameters.APADJ2  + (hitValueNew['APADJ']~=nil and hitValueNew['APADJ'] or 0)
		-- 	hitValueNew['SENSE_RATE'] = parameters.SENSE_RATE2
		-- 	hitValueNew['BUFFTIME'] = parameters.BUFFTIME5
		-- 	local bullet = require("gameroomcore.SBullet").new(self.world,4,self.itemID,skill4.hitTime,0,self.lastBulletPositionX,self.lastBulletPositionY)
		-- 	bullet:directFightAura(1,attackRange,hitValueNew,bullet.attr.angle,skill4.degree) 
		-- 	bullet:setDead() 
		-- 	--debuglog("添加一个群体aoe...........")
		-- end

	-- 	if mode==2 or mode==3 or mode==4 then
	-- 		self.mode5time=self.world:getGameTime()
	-- 	end
	-- end


	if mode==3 then
		--debuglog("添加一个群体aoe...........0")
		local skill3 = self.attribute.skills[3] 
		local parameters3 = skill3.parameters 


		local attackRange = {posX=self.posX,posY=self.posY,radius=skill3.atkDis/self.world.setting.AdjustAttRange} 

		local hitValueNew = self:getPrepareHithitValue()
		--debuglog("parameters:..."..self.world.cjson.encode(parameters3))
		hitValueNew['skillID'] = 3
		hitValueNew['APADJ'] = parameters3.APADJ3 + (hitValueNew['APADJ']~=nil and hitValueNew['APADJ'] or 0)
		--hitValueNew['SENSE_RATE'] = parameters.SENSE_RATE2
		hitValueNew['BUFFTIME'] = parameters3.BUFFTIME
		--local bullet = require("gameroomcore.SBullet").new(self.world,3,self.itemID,skill3.hitTime,0,self.posX,self.posY)
		--self:directFightAuratoDalay(0,attackRange,hitValueNew,0,skill4.angle,skill4.degree)
		self:directFightAuratoDalay(3,0,hitValueNew,{posX=self.posX,posY=self.posY,RANGE=skill3.atkDis},parameters3.HURTHITTIME)
		-- bullet:directFightAura(1,attackRange,hitValueNew,bullet.attr.angle,skill3.degree) 
		-- bullet:setDead() 
		--debuglog("添加一个群体aoe...........")

		if hitValueBoth['SHIELDATK']~=nil and hitValueBoth['SHIELDATK']>0 then
			hitValueBoth['HPEXTRA_UPFIX'] = hitValueBoth['SHIELDATK']*0.01*hitValueBoth['ATK']
			hitValueBoth['HPEXTRA_UPFIX_RATE'] = 100
		end

	end

	if mode==4  then
			--APADJ2=0,17,34,51,69,87,106,125,144,163,183,203,224,245,266,287,320,354,390,443,500;SENSE_RATE2=0,100;BUFFTIME5=3
			--debuglog("添加一个群体aoe...........0")
			local skill4 = self.attribute.skills[4] 
			local parameters4 = skill4.parameters 


			-- local attackRange = {posX=self.lastBulletPositionX,posY=self.lastBulletPositionY,radius=skill4.atkDis/self.world.setting.AdjustAttRange} 

			local hitValueNew = self:getPrepareHithitValue()
			-- --debuglog("parameters:..."..self.world.cjson.encode(parameters4))
			-- hitValueNew['skillID'] = 4
			-- hitValueNew['APADJ'] = parameters4.APADJ3 + (hitValueNew['APADJ']~=nil and hitValueNew['APADJ'] or 0)
			-- --hitValueNew['SENSE_RATE'] = parameters.SENSE_RATE2
			-- hitValueNew['BUFFTIME'] = parameters4.BUFFTIME
			-- local bullet = require("gameroomcore.SBullet").new(self.world,4,self.itemID,skill4.hitTime,0,self.lastBulletPositionX,self.lastBulletPositionY)
			-- --self:directFightAuratoDalay(1,attackRange,hitValueNew,0,skill4.angle,skill4.degree)
			-- bullet:directFightAura(1,attackRange,hitValueNew,bullet.attr.angle,skill4.degree) 
			-- bullet:setDead() 
			-- --debuglog("添加一个群体aoe...........")

			local creatureID=self.world:addCreature(self.world.tostring(102),self.teamOrig,self.lastBulletPositionX,self.lastBulletPositionY,self,1,0)
			local obj  = self.world.allItemList[creatureID]
			self.creatureList[#self.creatureList+1]=creatureID  
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			attributes['buffParameter']=hitValueNew
			attributes['buffParameter']['changeMode']=mode
			attributes['buffParameter']['RANGE'] = skill4.atkDis
			attributes['buffParameter']['SENSE_RATE'] = hitValueBoth['SENSE_RATE']
			attributes['buffParameter']['BUFFTIME'] = hitValueBoth['BUFFTIME']
			attributes['buffParameter']['APADJ'] = parameters4.APADJ3 + (hitValueNew['APADJ']~=nil and hitValueNew['APADJ'] or 0)
			----debuglog("jaylog addCreature  creatureID:"..creatureID)
			attributes['buffParameter']['buffType'] = 1			--parameters.PASSNUM
			attributes['buffParameter']['buffIntervalTime'] = skill4.bulletTimeInterval
			attributes['BUFFTIME'] = parameters4.BUFFTIME
			-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill4.skillID),attributes,skill4.duration,{99},0,self.itemID,obj.itemID,skill4.hitTime)
			local buff = self.world:createBuff(self:__skillID2buffID(skill4.skillID),attributes,skill4.duration,{99},0,self.itemID,obj.itemID,skill4.hitTime)
			--buff.debug = true
			--self:addBuff(buff)
			obj:addBuff(buff)
			obj:setDeadTime(skill4.duration) 

			hitValueBoth['SENSE_RATE'] = 0
			-- local customize={attackMode=3,degree=0,AtkDis=parameters['=']['RANGE'][level],BulletSpeed=99999,targetType=skill.targetType} 
			-- hitValueBoth['E']['CHECK']=obj.itemID 
			-- self.world:addBullet(mode,self.itemID,adjTime+self.world:getGameTime()+skill.HitTime+delay,self.itemID,obj.posX,obj.posY,false,hitValueBoth,customize) 
		
	end

	-- if self.mode5in1time>self.world:getGameTime() and itemID~=self.itemID then
	-- 	if mode==1 then
	-- 		--BLEED_HURTFIX_RATE2=0,3,5,8,11,14,17,20,23,26,29,32,36,39,42,46,51,56,62,70,80
	-- 		local skill = self.attribute.skills[5] 
	-- 		local parameters = skill.parameters 
	-- 		hitValueBoth['SENSE_RATE'] = parameters.SENSE_RATE2
	-- 		hitValueBoth['BUFFTIME'] = parameters.BUFFTIME6
	-- 	end
	-- end

	if mode==1 then
		self.mode1bool = true
	end

	return hitValueBoth 
end 

--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero4:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	
	--以自身为圆心，范围内（约5个身位）目标瞬间治疗。

	if (hitValue['CDTIMECLEARFIX']~=nil and hitValue['CDTIMECLEARFIX']>0 and self.CDTIMECLEARFIXNUM==0 ) then
		local cdR = self.world.formula:getRandnum(0,100)
		if cdR<=hitValue['CDTIMECLEARRATE']  then
			self.callBackEndBullet = self.lastBulletID
			--debuglog("全体技能减CD........."..hitValue['CDTIMECLEARFIX'].." callBackEndBullet:"..self.callBackEndBullet)
			local sk = self.attribute.skills
			local gt = self.world:getGameTime()
			for i=2,5 do
				if sk[i] ~=nil then
					sk[i].lastCoolDownTime = sk[i].lastCoolDownTime - hitValue['CDTIMECLEARFIX']
					--debuglog("全体技能减CD.........i:"..i.." lastCoolDownTime:"..sk[i].lastCoolDownTime)
				end
			end
			self:syncSkill(0)
		end
		self.CDTIMECLEARFIXNUM = 1
	end	

	if mode==3 then
		hitValue['FIXREHP'] = self.world.mAbs(hitValue['APADJ2']*self.attribute.ATK*0.01)
	end

	--5变4
	if mode==4 then
		hitValue['FIXREHP'] = self.world.mAbs(hitValue['APADJ2']*self.attribute.ATK*0.01)
	end

	-- if mode==1 and self.mode1bool then
	-- 	local skill = self.attribute.skills[1] 
	-- 	local parameters = skill.parameters 
	-- 	local attributes = {}
	-- 	attributes['CRI_UPFIX_RATE'] = parameters['CRI_UPFIX_RATE2']
	-- 	attributes['CRI_UPFIX'] = parameters['CRI_UPFIX2'] 
	-- 	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,parameters['BUFFTIME2'],{},0,self.itemID,self.itemID,0.1)
	-- 	self:addBuff(buff)

	-- 	-- hitValue['REHP'] = parameters['REHP2']

	-- 	-- local hitValueNew = {}
	-- 	-- hitValueNew['REHP']  = parameters['REHP2']
	-- 	-- self:directHurt(self.itemID,mode,hitValueNew,0) 
	-- 	----debuglog("REHP:"..hitValue['REHP'])
	-- 	self.mode1bool = false
	-- end

	ret = SHero4.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	
	return ret 
end 


--- 受傷害計算,调用SActor的hurted
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero4:hurted(itemID,bulletID,mode,hitValue,adjTime)

	local hurt = SHero4.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
	--4变5
	--ADADJ=0;APADJ=0;REBOUND_HURT_RATE2=10;REBOUND_HURT2=50;BUFFTIME2=5;CDTIME=20
	if self.mode5timefj>self.world:getGameTime() and itemID ~= self.itemID and hurt>0  and hitValue['isREBOUND']==nil  then
		local skill = self.attribute.skills[5] 
		local parameters = skill.parameters 

		math.randomseed(os.time()+adjTime*54671)
		--self.world:setRandomSeed()
		local rand = self.world.mRandom(0,100)

		if rand<parameters.REBOUND_HURT_RATE2 then
			local hitValueNew = {}
			hitValueNew['FIXHURT']  = hurt * parameters.REBOUND_HURT2 * 0.01
			hitValueNew['isREBOUND']  = true
			self.world.allItemList[itemID]:directHurt(self.itemID,5,hitValueNew,0) 
		end
	end

	return hurt
end



return SHero4 
