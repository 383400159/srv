debuglog('jaylog SHero worldForHero:'..worldForHero)
local SHero = class("SHero", require("gameroom.hero.SHeroInWorld"..worldForHero))

--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @param actorID int - 游戏房玩家序号ID
-- @return null
function SHero:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	--debuglog("进来没！！！！！！！！！！！！！！")	

	if (self.className==nil) then 
		self.className="SHero" 
	end 

	if loginID==nil then loginID = "" end
	if skinNum==nil then skinNum = 0 end


	self.paths={}						--AI行进路线
	self.attackTarget=nil 	--攻击目标
	self.attribute={}				--英雄属性设置
	self.actorType=0 				--角色类型
	self.posX=12 						--位置X坐标
	self.posY=140 					--位置Y坐标
	self.lastPosX=0 				--上次位置X坐标
	self.lastPosY=0 				--上次位置Y坐标
	self.team =nil 					--队伍
	self.teamOrig = nil 		--原来队伍
	self.world =nil 				--world Obj
	self.parent=nil 				--父类

	self.itemID=actorID 								--游戏房角色num
	self.deadTime=0 							--死亡时间
	self.deadFlag=0 							--死亡状态
	self.dirty=0
	self.debug=false

	self.status=0 -- 0=idle , 1=walk , 2=standby , 3=fight , 4=blockwait , 5=special , 6=dizzy , 7=freeze
	self.statusList={}

	self.syncMsg={}
	self.lastBulletID=0
	self.buffList={}
	
	self.isVisible=0 -- 1=yes 2=no -1=hidden 0=undeclared
	self.lastIsVisible=0 -- 1=yes 2=no -1=hidden 0=undeclared

	self.isGrass=0 -- 1=yes 2=no 0=undeclared

	self.lastAttackID=0  -- last attack id
	self.lastAttackTime=0 -- keep 3 second

	self.lastTowerPosition=nil
	self.lastTowerID=0

	self.visibleList={}

	self.skeleton=0

	self.prepareSkillAttackNum=0 -- wait for skill attack, skill order (mode 1-4)
	self.lastBulletPositionX=0 -- skill attack , start from position X 
	self.lastBulletPositionY=0 -- skill attack , start from position Y
	self.lastBulletTarget=0 -- skill attack , start from position Y
	self.lastHeroAttack=0 -- last attacked by enemy Hero
	
	self.heroAttack={} -- record the time of last attacked by enemy Hero

	self.comboKillHero=0
	self.comboKilled=0

	self.lastKillHero=0
	self.lastKilledByHero={}
	self.lastKillHeroTime=0
	self.playerObj=nil
	self.playerJson=nil
	self.playerHeroesObj=nil
	self.playerHeroesJson=nil

	self.bonus={}
	self.bonusType={}

	self.skinNum=0

	self.isSurrender=nil
	self.surrenderOrder=0

	self.lastControlTime=0
	self.lastOfflineTime=0
	self.totalIdleTime=0
	self.maxIdleTime=0

	self.openprint=0
	self.checkOverLapTime=0 


	self.starList={}

	self.autoBlocked=false
	--第一次进游戏
	self.beginGame = true

	--任务list
	self.taskList={}
	self.checkNPCList={}

 
	self.world = world

	self.skinNum = skinNum

	if loginID~="" then
		self.loginID = loginID
		--if world.playerList[world:getItemID()]['playerJson']~=nil then
		self:D('jaylog SHero:ctor itemID',actorID)
		if world.playerList[actorID]['playerJson']~=nil then
			self.playerJson = world.playerList[actorID]['playerJson']
			self:D("skinHeroes playerJson",self.world.cjson.encode(self.playerJson))
		end

	end

	self:D('jaylog SHero:ctor before call super')
	SHero.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.debug=false
	self:D(" loginID :"..world.playerList[self.itemID]['id'])
	if   world.playerList[self.itemID]['id']=='AI奶爸' or world.playerList[self.itemID]['id']=='ywvvvvvvvv' or world.playerList[self.itemID]['id']=='ywnjjjj'  then
			self.AImode=1
	else
			self.AImode=0
	end

	self.redirectRoomTime = 0
	self.autoMove = false				--自动寻路
	self.movePath = {}					--自动寻路路线
	self.autoFollow = false			--自动跟随
	self.autoFollowTargetID = 0 	--自动跟随目标ID
	self.autoFollowTime = 0 			--自动跟随moveTo时间
	self.lastMoveTime = 0					--上次移动时间

	-- API Call 顺序号seqNo
	self.seqNo = {
		task = 0,
	}

	self.creatureList={}

	self.autoFightAI = require("gameroom.ai.SAIHero").new(self)

end 

--- move motion , call every update loop
-- @return null
function SHero:move() 
	-- if self.moveStopTime>self.world.gameTime then
	-- 	return nil
	-- end
	SHero.super.move(self)

	if  self.lastControlTime+3<self.world:getGameTime() and self.lastCoolDownTime<self.world:getGameTime() then
		if self.heroIdleTime==0 then
			self.heroIdleTime = self.world:getGameTime()
		end
		if (self.AImode>0) and self.autoBlocked and self.heroIdleTime+0<self.world:getGameTime() then
			self.autoBlocked = false
		else
			self.autoBlocked = true
		end
	else
		self.heroIdleTime = 0
	end

	-- 檢查上馬
	self:prepareSkillAttackMode7(true)
	-- 刷新能源版的状态
	self.attribute.energyBoard:updateStatus()

end

--- init funtion 初始化属性参数
-- @param id int - role id
-- @param posX int - 起始坐标X
-- @param posY int - 起始坐标Y
-- @return null
function SHero:__init(id,posX,posY)
	self:D('jaylog SHero:__init before '..self.itemID)
	self.attribute = require("gameroom.attribute.SAttributeHero").new(id,1,self) --- level 1
	self.initX = posX
	self.initY = posY
	self.prepareSkillAttackNum = 0
	self.lastBulletPositionX = 0
	self.lastBulletPositionY = 0
	self.lastHeroAttack = -1
	self.lastHeroAttackForTower = -1

	self.taskObj = require("gameroom.STask").new(self)	
	self.counterObj = require("gameroom.SCounter").new(self)
	-- self.nextREHPMPTime = self.world:getGameTime()
	self:D('jaylog SHero:__init after '..self.itemID)
end


--- 设置技能限制施放时间
-- @param skill table - 角色某一招技能的所有设置值
-- @return null
function SHero:useCDTime(skill)
	local cooldown = 0
	debuglog(" skill :"..self.world.cjson.encode(skill['parameters']))
	if skill.rank~=1 then
		cooldown = skill.parameters.CDTIME
	else
		cooldown = skill.parameters['CDTIME'..self.mode1step]	
	end

	skill.lastCoolDownValue = cooldown
	skill.lastCoolDownTime = self.world:getGameTime() + skill.lastCoolDownValue
	debuglog("useCDTime CDTIME:"..cooldown )
	debuglog("useCDTime lastCoolDownTime:"..skill.lastCoolDownTime )
	local sk = self.attribute.skills
	local gt = self.world:getGameTime()
	for i=2,7 do
		if sk[i] ~=nil then
			debuglog("useCDTime 增加公共cd..i:"..self.attribute.skills[i].lastCoolDownTime)
			debuglog("useCDTime 增加公共cd..g:"..self.world:getGameTime())
			if sk[i].lastCoolDownTime<(gt+skill.cutTime) then
				sk[i].lastCoolDownTime = gt+skill.cutTime
				debuglog("useCDTime 增加公共cd..n:"..self.attribute.skills[i].lastCoolDownTime)
			end
		end
	end
end

--- 使用技能伤害，call父类的skillAttack
-- @param mode int - 技能 1-8 rank
-- @param itemID int - 攻擊目標 itemID
-- @param positionX float - 攻擊目標 位置 X
-- @param positionY float - 攻擊目標 位置 Y
-- @param force bool - true ＝ 無視失控, 失控時攻擊目標用
-- @param fromClientSide bool - true ＝ 來自客戶端
-- @return msg table - 返回msg 給client 包括action move skillstatus
function SHero:skillAttack(mode,itemID,positionX,positionY,force,fromClientSide,nPara,pPara)
	--debuglog("skillAttack........mode :",mode)
	return SHero.super.skillAttack(self,mode,itemID,positionX,positionY,force,fromClientSide,nPara,pPara)
end


-- --{"sk":[ {"s":1 , "l":1 ,"t":1.01 ,"cd":5 },{"s":2 , "l":1 ,"t":1.01 ,"cd":5 } ]}
--- sync skill信息给client端
-- @param delay float - 延迟执行时间
-- @return status table - 格式：{"sk":[ {"s":1 , "l":1 ,"t":1.01 ,"cd":5 },{"s":2 , "l":1 ,"t":1.01 ,"cd":5 } ]}
function SHero:syncSkill(delay)
	if delay==nil then delay = 0 end
	local status = {sk={i=self.itemID,a={}}}
	local t,cd
	for k,v in pairs(self.attribute.skills) do
		t = v.lastCoolDownTime-self.world:getGameTime()
		cd = v.parameters.CDTIME
		if t<=0 and v.lastCoolDownTime>=0 then
			t = 0.01
		elseif t<0 then
			t = 0
		end

		if v.rank~=nil and cd~=nil and v.rank>1 and cd>0 then
			status['sk']['a'][#status['sk']['a']+1] = {d=delay,s=v.rank,t=t,cd=cd}
		end
	end
	self:updateSyncMsg(status)
	return status['sk']['a']
end


--- 發動攻擊
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return ret float - 傷害值
function SHero:hitTarget(itemID,bulletID,mode,hitValue,adjTime)
	local CRItype = 0
	--APADJ=0;ADADJ=50;CDTIME1=0.76;CDTIME2=0.53;CDTIME3=0.76;CDTIME4=0.53;CDTIME5=1;ATKMOVEDIS_S1=50;ATKMOVEDIS_S2=50;ATKMOVEDIS_S3=50;ATKMOVEDIS_S4=50;ATKMOVEDIS_S5=50
	if mode==1 then
			local skill = self.attribute.skills[mode]
			local parameters = skill.parameters 
		if self.mode1order>0 then
			-- local carom = skill.carom
			-- local carom_interval = skill.carom_interval
			self:D("carom:",carom)
			self:D("carom_interval:",carom_interval)
			local caromlist = skill.carom
			self:D("caromlist :",self.world.cjson.encode(caromlist))	
			
			-- if caromlist[self.mode1order]==nil then
			-- 	--阶段上限
			-- 	self.mode1order = 1
			-- 	self.mode1type = 0
			-- end
			
			local caromCrilist = string.split(caromlist[self.mode1order],",")
			self:D("caromCrilist :",self.world.cjson.encode(caromCrilist))	
			--获得间隔时间
			local caromitvlist = skill.carom_interval
			local caromitvtimelist = string.splitNumber(caromitvlist[self.mode1order],",")
			self:D("caromitvtimelist :",self.world.cjson.encode(caromitvtimelist))	
			local atknum =  #caromCrilist

			local mode1delaytime = 0
			for i=1,atknum do
				self:D("mode1 打几下,atknum:",atknum)
				CRItype = self.world.tonumber(caromCrilist[i])
				hitValue['SEPARATE'] = 100/atknum
				self:D("mode1 打几下,hitValue['SEPARATE']:",hitValue['SEPARATE'])
				--计算普通攻击伤害
				--self.world:setRandomSeed()
				local CRIhurt = self.world.formula:modeCriHurt(CRItype)
				hitValue['CRIhurt'] = CRIhurt 
				--减掉第一下攻击延迟
				mode1delaytime = caromitvtimelist[i]+adjTime - caromitvtimelist[1]
				self:D("mode1 打几下,mode1delaytime:",mode1delaytime)
				ret = SHero.super.hitTarget(self,itemID,bulletID,mode,hitValue,mode1delaytime)
			end
		else
			--普通攻击冲刺
			CRItype = self.world.tonumber(parameters['PREATKCAROM'..self.mode1step])
			local CRIhurt = self.world.formula:modeCriHurt(CRItype)
			hitValue['CRIhurt'] = CRIhurt 
			ret = SHero.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime)
		end
		-- if caromlist[self.mode1order]~=nil then
		-- 	--切换阶段 阶段+1
		-- 	if  caromlist[self.mode1order+1]~=nil then
		-- 		self.mode1type = self.world.tonumber(caromCrilist[1])
		-- 		self.mode1order = self.mode1order + 1
		-- 	else	
		-- 		self.mode1order = 1
		-- 		self.mode1type = 0
		-- 	end
		-- end

		self:D("mode1 self.mode1order :",self.mode1order)
		-- debuglog("self.mode1star :",self.mode1star)
		-- debuglog("caromCrilist :",self.world.cjson.encode(caromCrilist))
		-- self.mode1atktime = self.world:getGameTime()

	else
		local carom = self.attribute.skills[mode].carom
		CRIhurt = self.world.formula:modeCriHurt(self.world.tonumber(carom[1]))
		hitValue['CRIhurt'] = CRIhurt 
	end
	


	if mode~=1 then
		local skill={}
		if mode>100 then
			skill = self.attribute.skills[mode-100]
		else
			skill = self.attribute.skills[mode]
		end
		
		if skill~=nil and skill.demonObj~=nil then
			skill.demonObj:hitTargetPrepare(itemID,bulletID,mode,hitValue,adjTime)
		end
		ret = SHero.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime)
		if skill~=nil and skill.demonObj~=nil then
			ret = skill.demonObj:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)
		end
	end



	debuglog("SHero:hitTarget.."..mode)
	return ret
end

--- 受傷害計算
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero:hurted(itemID,bulletID,mode,hitValue,adjTime)


	local fromObj = nil
	if itemID>0 then
		fromObj = self.world.allItemList[itemID]
	end


	if itemID>0 and fromObj.attribute.actorType==0 and fromObj.teamOrig~=self.teamOrig then
		self.lastHeroAttack = itemID
		self.lastHeroAttackTime = self.world.gameTime
		self.heroAttack[itemID] =self.world.gameTime
		if (hitValue['Effect']==nil or hitValue['Effect']==1 or hitValue['Effect']==9) and (hitValue['NoTowerProtect']==nil or hitValue['NoTowerProtect']~=1) then
			self.lastHeroAttackForTower = itemID
		end
	elseif itemID>0 and fromObj.parent~=nil and fromObj.parent.attribute~=nil and fromObj.parent.attribute.actorType==0 and fromObj.parent.teamOrig~=self.teamOrig then
		self.lastHeroAttack = fromObj.parent.itemID
		self.lastHeroAttackTime = self.world.gameTime
		self.heroAttack[fromObj.parent.itemID] = self.world.gameTime

		if (hitValue['Effect']==nil or hitValue['Effect']==1 or hitValue['Effect']==9) and (hitValue['NoTowerProtect']==nil or hitValue['NoTowerProtect']~=1) then
			self.lastHeroAttackForTower = fromObj.parent.itemID
		end
	end


	local hurt = SHero.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
	if hurt>0 then
		self.attribute.energyBoard:run("TRIGGERLOWER_HP",{HP=self.attribute.HP,MaxHP=self.attribute.MaxHP})
	end

	return hurt
end



--- 调整自身HP值
-- @param hp float - 调整的值
-- @param forceSync boolean - 强制syn玩家HP数据到client
-- @param must boolean - 无视任何状态都扣血
-- @return ret boolean - 是否成功调整HP
function SHero:adjHP(hp,forceSync,must) 
	if forceSync ==nil then forceSync = false end
	if must ==nil then must = false end

	local ret = SHero.super.adjHP(self,hp,forceSync,must) 
	return ret 
end

--- 由getAttributeAndSync调用，用于组织heroInfo信息
function SHero:getAttribute(syncMsg)
	if syncMsg==nil then syncMsg = false end
	local msg = {
		hi = {
			eq7q = self:getCounter('killhero'),
			eq8q = self:getCounter('killed')
		}
	}
	if syncMsg then
		self:updateSyncMsg(msg)
	end

	return msg
end



--- 重新計算所有有效buff
-- @return null
function SHero:reCalBuff()
	SHero.super.reCalBuff(self)
	if self.debug  then
		if self.statusList ~=nil then
		for key,value in pairs(self.statusList) do
			--debuglog("Log2\tID:"..self.itemID.." Team:"..self.team.." Status:"..key.." totalTime:"..value['t'].." remainTime:"..(value['t']-self.world.gameTime-value['r']))
		end
		end
		if self.buffList ~=nil then
		for key,value in pairs(self.buffList) do
			if key ~=nil and value ~=nil then
			--debuglog("Log2\tID:"..self.itemID.." Team:"..self.team.." Buff:"..key.." Detail:"..(value.buffAttribute~=nil and cjson.encode(value.buffAttribute)  or "NULL" ).." Para:"..(value.buffParameter~=nil and  cjson.encode(value.buffParameter) or "NULL"))
			end
		end
		end
	end
end


--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SHero:goToDead(itemID,mode,adjTime,bonus)
	if mode==nil then mode = 0 end
	if adjTime==nil then adjTime = 0 end
	if bonus==nil then bonus = {} end

	self:D("goToDead。。。。。。。。SHero ",self.attribute.roleId)
	SHero.super.goToDead(self,itemID,mode,adjTime,bonus)
	local time=5
	
	if self.world.setting.ReviveTime~=nil and self.world.setting.ReviveTime>0 then
		time = self.world.setting.ReviveTime
	end

	if self.world.gameRoomSetting['ISGVB']==1 then
		time = 9999
	end

	self.attackTarget = nil
	if type(adjTime)=="string" then self:D('why is string "'..adjTime..'"') end
	self.deadTime = self.world:getGameTime() + time + adjTime
	if adjTime>1 then adjTime = 1 end
	self:addStatusList({s=9,r=self.world:getGameTime()+adjTime,t=time,i=self.itemID},adjTime)
	self:moveTo(self.posX,self.posY)

	self:setCounter("killed",1)
	self.comboKillHero = 0
	self.comboKilled = self.comboKilled + 1
	self:getAttributeAndSync()

	local lastAtkId = 0
	local lastAtkTime = 0
	self:D('jaylog heroAttack : ',self.world.cjson.encode(self.heroAttack))
	for k,v in pairs(self.heroAttack) do
		if v~=nil and v+10>=self.world:getGameTime() then
			if v>lastAtkTime then
				lastAtkId = k
				lastAtkTime = v
			end
		end
	end

	if lastAtkId~=0 then
		local msgtime = 0.2
		local bcfound = false
		local obj = self.world.allItemList[lastAtkId]
		if not self.world.gameFlag['firstKill'] then
			self.world.gameFlag['firstKill'] = true
			self:updateSyncMsg({bc={{mid=10,p1=obj.itemID,p2=self.itemID,d=msgtime+adjTime}}})
			bcfound = true
		end
		obj.comboKillHero = obj.comboKillHero + 1
		obj.comboKilled = 0
		if obj.lastKillHeroTime+12>=self.world:getGameTime() then
			obj.lastKillHero = obj.lastKillHero + 1
		else
			obj.lastKillHero = 1
		end
		obj.lastKillHeroTime = self.world:getGameTime()
		if obj.lastKillHero>1 then
			if obj.lastKillHero>5 then
				obj.lastKillHero = 5
			end
			self:updateSyncMsg({bc={{mid=88+obj.lastKillHero,p1=obj.itemID,p2=self.itemID,d=msgtime+obj.comboKillHero*0.3+adjTime}}})
			bcfound = true
		end
		
		if self.lastKilledByHero[obj.itemID]==nil then
			self.lastKilledByHero[obj.itemID] = 1
		end
		if not bcfound then
			if obj.lastKilledByHero[self.itemID]~=nil and obj.lastKilledByHero[self.itemID]==1 and (self.lastKilledByHero[obj.itemID]==nil or self.lastKilledByHero[obj.itemID]==1) then
				self:updateSyncMsg({bc={{mid=94,p1=obj.itemID,p2=self.itemID,d=msgtime+self.comboKillHero*0.3+adjTime}}})
				obj.lastKilledByHero[self.itemID] = 2
				self.lastKilledByHero[obj.itemID] = 2
				bcfound = true
			end
		end
		if not bcfound then
			self.world:addSyncMsg({bc={{mid=9,p1=obj.itemID,p2=self.itemID,d=adjTime}}})
		end
		obj:setCounter("killhero",1)
		obj:getAttributeAndSync()
	end
end


--- 准备攻击前置设置，在prepareHit之前执行
-- @param mode int - 技能1-7
-- @param itemID int - 目标对象id
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SHero:prepareSkillAttackCustom(mode,itemID,x,y,adjtime,syncMsg)
	local skill = {}
	if mode>100 then
		skill = self.attribute.skills[mode-100]
	else
		skill = self.attribute.skills[mode]
	end
	
	if skill~=nil and skill.demonObj~=nil then
		skill.demonObj:prepareSkillAttackCustom(mode,itemID,x,y,adjtime,syncMsg)
	else
		SHero.super.prepareSkillAttackCustom(self,mode,itemID,x,y,adjTime,syncMsg)
	end
end

--- API Call结果返回处理
-- @param jobID string - 队列ID
-- @param result string - API返回的结果
-- @return null
function SHero:APICallJobCallBack(jobID,result)
	if self.world.gameRoomSetting['ISYW']==1 then
		self:D('jaylog hero APICallJobCallBack in:'..jobID..' result:'..result)
		local dataAll = self.world.cjson.decode(result)
		local data = {}
		if dataAll~=nil and dataAll['data']~=nil then
			data = dataAll['data']
		end
		-- if data['task']~=nil and data['task']~={} and data['seqNo']~=nil and self.world.tonumber(data['seqNo'])>=self.seqNo['task'] then
		-- 	self.taskObj.taskList = data['task']
		-- 	self.taskObj:refreshList()
		-- 	--debuglog('jaylog hero APICallJobCallBack after:'..jobID..' result:'..result)
		-- 	--debuglog('jaylog hero APICallJobCallBack type=task '..result)
		-- 	self:activeTaskSyncMsg()
		-- 	self.seqNo['task'] = self.world.tonumber(data['seqNo'])
		-- end
		-- if data['taskGift']~=nil and data['taskGift']~={} then
		-- 	--debuglog('jaylog hero APICallJobCallBack type=taskGift '..result..' jobID:'..jobID)
		-- 	self:activeTaskRewardSyncMsg(data['taskGift'])
		-- 	self:activeTaskSyncMsg()
		-- end
		if data['updateProperty']~=nil then
			self:updateProperty()
			local result=self:getAllInfo(0,true)
			self:updateSyncMsg({i=result})
		end
		if data['updateSkill']~=nil then
			self:updateSkillProperty()
		end
		if data['updateDemon']~=nil then
			self:updateDemonProperty()
		end
		if data['updateEnergy']~=nil then
			self:updateEnergyProperty()
		end
		if data['updateTask']~=nil then
			self:updateTask()
		end
		if data['updateRebirth']~=nil then
			self:updateRebirth()
		end
		if self.world.sSub(result,1,1)=="1" then
			self:updateProperty()
			local result=self:getAllInfo(0,true)
			self:updateSyncMsg({i=result})
		end
		if self.world.sSub(result,2,2)=="1" then
			self:updateSkillProperty()
		end
		if self.world.sSub(result,3,3)=="1" then
			self:updateTask()
		end
		if self.world.sSub(result,4,4)=="1" then
			self:updateDemonProperty()
		end
		if self.world.sSub(result,5,5)=="1" then
			self:updateEnergyProperty()
		end
		if self.world.sSub(result,6,6)=="1" then
			self:updateRebirth()
		end
		local response
		if self.world.sSub(result,1,1)=='{' then
			response = result
		else
			response = self.world.sSub(result,7)
		end
		self:activeSyncMsg(response)
	end
end

--- 更新玩家自身attribute属性
function SHero:updateProperty()
	local playerInfo=self.world:memcacheGet('aoePlayerData'..self.world.tonumber(self.world.playerList[self.itemID]['p']))
	self:D('jaylog updateProperty INFO:'..self.world.cjson.encode(playerInfo))
	local playerJson = self.world.cjson.decode(playerInfo)
	self:D('jaylog updateProperty JSON:'..self.world.cjson.encode(playerJson))
	local attr = playerJson['Player']
	self.attribute:setBaseValue(attr)
end

--- 更新玩家attribute技能属性
function SHero:updateSkillProperty()
	local playerInfo=self.world:memcacheGet('aoePlayerData'..self.world.tonumber(self.world.playerList[self.itemID]['p']))
	local playerJson = self.world.cjson.decode(playerInfo)
	self:D('jaylog updateSkillProperty JSON:'..self.world.cjson.encode(playerJson))
	local attr = playerJson['skillParam']
	self.attribute:setSkillBaseValue(attr)
end

function SHero:updateDemonProperty()
	local playerInfo=self.world:memcacheGet('aoePlayerData'..self.world.tonumber(self.world.playerList[self.itemID]['p']))
	local playerJson = self.world.cjson.decode(playerInfo)
	self:D('jaylog updateDemon JSON:'..self.world.cjson.encode(playerJson))
	local attr = playerJson['skillDemon']
	self.attribute:setDemonBaseValue(attr)
end

function SHero:updateEnergyProperty()
	local playerInfo=self.world:memcacheGet('aoePlayerData'..self.world.tonumber(self.world.playerList[self.itemID]['p']))
	local playerJson = self.world.cjson.decode(playerInfo)
	self:D('jaylog updateEnergy JSON:'..self.world.cjson.encode(playerJson))
	local attr = playerJson['energyData']
	self.attribute.energyBoard:reload(attr)
end

function SHero:updateTask()
	local playerInfo=self.world:memcacheGet('aoePlayerTask'..self.world.tonumber(self.world.playerList[self.itemID]['p']))
	local taskJson = self.world.cjson.decode(playerInfo)
	self:D('jaylog updateTask JSON:'..self.world.cjson.encode(taskJson),self.seqNo['task'])
	if taskJson['seqNo']~=nil and self.world.tonumber(taskJson['seqNo'])>=self.seqNo['task'] then
		self.taskObj.taskList = taskJson['task']
		self.taskObj:refreshList()

		-- self.world:debuglog('jaylog SHero:updateTask taskList:',self.world.cjson.encode({dailyTask=self.taskObj.taskList}))
		-- local response = {dailyTask=self.taskObj.taskList}
		-- local msg = {}
		-- msg[#msg+1] = {
		-- 	zz=3,
		-- 	i=self.itemID,
		-- 	rtype=1,
		-- 	rp=self.world.cjson.encode(response),
		-- }
		-- self:debuglog('jaylog SHero:updateTask sync apimsg '..self.world.cjson.encode(msg)..' loginID:'..self.world.playerList[self.itemID]['id'])
		-- self.world:addSyncMsg({apimsg=msg})
		-- self.seqNo['task'] = self.world.tonumber(taskJson['seqNo'])
	end
end

--- 执行重生
-- @param null
-- @return null
function SHero:updateRebirth()
	self.deadTime = self.gameTime
	self.rebirthX = self.posX
	self.rebirthY = self.posY
end

--- 将task数据发送给前端
-- @param null
-- @return null
function SHero:activeSyncMsg(response)
	local msg = {}

	msg[#msg+1] = {
		zz=3,
		i=self.itemID,
		--rp=self.world.cjson.encode(response),
		rp=response,
	}
	self:D('jaylog SHero:activeSyncMsg sync apimsg '..self.world.cjson.encode(msg)..' loginID:'..self.world.playerList[self.itemID]['id'])
	--debuglog('jaylog SHero:activeTaskSyncMsg sync apimsg encode '..string.base64encode(self.world.cjson.encode(response)))
	self.world:addSyncMsg({apimsg=msg})
end

--- 注销对象
-- @param null
-- @return null
function SHero:release()
	self:D('jaylog SHero:release ',self.itemID,' lid:',self.loginID)
	self.world.playerList[self.itemID] = nil
	SHero.super.release(self)
end

--- 将task数据发送给前端
-- @param null
-- @return null
function SHero:activeTaskSyncMsg()
	--local response = {dailyTask={{ID=1,time=60,rtype=1,finish=0,item_10={num=5,progress=5},item_12={num=5,progress=0}},{ID=2,time=-1,rtype=2,finish=0,enemy_123={num=10,progress=5},enemy_125={num=10,progress=0}},{ID=3,time=-1,rtype=3,finish=0,boss_1={num=1,progress=1},boss_2={num=1,progress=0}}}}
	local response = {dailyTask=self.taskObj.taskList}
	local msg = {}
	msg[#msg+1] = {
		zz=3,
		i=self.itemID,
		rtype=1,
		--rp=string.base64encode(self.world.cjson.encode(response)),
		rp=self.world.cjson.encode(response),
		--rp='ABC'
	}
	self:D('jaylog SHero:activeTaskSyncMsg sync apimsg '..self.world.cjson.encode(msg)..' loginID:'..self.world.playerList[self.itemID]['id'])
	--debuglog('jaylog SHero:activeTaskSyncMsg sync apimsg encode '..string.base64encode(self.world.cjson.encode(response)))
	self.world:addSyncMsg({apimsg=msg})
end

--- 领取task奖励时组织数据发送前端
-- @param taskID int - 任务ID
-- @return null
function SHero:activeTaskRewardSyncMsg(taskID)
	--local response = {dailyTask={{ID=2,time=-1,rtype=2,finish=0,enemy_123={num=10,progress=5},enemy_125={num=10,progress=0}},{ID=3,time=-1,rtype=3,finish=0,boss_1={num=1,progress=1},boss_2={num=1,progress=0}}}}
	local response = {taskGift=taskID}
	local msg = {}
	msg[#msg+1] = {
		zz=3,
		i=self.itemID,
		rtype=1,
		rp=self.world.cjson.encode(response),
	}
	self:D('jaylog SHero:activeTaskRewardSyncMsg sync apimsg '..self.world.cjson.encode(msg))
	self.world:addSyncMsg({apimsg=msg})
end

--- 设置task的自动寻路路线
-- @param taskID string - 任务ID
-- @return null
function SHero:getTaskPath(taskID)
	self:D('jaylog getTaskPath taskList:'..self.world.cjson.encode(self.taskObj.taskList))
	local taskData = nil
	for k,v in pairs(self.taskObj.taskList) do
		--self:debuglog('jaylog getTaskPath1 ',k,self.world.cjson.encode(v))
		for k1,v1 in pairs(v) do
			--self:debuglog('jaylog getTaskPath2 ',k1,self.world.cjson.encode(v1),taskID)
			if self.world.tonumber(k1)==self.world.tonumber(taskID) then
				taskData = v1
				--self:debuglog('jaylog getTaskPath taskData search:'..self.world.cjson.encode(taskData))
			end
		end
	end
	if taskData~=nil then
		self:D('jaylog getTaskPath taskData:'..self.world.cjson.encode(taskData))
		local taskCond = taskData['tasks']
		local ok = false
		local toX,toY = self.posX,self.posY
		for k,v in pairs(taskCond) do
			if not ok and v['finish']==0 then
				toX = v['X']
				toY = v['Y']
				ok = true
			end
		end
		self.world.transfer:getMapPathDetail(self.world.playerList[self.itemID]['m'],taskData['mapID'],self.posX,self.posY,toX,toY,self.itemID)
	end
end

--- call api接口
-- @param data string - 传给API的data数据
-- @param ctrl string - call API接口的controller
-- @param act string  - call API接口的action
-- @return null
function SHero:addApiCall(data,ctrl,act)
	if act=='getTaskGift' then
		self:setAutoMove()
	end
	data['seqNo']=self.world.gameTime
	local requestData = {
		ctrl=ctrl,
		act=act,
		session=self.world.playerList[self.itemID]['s'],
		pid=self.world.playerList[self.itemID]['p'],
		data=data
	}
	self:D('jaylog SHero:addApiCall addAPICallJob: requestData->'..self.world.cjson.encode(requestData)..' itemID:'..self.itemID)
	self:addAPICallJob('callapicompress',self.world.cjson.encode(requestData))

end

--- 更新玩家信息
-- @param info int - 更新的类型，1=all,2=info,3=task,4=counter
function SHero:updateInfo(info,task,counter)
	local data = {}
	data = {mapModel=self.world.mapModel,mapPort=self.world.gamePort,HP=self.attribute.HP,MP=self.attribute.MP,X=self.posX,Y=self.posY}
	data['info'] = {mapModel=self.world.mapModel,mapPort=self.world.gamePort,HP=self.attribute.HP,MP=self.attribute.MP,X=self.posX,Y=self.posY}
	local ctrl = 'player'
	local act = 'updateInfo'
	self:addApiCall(data,ctrl,act)
end

--- call api获取全部task信息
-- @param null
-- @return null
function SHero:addApiJobGetTask()
	local data = {}
	self:addApiCall(data,'task','getTaskAll')
end

--- call api更新task信息到API
-- @param null
-- @return null
function SHero:addApiJobUpdateTask()
	local data = {task=self.taskObj.taskList}
	self:addApiCall(data,'task','updateTaskEvent')
end

--- call api获取任务奖励
-- @param taskID int - 任务ID
-- @return null
function SHero:addApiJobGetGift(taskID)
	local data = {taskID=taskID}
	self:addApiCall(data,'task','getTaskGift')
end

-- call api获取全部counter信息
function SHero:addApiJobGetCounter()
	local data = {}
	self:addApiCall(data,'default','getCounter')
end

-- update counter
function SHero:addApiJobUpdateCounter()
	local data = {counter=self.counterObj:getCacheCounter()}
	self:addApiCall(data,'player','addCounter')
end

function SHero:addApiJobGetProperty()
	local requestData = {
		ctrl='player',
		act='lampLevelUp',
		session=self.world.playerList[self.itemID]['s'],
		pid=self.world.playerList[self.itemID]['p'],
		data={seqNo=self.world.gameTime,lampType=1,mapModel=self.world.mapModel}
	}
	self:D('jaylog SHero:getApiTaskAll addApiJobGetProperty: requestData->'..self.world.cjson.encode(requestData)..' itemID:'..self.itemID)
	self:addAPICallJob('callapi',self.world.cjson.encode(requestData))
end

function SHero:addApiJobGetSkill()
	local requestData = {
		ctrl='skill',
		act='upLevel',
		session=self.world.playerList[self.itemID]['s'],
		pid=self.world.playerList[self.itemID]['p'],
		data={seqNo=self.world.gameTime,skillRank=2,rank=2}
	}
	self:D('jaylog SHero:getApiTaskAll addApiJobGetSkill: requestData->'..self.world.cjson.encode(requestData)..' itemID:'..self.itemID)
	self:addAPICallJob('callapi',self.world.cjson.encode(requestData))
end

--- 设置自动跟随
-- @param itemID int - 目标ID，itemID>0开启跟随，不填或0取消跟随
-- @return null
function SHero:setAutoFollow(itemID)
	if itemID==nil then
		itemID = 0
	end
	if itemID>0 then
		self.autoFollow = true
		local targetObj = self.world.allItemList[itemID]
		if targetObj.sharedID>0 then
			self.autoFollowTargetID = targetObj.sharedID
		else
			self.autoFollowTargetID = itemID
		end
		self:addStatusList({s=994,r=self.world.gameTime,t=9999})
	else
		self.autoFollow = false
		self.autoFollowTargetID = 0
		self:removeStatusList(994)
	end
end

--- 设置自动导航
-- @param itemID int - 目标ID，itemID>0开启跟随，不填或0取消跟随
-- @return null
function SHero:setAutoMove(taskID)
	if taskID==nil then
		taskID = 0
	end
	if taskID>0 then
		self:getTaskPath(taskID)
		self.autoMove = true
		self:addStatusList({s=996,r=self.world.gameTime,t=9999})
	else
		self.autoMove = false
		self:removeStatusList(996)
	end
end


--- 设置暫停AI
-- @return null
function SHero:suspendAI()
	if self.AImode>0 then
		self.autoBlocked = true
	end
end


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SHero:prepareHit(mode,adjTime,buff)
	local hitValueBoth=SHero.super.prepareHit(self,mode,adjTime,buff)
	self:callCreature(hitValueBoth)
	if self.attribute.skills[mode]~=nil and self.attribute.skills[mode].demonObj~=nil then
		self.attribute.skills[mode].demonObj:prepareHit(mode,adjTime,buff,hitValueBoth)
	end
	if self.attribute.skills[mode-100]~=nil and self.attribute.skills[mode-100].demonObj~=nil then
		self.attribute.skills[mode-100].demonObj:prepareHit(mode,adjTime,buff,hitValueBoth)
	end

	return hitValueBoth 
end 


--英雄的自动攻击..........
function SHero:_autoFight()
	if  self.statusList[4007]==nil and not self.autoBlocked and self.AIlastMoveTime<self.world:getGameTime() and self.AIlastATKTime<self.world:getGameTime() and self.lastCoolDownTime<self.world:getGameTime() and  not self:isDead() then
		self:_autoFightToHero()
	end

end

--自动攻击用来重载
function SHero:_autoFightToHero()
	--需要获得自动攻击的item  释放skill的id
	local targetID,skillID,cdTime=self.autoFightAI:autoFighTotHero()
	if targetID>0 then
		--debuglog("SHero:_autoFight 进去之前 lastCoolDownTime:"..self.lastCoolDownTime.." gameTime:"..self.world.gameTime.." ret:"..self.world.cjson.encode(ret).."第几下:"..self.mode1order)
		ret = self:skillAttack(skillID,targetID)
		self.AIlastATKTime = self.world:getGameTime()+cdTime
		--防止放完技能立刻回头不好的体验
		self.AIlastMoveTime = self.world:getGameTime() + 0.2
		--debuglog("SHero:_autoFight lastCoolDownTime:"..self.lastCoolDownTime.." gameTime:"..self.world.gameTime.." ret:"..self.world.cjson.encode(ret).."第几下:"..self.mode1order)
	end
	return skillID
end


--- 自动移动chud
-- @return null
function SHero:_autoMove()
	-- debuglog("SHero:_autoMove")
	local moveRet=self.autoFightAI:autoMoveToAlerted()
	if not self.autoBlocked and self.AIlastMoveTime < self.world:getGameTime() and  not self:isDead() and not moveRet and self.statusList[4007]==nil then
		
		local hprate = self.attribute.HP/self.attribute.MaxHP
		
		--用来判断切状态
		-- local maxHprate = 1
		-- local minHprate = 0.2
		debuglog("AIRoleSetting:"..self.world.cjson.encode(self.attribute.AIRoleSetting))
		local maxHprate = self.attribute.AIRoleSetting['switchAtkModeA']*0.01
		local minHprate = self.attribute.AIRoleSetting['switchAtkModeB']*0.01

		if  self.world.tonumber(self.world.mapModel)~=2 then
			minHprate = 0
		end

		if hprate>minHprate and hprate<maxHprate then
			self.autoFightAI:autoMoveToHero()
		else
			self.autoFightAI:autoMoveToATKHero()	
		end
		

		self.AIlastMoveTime = self.moveToEndTime
	end
end

--设玩家自动AI
function SHero:setAuto(auto)
	if auto==nil then auto = false end

	debuglog("setAuto auto:"..(auto and "true" or "false").." itemID:"..self.itemID)
	if auto then
		self.AImode=1
		self.autoBlocked = false
	else
		self.AImode=0
		self.autoBlocked = true
	end

end

function SHero:goToGameRoom(queue)
	debuglog('jaylog SHero:goToGameRoom key:'..'tcphold'..string.base64encode(self.loginID))
	local dataTmp = self.world:memcacheLocalGet('tcphold'..string.base64encode(self.loginID))
	local data = self.world.cjson.decode(dataTmp)
	debuglog('jaylog SHero:goToGameRoom data:'..self.world.cjson.encode(data)..' i:'..self.itemID..' plist:'..self.world.cjson.encode(self.world.playerList[self.itemID]))
	local port=1330+((self.world.tonumber(data['p'])%5)*2);
	local result = {i={i=self.itemID,host=data['sip'],roomid=self.world.tonumber(data['p']),port=port,pid=self.world.playerList[self.itemID]['p'],mapid=data['m']}}
	debuglog('jaylog SHero:goToGameRoom '..self.world.cjson.encode(result))
	self:updateSyncMsg(result)
	-- self.world.playerList[self.itemID]['online'] = false
	-- self.world.playerList[self.itemID]['offLineTime'] = self.world.gameTime
end

function SHero:prepareSkillAttackMode7(updateMove)
	if self.world.gameRoomSetting.ISGVB~=1 then
		SHero.super.prepareSkillAttackMode7(self,updateMove)
	else
		--屏蔽GVB骑马
		return nil
	end
end


return SHero
