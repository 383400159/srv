local SHeroInWorld2004 = class("SHeroInWorld2004", require("gameroomcore.SHeroBase"))

function SHeroInWorld2004:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld2004.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.blackBallNum = 0
	self.whiteBallNum = 0
end



function SHeroInWorld2004:getBossObj()
	local obj = self.world:getObjBySubName("BOSS1",self.world.itemListFilter.heroList)
	return obj
end

function SHeroInWorld2004:addStatusList(statusArray, adjTime)

	--debuglog("addStatusList iD:"..statusArray['s'])
	--黑球
	local blackAdd = 0
	local whiteAdd = 0
	if statusArray~=nil and statusArray['s']==4056 and self.blackBallNum<3 and self.whiteBallNum<3 then
		self.blackBallNum = self.blackBallNum + 1
		debuglog("黑白球 黑球+1 :"..self.blackBallNum)
		blackAdd = 1

	end
	--白球
	if statusArray~=nil and statusArray['s']==4057 and self.blackBallNum<3 and self.whiteBallNum<3 then
		self.whiteBallNum = self.whiteBallNum + 1
		debuglog("黑白球 白球+1 :"..self.whiteBallNum)
		whiteAdd = 1
	end

	--需要特殊处理 黑护盾
	if self.blackBallNum==3 and blackAdd>0 then
		debuglog("黑白球 添加黑护盾 :"..self.blackBallNum)	
		local obj = self:getBossObj()
		local hitValue = obj:prepareHit(16,0,false)
		--ABSORDCURE_UPFIX=0;ABSORDCURE_UPFIX_RATE=100;BUFFTIME=9999  
		-- hitValue['ABSORDCURE_UPFIX_RATE'] = 100
		-- hitValue['ABSORDCURE_UPFIX'] = hitValue['ATK']*hitValue['APADJ2']*0.01 + 1
		hitValue['MAXABSORDCURE_UPFIX_RATE'] = 100
		hitValue['MAXABSORDCURE_UPFIX'] = hitValue['ATK']*hitValue['APADJ2']*0.01 + 1
		--debuglog("ABSORDCURE 添加黑护盾值:"..hitValue['MAXABSORDCURE_UPFIX'].." ATK:"..hitValue['ATK'].." APADJ2:"..hitValue['APADJ2'])
		self.attribute.ABSORDCURE = self.attribute.ABSORDCURE + hitValue['ATK']*hitValue['APADJ2']*0.01 + 1
		hitValue['BUFFTIME'] = 90000
		--debuglog("ABSORDCURE 添加黑护盾值0:"..self.attribute.ABSORDCURE)
		self:directHurt(self.itemID,16,hitValue,0) 
	    debuglog("ABSORDCURE 添加黑护盾值:"..hitValue['MAXABSORDCURE_UPFIX'])
	    -- debuglog("ABSORDCURE 添加黑护盾值1:"..self.attribute.ABSORDCURE)
	end

	--需要特殊处理 白护盾
	if self.whiteBallNum==3 and whiteAdd>0 then
		debuglog("黑白球 添加白护盾 :"..self.whiteBallNum)	
		local obj = self:getBossObj()
		local hitValue = obj:prepareHit(17,0,false) 
		hitValue['MAXHURTDESTROY_UPFIX_RATE'] = 100
		hitValue['MAXHURTDESTROY_UPFIX'] = hitValue['ATK']*hitValue['APADJ2']*0.001 + 1
		self.attribute.HURTDESTROY = self.attribute.HURTDESTROY + hitValue['ATK']*hitValue['APADJ2']*0.001 + 1
		hitValue['BUFFTIME'] = 90000
		--APADJ=20;BEALLHURT_UP=100;BEALLHURT_UP_RATE=100;ALLHURT_UP=50;ALLHURT_UP_RATE=100;THREAT_UP=100;THREAT_UP_RATE=100;HURTDESTROY_UPFIX=0;HURTDESTROY_UPFIX_RATE=100;BUFFTIME=9999
		self:directHurt(self.itemID,17,hitValue,0) 
		debuglog("HURTDESTROY 添加白护盾值:"..hitValue['MAXHURTDESTROY_UPFIX'])
	end

	--需要特殊处理 中和反应
	if self.whiteBallNum>0 and self.blackBallNum>0  then
		debuglog("黑白球 中和反应 ")	
		self.whiteBallNum=self.whiteBallNum-1
		self.blackBallNum=self.blackBallNum-1
		local obj = self:getBossObj()
		local hitValue = obj:prepareHit(18,0,false)  
		--self:directHurt(self.itemID,18,hitValue,0) 
		self:addStatusList({s=hitValue['ADDSTATUS2'],r=self.world.gameTime,t=hitValue['ADDSTATUSTIME2']})
		self:directFightAuratoDalay(1,self.itemID,hitValue,{posX=self.posX,posY=self.posY,RANGE=1000},0) 

		self:removeBUff("BEALLHURT")
		self:removeBUff("ALLHURT")
		self:removeBUff("BECURE")
		self:removeBUff("THREATFIXVALUE")
		--APADJ=50;ADDSTATUS2=4040;ADDSTATUSTIME2=5
	end

	--黑球buff
	if self.blackBallNum<3 and self.blackBallNum>0 and blackAdd>0 then
		debuglog("黑白球 添加黑buff :"..self.blackBallNum)	
		local obj = self:getBossObj()
		local hitValue = obj:prepareHit(14,0,false) 
		--APADJ=20;BECURE_DOWN=15;BECURE_DOWN_RATE=100;BUFFTIME=9999 
		hitValue['APADJ'] = hitValue['APADJ']*self.blackBallNum
		hitValue['BECURE_DOWN'] = hitValue['BECURE_DOWN']*self.blackBallNum

		self:directHurt(self.itemID,14,hitValue,0) 
	end
	--白球buff
	if self.whiteBallNum<3 and self.whiteBallNum>0 and whiteAdd>0 then
		debuglog("黑白球 添加白buff :"..self.whiteBallNum)	
		local obj = self:getBossObj()
		local hitValue = obj:prepareHit(15,0,false) 
		--APADJ=20;BEALLHURT_UP=15;BEALLHURT_UP_RATE=100;ALLHURT_UP=10;ALLHURT_UP_RATE=100;BUFFTIME=9999 
		hitValue['APADJ'] = hitValue['APADJ']*self.whiteBallNum
		hitValue['BEALLHURT_UP'] = hitValue['BEALLHURT_UP']*self.whiteBallNum
		hitValue['ALLHURT_UP'] = hitValue['ALLHURT_UP']*self.whiteBallNum
		self:directHurt(self.itemID,15,hitValue,0) 
	end

	--白电球的时候碰球放闪电链
	if self.whiteBallNum==3 and statusArray~=nil and (statusArray['s']==4056 or statusArray['s']==4057) then
		debuglog("黑白球 闪电链 ")	
		local obj = self:getBossObj()
		obj.startID = self.itemID
		obj:prepareHit(19,0,false)  
		local skill = obj.attribute.skills[19] 
		local parameters = skill.parameters 
		local itemIDList = {}
		for k,v in pairs(obj.dlist) do
			itemIDList[#itemIDList+1]=v.itemID
		end
		local syncMsg = {a={{x=self.posX,y=self.posY,sx=obj.posX,sy=obj.posY,ht=1.07,ti=self.itemID,m=3,i=obj.itemID,p=''}}}
		syncMsg['a'][#syncMsg['a']]['p'] = implode(',',itemIDList)..";"..parameters.LIGHTNINGNEXTDELAY
		obj:updateSyncMsg(syncMsg)
		debuglog("闪电链列表  黑白球:"..syncMsg['a'][#syncMsg['a']]['p'].." syncMsg:"..self.world.cjson.encode(syncMsg))
		--syncMsg:{"a":{"t":0,"x":99.9,"y":67.45,"sx":97.779998779297,"ht":1.07,"ti":1217,"sy":69.870002746582,"m":3,"i":1,"p":"1217,1028,1027,1023,1018,1018,1218,1218,1215,1213;0.25"}}

	end


	if self.blackBallNum==3 and statusArray~=nil and (statusArray['s']==4056 or statusArray['s']==4057) then
		local obj = self:getBossObj()
		local skill = obj.attribute.skills[16] 
		local parameters = skill.parameters 

		if statusArray['s']==4056 then
			debuglog("黑白球 blackBallNum3添加黑buff :"..self.blackBallNum)	
			local obj = self:getBossObj()
			local hitValue1 = obj:prepareHit(14,0,false) 
			--APADJ=20;BECURE_DOWN=15;BECURE_DOWN_RATE=100;BUFFTIME=9999 
			hitValue={}
			hitValue['ATK'] = hitValue1['ATK']
			hitValue['   '] = hitValue1['APADJ']*parameters.HURTMULTIPLE*0.01
			self:directHurt(self.itemID,14,hitValue,0) 
		end
		if statusArray['s']==4057 then
			debuglog("黑白球 blackBallNum3添加白buff :"..self.whiteBallNum)	
			local obj = self:getBossObj()
			local hitValue1 = obj:prepareHit(15,0,false)
			--APADJ=20;BEALLHURT_UP=15;BEALLHURT_UP_RATE=100;ALLHURT_UP=10;ALLHURT_UP_RATE=100;BUFFTIME=9999 
			hitValue={}
			hitValue['ATK'] = hitValue1['ATK']
			hitValue['APADJ'] = hitValue1['APADJ']*parameters.HURTMULTIPLE*0.01
			self:directHurt(self.itemID,15,hitValue,0) 
		end
	end

	if (statusArray['s']==4056 or statusArray['s']==4057) then
		
		if self.whiteBallNum==0 and self.blackBallNum==0 then
			self:removeStatusList(4058)
			debuglog("黑白球 取消状态 球没了 ")	
		elseif (self.blackBallNum==3 or self.whiteBallNum==3) then
			self:removeStatusList(4058)
			debuglog("黑白球 取消状态 球3个"..self.whiteBallNum.." blackBallNum:"..self.blackBallNum)	
		else
			debuglog("黑白球 add状态4058 whiteBallNum:"..self.whiteBallNum.." blackBallNum:"..self.blackBallNum)	
			self:addStatusList({s=4058,r=self.world.gameTime,t=9999,p1=self.whiteBallNum,p2=self.blackBallNum},0)
		end
	end

 	local ret = SHeroInWorld2004.super.addStatusList(self,statusArray, adjTime)  
	return ret
end

function SHeroInWorld2004:removeStatusList(statusNum,adjTime)

	--黑球
	if statusNum~=nil and statusNum==4051 then
		self.blackBallNum = self.blackBallNum - 1
	end
	--白球
	if statusNum~=nil and statusNum==4052 then
		self.whiteBallNum = self.whiteBallNum - 1
	end

 	local ret = SHeroInWorld2004.super.removeStatusList(self,statusNum,adjTime)  
	
	return ret
end



function SHeroInWorld2004:removeBUff(name)
	if name=="MAXABSORDCURE" or name=="MAXHURTDESTROY" then
		debuglog("黑白球 removeBUff:"..name)
		self.blackBallNum=0
		self.whiteBallNum=0		
		self:removeBUff("BEALLHURT")
		self:removeBUff("ALLHURT")
		self:removeBUff("THREATFIXVALUE")
	end
	SHeroInWorld2004.super.removeBUff(self,name)
end


function SHeroInWorld2004:prepareSkillAttackMode7(updateMove)
	return nil
end

return SHeroInWorld2004
