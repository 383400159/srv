local SHero5 = class("SHero5", require("gameroom.hero.SHero")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @param actorID int - 游戏房玩家序号ID
-- @return null
function SHero5:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	if (self.className==nil) then 
		self.className = "SHero5" 
	end 
	self.mode5time = 0
	self.mode5in1time = 0

	self.mode1bool = false
	--debuglog('jaylog SHero5:ctor before super')
	SHero5.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	--debuglog('jaylog SHero5:ctor after super')
end 



--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SHero5:prepareHit(mode,adjTime,buff)  

	-- if (mode==3) then 
	-- 	local skill = self.attribute.skills[3] 
	-- 	local parameters = skill.parameters 
	-- 	local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),{BUFFONLY=1,buffParameter={buffTargetPosX=self.lastBulletPositionX,buffTargetPosY=self.lastBulletPositionY,buffIntervalTime=parameters.INTERVALTIME}},skill.duration,{mode},0,self.itemID,self.itemID,adjTime+skill.hitTime) 
	-- 	self:addBuff(buffObj) 
	-- end 
	-- if (mode==13) then 
	-- 	mode=3
	-- end
	-- if (mode==5) then
	-- 	local skill = self.attribute.skills[5] 
	-- 	local parameters = skill.parameters 
	-- 	self.mode5time = self.world:getGameTime() + parameters.BUFFTIME
	-- 	self.mode5in1time = self.world:getGameTime() + parameters.BUFFTIME
	-- end

	local hitValueBoth=SHero5.super.prepareHit(self,mode,adjTime,buff) 

	-- if self.mode5time>self.world:getGameTime() and itemID~=self.itemID then
	-- 	local skill = self.attribute.skills[5] 
	-- 	local parameters = skill.parameters 
	
	-- 	if mode==2 then
	-- 		--MSPD_DOWNFIX_RATE2=0,3,5,8,11,14,17,20,23,26,29,32,36,39,42,46,51,56,62,71,80;MSPD_DOWNFIX2=300;BUFFTIME2=5
	-- 		hitValueBoth['MSPD_DOWNFIX_RATE'] = parameters.MSPD_DOWNFIX_RATE2 + (hitValueBoth['MSPD_DOWNFIX_RATE']~=nil and hitValueBoth['MSPD_DOWNFIX_RATE'] or 0)
	-- 		hitValueBoth['MSPD_DOWNFIX'] = parameters.MSPD_DOWNFIX2 +(hitValueBoth['MSPD_DOWNFIX']~=nil and hitValueBoth['MSPD_DOWNFIX'] or 0)
	-- 		if parameters.BUFFTIME2>hitValueBoth['BUFFTIME'] then
	-- 			hitValueBoth['BUFFTIME'] = parameters.BUFFTIME2
	-- 		end
	-- 	end
	-- 	if mode==3 then
	-- 		--POISON_HURTFIX_RATE2=0,100;POISON_HURTFIX2=0,18,37,56,75,95,114,135,156,177,198,220,242,264,287,311,346,383,421,479,540;BUFFTIME3=3
	-- 		hitValueBoth['POISON_HURTFIX_RATE'] = parameters.POISON_HURTFIX_RATE2 + (hitValueBoth['POISON_HURTFIX_RATE']~=nil and hitValueBoth['POISON_HURTFIX_RATE'] or 0)
	-- 		hitValueBoth['POISON_HURTFIX'] = parameters.POISON_HURTFIX2 + (hitValueBoth['POISON_HURTFIX']~=nil and hitValueBoth['POISON_HURTFIX'] or 0)
	-- 		if parameters.BUFFTIME3>hitValueBoth['BUFFTIME'] then
	-- 			hitValueBoth['BUFFTIME'] = parameters.BUFFTIME3
	-- 		end
	-- 	end
		if mode==4 then
	-- 		--DIZZY_RATE2=0,3,6,9,12,16,19,22,26,29,33,37,40,44,48,52,58,64,70,80,90;BUFFTIME4=3
	-- 		if parameters.DIZZY_RATE2>hitValueBoth['DIZZY_RATE'] then
	-- 			hitValueBoth['DIZZY_RATE'] = parameters.DIZZY_RATE2
	-- 		end
	-- 		if parameters.BUFFTIME4>hitValueBoth['BUFFTIME'] then
	-- 			hitValueBoth['BUFFTIME'] = parameters.BUFFTIME4
	-- 		end
			hitValueBoth['bulletAttackMode4ExtendDistance'] = 100
		end

	-- 	if mode==2 or mode==3 or mode==4 then
	-- 		self.mode5time=self.world:getGameTime()
	-- 	end
	-- end
	

	-- if self.mode5in1time>self.world:getGameTime() and itemID~=self.itemID then
	-- 	if mode==1 then
	-- 		--BLEED_HURTFIX_RATE2=0,3,5,8,11,14,17,20,23,26,29,32,36,39,42,46,51,56,62,70,80
	-- 		local skill = self.attribute.skills[5] 
	-- 		local parameters = skill.parameters 
	-- 		hitValueBoth['DEF_DOWN_RATE'] = parameters.DEF_DOWN_RATE2
	-- 	end
	-- end

	if mode==3 then
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 
		local attributes = {}
		attributes['ATK_UPFIX_RATE'] = parameters.ATK_UPFIX_RATE2
		attributes['ATK_UPFIX'] = parameters.ATK_UPFIX2
		attributes['BUFFTIME'] = parameters.BUFFTIME2
		-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,parameters.BUFFTIME2,{},0,self.itemID,self.itemID,0)
		local buff = self.world:createBuff(self:__skillID2buffID(skill.skillID,0),attributes,parameters.BUFFTIME2,{},0,self.itemID,self.itemID,0)
		self:addBuff(buff)
	end


	if mode==1 then
		self.mode1bool = true
	end
	return hitValueBoth 
end 

--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero5:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	
	local ret = 0
	-- local times = 1
	-- if mode==3 then
	-- 	times = 2
	-- 	hitValue['SEPARATE'] = 50
	-- end
	-- for i=1,times do
	-- 	ret = ret + SHero5.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	-- 	adjTime = adjTime + 0.1
	-- end

	if mode==4 then
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 

		local attackRange = {posX=obj.posX,posY=obj.posY,radius=parameters.EXPLODERANGE/self.world.setting.AdjustAttRange} 

		local hitValueNew = self:getPrepareHithitValue()
		--debuglog("parameters:..."..self.world.cjson.encode(parameters))
		hitValueNew['skillID'] = 4
		hitValueNew['APADJ'] = parameters.APADJ2 + (hitValueNew['APADJ']~=nil and hitValueNew['APADJ'] or 0)
		
		local bullet = require("gameroomcore.SBullet").new(self.world,4,self.itemID,0.2,0,obj.posX,obj.posY)
		bullet.attr.ignoreID = {itemID}
		bullet:directFightAura(1,attackRange,hitValueNew,bullet.attr.angle,0) 
		bullet:setDead() 
		hitValue['attackP'] = "1"
		if hitValue['APADJ']==0 then
			hitValue['APADJ'] = parameters.APADJ2
		end
		-- local attributes = {}
		-- attributes['MSPD_UPFIX_RATE'] = parameters.MSPD_UPFIX_RATE2
		-- attributes['MSPD_UPFIX'] = parameters.MSPD_UPFIX2
		-- attributes['BUFFTIME'] = parameters.BUFFTIME2
		-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,parameters.BUFFTIME2,{},0,self.itemID,self.itemID,0)
		-- self:addBuff(buff)

	end

	if mode==1 and self.mode1bool then
		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters 
		local attributes = {}
		attributes['CRI_UPFIX_RATE'] = parameters['CRI_UPFIX_RATE2']
		attributes['CRI_UPFIX'] = parameters['CRI_UPFIX2'] 
		-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,parameters['BUFFTIME2'],{},0,self.itemID,self.itemID,0.1)
		local buff = self.world:createBuff(self:__skillID2buffID(skill.skillID),attributes,parameters['BUFFTIME2'],{},0,self.itemID,self.itemID,0.1)
		self:addBuff(buff)
		self.mode1bool = false
	end


	ret = ret + SHero5.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	return ret 
end 




return SHero5 
