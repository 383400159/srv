local SHeroInWorld101 = class("SHeroInWorld101", require("gameroomcore.SHeroBase"))

function SHeroInWorld101:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld101.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SHeroInWorld101