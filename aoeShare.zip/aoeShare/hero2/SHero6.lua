local SHero6 = class("SHero6", require("gameroom.hero.SHero1")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @param actorID int - 游戏房玩家序号ID
-- @return null
function SHero6:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SHero6" 
	end 
	debuglog('jaylog SHero6:ctor before super')
	SHero6.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	debuglog('jaylog SHero6:ctor after super')
end 


return SHero6 