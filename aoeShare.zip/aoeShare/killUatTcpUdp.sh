#!/bin/bash

ps aux |grep "server-uataoe" |grep -v 'grep' |awk '{print $2" "$12" "$14}'
ps aux |grep "server-uataoe" |grep -v 'grep' |awk '{print "kill -9 "$2}' | sh

/var/aoe_fb/MasterGame.sh
