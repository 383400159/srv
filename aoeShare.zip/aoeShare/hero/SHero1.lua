local SHero1 = class("SHero1", require("gameroom.hero.SHero6")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @param actorID int - 游戏房玩家序号ID
-- @return null
function SHero1:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SHero1" 
	end 
	SHero1.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end 



return SHero1 
