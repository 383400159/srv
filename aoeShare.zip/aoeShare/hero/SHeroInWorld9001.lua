local SHeroInWorld9001 = class("SHeroInWorld9001", require("gameroomcore.SHeroBase"))

function SHeroInWorld9001:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld9001.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

--- 調整HP
-- @param hp float - HP
-- @param forceSync bool - 強制同步
-- @param must bool - 必定傷HP
-- @return success bool - true = ok
function SHeroInWorld9001:adjHP(hp,forceSync,must,zz)
	if self.actorType==0 then
		-- self:D('jaylog SHeroInWorld9001:adjHP ',self.attribute.HP,hp,self.attribute:getMaxHP(),(self.attribute:getMaxHP()*0.3))
		if hp<0 and (self.attribute.HP+hp)<(self.attribute:getMaxHP()*0.2) then
			-- hp = self.attribute:getMaxHP() - self.attribute.HP
			hp = 0
		end
		-- self:D('jaylog SHeroInWorld9001:adjHP ',self.attribute.HP,hp,self.attribute:getMaxHP(),(self.attribute:getMaxHP()*0.3))
	end
	local ret = SHeroInWorld9001.super.adjHP(self,hp,forceSync,must,zz)
	-- self:D('jaylog SHeroInWorld9001:adjHP ret ',ret)
	return ret
end

return SHeroInWorld9001