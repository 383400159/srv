local SHeroInWorld3005 = class("SHeroInWorld3005", require("gameroomcore.SHeroBase"))

function SHeroInWorld3005:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld3005.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.sharedList = {}
end



--- 受傷害計算,调用SActor的hurted
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHeroInWorld3005:hurted(itemID,bulletID,mode,hitValue,adjTime)

	local hurt = SHeroInWorld3005.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
	if self.statusList[4071]~=nil and hurt>0 then
		local team = self.world:runTargetTypeFilter(5,self.team,self.itemID,{},
		function(v)
		 	if  v.itemID~=self.itemID and v.statusList[4071]~=nil then
				debuglog("生命链共享 分享 itemID:"..v.itemID.." hurt:"..hurt)
				v:adjHP(-hurt)
				if hurt~=0 then
					v:updateSyncMsg({h={{i=v.itemID,t=0,d=adjTime,h=self.world.mFloor(hurt),hp=self.world.mFloor(v.attribute.HP),hpe=0,ti=itemID,m=1,s=0}}})
				end
			end
		end
		)

		--所有人受伤
		debuglog("生命链共享 itemID:"..self.itemID.." hurt:"..hurt)
		-- local team = self:getTeammatelist()
		-- for k,v in pairs(team) do
		-- 	if  v.itemID~=self.itemID and v.statusList[4071]~=nil then
		-- 		debuglog("生命链共享 分享 itemID:"..v.itemID.." hurt:"..hurt)
		-- 		v:adjHP(-hurt)
		-- 		if hurt~=0 then
		-- 			v:updateSyncMsg({h={{i=v.itemID,t=0,d=adjTime,h=self.world.mFloor(hurt),hp=self.world.mFloor(v.attribute.HP),hpe=0,ti=itemID,m=1,s=0}}})
		-- 		end
		-- 	end
		-- end
	end
	return hurt
end


function SHeroInWorld3005:prepareSkillAttackMode7(updateMove)
	return nil
end

return SHeroInWorld3005
