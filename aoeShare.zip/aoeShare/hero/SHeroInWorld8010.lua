local SHeroInWorld8010 = class("SHeroInWorld8010", require("gameroomcore.SHeroBase"))

function SHeroInWorld8010:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld8010.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	-- self.changePartHP = 1000
end

--- 調整HP
-- @param hp float - HP
-- @param forceSync bool - 強制同步
-- @param must bool - 必定傷HP
-- @return success bool - true = ok
-- function SHeroInWorld8010:adjHP(hp,forceSync,must,zz)
-- 	if self.actorType==0 or self.attribute.actorType==0 then
-- 		-- self:D('jaylog SHeroInWorld8010:adjHP ',self.attribute.HP,hp,self.attribute:getMaxHP(),(self.attribute:getMaxHP()*0.3))
-- 		if hp<0 and ((self.attribute.HP+hp)<(self.attribute:getMaxHP()*0.2) or ((self.attribute.HP+hp)<100)) then
-- 			-- hp = self.attribute:getMaxHP() - self.attribute.HP
-- 			hp = 0
-- 		end
-- 		-- self:D('jaylog SHeroInWorld8010:adjHP ',self.attribute.HP,hp,self.attribute:getMaxHP(),(self.attribute:getMaxHP()*0.3))
-- 	end
-- 	local ret = SHeroInWorld8010.super.adjHP(self,hp,forceSync,must,zz)
-- 	-- self:D('jaylog SHeroInWorld8010:adjHP ret ',ret)
-- 	return ret
-- end

function SHeroInWorld8010:skillAttackMode9CallBack(p,itemID,atkP)
	SHeroInWorld8010.super.skillAttackMode9CallBack(self,p,itemID,atkP)
	self.world:D('xiaomalog SCreature118 param:',p,itemID,atkP)
	self:removeStatusList(999)
	self.world:D('xiaomalog SCreature118 not existEnemy removeStatusList 999')
	self:addStatusList({zz=3,i=self.itemID,s=621,r=self.world.gameTime,t=0.5,p2=0.5})
end

return SHeroInWorld8010