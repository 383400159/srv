local SHeroInWorld1997 = class("SHeroInWorld1997", require("gameroomcore.SHeroBase"))

function SHeroInWorld1997:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld1997.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	debuglog("SHeroInWorld1997:ctor........")
	--下次检测站位的时间
	self.nextMoveAITime = 0
end


function SHeroInWorld1997:_autoMove()
	if self.world.worldQTETime==nil or self.world.worldQTETime<self.world:getGameTime()  then
		self.autoFightAI.isBehindAI = true
		return SHeroInWorld1997.super._autoMove(self)
	else
		self.autoFightAI.isBehindAI = false
		return true
	end
end
--- 自动释放技能 
-- @return null
function SHeroInWorld1997:_autoFight()
	if self.isAI~=nil and self.isAI  then
		-- --记录AI需要躲避的时间
		-- self.worldQTETime = self.world:getGameTime() + skill.hitTime + parameters.LIFETIME
		-- --转动方向
		-- self.worldQTEDirection = self.angleSpeed
		debuglog("旋转AI:"..self.itemID.." "..self.world.worldQTETime.." "..self.world:getGameTime().." "..self.nextMoveAITime)
		if self.world.worldQTETime>=self.world:getGameTime() and self.nextMoveAITime<self.world:getGameTime() then
			--计算新坐标
			local r = 5
			if self.world.worldQTEDirection>0 then
				r = r*-1
			end
			local toX,toY = self.world.map:getXYLengthCross(self.posX,self.posY,self.world.BossX,self.world.BossY,r) 	
			local newtoX,newtoY=(self.posX+toX+self.world.formula:getRandnum(-100,100)*0.01),(self.posY+toY+self.world.formula:getRandnum(-100,100)*0.01)
			--local ret,newtoX,newtoY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX,self.posY+toY) 
			self:setMoveTarget(newtoX,newtoY)	
			self.nextMoveAITime = self.moveToEndTime-0.5
			return true
		else
			return SHeroInWorld1997.super._autoFight(self)	
		end
	else
		return SHeroInWorld1997.super._autoFight(self)
	end
end



return SHeroInWorld1997
