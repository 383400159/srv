local SHeroInWorld103 = class("SHeroInWorld103", require("gameroomcore.SHeroBase"))

function SHeroInWorld103:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld103.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


function SHeroInWorld103:prepareSkillAttackMode7(updateMove)
	return nil
end

return SHeroInWorld103