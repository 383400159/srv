local SHeroInWorld101 = class("SHeroInWorld101", require("gameroomcore.SHeroBase"))

function SHeroInWorld101:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld101.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

	-- --AI当时的行为 0为不作为
	-- self.worldAIMode=0
	-- --AI逗留时间
	-- self.worldAIDead=999999
	-- --AI切换下次行为的时间
	-- self.worldAINextModeTime=0
	-- --AI开始时间
	-- self.worldAIStartTime=0
	-- --AI正在执行动作 下次允许执行新动作的时间
	-- self.worldAINextTime=0
	-- --AI攻击开始时间
	-- self.worldAIATKStartTime=0
	-- --AI攻击结束时间
	-- self.worldAIATKEndTime=0
	-- --AI被打还击
	-- self.worldAICounterAttack=0
	-- --AI下线时间
	-- self.worldAIOfflineTime=0

end

---英雄的自动攻击..........
--返回true代表执行world的AI false执行英雄AI
-- function SHeroInWorld101:_autoFight()
	
-- 	if self.isAI then
-- 		return self.autoFightAI:world101AutoFight()
-- 	else
-- 		return false
-- 	end
-- 	-- if self.isAI and (self.worldAIStartTime + self.worldAIDead) > self.world:getGameTime() then

-- 	-- 	self.worldAIATKStartTime=self.moveToEndTime

-- 	-- 	--打怪AI开启战斗
-- 	-- 	if self.worldAIATKStartTime<self.world:getGameTime() and self.worldAIATKEndTime>self.world:getGameTime() then
-- 	-- 		--执行战斗AI
-- 	-- 		return false
-- 	-- 	end

-- 	-- 	--被人攻击开启AI
-- 	-- 	if self.lastHurtItemID>0  then
-- 	-- 		local obj = self.world.allItemList[self.lastHurtItemID]
-- 	-- 		if not obj:isDead() and (self.lastHurtTime+10)>self.world:getGameTime() then
-- 	-- 			self.worldAICounterAttack=self.lastHurtItemID
-- 	-- 			return false
-- 	-- 		end
-- 	-- 	end
-- 	-- 	--恢复正常地图AI
-- 	-- 	self.worldAICounterAttack=0


-- 	-- 	return true
-- 	-- else
-- 	-- 	return false
-- 	-- end
-- end


-- 出生点：60,50
-- 跑路点：150,60;55,280;150,275;140,190
-- NPC点：65,45;85,228;108,208;111,230
-- 小怪点：61,105;49,214;145,122;104,270;146,271

--- 自动移动chud
-- @return null
-- function SHeroInWorld101:_autoMove()


-- 	if self.isAI then
-- 		return self.autoFightAI:world101AutoMove()
-- 	else
-- 		return false
-- 	end

	
-- 	-- --AI溜达够了
-- 	-- if self.world:getGameTime()>(self.worldAIStartTime + self.worldAIDead) or (self.worldAIOfflineTime>0 and self.world:getGameTime()>self.worldAIOfflineTime) then
-- 	-- 	--需要擦除AI
-- 	-- end


-- 	-- if self.isAI and (self.worldAIStartTime + self.worldAIDead) > self.world:getGameTime() and self.worldAINextTime <  self.world:getGameTime() and self.worldAICounterAttack==0 then
-- 	-- 	--切换AI的行为
-- 	-- 	if self.world:getGameTime()>self.worldAINextModeTime then
-- 	-- 		self.worldAIMode = self.world.formula:getRandnum(1,5)
-- 	-- 		self.worldAINextModeTime = self.world:getGameTime() + self.world.formula:getRandnum(45,75)
-- 	-- 		self:D("地图AI itemID:",self.itemID," 切换模式为:",self.worldAIMode," 下次切换模式时间为:",self.worldAINextModeTime," 当前时间为:",self.world:getGameTime())
-- 	-- 	end

-- 	-- 	--跑出生点
-- 	-- 	if self.worldAIMode==1 then
-- 	-- 		local toX,toY = self:getWorldAIPOS(1)
-- 	-- 		self:setMoveTarget(toX,toY)
-- 	-- 		self:D("地图AI itemID:",self.itemID," 跑出生点",toX,toY)
-- 	-- 		self.worldAINextTime=self.moveToEndTime + self.world.formula:getRandnum(1,5)
-- 	-- 		self.worldAINextModeTime=self.moveToEndTime + self.world.formula:getRandnum(2,5)
-- 	-- 	end
-- 	-- 	--散步
-- 	-- 	if self.worldAIMode==2 then
-- 	-- 		local toX,toY = self:getWorldAIPOS(2)
-- 	-- 		self:setMoveTarget(toX,toY)
-- 	-- 		self:D("地图AI itemID:",self.itemID," 散步",toX,toY)
-- 	-- 		self.worldAINextTime=self.moveToEndTime + self.world.formula:getRandnum(0,3)
-- 	-- 	end
-- 	-- 	--找npc
-- 	-- 	if self.worldAIMode==3 then
-- 	-- 		local toX,toY = self:getWorldAIPOS(3)
-- 	-- 		self:setMoveTarget(toX,toY)
-- 	-- 		self:D("地图AI itemID:",self.itemID," 找npc",toX,toY)
-- 	-- 		self.worldAINextTime=self.moveToEndTime + self.world.formula:getRandnum(1,7)
-- 	-- 	end
-- 	-- 	--找小怪点
-- 	-- 	if self.worldAIMode==4 then
-- 	-- 		local toX,toY = self:getWorldAIPOS(4)
-- 	-- 		self:setMoveTarget(toX,toY)
-- 	-- 		self:D("地图AI itemID:",self.itemID," 找小怪点",toX,toY)
-- 	-- 		self.worldAINextTime=self.moveToEndTime + self.world.formula:getRandnum(10,30)
-- 	-- 		self.worldAIATKStartTime=self.moveToEndTime
-- 	-- 		self.worldAIATKEndTime=self.worldAINextTime
-- 	-- 	end
-- 	-- 	--挂机 然后下线
-- 	-- 	if self.worldAIMode==5 then
-- 	-- 		local toX,toY = self:getWorldAIPOS(2)
-- 	-- 		self:setMoveTarget(toX,toY)
-- 	-- 		self:D("地图AI itemID:",self.itemID," 挂机散步",toX,toY)
-- 	-- 		self.worldAINextTime=self.moveToEndTime + self.world.formula:getRandnum(300,600)
-- 	-- 		self.worldAIOfflineTime=self.moveToEndTime + self.world.formula:getRandnum(30,60)
-- 	-- 	end

-- 	-- 	return true
-- 	-- else
-- 	-- 	return false
-- 	-- end
-- end

-- function SHeroInWorld101:getWorldAIPOS(type)
-- 	-- body
-- 	local alist = {{60,50}}
-- 	local blist = {{150,60},{55,280},{150,275},{140,190}}
-- 	local clist = {{65,45},{85,228},{108,208},{111,230}}
-- 	local dlist = {{61,105},{49,214},{145,122},{104,270},{146,271}}

-- 	local list = {}

-- 	if type==1 then
-- 		list = alist
-- 	end
-- 	if type==2 then
-- 		list = blist
-- 	end
-- 	if type==3 then
-- 		list = clist
-- 	end
-- 	if type==4 then
-- 		list = dlist
-- 	end

-- 	local r = self.world.formula:getRandnum(1,#list)
-- 	local randX = self.world.formula:getRandnum(-500,500)
-- 	local randY = self.world.formula:getRandnum(-500,500)

-- 	return list[r][1]+randX*0.01,list[r][2]+randY*0.01
-- end

--- 受傷害計算
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHeroInWorld101:hurted(itemID,bulletID,mode,hitValue,adjTime)

	local hurt = SHeroInWorld101.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)

	return hurt
end


return SHeroInWorld101