local SHeroInWorld2006 = class("SHeroInWorld2006", require("gameroomcore.SHeroBase"))

function SHeroInWorld2006:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld2006.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self:D("位面攻击启动 SHeroInWorld2006")

end

function SHeroInWorld2006:addStatusList(statusArray, adjTime)
	--飞去位面
	if statusArray['s']==4300 then
		self:D("位面攻击启动 飞去位面")
		self:moveTo(self.posX+10,self.posY+10,true,2)
	end
	if statusArray['s']==4301 then
		self:D("位面攻击启动 飞出位面")
		self:moveTo(self.posX-10,self.posY-10,true,2)
		return nil
	end

	return SHeroInWorld2006.super.addStatusList(self,statusArray, adjTime)
end


function SHeroInWorld2006:endStatusCallBack( statusNum )

end


function SHeroInWorld2006:getBossObj()
	local obj = self.world:getObjBySubName("BOSS1",self.world.itemListFilter.heroList)
	return obj
end





return SHeroInWorld2006
