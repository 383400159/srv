local SHeroInWorld8011 = class("SHeroInWorld8011", require("gameroomcore.SHeroBase"))

function SHeroInWorld8011:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld8011.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.canPickUp = false
end

function SHeroInWorld8011:getBossObj()
	local obj = self.world:getObjBySubName("BOSS1",self.world.itemListFilter.heroList)
	return obj
end


function SHeroInWorld8011:_autoMove()
	local obj = self:getBossObj()
	if obj~=nil and not obj:isDead() then
		return false
	else
		return true
	end
end

function SHeroInWorld8011:skillAttackMode9CallBack(roleId,itemID)
	local obj = self.world.allItemList[itemID]
	if obj~=nil and not self:isDead() and self.actorType==0 then
		self.world:D('jaylog SHeroInWorld8011:skillAttackMode9CallBack ',self.itemID,itemID,roleId)
		self:addStatusList({zz=3,i=self.itemID,s=4422,r=self.world.gameTime,t=9999})
	end
end

--- 角色死亡,call 父类
function SHeroInWorld8011:goToDead(itemID,mode,adjTime,bonus)
	SHeroInWorld8011.super.goToDead(self,itemID,mode,adjTime,bonus)
	if self.isSmallAI then
		self:addStatusList({s=42,r=self.world.gameTime,t=9999999,i=self.itemID},60)
		self.world.playerList[self.itemID]['online'] = false
		self.world.playerList[self.itemID]['offLineTime']=self.world.gameTime-self.world.gameRoomSetting.offlineRemoveWaitTime + 60
	end
end

return SHeroInWorld8011