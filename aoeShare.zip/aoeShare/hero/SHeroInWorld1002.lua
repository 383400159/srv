local SHeroInWorld1002 = class("SHeroInWorld1002", require("gameroomcore.SHeroBase"))

function SHeroInWorld1002:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld1002.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


--- 复活, 游戏loop
-- @param null
-- @return null
function SHeroInWorld1002:revive()
end

--- 角色死亡,call 父类
function SHeroInWorld1002:goToDead(itemID,mode,adjTime,bonus)  
	SHeroInWorld1002.super.goToDead(self,itemID,mode,adjTime,bonus) 
	if self.parent==nil then
		self.world:D('jaylog SHeroInWorld1002:goToDead ',itemID,mode,self.loginID)
		if self.team=='A' then
			self.world.gameCounter['pointsB'] = self.world.gameCounter['pointsB'] + 1
		else
			self.world.gameCounter['pointsA'] = self.world.gameCounter['pointsA'] + 1
		end
		self.world:syncPointsInfo()
	end
end 

function SHeroInWorld1002:prepareSkillAttackMode7(updateMove)
	return nil
end

return SHeroInWorld1002