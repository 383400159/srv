local SHeroInWorld2005 = class("SHeroInWorld2005", require("gameroomcore.SHeroBase"))

function SHeroInWorld2005:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld2005.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.colour = ''
	--缓存中了多少影魔诅咒
	self.st4116List = {}
	self.next4116HurtTime = 0
end


function SHeroInWorld2005:endStatusCallBack( statusNum )
	-- body
	-- if statusNum==4116 then
	-- 	--召唤寄生影魔
	-- 	self:create286(7)
	-- end
end

--召唤
function SHeroInWorld2005:create286(hp)
	local creatureID=self.world:addCreature(self.world.tostring(286),'',self.posX,self.posY,self,1,0) 
	local obj  = self.world.allItemList[creatureID]
	local eItemList = {} 
	local enemy = self.world:runTargetTypeFilter(5,self.team,self.itemID,{},
		function(objv)
			ok = true
			if (objv.itemID==self.itemID) then ok = false end
			if (objv:isDead()) then ok = false end
			if ok then
				eItemList[#eItemList+1]=objv.itemID
			end
		end
		)

	if #eItemList>0 then
		local r = self.world.formula:getRandnum(1,#eItemList)
		obj.Hatredlist[""..eItemList[r]]=999999
	else
		obj.Hatredlist[""..self.itemID]=999999
	end
	obj.attribute.HP=hp
	obj:adjHP(0,true)
	self:D("一粒蛋影魔召唤  召唤寄生影魔286  creatureID:",creatureID)
end


function SHeroInWorld2005:getBossObj()
	local obj = self.world:getObjBySubName("BOSS1",self.world.itemListFilter.heroList)
	return obj
end

--- fight motion , call every update loop
-- @return null
function SHeroInWorld2005:fight()
	
	--运算口几次血
	--self.st4116List[#self.st4116List+1]={starTime=self.world.gameTime,t=10}	
	if self.st4116List~=nil and #self.st4116List>0 and self.next4116HurtTime<self.world:getGameTime() then
		local obj = self:getBossObj()
		local skill = obj.attribute.skills[8] 
		local parameters = skill.parameters 
		--ADDSTATUS2=41;ADDSTATUSTIME2=8;CLEANSELFSTATUS=4118;RADIUS=300;DURATION=8;HURTTIME=9;HURTINTERVAL=1;HURT=10;ENEMYHP=7

		self:D("一粒蛋影魔召唤  寄生:",self.itemID,self.world.cjson.encode(self.st4116List))
		local hitValueNew = {}
		hitValueNew['FIXHURT'] = 0
		for k,v in pairs(self.st4116List) do
			--判断状态过期没 没过期给予一个伤害
			if self.world:getGameTime()<(v.starTime+v.t) then
				hitValueNew['FIXHURT'] = hitValueNew['FIXHURT'] + obj.attribute.ATK*parameters.HURT*0.01
			else
				self:create286(v.hp)
				table.remove(self.st4116List,k)
			end
		end
		if hitValueNew['FIXHURT']>0 then
			self:directHurt(self.itemID,1,hitValueNew,0)
			self:D("一粒蛋影魔召唤  寄生伤害计算:",self.itemID,k)
		end
		self.next4116HurtTime = self.world:getGameTime() + parameters.HURTINTERVAL
	end


	SHeroInWorld2005.super.fight(self) 
end

return SHeroInWorld2005
