local SHeroInWorld1003 = class("SHeroInWorld1003", require("gameroomcore.SHeroBase"))

function SHeroInWorld1003:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld1003.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	--采矿成功次数
	self.atkMode9=0
	--1-3为矿 4击杀hero 5击杀怪
	self.gatherList={0,0,0,0,0}
end

function SHeroInWorld1003:skillAttackMode9CallBack(roleId,itemID)
	self:D("挖矿 回调",roleId,itemID)
	local obj = self.world.allItemList[itemID]
	if (roleId==280 or roleId==281 or roleId==282 ) and obj~=nil and not obj:isDead() then
		obj.attribute.HP=0
		obj:addStatusList({s=42,r=self.world.gameTime,t=16,i=obj.itemID},0.2)
		self.gatherList[roleId-279]= (self.gatherList[roleId-279]~=nil and self.gatherList[roleId-279] or 0 ) + 1
		self.atkMode9 = self.atkMode9 + 1
		self:D("挖矿 需要加分..........",self.world.cjson.encode(self.gatherList)," 采集次数:",self.atkMode9)

		-- local data = {}
		-- --data = {mapModel=self.world.mapModel,mapPort=self.world.gamePort,HP=self.attribute.HP,MP=self.attribute.MP,X=self.posX,Y=self.posY}
		-- data['info'] = {type=roleId-279}
		-- local ctrl = 'internalapi'
		-- local act = 'finishAct1'
		-- self:addApiCall(data,ctrl,act)

	end
end

function SHeroInWorld1003:prepareSkillAttackMode9(p)
	-- body
	SHeroInWorld1003.super.prepareSkillAttackMode9(self,p)
end


--- 复活, 游戏loop
-- @param null
-- @return null
function SHeroInWorld1003:revive()
	--GVB 没复活
	if self.deadTime<=self.world:getGameTime() then
		self:removeStatusList(9)
		self.towerComplete = 0
		if table.nums(self.buffList)>0 then
			local recal = false
			local skillID = 0
			for k,v in pairs(self.buffList) do
				skillID = v.buffID%1000000
				if skillID<990000 then
					self.buffList[k].isRemove = 1
					local statusNum = self:__buffID2StatusNum(v.buffID,v.buffParameter['statusnum'])
					if self.statusList[statusNum]~=nil and v.buffID>10000 then
						self:removeStatusList(statusNum)
					end
					recal = true
				end
			end
			if recal then
				self:reCalBuff()
			end
		end
		self.attribute.HP = self.attribute:getMaxHP()
		self.attribute.MP = self.attribute:getMaxMP()
		local pos = {{84,244},{146,244},{84,244},{146,244}}

		local r1 = self.world.formula:getRandnum(1,#pos)
		self.rebirthX=pos[r1][1]
		self.rebirthY=pos[r1][2]

		if self.rebirthX~=0 and self.rebirthY~=0 then
			self.posX = self.rebirthX
			self.posY = self.rebirthY
		else
			self.posX = self.initX
			self.posY = self.initY
		end
		self:__findingZone()
		self.skeleton = 0
		self.lastWalkTime = self.world:getGameTime()
		self.invincibleTime = self.world:getGameTime() + 1.5
		if self.rebirthX~=0 and self.rebirthY~=0 then
			self:moveTo(self.rebirthX,self.rebirthY,true,1)
			self.rebirthX = 0
			self.rebirthY = 0
		else
			self:moveTo(self.initX,self.initY,true,1)
		end
		self.syncMsg['m']['d']=0.05
		--self.syncMsg['m']=nil
		self.attackTarget = nil
		self.prepareSkillAttackNum = 0
		self.status = 0
		self:setCounter('revive')
		self:__getInfo()
		self:syncStatus()

		local result=self:getAllInfo(0,true)
		result['s'] = 1
		self:updateSyncMsg({i=result})
--		debuglog("血条bug revive .......itemID:"..self.itemID.." revive ..getMaxMP:"..self.attribute:getMaxMP())
	end

end


--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHeroInWorld1003:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	local ret = SHeroInWorld1003.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	local obj = self.world.allItemList[itemID]
	if ret>0 and obj:isDead() and (obj.attribute.actorType==0 or obj.attribute.actorType==1) then
		if obj.attribute.actorType==0 then
			self.gatherList[4]=self.gatherList[4]+1
		else
			self.gatherList[5]=self.gatherList[5]+1
		end
	end

	return ret 
end 



return SHeroInWorld1003