local SHeroInWorld1 = class("SHeroInWorld1", require("gameroomcore.SHeroBase"))

function SHeroInWorld1:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld1.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

function SHeroInWorld1:prepareSkillAttackMode7(updateMove)
	return nil
end

return SHeroInWorld1