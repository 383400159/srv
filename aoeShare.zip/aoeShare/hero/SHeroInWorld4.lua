local SHeroInWorld4 = class("SHeroInWorld4", require("gameroomcore.SHeroBase"))

function SHeroInWorld4:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld4.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end




return SHeroInWorld4