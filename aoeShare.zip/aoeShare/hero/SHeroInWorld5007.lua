local SHeroInWorld5007 = class("SHeroInWorld5007", require("gameroomcore.SHeroBase"))

function SHeroInWorld5007:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld5007.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	debuglog("SHeroInWorld5007:ctor........")
	--下次检测站位的时间
	self.nextMoveAITime = 0
end


function SHeroInWorld5007:_autoMove()
	if self.world.worldQTETime==nil or self.world.worldQTETime<self.world:getGameTime()  then
		self.autoFightAI.isBehindAI = true
		return SHeroInWorld5007.super._autoMove(self)
	else
		self.autoFightAI.isBehindAI = false
		return true
	end
end
--- 自动释放技能 
-- @return null
function SHeroInWorld5007:_autoFight()
	if self.isAI~=nil and self.isAI  then
		-- --记录AI需要躲避的时间
		-- self.worldQTETime = self.world:getGameTime() + skill.hitTime + parameters.LIFETIME
		-- --转动方向
		-- self.worldQTEDirection = self.angleSpeed
		debuglog("旋转AI:"..self.itemID.." "..self.world.worldQTETime.." "..self.world:getGameTime().." "..self.nextMoveAITime)
		if self.world.worldQTETime>=self.world:getGameTime() and self.nextMoveAITime<self.world:getGameTime() then
			--计算新坐标
			local r = 5
			if self.world.worldQTEDirection>0 then
				r = r*-1
			end
			local toX,toY = self.world.map:getXYLengthCross(self.posX,self.posY,self.world.BossX,self.world.BossY,r) 	
			local newtoX,newtoY=(self.posX+toX+self.world.formula:getRandnum(-100,100)*0.01),(self.posY+toY+self.world.formula:getRandnum(-100,100)*0.01)
			--local ret,newtoX,newtoY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX,self.posY+toY) 
			self:setMoveTarget(newtoX,newtoY)	
			self.nextMoveAITime = self.moveToEndTime-0.5
			return true
		else
			return SHeroInWorld5007.super._autoFight(self)	
		end
	else
		return SHeroInWorld5007.super._autoFight(self)
	end
end

--- 調整HP
-- @param hp float - HP
-- @param forceSync bool - 強制同步
-- @param must bool - 必定傷HP
-- @return success bool - true = ok
-- function SHeroInWorld5007:adjHP(hp,forceSync,must,zz)
-- 	if self.actorType==0 or self.attribute.actorType==0 then
-- 		-- self:D('jaylog SHeroInWorld5007:adjHP ',self.attribute.HP,hp,self.attribute:getMaxHP(),(self.attribute:getMaxHP()*0.3))
-- 		if hp<0 and ((self.attribute.HP+hp)<(self.attribute:getMaxHP()*0.2) or ((self.attribute.HP+hp)<100)) then
-- 			-- hp = self.attribute:getMaxHP() - self.attribute.HP
-- 			hp = 0
-- 		end
-- 		-- self:D('jaylog SHeroInWorld5007:adjHP ',self.attribute.HP,hp,self.attribute:getMaxHP(),(self.attribute:getMaxHP()*0.3))
-- 	end
-- 	local ret = SHeroInWorld5007.super.adjHP(self,hp,forceSync,must,zz)
-- 	-- self:D('jaylog SHeroInWorld5007:adjHP ret ',ret)
-- 	return ret
-- end

return SHeroInWorld5007

