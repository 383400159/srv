local SHeroInWorld2007 = class("SHeroInWorld2007", require("gameroomcore.SHeroBase"))

function SHeroInWorld2007:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld2007.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	--绑定一个冰牢
	self.creatureID = 0
	--下次冰冻时间
	self.next4280FROZENTime = 0 
	self.next4282FROZENTime = 0

	self.lastMoveTime = 0
end

function SHeroInWorld2007:addStatusList(statusArray, adjTime)
	--判断有没有冰牢冻住玩家 绑定一个怪在脚下
	if statusArray['s']==4280 then
		--让原来的冰牢死掉
		if self.creatureID>0 then
			local obj = self.world.allItemList[self.creatureID] 
			if obj~=nil then
				obj.attribute.HP=0
				obj:addStatusList({s=42,r=self.world.gameTime,t=16,i=obj.itemID},2)
				obj:directHurt(obj.itemID,1,{},0)
				self.creatureID = 0
			end
		end
		local bossObj = self:getBossObj()
		self.creatureID = self.world:addCreature(self.world.tostring(302),bossObj.teamOrig,self.posX,self.posY,self,1,0)
		self:D("冰牢 召唤一个302",self.creatureID)
	end
	return SHeroInWorld2007.super.addStatusList(self,statusArray, adjTime)
end


function SHeroInWorld2007:endStatusCallBack( statusNum )

end


function SHeroInWorld2007:getBossObj()
	local obj = self.world:getObjBySubName("BOSS1",self.world.itemListFilter.heroList)
	return obj
end

--- fight motion , call every update loop
-- @return null
function SHeroInWorld2007:fight()
	--self:D("冰牢 fight")
	if self.statusList[4280]~=nil then
		self:D("冰牢 有4280")
		local obj = self.world.allItemList[self.creatureID] 
		if obj~=nil and not obj:isDead()  then
			if self.world:getGameTime()>self.next4280FROZENTime then
				local bossObj = self:getBossObj()
				local skill = bossObj.attribute.skills[5] 
				local parameters = skill.parameters
				self:D("冰牢 冻住不洗澡")
				local attributes = table.deepcopy(self:getPrepareHithitValue())
				attributes['FIXHURT'] = self.attribute.MaxHP * parameters.HURTMAXHP * 0.01
				attributes['FROZEN_RATE']=100
				attributes['BUFFTIME'] = 99
				bossObj:directHurtToDalay(1,self.itemID,attributes,0)
				self.next4280FROZENTime = self.world:getGameTime() + parameters.ATKINTERVAL
				--让冰块恢复到玩家脚下
				obj:moveTo(self.posX,self.posY,true,6)
			end
		else
			self:D("冰牢 该洗澡了")
			self:removeStatusList(4280)
			self:removeBUff('FROZEN')
			self.next4280FROZENTime = 0
			self.creatureID = 0
		end
	else
		if self.creatureID>0 then
			local obj = self.world.allItemList[self.creatureID] 
			if obj~=nil then
				obj.attribute.HP=0
				obj:addStatusList({s=42,r=self.world.gameTime,t=16,i=obj.itemID},2)
				obj:directHurt(obj.itemID,1,{},0)
				self.creatureID = 0
				self:D("冰牢 该洗澡了")
				self:removeBUff('FROZEN')
			else
				self.creatureID = 0
			end
		end
	end
	
	SHeroInWorld2007.super.fight(self) 
end


--- move motion , call every update loop
-- @return null
function SHeroInWorld2007:move() 
	--self:D("冰牢 move")
	if self.statusList[4282]~=nil then
		if self.lastMoveTime == 0 then
			local bossObj = self:getBossObj()
			self.lastMoveTime = bossObj.bhsdTime
		end

		if self.paths~=nil and #self.paths>0  then
			self.lastMoveTime = self.world:getGameTime()
		end


		if (self.world:getGameTime()-self.lastMoveTime)>5 and self.world:getGameTime()>self.next4282FROZENTime then
			--玩家长久未动冰冻自己
			local bossObj = self:getBossObj()
			local attributes = table.deepcopy(self:getPrepareHithitValue())
			--attributes['FIXHURT'] = 999
			attributes['FROZEN_RATE']=100
			attributes['BUFFTIME'] = 8
			bossObj:directHurtToDalay(1,self.itemID,attributes,0)
			self.next4282FROZENTime = self.world:getGameTime() + 0.2
		end
	else
		self.lastMoveTime = 0
	end

	SHeroInWorld2007.super.move(self)
end




return SHeroInWorld2007
