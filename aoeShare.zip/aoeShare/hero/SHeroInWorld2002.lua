local SHeroInWorld2002 = class("SHeroInWorld2002", require("gameroomcore.SHeroBase"))

function SHeroInWorld2002:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld2002.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end



function SHeroInWorld2002:prepareSkillAttackMode7(updateMove)
	return nil
end

return SHeroInWorld2002