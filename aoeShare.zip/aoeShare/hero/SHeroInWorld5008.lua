local SHeroInWorld5008 = class("SHeroInWorld5008", require("gameroomcore.SHeroBase"))

function SHeroInWorld5008:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld5008.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.startMode9 = 0
	self.canPickUp = false
end


function SHeroInWorld5008:skillAttackMode9CallBack(roleId,itemID)
	local obj = self.world.allItemList[itemID]
	if obj~=nil and not obj:isDead() and self.actorType==0 then
		self.world:D('jaylog SHeroInWorld5008:skillAttackMode9CallBack start kill',roleId,itemID,self.world.cjson.encode(self.statusList[100]),self.world.cjson.encode(self.statusList[984]))
		obj.attribute.HP = 0
		obj:directHurt(itemID,1,{})
		self:setAutoBlocked(true)
		for k,v in pairs(self.world.itemListFilter.heroList) do
			if v.actorType==0 then
				self.world:D('jaylog SHeroInWorld5008:skillAttackMode9CallBack removeStatusList',v.itemID,self.world.cjson.encode(v.statusList[100]),self.world.cjson.encode(v.statusList[984]))
				if v.statusList[984]~=nil and v.statusList[984]['p3']==itemID then
					v:removeStatusList(984)
					v.startMode9 = 0
					v.canPickUp = false
					v:setAutoBlocked(true)
				end
			end
		end
		for k,v in pairs(self.world.itemListFilter.heroList) do
 			if v.actorType==0 and v.parent==nil then
 				local dist = 9999
 				local distNew,targetID = 0,0
 				for k1,v1 in pairs(self.world.allItemList) do
 					if v1.actorType==1 and self.world.tonumber(v1.attribute.roleId)==self.world.tonumber(roleId) and not v1:isDead() then
 						distNew = v:distance(v1.posX,v1.posY)
 						if distNew<dist then
 							dist = distNew
 							targetID = v1.itemID
 						end
 						self.world:D('jaylog set dist targetID:',dist,distNew,targetID,v1.itemID,v1.attribute.roleId,roleId)
 					end
 				end
 				if targetID~=0 then
	 				v:addStatusList({zz=3,i=v.itemID,s=984,r=self.world.gameTime,t=9999,p1=roleId,p2=self.world.tonumber(self.world.setting['takeFireTime']),p3=targetID,p4=dist,p5=1},0.2)
	 			end
 				self.world:D('jaylog statusList984:',v.itemID,self.world.cjson.encode(v.statusList[100]),self.world.cjson.encode(v.statusList[984]))
 			end
 		end
	end
end


function SHeroInWorld5008:prepareSkillAttackMode7(updateMove)
	return nil
end

--- 设置自动跟随到达后停止并且不参状态
-- @param itemID int - 目标ID，itemID>0开启跟随，不填或0取消跟随
-- @return null
-- function SHeroInWorld5008:setAutoTo(itemID)
-- 	if itemID==0 and self.statusList[984]~=nil then
-- 		local status = self.statusList[984]
-- 		self:addStatusList({zz=3,i=self.itemID,s=984,r=self.world.gameTime,t=9999,p1=status['p1'],p2=status['p2'],p3=status['p3'],p4=status['p4'],p5=1})
-- 	end
-- end

--- 調整HP
-- @param hp float - HP
-- @param forceSync bool - 強制同步
-- @param must bool - 必定傷HP
-- @return success bool - true = ok
-- function SHeroInWorld5008:adjHP(hp,forceSync,must,zz)
-- 	if self.actorType==0 then
-- 		-- self:D('jaylog SHeroInWorld5008:adjHP ',self.attribute.HP,hp,self.attribute:getMaxHP(),(self.attribute:getMaxHP()*0.3))
-- 		if hp<0 and (self.attribute.HP+hp)<(self.attribute:getMaxHP()*0.3) then
-- 			-- hp = self.attribute:getMaxHP() - self.attribute.HP
-- 			hp = 0
-- 		end
-- 		-- self:D('jaylog SHeroInWorld5008:adjHP ',self.attribute.HP,hp,self.attribute:getMaxHP(),(self.attribute:getMaxHP()*0.3))
-- 	end
-- 	local ret = SHeroInWorld5008.super.adjHP(self,hp,forceSync,must,zz)
-- 	-- self:D('jaylog SHeroInWorld5008:adjHP ret ',ret)
-- 	return ret
-- end

return SHeroInWorld5008