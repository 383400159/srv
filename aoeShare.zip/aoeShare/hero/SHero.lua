----debuglog('jaylog SHero worldForHero:'..worldForHero)
local SHero
if worldForHero==0 then
	SHero = class("SHero", require("gameroomcore.SHeroBase"))
else
	SHero = class("SHero", require("gameroom.hero.SHeroInWorld"..worldForHero))
end
--printlog('create SHERO ==================== '..worldForHero)
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @param actorID int - 游戏房玩家序号ID
-- @return null
function SHero:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	----debuglog("进来没！！！！！！！！！！！！！！")	

	if (self.className==nil) then 
		self.className="SHero" 
	end 

	if loginID==nil then loginID = "" end
	if skinNum==nil then skinNum = 0 end


	self.paths={}						--AI行进路线
	self.attackTarget=nil 	--攻击目标
	self.attribute={}				--英雄属性设置
	self.actorType=0 				--角色类型
	self.posX=12 						--位置X坐标
	self.posY=140 					--位置Y坐标
	self.lastPosX=0 				--上次位置X坐标
	self.lastPosY=0 				--上次位置Y坐标
	self.team =nil 					--队伍
	self.teamOrig = nil 		--原来队伍
	self.world =nil 				--world Obj
	self.parent=nil 				--父类

	self.itemID=actorID 								--游戏房角色num
	self.deadTime=0 							--死亡时间
	self.deadFlag=0 							--死亡状态
	self.dirty=0
	self.debug=false
	self.isAI=false					--是否AI
	self.initAI=false				--是否初始化AI数据

	self.status=0 -- 0=idle , 1=walk , 2=standby , 3=fight , 4=blockwait , 5=special , 6=dizzy , 7=freeze
	self.statusList={}

	self.syncMsg={}
	self.lastBulletID=0
	self.buffList={}
	
	self.isVisible=0 -- 1=yes 2=no -1=hidden 0=undeclared
	self.lastIsVisible=0 -- 1=yes 2=no -1=hidden 0=undeclared

	self.isGrass=0 -- 1=yes 2=no 0=undeclared

	self.lastAttackID=0  -- last attack id
	self.lastAttackTime=0 -- keep 3 second

	self.lastTowerPosition=nil
	self.lastTowerID=0

	self.visibleList={}

	self.skeleton=0

	self.prepareSkillAttackNum=0 -- wait for skill attack, skill order (mode 1-4)
	self.lastBulletPositionX=0 -- skill attack , start from position X 
	self.lastBulletPositionY=0 -- skill attack , start from position Y
	self.lastBulletTarget=0 -- skill attack , start from position Y
	self.lastHeroAttack=0 -- last attacked by enemy Hero
	
	self.heroAttack={} -- record the time of last attacked by enemy Hero

	self.comboKillHero=0
	self.comboKilled=0

	self.lastKillHero=0
	self.lastKilledByHero={}
	self.lastKillHeroTime=0
	self.playerObj=nil
	self.playerJson=nil
	self.playerHeroesObj=nil
	self.playerHeroesJson=nil

	self.bonus={}
	self.bonusType={}

	self.skinNum=0

	self.isSurrender=nil
	self.surrenderOrder=0

	self.lastControlTime=0
	self.lastOfflineTime=0
	self.totalIdleTime=0
	self.maxIdleTime=0

	self.openprint=0
	self.checkOverLapTime=0 


	self.starList={}

	self.autoBlocked=false
	--第一次进游戏
	self.beginGame = true

	--任务list
	self.taskList={}
	self.checkNPCList={}

	--任务开启的自动
	self.isTaskAuto = false
 	self.onlySimpleAttack = false
	self.world = world

	self.skinNum = skinNum

	if loginID~="" then
		self.loginID = loginID
		--if world.playerList[world:getItemID()]['playerJson']~=nil then
		self:D('jaylog SHero:ctor itemID',actorID)
		if world.playerList[actorID]['playerJson']~=nil then
			self.playerJson = world.playerList[actorID]['playerJson']
			self:D("skinHeroes playerJson",self.world.cjson.encode(self.playerJson))
		end

	end

	self:D('jaylog SHero:ctor before call super')
	SHero.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.debug=false
	self:D(" loginID :"..world.playerList[self.itemID]['id'])
	-- if   world.playerList[self.itemID]['id']=='AI奶爸' or world.playerList[self.itemID]['id']=='ywvvvvvvvv' or world.playerList[self.itemID]['id']=='ywnjjjj'  then
	-- 		self.AImode=1
	-- else
			self.AImode=0
	-- end

	self.redirectRoomTime = 0
	self.autoMoveStartTime = 0			--自动寻路开始时间
	self.autoMove = false				--自动寻路
	self.autoMoveStartAI = false		--自动寻路后开启AI
	self.autoMoveStartCollect = false		--自动寻路后开启AI
	self.movePath = {}					--自动寻路路线
	self.autoFollow = false			--自动跟随
	self.autoFollowTargetID = 0 	--自动跟随目标ID
	self.autoFollowTime = 0 			--自动跟随moveTo时间
	self.autoTo = false			--自动跟随停止
	self.autoToTargetID = 0 	--自动跟随停止目标ID
	self.lastMoveTime = 0					--上次移动时间
	self.lastTaskRedirectTime = 0 			--上次任务跳房时间
	self.redirectUpdataTask = false
	self.WFTaskID = 0 			--现时自身无缝taskID
	self.autoMoveTaskID = 0 	--自动寻路taskID
	self.taskUpdateAutoMoveID = 0 	--更新任务后会执行自动寻路的taskID

	self.lastBulletIDForDamage = 0			--計算損耗 的最後記錄子彈
	self.lastBulletIDForDamageDefense = {}			--計算損耗 的最後記錄子彈

	self.changePartSP = 999999 --控制SP的最大值

	-- API Call 顺序号seqNo
	self.seqNo = {
		task = 0,
		property = 0,
		api = 0,
		all = 100000000000,
	}
	self.stepCounter = {}				--每招的击中统计
	self.stepCounterStart = false		--开启计算每招的击中统计
	self.rebirthLockGVB = {}			--GVB点重生后锁操作
	self.clientInitLoopNum = 0 			--clientInit start=2时的循环次数
	self.clientInitLoopNum3 = 0 		--clientInit start=3时的循环次数
	self.clientInitLoopNum5 = 0 		--clientInit start=5时的循环次数

	self.creatureList={}

	self.autoFightAI = require("gameroom.ai.SAIHero").new(self)

	--下次恢复SP时间
	self.nextADDSPTime = 0
	--开始call tips api的时间
	self.startTipsCall = 0
	--重生延迟时间
	self.deadDelayTime = 0
end 

--- move motion , call every update loop
-- @return null
function SHero:move() 
	-- if self.moveStopTime>self.world.gameTime then
	-- 	return nil
	-- end
	SHero.super.move(self)

	local gameTime = self.world:getGameTime()

	if  self.lastControlTime+2<gameTime and self.lastCoolDownTime<gameTime then
		if self.heroIdleTime==0 then
			self.heroIdleTime = gameTime
		end
		if (self.AImode>0) and self.autoBlocked and self.heroIdleTime+0<gameTime then
			self.autoBlocked = false
		else
			self.autoBlocked = true
		end
	else
		self.heroIdleTime = 0
	end

	-- 檢查上馬
	self:prepareSkillAttackMode7(true)
	-- 刷新能源版的状态
	self.attribute.energyBoard:updateStatus()

	--- - 防型装备 护手、头盔、衣服、鞋子的耐久度消耗：
	--- 清除記錄
	for k,v in pairs(self.lastBulletIDForDamageDefense) do
		if v+5<gameTime then
			self.lastBulletIDForDamageDefense[k] = nil
		end
	end

	if self.isAI and not self.initAI and false then
		self:setPersonalityAI()
		self:D("fenglog 英雄AI gxAIlist:",self.world.cjson.encode(self.gxAIlist))
		self.initAI = true
	end
	
end

--- 檢查角色info是否需要同步, 及做相應處理
-- @return null
function SHero:syncInfo()
	SHero.super.syncInfo(self)
	--每秒增加SP
	if self.attribute.parameterArr.RESPNUM~=nil and self.attribute.parameterArr.RESPNUM>0 and self.world:getGameTime()>self.nextADDSPTime then
		self:adjSP(self.attribute.parameterArr.RESPNUM*3)
		self.nextADDSPTime = self.world:getGameTime() + 3
	end 
	--到时间就call tips api
	if self.startTipsCall>0 and self.startTipsCall<self.world:getGameTime() then
		self:addApiCall({},'player','getTipsStatusList')
		self.startTipsCall = 0
	end
end

--- init funtion 初始化属性参数
-- @param id int - role id
-- @param posX int - 起始坐标X
-- @param posY int - 起始坐标Y
-- @return null
function SHero:__init(id,posX,posY)
	self:D('jaylog SHero:__init before ',self.itemID)
	self.attribute = require("gameroom.attribute.SAttributeHero").new(id,1,self) --- level 1
	local pos
	if self.team=="A" then
		pos = string.splitNumber(self.world.setting['heroAInitialPosition'], ',')
	else
		if self.world.setting['heroBInitialPosition']~=nil then
			pos = self.world.sSplitNumber(self.world.setting['heroBInitialPosition'], ',')
		else
			pos = self.world.sSplitNumber(self.world.setting['heroAInitialPosition'], ',')
		end
	end
	if self.world.gameRoomSetting['ISYW']==1 then
		self.initX = pos[1]
		self.initY = pos[2]
	else
		self.initX = posX
		self.initY = posY
	end
	self.prepareSkillAttackNum = 0
	self.lastBulletPositionX = 0
	self.lastBulletPositionY = 0
	self.lastHeroAttack = -1
	self.lastHeroAttackForTower = -1

	--个性AI
	self.gxAIlist={
		AImaxHprate = self.attribute.AIRoleSetting['switchAtkModeA'][1]*0.01,
		AIminHprate = self.attribute.AIRoleSetting['switchAtkModeB'][1]*0.01,
		warnReactionTime = 0,
		warnRate =  100,
		atkARate =  100,
		defRate =  100,
		atkBRate =  100,
		skillRate =  100,
		normalAtkRate =  100,

	}
	-- self.AImaxHprate = self.attribute.AIRoleSetting['switchAtkModeA'][1]*0.01
	-- self.AIminHprate = self.attribute.AIRoleSetting['switchAtkModeB'][1]*0.01

	self.taskObj = require("gameroom.STask").new(self)	
	self.counterObj = require("gameroom.SCounter").new(self)
	self.equipCounter = require("gameroom.SEquipCounter").new(self)
	-- self.nextREHPMPTime = self.world:getGameTime()
	self:D('jaylog SHero:__init after ',self.itemID)
end

--设置个性AI 只适用用虚拟玩家AI
function SHero:setPersonalityAI()
	local AIRoleSetting = self.attribute.AIRoleSetting
	self.gxAIlist.AImaxHprate = (AIRoleSetting['switchAtkModeA'][1] + self.world.formula:getRandnum(-AIRoleSetting['switchAtkModeA'][2],AIRoleSetting['switchAtkModeA'][2]))*0.01
	self.gxAIlist.AIminHprate = (AIRoleSetting['switchAtkModeB'][1] + self.world.formula:getRandnum(-AIRoleSetting['switchAtkModeB'][2],AIRoleSetting['switchAtkModeB'][2]))*0.01
	self.gxAIlist.warnReactionTime =  self.world.formula:getRandnum(AIRoleSetting['warnReactionTime'][1]*100,AIRoleSetting['warnReactionTime'][2]*100)*0.01
	self.gxAIlist.warnRate =  self.world.formula:getRandnum(AIRoleSetting['warnRate'][1],AIRoleSetting['warnRate'][2])
	self.gxAIlist.atkARate =  self.world.formula:getRandnum(AIRoleSetting['atkARate'][1],AIRoleSetting['atkARate'][2])
	self.gxAIlist.defRate =  self.world.formula:getRandnum(AIRoleSetting['defRate'][1],AIRoleSetting['defRate'][2])
	self.gxAIlist.atkBRate =  self.world.formula:getRandnum(AIRoleSetting['atkBRate'][1],AIRoleSetting['atkBRate'][2])
	self.gxAIlist.skillRate =  self.world.formula:getRandnum(AIRoleSetting['skillRate'][1],AIRoleSetting['skillRate'][2])
	self.gxAIlist.normalAtkRate =  self.world.formula:getRandnum(AIRoleSetting['normalAtkRate'][1],AIRoleSetting['normalAtkRate'][2])
end

--- 设置技能限制施放时间
-- @param skill table - 角色某一招技能的所有设置值
-- @return null
function SHero:useCDTime(skill)
	local cooldown = 0
	----debuglog(" skill :"..self.world.cjson.encode(skill['parameters']))
	if skill.rank~=1 then
		cooldown = skill.parameters.CDTIME
	else
		cooldown = skill.parameters['CDTIME'..self.mode1step]	
	end

	skill.lastCoolDownValue = cooldown
	skill.lastCoolDownTime = self.world:getGameTime() + skill.lastCoolDownValue
	----debuglog("useCDTime CDTIME:"..cooldown )
	----debuglog("useCDTime lastCoolDownTime:"..skill.lastCoolDownTime )
	local sk = self.attribute.skills
	local gt = self.world:getGameTime()
	for i=2,7 do
		if sk[i] ~=nil then
			----debuglog("useCDTime 增加公共cd..i:"..self.attribute.skills[i].lastCoolDownTime)
			----debuglog("useCDTime 增加公共cd..g:"..self.world:getGameTime())
			if sk[i].lastCoolDownTime<(gt+skill.cutTime) then
				sk[i].lastCoolDownTime = gt+skill.cutTime
				----debuglog("useCDTime 增加公共cd..n:"..self.attribute.skills[i].lastCoolDownTime)
			end
		end
	end
end

--- 使用技能伤害，call父类的skillAttack
-- @param mode int - 技能 1-8 rank
-- @param itemID int - 攻擊目標 itemID
-- @param positionX float - 攻擊目標 位置 X
-- @param positionY float - 攻擊目標 位置 Y
-- @param force bool - true ＝ 無視失控, 失控時攻擊目標用
-- @param fromClientSide bool - true ＝ 來自客戶端
-- @return msg table - 返回msg 給client 包括action move skillstatus
function SHero:skillAttack(mode,itemID,positionX,positionY,force,fromClientSide,nPara,pPara)
	----debuglog("skillAttack........mode :",mode)
	local ret = SHero.super.skillAttack(self,mode,itemID,positionX,positionY,force,fromClientSide,nPara,pPara)
	if 	self.AImode==1 and  not self.autoBlocked and ret~=nil and mode>1 and mode<=5 then
		--AI技能释放成功
		--判断一秒内放的技能有几个
		if self.world.AIUseSkillNum==nil then
			self.world.AIUseSkillNum = 0
			--下次切换的时间
			self.world.AIUseSkillTime = self.world:getGameTime()+self.world.setting.AISkillDurationXinshou 
		else
			self.world.AIUseSkillNum = self.world.AIUseSkillNum + 1	
			self:D("fenglog 一段时间内限制技能次数 次数加一 itemID:",self.itemID,self.world.AIUseSkillNum,self.world.AIUseSkillTime,self.world:getGameTime(),mode,self.world.cjson.encode(ret))
		end 
	end
	return ret
end


-- --{"sk":[ {"s":1 , "l":1 ,"t":1.01 ,"cd":5 },{"s":2 , "l":1 ,"t":1.01 ,"cd":5 } ]}
--- sync skill信息给client端
-- @param delay float - 延迟执行时间
-- @return status table - 格式：{"sk":[ {"s":1 , "l":1 ,"t":1.01 ,"cd":5 },{"s":2 , "l":1 ,"t":1.01 ,"cd":5 } ]}
function SHero:syncSkill(delay)
	if delay==nil then delay = 0 end
	local status = {sk={i=self.itemID,a={}}}
	local t,cd
	for k,v in pairs(self.attribute.skills) do
		--self:D("skill list:",k," _ ",self.world.cjson.encode(v.parameters))
		t = v.lastCoolDownTime-self.world:getGameTime()
		cd = v.parameters.CDTIME
		if t<=0 and v.lastCoolDownTime>=0 then
			t = 0.01
		elseif t<0 then
			t = 0
		end

		if v.rank~=nil and cd~=nil and v.rank>1 and cd>0 then
			status['sk']['a'][#status['sk']['a']+1] = {d=delay,s=v.rank,t=t,cd=cd}
		end
	end
	self:updateSyncMsg(status)
	return status['sk']['a']
end


--- 發動攻擊
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return ret float - 傷害值
function SHero:hitTarget(itemID,bulletID,mode,hitValue,adjTime)
	local CRItype = 0
	--APADJ=0;ADADJ=50;CDTIME1=0.76;CDTIME2=0.53;CDTIME3=0.76;CDTIME4=0.53;CDTIME5=1;ATKMOVEDIS_S1=50;ATKMOVEDIS_S2=50;ATKMOVEDIS_S3=50;ATKMOVEDIS_S4=50;ATKMOVEDIS_S5=50
	if mode==1 then
			local skill = self.attribute.skills[mode]
			local parameters = skill.parameters 
		if self.mode1order>0 then
			-- local carom = skill.carom
			-- local carom_interval = skill.carom_interval
			self:D("carom:",carom)
			self:D("carom_interval:",carom_interval)
			local caromlist = skill.carom
			self:D("caromlist :",self.world.cjson.encode(caromlist))	
			
			-- if caromlist[self.mode1order]==nil then
			-- 	--阶段上限
			-- 	self.mode1order = 1
			-- 	self.mode1type = 0
			-- end
			
			local caromCrilist = string.split(caromlist[self.mode1order],",")
			self:D("caromCrilist :",self.world.cjson.encode(caromCrilist))	
			--获得间隔时间
			local caromitvlist = skill.carom_interval
			local caromitvtimelist = string.splitNumber(caromitvlist[self.mode1order],",")
			self:D("caromitvtimelist :",self.world.cjson.encode(caromitvtimelist))	
			local atknum =  #caromCrilist

			--获得需要击退的动作
			local carom_step_backward = skill.carom_step_backward
			local carombackward = string.splitNumber(carom_step_backward,",")
			self:D("carombackward :",self.world.cjson.encode(carombackward))
			local mode1delaytime = 0
			local mode1backward = -1

			for k,v in pairs(carombackward) do
				self:D("carombackward v:",self.world.cjson.encode(carombackward),v,self.mode1step)
				if v==tonumber(self.mode1step) then
					self:D("carombackward v1:",self.world.cjson.encode(carombackward),v,self.mode1step)
					local obj = self.world.allItemList[itemID]
					if self.parent==nil and obj.attribute.actorType==1 then
						mode1backward = 0
					end
					
				end
			end
		

			for i=1,atknum do
				self:D("mode1 打几下,atknum:",atknum)
				CRItype = self.world.tonumber(caromCrilist[i])
				hitValue['SEPARATE'] = 100/atknum
				self:D("mode1 打几下,hitValue['SEPARATE']:",hitValue['SEPARATE'])
				--计算普通攻击伤害
				--self.world:setRandomSeed()
				local CRIhurt = self.world.formula:modeCriHurt(CRItype)
				hitValue['CRIhurt'] = CRIhurt 
				--减掉第一下攻击延迟
				mode1delaytime = caromitvtimelist[i]+adjTime - caromitvtimelist[1]
				self:D("mode1 打几下,mode1delaytime:",mode1delaytime)
				if mode1backward==0 then
					--直播一次受击动作
					mode1backward = 1
					hitValue['Effect'] = 96
					local obj = self.world.allItemList[itemID] 
					local path = obj:moveTo(obj.posX,obj.posY) 	
					obj.syncMsg['m'] = nil
				end
				ret = SHero.super.hitTarget(self,itemID,bulletID,mode,hitValue,mode1delaytime)
				
			end
		else
			--普通攻击冲刺
			CRItype = self.world.tonumber(parameters['PREATKCAROM'..self.mode1step])
			local CRIhurt = self.world.formula:modeCriHurt(CRItype)
			hitValue['CRIhurt'] = CRIhurt 
			ret = SHero.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime)
		end
		-- if caromlist[self.mode1order]~=nil then
		-- 	--切换阶段 阶段+1
		-- 	if  caromlist[self.mode1order+1]~=nil then
		-- 		self.mode1type = self.world.tonumber(caromCrilist[1])
		-- 		self.mode1order = self.mode1order + 1
		-- 	else	
		-- 		self.mode1order = 1
		-- 		self.mode1type = 0
		-- 	end
		-- end

		self:D("mode1 self.mode1order :",self.mode1order)
		-- --debuglog("self.mode1star :",self.mode1star)
		-- --debuglog("caromCrilist :",self.world.cjson.encode(caromCrilist))
		-- self.mode1atktime = self.world:getGameTime()

	else
		if self.attribute.skills[mode]~=nil then
			local carom = self.attribute.skills[mode].carom
			CRIhurt = self.world.formula:modeCriHurt(self.world.tonumber(carom[1]))
			hitValue['CRIhurt'] = CRIhurt 
		end
	end
	


	if mode~=1 then
		local skill={}
		if mode>100 then
			skill = self.attribute.skills[mode-100]
		else
			skill = self.attribute.skills[mode]
		end
		
		if skill~=nil and skill.demonObj~=nil then
			skill.demonObj:hitTargetPrepare(itemID,bulletID,mode,hitValue,adjTime)
			--self:D("魔灵技能 hitTargetPrepare1 :",self.world.cjson.encode(hitValue))
			hitValue['DATKP'] = ""..skill.demonID
			hitValue['INEVITABLEHIT'] = 1
		end
		ret = SHero.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime)
		if skill~=nil and skill.demonObj~=nil then
			ret = skill.demonObj:hitTarget(itemID,bulletID,mode,hitValue,adjTime,ret)
		end
	end

	--- 攻型装备 武器、戒指、项链、护符 的耐久度消耗：
	--- 1、普通攻击，每次攻击，有5%机率减少1点耐久度；（每次攻击击中多个目标只计算一次扣损）
	--- 2、技能施放，每次施放，有10%机率减少1点耐久度	
	if self.lastBulletID>0 and self.lastBulletIDForDamage~=self.lastBulletID then
		local rand = self.world.formula:getRandnum(1,100)
		-- if (mode==1 and rand<=5) or (mode~=1 and rand<=10) then
		local settingLocal = self.world.setting
		if (mode==1 and rand<=self.world.tonumber(settingLocal['DuraATKHitRate'])) then
			self.equipCounter:setCounter('equipdamageattack',self.world.tonumber(settingLocal['DuraATKHit']))
			self.lastBulletIDForDamage = self.lastBulletID
		end
		if (mode~=1 and rand<=self.world.tonumber(settingLocal['DuraATKSkillRate'])) then
			self.equipCounter:setCounter('equipdamageattack',self.world.tonumber(settingLocal['DuraATKSkill']))
			self.lastBulletIDForDamage = self.lastBulletID
		end
	end

	-- 统计每part step击中数
	if self.world.gameRoomSetting['ISGVB']==1 and self.stepCounterStart then
		if mode>100 then
			mode = mode - 100
		end
		if self.stepCounter[mode]==nil then
			self.stepCounter[mode] = 0
		end
		self.stepCounter[mode] = self.stepCounter[mode] + 1
	end

	----debuglog("SHero:hitTarget.."..mode)
	return ret
end

--- 受傷害計算
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero:hurted(itemID,bulletID,mode,hitValue,adjTime)


	local fromObj = nil
	if itemID>0 then
		fromObj = self.world.allItemList[itemID]
	end


	if itemID>0 and fromObj.attribute.actorType==0 and fromObj.teamOrig~=self.teamOrig then
		self.lastHeroAttack = itemID
		self.lastHeroAttackTime = self.world.gameTime
		self.heroAttack[itemID] =self.world.gameTime
		if (hitValue['Effect']==nil or hitValue['Effect']==1 or hitValue['Effect']==9) and (hitValue['NoTowerProtect']==nil or hitValue['NoTowerProtect']~=1) then
			self.lastHeroAttackForTower = itemID
		end
	elseif itemID>0 and fromObj.parent~=nil and fromObj.parent.attribute~=nil and fromObj.parent.attribute.actorType==0 and fromObj.parent.teamOrig~=self.teamOrig then
		self.lastHeroAttack = fromObj.parent.itemID
		self.lastHeroAttackTime = self.world.gameTime
		self.heroAttack[fromObj.parent.itemID] = self.world.gameTime

		if (hitValue['Effect']==nil or hitValue['Effect']==1 or hitValue['Effect']==9) and (hitValue['NoTowerProtect']==nil or hitValue['NoTowerProtect']~=1) then
			self.lastHeroAttackForTower = fromObj.parent.itemID
		end
	end


	local hurt = SHero.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
	if hurt>0 and  not self:isDead() then
		self.attribute.energyBoard:run("TRIGGERLOWER_HP",{HP=self.attribute.HP,MaxHP=self.attribute.MaxHP})
	end

	--- - 防型装备 护手、头盔、衣服、鞋子的耐久度消耗：
	--- 1、普通攻击，每次被攻击，有5%机率减少1点耐久度
	if hurt>0 and fromObj~=nil and bulletID==fromObj.lastBulletID and self.lastBulletIDForDamageDefense[bulletID]==nil then
		local rand = self.world.formula:getRandnum(1,100)
		local settingLocal = self.world.setting
		if (rand<=self.world.tonumber(settingLocal['DuraDEFbeHitRate'])) then
			self.equipCounter:setCounter('equipdamagedefense',self.world.tonumber(settingLocal['DuraDEFbeHit']))
			self.lastBulletIDForDamageDefense[bulletID] = self.world:getGameTime()
		end
	end

	-- --计算格挡
	-- if self.moveShieldTime>0 and self.moveShieldTime>self.world:getGameTime() and  self.shieldSkillTime<self.world:getGameTime() then
	-- 	--释放格挡技能
	-- 	--debuglog("格挡  释放格挡技能/////////.......................")
	-- 	math.randomseed(os.time()+itemID*1888) 
	-- 	--self.world:setRandomSeed()
	-- 	local skill = self.attribute.skills[7] 
	-- 	local parameters = skill.parameters 
	-- 	if self.world.mRandom(0,100)<parameters.COUNTER_RATE then
	-- 		self:skillAttack(7,itemID)
	-- 		self.shieldSkillTime = self.moveShieldTime
	-- 		self:removeSkillAttackMode7()
	-- 	end
	-- end


	return hurt
end



--- 调整自身HP值
-- @param hp float - 调整的值
-- @param forceSync boolean - 强制syn玩家HP数据到client
-- @param must boolean - 无视任何状态都扣血
-- @return ret boolean - 是否成功调整HP
function SHero:adjHP(hp,forceSync,must,zz) 
	if forceSync ==nil then forceSync = false end
	if must ==nil then must = false end

	local ret = SHero.super.adjHP(self,hp,forceSync,must,zz) 
	return ret 
end

--- 由getAttributeAndSync调用，用于组织heroInfo信息
function SHero:getAttribute(syncMsg)
	if syncMsg==nil then syncMsg = false end
	local msg = {
		hi = {
			eq7q = self:getCounter('killhero'),
			eq8q = self:getCounter('killed')
		}
	}
	if syncMsg then
		self:updateSyncMsg(msg)
	end

	return msg
end



--- 重新計算所有有效buff
-- @return null
function SHero:reCalBuff()
	SHero.super.reCalBuff(self)
	if self.debug  then
		if self.statusList ~=nil then
		for key,value in pairs(self.statusList) do
			----debuglog("Log2\tID:"..self.itemID.." Team:"..self.team.." Status:"..key.." totalTime:"..value['t'].." remainTime:"..(value['t']-self.world.gameTime-value['r']))
		end
		end
		if self.buffList ~=nil then
		for key,value in pairs(self.buffList) do
			if key ~=nil and value ~=nil then
			----debuglog("Log2\tID:"..self.itemID.." Team:"..self.team.." Buff:"..key.." Detail:"..(value.buffAttribute~=nil and cjson.encode(value.buffAttribute)  or "NULL" ).." Para:"..(value.buffParameter~=nil and  cjson.encode(value.buffParameter) or "NULL"))
			end
		end
		end
	end
end


--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SHero:goToDead(itemID,mode,adjTime,bonus)
	if mode==nil then mode = 0 end
	if adjTime==nil then adjTime = 0 end
	if bonus==nil then bonus = {} end
	-- self.world:D("pvp 检测击杀:",itemID,self.itemID,self.world.playerList[itemID]['id'],self.world.playerList[self.itemID]['id'],mode)
	self:D("goToDead。。。。。。。。SHero ",self.attribute.roleId,itemID,adjTime)
	-- if self.isAI then
	-- 	self.world:D('jaylog AI goToDead ',self.loginID)
	-- end
	SHero.super.goToDead(self,itemID,mode,adjTime,bonus)
	local time=5
	
	if self.world.setting.ReviveTime~=nil and self.world.tonumber(self.world.setting.ReviveTime)>0 then
		time = self.world.setting.ReviveTime
		self:D('jaylog SHero:goToDead time 1:',time,self.loginID)
	end

	if self:isAIObj() and self.world.setting.PVPreviveTime~=nil and self.world.tonumber(self.world.setting.PVPreviveTime)>0 then
		time = self.world.setting.PVPreviveTime
		self:D('jaylog SHero:goToDead time 2:',time,self.loginID)
	end

	if (self.world.tonumber(self.world.mapModel)==1001 or self.world.tonumber(self.world.mapModel)==1005 or self.world.tonumber(self.world.mapModel)==1006 or self.world.tonumber(self.world.mapModel)==1008) and self.world.setting.PVPreviveTime~=nil and self.world.tonumber(self.world.setting.PVPreviveTime)>0 then
		time = self.world.setting.PVPreviveTime
		self:D('jaylog SHero:goToDead time 3:',time,self.loginID)
	end

	if self.world.gameRoomSetting['ISGVB']==1 then
		time = 9999
		self:D('jaylog SHero:goToDead time 4:',time,self.loginID)
	end
	--清除AI上次行为
	self.autoFightAI:cleanWorldAI()
	self:setAutoMove()
	self.attackTarget = nil
	if type(adjTime)=="string" then self:D('why is string "'..adjTime..'"') end
	self.deadTime = self.world:getGameTime() + time + adjTime
	if self.world.gameRoomSetting['ISPVP']==1 and self.parent==nil and self.world.gameFlag['pvpHeroReviveDelayStart'] and self.world.gameFlag['pvpHero'..self.team..'ReviveDelay']~=0 then
		self.world:D('jaylog goToDead checkPVPreviveDelay',self.world.gameTime,self.attribute.roleId,self.world.gameFlag['pvpHeroReviveDelayStart'],self.deadTime,self.world.gameFlag['pvpHero'..self.team..'ReviveDelay'],self.world.gameFlag['pvpHero'..self.team..'ReviveTime'])
		if (self.world.gameFlag['pvpHero'..self.team..'ReviveTime'] + self.world.gameFlag['pvpHero'..self.team..'ReviveDelay'])>self.deadTime then
			self.deadTime = self.world.gameFlag['pvpHero'..self.team..'ReviveTime'] + self.world.gameFlag['pvpHero'..self.team..'ReviveDelay']
		end
		self.world.gameFlag['pvpHero'..self.team..'ReviveTime'] = self.deadTime
	end
	if adjTime>1 then adjTime = 1 end
	local s9data = {s=9,r=self.world:getGameTime()+adjTime,t=9999,i=self.itemID}
	local reviveCost
	local reviveCostType
	local reviveTeamCost,reviveTeamCostType
	if self.world.gameRoomSetting['ISYW']==1 then
		reviveCost = self.world.sSplitNumber(self.world.setting['YWreviveCost'],',')
		reviveCostType = self.world.tonumber(self.world.setting['YWreviveCostType'])
		if reviveCost[self.attribute.rebirth]==nil then
			s9data['p1'] = reviveCost[#reviveCost]
		else
			s9data['p1'] = reviveCost[self.attribute.rebirth]
		end
		s9data['p2'] = reviveCostType
	end
	if self.world.gameRoomSetting['ISGVB']==1 then
		reviveCost = self.world.sSplitNumber(self.world.setting['GVBreviveCostNum'],',')
		reviveCostType = self.world.tonumber(self.world.setting['GVBreviveCostType'])
		if reviveCost[self.attribute.rebirth]==nil then
			s9data['p1'] = reviveCost[#reviveCost]
		else
			s9data['p1'] = reviveCost[self.attribute.rebirth]
		end
		s9data['p2'] = reviveCostType
		reviveTeamCost = self.world.sSplitNumber(self.world.setting['GVBTeamreviveCostNum'],',')
		reviveTeamCostType = self.world.tonumber(self.world.setting['GVBTeamreviveCostType'])
		if reviveTeamCost[self.attribute.rebirthTeam]==nil then
			s9data['p3'] = reviveTeamCost[#reviveTeamCost]
		else
			s9data['p3'] = reviveTeamCost[self.attribute.rebirthTeam]
		end
		s9data['p4'] = reviveTeamCostType
	end
	local p6 = itemID
	if self.world.allItemList[itemID]~=nil and self.world.allItemList[itemID].parent~=nil then
		p6 = self.world.allItemList[itemID].parent.itemID
	end
	s9data['p6'] = p6
	self.world:D('jaylog SHero:goToDead s9data ',self.loginID,self.world.cjson.encode(s9data),self.world.cjson.encode(reviveCost),self.world.setting['YWreviveCostType'])
	self:addStatusList(s9data,adjTime+0.1)
	--死亡倒计时状态
	self:addStatusList({s=981,r=self.world:getGameTime()+adjTime,t=time},adjTime+0.1)
	self:moveTo(self.posX,self.posY)

	self:setCounter("killed",1)
	-- 攻型装备 武器、戒指、项链、护符 的耐久度消耗
	-- 3、野外死亡：每次死亡损耗当前耐久度15%
	-- 防型装备 护手、头盔、衣服、鞋子的耐久度消耗：
	-- 3、野外死亡：每次死亡损耗当前耐久度30%
	if self.world.gameRoomSetting['ISYW']==1 then
		self.equipCounter:setCounter("equipdamagedead",1)
	end
	self.comboKillHero = 0
	self.comboKilled = self.comboKilled + 1
	self:getAttributeAndSync()

	local lastAtkId = 0
	local lastAtkTime = 0
	-- self:D('jaylog heroAttack : ',self.world.cjson.encode(self.heroAttack))
	for k,v in pairs(self.heroAttack) do
		if v~=nil and v+10>=self.world:getGameTime() then
			if v>lastAtkTime then
				lastAtkId = k
				lastAtkTime = v
			end
		end
	end

	if lastAtkId~=0 and self.world.allItemList[lastAtkId]~=nil and self.parent==nil then
		local msgtime = 0.2
		local bcfound = false
		local obj = self.world.allItemList[lastAtkId]
		if not self.world.gameFlag['firstKill'] then
			self.world.gameFlag['firstKill'] = true
			local p1ID = obj.itemID
			if obj.parent~=nil then
				p1ID = obj.parent.itemID
			end
			self:updateSyncMsg({bc={{mid=10,p1=p1ID,p2=self.itemID,d=msgtime+adjTime}}})
			self.world:D('jaylog goToDead bc10 ',obj.itemID,obj.attribute.roleId,obj.loginID,self.itemID,self.attribute.roleId,self.loginID)
			bcfound = true
		end
		obj.comboKillHero = obj.comboKillHero + 1
		obj.comboKilled = 0
		if obj.lastKillHeroTime+12>=self.world:getGameTime() then
			obj.lastKillHero = obj.lastKillHero + 1
		else
			obj.lastKillHero = 1
		end
		obj.lastKillHeroTime = self.world:getGameTime()
		if obj.lastKillHero>1 then
			if obj.lastKillHero>5 then
				obj.lastKillHero = 5
			end
			local p1ID = obj.itemID
			if obj.parent~=nil then
				p1ID = obj.parent.itemID
			end
			self:updateSyncMsg({bc={{mid=88+obj.lastKillHero,p1=p1ID,p2=self.itemID,d=msgtime+obj.comboKillHero*0.3+adjTime}}})
			self.world:D('jaylog goToDead bc88 ',obj.itemID,obj.attribute.roleId,obj.loginID,self.itemID,self.attribute.roleId,self.loginID)
			bcfound = true
		end
		
		if self.lastKilledByHero[obj.itemID]==nil then
			self.lastKilledByHero[obj.itemID] = 1
		end
		if not bcfound then
			if obj.lastKilledByHero[self.itemID]~=nil and obj.lastKilledByHero[self.itemID]==1 and (self.lastKilledByHero[obj.itemID]==nil or self.lastKilledByHero[obj.itemID]==1) then
				local p1ID = obj.itemID
				if obj.parent~=nil then
					p1ID = obj.parent.itemID
				end
				self:updateSyncMsg({bc={{mid=94,p1=p1ID,p2=self.itemID,d=msgtime+self.comboKillHero*0.3+adjTime}}})
				self.world:D('jaylog goToDead bc94 ',obj.itemID,obj.attribute.roleId,obj.loginID,self.itemID,self.attribute.roleId,self.loginID)
				obj.lastKilledByHero[self.itemID] = 2
				self.lastKilledByHero[obj.itemID] = 2
				bcfound = true
			end
		end
		if not bcfound then
			local p1ID = obj.itemID
			if obj.parent~=nil then
				p1ID = obj.parent.itemID
			end
			self.world:addSyncMsg({bc={{mid=9,p1=p1ID,p2=self.itemID,d=adjTime}}})
			self.world:D('jaylog goToDead bc9 ',obj.itemID,obj.attribute.roleId,obj.loginID,self.itemID,self.attribute.roleId,self.loginID)
		end
		if obj.parent~=nil then
			obj.parent:setCounter("killhero",1)
		else
			obj:setCounter("killhero",1)
		end
		-- 增加荣誉点
		if self.world.gameRoomSetting['ISYW']==1 then
			if obj.actorType==0 then
				local p1ID = obj.itemID
				if obj.parent~=nil then
					p1ID = obj.parent.itemID
				end
				self.world:addSyncMsg({bc={{mid=102,p1=p1ID,p2=self.itemID,p3=obj.attribute.school..','..self.attribute.school,d=adjTime}}})
				self.world:D('jaylog goToDead bc102 ',obj.itemID,obj.attribute.roleId,obj.loginID,self.itemID,self.attribute.roleId,self.loginID)
			end
			if obj.actorType==0 and not obj:isAIObj() then
				if (obj.attribute.level-self.attribute.level)<10 then
					local levelKey,gradeKey = '',''
					local num = self.world.mAbs(obj.attribute.level-self.attribute.level)
					local lv = ''
					if num<10 then
						lv = '00'..num
					elseif num<100 then
						lv = '0'..num
					else
						lv = num
					end
					if (obj.attribute.level-self.attribute.level)>0 then
						levelKey = 'ld'..lv
					else
						levelKey = 'lu'..lv
					end
					num = self.world.mAbs(obj.attribute.GRADELEVEL-self.attribute.GRADELEVEL)
					if num<10 then
						lv = '00'..num
					elseif num<100 then
						lv = '0'..num
					else
						lv = num
					end
					if (obj.attribute.GRADELEVEL-self.attribute.GRADELEVEL)>0 then
						gradeKey = 'gd'..lv
					else
						gradeKey = 'gu'..lv
					end
					obj.equipCounter:setCounter('grade_m'..levelKey..gradeKey..'p'..self.world.playerList[self.itemID]['p']..'ct'..self.world.tNums(self.heroAttack),1)
					obj:updateEquipLose()
					for hak,hav in pairs(self.heroAttack) do
						local haObj = self.world.allItemList[hak]
						if haObj~=nil and haObj.actorType==0 and not haObj:isAIObj() and hak~=lastAtkId then
							haObj.equipCounter:setCounter('grade_s'..levelKey..gradeKey..'p'..self.world.playerList[self.itemID]['p']..'ct'..self.world.tNums(self.heroAttack),1)
							haObj:updateEquipLose()
						end
					end
				end
			end
		end
		obj:getAttributeAndSync()
	end

	if self.world.gameRoomSetting['ISYW']==1 and not self:isAIObj() then
		self:setAuto(false)
		self:updateEquipLose()
	end
	self:setBossCounter(itemID,mode,adjTime,bonus)
end

function SHero:setBossCounter(itemID,mode,adjTime,bonus)
	--成就统计
	if self.statusList[4010]~=nil then
		--盗梦空间
		self:setCounter("dieInDream_2001",1)
	end

	if self.statusList[4021]~=nil then
		--不小心踩坑了！
		self:setCounter("killBossOnlyMeAlive_2002",1)
	end
end

--- 准备攻击前置设置，在prepareHit之前执行
-- @param mode int - 技能1-7
-- @param itemID int - 目标对象id
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SHero:prepareSkillAttackCustom(mode,itemID,x,y,adjtime,syncMsg)
	local skill = {}
	if mode>100 then
		skill = self.attribute.skills[mode-100]
	else
		skill = self.attribute.skills[mode]
	end
	
	if skill~=nil and skill.demonObj~=nil then
		skill.demonObj:prepareSkillAttackCustom(mode,itemID,x,y,adjtime,syncMsg)
	else
		SHero.super.prepareSkillAttackCustom(self,mode,itemID,x,y,adjTime,syncMsg)
	end
end

--- API Call结果返回处理
-- @param jobID string - 队列ID
-- @param result string - API返回的结果
-- @return null
function SHero:APICallJobCallBack(jobID,result)
	--if self.world.gameRoomSetting['ISYW']==1 then
		self:D('jaylog hero APICallJobCallBack in:',jobID,' result:',result,self.loginID,' online:',self.world.cjson.encode(self.world.playerList[self.itemID]['online']))
		--self.world:--debuglog('jaylog hero APICallJobCallBack world in:'..jobID..' result:'..result)
		if result==nil or result=='noData' then
			return nil
		end
		local dataAll = self.world.cjson.decode(result)
		--local data = {}
		-- if dataAll~=nil and dataAll['data']~=nil then
		-- 	data = dataAll['data']
		-- end
		-- if data['updateProperty']~=nil then
		-- 	self:updateProperty()
		-- 	local result=self:getAllInfo(0,true)
		-- 	self:updateSyncMsg({i=result})
		-- end
		-- if data['updateSkill']~=nil then
		-- 	self:updateSkillProperty()
		-- end
		-- if data['updateDemon']~=nil then
		-- 	self:updateDemonProperty()
		-- end
		-- if data['updateEnergy']~=nil then
		-- 	self:updateEnergyProperty()
		-- end
		-- if data['updateTask']~=nil then
		-- 	self:updateTask()
		-- end
		-- if data['updateRebirth']~=nil then
		-- 	self:updateRebirth()
		-- end
		-- if data['updateRebirthFree']~=nil then
		-- 	self:updateRebirthFree()
		-- end
		if dataAll~=nil then
			for k,resultSub in pairs(dataAll) do
				-- local seqNo = self.world.tonumber(self.world.sSub(resultSub,10,25))
				if self.world.sSub(resultSub,1,1)=="1" then
					self:updateProperty()
				end
				if self.world.sSub(resultSub,2,2)=="1" then
					self:updateSkillProperty()
				end
				if self.world.sSub(resultSub,3,3)=="1" then
					self:updateTask()
				end
				if self.world.sSub(resultSub,4,4)=="1" then
					self:updateDemonProperty()
				end
				if self.world.sSub(resultSub,5,5)=="1" then
					self:updateEnergyProperty()
				end
				if self.world.sSub(resultSub,6,6)=="1" then
					self:updateRebirth()
					self.attribute.rebirth = self.attribute.rebirth + 1
				end
				if self.world.sSub(resultSub,7,7)=="1" then
					self:updateRebirthFree()
				end
				if self.world.sSub(resultSub,8,8)=="1" then
					self.attribute.HP = self.attribute:getMaxHP()
				end
				if self.world.sSub(resultSub,9,9)=="1" then
					self.rebirthBuff['MSPD'] = 1
					self:updateRebirthFree()
				end
				if self.world.sSub(resultSub,10,10)=="1" then
					self.rebirthBuff['MSPD'] = 1
					self.rebirthBuff['HP'] = 1
					self:updateRebirthFree()
				end
				if self.world.sSub(resultSub,11,11)=="1" then
					self.rebirthBuff['MSPD'] = 1
					self.rebirthBuff['HP'] = 1
					self.rebirthBuff['ATK'] = 1
					self:updateRebirth()
				end
				if self.world.sSub(resultSub,12,12)=="1" then
					if self.world.gameRoomSetting['ISGVB']==1 and self.world.setting['GVBreviveBuffName']~=nil then
						self.rebirthBuff[self.world.setting['GVBreviveBuffName']] = self.world.tonumber(self.world.setting['GVBreviveBuffPer'])
					end
					self:updateRebirth()
					self.attribute.rebirth = self.attribute.rebirth + 1
					self:updateRebirthStatus()
				end
				if self.world.sSub(resultSub,13,13)=="1" then
					local otherID=self.world:memcacheGet('aoeRebirthOtherID'..self.world.tonumber(self.world.playerList[self.itemID]['p']))
					for pk,pv in pairs(self.world.playerList) do
						if self.world.tonumber(otherID)==self.world.tonumber(pv['p']) then
							if self.world.gameRoomSetting['ISGVB']==1 and self.world.setting['GVBreviveBuffName']~=nil then
								self.world.allItemList[pk].rebirthBuff[self.world.setting['GVBreviveBuffName']] = self.world.tonumber(self.world.setting['GVBreviveBuffPer'])
							end
							self.world.allItemList[pk]:updateRebirth(self.rebirthLockGVB[pk]['x'],self.rebirthLockGVB[pk]['y'])
							self.rebirthLockGVB[pk] = nil
							self.world.allItemList[pk].attribute.rebirth = self.world.allItemList[pk].attribute.rebirth + 1
							self.world.allItemList[pk]:updateRebirthStatus()
						end
					end
				end
				if self.world.sSub(resultSub,14,14)=="1" then
					self:removeSkillAttackMode9()
				end
				if self.world.sSub(resultSub,16,16)=="1" then
					self.attribute.rebirthTeam = self.attribute.rebirthTeam + 1
					local selfDead = self:isDead()
					local rbX,rbY = 0,0
					for pk,pv in pairs(self.rebirthLockGVB) do
						if not selfDead then
							rbX,rbY = self.rebirthLockGVB[pk]['x'],self.rebirthLockGVB[pk]['y']
							break
						end
					end
					for ak,av in pairs(self.world.itemListFilter.heroList) do
						if av.actorType==0 then
							local pk=ak
							if self.world.gameRoomSetting['ISGVB']==1 and self.world.setting['GVBTeamreviveBuffName']~=nil then
								self.world.allItemList[pk].rebirthBuff[self.world.setting['GVBTeamreviveBuffName']] = self.world.tonumber(self.world.setting['GVBTeamreviveBuffPer'])
							end
							local toX,toY = av.posX,av.posY
							if self.rebirthLockGVB[ak]~=nil then
								if not selfDead then
									toX,toY = rbX,rbY
								end
								if self.world.allItemList[pk]:isDead() then
									-- if self.world.setting['GVBTeamreviveBuffName']~=nil then
									-- 	self.world.allItemList[pk].rebirthBuff[self.world.setting['GVBTeamreviveBuffName']] = self.world.tonumber(self.world.setting['GVBTeamreviveBuffPer'])
									-- end
									self.world.allItemList[pk]:updateRebirth(toX,toY)
									self.rebirthLockGVB[pk] = nil
									self.world.allItemList[pk]:updateRebirthStatus()
								end
							else
								if not self.world.allItemList[pk]:isDead() then
									self.world.allItemList[pk].attribute.HP = self.world.allItemList[pk].attribute:getMaxHP()
									local result=self.world.allItemList[pk]:getAllInfo(0,true)
									self.world.allItemList[pk]:updateSyncMsg({i=result})
									for rbk,rbv in pairs(self.world.allItemList[pk].rebirthBuff) do
										if rbv~=0 then
											self.world.allItemList[pk]:addRebirthBuff(rbk,rbv)
											self.world.allItemList[pk].rebirthBuff[rbk] = 0
										end
									end
								else
									if not selfDead then
										toX,toY = rbX,rbY
									end
									self.world.allItemList[pk]:updateRebirth(toX,toY)
									self.rebirthLockGVB[pk] = nil
									self.world.allItemList[pk]:updateRebirthStatus()
								end
							end
						end
					end
				end
				-- if self.world.sSub(resultSub,15,15)=="1" then
				-- 	self:updateSyncMsg({bc={{zz=3,mid=104,i=self.itemID}}})
				-- 	self.world:D('jaylog add mid 104',self.world.cjson.encode(self.syncMsg))
				-- end
				-- if self.world.sSub(resultSub,16,16)=="1" then
				-- 	self:updateSyncMsg({bc={{zz=3,mid=105,i=self.itemID}}})
				-- 	self.world:D('jaylog add mid 105',self.world.cjson.encode(self.syncMsg))
				-- end
				-- if self.world.sSub(resultSub,17,17)=="1" then
				-- 	self:updateSyncMsg({bc={{zz=3,mid=106,i=self.itemID}}})
				-- 	self.world:D('jaylog add mid 106',self.world.cjson.encode(self.syncMsg))
				-- end
				-- if self.world.sSub(resultSub,18,18)=="1" then
				-- 	self:updateSyncMsg({bc={{zz=3,mid=108,i=self.itemID}}})
				-- 	self.world:D('jaylog add mid 108',self.world.cjson.encode(self.syncMsg))
				-- end

				-- 如有变量属性，会在最后getAllInfo一次
				if self.world.sSub(resultSub,1,1)=="1" then
					local resultInfo=self:getAllInfo(0,true)
					self:updateSyncMsg({i=resultInfo})
				end
				local response,rType
				if self.world.sSub(resultSub,31,31)=='{' then
					response = string.base64encode(self.world.sSub(resultSub,31))
					rType = 1
				else
					response = self.world.sSub(resultSub,31)
					rType = 2
				end
				-- if self.world.gameRoomSetting['ISYW']==1 and (self.world.playerList[self.itemID]['online']==nil or not self.world.playerList[self.itemID]['online']) then
				-- 	if self.world.sSub(resultSub,3,3)=="1" then
				-- 		-- local playerInfo=self.world:memcacheGet('aoePlayerTask'..self.world.tonumber(self.world.playerList[self.itemID]['p']))
				-- 		self.world:D('jaylog firstTaskData:',response)
				-- 		self.world:memcacheLocalSet('firstTaskData'..self.world.playerList[self.itemID]['p'],response)
				-- 	end
				-- end
				if self.world.gameRoomSetting['ISYW']==0 and (self.world.gameRoomInfo['worldSubMode']==1 or self.world.gameRoomInfo['worldSubMode']==2) and not self.firstAdd then
				else
					self:activeSyncMsg(response,rType)
					self.world:D('jaylog SHero:APICallJobCallBack syncMsg after:',self.world.cjson.encode(self.syncMsg))
					if self.world.sSub(resultSub,15,15)~="1" then
						self.startTipsCall = self.world:getGameTime()+self.world.gameRoomSetting['callTipsApiWaitTime']
					end
					if self.world.gameRoomSetting['ISYW']==1 then
						local badEquip = self.world:memcacheGet('badEquip'..self.world.playerList[self.itemID]['p'])
						if badEquip~=nil and badEquip==1 then
							self:updateSyncMsg({bc={{zz=3,mid=103,i=self.itemID}}})
							self.world:memcacheDel('badEquip'..self.world.playerList[self.itemID]['p'])
						end
						local addToTmpBag = self.world:memcacheGet('addToTmpBag'..self.world.playerList[self.itemID]['p'])
						if addToTmpBag~=nil and addToTmpBag==1 then
							self:updateSyncMsg({bc={{zz=3,mid=104,i=self.itemID}}})
							self.world:memcacheDel('addToTmpBag'..self.world.playerList[self.itemID]['p'])
						end
						local readyOutData = self.world:memcacheGet('readyOutData'..self.world.playerList[self.itemID]['p'])
						if readyOutData~=nil and readyOutData==1 then
							self:updateSyncMsg({bc={{zz=3,mid=105,i=self.itemID}}})
							self.world:memcacheDel('readyOutData'..self.world.playerList[self.itemID]['p'])
						end
						local isHaveTmpBag = self.world:memcacheGet('isHaveTmpBag'..self.world.playerList[self.itemID]['p'])
						if isHaveTmpBag~=nil and isHaveTmpBag==1 then
							self:updateSyncMsg({bc={{zz=3,mid=106,i=self.itemID}}})
							self.world:memcacheSet('isHaveTmpBag'..self.world.playerList[self.itemID]['p'],0)
						end
						local isNeedChangeStrong = self.world:memcacheGet('isNeedChangeStrong'..self.world.playerList[self.itemID]['p'])
						if isNeedChangeStrong~=nil and isNeedChangeStrong==1 then
							self.world:D('jaylog isNeedChangeStrong add bc:',isNeedChangeStrong,self.itemID,self.loginID,'isNeedChangeStrong'..self.world.playerList[self.itemID]['p'])
							self:updateSyncMsg({bc={{zz=3,mid=108,i=self.itemID}}})
							self.world:memcacheSet('isNeedChangeStrong'..self.world.playerList[self.itemID]['p'],0)
						end
					end
				end
			end
		end
	--end
end

--- 更新玩家自身attribute属性
-- @param null
-- @return null
function SHero:updateProperty()
	if self.world.gameRoomSetting['ISYW']==1 then
		local playerInfo=self.world:memcacheGet('aoePlayerData'..self.world.tonumber(self.world.playerList[self.itemID]['p']))
		self:D('jaylog updateProperty INFO:'..self.world.cjson.encode(playerInfo))
		local playerJson = self.world.cjson.decode(playerInfo)
		--self:D('jaylog updateProperty JSON:'..self.world.cjson.encode(playerJson))
		if ""..self.world.playerList[self.itemID]['id']~=""..playerJson['Player']['loginID'] then
			self.world:clearSyncInfoCache(self.itemID)
		end
		if self.world.tonumber(self.attribute.level)~=self.world.tonumber(playerJson['Player']['level']) then
			self.world:clearSyncInfoCache(self.itemID)
		end
		if self.world.tonumber(self.attribute.WINGID)~=self.world.tonumber(playerJson['Player']['WINGID']) then
			self.world:clearSyncInfoCache(self.itemID)
		end
		if self.world.tonumber(self.attribute.WINGSTAGE)~=self.world.tonumber(playerJson['Player']['WINGSTAGE']) then
			self.world:clearSyncInfoCache(self.itemID)
		end
		if self.world.tonumber(self.attribute.WEAPONID)~=self.world.tonumber(playerJson['Player']['WEAPONID']) then
			self.world:clearSyncInfoCache(self.itemID)
		end
		if self.world.tonumber(self.attribute.WINGHIDE)~=self.world.tonumber(playerJson['Player']['WINGHIDE']) then
			self.world:clearSyncInfoCache(self.itemID)
		end
		if self.world.tonumber(self.attribute.HORSEID)~=self.world.tonumber(playerJson['Player']['HORSEID']) then
			self.world:clearSyncInfoCache(self.itemID)
			self:removeSkillAttackMode7()
			if self.world.tonumber(self.attribute.HORSEID)==0 and self.world.tonumber(playerJson['Player']['HORSEID'])~=0 then
				self.horseNow = true
			end
		end
		local attr = playerJson['Player']
		if attr['HP']~=nil then
			attr['HP'] = self.attribute.HP
			-- self.world:D('jaylog updateProperty HP==0 ',self.world.cjson.encode(attr))
		end
		if attr['MP']~=nil then
			attr['MP'] = self.attribute.MP
			-- self.world:D('jaylog updateProperty MP==0 ',self.world.cjson.encode(attr))
		end
		if attr['skillOpen']~=nil then
			local idx = 1
			if attr['SKILLOPEN']==nil then
				attr['SKILLOPEN'] = {}
			end
			for i=8,1,-1 do
				attr['SKILLOPEN'][idx] = self.world.tonumber(self.world.sSub(playerJson['Player']['skillOpen'],i,i))
				idx = idx + 1
			end
		end
		self:D('jaylog updateProperty SKILLOPEN ',self.world.cjson.encode(attr))
		self.attribute:setBaseValue(attr)
		self:D('jaylog updateProperty SKILLOPEN ',self.world.cjson.encode(self.attribute.SKILLOPEN))
		self.world.playerList[self.itemID]['id'] = playerJson['Player']['loginID']
		self.world.playerList[self.itemID]['playerJson'] = self.world.tDeepcopy(playerJson)
		self.world:memcacheLocalSet('playerJson'..playerJson['Player']['playerID'],playerInfo)
		local sdata = self.world.cjson.decode(self.world:memcacheLocalGet('session_'..self.world.playerList[self.itemID]['s']))
		self.world:D('jaylog updateProperty sdata:',self.world.cjson.encode(sdata),self.world.playerList[self.itemID]['s'])
		sdata['loginID'] = playerJson['Player']['loginID']
		self.world:memcacheLocalSet('session_'..self.world.playerList[self.itemID]['s'],self.world.cjson.encode(sdata))
		self.loginID = playerJson['Player']['loginID']
		local skillOpen = self.world.tonumber(self.world.playerList[self.itemID]['playerJson']['Player']['skillOpen'])
		local aiOpen = self.world.tonumber(self.world.playerList[self.itemID]['playerJson']['Player']['aiOpen'])
		local dmOpen = self.world.tonumber(self.world.playerList[self.itemID]['playerJson']['Player']['dmOpen'])
		local extraOpen = dmOpen*10+aiOpen
		if self.statusList[88]==nil or self.statusList[88]['p1']~=skillOpen or self.statusList[88]['p3']~=extraOpen then
			-- 技能开启状态标识
			self:D('jaylog update status 88 ',self.world.cjson.encode(self.statusList[88]),skillOpen,extraOpen)
			if self.statusList[88]['p3']~=extraOpen then
				self:addStatusList({zz=3,s=88,r=self.gameTime,t=99999,p1=skillOpen,p2=8,p3=extraOpen,p4=1})
			else
				self:addStatusList({zz=3,s=88,r=self.gameTime,t=99999,p1=skillOpen,p2=8,p3=extraOpen})
			end
		end
		if self.world.playerList[self.itemID]['playerJson']['Player']['addStatus']~=nil then
			local statusnum = 0
			for ask,asv in pairs(self.world.playerList[self.itemID]['playerJson']['Player']['addStatus']) do
				statusnum = self.world.tonumber(asv)
				if self.statusList[statusnum]==nil then
					self:addStatusList({zz=3,s=statusnum,r=self.gameTime,t=99999})
					if statusnum==603 then
						local attributes = {}
						attributes['MSPD_DOWN_RATE'] = 100
						attributes['MSPD_DOWN'] = 50
						attributes['BUFFTIME'] = 99999
						local duration = 99999
						local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(1),attributes,duration,{},0,self.itemID,self.itemID)
						self:addBuff(buff)
					end
				end
			end
		end
		if self.world.playerList[self.itemID]['playerJson']['Player']['delStatus']~=nil then
			local statusnum = 0
			for ask,asv in pairs(self.world.playerList[self.itemID]['playerJson']['Player']['delStatus']) do
				statusnum = self.world.tonumber(asv)
				if self.statusList[statusnum]~=nil then
					self:removeStatusList(statusnum)
					if statusnum==603 then
						self:removeBUff('MSPD_DOWN')
					end
				end
			end
		end
	end
end

--- 更新玩家attribute技能属性
-- @param null
-- @return null
function SHero:updateSkillProperty()
	local playerInfo=self.world:memcacheGet('aoePlayerData'..self.world.tonumber(self.world.playerList[self.itemID]['p']))
	local playerJson = self.world.cjson.decode(playerInfo)
	self:D('jaylog updateSkillProperty JSON:'..self.world.cjson.encode(playerJson))
	local attr = playerJson['skillParam']
	self.attribute:setSkillBaseValue(attr)
end

--- 更新玩家魔灵技能属性
-- @param null
-- @return null
function SHero:updateDemonProperty()
	local playerInfo=self.world:memcacheGet('aoePlayerData'..self.world.tonumber(self.world.playerList[self.itemID]['p']))
	local playerJson = self.world.cjson.decode(playerInfo)
	self:D('jaylog updateDemon JSON:'..self.world.cjson.encode(playerJson))
	local attr = playerJson['skillDemon']
	self.attribute:setDemonBaseValue(attr)
end

--- 更新玩家圣灵属性
-- @param null
-- @return null
function SHero:updateEnergyProperty()
	local playerInfo=self.world:memcacheGet('aoePlayerData'..self.world.tonumber(self.world.playerList[self.itemID]['p']))
	local playerJson = self.world.cjson.decode(playerInfo)
	self:D('jaylog updateEnergy JSON:'..self.world.cjson.encode(playerJson))
	local attr = playerJson['energyData']
	self.attribute.energyBoard:reload(attr)
end

--- 更新玩家任务列表
-- @param null
-- @return null
function SHero:updateTask(task)
	local playerInfo=self.world:memcacheGet('aoePlayerTask'..self.world.tonumber(self.world.playerList[self.itemID]['p']))
	local taskJson = self.world.cjson.decode(playerInfo)
	self.world:D('jaylog updateTask JSON:',self.world.cjson.encode(taskJson),self.seqNo['task'],self.loginID)
	--if taskJson['seqNo']~=nil and self.world.tonumber(taskJson['seqNo'])>self.seqNo['task'] then
	if task==nil then
		self.taskObj.apiTaskList = taskJson['task']
		-- self.taskObj.updateTaskList = taskJson['upTaskInfo']
	else
		self.taskObj.taskList = task
		-- if task["1"]["1010"]~=nil or task["1"]["50001010"]~=nil then
		-- 	for k,v in pairs(task["1"]) do
		-- 		for k1,v1 in pairs(v) do
		-- 			if k1=='tasks' then
		-- 				for k2,v2 in pairs(v1) do
		-- 					self:moveTo(v2['X'],v2['Y'],true,1,99999)
		-- 				end
		-- 			end
		-- 		end
		-- 	end
		-- end
	end
	self.taskObj:refreshList()
	if self.taskUpdateAutoMoveID~=0 then
		self:setAutoMove(self.taskUpdateAutoMoveID)
		self.taskUpdateAutoMoveID = 0
	end
	--end
end

--- 保存任务列表
-- @param null
-- @return null
function SHero:saveTask()
	local data = self.world.cjson.encode({task=self.taskObj.taskList,seqNo=self.world.gameTime})
	self.world:memcacheSet('aoePlayerTask'..self.world.tonumber(self.world.playerList[self.itemID]['p']),data)
end

--- 执行重生
-- @param null
-- @return null
function SHero:updateRebirth(toX,toY)
	self.deadTime = self.world.gameTime
	if toX~=nil and toY~=nil then
		self.rebirthX = toX
		self.rebirthY = toY
	else
		self.rebirthX = self.posX
		self.rebirthY = self.posY
	end
	self:revive()
end

--- 执行免费重生
-- @param null
-- @return null
function SHero:updateRebirthFree()
	self.deadTime = self.world.gameTime
	self:revive()
end

--- 免费重生加BUFF
-- @param buffName string - buff的名字
-- @param buffValue int - buff的值
-- @return null
function SHero:addRebirthBuff(buffName,buffValue)
	if buffName==nil then return nil end
	if buffName=='MSPD' and buffValue==1 then
		local attributes = {}
		local hitValueNew = self:getPrepareHithitValue()
		attributes = hitValueNew
		attributes['BUFFONLY']=1
		attributes['MSPD_UP'] = 100
		attributes['buffType'] = 3
		attributes['BUFFTIME'] = 5
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0,99),attributes,5,{},0,self.itemID,self.itemID,0)
		self:addBuff(buff)
	end
	if buffName=='HP' and buffValue==1 then
		local attributes = {}
		local hitValueNew = self:getPrepareHithitValue()
		attributes = hitValueNew
		attributes['BUFFONLY']=1
		attributes['HP_UP'] = 30
		attributes['buffType'] = 3
		attributes['BUFFTIME'] = 99999
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0,99),attributes,99999,{},0,self.itemID,self.itemID,0)
		self:addBuff(buff)
	end
	if buffName=='ATK' and buffValue==1 then
		local attributes = {}
		local hitValueNew = self:getPrepareHithitValue()
		attributes = hitValueNew
		attributes['BUFFONLY']=1
		attributes['ATK_UP'] = 30
		attributes['buffType'] = 3
		attributes['BUFFTIME'] = 99999
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0,99),attributes,99999,{},0,self.itemID,self.itemID,0)
		self:addBuff(buff)
	end
	local buffNameList = self.world.sSplit(buffName,"_")
	if buffNameList[2]~=nil and buffNameList[2]~='' then
		local attributes = {}
		local hitValueNew = self:getPrepareHithitValue()
		attributes = hitValueNew
		attributes['BUFFONLY']=1
		attributes[buffName] = buffValue
		attributes['buffType'] = 3
		attributes['BUFFTIME'] = 99999
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(0,99),attributes,99999,{},0,self.itemID,self.itemID,0)
		self:addBuff(buff)
	end
end

--- 将responce数据发送给前端
-- @param response string - 传输的string
-- @param rType integer - 传输类型 0=json 1=base64encode 2=gzip
-- @param isReturn boolean - 是否只返回数据不sync
-- @return null
function SHero:activeSyncMsg(response,rType,isReturn)
	if response==nil or response=="" then return nil end
	if rType==nil then rType = 0 end
	if isReturn==nil then isReturn = false end
	local msg = {{zz=3,i=self.itemID,rtype=rType,rp=response}}
	self:D('jaylog SHero:activeSyncMsg sync apimsg '..self.world.cjson.encode(msg)..' loginID:'..self.world.playerList[self.itemID]['id'])
	-- self.world:addSyncMsg({apimsg=msg})
	local amsg = {apimsg=msg}
	if isReturn then
		return amsg
	else
		self:updateSyncMsg(amsg)
	end
end

--- 注销对象
-- @param null
-- @return null
function SHero:release()
	self:D('jaylog SHero:release ',self.itemID,' lid:',self.loginID)
	self.world.playerList[self.itemID] = nil
	SHero.super.release(self)
end

--- 将task数据发送给前端
-- @param null
-- @return null
function SHero:activeTaskSyncMsg(taskTable,isReturn)
	local response = {errcode=0,mes='',data={}}--task=self.taskObj.taskList
	if taskTable==nil then
		taskTable = {}
	end
	if isReturn==nil then
		isReturn = false
	end
	for k,v in pairs(taskTable) do
		response["data"][k]=v
	end
	-- if empty(taskTable) and self.syncMsg['apimsg']~=nil then
	-- 	self.world:D('jaylog activeTaskSyncMsg before syncMsg:',self.world.cjson.encode(self.syncMsg))
	-- 	local data = {}
	-- 	for k,v in pairs(self.syncMsg['apimsg']) do
	-- 		if self.world.sSub(v['rp'],1,1)=='{' then
	-- 			data = self.world.cjson.decode(v['rp'])
	-- 			if data['data']['task']~=nil then
	-- 				for k1,v1 in pairs(data['data']['task']) do
	-- 					for k2,v2 in pairs(v1) do
	-- 						if self.taskObj.taskList[k1][k2]~=nil and self.taskObj.taskList[k1][k2]['tasks']['progress']>v2['tasks']['progress'] then
	-- 							data['data']['task']
	-- 						end
	-- 					end
	-- 				end
	-- 			end
	-- 		end
	-- 	end
	-- 	self.world:D('jaylog activeTaskSyncMsg after syncMsg:',self.world.cjson.encode(self.syncMsg))
	-- end
	-- if tasktype=="taskGift" and  tasktable~=nil then
	-- 	response["data"]["taskGift"]=tasktable
	-- end
	-- if tasktype=="rGet" and  tasktable~=nil then
	-- 	response["data"]["rGet"]=tasktable
	-- end
	local response = string.base64encode(self.world.cjson.encode(response))
	local ret = self:activeSyncMsg(response,1,isReturn)
	return ret
end

--- 将task数据发送给前端
-- @param null
-- @return null 
function SHero:activeTaskUpdateSyncMsg(taskID)
	-- local response = {errcode=0,mes='',data={task=self.taskObj.taskList}}
	self:D("feng task itemID 作一个数据给前端结算:",self.itemID,self.world.cjson.encode(self.taskObj.taskList[taskID]))

	--self:updateSyncMsg({task=self.taskObj.taskList[taskID]})
end



--- 领取task奖励时组织数据发送前端
-- @param taskID int - 任务ID
-- @return null
function SHero:activeTaskRewardSyncMsg(taskID)
	local response = {taskGift=taskID}
	local msg = {}
	msg[#msg+1] = {
		zz=3,
		i=self.itemID,
		rtype=1,
		rp=self.world.cjson.encode(response),
	}
	self:D('jaylog SHero:activeTaskRewardSyncMsg sync apimsg '..self.world.cjson.encode(msg))
	-- self.world:addSyncMsg({apimsg=msg})
	self:updateSyncMsg({apimsg=msg})
end

--- 设置task的自动寻路路线
-- @param taskID string - 任务ID
-- @return null
function SHero:getTaskPath(taskID)
	self:D('jaylog getTaskPath taskList:'..self.world.cjson.encode(self.taskObj.taskList))
	local taskData = nil
	local ret = false
	local redirectNow = false
	local redirectX,redirectY
	for k,v in pairs(self.taskObj.taskList) do
		--self:--debuglog('jaylog getTaskPath1 ',k,self.world.cjson.encode(v))
		for k1,v1 in pairs(v) do
			--self:--debuglog('jaylog getTaskPath2 ',k1,self.world.cjson.encode(v1),taskID)
			if self.world.tonumber(v1['taskID'])==self.world.tonumber(taskID) then
				taskData = v1
				--self:--debuglog('jaylog getTaskPath taskData search:'..self.world.cjson.encode(taskData))
			end
		end
	end
	if taskData~=nil then
		self:D('jaylog getTaskPath taskData:'..self.world.cjson.encode(taskData))
		local taskCond = taskData['tasks']
		local ok = false
		local toX,toY = self.posX,self.posY
		for k,v in pairs(taskCond) do
			if not ok and v['finish']==0 then
				toX = v['X']
				toY = v['Y']
				ok = true
			end
			if self.world.sFind(k,'enemy')~=nil then
				self.world:D('jaylog autoMoveStartAI true')
				self.autoMoveStartAI = true
			else
				self.world:D('jaylog autoMoveStartAI false')
				self.autoMoveStartAI = false
			end
		end
		if taskData['extra']['COLLECTTIME']~=nil then
			self:D('jaylog autoMoveStartCollect true')
			self.autoMoveStartCollect = true
		else
			self:D('jaylog autoMoveStartCollect false')
			self.autoMoveStartCollect = false
		end
		if taskData['redirectMap']~=nil and (self.world.tonumber(taskData['redirectMap'])==1 or self.world.tonumber(taskData['redirectMap'])==2) and self.world.tonumber(self.world.mapModel)~=self.world.tonumber(taskData['mapID']) then
			redirectNow = true
			if self.world.tonumber(taskData['redirectMap'])==2 then
				redirectX,redirectY = toX,toY
			end
		end
		self.world.transfer:getMapPathDetail(self.world.playerList[self.itemID]['m'],taskData['mapID'],self.posX,self.posY,toX,toY,self.itemID)
		if toX~=0 and toY~=0 then
			ret = true
		end
	end
	self:D('jaylog SHero:getTaskPath ret ',ret)
	return ret,redirectNow,redirectX,redirectY
end

--- call api接口
-- @param data string - 传给API的data数据
-- @param ctrl string - call API接口的controller
-- @param act string  - call API接口的action
-- @return null
function SHero:addApiCall(data,ctrl,act)
	if self:isAIObj() then return nil end
	if self.world.gameRoomSetting['ISYW']==1 and (act=='getTaskGift' or act=='changeName') then
		self:setAutoMove()
		data['info'] = {mapModel=self.world.mapModel,mapPort=self.world.gamePort,HP=self.attribute.HP,MP=self.attribute.MP,X=self.posX,Y=self.posY}
	end
	data['seqNo'] = self.seqNo['all']+1
	local requestData = {
		ctrl=ctrl,
		act=act,
		session=self.world.playerList[self.itemID]['s'],
		pid=self.world.playerList[self.itemID]['p'],
		lAccount=self.world.playerList[self.itemID]['playerJson']['Player']['lAccount'],
		data=data
	}
	self:D('jaylog SHero:addApiCall addAPICallJob: requestData->',self.world.cjson.encode(requestData),' seqNo:',self.world.cjson.encode(self.seqNo),' itemID:',self.itemID,' x:',self.posX,' y:',self.posY,' lid:',self.loginID,' gt:',self.world:getGameTime())
	--self:addAPICallJob('callapiloop',self.world.cjson.encode(requestData),true)
	self:addAPICallJob('callapiloop',requestData,true)
	self.seqNo['all'] = self.seqNo['all']+1
end

--- 更新玩家信息
-- @param isLogout boolean - 是否退出
-- @return null
function SHero:updateInfo(isLogout,task,counter)
	local data = {}
	--data = {mapModel=self.world.mapModel,mapPort=self.world.gamePort,HP=self.attribute.HP,MP=self.attribute.MP,X=self.posX,Y=self.posY}
	data['info'] = {mapModel=self.world.mapModel,mapPort=self.world.gamePort,HP=self.attribute.HP,MP=self.attribute.MP,X=self.posX,Y=self.posY}
	if isLogout==nil then
		isLogout = false
	end
	if isLogout then
		data['info']['lastOffLineTime'] = 1
	end
	if task~=nil then
		data['task'] = self.taskObj.taskList
	end
	if self.world.mapModel~=self.world.setting.newPlayerGVB then
		if ''..self.attribute.roleId=='4' or ''..self.attribute.roleId=='9' then
			data['info']['skillStatus'] = self:getMode2ATKMode()
		end
	end
	if counter~=nil then
		data['counter'] = self.counterObj:getCacheCounter()
	end
	local ctrl = 'player'
	local act = 'updateInfo'
	self:addApiCall(data,ctrl,act)
end

--- 更新装备耐久度
-- @param null
-- @return null
function SHero:updateEquipLose()
	if self.equipCounter:existCounter() then
		local data = {}
		for k,v in pairs(self.equipCounter.counter) do
			data[k] = v
			self.equipCounter.counter[k] = 0
		end
		local ctrl = 'bag'
		local act = 'useLosses'
		self:addApiCall(data,ctrl,act)
	end
end

--- call api获取全部task信息
-- @param null
-- @return null
function SHero:addApiJobGetTask()
	self:addApiCall({},'task','getTaskAll')
end

--- call api更新task信息到API
-- @param null
-- @return null
function SHero:addApiJobUpdateTask()
	local data = self:getTaskData()
	self:addApiCall(data,'task','updateTaskEvent')
end

--- 获取task返回数据格式
-- @param null
-- @return data table - task data
function SHero:getTaskData()
	return {task=self.taskObj.taskList}
end

--- call api获取任务奖励
-- @param taskID int - 任务ID
-- @return null
-- function SHero:addApiJobGetGift(taskID)
-- 	local data = {taskID=taskID}
-- 	self:addApiCall(data,'task','getTaskGift')
-- end

-- call api获取全部counter信息
function SHero:addApiJobGetCounter()
	self:addApiCall({},'default','getCounter')
end

-- update counter
function SHero:addApiJobUpdateCounter()
	local data = self:getObjCounter()
	self:addApiCall(data,'player','addCounter')
end

--- 获取角色的counter对象数据
-- @param null
-- @return data table - counter data
function SHero:getObjCounter()
	return {counter=self.counterObj:getCacheCounter()}
end

-- function SHero:addApiJobGetProperty()
-- 	local requestData = {
-- 		ctrl='player',
-- 		act='lampLevelUp',
-- 		session=self.world.playerList[self.itemID]['s'],
-- 		pid=self.world.playerList[self.itemID]['p'],
-- 		data={seqNo=self.world.gameTime,lampType=1,mapModel=self.world.mapModel}
-- 	}
-- 	self:D('jaylog SHero:getApiTaskAll addApiJobGetProperty: requestData->'..self.world.cjson.encode(requestData)..' itemID:'..self.itemID)
-- 	self:addAPICallJob('callapi',self.world.cjson.encode(requestData))
-- end

-- function SHero:addApiJobGetSkill()
-- 	local requestData = {
-- 		ctrl='skill',
-- 		act='upLevel',
-- 		session=self.world.playerList[self.itemID]['s'],
-- 		pid=self.world.playerList[self.itemID]['p'],
-- 		data={seqNo=self.world.gameTime,skillRank=2,rank=2}
-- 	}
-- 	self:D('jaylog SHero:getApiTaskAll addApiJobGetSkill: requestData->'..self.world.cjson.encode(requestData)..' itemID:'..self.itemID)
-- 	self:addAPICallJob('callapi',self.world.cjson.encode(requestData))
-- end

--- 设置自动导航
-- @param itemID int - 目标ID，itemID>0开启跟随，不填或0取消跟随
-- @return null
function SHero:setAutoMove(taskID)
	if taskID==nil then
		taskID = 0
	end
	if taskID>0 then
		self:setAuto(false)
		local ret,redirectNow,redirectX,redirectY = self:getTaskPath(taskID)
		local toMap,toRoomID
		if ret then
			self.autoMove = true
			self:addStatusList({zz=3,s=996,r=self.world.gameTime,t=9999})
			if redirectNow then
				self:executeAPICall(true)
				if self.redirectRoomTime<self.world.gameTime then
					self.redirectRoomTime = self.world.gameTime + 5
					if self.world.gameRoomSetting['ISYW']==1 then
						self:updateEquipLose()
					end
					for k,v in pairs(self.movePath) do
						if v['isLast']~=nil and v['isLast']==1 then
							toMap = self.world.tonumber(k)
							toRoomID = self.world.tonumber(self.world.gameRoomInfoAll[toMap]['port'])
						end
					end
					self.world:redirectRoom(self.itemID,toMap,toRoomID,nil,redirectX,redirectY)
				end
			end
		end
	else
		--self:setAuto(false)
		--self:D('jaylog SHero:setAutoMove stop ',self.itemID,self.loginID)
		self.autoMove = false
		self:removeStatusList(996)
		self.autoMoveStartAI = false
		self.autoMoveStartCollect = false
	end
end


--- 设置暫停AI
-- @return null
function SHero:suspendAI()
	if self.AImode>0 then
		self.autoBlocked = true
	end
end


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SHero:prepareHit(mode,adjTime,buff)
	local hitValueBoth=SHero.super.prepareHit(self,mode,adjTime,buff)
	self:callCreature(hitValueBoth)
	if self.attribute.skills[mode]~=nil and self.attribute.skills[mode].demonObj~=nil then
		self.attribute.skills[mode].demonObj:prepareHit(mode,adjTime,buff,hitValueBoth)
	end
	if self.attribute.skills[mode-100]~=nil and self.attribute.skills[mode-100].demonObj~=nil then
		self.attribute.skills[mode-100].demonObj:prepareHit(mode,adjTime,buff,hitValueBoth)
	end

	return hitValueBoth 
end 

--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SHero:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	if self.attribute.skills[mode]~=nil and self.attribute.skills[mode].demonObj~=nil then
		self.attribute.skills[mode].demonObj:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt)
	end
	local hurt = SHero.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
end



--英雄的自动攻击..........
function SHero:_autoFight() 
	local ret=SHero.super._autoFight(self)
	self:D("heroAI 进来没"..self.itemID,ret,autoBlocked,self.AIlastMoveTime,self.world:getGameTime(),self.AIlastATKTime,self.lastCoolDownTime)
	if not ret and self.statusList[4007]==nil and self.statusList[73]==nil and not self.autoBlocked and self.AIlastMoveTime<self.world:getGameTime() and self.AIlastATKTime<self.world:getGameTime() and self.lastCoolDownTime<self.world:getGameTime() and  not self:isDead() then
		self:D("heroAI 进来没"..self.itemID, "    3")
		self:_autoFightToHero()
	end
	return ret
end

--自动攻击用来重载
function SHero:_autoFightToHero()
	--需要获得自动攻击的item  释放skill的id
	local targetID,skillID,cdTime = self:_autoFightSkillToHero()
	--self:D("feng heroAI1: targetID: _autoFightToHero:",targetID," skillID:",skillID,"itemID:",self.itemID)
	if targetID>0 then
		self:clearSkillAttack()
		self.islastATK = false
		ret = self:skillAttack(skillID,targetID)
		self:D("feng heroAI: targetID: _autoFightToHero:",targetID," skillID:",skillID,"itemID:",self.itemID,self.world.cjson.encode(ret))
		if not self.islastATK  then
			self.AIlastATKTime = self.world:getGameTime()+cdTime
			self.AIlastMoveTime = self.world:getGameTime() + 0.1
		end
		if self.isSmallAI~=nil and self.isSmallAI then
			self.AIlastATKTime = self.world:getGameTime()+2
		end
		--防止放完技能立刻回头不好的体验
		----debuglog("SHero:_autoFight lastCoolDownTime:"..self.lastCoolDownTime.." gameTime:"..self.world.gameTime.." ret:"..self.world.cjson.encode(ret).."第几下:"..self.mode1order)
	end
	return skillID
end

--用来重载SKill传入参数
function SHero:_autoFightSkillToHero()
	local targetID,skillID,cdTime
	if self.onlySimpleAttack~=nil and self.onlySimpleAttack then
		targetID,skillID,cdTime=self.autoFightAI:autoFightToHero({})
	else
		targetID,skillID,cdTime=self.autoFightAI:autoFightToHero()
	end
	return targetID,skillID,cdTime
end

--- 自动移动
-- @return null
function SHero:_autoMove()
	-- --debuglog("SHero:_autoMove")
	local ret=SHero.super._autoMove(self)

	local moveRet=self.autoFightAI:autoMoveToAlerted()
	if not ret and not self.autoBlocked and self.AIlastMoveTime < self.world:getGameTime() and  not self:isDead() and not moveRet and self.statusList[4007]==nil then
		
		local hprate = self.attribute.HP/self.attribute.MaxHP
		
		--用来判断切状态
		-- local maxHprate = 1
		-- local minHprate = 0.2
		-- --debuglog("AIRoleSetting:"..self.world.cjson.encode(self.attribute.AIRoleSetting))
		-- local AImaxHprate = self.attribute.AIRoleSetting['switchAtkModeA']*0.01
		-- local AIminHprate = self.attribute.AIRoleSetting['switchAtkModeB']*0.01

		if  self.world.tonumber(self.world.mapModel)~=2 then
			self.AIminHprate = 0
		end

		if hprate>self.gxAIlist.AIminHprate and hprate<self.gxAIlist.AImaxHprate then
			self.autoFightAI:autoMoveToHero()
		else
			if hprate>=self.gxAIlist.AImaxHprate then
				self.autoFightAI:autoMoveToATKHero(1)
			else
				self.autoFightAI:autoMoveToATKHero(2)
			end	
		end
		
		--self:D("heroAI set AIlastMoveTime:",self.moveToEndTime,self.itemID)
		if (self.moveToEndTime-self.world:getGameTime())<2 then
			self.AIlastMoveTime = self.moveToEndTime
		else
			self.AIlastMoveTime = self.world:getGameTime()+2
		end
	end

	return ret
end

---暂停玩家AI auto暂停或者启动AI  delay暂停多久
-- @return null
function SHero:setAutoBlocked(auto,delay)
	if auto==nil then auto = false end
	if delay==nil then delay = 9999 end
	self:D("setAutoBlocked auto:",(auto and "true" or "false"),delay," itemID:"..self.itemID)
	if auto then
		self.stopAITime = 0
	else
		self.stopAITime = self.world:getGameTime()+delay
	end
end



---设玩家自动AI
-- @return null
function SHero:setAuto(auto)
	if auto==nil then auto = false end

	self:D("setAuto auto:",(auto and "true" or "false")," itemID:"..self.itemID)
	if auto then
		self.AImode=1
		self.autoBlocked = false
	else
		self.AImode=0
		self.autoBlocked = true
	end
	-- self.world:addSyncMsg({automsg=self.AImode+1})
	self:updateSyncMsg({automsg={{auto=self.AImode+1,i=self.itemID,zz=3}}})
end

---设玩家任务自动AI
-- @return null
function SHero:setTaskAuto(auto)
	if auto==nil then auto = false end

	self:D("setTaskAuto auto:",(auto and "true" or "false")," itemID:"..self.itemID)
	if auto then
		self.AImode=1
		self.autoBlocked = false
		self.isTaskAuto=true
	end

	if not auto and self.isTaskAuto then
		self.AImode=0
		self.autoBlocked = true
		self.isTaskAuto = false
	end
	-- self.world:addSyncMsg({automsg=self.AImode+1})
	--self:updateSyncMsg({automsg={{auto=self.AImode+1,i=self.itemID,zz=3}}})
end

function SHero:goToGameRoom(queue)
	--debuglog('jaylog SHero:goToGameRoom key:'..'tcphold'..self.world.playerList[self.itemID]['p'])
	self:updateInfo()
	self:executeAPICall(true)
	local dataTmp = self.world:memcacheLocalGet('tcphold'..self.world.playerList[self.itemID]['p'])
	local data = self.world.cjson.decode(dataTmp)
	--debuglog('jaylog SHero:goToGameRoom data:'..self.world.cjson.encode(data)..' i:'..self.itemID..' plist:'..self.world.cjson.encode(self.world.playerList[self.itemID]))
	local port=1330+((self.world.tonumber(self.world.playerList[self.itemID]['p'])%5)*2);
	-- if self.world.gameRoomSetting['ISUAT']==1 then
	-- 	port = port + 3000
	-- end
	port = port + self.world.tonumber(self.world.Config.tcpPortAdd)
	local result = {i={i=self.itemID,host=data['sip'],roomid=self.world.tonumber(data['p']),port=port,pid=self.world.playerList[self.itemID]['p'],mapid=data['m']}}
	--debuglog('jaylog SHero:goToGameRoom '..self.world.cjson.encode(result))
	self:updateSyncMsg(result)
	self.world.playerList[self.itemID]['online'] = false
	self.world.playerList[self.itemID]['offLineTime'] = self.world.gameTime-self.world.gameRoomSetting.offlineRemoveWaitTime
end

--- 跳房時, 需要轉移gameRoom數值, 這裡是讀取 
-- @param isWF boolean - 是否无缝跳房
-- @return data table , 讀取當前的gameRoom 需要轉移的數據 
function SHero:getChangeRoomCacheData(ISWF)
	local result = SHero.super.getChangeRoomCacheData(self)
	if not ISWF then
		result['HP'] = self.attribute.HP
		result['MP'] = self.attribute.MP
		result['SP'] = self.SP
		-- 牧师正邪印设置带过跳图
		-- self.world:D('jaylog SHero:getChangeRoomCacheData newPlayerGVB',self.world.setting.newPlayerGVB,self.world.mapModel)
		if self.world.tonumber(self.world.mapModel)~=self.world.tonumber(self.world.setting.newPlayerGVB) then
			if ''..self.attribute.roleId=='4' or ''..self.attribute.roleId=='9' then
				result['skillStatus'] = self:getMode2ATKMode()
			end
		end
		result['equipCounter'] = self.equipCounter:getAllCounter()
		result['taskList'] = self.taskObj.taskList
		result['counterList'] = self.counterObj:getAllCounter()
		self:D('jaylog SHero:getChangeRoomCacheData ',ISWF,self.world.cjson.encode(result))
	end
	return result
end

--- 跳房時, 需要轉移gameRoom數值, 這裡是讀取 
-- @return data table , 讀取當前的gameRoom 需要轉移的數據 
function SHero:setChangeRoomCacheData(data)
	local result = SHero.super.setChangeRoomCacheData(self,data)
	self:D('jaylog SHero:setChangeRoomCacheData ',self.firstAdd,self.loginID,self.world.cjson.encode(data))
	-- if self.loginID=='jaysd42' or self.loginID=='浪漫的尤洛霆' then
		if data['equipCounter']~=nil then
			self:D('jaylog equipCounter before:',self.world.cjson.encode(self.equipCounter:getAllCounter()))
			self.equipCounter:refreshList(data['equipCounter'])
			self:D('jaylog equipCounter after:',self.world.cjson.encode(self.equipCounter:getAllCounter()))
		end
		if data['taskList']~=nil then
			self:D('jaylog taskList before:',self.world.cjson.encode(self.taskObj.taskList))
			self.taskObj.apiTaskList = self.world.tDeepcopy(data['taskList'])
			self.taskObj.taskList = self.world.tDeepcopy(data['taskList'])
			self.taskObj:refreshList()
			self.firstAdd = false
			self:D('jaylog taskList after:',self.world.cjson.encode(self.taskObj.taskList))
		end
		if data['counterList']~=nil then
			self:D('jaylog counterList before:',self.world.cjson.encode(self.counterObj:getAllCounter()))
			self.counterObj:setOldCounter(data['counterList'])
			self:D('jaylog counterList after:',self.world.cjson.encode(self.counterObj:getAllCounter()))
		end
		if data['HP']~=nil then
			self.attribute.HP = data['HP']
		end
		if data['MP']~=nil then
			self.attribute.MP = data['MP']
		end
		if data['SP']~=nil then
			self.SP = data['SP']
			self:adjSP(0)
		end
		-- 设置牧师正邪印
		if ''..self.attribute.roleId=='4' or ''..self.attribute.roleId=='9' then
			if data['skillStatus']~=nil then
				self:setMode2ATKMode(data['skillStatus'])
			end
		end
	-- end
	return result
end

--- 是否AI
-- @param null
-- @return result boolean - true或false
function SHero:isAIObj()
	local result = false
	if self.isAI or self.parent~=nil then
		result = true
	end
	return result
end

--- 更新玩家重生所需扣除钻石数
-- @param null
-- @return null
function SHero:updateRebirthStatus()
	local sdata = {s=77,r=self.world:getGameTime(),t=999999,i=self.itemID}
	local reviveCost = self.world.sSplitNumber(self.world.setting['GVBreviveCostNum'],',')
	local reviveCostType = self.world.tonumber(self.world.setting['GVBreviveCostType'])
	self:D('jaylog SHero:updateRebirthStatus ',self.attribute.rebirth,self.world.cjson.encode(reviveCost))
	if reviveCost[self.attribute.rebirth]==nil then
		sdata['p1'] = reviveCost[#reviveCost]
	else
		sdata['p1'] = reviveCost[self.attribute.rebirth]
	end
	sdata['p2'] = reviveCostType
	local reviveTeamCost = self.world.sSplitNumber(self.world.setting['GVBTeamreviveCostNum'],',')
	local reviveTeamCostType = self.world.tonumber(self.world.setting['GVBTeamreviveCostType'])
	self:D('jaylog SHero:updateTeamRebirthStatus ',self.attribute.rebirth,self.world.cjson.encode(reviveCost))
	if reviveTeamCost[self.attribute.rebirthTeam]==nil then
		sdata['p3'] = reviveTeamCost[#reviveTeamCost]
	else
		sdata['p3'] = reviveTeamCost[self.attribute.rebirthTeam]
	end
	sdata['p4'] = reviveTeamCostType
	self:removeStatusList(77)
	self:addStatusList(sdata)
end


function SHero:adjSP(sp)

end

return SHero
