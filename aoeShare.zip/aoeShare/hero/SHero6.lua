local SHero6 = class("SHero6", require("gameroom.hero.SHero")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @param actorID int - 游戏房玩家序号ID
-- @return null
function SHero6:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SHero6" 
	end 

	--愤怒值
	self.SP = 0
	--愤怒最大值
	self.maxSP = 9
	--旋风斩消耗5愤怒值进行特殊攻击 对出血敌人造成吸血伤害
	self.hurtDrainLifeMode = 0
	--大招消耗5愤怒点 让目标流血
	self.addFIXHURTMode = 0
	--停止恢复愤怒值时间
	self.nextStopAddSPTime = 0
	--下次恢复愤怒值时间
	self.nextAddSPTime = 0
	--一次恢复多少愤怒值
	self.addSPNum = 0


	self.mode4time = 0
	self.mode4atkTime = 0
	self.mode4atkNum = 1
	self.mode4start = false
	self.mode4idx = 0
	self.mode4num = 0
	self.mode4autoReset = true

	self.mode3bulletid = 0	--3号技能子弹ID
	self.mode3x = 0					--3号技能施放坐标X
	self.mode3y = 0					--3号技能施放坐标Y

	--需要4变5
	-- self.mode5time = 0
	self.mode5in1time = 0
	self.mode5adjsp = 0


	self.mode2time = 0
	self.mode2x = 0--记录2号技能的落点
	self.mode2y = 0
	self.modeold2x = 0 --记录2号发技能的起点
	self.modeold2y = 0 --记录2号发技能的起点

	self.mode1bool = false

	--AI释放大招开始SP类型
	self.mode4AItype = 0
	--下次切换AI行为时间
	self.mode4AINextTime = 0
	--当前已经释放AI技能的次数
	self.mode4AINum = 0
	--下次释放冲锋时间
	self.mode2AINextTime = 0
	--3号特效击中次数
	self.mode3AtkNum = 0

	self:D("新的狂战士初始化.。。。。。。。。。。。。。。。")
	SHero6.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self:D('jaylog SHero6:ctor after super')
end 


--重载AI
function SHero6:_autoFightToHero()

	--需要判断队友是否没血了
	--获得队友列表
	  	--阿文用来替换ai攻击
	if self.world.heroNeedSkillID~=nil and self.world.heroNeedSkillID>0 then
	 
		ret = true
	else
		ret = false
		if (self.teamOrig=="A") then
			teamlist=self.world.itemListFilter.heroTeamAList
		else
			teamlist=self.world.itemListFilter.heroTeamBList
		end

		local skill2 = self.attribute.skills[2]  
		local skill5 = self.attribute.skills[5]
		local skill4 = self.attribute.skills[4]    
		
		--原地扫描附近队友
		if (self.attribute.SKILLOPEN[2]==nil or self.attribute.SKILLOPEN[2]==1)  and skill2.lastCoolDownTime<self.world:getGameTime() and self.world.gameRoomSetting.ISGVB==1 then
			--需要救援的列表
			local targetList = {}
			local visRange={posX=self.posX,posY=self.posY,radius=skill2.atkDis/self.world.setting.AdjustVisRange}

			for k,value in pairs(teamlist) do
				ok = true
				if (not value:isDead()) then ok =false end
				if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
				if ok and (value.attribute.HP/value.attribute.MaxHP)<0.8 then
					local d = value:colliding(visRange,0,0,self.itemID)
					--判断他最近被击中过
					if d>=0 and self.lastAttackTime+2>self.world:getGameTime() then
						targetList[#targetList+1] ={itemID=value.itemID,hprate=value.attribute.HP/value.attribute.MaxHP} 
					end
				end
			end
			--赛选出最优的几个队友
			--self:D(" skill3 AI targetList:"..self.world.cjson.encode(targetList))
			if #targetList>0 then

				self.world.tSort(targetList,function( a1,b1 )
								return a1['hprate'] < b1['hprate']
							end)

				local protectionID = targetList[1]['itemID']
				local obj = self.world.allItemList[protectionID] 
				--击中最近攻击队友的目标
				ret = self:skillAttack(2,obj.lastAttackID)
			end
		end

		if (self.attribute.SKILLOPEN[5]==nil or self.attribute.SKILLOPEN[5]==1)  and skill5.lastCoolDownTime<self.world:getGameTime() then

			
			local targetList = {}
			local visRange={posX=self.posX,posY=self.posY,radius=1000/self.world.setting.AdjustVisRange}

			local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
			function(value)
			 	ok = true
				if (value:isDead()) then ok =false end
				if (value.attribute.HP<=0) then ok =false end
				if (value.attribute.actorType~=0) then ok =false end
				if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
				if ok  then
					local d = value:colliding(visRange,0,0,self.itemID)
					if d>=0 then
						targetList[#targetList+1] = {id=value.itemID}
					end
				end
			end
			)

			local hprate=self.attribute.HP/self.attribute.MaxHP
			if hprate>0.4 and #targetList>0 then
				ret = self:skillAttack(5,self.itemID)
			end
		end

		--刷新AI4行为
		if self.world:getGameTime()>self.mode4AINextTime or (self.mode4AItype>0 and self.mode4AINum==self.mode4AItype) then
			self.mode4AItype = self.world.formula:getRandnum(0,3)
			self.mode4AINextTime = self.world:getGameTime() + 60
			self.mode4AINum = 0
		end

		self:D("狂战士AI套路 参数:",self.mode4AItype,self.mode4AINum,self.SP,self.mode4AINextTime)

		if (self.attribute.SKILLOPEN[4]==nil or self.attribute.SKILLOPEN[4]==1)  and skill4.lastCoolDownTime<self.world:getGameTime()  and (self.mode4AItype>0 and self.mode4AINum>0 and self.mode4AINum<self.mode4AItype) or (self.mode4AINum==0  and ((self.mode4AItype==1 and self.SP>=30) or (self.mode4AItype==2 and self.SP>=60) or (self.mode4AItype==3 and self.SP>=90)))  then
			local targetList = {}
			local visRange={posX=self.posX,posY=self.posY,radius=1000/self.world.setting.AdjustVisRange}
			local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
			function(value)
			 	ok = true
				if (value:isDead()) then ok =false end
				if (value.attribute.HP<=0) then ok =false end
				if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
				if ok  then
					local d = value:colliding(visRange,0,0,self.itemID)
					if d>=0 then
						local zs = 0
						if value.attribute.HP<value.attribute.MaxHP*self.attribute.parameterArr['BEHEADEDHP']*0.01 then
							zs = 1
						end
						targetList[#targetList+1] = {d=d,id=value.itemID,zs=zs}
					end
				end
			end
			)
			self:D("狂战士AI套路 可选目标 targetList:",self.world.cjson.encode(targetList))
			if #targetList>0 then
				self.world.tSort(targetList,function( a1,b1 )
									return a1['zs'] < b1['zs']
								end)
				self.world.tSort(targetList,function( a1,b1 )
										return a1['d'] < b1['d']
									end)
				ret = self:skillAttack(4,targetList[1]['id'])
				self.mode4AINum = self.mode4AINum + 1
			end
		end

		if self.mode4AItype==0 then
			ret = false
		end

	end
	

	if not ret then
		local retSkillID=SHero6.super._autoFightToHero(self) 
		if retSkillID==3 then
			self.AIlastATKTime = self.world.gameTime
		end
	end
end


function SHero6:_autoFightSkillToHero()
	local targetID,skillID,cdTime
	local heroSkillList = self.attribute.AIRoleSetting['normalSkillList']
	local newSkillList = {}
	--重载掉狂战士的大招
	if self.mode4AItype~=0 then
		for k,v in pairs(heroSkillList) do
			if v~=4 then
				newSkillList[#newSkillList+1]=v
			end
		end
	else
		newSkillList = heroSkillList
	end
	if self.onlySimpleAttack~=nil and self.onlySimpleAttack then
		targetID,skillID,cdTime=self.autoFightAI:autoFightToHero({})
	else
		targetID,skillID,cdTime=self.autoFightAI:autoFightToHero(newSkillList)
	end
	return targetID,skillID,cdTime
end

--- init funtion 初始化属性参数
-- @param id int - role id
-- @param posX int - 起始坐标X
-- @param posY int - 起始坐标Y
-- @return null
function SHero6:__init(id,posX,posY)
	SHero6.super.__init(self,id,posX,posY) 
	self.maxSP=self.attribute.parameterArr.MAXSP
	--debuglog("狂战士最大值:",self.maxSP)
	self:addStatusList({zz=3,s=69,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.maxSP},0.5)
	self:addStatusList({zz=3,s=70,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.SP,p3=1},0.5)
	-- if self.world.tonumber(self.world.mapModel)==9005 then
	-- 	self:adjSP(self.maxSP)
	-- end
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SHero6:prepareHit(mode,adjTime,buff)  


	
	local hitValueBoth=SHero6.super.prepareHit(self,mode,adjTime,buff) 

	if (mode==3) then
		-- local skill = self.attribute.skills[3] 
		-- local parameters = skill.parameters 

		-- local attributes = {}
		-- attributes['CRI_UPFIX_RATE'] = parameters.CRI_UPFIX_RATE2
		-- attributes['CRI_UPFIX'] = parameters.CRI_UPFIX2
		-- attributes['BUFFTIME'] = parameters.BUFFTIME2
		-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,parameters.BUFFTIME2,{},0,self.itemID,self.itemID,0)
		-- self:addBuff(buff)
		-- self.hurtDrainLifeMode=1
		
		--天赋 减伤 
		-- if parameters.BEALLHURT_DOWN2~=nil then 
		-- 	local hitValueNew={}
		-- 	hitValueNew['BEALLHURT_DOWN']=parameters.BEALLHURT_DOWN2 
		-- 	hitValueNew["BEALLHURT_DOWN_RATE"]=parameters.BEALLHURT_DOWN_RATE2
		-- 	hitValueNew["BUFFTIME"]=parameters.BUFFTIME2
		-- 	self:directHurt(self.itemID,mode,hitValueNew,0) 
		-- end
		self.mode3AtkNum = 0
		hitValueBoth['Effect'] = 97
	end

	if (mode==2) then
		hitValueBoth['bulletAttackMode4Passthru'] = false;
	end

	if mode==4 then
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		local parametersOrg = skill.parameters

		if self.SP>=parameters.USESPNUM then
			self:useSP(parameters.USESPNUM)
		else

		end

		hitValueBoth['ADADJ'] = parameters.ADADJ2
		hitValueBoth['BEHEADEDHURT'] = parameters.BEHEADEDHURT4

		if self.mode4atkNum==1 then
			skill = self.attribute.skills[10]
			parameters = skill.parameters
			hitValueBoth['BEHEADEDHURT'] = parameters.BEHEADEDHURT2
			hitValueBoth['changeMode'] = 10
		end

		if self.mode4atkNum==2 then
			skill = self.attribute.skills[11]
			parameters = skill.parameters
			hitValueBoth['BEHEADEDHURT'] = parameters.BEHEADEDHURT3
			hitValueBoth['changeMode'] = 11
		end

		-- 计算角色移动位置并移动
		local d1 = self:distance(self.lastBulletPositionX,self.lastBulletPositionY)
		local neardis = parameters.NEARESTUSEDIS/self.world.setting.AdjustAttRange
		if self.lastBulletTarget~=nil and self.lastBulletTarget>0 and self.world.allItemList[self.lastBulletTarget]~=nil and self.world.allItemList[self.lastBulletTarget].attribute.width>=4 then
			neardis = self.world.allItemList[self.lastBulletTarget].attribute.width * 2 * 0.75
		end
		local atkDis = (d1-neardis)>0 and (d1-neardis) or d1

		local toX1,toY1 = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,atkDis)
		local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX1,self.posY+toY1) 
		--local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY)
		self:D("狂战士 大招 posX:"..self.posX.." posY:"..self.posY.." lastBulletPositionX:"..self.lastBulletPositionX.." lastBulletPositionY:"..self.lastBulletPositionY.." toX:"..toX.." toY:"..toY.." toX1:"..(self.posX+toX1).." toY1:"..(self.posY+toY1),d1,atkDis)
		local d = self:distance(toX,toY)
		local FLYSPEED = (d*100)/(parameters['FLYTIME'])

		if (d1-neardis)>0 and self.lastBulletTarget>0 then
			self:moveTo(toX,toY,false,6,FLYSPEED)
		end
		
		if self.lastBulletTarget==0 then
			self.lastBulletPositionX = self.posX
			self.lastBulletPositionY = self.posY
		end

		-- 设置子弹打中时间hitTime
		local endTime = 0
		if self.moveToEndTime==0 then
			endTime = self.world:getGameTime()
		end
		self.prepareSKVar['interval'] = endTime - self.world:getGameTime()
		self.mode4atkTime = endTime
		-- self:D('jaylog SHero6:prepareHit moveToEndTime ',self.mode4atkNum,self.moveToEndTime,self.world:getGameTime(),parametersOrg['DHTIME'..self.mode4atkNum])
		-- 加可连技提示
		if self.mode4atkNum<3 then
			local timeLen = parametersOrg['DHTIME'..self.mode4atkNum]
			if self.moveToEndTime>self.world:getGameTime() then
				timeLen = self.moveToEndTime - self.world:getGameTime() + parametersOrg['DHTIME'..self.mode4atkNum]
			end
			if not self.mode4autoReset then
				-- 教程中设置一直保留可施放直至教程结束
				timeLen = timeLen + 9999
			end
			self:addStatusList({zz=3,s=95,r=self.world:getGameTime(),t=timeLen,i=self.itemID,p1=self.mode4atkNum})
			self:D('jaylog SHero6:prepareHit addStatusList 95 ',self.mode4atkNum,self.mode4atkTime,self.moveToEndTime,timeLen,self.world:getGameTime(),parametersOrg['DHTIME'..self.mode4atkNum])
		end
		-- 设置技能施放间隔时间
		-- self.attribute.skills[4].lastCoolDownTime = self.moveToEndTime + skill.cutTime
		-- self:syncSkill(0)

		local skillValue = self.world:createSkillValue()
		for k,v in pairs(skill) do
			if skillValue[k]~=nil then
				skillValue[k] = v
			end
		end
		hitValueBoth['skillValue'] = skillValue

		self:D('jaylog SHero6:prepareHit hitValueBoth ',self.world.cjson.encode(hitValueBoth),self.world:getGameTime(),self.moveToEndTime)
	end

	-- if mode==4 then
	-- 	--NEARESTUSEDIS=200;FLYTIME=0.35;STOPTIME=0.15;DOWNTIME=0.1
	-- 	local skill = self.attribute.skills[4] 
	-- 	local parameters = skill.parameters 


	-- 	if self.SP>=parameters.USESPNUM then
	-- 		-- self.addFIXHURTMode=1
	-- 		self:useSP(parameters.USESPNUM)
	-- 	else
	-- 		-- self.addFIXHURTMode=0
	-- 	end

	-- 	if self.mode4atkNum==1 then
	-- 		skill = self.attribute.skills[10]
	-- 		parameters = skill.parameters
	-- 	end

	-- 	if self.mode4atkNum==2 then
	-- 		skill = self.attribute.skills[11]
	-- 		parameters = skill.parameters
	-- 	end

	-- 	local d1 = self:distance(self.lastBulletPositionX,self.lastBulletPositionY)
	-- 	local atkDis = (d1-parameters.NEARESTUSEDIS/self.world.setting.AdjustAttRange)>0 and (d1-parameters.NEARESTUSEDIS/self.world.setting.AdjustAttRange) or d1

	-- 	local toX1,toY1 = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,atkDis)
	-- 	local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX1,self.posY+toY1) 
	-- 	--local ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY)
	-- 	self:D("狂战士 大招 posX:"..self.posX.." posY:"..self.posY.." lastBulletPositionX:"..self.lastBulletPositionX.." lastBulletPositionY:"..self.lastBulletPositionY.." toX:"..toX.." toY:"..toY)
	-- 	local d = self:distance(toX,toY)
	-- 	local FLYSPEED = (d*100)/(parameters['FLYTIME'])

	-- 	self:moveTo(toX,toY,false,6,FLYSPEED,skill.hitTime)
	-- 	--local dealyTime = (d*100)/parameters['FLYSPEED']
	-- 	local dealyTime = skill.hitTime+parameters['FLYTIME']
	-- 	local attributes = {}
	-- 	attributes['buffParameter']={}
	-- 	attributes['BUFFONLY']=1
	-- 	attributes['buffParameter'] = {}
	-- 	attributes['buffParameter']['buffIntervalTime'] = dealyTime
	-- 	local buffObj=require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,dealyTime,{mode},0,self.itemID,self.itemID,skill.hitTime) 
	-- 	buffObj.debug = true
 -- 		self:addBuff(buffObj)
 -- 		self:D("狂战士 大招 d:"..d.."dealyTime:"..dealyTime.." lastBulletPositionX:"..self.lastBulletPositionX.." lastBulletPositionY:"..self.lastBulletPositionY.." posX"..self.posX.." posY:"..self.posY,self.world.gameTime,self.world.gameTime+dealyTime)
	-- 	hitValueBoth=nil
	-- 	self.mode4time = self.world.gameTime+dealyTime
	-- 	self.mode4idx = 0
	-- 	self.mode4num = 2
	-- 	self.mode4start = false

	-- 	self.lastBulletPositionX = toX
	-- 	self.lastBulletPositionY = toY

	-- 	return nil
	-- end

	-- if mode==104 then
	-- 	local skill = self.attribute.skills[4] 
	-- 	local parameters = skill.parameters 
	-- 	self:D('jaylog SHero6:mode104 ',self.world.gameTime,self.mode4time)
	-- 	self.mode4idx = self.mode4idx + 1
	-- 	-- if self.mode4idx==self.mode4num then
	-- 	if not self.mode4start and (self.world:getGameTime()>self.mode4time or (self.mode4atkNum==3 and self.mode4idx==self.mode4num)) then
	-- 	-- if self.mode4idx==self.mode4num or ((self.mode4idx==1 or self.mode4idx>self.mode4num) and self.world:getGameTime()>=self.mode4time) then
	-- 		local goOn = true
	-- 		self.mode4start = true
	-- 		if self.mode4atkNum==1 and goOn then
	-- 			local skill1 = self.attribute.skills[10] 
	-- 			hitValueBoth['ADADJ'] = parameters.ADADJ2
	-- 			hitValueBoth['BEHEADEDHURT'] = parameters.BEHEADEDHURT2
	-- 			self:D('jaylog SHero6:prepareHit mode104 1 ',self.mode4atkNum)
	-- 			local skillValue = self.world:createSkillValue()
	-- 			for k,v in pairs(skill1) do
	-- 				if skillValue[k]~=nil then
	-- 					skillValue[k] = v
	-- 				end
	-- 			end
	-- 			hitValueBoth['skillValue'] = skillValue
	-- 			self.mode4atkNum = 2
	-- 			self.mode4atkTime = self.world:getGameTime()
	-- 			goOn = false
	-- 			self.mode4idx = 0
	-- 		end
	-- 		if self.mode4atkNum==2 and goOn then
	-- 			local skill1 = self.attribute.skills[11] 
	-- 			hitValueBoth['ADADJ'] = parameters.ADADJ2
	-- 			hitValueBoth['BEHEADEDHURT'] = parameters.BEHEADEDHURT3
	-- 			self:D('jaylog SHero6:prepareHit mode4 2 ',self.mode4atkNum)
	-- 			local skillValue = self.world:createSkillValue()
	-- 			for k,v in pairs(skill1) do
	-- 				if skillValue[k]~=nil then
	-- 					skillValue[k] = v
	-- 				end
	-- 			end
	-- 			hitValueBoth['skillValue'] = skillValue
	-- 			self.mode4atkNum = 3
	-- 			self.mode4atkTime = self.world:getGameTime()
	-- 			goOn = false
	-- 			self.mode4idx = 0
	-- 		end
	-- 		if self.mode4atkNum==3 and goOn then
	-- 			hitValueBoth=nil
	-- 			self:D("狂战士 大招 回调",self.world.gameTime)
	-- 			local hitValueNew = self:getPrepareHithitValue()
	-- 			hitValueNew['skillID'] = 4
	-- 			hitValueNew['ADADJ'] = parameters.ADADJ2 
	-- 			hitValueNew['BEHEADEDHURT'] = parameters.BEHEADEDHURT4

	-- 			-- if self.addFIXHURTMode==1 then
	-- 			-- 	hitValueNew['BLEED_HURTFIX_RATE'] = parameters.BLEED_HURTFIX_RATE2
	-- 			-- 	hitValueNew['BLEED_HURTFIX'] = parameters.BLEED_HURTFIX2
	-- 			-- 	hitValueNew['BUFFTIME'] = parameters.BUFFTIME2	
	-- 			-- end

	-- 			self:directFightAuratoDalay(4,0,hitValueNew,{posX=self.posX,posY=self.posY,RANGE=skill.atkDis},0) 
	-- 			self.mode4atkNum = 1
	-- 			self.mode4atkTime = 0
	-- 			self.mode4idx = 0
	-- 		end
	-- 		if self.mode4atkNum>1 and self.SP<parameters.USESPNUM then
	-- 			self.attribute.skills[mode-100].lastCoolDownTime = self.attribute.skills[mode-100].lastCoolDownTime + parameters.CDTIME
	-- 			self:syncSkill(0)
	-- 			self.mode4atkNum = 1
	-- 			self.mode4atkTime = 0
	-- 		end
	-- 	else
	-- 		hitValueBoth = nil
	-- 	end
	-- 	mode = 4
	-- end



	--需要4变5
	if (mode==5) then
		--APADJ=0;ADADJ=0;ATK_UP=10;LOSSHP_HURT=8;BUFFTIME=7;BLEED_HURTFIX_RATE2=100;BLEED_HURTFIX2=17;BUFFTIME2=3;CDTIME=20
		--APADJ=0;ADADJ=0;ATK_UP=25;LOSSHP_HURT_RATE=100;LOSSHP_HURT=8;BUFFTIME=7;BLEED_HURTFIX_RATE2=100;BLEED_HURTFIX2=17;BUFFTIME2=7;CDTIME=20
		local skill = self.attribute.skills[5] 
		local parameters = skill.parameters 
		-- self.mode5time = self.world:getGameTime() + parameters.BUFFTIME
		-- self.mode5in1time = self.world:getGameTime() + parameters.BUFFTIME

		-- self.nextStopAddSPTime = self.world:getGameTime() + parameters.BUFFTIME
		-- self.addSPNum = parameters.RESPNUM
		self:adjSP(parameters.ADJSPNUM)


		--天赋增加攻击
		-- if parameters.USESCALEHP~=nil then
		-- 	if self.attribute.HP>self.attribute.MaxHP*parameters.USESCALEHP*0.01 then
		-- 		self:adjHP(-self.attribute.MaxHP*parameters.USESCALEHP*0.01,true)
		-- 		local hitValueNew={}
		-- 		hitValueNew['ATK_UPFIX_RATE']=100 
		-- 		hitValueNew["ATK_UPFIX"]=1000
		-- 		hitValueNew["BUFFTIME"]=10
		-- 		self:directHurt(self.itemID,mode,hitValueNew,0) 
		-- 	end
		-- end
	end


	-- if mode==1 then
	-- 	self.mode1bool = true
	-- 	--buff效果内 每次普工都流血 天赋
	-- 	if self.mode5in1time>self.world:getGameTime()  then

	-- 		local skill = self.attribute.skills[5] 
	-- 		local parameters = skill.parameters 
	-- 		if parameters.BUFFHITBLEED~=nil then
	-- 			hitValueBoth['BLEED_HURTFIX_RATE'] = parameters.BLEED_HURTFIX_RATE2
	-- 			hitValueBoth['BLEED_HURTFIX'] = parameters.BLEED_HURTFIX2
	-- 			hitValueBoth['BUFFTIME'] = parameters.BUFFTIME2
	-- 		end
	-- 	end
	-- 	self.mode5adjsp = 0
	-- end

	return hitValueBoth 
end 


--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero6:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 

	if mode==7 then
		local skill = self.attribute.skills[7] 
		local parameters = skill.parameters 
		--释放血剑斩，对目标造成%sBB物理伤害，并使对方100%持续%s秒出血。AAAA冷却：%s 秒
		--HURTAD_HURT=30;HURTAP_HURT=30;BUFFTIME=10;COUNTER_RATE=10;APADJ2=0;ADADJ2=150;BLEED_HURTFIX2=30;BUFFTIME2=5;CDTIME=30
		self:D("格挡   触发格挡攻击...........")
		hitValue['APADJ'] = hitValue['APADJ']+parameters.APADJ2
		hitValue['ADADJ'] = hitValue['ADADJ']+parameters.ADADJ2
		hitValue['BLEED_HURTFIX'] = hitValue['BLEED_HURTFIX']+parameters.BLEED_HURTFIX2
		hitValue['BUFFTIME'] = parameters.BUFFTIME2
	end


	if mode==1  then
		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters 
		-- local attributes = {}
		-- attributes['CRI_UP_RATE'] = parameters['CRI_UP_RATE2']
		-- attributes['CRI_UP'] = parameters['CRI_UP2'] 
		-- local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,parameters['BUFFTIME2'],{},0,self.itemID,self.itemID,0.1)
		-- self:addBuff(buff)

		self:D("狂战士1mode parameters:",self.world.cjson.encode(parameters))
		--击中出血目标获得2点愤怒点。
		if self:isLessHP(itemID) then
			self:adjSP(parameters.ADJSPNUM2)
			-- hitValue['Effect'] = 6
		else
			self:adjSP(parameters.ADJSPNUM)
		end

	end

	if mode==2 then
		if self:isLessHP(itemID) then
			-- hitValue['Effect'] = 6
		end
	end

	if mode==3  then
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 
		--击中出血目标获得2点愤怒点。
		if self:isLessHP(itemID) then
			-- hitValue['Effect'] = 6
			self:adjSP(parameters.ADJSPNUM2)
		else
			self:adjSP(parameters.ADJSPNUM)
		end

		self.mode3AtkNum = self.mode3AtkNum  + 1
		if self.mode3AtkNum%2==0 then
			hitValue['Effect'] = nil
		end
	end

	if mode==3 and self.hurtDrainLifeMode==1 then


		-- if self:isVAM(itemID) then
		-- 	self:D("狂战士 旋风吸血 目标自带流血:")
		--   	local skill = self.attribute.skills[3] 
		-- 	local parameters = skill.parameters 
		-- 	hitValue['VAMPIREAD_RATE']=100
		--   	hitValue['VAMPIREAD']=parameters.VAMPIREAD2
		-- end
	end

	local ret = SHero6.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 

	if mode==2 and hitValue['Effect']~=2 then
		--print("prepareHit 飞飞飞........ x y tox toy distance ",self.posX,toX,self.posY,toY,skill.atkDis/self.world.setting.AdjustAttRange)
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[2] 
		local parameters = skill.parameters 
		
		local d = obj:distance(self.mode2x,self.mode2y)+self.attribute.width
		local toX,toY = self.world.map:getXYLength(self.modeold2x,self.modeold2y,self.mode2x,self.mode2y,d)
		ret2,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
		if ret>0 then
			obj:moveTo(toX,toY,false,5,skill.bulletSpeed,0) 
		end

		--击中斩杀状态目标获得更多愤怒点
		if self:isLessHP(itemID) then
			self:adjSP(parameters.ADJSPNUM2)
		else
			self:adjSP(parameters.ADJSPNUM)
		end		

		if parameters.MSPD_UP2~=nil then
			--天赋 冲锋加速
			local hitValueNew={}
			hitValueNew['MSPD_UP']=parameters.MSPD_UP2 
			hitValueNew["MSPD_UP_RATE"]=parameters.MSPD_UP_RATE2
			hitValueNew["BUFFTIME"]=parameters.BUFFTIME2
			self:directHurt(self.itemID,mode,hitValueNew,0) 
		end
	
	end

	if mode==4 and self.mode4atkNum==1 and hitValue['changeMode']==nil then
		-- self:D('jaylog SHero6:hitTarget hitValue',self.world.cjson.encode(hitValue))
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		local obj = self.world.allItemList[itemID]
		if ret>0 then
			--弹飞园半径
			local r = parameters.BACKWARD/self.world.setting.AdjustAttRange
			toX,toY = self.world.map:getXYLength(self.posX,self.posY,obj.posX,obj.posY,r) 
			ret,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
			obj:moveTo(toX,toY,true,5,parameters.BACKWARDSPEED,parameters.BACKWARDDELAY)
		end
	end
	
	--buff状态下每次攻击都有记录恢复9点愤怒值
	-- if self.mode5in1time>self.world:getGameTime() and hitValue['Effect']~=2 and self.mode5adjsp==0 then
	-- 	local skill = self.attribute.skills[5] 
	-- 	local parameters = skill.parameters 
	-- 	if parameters.BUFFHITRESP~=nil then
	-- 		local rand = math.random(1,100)	
	-- 		if rand<parameters.BUFFHITRESPRATE then
	-- 			self.mode5adjsp = 1
	-- 			self:adjSP(parameters.BUFFHITRESPNUM)
	-- 		end
	-- 	end
	-- end
	return ret 
end 

--是否流血
function SHero6:isVAM(itemID)
	local obj = self.world.allItemList[itemID] 
	local vam = false
	for k,v in pairs(obj.buffList) do
		--self:D("狂战士 旋风吸血1:",self.world.cjson.encode(v.buffAttribute.buffParameter))
		if v.buffAttribute.buffParameter.FIXHURT>0 then
			vam=true
		end
	end
	return vam
end

--- move motion , call every update loop
-- @return null
-- function SHero6:move() 
-- 	local skill = self.attribute.skills[4] 
-- 	local parameters = skill.parameters 
-- 	local addTime = 0
-- 	if self.mode4atkTime>0 then
-- 		if self.mode4atkNum==3 then
-- 			addTime = parameters['DHTIME'..(self.mode4atkNum-1)]
-- 		else
-- 			addTime = parameters['DHTIME'..self.mode4atkNum]
-- 		end
-- 	end
-- 	if self.mode4atkTime>0 and self.mode4atkTime+addTime<self.world:getGameTime() then
-- 		self.mode4atkNum = 1
-- 		self.attribute.skills[4].lastCoolDownTime = self.world:getGameTime() + parameters.CDTIME
-- 		self.mode4atkTime = 0
-- 		self:syncSkill(0)
-- 		self:removeStatusList(95)
-- 		self:D('jaylog SHero6 move checkTime:',self.mode4atkNum,self.mode4atkTime,parameters['DHTIME'..self.mode4atkNum],self.world:getGameTime())
-- 	end
-- 	return SHero6.super.move(self)
-- end

--- 准备攻击前置设置，在prepareHit之后执行，call父类
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SHero6:prepareSkillAttackCustom(mode,target,x,y,adjTime,syncMsg)  

	-- if mode==4  then
	-- 	local skill = self.attribute.skills[mode] 
	-- 	local parameters = skill.parameters 

	-- 	self:D('jaylog SHero6:prepareSkillAttackCustom mode4 ',self.mode4atkNum)
	-- 	local goOn = true
	-- 	if self.mode4atkNum==1 and goOn then
	-- 		self:D('jaylog SHero6:prepareSkillAttackCustom 1 ',self.mode4atkNum)
	-- 		syncMsg['a']['p'] = '1'
	-- 		syncMsg['a']['x'] = self.lastBulletPositionX
	-- 		syncMsg['a']['y'] = self.lastBulletPositionY
	-- 		goOn = false
	-- 	end
	-- 	if self.mode4atkNum==2 and goOn then
	-- 		self:D('jaylog SHero6:prepareSkillAttackCustom 2 ',self.mode4atkNum)
	-- 		syncMsg['a']['p'] = '2'
	-- 		syncMsg['a']['x'] = self.lastBulletPositionX
	-- 		syncMsg['a']['y'] = self.lastBulletPositionY
	-- 		goOn = false
	-- 	end
	-- 	if self.mode4atkNum==3 and goOn then
	-- 		self:D('jaylog SHero6:prepareSkillAttackCustom 3 ',self.mode4atkNum)
	-- 		syncMsg['a']['p'] = '3'
	-- 		syncMsg['a']['x'] = self.lastBulletPositionX
	-- 		syncMsg['a']['y'] = self.lastBulletPositionY
	-- 		self:D("狂战士大战:".." syncMsg:"..self.world.cjson.encode(syncMsg))
	-- 	end
	-- end

	if mode==4 then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 

		-- self.world.bulletList[self.lastBulletID].attr.debug = true

		self:D('jaylog SHero6:prepareSkillAttackCustom mode4 ',self.mode4atkNum)
		local goOn = true
		if self.mode4atkNum==1 and goOn then
			syncMsg['a']['p'] = '1'
			syncMsg['a']['m'] = 10
			self.mode4atkNum = 2
			self:D('jaylog SHero6:prepareSkillAttackCustom 1 ',self.mode4atkNum,self.world.cjson.encode(syncMsg))
			goOn = false
		end
		if self.mode4atkNum==2 and goOn then
			syncMsg['a']['p'] = '2'
			syncMsg['a']['m'] = 11
			self.mode4atkNum = 3
			self:D('jaylog SHero6:prepareSkillAttackCustom 2 ',self.mode4atkNum,self.world.cjson.encode(syncMsg))
			goOn = false
		end
		if self.mode4atkNum==3 and goOn then
			syncMsg['a']['p'] = '3'
			self.mode4atkNum = 1
			self.mode4atkTime = 0
			self:removeStatusList(95)
			self:D('jaylog SHero6:prepareSkillAttackCustom 3 ',self.mode4atkNum,self.world.cjson.encode(syncMsg))
		end
		syncMsg['a']['x'] = self.lastBulletPositionX
		syncMsg['a']['y'] = self.lastBulletPositionY
		if  self.SP<parameters.USESPNUM then
			if self.moveToEndTime>0 then
				self.attribute.skills[mode].lastCoolDownTime = self.moveToEndTime + parameters.CDTIME
			else
				self.attribute.skills[mode].lastCoolDownTime = self.world:getGameTime() + parameters.CDTIME
			end
			self:syncSkill(0)
			self.mode4atkNum = 1
			self.mode4atkTime = 0
			self:removeStatusList(95)
			self:D('jaylog SHero6:isLessSP cannot use part 3')
		end
		-- if self.mode4atkNum>1 and self.SP<parameters.USESPNUM then
		-- 	self.attribute.skills[mode].lastCoolDownTime = self.moveToEndTime + parameters.CDTIME
		-- 	self:syncSkill(0)
		-- 	self.mode4atkNum = 1
		-- 	self.mode4atkTime = 0
		-- 	self:removeStatusList(95)
		-- end
	end

	if (mode==2 ) then 
		--print("prepareHit 飞飞飞........ x y tox toy distance ",self.posX,toX,self.posY,toY,skill.atkDis/self.world.setting.AdjustAttRange)
		local skill = self.attribute.skills[2] 
		local parameters = skill.parameters 

		local toX,toY = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,(skill.atkDis-parameters.MOVECUT)/self.world.setting.AdjustAttRange)
		local ret
		self:D("prepareHit 飞飞飞........ x tox y toy distance ",self.posX,toX,self.posY,toY,(skill.atkDis-parameters.MOVECUT)/self.world.setting.AdjustAttRange)
		ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX,self.posY+toY) 

		local delaytime = parameters.COLLISIONBULLETHITTIME
		self.mode2time = self.world:getGameTime()+adjTime+delaytime
		self.modeold2x = self.posX
		self.modeold2y = self.posY
		--self.world:self:D('============= hero rush itemid ox oy x y ',self.itemID,self.modeold2x,self.modeold2y,toX,toY)
		self:moveTo(toX,toY,false,6,skill.bulletSpeed,adjTime+delaytime) 
		self.mode2x = toX
		self.mode2y = toY
		syncMsg['a']['x'] = toX
		syncMsg['a']['y'] = toY
		local attributes = {}
		attributes['IMMUNECONTROL_RATE'] = 100
		--attributes['IMMUNECONTROL'] = self.moveToEndTime
		attributes['BUFFTIME'] = 0.2
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,0.2,{},0,self.itemID,self.itemID,adjTime)
		self:addBuff(buff)

	end

	SHero6.super.prepareSkillAttackCustom(self,mode,target,x,y,adjTime,syncMsg)  
end 

function SHero6:checkMana(mode)

	if mode==4  then

		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		
		self:D("愤怒 ",self.world.cjson.encode(parameters))
		if self.SP<parameters.USESPNUM then
			-- self:D('jaylog checkMana SP',self.SP,parameters.USESPNUM)
			return false
		end
	end

	-- self:D('jaylog checkMana return',SHero6.super.checkMana(self,mode))
	return SHero6.super.checkMana(self,mode) 	
end


--- 自动移动
-- @return null
function SHero6:_autoMove()
	-- self:D("SHero:_autoMove")
	local ret=SHero6.super._autoMove(self)
	local moveRet=self.autoFightAI:autoMoveToAlerted()

	if not ret and not self.autoBlocked and self.AIlastMoveTime < self.world:getGameTime() and  not self:isDead() and not moveRet and self.statusList[4007]==nil then
		
		local gt = self.world:getGameTime()


		if self.autoFightAI.nextMoveTargetTime>gt then
			self:D("狂战士 放autoMoveToATKHero nextMoveTargetTime:"..self.autoFightAI.nextMoveTargetTime.." gameTime:"..self.world.gameTime)
			self.autoFightAI:autoMoveToATKHero()
		else
			self:D("狂战士 放autoMoveToHero")
			self.autoFightAI:autoMoveToHero()
		end

		self.AIlastMoveTime = self.moveToEndTime
	end
	
	return ret
end

function SHero6:adjSP(sp,force)
	if force==nil then
		force = false
	end
	local skill = self.attribute.skills[4] 
	local parameters = skill.parameters 
	-- if not force and self.mode4atkTime>0 and self.mode4atkNum>1 and self.mode4atkTime+parameters['DHTIME'..(self.mode4atkNum-1)]>self.world:getGameTime() then
	if not force and self.statusList[95]~=nil then
		self:D('jaylog SHero6 3s not adjSP',self.mode4atkTime,self.mode4atkNum,self.world.gameTime,parameters['DHTIME'..self.mode4atkNum])
		return nil
	end

	self.SP = math.round(self.SP + sp, 1)
	if self.SP>self.maxSP then self.SP = self.maxSP end
	if self.SP>self.changePartSP then self.SP=self.changePartSP end

	if self.SP<1 then 
		self.SP = 0 
	end
	self:addStatusList({zz=3,s=70,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.SP,p3=(self:checkMana(4) and 0 or 1)},0)
	self:D("单次增加愤怒值:",sp,"总愤怒值:",self.SP,self:checkMana(4),(self:checkMana(4) and 0 or 1),self.world.cjson.encode(self.syncMsg['s']))
end

function SHero6:useSP(sp)

	self.SP = math.round(self.SP - sp, 1)

	if self.SP<1 then 
		self.SP = 0 
	end
	self:D("单次使用愤怒值:",sp,"总愤怒值:",self.SP)
	self:addStatusList({zz=3,s=70,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.SP,p3=(self:checkMana(4) and 0 or 1)},0)
end


function SHero6:syncInfo()
	--每隔一秒恢复一次sp
	-- if self.nextStopAddSPTime>self.world:getGameTime() and self.world:getGameTime()>self.nextAddSPTime then
	-- 	self:adjSP(self.addSPNum)
	-- 	self.nextAddSPTime = self.world:getGameTime() + 1
	-- end
	local skill = self.attribute.skills[4] 
	local parameters = skill.parameters 
	local addTime = 0
	if self.mode4atkNum==3 then
		addTime = parameters['DHTIME'..(self.mode4atkNum-1)]
	else
		addTime = parameters['DHTIME'..self.mode4atkNum]
	end
	if self.mode4atkNum>1 and self.statusList[95]==nil then
		self.mode4atkNum = 1
		self.attribute.skills[4].lastCoolDownTime = self.world:getGameTime() + parameters.CDTIME
		self.mode4atkTime = 0
		self:syncSkill(0)
		self:removeStatusList(95)
		self:D('jaylog SHero6 syncInfo checkTime:',self.mode4atkNum,self.mode4atkTime,parameters['DHTIME'..self.mode4atkNum],self.world:getGameTime())
	end
	SHero6.super.syncInfo(self)
end

--- 目标是否斩杀状态(少于百分比血量)
-- @param itemID int - 目标itemID
-- @return lessHP boolean - 是否少于百分比血量
function SHero6:isLessHP(itemID)
	local obj = self.world.allItemList[itemID]
	-- self.world:D('jaylog SHero6:isLessHP ',self.world.cjson.encode(self.attribute.parameterArr))
	if obj.attribute.HP<obj.attribute.MaxHP*self.attribute.parameterArr['BEHEADEDHP']*0.01 then
		return true
	else
		return false
	end
end

--- 设置技能限制施放时间
-- @param skill table - 角色某一招技能的所有设置值
-- @return null
function SHero6:useCDTime(skill)
	local ret = SHero6.super.useCDTime(self,skill)
	if skill.rank==4 then
		if self.mode4atkNum<3 then
			local skill1 = self.attribute.skills[4] 
			local parameters = skill1.parameters 
			local sk = self.attribute.skills
			local gt = self.world:getGameTime()
			skill.lastCoolDownTime = gt + parameters.REACTIONTIME
			sk[4].lastCoolDownTime = gt + parameters.REACTIONTIME
		end
	end
	return ret
end

return SHero6 
