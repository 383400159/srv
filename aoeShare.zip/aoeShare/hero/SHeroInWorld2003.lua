local SHeroInWorld2003 = class("SHeroInWorld2003", require("gameroomcore.SHeroBase"))

function SHeroInWorld2003:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld2003.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

function SHeroInWorld2003:prepareSkillAttackMode7(updateMove)
	return nil
end

return SHeroInWorld2003
