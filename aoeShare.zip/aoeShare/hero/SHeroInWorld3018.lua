local SHeroInWorld3018 = class("SHeroInWorld3018", require("gameroomcore.SHeroBase"))

function SHeroInWorld3018:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld3018.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	debuglog("SHeroInWorld3018:ctor........")
	--第一次站位
	self.moveAIone = false
	--下次检测站位时间
	self.nextMoveAITime = 0
	--自己的站位
	self.AIdirection = 2
	self.moveToX = 0
	self.moveToY = 0
end


function SHeroInWorld3018:_autoMove()
	if self.world.tpAIMoveTime==0 then
		self.autoFightAI.isBehindAI = true
		return SHeroInWorld3018.super._autoMove(self)
	else
		self.autoFightAI.isBehindAI = false
		if self.nextMoveAITime>self.world:getGameTime() then
			self:D("地图AI移动"..self.itemID,self.moveToX,self.moveToY)
			self:moveTo(self.moveToX,self.moveToY,true)
		end
		return true
	end
end
--- 自动释放技能 
-- @return null
function SHeroInWorld3018:_autoFight()
	if self.isAI~=nil and self.isAI  then
		if self.world.tpAIMoveTime~=nil and self.world.tpAIMoveTime>self.world:getGameTime() then
			--处于天平AI下
			--天平AI行为
			if not self.moveAIone then
				local a = self.itemID%2==0 and 0 or 1
				--local a = self.world.formula:getRandnum(0,1)
				--分布位置
				if self.itemID~=5  then
				-- if self.itemID~=5 or self.world.gameRoomSetting['maxPlayer']>1 then
					if a==0 then
						local toX,toY = self.world.formula:getRandomCirclePoint(self.world.tpSetting[1]['x'],self.world.tpSetting[1]['y'],self.world.tpSetting[1]['r']-2)
						self.moveToX,self.moveToY = toX,toY
						self:moveTo(toX,toY,true)
						--self.tpAMoveList[#self.tpAMoveList+1]=self.itemID
						self.AIdirection = 0
						self:D("地图AI3018:"..self.itemID,"初始去左边 ")
					else
						local toX,toY = self.world.formula:getRandomCirclePoint(self.world.tpSetting[2]['x'],self.world.tpSetting[2]['y'],self.world.tpSetting[2]['r']-2)
						self.moveToX,self.moveToY = toX,toY
						self:moveTo(toX,toY,true)
						--self.tpBMoveList[#self.tpBMoveList+1]=self.itemID
						self.AIdirection = 1
						self:D("地图AI3018:"..self.itemID,"初始去右边 ")
					end
					self.nextMoveAITime = self.moveToEndTime+0.5
					self.world.nextMoveAITime = self.moveToEndTime+0.5
					self.moveAIone = true
				else
					local b = self.world.formula:getRandnum(1,2)
					local toX,toY = self.world.formula:getRandomCirclePoint(self.world.tpSetting[b]['x'],self.world.tpSetting[b]['y'],self.world.tpSetting[b]['r']+self.world.formula:getRandnum(3,5),true)
					self.moveToX,self.moveToY = toX,toY
					self:moveTo(toX,toY,true)
					self.AIdirection = 2
					self:D("地图AI3018:"..self.itemID,"5号单独出去 出去",self.world.tpZNum,self.world.tpYNum,self.AIdirection,toX,toY)
					self.nextMoveAITime = self.world:getGameTime()+(self.world.tpAIAllTime-4)
					--self.world.nextMoveAITime = self.moveToEndTime+0.5
					self.moveAIone = true
				end
			end
			--self:D("地图AI3018:"..self.itemID,"进第2次",self.moveAIone,self.nextMoveAITime,self.world.nextMoveAITime,self.world:getGameTime())
			if self.moveAIone and self.world:getGameTime()>self.nextMoveAITime and self.world:getGameTime()>self.world.nextMoveAITime and self.attribute.roleId%5~=2 then
				--判断场上的格子情况进行调整位置
				local isQ = false
				if (self.world.tpZNum+self.world.tpYNum)==(self.world.gameRoomSetting['maxPlayer']+self.world.gameRoomSetting['AIMaxPlayer'])  then
					isQ = true
					self:D("地图AI3018:"..self.itemID,"2边占满了 需要有人出去")
				end
				--self:D("地图AI3018:"..self.itemID,"第2次",self.world.tpZNum,self.world.tpYNum,self.AIdirection,self.world.cjson.encode(self.world.tpSetting))
				
				if self.AIdirection==2 then
					if self.world.tpZNum>self.world.tpYNum then
						--外围人补右边
						local toX,toY = self.world.formula:getRandomCirclePoint(self.world.tpSetting[2]['x'],self.world.tpSetting[2]['y'],self.world.tpSetting[2]['r']-2)
						self.moveToX,self.moveToY = toX,toY
						self:moveTo(toX,toY,true)
						self.AIdirection = 1
						self:D("地图AI3018:"..self.itemID,"外围人补右边",self.world.tpZNum,self.world.tpYNum,self.AIdirection,toX,toY)
					end
					if self.world.tpYNum>self.world.tpZNum then
						--外围人补左边
						local toX,toY = self.world.formula:getRandomCirclePoint(self.world.tpSetting[1]['x'],self.world.tpSetting[1]['y'],self.world.tpSetting[1]['r']-2)
						self.moveToX,self.moveToY = toX,toY
						self:moveTo(toX,toY,true)
						self.AIdirection = 0
						self:D("地图AI3018:"..self.itemID,"外围人补左边",self.world.tpZNum,self.world.tpYNum,self.AIdirection,toX,toY)
					end
					self.nextMoveAITime = self.moveToEndTime+0.5
					self.world.nextMoveAITime = self.moveToEndTime+0.5
				end

				if ((self.world.tpZNum-self.world.tpYNum)>1 or (isQ and self.world.tpZNum>self.world.tpYNum)) and self.AIdirection==0 then
					--左边大于右边 左边的人去右边
					if isQ then
						local toX,toY = self.world.formula:getRandomCirclePoint(self.world.tpSetting[1]['x'],self.world.tpSetting[1]['y'],self.world.tpSetting[1]['r']+self.world.formula:getRandnum(3,5),true)
						self.moveToX,self.moveToY = toX,toY
						self:moveTo(toX,toY,true)
						self.AIdirection = 2
						self:D("地图AI3018:"..self.itemID,"左边大于右边 左边的人去右边 出去",self.world.tpZNum,self.world.tpYNum,self.AIdirection,toX,toY)
					else
						local toX,toY = self.world.formula:getRandomCirclePoint(self.world.tpSetting[2]['x'],self.world.tpSetting[2]['y'],self.world.tpSetting[2]['r']-2)
						self.moveToX,self.moveToY = toX,toY
						self:moveTo(toX,toY,true)
						self.AIdirection = 1
						self:D("地图AI3018:"..self.itemID,"左边大于右边 左边的人去右边",self.world.tpZNum,self.world.tpYNum,self.AIdirection,toX,toY)
					end
					self.nextMoveAITime = self.moveToEndTime+0.5
					self.world.nextMoveAITime = self.moveToEndTime+0.5
				end
				
				if ((self.world.tpYNum-self.world.tpZNum)>1 or (isQ and self.world.tpYNum>self.world.tpZNum)) and self.AIdirection==1 then
					--右边大于左边 右边的人去左边
					if isQ then
						local toX,toY = self.world.formula:getRandomCirclePoint(self.world.tpSetting[2]['x'],self.world.tpSetting[2]['y'],self.world.tpSetting[2]['r']+self.world.formula:getRandnum(3,5),true)
						self.moveToX,self.moveToY = toX,toY
						self:moveTo(toX,toY,true)
						self.AIdirection = 2
						self:D("地图AI3018:"..self.itemID,"右边大于左边 右边的人去左边 出去",self.world.tpZNum,self.world.tpYNum,self.AIdirection,toX,toY)
					else
						local toX,toY = self.world.formula:getRandomCirclePoint(self.world.tpSetting[1]['x'],self.world.tpSetting[1]['y'],self.world.tpSetting[1]['r']-2)
						self.moveToX,self.moveToY = toX,toY
						self:moveTo(toX,toY,true)
						self.AIdirection = 0
						self:D("地图AI3018:"..self.itemID,"右边大于左边 右边的人去左边",self.world.tpZNum,self.world.tpYNum,self.AIdirection,toX,toY)
					end
					self.nextMoveAITime = self.moveToEndTime+0.5
					self.world.nextMoveAITime = self.moveToEndTime+0.5
				end

			end

			return true
		else
			self.moveAIone = false
			self.world.nextMoveAITime = 0
			self.AIdirection = 2
			self.nextMoveAITime = 0
			return SHeroInWorld3018.super._autoFight(self)
		end
	else
		return SHeroInWorld3018.super._autoFight(self)
	end
end



return SHeroInWorld3018
