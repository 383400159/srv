local SHero7 = class("SHero7", require("gameroom.hero.SHero")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @param actorID int - 游戏房玩家序号ID
-- @return null
function SHero7:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 


	if (self.className==nil) then 
		self.className = "SHero7" 
	end 
	--愤怒值
	self.SP = 0
	--愤怒最大值
	self.maxSP = 100


	SHero7.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)

end 

--重载AI
function SHero7:_autoFightToHero()

	--需要判断队友是否没血了
	--获得队友列表
	if self.world.heroNeedSkillID~=nil and self.world.heroNeedSkillID>0 then
	 
		ret = true
	else

	    ret = false
		if (self.teamOrig=="A") then
			teamlist=self.world.itemListFilter.heroTeamAList
		else
			teamlist=self.world.itemListFilter.heroTeamBList
		end
		local skill3 = self.attribute.skills[3]
		local skill2 = self.attribute.skills[2]  

		self:D("矮子的SKILLOPEN:",self.world.cjson.encode(self.attribute.SKILLOPEN))
		--近战嘲讽boss
		if (self.attribute.SKILLOPEN[3]==nil or self.attribute.SKILLOPEN[3]==1)  and skill3.lastCoolDownTime<self.world:getGameTime() then

			--PVP和gvb不同的处理方法
			if  self.world.tonumber(self.world.mapModel)==2 then
				
				--pvp处理控制自己的对手或者范围内对手
				local targetList = {}
				local visRange={posX=self.posX,posY=self.posY,radius=skill3.atkDis/self.world.setting.AdjustVisRange}

				local enemy = self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
				function(obj)
				 	ok = true
					if (value:isDead()) then ok =false end
					if (value.attribute.HP<=0) then ok =false end
					if (value.attribute.actorType~=0) then ok =false end
					if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
					if ok  then
						local d = value:colliding(visRange,0,0,self.itemID)
						if d>=0 then
							targetList[#targetList+1] = {id=value.itemID}
						end
					end
				end
				)

				if #targetList>0 then
					ret = self:skillAttack(3,self.itemID)
				end

			else
				--gvb处理 拉住boss仇恨
				local targetList = {}
				--local enemy=self:getEnemylist()
				local visRange={posX=self.posX,posY=self.posY,radius=skill3.useDis/self.world.setting.AdjustVisRange}
				local targetList = self.autoFightAI:__findTarget(1,visRange,false)
				--矮子强行只打boss 判断有没有boss 有boss切换目标
			  	if  self.world.tonumber(self.world.mapModel)~=2 then
					for k,v in pairs(targetList) do
						local obj  = self.world.allItemList[v["itemID"]]
						if obj~=nil and obj.attribute~=nil and obj.attribute.actorType==2 and obj.attackTarget~=nil and obj.attackTarget>0 then
							--判断boss的目标是不是矮子 不是则放嘲讽
							local obj1  = self.world.allItemList[obj.attackTarget]
							if obj1~=nil and obj1.attribute.roleId%5~=2 then
								ret = self:skillAttack(3,obj.itemID)
							end
						end
					end
				end
			end
		end


		
		--原地扫描附近队友
		if (self.attribute.SKILLOPEN[2]==nil or self.attribute.SKILLOPEN[2]==1)  and skill2.lastCoolDownTime<self.world:getGameTime()  and self.world.gameRoomSetting.ISGVB==1 then
			--需要救援的列表
			local targetList = {}
			local visRange={posX=self.posX,posY=self.posY,radius=skill2.atkDis/self.world.setting.AdjustVisRange}

			for k,value in pairs(teamlist) do
				ok = true
				if (not value:isDead()) then ok =false end
				if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
				if ok and (value.attribute.HP/value.attribute.MaxHP)<0.8 then
					local d = value:colliding(visRange,0,0,self.itemID)
					--判断他最近被击中过
					if d>=0 and self.lastAttackTime+2>self.world:getGameTime() then
						targetList[#targetList+1] ={itemID=value.itemID,hprate=value.attribute.HP/value.attribute.MaxHP} 
					end
				end
			end
			--赛选出最优的几个队友
			----debuglog(" skill3 AI targetList:"..self.world.cjson.encode(targetList))
			if #targetList>0 then

				self.world.tSort(targetList,function( a1,b1 )
								return a1['hprate'] < b1['hprate']
							end)

				local protectionID = targetList[1]['itemID']
				local obj = self.world.allItemList[protectionID] 
				--击中最近攻击队友的目标
				ret = self:skillAttack(2,obj.lastAttackID)
			end
		end

	end


	if not ret then
		SHero7.super._autoFightToHero(self) 
	end
end


--- init funtion 初始化属性参数
-- @param id int - role id
-- @param posX int - 起始坐标X
-- @param posY int - 起始坐标Y
-- @return null
function SHero7:__init(id,posX,posY)
	SHero7.super.__init(self,id,posX,posY) 
	self.maxSP=self.attribute.parameterArr.MAXSP
	self:addStatusList({zz=3,s=65,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.maxSP,zz=3},0.5)
	self:addStatusList({zz=3,s=66,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.SP,p2=1},0.5)
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SHero7:prepareHit(mode,adjTime,buff)  

	local hitValueBoth=SHero7.super.prepareHit(self,mode,adjTime,buff) 
	if mode==4 then
		--APADJ=0;ADADJ=150;APADJ2=20;PARALYSIS_RATE=100;BUFFTIME=0.5;CDTIME=30
		--CDTIME=15;HP_UP_RATE=100;DEF_UP_RATE=100;MDEF_UP_RATE=100;IMMUNEDEBUFF_RATE=100;ATKDIS_UPFIX_RATE=100;ATKDIS_UPFIX=150;ROLEBUFFSKILLA_RATE=100;ALLHURT_DOWN_RATE=100;BUFFTIME=7
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		local hitValueNew = self:getPrepareHithitValue()
		attributes['buffParameter'] = hitValueNew
		attributes['buffParameter']['APADJ'] = (attributes['buffParameter']['APADJ']~=nil and attributes['buffParameter']['APADJ'] or 0)+parameters.APADJ2 
		--attributes['buffParameter']['FIXHURT'] = 250
		attributes['buffParameter']['changeMode']=mode
		attributes['buffParameter']['RANGE'] = skill.atkDis
		attributes['buffParameter']['buffType'] = 1
		attributes['buffParameter']['buffIntervalTime'] = hitValueBoth['bulletTimeInterval2']
		attributes['BUFFTIME'] = hitValueBoth['duration2']
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,hitValueBoth['duration2'],{99},0,self.itemID,self.itemID,skill.hitTime+0.5)
		self:addBuff(buff) 
		
		self:useSP(parameters.USESPNUM)
	end

	if mode==3 then
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 
		self:adjSP(parameters.HURTRESPNUM)
	end
	return hitValueBoth 
end 

--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero7:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	local ret = SHero7.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	if ret>0 and mode==1 and hitValue['mode1step']~=nil and self.world.tonumber(hitValue['mode1step'])>0 then
		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters 
		--APADJ=0;ADADJ=70;HURTRESPNUM=1;HURTREHPNUM=0.1;HURTREHPMOVE=3
		-- local abclist = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"}
		-- local step=abclist[self.world.tonumber(hitValue['mode1step'])]
		-- if step=='c' then
		self:D("矮子普攻 ",self.world.tonumber(hitValue['mode1step']),parameters.HURTREHPMOVE )
		if self.world.tonumber(hitValue['mode1step'])==parameters.HURTREHPMOVE then
			local hitValueNew = table.deepcopy(self:getPrepareHithitValue())
			local rehp = self.attribute.MaxHP * parameters.HURTREHPNUM * 0.01
			if rehp<1 then
				rehp = 1
			end
			hitValueNew['FIXHURT']= -rehp
			self:directHurtToDalay(1,self.itemID,hitValueNew,0)
			self:D("矮子普攻 回血 ",self.world.tonumber(hitValue['mode1step']),parameters.HURTREHPMOVE,hitValueNew['FIXHURT'],self.attribute.MaxHP)
			self:addStatusList({s=93,r=self.world:getGameTime(),t=1,i=self.itemID},0)
		end
	end

	if ret>0 and mode==1 then
		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters 
		self:adjSP(parameters.HURTRESPNUM)
	end

	if ret>0 and mode==3 and hitValue['Effect']~=2 and hitValue['Effect']~=5 then
		local obj = self.world.allItemList[itemID] 
		--debuglog("矮子嘲讽 "..obj.itemID..obj.teamOrig.." "..obj.attribute.roleId)
		if self.teamOrig~=obj.teamOrig then
			local skill = self.attribute.skills[3] 
			local parameters = skill.parameters 


			local d =self.world.mPow(self.world.mPow(obj.posX-self.posX,2) + self.world.mPow(obj.posY-self.posY,2),0.5)
			--debuglog(itemID.." 2点之间的距离为.......:"..d)

			if d>1 then
				d=d-1
			end

			local toX,toY = self.world.map:getXYLength(obj.posX,obj.posY,self.posX,self.posY,d)
			local ret1
			--print("prepareHit 飞飞飞........ x tox y toy distance ",self.posX,toX,self.posY,toY,(skill.atkDis-parameters.MOVECUT)/self.world.setting.AdjustAttRange)
			ret1,toX,toY=self.world.map:findPointStraightLineNearest(obj.posX,obj.posY,obj.posX+toX,obj.posY+toY) 
			--实际距离求速度
			local sd = d
			local bulletSpeed = (sd/parameters.ABSORDTIME)*100
			--debuglog("飞行时间:"..parameters.ABSORDTIME)
			--debuglog("飞行距离:"..sd)
			--debuglog("飞行速度:"..bulletSpeed)
			obj:moveTo(toX,toY,false,5,bulletSpeed,0)

			-- hitValue['OUTCTL_RATE'] = parameters.OUTCTL_RATE2
			-- if obj.attribute.actorType==1 then
			-- 	hitValue['BUFFTIME'] = parameters.BUFFTIME2
			-- else
			-- 	hitValue['BUFFTIME'] = parameters.BUFFTIME3
			-- end
			local attributes = {}
			attributes['OUTCTL_RATE'] = parameters.OUTCTL_RATE2 
			if obj.attribute.actorType==1 then
				attributes['BUFFTIME'] = parameters.BUFFTIME2
			else
				attributes['BUFFTIME'] = parameters.BUFFTIME3
			end
			self:D("嘲讽晕多久",attributes['BUFFTIME'],self.world.cjson.encode(parameters))
			--ADADJ=300;HURTTRANSFERSP=1000;CDTIME=10;OUTCTL_RATE2=100;BUFFTIME2=2;BUFFTIME3=5
			--attributes['BUFFTIME'] = hitValue['BUFFTIME']
			local buff = require("gameroomcore.SBuff").new(self.world,obj:__skillID2buffID(0),attributes,attributes['BUFFTIME'],{},0,obj.itemID,obj.itemID)
			obj:addBuff(buff)

			obj.attackTarget = self.itemID

			--增加打boss的特殊效果
			if obj.attribute.actorType==2 then
				obj.BossHatredlist[#obj.BossHatredlist+1]={itemID=self.itemID,endTime=self.world:getGameTime()+parameters.BUFFTIME3} 
				obj:addStatusList({s=44,r=parameters.BUFFTIME3,t=self.world:getGameTime()+parameters.BUFFTIME3,i=obj.itemID})
			end
		
			-- 复制最高的仇恨值作为自己的仇恨值
			if not self.world.empty(obj.Hatredlist) then
				local maxHatred = 0
				for k,v in pairs(obj.Hatredlist) do
					if maxHatred<v then
						maxHatred=v
					end
				end
				obj.Hatredlist[""..self.itemID] = maxHatred
			end
		end
	end

	if mode==4 and ret>0 then
		self:addStatusList({s=93,r=self.world:getGameTime(),t=1,i=self.itemID},0)
	end


	return ret 
end 


--- 受傷害計算,调用SActor的hurted
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero7:hurted(itemID,bulletID,mode,hitValue,adjTime)
	local hurt = SHero7.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
	return hurt
end

function SHero7:checkMana(mode)
	if mode==4  then
		local skill = self.attribute.skills[mode] 
		local parameters = skill.parameters 
		 
		self:D("愤怒 ",self.world.cjson.encode(parameters))
		if self.SP<parameters.USESPNUM then
			return false
		end
	end
	return SHero7.super.checkMana(self,mode) 	
end

--- 自动移动chud
-- @return null
function SHero7:_autoMove()
	-- --debuglog("SHero:_autoMove")
	local ret=SHero7.super._autoMove(self)
	local moveRet=self.autoFightAI:autoMoveToAlerted()
	if not ret and not self.autoBlocked and self.AIlastMoveTime < self.world:getGameTime() and  not self:isDead() and not moveRet  and self.statusList[4007]==nil then
		self.autoFightAI:autoMoveToATKHero()
		self.AIlastMoveTime = self.moveToEndTime
	end
	return ret
end


function SHero7:adjSP(sp,force)

	self.SP = math.round(self.SP + sp, 1)
	if self.SP>self.maxSP then self.SP = self.maxSP end
	if self.SP>self.changePartSP then self.SP=self.changePartSP end

	if self.SP<1 then 
		self.SP = 0 
	end
	self:addStatusList({zz=3,s=66,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.SP,p2=(self:checkMana(4) and 0 or 1)},0)
	self:D("单次增加愤怒值:",sp,"总愤怒值:",self.SP)
end

function SHero7:useSP(sp)

	self.SP = math.round(self.SP - sp, 1)

	if self.SP<1 then 
		self.SP = 0 
	end
	self:addStatusList({zz=3,s=66,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.SP,p2=(self:checkMana(4) and 0 or 1)},0)
	self:D("单次使用愤怒值:",sp,"总愤怒值:",self.SP)
end



return SHero7 
