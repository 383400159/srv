local SHeroInWorld3016 = class("SHeroInWorld3016", require("gameroomcore.SHeroBase"))

function SHeroInWorld3016:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld3016.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.is41 = false
	debuglog("SHeroInWorld3016:ctor........")
end


function SHeroInWorld3016:skillAttackMode9CallBack(roleId,itemID,atkP)
	self:D("挖矿 回调",roleId,itemID)
	local obj = self.world.allItemList[itemID]
	if  obj~=nil and not obj:isDead() and obj.isEnd==nil and  self.world.tonumber(atkP)>0 then
		self:D("挖矿 成功",roleId,itemID,atkP)
		obj.isEnd = atkP
		self.is41 = true
		local attributes = table.deepcopy(self:getPrepareHithitValue())
		attributes['FIXHURT'] = 8
		self:directHurtToDalay(1,self.itemID,attributes,0)

		local status = obj.statusList[4135]
		obj:addStatusList({s=4135,r=self.world:getGameTime(),t=16,i=self.itemID,p1=status['p1'],p2=status['p2'],p3=status['p3'],p4=(obj.iscolor==atkP and 2 or 3),p5=1 })
		--刷新boss显示列表
		local bossObj = self:getBossObj()
		bossObj:syncQTE()
	end
end



--- move motion , call every update loop
-- @return null
function SHeroInWorld3016:move()

	--清除身上的4134
	local status4134 = self.statusList[4134]
	local status4137 = self.statusList[4137]
	local status999 = self.statusList[999]
	local status41 = self.statusList[41]
	if status4134~=nil and (status999~=nil or status41~=nil) then
		self:removeStatusList(4134)
	end

	if status4137~=nil and status4134==nil and status999==nil and status41==nil and not self.is41 then
		self:addStatusList({s=4134,r=self.world.gameTime,t=16,i=self.itemID,p1=status4137['p1'],p2=status4137['p2']},0)
	end

	if status4137==nil then
		self:removeStatusList(4134)
	end

	SHeroInWorld3016.super.move(self)
end



--- 设置自动跟随到达后回调
-- @param stopType int - 停止类型，0=手动停止，1=自动停止
-- @return null
function SHeroInWorld3016:setAutoToCallBack(stopType)
	--假如是自动停止则
	if stopType==1 then
		self:skillAttack(9)
	end
	return SHeroInWorld3016.super.setAutoToCallBack(self,stopType)
end



function SHeroInWorld3016:setAutoTo(itemID,stopType)
	return SHeroInWorld3016.super.setAutoTo(self,itemID,stopType)
end

function SHeroInWorld3016:getBossObj()
	local obj = self.world:getObjBySubName("BOSS1",self.world.itemListFilter.heroList)
	return obj
end

return SHeroInWorld3016
