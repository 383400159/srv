local SHeroInWorld5 = class("SHeroInWorld5", require("gameroomcore.SHeroBase"))

function SHeroInWorld5:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld5.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SHeroInWorld5