local SHeroInWorld1100 = class("SHeroInWorld1100", require("gameroomcore.SHeroBase"))

function SHeroInWorld1100:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld1100.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

function SHeroInWorld1100:prepareSkillAttackMode7(updateMove)
	return nil
end

return SHeroInWorld1100