local SHeroInWorld3017 = class("SHeroInWorld3017", require("gameroomcore.SHeroBase"))

function SHeroInWorld3017:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld3017.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	debuglog("SHeroInWorld3017:ctor........")
end


function SHeroInWorld3017:skillAttackMode9CallBack(roleId,itemID,atkP)
	self:D("挖矿 回调",roleId,itemID)
	local obj = self.world.allItemList[itemID]
	if  obj~=nil and not obj:isDead() and obj.isEnd==nil then
		self:D("挖矿 成功",roleId,itemID)
		obj.isEnd = true
		local attributes = table.deepcopy(self:getPrepareHithitValue())
		attributes['FIXHURT'] = 8
		attributes['DIZZYNOEFFECT_RATE'] = 100
		attributes['BUFFTIME'] = 15
		self:directHurtToDalay(1,self.itemID,attributes,0)
		self:addStatusList({s=76,r=self.world:getGameTime(),t=15,i=self.itemID},0.1)
		--结算坐骑	
		local obj = self.world.allItemList[obj.jyID]
		obj:addStatusList({s=4153,r=self.world.gameTime,t=99999,i=self.itemID,p1=self.itemID},0)
	end
end
--- 设置自动跟随到达后回调
-- @param stopType int - 停止类型，0=手动停止，1=自动停止
-- @return null
function SHeroInWorld3017:setAutoToCallBack(stopType)
	--假如是自动停止则
	if stopType==1 then
		self:skillAttack(9)
	end
	return SHeroInWorld3017.super.setAutoToCallBack(self,stopType)
end

return SHeroInWorld3017
