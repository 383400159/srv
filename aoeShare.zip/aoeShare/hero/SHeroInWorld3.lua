local SHeroInWorld3 = class("SHeroInWorld3", require("gameroomcore.SHeroBase"))

function SHeroInWorld3:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld3.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.sharedID = 0
	self.sharedproHP = 1
	self.preInCam = 0				--列队入镜流程序号
	self.inCamTime = 0			--入镜等待结束时间 
	self.inTransitDoor = false	--是否在传送门内
end


--- 角色死亡,call 父类
function SHeroInWorld3:goToDead(itemID,mode,adjTime,bonus)  
	if self.world.gameFlag['passTransitDoorID'][''..self.itemID]~=nil then
		if self.sharedID>0 and self.world.allItemList[self.sharedID]~=nil then
			local shareObj = self.world.allItemList[self.sharedID]
			self:moveTo(shareObj.posX,shareObj.posY,true,1,99999)
			shareObj:setShared(0)
			shareObj:addStatusList({s=42,r=self.world:getGameTime(),t=999},0)
			shareObj.attribute.HP = 0
			shareObj:directHurt(self.itemID,1,{},0)
			self:setShared(0)
		end
		self.world.gameFlag['passTransitDoorNum'] = self.world.gameFlag['passTransitDoorNum'] - 1
		self.world.gameFlag['passTransitDoorLastNum'] = self.world.gameFlag['passTransitDoorLastNum'] + 1
		self.world.gameFlag['passTransitDoorID'][''..self.itemID] = nil
		self.world.transitDoor:addStatusList({s=4002,r=self.world.gameTime,t=99999,i=self.world.transitDoor.itemID,p1=self.world.gameFlag['passTransitDoorLastNum']},0.2)
	end
	if self.statusList[4007]~=nil then
		if self.sharedID>0 and self.world.allItemList[self.sharedID]~=nil then
			local shareObj = self.world.allItemList[self.sharedID]
			self:moveTo(shareObj.posX,shareObj.posY,true,1,99999)
			self:setShared(0)
			shareObj:setShared(0)
			self:removeStatusList(4007)
			self.AIlastMoveTime = self.world.gameTime+2
			self:removeStatusList(4010)
			self:removeBUff('INVICINBLE')
			shareObj:addStatusList({s=42,r=self.world:getGameTime(),t=999},0)
			-- shareObj.attribute.HP = 0
			-- shareObj:directHurt(self.itemID,1,{},0)
		end
	end
	SHeroInWorld3.super.goToDead(self,itemID,mode,adjTime,bonus) 
end 


function SHeroInWorld3:prepareSkillAttackMode7(updateMove)
	return nil
end

return SHeroInWorld3