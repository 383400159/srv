local SHeroInWorld3009 = class("SHeroInWorld3009", require("gameroomcore.SHeroBase"))

function SHeroInWorld3009:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld3009.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


function SHeroInWorld3009:skillAttackMode9CallBack(roleId,itemID)
	if self.world.allItemList[itemID]~=nil and not self.world.allItemList[itemID]:isDead() then
		self.world.allItemList[itemID]:removeStatusList(4101)
	end
end


function SHeroInWorld3009:prepareSkillAttackMode7(updateMove)
	return nil
end

return SHeroInWorld3009