local SHeroInWorld6 = class("SHeroInWorld6", require("gameroomcore.SHeroBase"))

function SHeroInWorld6:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld6.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

return SHeroInWorld6