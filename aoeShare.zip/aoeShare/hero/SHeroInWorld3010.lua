local SHeroInWorld3010 = class("SHeroInWorld3010", require("gameroomcore.SHeroBase"))

function SHeroInWorld3010:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld3010.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	--boss吸血专用 附带中毒伤害
	self.mode3Num = 0
	self.mode3NextTime = 0
end

function SHeroInWorld3010:getBossObj()
	local obj = self.world:getObjBySubName("BOSS1",self.world.itemListFilter.heroList)
	return obj
end

--- fight motion , call every update loop
-- @return null
function SHeroInWorld3010:fight()
	-- debuglog("甲虫大招 持续伤害 fight:")
	if self.statusList[4090]==nil then
		self.mode3Num = 0
		self.mode3NextTime = 0
	end

	if self.statusList[4090]~=nil and self.world.gameTime > self.mode3NextTime then
		local obj = self:getBossObj()
		local skill = obj.attribute.skills[3] 
		local parameters = skill.parameters 

		self.mode3Num = self.mode3Num + 1
		local hitValueNew = {}
		hitValueNew['FIXHURT'] = (15/parameters.EXPECTNUM)*0.0154*(2.718^(0.1555*self.mode3Num))*self.attribute.MaxHP
 		--hitValueNew['FIXHURT']  = 100*self.mode3Num
 		debuglog("甲虫大招 持续伤害 mode3Num:"..self.mode3Num.." FIXHURT:"..hitValueNew['FIXHURT'])
  		self:directHurt(self.itemID,1,hitValueNew,0) 

  		if ((obj.attribute.HP/obj.attribute.MaxHP)*100<(parameters.P3BOSSREHPMAX-parameters.BOSSREHP) and self.world.partType==3) or self.world.partType<3  then
  			debuglog("甲虫大招 BOSS回血前:"..obj.attribute.HP)
			local bossHitValueNew = {}
	 		bossHitValueNew['FIXHURT']  = -obj.attribute.MaxHP*parameters.BOSSREHP*0.01
	  		obj:directHurt(obj.itemID,1,bossHitValueNew,0) 
	  		debuglog("甲虫大招 BOSS回血后:"..obj.attribute.HP.." FIXHURT:"..bossHitValueNew['FIXHURT'].." MaxHP:"..obj.attribute.MaxHP.." BOSSREHP:"..parameters.BOSSREHP*0.01)
	  		self.mode3NextTime = self.world.gameTime + parameters.HURTINTERVAL

  		end
  		obj:addStatusList({s=4095,r=self.world.gameTime,t=parameters.HURTINTERVAL,i=obj.itemID})
	end

	SHeroInWorld3010.super.fight(self) 
end

--- 角色死亡,call 父类
function SHeroInWorld3010:goToDead(itemID,mode,adjTime,bonus)  
	SHeroInWorld3010.super.goToDead(self,itemID,mode,adjTime,bonus) 
	self:removeStatusList(4090)
end 


function SHeroInWorld3010:prepareSkillAttackMode7(updateMove)
	return nil
end

return SHeroInWorld3010
