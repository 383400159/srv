local SHeroInWorld3014 = class("SHeroInWorld3014", require("gameroomcore.SHeroBase"))

function SHeroInWorld3014:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld3014.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


function SHeroInWorld3014:skillAttackMode9CallBack(roleId,itemID)
	self:D("挖矿 回调",roleId,itemID)
	local obj = self.world.allItemList[itemID]
	if  obj~=nil and not obj:isDead() and obj.isEnd==nil then
		self:D("挖矿 成功",roleId,itemID)
		obj.isEnd = true
	end
end

return SHeroInWorld3014
