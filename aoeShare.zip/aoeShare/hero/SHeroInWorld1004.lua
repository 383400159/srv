local SHeroInWorld1004 = class("SHeroInWorld1004", require("gameroomcore.SHeroBase"))

function SHeroInWorld1004:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld1004.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end

function SHeroInWorld1004:prepareSkillAttackMode7(updateMove)
	return nil
end

--- 复活, 游戏loop
-- @param null
-- @return null
function SHeroInWorld1004:revive()
	--GVB 没复活
	if self.deadTime<=self.world:getGameTime() then
		self:removeStatusList(9)
		self.towerComplete = 0
		if table.nums(self.buffList)>0 then
			local recal = false
			local skillID = 0
			for k,v in pairs(self.buffList) do
				skillID = v.buffID%1000000
				if skillID<990000 then
					self.buffList[k].isRemove = 1
					local statusNum = self:__buffID2StatusNum(v.buffID,v.buffParameter['statusnum'])
					if self.statusList[statusNum]~=nil and v.buffID>10000 then
						self:removeStatusList(statusNum)
					end
					recal = true
				end
			end
			if recal then
				self:reCalBuff()
			end
		end
		self.attribute.HP = self.attribute:getMaxHP()
		self.attribute.MP = self.attribute:getMaxMP()
		local pos = self.world.playerPoint

		local r1 = self.world.formula:getRandnum(1,#pos)
		self.rebirthX=pos[r1][1]
		self.rebirthY=pos[r1][2]

		if self.rebirthX~=0 and self.rebirthY~=0 then
			self.posX = self.rebirthX
			self.posY = self.rebirthY
		else
			self.posX = self.initX
			self.posY = self.initY
		end
		self:__findingZone()
		self.skeleton = 0
		self.lastWalkTime = self.world:getGameTime()
		self.invincibleTime = self.world:getGameTime() + 1.5
		if self.rebirthX~=0 and self.rebirthY~=0 then
			self:moveTo(self.rebirthX,self.rebirthY,true,1)
			self.rebirthX = 0
			self.rebirthY = 0
		else
			self:moveTo(self.initX,self.initY,true,1)
		end
		self.syncMsg['m']['d']=0.05
		--self.syncMsg['m']=nil
		self.attackTarget = nil
		self.prepareSkillAttackNum = 0
		self.status = 0
		self:setCounter('revive')
		self:__getInfo()
		self:syncStatus()

		local result=self:getAllInfo(0,true)
		result['s'] = 1
		self:updateSyncMsg({i=result})
--		debuglog("血条bug revive .......itemID:"..self.itemID.." revive ..getMaxMP:"..self.attribute:getMaxMP())
	end

end

function SHeroInWorld1004:useWorldSkill(skillID)
	--给水晶回血
	if skillID==1 then
		self.world:addBaseHP()
	else
		self.world:useBaseSkill(skillID)
	end
end

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SHeroInWorld1004:prepareHit(mode,adjTime,buff)
	local hitValueBoth=SHeroInWorld1004.super.prepareHit(self,mode,adjTime,buff)

	if mode==2 then
		self:useWorldSkill(4)	
	end
	
	return hitValueBoth 
end 

return SHeroInWorld1004