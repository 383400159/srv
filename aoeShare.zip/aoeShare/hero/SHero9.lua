local SHero9 = class("SHero9", require("gameroom.hero.SHero")) 
 
--- Constructor
-- @param world object - world object
-- @param id int - roleID
-- @param team int - 游戏中的分队
-- @param posX int - 起始点X坐标
-- @param posY int - 起始点Y坐标
-- @param loginID int - 玩家角色名称
-- @param skinNum int - 皮肤
-- @param actorID int - 游戏房玩家序号ID
-- @return null
function SHero9:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 

	if (self.className==nil) then 
		self.className = "SHero9" 
	end 

	--SPa是圣印 SPb邪印
	self.SPa=0
	self.SPb=0
	--愤怒列表
	self.SPList = {}
	self.maxSP=8
	--单次攻击有没有增加愤怒值
	self.addSPMode = 0

	--当前攻击模式
	self.mode1ATKMode=1
	--4变5
	self.mode5time = 0
	self.mode5in1time = 0
	--反击时间
	self.mode5timefj = 0

	self.mode7time = 0
	--天启者天赋减cd次数
	self.CDTIMECLEARFIXNUM=0

	self.mode1bool = false
	--debuglog('jaylog SHero9:ctor before super')
	SHero9.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	--debuglog('jaylog SHero9:ctor after super')

	--AI释放大招开始SP类型
	self.mode4AItype = 0
	--下次切换AI行为时间
	self.mode4AINextTime = 0
	self.mode2AINextTime = 0
	--当前已经释放AI技能的次数
	self.mode4AINum = 0
	if self.world.gameRoomSetting.ISGVB==1 then
		self.attribute.skills[3].atkDis = 999999
	end

end 



--重载AI
function SHero9:_autoFightToHero()

	--需要判断队友是否没血了
	--获得队友列表
	if self.world.heroNeedSkillID~=nil and self.world.heroNeedSkillID>0 then
		ret = true
	else

		ret = false
		if (self.teamOrig=="A") then
			teamlist=self.world.itemListFilter.heroTeamAList
		else
			teamlist=self.world.itemListFilter.heroTeamBList
		end
		local skill4 = self.attribute.skills[4]
		local skill3 = self.attribute.skills[3]  
		local skill2 = self.attribute.skills[2]  
		
		--原地扫描附近队友
		if (self.attribute.SKILLOPEN[3]==nil or self.attribute.SKILLOPEN[3]==1)  and skill3.lastCoolDownTime<self.world:getGameTime() then
			--需要回复的列表
			local targetList = {}
			local visRange={posX=self.posX,posY=self.posY,radius=skill3.atkDis/self.world.setting.AdjustVisRange}

			for k,value in pairs(teamlist) do
				ok = true
				if (value:isDead()) then ok =false end
				if (value.attribute.HP<=0) then ok =false end
				if (value.attribute.actorType~=0) then ok =false end
				if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
				if ok and (value.attribute.HP/value.attribute.MaxHP)<0.8 then
					local d = value:colliding(visRange,0,0,self.itemID)
					if d>=0 then
						targetList[#targetList+1] = {id=value.itemID,hpScale=(value.attribute.HP/value.attribute.MaxHP)*100}
					end
				end
			end
			--debuglog("奶爸AI mode3 AI targetList:"..self.world.cjson.encode(targetList))
			-- if #targetList>0 then
			-- 	self.world.tSort(targetList,function( a1,b1 )
			-- 						return a1['hpScale'] < b1['hpScale']
			-- 					end)
			-- 	-- ret = self:skillAttack(3,self.itemID)
			-- 	local obj1 = self.world.allItemList[targetList[1]['id']]
			-- 	ret = self:skillAttack(4,0,obj1.posX,obj1.posY,false,true)
			-- end
			

			--赛选出最优的几个队友
			----debuglog(" skill3 AI targetList:"..self.world.cjson.encode(targetList))
			if #targetList>0 or (self.attribute.HP/self.attribute.MaxHP)<0.8 then
				ret = self:skillAttack(3,self.itemID)
			end
		end

				--刷新AI4行为
		if self.world:getGameTime()>self.mode4AINextTime  then
			self.mode4AItype = 1
			self.mode4AINextTime = self.world:getGameTime() + 60
			self.mode4AINum = self.world.formula:getRandnum(0,6)
		end
		if self.world:getGameTime()>self.mode2AINextTime and skill2.lastCoolDownTime<self.world:getGameTime()  then
			self.mode2AINextTime = self.world:getGameTime() + self.world.formula:getRandnum(55,90)
			ret = self:skillAttack(2)
		end

		--远程甩技能回血
		self:D("牧师甩大招:",self.mode4AINum,self.SPa,self.SPb,self.mode4AINextTime,self.world:getGameTime())
		if (self.attribute.SKILLOPEN[4]==nil or self.attribute.SKILLOPEN[4]==1) and (self.SPa+self.SPb)>=self.mode4AINum  and skill4.lastCoolDownTime<self.world:getGameTime() and self.world.gameRoomSetting.ISGVB==1 then
			--需要回复的列表
			local targetList = {}
			for k,value in pairs(teamlist) do
				ok = true
				if (value:isDead()) then ok =false end
				if (value.attribute.HP<=0) then ok =false end
				if (value.attribute.actorType~=0) then ok =false end
				if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil) then ok = false end
				if ok and (value.attribute.HP/value.attribute.MaxHP)<0.7 then
					targetList[#targetList+1]={id=value.itemID,hpScale=(value.attribute.HP/value.attribute.MaxHP)*100}
				end
			end
			--debuglog("奶爸AI AI targetList:"..self.world.cjson.encode(targetList))
			--赛选出最优的几个队友
			local dislist = {}
			if #targetList>0 then
				--根据生命比例选择第一优先目标
				self.world.tSort(targetList,function( a1,b1 )
									return a1['hpScale'] < b1['hpScale']
								end)
				--debuglog("奶爸AI targetList:"..self.world.cjson.encode(targetList))
				local obj1 = self.world.allItemList[targetList[1]['id']] 
				for i=2,#targetList do
					local obj2 = self.world.allItemList[targetList[i]['id']] 
					local d = self.world.mPow(self.world.mPow(obj1.posX-obj2.posX,2) + self.world.mPow(obj1.posY-obj2.posY,2),0.5)	
					if d<(skill4.atkDis/self.world.setting.AdjustVisRange) and (obj2.attribute.HP/obj2.attribute.MaxHP)<0.7 then
						dislist[#dislist+1] ={id=targetList[i]['id'],DIS=d} 
					end
				end	
				self.world.tSort(dislist,function( a1,b1 )
									return a1['DIS'] < b1['DIS']
								end)
				--根据距离选择最佳投放点
				if #dislist>0 then
					local obj3 = self.world.allItemList[dislist[1]['id']] 
					--debuglog("奶爸AI 加血  主联ID:"..obj1.itemID.." 共联ID:"..dislist[1]['id'].." posX:"..obj1.posX.." posY:"..obj1.posY.." posX1:"..obj3.posX.." posY1:"..obj3.posY)
					ret = self:skillAttack(4,0,(obj3.posX+obj1.posX)/2,(obj3.posY+obj1.posY)/2,false,true)
					--ret = self:skillAttack(4,targetList[1]['id'])
				else
					--debuglog("奶爸AI 加血  非共联ID:"..obj1.itemID.." posX:"..obj1.posX.." posY:"..obj1.posY)
					ret = self:skillAttack(4,obj1.itemID)
				end

			end
		end

	end

	if not ret then
		SHero9.super._autoFightToHero(self) 
	end
end

function SHero9:_autoFightSkillToHero()
	local targetID,skillID,cdTime
	local heroSkillList = self.attribute.AIRoleSetting['normalSkillList']
	local newSkillList = {}
	--重载掉狂战士的大招
	if self.mode4AItype~=0 then
		for k,v in pairs(heroSkillList) do
			if v~=4 or (v==4 and (self.SPa+self.SPb)>=self.mode4AINum) then
				newSkillList[#newSkillList+1]=v
			end
		end
	else
		newSkillList = heroSkillList
	end
	if self.onlySimpleAttack~=nil and self.onlySimpleAttack then
		targetID,skillID,cdTime=self.autoFightAI:autoFightToHero({})
	else
		targetID,skillID,cdTime=self.autoFightAI:autoFightToHero(newSkillList)
	end
	return targetID,skillID,cdTime
end



--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SHero9:goToDead(itemID,mode,adjTime,bonus)  
	SHero9.super.goToDead(self,itemID,mode,adjTime,bonus) 
end 


--- init funtion 初始化属性参数
-- @param id int - role id
-- @param posX int - 起始坐标X
-- @param posY int - 起始坐标Y
-- @return null
function SHero9:__init(id,posX,posY)
	SHero9.super.__init(self,id,posX,posY) 
	self.maxSP=self.attribute.parameterArr.MAXSP
	--debuglog("天启者最大MAXSP:"..self.maxSP)
	self:addStatusList({zz=3,s=61,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.maxSP,zz=3},0.5)
	self:addStatusList({zz=3,s=78,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=1},0.5)
	self:addStatusList({zz=3,s=62,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.SPa,p2=self.SPb},0.5)
	-- if self.world.tonumber(self.world.mapModel)==9005 then
	-- 	self:adjSP('a',self.maxSP/2)
	-- 	self:adjSP('b',self.maxSP/2)
	-- end

end


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SHero9:prepareHit(mode,adjTime,buff)  

	self.addSPMode = 0
	self.CDTIMECLEARFIXNUM = 0

	local hitValueBoth=SHero9.super.prepareHit(self,mode,adjTime,buff) 

	--ALLHURT_DOWN=50;SPMAXUP=5;SEGETRANDOM=5;CDTIME=25;BUFFTIME=10
	if mode==5 then
		local skill = self.attribute.skills[5] 
		local parameters = skill.parameters
		self.mode5timefj = parameters.BUFFTIME + self.world:getGameTime()
		-- self:addStatusList({s=1005,r=self.world:getGameTime(),t=parameters.CDTIME,i=self.itemID},adjTime)
		-- self:addStatusList({s=61,r=self.world:getGameTime(),t=99,i=self.itemID,p1=self.maxSP},0)
		-- local randA = self.world.formula:getRandnum(1,parameters.SEGETRANDOM)
		-- self:adjSP("a",randA)
		-- self:adjSP("b",parameters.SEGETRANDOM-randA)
		-- self.attribute.skills[4].lastCoolDownTime = self.attribute.skills[4].lastCoolDownTime - parameters.BUFFCDTIME
		-- self:syncSkill(0)

		--添加团队免伤
		local attributes = {}
		attributes['buffParameter']={}
		attributes['BUFFONLY']=1
		attributes['INEVITABLEHIT'] = 1
		attributes['buffParameter']['RANGE'] = parameters.RANGE
		if self.world.gameRoomSetting.ISGVB==1 then
			attributes['buffParameter']['RANGE'] = 99999
		end
		-- attributes['buffParameter']['FIXHURT'] =   8
		attributes['buffParameter']['BEALLHURT_DOWN'] = parameters.BEALLHURT_DOWN2
		attributes['buffParameter']['BEALLHURT_DOWN_RATE'] = parameters.BEALLHURT_DOWN_RATE2
		attributes['buffParameter']['ADDSTATUS'] = parameters.MSHPEXTRA
		attributes['buffParameter']['ADDSTATUSTIME'] = 0.5
		attributes['buffParameter']['BUFFTIME'] = 0.5
		attributes['buffParameter']['buffIntervalTime'] = 0.5
		attributes['buffParameter']['buffType'] = 5
		attributes['buffParameter']['Effect'] = -1
		-- attributes['BUFFTIME'] = 0.5
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,parameters.BUFFTIME,{99},0,self.itemID,self.itemID,0)
		--buff.debug = true
		self:addBuff(buff)
		
		--天赋团队请buff
		-- if parameters.IMMUNECONTROLTEAM~=nil then
			
		-- 	local visRange = {posX=self.posX,posY=self.posY,radius=(skill.atkDis/self.world.setting.AdjustAttRange)}
		-- 	----debuglog('jaylog useDis:'..skill.useDis..' AdjustAttRange:'..self.world.setting.AdjustAttRange)
		-- 	local dtlist = {}
		-- 	local team = self.world:runTargetTypeFilter(11,self.team,self.itemID,{},
		-- 	function(obj)
		-- 	 	if obj.teamOrig==self.teamOrig then
		-- 			ok = true
		-- 			if (obj:isDead()) then ok = false end
		-- 			----debuglog('jaylog ok:'..ok)
		-- 			if ok then
		-- 				local d = obj:colliding(visRange,0,0,self.itemID)
		-- 				----debuglog('jaylog is colliding:'..obj.itemID..' d:'..d)
		-- 				if (d>=0) then 
		-- 					dtlist[#dtlist+1] = obj
		-- 				end
		-- 			end
		-- 		end
		-- 	end
		-- 	)
		-- 	local IMMUNECONTROLtb = {
		-- 		DIZZY = 0,
		-- 		SILIENCE = 0,
		-- 		OUTCTL = 0,
		-- 		STONE = 0,
		-- 		PARALYSIS = 0,
		-- 		FROZEN = 0,
		-- 		SLEEP = 0,
		-- 	}
			
		-- 	--天赋 移除所有的减益buff
		-- 	for key,obj in pairs(dtlist) do
		-- 		for k,v in pairs(IMMUNECONTROLtb) do
		-- 			if obj.attribute.buffAttribute[k]>0 then
		-- 				obj:removeBUff(k)
		-- 			end
		-- 		end
		-- 	end

		-- end

		--天赋添加一个群体aoe加各种buff
		--天赋 提升治疗量 
		-- if parameters.BECURETEAM~=nil then
		-- 	local hitValue = self:getPrepareHithitValue()
		-- 	self:D("天赋 友军治疗提升")
		-- 	hitValue['BECURE_UP'] = parameters.BECURE_UP2
		-- 	hitValue['BECURE_UP_RATE'] = parameters.BECURE_UP_RATE2
		-- 	hitValue['BUFFTIME'] = parameters.BUFFTIME2
		-- 	self:directFightAuratoDalay(5,self.itemID,hitValue,{posX=self.posX,posY=self.posY,RANGE=skill.atkDis},skill.hitTime) 
		-- end
		-- --天赋 免控3s 
		-- if parameters.IMMUNECONTROLTEAM~=nil then
		-- 	local hitValue = self:getPrepareHithitValue()
		-- 	hitValue['IMMUNECONTROL_RATE'] = parameters.IMMUNECONTROL_RATE3
		-- 	hitValue['BUFFTIME'] = parameters.BUFFTIME3
		-- 	self:directFightAuratoDalay(5,self.itemID,hitValue,{posX=self.posX,posY=self.posY,RANGE=skill.atkDis},skill.hitTime) 
		-- end

	end

	--HURTAD_HURT=30;HURTAP_HURT=30;BUFFTIME=10;COUNTER_RATE=10;ADADJ2=0;APADJ2=0;HURTAD_HURT2=100;HURTAD_HURT_RATE2=100;BUFFTIME2=5;CDTIME=30
	if mode==7 then
		local skill = self.attribute.skills[7] 
		local parameters = skill.parameters
		local attributes = {}
		attributes['HURTAD_HURT'] = parameters.HURTAD_HURT2
		attributes['HURTAD_HURT_RATE'] = parameters.HURTAD_HURT_RATE2
		attributes['HURTAP_HURT'] = parameters.HURTAP_HURT2
		attributes['HURTAP_HURT_RATE'] = parameters.HURTAP_HURT_RATE2
		attributes['BUFFTIME'] = parameters.BUFFTIME2
		local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID,0),attributes,parameters.BUFFTIME2,{},0,self.itemID,self.itemID,0)
		self:addBuff(buff)
	end

	if mode==3 then
		--debuglog("添加一个群体aoe...........0")
		local skill3 = self.attribute.skills[3] 
		local parameters3 = skill3.parameters 

		--APADJ3=100;EVILTRANSFERAP3=50;APADJ2=100;SEALTRANSFERAP2=50;CDTIME=10
		--local attackRange = {posX=self.posX,posY=self.posY,radius=skill3.atkDis/self.world.setting.AdjustAttRange} 

		local hitValueNew = self:getPrepareHithitValue()
		--debuglog("parameters:..."..self.world.cjson.encode(parameters3))
		hitValueNew['skillID'] = 3
		hitValueNew['APADJ'] = (parameters3.APADJ3 + (hitValueNew['APADJ']~=nil and hitValueNew['APADJ'] or 0))
		hitValueNew['BUFFTIME'] = parameters3.BUFFTIME
		self:directFightAuratoDalay(3,0,hitValueNew,{posX=self.posX,posY=self.posY,RANGE=parameters3.GVBHURTRANGE},parameters3.HURTHITTIME)

		-- if hitValueBoth['SHIELDATK']~=nil and hitValueBoth['SHIELDATK']>0 then
		-- 	hitValueBoth['HPEXTRA_UPFIX'] = hitValueBoth['SHIELDATK']*0.01*hitValueBoth['ATK']
		-- 	hitValueBoth['HPEXTRA_UPFIX_RATE'] = 100
		-- end

		-- --天赋 受攻击的敌人物防和魔防下降10%/20%/30%
		-- if parameters3.BEHURTMDDOWN~=nil then
		-- 	local hitValueNew = self:getPrepareHithitValue()
		-- 	--debuglog("parameters:..."..self.world.cjson.encode(parameters3))
		-- 	hitValueNew['skillID'] = 3
		-- 	hitValueNew['DEF_DOWN_RATE'] = 100
		-- 	hitValueNew['MDEF_DOWN_RATE'] = 100
		-- 	hitValueNew['DEF_DOWN'] = parameters3.DEF_DOWN2
		-- 	hitValueNew['MDEF_DOWN'] =  parameters3.MDEF_DOWN2
		-- 	hitValueNew['BUFFTIME'] = parameters3.BUFFTIME2
		-- 	self:directFightAuratoDalay(3,0,hitValueNew,{posX=self.posX,posY=self.posY,RANGE=skill3.atkDis},parameters3.HURTHITTIME)
		-- end
		-- --天赋 沉默
		-- if parameters3.BEHURTSILIENCE~=nil then
		-- 	local hitValueNew = self:getPrepareHithitValue()
		-- 	--debuglog("parameters:..."..self.world.cjson.encode(parameters3))
		-- 	hitValueNew['skillID'] = 3
		-- 	hitValueNew['SILIENCE_RATE'] = parameters3.SILIENCE_RATE3
		-- 	hitValueNew['BUFFTIME'] = parameters3.BUFFTIME3
		-- 	self:directFightAuratoDalay(3,0,hitValueNew,{posX=self.posX,posY=self.posY,RANGE=skill3.atkDis},parameters3.HURTHITTIME)
		-- end

		-- --天赋 友军攻击提升
		-- if parameters3.ATKTEAM~=nil  then
		-- 	local hitValue = self:getPrepareHithitValue()
		-- 	self:D("天赋 友军攻击提升")
		-- 	hitValue['ATK_UP_RATE'] = parameters3.ATK_UP_RATE2
		-- 	hitValue['ATK_UP'] = parameters3.ATK_UP2
		-- 	hitValue['BUFFTIME'] = parameters3.BUFFTIME2
		-- 	self:directFightAuratoDalay(3,self.itemID,hitValue,{posX=self.posX,posY=self.posY,RANGE=skill3.atkDis},parameters3.HURTHITTIME) 
		-- end
	end

	if mode==4  then
			--APADJ2=0,17,34,51,69,87,106,125,144,163,183,203,224,245,266,287,320,354,390,443,500;SENSE_RATE2=0,100;BUFFTIME5=3
			--debuglog("添加一个群体aoe...........0")
			local skill4 = self.attribute.skills[4] 
			local parameters4 = skill4.parameters 


			-- local attackRange = {posX=self.lastBulletPositionX,posY=self.lastBulletPositionY,radius=skill4.atkDis/self.world.setting.AdjustAttRange} 

			local hitValueNew = self:getPrepareHithitValue()
			-- --debuglog("parameters:..."..self.world.cjson.encode(parameters4))
			-- hitValueNew['skillID'] = 4
			-- hitValueNew['APADJ'] = parameters4.APADJ3 + (hitValueNew['APADJ']~=nil and hitValueNew['APADJ'] or 0)
			-- --hitValueNew['SENSE_RATE'] = parameters.SENSE_RATE2
			-- hitValueNew['BUFFTIME'] = parameters4.BUFFTIME
			-- local bullet = require("gameroomcore.SBullet").new(self.world,4,self.itemID,skill4.hitTime,0,self.lastBulletPositionX,self.lastBulletPositionY)
			-- --self:directFightAuratoDalay(1,attackRange,hitValueNew,0,skill4.angle,skill4.degree)
			-- bullet:directFightAura(1,attackRange,hitValueNew,bullet.attr.angle,skill4.degree) 
			-- bullet:setDead() 
			-- --debuglog("添加一个群体aoe...........")
			--APADJ3=100;EVILTRANSFERAP3=100;APADJ2=100;SEALTRANSFERAP2=100;CDTIME=15
			local creatureID=self.world:addCreature(self.world.tostring(parameters4.ENEMYID),self.teamOrig,self.lastBulletPositionX,self.lastBulletPositionY,self,1,0)
			local obj  = self.world.allItemList[creatureID]
			self.creatureList[#self.creatureList+1]=creatureID  
			local attributes = {} 
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			attributes['buffParameter']=hitValueNew
			attributes['buffParameter']['changeMode']=mode
			attributes['buffParameter']['RANGE'] = skill4.atkDis
			attributes['buffParameter']['SENSE_RATE'] = hitValueBoth['SENSE_RATE']
			attributes['buffParameter']['BUFFTIME'] = hitValueBoth['BUFFTIME']
			local hurtUp = self.SPb*parameters4.EVILTRANSFERAP3*0.01
			--天赋 邪印效果提升20%/40%/60%/80%/100% 
			-- if parameters4.EVILEFFECTUP~=nil then
			-- 	hurtUp = hurtUp * (1+parameters4.EVILEFFECTUP*0.01)
			-- end
			-- --天赋 图腾作用范围内，受击目标受到治疗下降10%/20%/30%/40%/50%
			-- if parameters4.BECURESKILL~=nil then
			-- 	attributes['buffParameter']['BECURE_DOWN_RATE'] = hitValueBoth['BECURE_DOWN_RATE2']
			-- 	attributes['buffParameter']['BECURE_DOWN'] = hitValueBoth['BECURE_DOWN2']
			-- 	attributes['buffParameter']['BUFFTIME'] = hitValueBoth['BUFFTIME2']
			-- end
		
			self:D("天启者 伤害量增加:",(1+hurtUp))
			attributes['buffParameter']['APADJ'] = (parameters4.APADJ3 + (hitValueNew['APADJ']~=nil and hitValueNew['APADJ'] or 0))*(1+hurtUp)
			----debuglog("jaylog addCreature  creatureID:"..creatureID)
			attributes['buffParameter']['buffType'] = 1			--parameters.PASSNUM
			attributes['buffParameter']['buffIntervalTime'] = skill4.bulletTimeInterval
			attributes['BUFFTIME'] = parameters4.BUFFTIME
			local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill4.skillID),attributes,skill4.duration,{99},0,self.itemID,obj.itemID,skill4.hitTime)
			--buff.debug = true
			--self:addBuff(buff)
			obj:addBuff(buff)
			obj:setDeadTime(skill4.duration+skill4.hitTime+0.05) 
			obj:addStatusList({s=983,r=self.world:getGameTime(),t=99999,i=self.itemID},0)
			hitValueBoth['SENSE_RATE'] = 0
			-- local customize={attackMode=3,degree=0,AtkDis=parameters['=']['RANGE'][level],BulletSpeed=99999,targetType=skill.targetType} 
			-- hitValueBoth['E']['CHECK']=obj.itemID 
			-- self.world:addBullet(mode,self.itemID,adjTime+self.world:getGameTime()+skill.HitTime+delay,self.itemID,obj.posX,obj.posY,false,hitValueBoth,customize) 
		
	end

	-- if self.mode5in1time>self.world:getGameTime() and itemID~=self.itemID then
	-- 	if mode==1 then
	-- 		--BLEED_HURTFIX_RATE2=0,3,5,8,11,14,17,20,23,26,29,32,36,39,42,46,51,56,62,70,80
	-- 		local skill = self.attribute.skills[5] 
	-- 		local parameters = skill.parameters 
	-- 		hitValueBoth['SENSE_RATE'] = parameters.SENSE_RATE2
	-- 		hitValueBoth['BUFFTIME'] = parameters.BUFFTIME6
	-- 	end
	-- end

	if mode==1 then
		self.mode1bool = true
	end

	if mode==2 then
		if self.mode1ATKMode==1 then
			self.mode1ATKMode=10
			self:addStatusList({zz=3,s=78,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.mode1ATKMode},0)
		else
			self.mode1ATKMode=1
			self:addStatusList({zz=3,s=78,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.mode1ATKMode},0)
		end
	end

	--消耗所有的印
	if  mode==4 then
		self.mode4REHPSP = self.SPa 
		self:useSP()
	end


	return hitValueBoth 
end 

--设置生邪印 atkMode==1 邪 反之圣
function SHero9:setMode2ATKMode(atkMode)
	if atkMode==1 then
		self.mode1ATKMode=10
		self:addStatusList({zz=3,s=78,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.mode1ATKMode},0)
	else
		self.mode1ATKMode=1
		self:addStatusList({zz=3,s=78,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.mode1ATKMode},0)
	end
end
--刷新生邪印
function SHero9:refMode2ATKMode()
	self:addStatusList({zz=3,s=78,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.mode1ATKMode},0)
end
--获得当前圣邪印
function SHero9:getMode2ATKMode()
	local atkMode = 0
	if self.mode1ATKMode==10 then
		atkMode = 1
	end 
	return atkMode
end
--- 使用技能伤害，call父类的skillAttack
-- @param mode int - 技能 1-8 rank
-- @param itemID int - 攻擊目標 itemID
-- @param positionX float - 攻擊目標 位置 X
-- @param positionY float - 攻擊目標 位置 Y
-- @param force bool - true ＝ 無視失控, 失控時攻擊目標用
-- @param fromClientSide bool - true ＝ 來自客戶端
-- @return msg table - 返回msg 給client 包括action move skillstatus
function SHero9:skillAttack(mode,itemID,positionX,positionY,force,fromClientSide,nPara,pPara)
	--普通攻击切换模式 普通攻击:修改为直线攻击,触碰单目标后消失(类单体伤害)。每次攻击成功击中目标,获得1点箭魂,击杀目标获得3点。
	if mode==1 then
		mode=self.mode1ATKMode
		self:D("天启者 切换普通攻击为:",mode)
	end

	return SHero9.super.skillAttack(self,mode,itemID,positionX,positionY,force,fromClientSide,nPara,pPara)
end


--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero9:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	
	--以自身为圆心，范围内（约5个身位）目标瞬间治疗。

	if (hitValue['CDTIMECLEARFIX']~=nil and hitValue['CDTIMECLEARFIX']>0 and self.CDTIMECLEARFIXNUM==0 ) then
		local cdR = self.world.formula:getRandnum(0,100)
		if cdR<=hitValue['CDTIMECLEARRATE']  then
			self.callBackEndBullet = self.lastBulletID
			--debuglog("全体技能减CD........."..hitValue['CDTIMECLEARFIX'].." callBackEndBullet:"..self.callBackEndBullet)
			local sk = self.attribute.skills
			local gt = self.world:getGameTime()
			for i=2,5 do
				if sk[i] ~=nil then
					sk[i].lastCoolDownTime = sk[i].lastCoolDownTime - hitValue['CDTIMECLEARFIX']
					--debuglog("全体技能减CD.........i:"..i.." lastCoolDownTime:"..sk[i].lastCoolDownTime)
				end
			end
			self:syncSkill(0)
		end
		self.CDTIMECLEARFIXNUM = 1
	end	

	if mode==3 then
		local skill = self.attribute.skills[3] 
		local parameters = skill.parameters 
		hitValue['FIXREHP'] = self.world.mAbs(hitValue['APADJ2']*self.attribute.ATK*0.01)
	end

	--5变4
	if mode==4 then
		local skill = self.attribute.skills[4] 
		local parameters = skill.parameters 
		local rehpUP = self.mode4REHPSP*parameters.SEALTRANSFERAP2*0.01
		--天赋 圣印效果提升20%/40%/60%/80%/100%
		-- if parameters.SEALEFFECTUP~=nil then
		-- 	rehpUP = rehpUP * (1+parameters.SEALEFFECTUP*0.01)
		-- end
		self:D("天启者 治疗量增加:",self.mode4REHPSP,parameters.SEALTRANSFERAP2,(1+rehpUP))
		hitValue['FIXREHP'] = self.world.mAbs(hitValue['APADJ2']*self.attribute.ATK*0.01)*(1+rehpUP)
	end

	-- if mode==1 and self.mode1bool then
	-- 	local skill = self.attribute.skills[1] 
	-- 	local parameters = skill.parameters 
	-- 	local attributes = {}
	-- 	attributes['CRI_UPFIX_RATE'] = parameters['CRI_UPFIX_RATE2']
	-- 	attributes['CRI_UPFIX'] = parameters['CRI_UPFIX2'] 
	-- 	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(skill.skillID),attributes,parameters['BUFFTIME2'],{},0,self.itemID,self.itemID,0.1)
	-- 	self:addBuff(buff)

	-- 	-- hitValue['REHP'] = parameters['REHP2']

	-- 	-- local hitValueNew = {}
	-- 	-- hitValueNew['REHP']  = parameters['REHP2']
	-- 	-- self:directHurt(self.itemID,mode,hitValueNew,0) 
	-- 	----debuglog("REHP:"..hitValue['REHP'])
	-- 	self.mode1bool = false
	-- end

	if mode==1 then
		local obj = self.world.allItemList[itemID] 
		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters 
		--EXPLODERANGE=200;ATKMOVEDIS_S1=0;ATKMOVEDIS_S2=0;CDTIME1=0.5;CDTIME2=0.5
		local attackRange = {posX=obj.posX,posY=obj.posY,radius=parameters.EXPLODERANGE/self.world.setting.AdjustAttRange} 

		local hitValueNew = self:getPrepareHithitValue()
		----debuglog("parameters:..."..self.world.cjson.encode(parameters))
		hitValueNew['skillID'] = 1
		hitValueNew['APADJ'] = parameters.APADJ
		hitValueNew['ADADJ'] = parameters.ADADJ
		
		local bullet = require("gameroomcore.SBullet").new(self.world,1,self.itemID,0.2,0,obj.posX,obj.posY)
		bullet.attr.ignoreID = {itemID}
		bullet:directFightAura(1,attackRange,hitValueNew,bullet.attr.angle,0) 
		bullet:setDead() 
		hitValue['attackZXP'] = "1"

	end


	ret = SHero9.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	
	--增加圣印
	if ret>0 and mode==1 and self.addSPMode==0 then
		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters 
		self:adjSP('a',parameters.ADJSEALNUM)
		self.addSPMode=1 
	end
	--增加邪印
	if ret>0 and mode==10 and self.addSPMode==0 then
		local skill = self.attribute.skills[10] 
		local parameters = skill.parameters 
		self:adjSP('b',parameters.ADJEVILNUM)
		self.addSPMode=1
	end

	return ret 
end 


--- 受傷害計算,调用SActor的hurted
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHero9:hurted(itemID,bulletID,mode,hitValue,adjTime)

	local hurt = SHero9.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
	--4变5
	--ADADJ=0;APADJ=0;REBOUND_HURT_RATE2=10;REBOUND_HURT2=50;BUFFTIME2=5;CDTIME=20
	-- if self.mode5timefj>self.world:getGameTime() and itemID ~= self.itemID and hurt>0  and hitValue['isREBOUND']==nil  then
	-- 	local skill = self.attribute.skills[5] 
	-- 	local parameters = skill.parameters 

	-- 	math.randomseed(os.time()+adjTime*54671)
	-- 	--self.world:setRandomSeed()
	-- 	local rand = self.world.mRandom(0,100)

	-- 	if rand<parameters.REBOUND_HURT_RATE2 then
	-- 		local hitValueNew = {}
	-- 		hitValueNew['FIXHURT']  = hurt * parameters.REBOUND_HURT2 * 0.01
	-- 		hitValueNew['isREBOUND']  = true
	-- 		self.world.allItemList[itemID]:directHurt(self.itemID,5,hitValueNew,0) 
	-- 	end
	-- end

	return hurt
end

function SHero9:adjSP(type,sp)
	self:D("adjSP",self.SPa,self.SPb,self.maxSP,self.itemID,self.loginID)
	if (self.SPa+self.SPb)>=self.maxSP then
		-- --池子满了 需要换位
		-- local lstable = {}
		-- --减去对应的sp
		-- if self.SPList[#self.SPList]=='A' then
		-- 	self.SPa=self.SPa-1
		-- else
		-- 	self.SPb=self.SPb-1
		-- end
		-- if type=='a' then
		-- 	lstable[#lstable+1] = 'A'
		-- 	self.SPa=self.SPa+1
		-- else
		-- 	lstable[#lstable+1] = 'B'
		-- 	self.SPb=self.SPb+1
		-- end

		-- --全部前移
		-- for i=1,#self.SPList-1 do
		-- 	lstable[#lstable+1] = self.SPList[i]
		-- end
		-- self.SPList = lstable
		return nil
	else
		if type=='a' then
			self.SPa = self.SPa + sp
			local  oldSPa = self.SPa
			if (self.SPa+self.SPb)>self.maxSP then 
				self.SPa = self.maxSP-self.SPb
			end	
			if (self.SPa+self.SPb)>self.changePartSP then 
				self.SPa = self.changePartSP-self.SPb
			end	
			for i=1,(sp -(oldSPa-self.SPa) ) do
				self.SPList[#self.SPList+1]='A'
			end
		end
		if type=='b' then
			self.SPb = self.SPb + sp
			local  oldSPb = self.SPb
			if (self.SPa+self.SPb)>self.maxSP then 
				self.SPb = self.maxSP-self.SPa
			end
			if (self.SPa+self.SPb)>self.changePartSP then 
				self.SPb = self.changePartSP-self.SPa
			end
			for i=1,(sp -(oldSPb-self.SPb) ) do
				self.SPList[#self.SPList+1]='B'
			end
		end
	end	



	local str = ""
	local str1 = ""
	for i=1,4 do
		if self.SPList[i]=='A' then
			str=str.."1"
		elseif self.SPList[i]=='B' then
			str=str.."2"
		else
			str=str.."0"
		end
	end
	for i=5,8 do
		if self.SPList[i]=='A' then
			str1=str1.."1"
		elseif self.SPList[i]=='B' then
			str1=str1.."2"
		else
			str1=str1.."0"
		end
	end
	--self:addStatusList({s=62,r=self.world:getGameTime(),t=99,i=self.itemID,p1=self.world.tonumber(str),p2=self.world.tonumber(str1)},0)
	self:addStatusList({zz=3,s=62,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.SPa,p2=self.SPb},0)
	self:D("愤怒值 单次增加:",type,sp," 剩余圣:",self.SPa,"剩余邪:",self.SPb,"最大值:",self.maxSP,"圣邪列表:",self.world.cjson.encode(self.SPList),self.world.tonumber(str),self.world.tonumber(str1))

end

function SHero9:useSP()
	self.SPa = 0
	self.SPb = 0
	self.SPList={}
	self:addStatusList({zz=3,s=62,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=0,p2=0},0)
	self:D("愤怒值 使用"," 剩余圣:",self.SPa,"剩余邪:",self.SPb,"最大值:",self.maxSP,"圣邪列表:",self.world.cjson.encode(self.SPList))
end

function SHero9:syncInfo()
	
	-- if self.statusList[1005]~=nil then
		
	-- else
	-- 	if self.maxSP~=3 then
	-- 		self:addStatusList({s=61,r=self.world:getGameTime(),t=99,i=self.itemID,p1=3},0)
	-- 	end
	-- 	self.maxSP=3
		
	-- end

	SHero9.super.syncInfo(self)
end

--- 设置技能限制施放时间
-- @param skill table - 角色某一招技能的所有设置值
-- @return null
function SHero9:useCDTime(skill)
	if skill.rank<10 or skill.rank>30 then
		SHero9.super.useCDTime(self,skill)
	end
end

-- function SHero9:removeStatusList( statusNum, adjTime )
-- 	self:D("暗牧清除removeStatusList:",statusNum,string.gsub(debug.traceback("", 2), "\n", " "))
-- 	return SHero9.super.removeStatusList(self,statusNum, adjTime)
-- end

return SHero9 