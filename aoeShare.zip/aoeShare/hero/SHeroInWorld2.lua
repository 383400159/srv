local SHeroInWorld2 = class("SHeroInWorld2", require("gameroomcore.SHeroBase"))

function SHeroInWorld2:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld2.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.pickBackTime = 0
	self.pickBackWaitCheckTime = 0
	self.energyBuffID = 0
	self.lastWarnTime = 0
end


--- 角色死亡,call 父类
function SHeroInWorld2:goToDead(itemID,mode,adjTime,bonus)  
	local obj = self.world.allItemList[itemID]
	if obj.actorType==0 and self.actorType==0 then
		self:removeSkillAttackMode9()
		if self.statusList[999]~=nil then
			self:removeStatusList(999)
		end
		if itemID~=self.itemID then
			self.world.gameCounter['points'..obj.team] = self.world.gameCounter['points'..obj.team] + self.world.tonumber(self.world.setting['kill_energy'])
			if (self.world.gameCounter['points'..obj.team]+self.world.tonumber(self.world.setting['enemy_energy']))>=self.world.tonumber(self.world.setting['win_energy']) then
				debuglog('jaylog SHeroInWorld2:goToDead bc60 id:'..itemID)
				obj:updateSyncMsg({bc={{zz=3,mid=60,i=obj.itemID}}})
			end
		end
		debuglog('jaylog SHeroInWorld2:goToDead itemID:'..itemID..' mode:'..mode..' objTeam:'..obj.team..' score:'..self.world.gameCounter['points'..obj.team])
		--if self.world.gameFlag['getFlagAID']==self.itemID then
		if self.statusList[37]~=nil then
			local monsterID = self.world:addMonster(self.world.setting['energyAPick'],self.posX,self.posY,'A',1,'')
			local monsterObj = self.world.allItemList[monsterID]
			monsterObj.pickBackTime = self.world.gameTime + self.world.tonumber(self.world.setting['PickBackTime'])
			monsterObj.pickBackWaitCheckTime = self.world.gameTime
			--self.world.gameFlag['getFlagAID'] = 0
			self:removeStatusList(37)
			self:removeBuffToID(self.energyBuffID)
			obj:updateSyncMsg({bc={{zz=2,mid=65,t=obj.team}}})
		end
		--if self.world.gameFlag['getFlagBID']==self.itemID then
		if self.statusList[51]~=nil then
			local monsterID = self.world:addMonster(self.world.setting['energyBPick'],self.posX,self.posY,'B',1,'')
			local monsterObj = self.world.allItemList[monsterID]
			monsterObj.pickBackTime = self.world.gameTime + self.world.tonumber(self.world.setting['PickBackTime'])
			monsterObj.pickBackWaitCheckTime = self.world.gameTime
			--self.world.gameFlag['getFlagBID'] = 0
			self:removeStatusList(51)
			self:removeBuffToID(self.energyBuffID)
			obj:updateSyncMsg({bc={{zz=2,mid=65,t=obj.team}}})
		end
		self.world:syncPointsInfo()
	end
	SHeroInWorld2.super.goToDead(self,itemID,mode,adjTime,bonus) 
	-- 角色死亡时生成锁定镜头木桩
	local creatureID = self.world:addCreature(self.world.tostring(113),self.team,self.initX,self.initY,self,1,0.1,self.attribute.roleId)
	local targetShareObj = self.world.allItemList[creatureID]
	local attributes = {}
	attributes['STOPMOVE_RATE'] = 100
	attributes['INVICINBLE_RATE'] = 100
	local buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(1),attributes,9999,{},0,self.itemID,self.itemID,0.1)
	targetShareObj:addBuff(buff)
	targetShareObj:addStatusList({s=4007,t=9999},0.5)
	local camMode = 0
	if self.team=='A' then
		camMode = 19
	else
		camMode = 20
	end
	targetShareObj:addStatusList({s=9005,t=9999,p1=camMode,p2=self.itemID},0.5)
	targetShareObj:addStatusList(self.statusList[997],0.5)
	targetShareObj:setCoexistID(self.itemID)
	self:setCoexistID(targetShareObj.itemID)
	for k,v in pairs(targetShareObj.statusList) do
		debuglog('jaylog statusList:'..k..' '..self.world.cjson.encode(v))
	end
	debuglog('jaylog addCreature itemID:'..creatureID..' selfID:'..self.itemID..' 9005:'..self.world.cjson.encode({s=4009,t=9999,p1=camMode,p2=self.itemID,i=targetShareObj.itemID}))
end

function SHeroInWorld2:revive()
	if self.deadTime<=self.world:getGameTime() and self.coexistID>0 and self.world.allItemList[self.coexistID]~=nil then
		-- 角色重生时清除锁定镜头木桩
		debuglog('jaylog coexistID'..self.coexistID..' deadTime:'..self.deadTime..' itemID:'..self.itemID)
		local shareObj = self.world.allItemList[self.coexistID]
		shareObj:setCoexistID(0)
		self:setCoexistID(0)
		shareObj:addStatusList({s=42,t=5})
		shareObj.attribute.HP = 0
		shareObj:directHurt(shareObj.itemID,1,{},0)
	end
	SHeroInWorld2.super.revive(self)
end







--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SHeroInWorld2:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	local hurt = SHeroInWorld2.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
end

function SHeroInWorld2:skillAttackMode9CallBack(roleId,itemID)
	debuglog('jaylog SHeroInWorld2:skillAttackMode9CallBack In roleId:'..roleId..' waitGetFlagAID:'..self.world.cjson.encode(self.world.gameFlag['waitGetFlagAID'])..' waitGetFlagBID:'..self.world.cjson.encode(self.world.gameFlag['waitGetFlagBID']))
	--red
	if roleId==101 or roleId==138 and not self:isDead() then
		--local min = self.world:getTableValueMin(self.world.gameFlag['waitGetFlagAID'])
		--debuglog('jaylog SHeroInWorld2:skillAttackMode9CallBack min:'..min..' roleId'..roleId)
		--if self.world.gameFlag['waitGetFlagAID'][self.itemID]~=nil and self.world.gameFlag['waitGetFlagAID'][self.itemID]==min then
		if self.world.allItemList[itemID]~=nil and not self.world.allItemList[itemID]:isDead() then
			self.world.allItemList[itemID].attribute.HP = 0
			self.world.allItemList[itemID]:directHurt(itemID,1,{},0)
			if self.team=='A' then
				self.world:addMonster(self.world.setting['energyAType'],self.world.setting['energyACoordinateX'],self.world.setting['energyACoordinateY'],'A',1,'')
				self:updateSyncMsg({bc={{zz=2,mid=61,t=self.team}}})
				self:updateSyncMsg({bc={{zz=2,mid=62,t='B'}}})
			else
				self:updateSyncMsg({bc={{mid=51,p1=self.itemID},{zz=2,mid=63,t='A'},{zz=3,mid=64,i=self.itemID}}})
				self:addStatusList({s=37,r=self.world.gameTime,t=9999})
				self.energyBuffID=self:addEnergyDeBuff()
				self.world.gameFlag['getFlagAID'] = self.itemID
			end
			--self.world.gameFlag['waitGetFlagAID'] = {}
		end
	end
	--blue
	if roleId==137 or roleId==139 and not self:isDead() then
		--debuglog('jaylog SHeroInWorld2:skillAttackMode9CallBack waitGetFlagBID:'..self.world.cjson.encode(self.world.gameFlag['waitGetFlagBID']))
		--local min = self.world:getTableValueMin(self.world.gameFlag['waitGetFlagBID'])
		--debuglog('jaylog SHeroInWorld2:skillAttackMode9CallBack min:'..min..' roleId'..roleId)
		--if self.world.gameFlag['waitGetFlagBID'][self.itemID]~=nil and self.world.gameFlag['waitGetFlagBID'][self.itemID]==min then
		if self.world.allItemList[itemID]~=nil and not self.world.allItemList[itemID]:isDead() then
			self.world.allItemList[itemID].attribute.HP = 0
			self.world.allItemList[itemID]:directHurt(itemID,1,{},0)
			if self.team=='B' then
				self.world:addMonster(self.world.setting['energyBType'],self.world.setting['energyBCoordinateX'],self.world.setting['energyBCoordinateY'],'B',1,'')
				self:updateSyncMsg({bc={{zz=2,mid=61,t=self.team}}})
				self:updateSyncMsg({bc={{zz=2,mid=62,t='A'}}})
			else
				self:updateSyncMsg({bc={{mid=52,p1=self.itemID},{zz=2,mid=63,t='B'},{zz=3,mid=64,i=self.itemID}}})
				self:addStatusList({s=51,r=self.world.gameTime,t=9999})
				self.energyBuffID=self:addEnergyDeBuff()
				self.world.gameFlag['getFlagBID'] = self.itemID
			end
			--self.world.gameFlag['waitGetFlagBID'] = {}
		end
	end
end

--- 第9招读条 
-- @param null
-- @return null
function SHeroInWorld2:removeSkillAttackMode9() 
	if self.statusList[41]~=nil then
		self:removeStatusList(41)
		if self.statusList[999]~=nil then
			--print(debug.traceback("", 2))
			self:debuglog("jaylog SHeroInWorld2:removeSkillAttackMode9 removeStatusList 999")
			self:removeStatusList(999)
		end
	end
	SHeroInWorld2.super.removeSkillAttackMode9(self)
	
end



function SHeroInWorld2:prepareSkillAttackMode7(updateMove)
	return nil
end

function SHeroInWorld2:addEnergyDeBuff()
	local buffStr = self.world.setting['energy_buff']
	local buffTmp = self.world.sSplit(buffStr,';')
	local buffTmp2 = {}
	local attributes = {}
	local buffTime = 0
	for k,v in pairs(buffTmp) do
		buffTmp2 = self.world.sSplit(v,'=')
		if buffTmp2[1]=='BUFFTIME' then
			buffTime = self.world.tonumber(buffTmp2[2])
		else
			attributes[buffTmp2[1]] = self.world.tonumber(buffTmp2[2])
		end
	end
	local buffID = self:__skillID2buffID(99,0)
	local buff = require("gameroomcore.SBuff").new(self.world,buffID,attributes,buffTime,{},0,self.itemID,self.itemID,0)
	self:addBuff(buff)
	return buffID
end



return SHeroInWorld2