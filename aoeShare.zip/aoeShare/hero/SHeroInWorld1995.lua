local SHeroInWorld1995 = class("SHeroInWorld1995", require("gameroomcore.SHeroBase"))

function SHeroInWorld1995:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld1995.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
end


return SHeroInWorld1995
