local SHeroInWorld2001 = class("SHeroInWorld2001", require("gameroomcore.SHeroBase"))

function SHeroInWorld2001:ctor(world,id,team,posX,posY,loginID,skinNum,actorID) 
	SHeroInWorld2001.super.ctor(self,world,id,team,posX,posY,loginID,skinNum,actorID)
	self.sharedID = 0
	self.sharedproHP = 1
	self.preInCam = 0				--列队入镜流程序号
	self.inCamTime = 0			--入镜等待结束时间 
	self.inTransitDoor = false	--是否在传送门内
end


--- 角色死亡,call 父类
function SHeroInWorld2001:goToDead(itemID,mode,adjTime,bonus)  
	if self.world.gameFlag['passTransitDoorID'][''..self.itemID]~=nil then
		if self.sharedID>0 and self.world.allItemList[self.sharedID]~=nil then
			local shareObj = self.world.allItemList[self.sharedID]
			self:moveTo(shareObj.posX,shareObj.posY,true,1,99999)
			shareObj:setShared(0)
			shareObj:addStatusList({s=42,r=self.world:getGameTime(),t=999},0)
			shareObj.attribute.HP = 0
			shareObj:directHurt(self.itemID,1,{},0)
			self:setShared(0)
		end
		self.world.gameFlag['passTransitDoorNum'] = self.world.gameFlag['passTransitDoorNum'] - 1
		self.world.gameFlag['passTransitDoorLastNum'] = self.world.gameFlag['passTransitDoorLastNum'] + 1
		self.world.gameFlag['passTransitDoorID'][''..self.itemID] = nil
		self.world.transitDoor:addStatusList({s=4002,r=self.world.gameTime,t=99999,i=self.world.transitDoor.itemID,p1=self.world.gameFlag['passTransitDoorLastNum']},0.2)
	end
	if self.statusList[4007]~=nil then
		if self.sharedID>0 and self.world.allItemList[self.sharedID]~=nil then
			local shareObj = self.world.allItemList[self.sharedID]
			self:moveTo(shareObj.posX,shareObj.posY,true,1,99999)
			self:setShared(0)
			shareObj:setShared(0)
			self:removeStatusList(4007)
			self.AIlastMoveTime = self.world.gameTime+2
			self:removeStatusList(4010)
			self:removeBUff('INVICINBLE')
			shareObj:addStatusList({s=42,r=self.world:getGameTime(),t=999},0)
			-- shareObj.attribute.HP = 0
			-- shareObj:directHurt(self.itemID,1,{},0)
		end
	end
	SHeroInWorld2001.super.goToDead(self,itemID,mode,adjTime,bonus) 
end 

--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SHeroInWorld2001:prepareHit(mode,adjTime,buff)  
	local hitValueBoth=SHeroInWorld2001.super.prepareHit(self,mode,adjTime,buff) 
	return hitValueBoth 
end 


--- 發動攻擊,call父类
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHeroInWorld2001:hitTarget(itemID,bulletID,mode,hitValue,adjTime) 
	ret = SHeroInWorld2001.super.hitTarget(self,itemID,bulletID,mode,hitValue,adjTime) 
	return ret 
end

--- 准备攻击前置设置，在prepareHit之前执行，call父类
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SHeroInWorld2001:prepareSkillAttackCustom(mode,target,x,y,adjTime,syncMsg)  
	SHeroInWorld2001.super.prepareSkillAttackCustom(self,mode,target,x,y,adjTime,syncMsg)  
end 

--- 受傷害計算,调用SActor的hurted
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SHeroInWorld2001:hurted(itemID,bulletID,mode,hitValue,adjTime)

	local hurt = SHeroInWorld2001.super.hurted(self,itemID,bulletID,mode,hitValue,adjTime)
		--共享生命	
	-- if self.sharedID>0 then
	-- 	local obj = self.world.allItemList[self.sharedID] 
	-- 	obj:adjHP(-hurt*self.sharedproHP)
	-- end
	return hurt
end


--设置共享生命id 
-- function SHeroInWorld2001:setShared(id,hppro)
-- 	if hppro==nil then hppro=1 end
-- 	self.sharedID = id
-- 	self.sharedproHP = hppro
-- end



--- 直接伤害回调
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
function SHeroInWorld2001:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt) 
	local hurt = SHeroInWorld2001.super.directHurtCallBack(self,itemID,mode,hitValue,adjTime,hurt)
end

function SHeroInWorld2001:prepareSkillAttackMode7(updateMove)
	return nil
end

return SHeroInWorld2001