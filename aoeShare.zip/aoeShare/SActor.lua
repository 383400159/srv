
local SActor = class("SActor", require("gameroomcore.SActorBase"))

-- SActorBase.lua
-- SActor.lua
-- SHeroBase.lua
-- SHero.lua

--- Constructor
-- @param world World - game world
-- @param id int - itemID
-- @param team char - "A" or "B" or "" or "C" .. "Z"
-- @param x float - positionX
-- @param y float - positionY
-- @return id int - itemID
function SActor:ctor(world,id,team,x,y,actorID)

	if self.className==nil then
		self.className="SActor"
	end	

	self.syncMsg = {}
	self.paths = {}

	self.attribute = nil
	self.actorType = 0 -- hero 

	self.team = ''			--队伍
	self.teamOrig = ''	--原队伍

	self.world = nil 		--world obj
	--self.itemID = 0 		--房间玩家排序ID

	self.deadTime = -1
	self.deadFlag = false
	self.dirty = false


	self.status = 0 -- 0=idle , 1=walk , 2=standby , 3=fight , 4=blockwait , 5=special , 6=dizzy , 7=freeze
	self.statusList = {}

	self.lastBulletID = 0
	self.buffList = {}
	self.prepareSkillAttackNum = 0

	self.isVisible = 0 -- 1=yes 2=no -1=hidden 0=undeclared
	self.lastIsVisible = 0 -- 1=yes 2=no -1=hidden 0=undeclared
	self.visibleList = {}

	self.lastAttackID = 0  -- last attack id
	self.lastAttackTime = 0 -- keep 3 second

	self.width = 1
	self.skeleton = 0

	--self.lastStandByAttackTime = 0 -- for skill stand by attack = 1
	--self.lastMoveMode = 0

	self.world = world
	-- if not string.find(self.className,'SHero') then
	-- 	self.itemID = self.world:getItemID()
	-- 	debuglog('jaylog SActor:not hero add itemID:'..self.itemID)
	-- end
	--print('jaylog SActor actorID:',actorID)
	if actorID~=nil or self.world.sFind(self.className,'SHero') then
		self.itemID = actorID
		--debuglog('jaylog SActor:exist actorID add itemID:'..self.itemID)
	else
		self.itemID = self.world:getItemID()
		--debuglog('jaylog SActor:not hero add itemID:'..self.itemID)
	end

	self.nextREHPMPTime = 0 --下次回复HPMP时间
	self.nextREHPMPzzTimes = 0
	self.nextREHPMPSyncTime = 0 --下次回复HPMP发送消息给client时间

	self.team = team
	self.teamOrig = team
	-- init attribute

	self.buffIDSeqNo = 1

	self.moveShieldTime = 0 --格挡
	self.shieldSkillTime = 0 --格挡技能触发时间
	self.lastWalkTime =0  --— 最後計算移動時間
	self.lastFightTime=0   --— 最後普通攻擊移動時間
	self.lastSPFightTime=0  --— 最後技能攻擊移動時間
	self.lastCoolDownTime=0  --— 所有動作的CD時間
	self.silentTime=0 --— 沉默時間, 不能出技能(不可以普通攻擊) — 可以用buff 取代
	self.silentTimeSkill=0 --— 沉默時間, 不能出技能(可以普通攻擊) — 可以用buff 取代
	self.outOfCtlTime=0  --— 失控時間，但可以自動攻擊
	self.outOfCtlAllTime=0  --— 全失控時間
	self.invincibleTime=0 --— 無敵時間  — 可以用buff 取代
	self.anitDeBuffTime=0 --— 無視debuff時間 — 可以用buff 取代
	self.blindTime=0 --— 失明時間, 全攻擊失效 — 可以用buff 取代
	--	self.checkOverLapTime=0 --— 最後計算碰撞時間
	self.moveStopTime = 0 		--移动停止时间
	self.moveToEndTime = 0 		--完成moveTo后的系统时间
	self.heroIdleTime = 0 		--英雄靜止時間
	self.autoBlocked = false
	self.lastAutoCallApiTime = 0 	--自动call api更新玩家信息

	self.autoTo = false			--自动跟随停止
	self.autoToTargetID = 0 	--自动跟随停止目标ID
	self.autoFollow = false			--自动跟随
	self.autoFollowTargetID = 0 	--自动跟随目标ID
	self.autoToPos = false		--自动移动状态
	self.autoToPosX = 0 		--自动移动目的地坐标X
	self.autoToPosY = 0 		--自动移动目的地坐标Y

	--记录需要endBullet的子弹ID
	self.callBackEndBullet = 0

	-- ping 分析
	self.pingtime = 0.0 -- 平均ping值
	self.lastpingtime = 0.0 -- 最後一次ping值
	self.ipaddress = "" -- 玩家ip地址

	self.counter = {	--单角色统计 counter
		points = 0,		--能量点数 points
		revive = 0, 	--复活次数
		killhero = 0,	--杀英雄数 killhero
		killed = 0,		--被杀数 killed
		hurted = 0,		--受伤害总量 hurted
		hurt = 0,		--伤害总量 hurt
		cure = 0,		--治疗总量 cure
		getFlag = 0, 	--取旗总数 getFlag
		killboss = 0,	--击杀BOSS数
	}



	self.lastHurtItemID = 0  --记录最近10秒被哪个玩家打
	self.lastHurtTime = 0    --记录最近被打的时间

	self.lastHurtAllID = 0  --记录最近10秒被哪个打
	self.lastHurtAllTime = 0    --记录最近被打的时间

	--判断战斗状态
	self.lastREHPHurtTime = 0 --记录最近被攻击事件
	self.lastREHPattackTime = 0 --记录最近攻击的事件

	--mode1相关参数
	self.mode1order = 0
	self.mode1atktime = 0
	self.mode1type = 0
	self.mode1step = 0

	--AI相关(type 1=hero,2=boss,3=enemy)
	self.AIlv = 1
	self.AItype = 1
	self.AImode = 0
	--仇恨列表
	self.Hatredlist = {}
	--仇恨列表 記錄
	self.HatredlistRecord = {}

	--共享生命id
	self.sharedID = 0
	self.sharedproHP = 1

	--初始坐标 出生坐标
	self.initX = 0
	self.initY = 0

	--重生坐标
	self.rebirthX = 0
	self.rebirthY = 0
	--重生buff标记
	self.rebirthBuff = {MSPD=0,HP=0,ATK=0,ATK10=0,ATK20=0}

	--change part limit hp
	self.changePartHP = 0
	--角色在world中的别名
	self.subName = ''
	--上一次施放技能返回值
	self.lastSkillRet = 0
	self.blockLen = 0
	self.blockWidth = 0

	--共生ID
	self.coexistID = 0
	self.statusListGarbage = {}
	self:__init(id,x,y,level)
	SActor.super.ctor(self,world,id,team,x,y)

	--bossAI
	self.AIlastCoolDown = 0
	self.AIlastAutoMove = 0
	self.AIlastATKtoMove = 0

	--heroAI
	self.AIlastATKTime=0
	self.AIlastMoveTime=0

	--AI里面的被打事件记录
	self.startHurtTime = 0

	--是否立即上马
	self.horseNow = false

	self.isRelease = false
	self.guideStep = 0 				--流程步骤ID
	self.guideStepFinish = false	--流程步骤是否完成
	self.firstAdd = false

	self.atkTaskList = {}
	self.clearSkillCDList={}	--记录各种技能清cd的时间

	self.autoFightAI = require("gameroom.ai.SAI").new(self)

	if self.attribute.parameterArr~=nil and self.attribute.parameterArr['NOMOVE']~=nil and self.attribute.parameterArr['NOBEFIGHT']~=nil then
		self:setNoMove(true)
	end
	--暂停AI
	self.stopAITime = 0

	--可以重生
	self.canRevive = true

	self:D('jaylog SActor:ctor end')

	--AI指定目标集火
	self.AITargetAuto = false
	self.AITargetItemID = 0
	self.AITargetTime = 0

	--sync hp信息
	self.lastSyncTime = 0
	self.lastSyncHP = 0
	self.lastSyncMP = 0
end


--- Release actor object
-- @return null
function SActor:release()
	SActor.super.release(self)
	self.world = nil
	self.attribute:release()
	self.attribute = nil
	self:D("SActor:release itemID:",self.itemID)
end


--- Initialize actor object (attribute skill ...)
-- @param id int - actor ID
-- @param x int - position x
-- @param y int - position y
-- @return null
function SActor:__init(id,x,y)
	self:D('jaylog SActor:__init start')
	self.attribute = require("gameroom.attribute.SAttribute").new(id,1,self)
	self.initX = x
	self.initY = y
	self.nextREHPMPTime = self.world:getGameTime()
	self.nextREHPMPzzTimes = 0

	self.taskObj = require("gameroom.STask").new(self)	
	self.counterObj = require("gameroom.SCounter").new(self)
end

--对象创建以后call的init
function SActor:createInit()
	-- body
end

--- get object speed , block per second
-- @return float speed
function SActor:_getSpeed()
	return self.getSpeed()
end

--- set object speed , block per second
-- @return null
function SActor:_setSpeed()
	self.setSpeed( self.attribute.MSPD / self.world.setting.walkingSpeed)
end


--- move motion , call every update loop
-- @return null
function SActor:move()
	-- if self.attribute.actorType==0 then
	-- 	debuglog("MK moveTo MSPD:"..self.attribute.MSPD)
	-- end

	self:runBuff()
	if self.moveStopTime>self.world.gameTime then
		return nil
	end

	SActor.super.move(self)
	--self:D("地图AI itemID:"..self.itemID,self.posX,self.posY,self.isAI,self.AImode,self.autoBlocked,self.outOfCtlTime,self.world:getGameTime())
	if  self.AImode>0 and not self.autoBlocked and (self.attribute.actorType==2 or self.attribute.actorType==1 or self.attribute.actorType==0)  and self.outOfCtlTime<self.world:getGameTime() then
		self:_autoMove()
	end	

end

--- 執行移動
-- @param x float - position x
-- @param y float - position y
-- @param force bool - 強制執行, 不論是否已到達
-- @param mode bool - 0 - 正常, 1 - 閃現 , 2 - 跳至 , 3 - 滾動, 4=擋移動, 5=擊飛, 6=技能移动
-- @param speed float - 速度
-- @param adjTime float - 廷遲執行, 給 5=擊飛, 6=技能移动 用
-- @return moveMsg table - 移動訊息
function SActor:moveTo(x,y,force,mode,speed,adjTime)
	-- if self.world.gameRoomSetting['ISPVP']==1 then
	-- 	if self.itemID~=1 then
	-- 		print('SActor:moveTo x',x,'y',y,'force',force,'mode',mode,'speed',speed,'adjTime',adjTime,'loginID',self.loginID,string.gsub(debug.traceback("", 2), "\n", " "))
	-- 	end
	-- end
	--击飞在身上有76和73状态的时候忽略
	if mode==5 and (self.statusList[73]~=nil or self.statusList[76]~=nil) then
		return {}
	end

	--if self.attribute.actorType==1 then
		--debuglog("parameterArr:"..self.world.cjson.encode(self.attribute.parameterArr))
	--end
	
	if self.attribute.actorType==1  and self.attribute.parameterArr['NOMOVE']~=nil then
		return {}
	end

	local result = SActor.super.moveTo(self,x,y,force,mode,speed,adjTime)
	if self.moveToEndTime > 0 then
		self:removeSkillAttackMode9()
	end
	return result
end



--- 取得自身範圍
-- @return VisibleRange table - 自身範圍
function SActor:getCircle()
		return {posX=self.posX,posY=self.posY,radius=self.attribute.width}
end

--- 是否撞到指定範圍
-- @param circle table - 範圍 {posX=,posY=,radius=}
-- @param angle float - 方向
-- @param degree float - 圓形有效角度
-- @param itemID1 int - itemID 撞到指定角色
-- @return distance int -  -1 = 撞不到 , >=0 撞到之間距離
function SActor:colliding(circle,angle,degree,itemID1)
	if self:isDead() then return -1 end
	return SActor.super.colliding(self,circle,angle,degree,itemID1)
end


--- 是否已死亡
-- @return isDead bool - true = 死亡
function SActor:isDead()
	if self.attribute==nil then return true end
	return self.attribute.HP<1 or self.status==9
end


--- fight motion , call every update loop
-- @return null
function SActor:fight()
	--判断是否进入ai状态
	if self.outOfCtlAllTime>self.world:getGameTime() then
		return nil
	end
	if self.status==3 and self.lastCoolDownTime-0.1<self.world:getGameTime()then
		self.status = 2
	end
	if self.attribute.roleId==802 then
		self.world:D("弓箭手BB fight0"..self.parent.itemID,self.AImode,self.autoBlocked,self.outOfCtlTime,self.checkOverLapTime,self.lastCoolDownTime,self.world:getGameTime())
	end
	if self.AImode>0 and not self.autoBlocked  and (self.attribute.actorType==2 or self.attribute.actorType==1 or self.attribute.actorType==0)  and self.outOfCtlTime<self.world:getGameTime() and self.checkOverLapTime<self.world:getGameTime() and self.lastCoolDownTime<self.world:getGameTime() then
		--self:D("是否激活仇恨状态.........1",self.itemID,self.AImode)
		if table.nums(self.Hatredlist)>0 and self.attribute.TYPEATK==2 then
			--self:debuglog("是否激活仇恨状态.........")
			self.autoFightAI.runAI=true
		end
		if self.attribute.roleId==802 then
			self.world:D("弓箭手BB fight1"..self.parent.itemID,self.AImode,self.autoBlocked,self.outOfCtlTime,self.checkOverLapTime,self.lastCoolDownTime,self.world:getGameTime())
		end
		self:_autoFight()
	end	
	if self:prepareSkillAttack()~=false then
		-- here ... mean skill attack happened
	else 
		self:outOfCtlFight()
	end
	if self.attackTarget~=nil then
		if self.world.allItemList[self.attackTarget]==nil or self.world.allItemList[self.attackTarget]:isDead() then
			self.attackTarget = nil
		end
	end

end
--- 自动移动chud
-- @return null
function SActor:_autoMove()
	--self:D("setting worldAIMode",self.world.setting.worldAIMode)
	if self.stopAITime>=self.world:getGameTime() then
		self:D("heroAI _autoMove 暂停AI中"..self.itemID)
		return true
	end

	if self.isAI~=nil and self.isAI and self.world.setting.worldAIMode~=nil then
		if self.world.setting.worldAIMode==1 then
			--self:D("地图AI itemID:"..self.itemID,self.posX,self.posY,self.isAI,self.AImode,self.autoBlocked,self.outOfCtlTime,self.world:getGameTime(),"world101AutoMove")	
			return self.autoFightAI:world101AutoMove()
		end
		if self.world.setting.worldAIMode==2 then
			--self:D("地图AI itemID:"..self.itemID,self.posX,self.posY,self.isAI,self.AImode,self.autoBlocked,self.outOfCtlTime,self.world:getGameTime(),"worldAIMode")		
			return self.autoFightAI:world1001AutoMove()
		end
	else
		return false
	end

	--return false
end
--- 自动释放技能 
-- @return null
function SActor:_autoFight()
	self:D("stopAITime:"..self.itemID,self.stopAITime,self.world:getGameTime())
	if self.stopAITime>=self.world:getGameTime() then
		self:D("heroAI _autoFight 暂停AI中"..self.itemID)
		return true
	end

	if self.isAI~=nil and self.isAI and self.world.setting.worldAIMode~=nil then
		if self.world.setting.worldAIMode==1 then	
			return self.autoFightAI:world101AutoFight()
		end
		if self.world.setting.worldAIMode==2 then	
			return self.autoFightAI:world1001AutoFight()
		end
	else
		return false
	end


	--return false
end

--- 進入死亡狀態
-- @param itemID int - 由誰擊殺
-- @param mode table - 技能1-7
-- @param adjTime float - 調整時間
-- @param bonus table - 獎勵
-- @return null
function SActor:goToDead(itemID,mode,adjTime,bonus)
	if mode==nil then mode = 0 end
	self.deadTime = self.world:getGameTime()
	self.attribute.HP = 0
	self.attribute.HPEXTRA = 0
	self.deadFlag = true
	self.attackTarget = nil
	self.lastBulletID = 0
	if table.nums(self.buffList)>0 then
		local statusNum
		local recal = false
		local skillID = 0
		for k,v in pairs(self.buffList) do
			skillID = v.buffID%1000000
			if skillID<990000 then
				v.isRemove = 1
				v:runBuff()
				statusNum = self:__buffID2StatusNum(v.buffID,v.buffParameter['statusnum'])
				if self.statusList[statusNum]~=nil and v.buffID>10000 then
					self:removeStatusList(statusNum)
				end
				recal=true
			end
		end
		if recal then
			self:reCalBuff()
			self.attribute.HP = 0
		end
	end
	self.isRelease = true
	if self.world.subNameDeadCounter[self.subName]~=nil then
		self.world.subNameDeadCounter[self.subName] = self.world.subNameDeadCounter[self.subName] + 1
	end
end

--- 复活, 游戏loop
-- @param null
-- @return null
function SActor:revive()
	--GVB 没复活
	if self.canRevive and self.deadTime<=self.world:getGameTime() then
		-- if self.isAI then
		-- 	self.world:D("AI复活了..........itemID:",self.itemID,self.loginID)
		-- end

		self:removeStatusList(9)
		--删除死亡倒计时状态
		self:removeStatusList(981)
		self.towerComplete = 0
		if table.nums(self.buffList)>0 then
			local recal = false
			local skillID = 0
			for k,v in pairs(self.buffList) do
				skillID = v.buffID%1000000
				if skillID<990000 then
					self.buffList[k].isRemove = 1
					local statusNum = self:__buffID2StatusNum(v.buffID,v.buffParameter['statusnum'])
					if self.statusList[statusNum]~=nil and v.buffID>10000 then
						self:removeStatusList(statusNum)
					end
					recal = true
				end
			end
			if recal then
				self:reCalBuff()
			end
		end
		self.attribute.HP = self.attribute:getMaxHP()
		self.attribute.MP = self.attribute:getMaxMP()
		if self.rebirthX~=0 and self.rebirthY~=0 then
			self.posX = self.rebirthX
			self.posY = self.rebirthY
		else
			self.posX = self.initX
			self.posY = self.initY
		end
		self:__findingZone()
		self.skeleton = 0
		self.lastWalkTime = self.world:getGameTime()
		self.invincibleTime = self.world:getGameTime() + 1.5
		if self.rebirthX~=0 and self.rebirthY~=0 then
			self:moveTo(self.rebirthX,self.rebirthY,true,1)
			self.rebirthX = 0
			self.rebirthY = 0
		else
			self:moveTo(self.initX,self.initY,true,1)
			if self.actorType==0 and not self:isAIObj() and self.world.gameRoomSetting['ISYW']==1 and self.world.playerList[self.itemID]~=nil then
				self:updateSyncMsg({bc={{zz=3,mid=108,i=self.itemID}}})
			end
		end
		if self.actorType==0 then
			for k,v in pairs(self.rebirthBuff) do
				if v~=0 then
					self:addRebirthBuff(k,v)
					self.rebirthBuff[k] = 0
				end
			end
		end
		self.syncMsg['m']['d']=0.05
		--self.syncMsg['m']=nil
		self.attackTarget = nil
		self.prepareSkillAttackNum = 0
		self.status = 0
		self:setCounter('revive')
		-- 设置coolDown令client无法按技能
		self:setCoolDownTime(self.world:getGameTime() + 0.5)
		self:__getInfo()
		self:syncStatus()

		local result=self:getAllInfo(0,true)
		result['s'] = 1
		self:updateSyncMsg({i=result})
		-- debuglog("血条bug revive .......itemID:"..self.itemID.." revive ..getMaxMP:"..self.attribute:getMaxMP())
		-- 离线时如果补杀，保存重生位置
		if self.actorType==0 and not self:isAIObj() and self.world.gameRoomSetting['ISYW']==1 and self.world.playerList[self.itemID]~=nil then
			if self.world.playerList[self.itemID]['online']~=nil and not self.world.playerList[self.itemID]['online'] then
				self:updateInfo(true)
			end
		end
	end

end




--- buffID 轉換成 statusID
-- @param buffID int  - buff ID
-- @param overrideNum int - 覆蓋 ID
-- @return statusID int - status ID
function SActor:__buffID2StatusNum(buffID, overrideNum)
	if overrideNum~=nil and overrideNum>0 then
		return overrideNum
	end
	return 0
	
	-- local statusNum = buffID % 10000
	-- if statusNum<500 then
	-- 	statusNum = statusNum+100
	-- end
	-- local statusType = buffID % 1000000
	-- if buffID<10000 or buffID>990000 then
	-- 	statusNum = 0
	-- end
	-- return statusNum
end


--- skillID 轉換成 buffID
-- @param skillID int  - skill ID
-- @param overrideSeq int - 覆蓋 ID , 不填=流水號, 00=唯一的buffID, 99=不會清除的buff
-- @return buffID int - buff ID
function SActor:__skillID2buffID(skillID, overrideSeq)
	local seqno = 0
	if overrideSeq~=nil then
		seqno = overrideSeq
	else
		seqno = self.buffIDSeqNo
		self.buffIDSeqNo = self.buffIDSeqNo + 1
		if (self.buffIDSeqNo>=99) then
			self.buffIDSeqNo = 1
		end
	end
	return self.itemID * 1000000 + seqno * 10000 + skillID
end

--- 執行 buff 處理
-- @return null
function SActor:runBuff()
	if self.attribute.buffAttribute==nil then
		self:E('release problem buffAttribute recalBuff ',debug.traceback("", 2))
	end
	if table.nums(self.buffList)>0 then
		local statusNum
		local recal = false
		for k,v in pairs(self.buffList) do
			if self.buffList[k]~=nil then
				v:runBuff()
			end
			if self.buffList[k]~=nil and self.buffList[k].isRemove==1 then
				statusNum = self:__buffID2StatusNum(v.buffID,v.buffParameter['statusnum'])
				if self.statusList[statusNum]~=nil and v.buffID>10000 then
					self:removeStatusList(statusNum)
				end
				v:release()
				self.buffList[k] = nil
				recal=true
			end
			if self.buffList[k]==nil then
				recal=true
			end
		end
		if recal then
			self:reCalBuff()
		end
	end
end

function SActor:skillAttackMode9CallBack(p,itemID,atkP)
	if self.actorType==0 and p~=nil then
		self.counterObj:setCounter("npc_"..p)
	end
end

function SActor:checkSkillAttackMode7Status()
	-- body
end

--- 檢查角色info是否需要同步, 及做相應處理
-- @return null
function SActor:syncInfo()

	if self.deadFlag then
		self.deadFlag = false
		local tmp = {i={i=self.itemID,s=9,at=self.actorType,d=0.1}}
		-- local tmp = {i={i=self.itemID,t=self.teamOrig,a=self.attribute.roleId,at=self.attribute.actorType,hp=self.world.mFloor(self.attribute.HP),
		-- hpe=0,mhpe=0,mhp=self.attribute:getMaxHP(),mp=self.world.mFloor(self.attribute.MP),s=9,x=self.posX,y=self.posY,
		-- l=self.attribute.level,d=0.1,si=self.skinNum}}
		self:updateSyncMsg(tmp)
	end
	if self.dirty then
		self:__getAllInfo()
		--debuglog('jaylog SActor:syncInfo syncStatus start...')
		self:syncStatus()
	end

	if self.dirty then
		self:syncSkill(0.05)
		self:getAttribute(true)
	end
	--- rehp remp

	if self.attribute==nil then
		self:E("syncInfo bug.......itemID:",self.itemID," teamOrig:",self.teamOrig)
	end

	--攻击和被攻击10秒以后可以回血
	if (self.attribute.HP<self.attribute.MaxHP or self.attribute.MP<self.attribute.MaxMP) and self.world:getGameTime()>self.lastREHPattackTime+self.world.setting.AutoHpOutkill and self.world:getGameTime()>self.lastREHPHurtTime+self.world.setting.AutoHpOutkill and   self.attribute.actorType==0 and not self:isDead() and self.nextREHPMPTime < self.world:getGameTime()  then
		self.nextREHPMPTime = self.world:getGameTime() + self.world.setting.AutoHpTime
		--debuglog('jaylog attribute baseTable:'..self.world.cjson.encode(self.attribute.baseTable))

		-- local addHPminus,addMPminus = 0,0
		-- if self.attribute.AUTOHP>0 then
		-- 	addHPminus = self.attribute.AUTOHP*self.attribute.MaxHP
		-- end
		-- if self.attribute.AUTOMP>0 then
		-- 	addMPminus = self.attribute.AUTOMP*self.attribute.MaxMP
		-- end
		self:D("fenglog 回血  itemID:",self.itemID,self.attribute.baseTable['AUTOHP']*self.attribute.MaxHP*0.01,self.world:getGameTime(),self.lastREHPattackTime,self.lastREHPHurtTime)
		local AUTOMP = self.attribute.baseTable['AUTOMP']*self.attribute.MaxMP*0.01
		local AUTOHP = self.attribute.baseTable['AUTOHP']*self.attribute.MaxHP*0.01
		-- if self.statusList[73]~=nil then
		if self:safe() then
			AUTOMP=AUTOMP*self.world.setting.AutoHpSafe
			AUTOHP=AUTOHP*self.world.setting.AutoHpSafe
		end
		if self.nextREHPMPzzTimes == 3 then
			self.nextREHPMPzzTimes = 0
			self:D("MP 变化前1:",self.attribute.MP,AUTOMP,self.attribute.baseTable['AUTOMP'],self.attribute.baseTable['AUTOHP'],self.attribute.MaxMP)
			self:adjMP(AUTOMP,true)
			self:adjHP(AUTOHP,true)
		else
			--debuglog("fenglog 回血  只有自己看到 其他人看不到 1 "..self.itemID)
			self:D("MP 变化前2:",self.attribute.MP,AUTOMP,self.attribute.baseTable['AUTOMP'],self.attribute.baseTable['AUTOHP'],self.attribute.MaxMP)
			self:adjMP(AUTOMP,true,false,3)
			self.nextREHPMPzzTimes=self.nextREHPMPzzTimes+1
			self:adjHP(AUTOHP,true,false,3)
		end

	end

	-- if self:isDead() and self.syncMsg['i']~=nil and self.statusList[9]~=nil then
	-- 	local remaintime = self.statusList[9]['t']-(self.world:getGameTime()-self.statusList[9]['r'])
	-- 	if remaintime>2 then
	-- 		local s9data = {s=9,r=remaintime,t=self.statusList[9]['t'],i=self.itemID,p1=self.statusList[9]['p1'],p2=self.statusList[9]['p2'],p3=self.statusList[9]['p3'],p4=self.statusList[9]['p4'],p5=self.statusList[9]['p5'],p6=self.statusList[9]['p6']}
	-- 		-- local reviveCost
	-- 		-- local reviveCostType
	-- 		-- if self.world.gameRoomSetting['ISYW']==1 and self.actorType==0 then
	-- 		-- 	reviveCost = self.world.sSplitNumber(self.world.setting['YWreviveCost'],',')
	-- 		-- 	reviveCostType = self.world.tonumber(self.world.setting['YWreviveCostType'])
	-- 		-- 	if reviveCost[self.attribute.rebirth]==nil then
	-- 		-- 		s9data['p1'] = reviveCost[#reviveCost]
	-- 		-- 	else
	-- 		-- 		s9data['p1'] = reviveCost[self.attribute.rebirth]
	-- 		-- 	end
	-- 		-- 	s9data['p2'] = reviveCostType
	-- 		-- end
	-- 		self:D('jaylog SActor:syncInfo s9data ',self.world.cjson.encode(s9data),self.world.cjson.encode(reviveCost),self.world.setting['YWreviveCostType'])
	-- 		self:addStatusMsg(s9data)
	-- 	end
	-- end

	if (self.actorType==0 or self.actorType==2) and self.lastSyncTime<self.world:getGameTime() and (self.lastSyncHP~=self.attribute.HP or self.lastSyncMP~=self.attribute.MP) then
		self:getInfo()
		self.lastSyncHP = self.attribute.HP
		self.lastSyncMP = self.attribute.MP
		self.lastSyncTime = self.world:getGameTime() + 1
	end

end

--- 廣播 同步角色 all info
-- @param adjTime float - 調整時間
-- @param isReturn bool- 直接返回結果, 不廣播
-- @return infoMsg table - 角色info
function SActor:getAllInfo(adjTime,isReturn)
	if adjTime==nil then adjTime = 0 end
	if isReturn==nil then isReturn = true end
	return self:__getAllInfo(adjTime,isReturn)
end

--- 廣播 同步角色 all info
-- @param adjTime float - 調整時間
-- @param isReturn bool - 直接返回結果, 不廣播
-- @return infoMsg table - 角色info
function SActor:__getAllInfo(adjTime,isReturn)
	local result = self:__getInfo(adjTime,isReturn)
	result['i'] = self.itemID
	result['t'] = self.teamOrig
	if self.attribute.roleIdChange~=99999 then
		result['a'] = self.world.tonumber(self.attribute.roleIdChange)
	else
		result['a'] = self.world.tonumber(self.attribute.roleId)
	end
	if self.attribute.actorTypeChange~=99999 then
		result['at'] = self.attribute.actorTypeChange
	else
		result['at'] = self.attribute.actorType
	end
	if self.statusList[602]~=nil and self.actorType==0 then
		-- if (self.attribute.school==1 and self.world.mapModel=='506') or (self.attribute.school==2 and self.world.mapModel=='106') then
			result['a'] = self.world.playerList[self.itemID]['playerJson']['Player']['addStatusRole']
			result['at'] = self.world.playerList[self.itemID]['playerJson']['Player']['addStatusType']
		-- end
	end
	result['mhp'] = self.attribute:getMaxHP()
	result['mmp'] = self.attribute:getMaxMP()
	result['st'] = 0
	result['x'] = self.posX
	result['y'] = self.posY
	result['l'] = self.attribute.level
	local infoType = 0
	if self.attribute.loginIDNotShow~=0 or self.attribute.bloodNotShow~=0 then
		infoType = self.attribute.loginIDNotShow + self.attribute.bloodNotShow*10
	end
	result['v'] = infoType
	result['d'] = adjTime
	result['si'] = self.skinNum
	if self.actorType==0 or (self.actorType==2 and self.itemID<1000) then
		result['mspdr'] = self.attribute.baseTable.MSPD / self.world.setting.walkingSpeed
		result['aspdr'] = self.attribute.baseTable.HORSEMSPD / self.world.setting.walkingSpeed
	end
	result['mz'] = self.mapZone
	result['wing'] = 1
	result['lw'] = 1
	result['rw'] = 1

	if self.attribute.WINGID~=0 and self.attribute.WINGHIDE==0 then
		result['wing'] = self.attribute.WINGID-29999
		result['wingStage'] = self.attribute.WINGSTAGE
	end
	if self.attribute.WEAPONLID~=0 then
		result['lw'] = self.attribute.WEAPONLID-90999
		result['lwStage'] = self.attribute.WEAPONLSTAGE
	end
	if self.attribute.WEAPONRID~=0 then
		result['rw'] = self.attribute.WEAPONRID-90999
		result['rwStage'] = self.attribute.WEAPONRSTAGE
	end
	if self.actorType==0 or self.attribute.roleId=='996' then
		if self.attribute.DEMON1==0 then
			result['dm1'] = 1
		else
			result['dm1'] = self.attribute.DEMON1
		end
		if self.attribute.DEMON2==0 then
			result['dm2'] = 1
		else
			result['dm2'] = self.attribute.DEMON2
		end
		if self.attribute.DEMON3==0 then
			result['dm3'] = 1
		else
			result['dm3'] = self.attribute.DEMON3
		end
		if self.attribute.DEMON4==0 then
			result['dm4'] = 1
		else
			result['dm4'] = self.attribute.DEMON4
		end
		result['gl'] = self.attribute.GRADELEVEL
		result['angel'] = self.attribute.ANGEL
	end
	if self.blockLen~=0 then
		result['bl'] = self.blockLen
	end
	if self.blockWidth~=0 then
		result['bw'] = self.blockWidth
	end
	if self.attribute.COEFFICIENT>0 then
		result['xs'] = self.attribute.COEFFICIENT
	end
	if self.attribute.STANDPOINT>0 then
		result['jd'] = self.attribute.STANDPOINT
	end
	if self.attribute.actorType==0 then
		result['id'] = self.world.playerList[self.itemID]['id']
	end
	result['horse'] = self:__getHorseInfo(adjTime,true)

	--print(debug.traceback("", 2))
	self:D('check allinfo ',self.attribute.baseTable.HORSEMSPD,',',self.attribute.baseTable.MSPD," : ",self.world.cjson.encode(result))
	if isReturn then
		return result
	end
	self:updateSyncMsg({i=result})
	return result
end

--- 同步角色info
-- @param adjTime float - 調整時間
-- @param isReturn bool - 直接返回結果, 不廣播
-- @return infoMsg table - 角色info
function SActor:getInfo(adjTime)
	if adjTime==nil then adjTime = 0 end
	self:__getInfo(adjTime)
end


--- 同步角色騎馬訊息
-- @param adjTime float - 調整時間
-- @param isReturn bool - 直接返回結果, 不廣播
-- @return infoMsg table - 角色info
function SActor:__getHorseInfo(adjTime,isReturn)
	if adjTime==nil then adjTime = 0 end
	if isReturn==nil then isReturn = false end
	local result = {i=self.itemID,horse=0,d=adjTime,mz=self.mapZone}
	if (self.statusList[50]~=nil and self.attribute.HORSEID~=0 and self.world.gameRoomSetting['ISYW']==1) or (self.statusList[603]~=nil) then
		if self.statusList[603]~=nil then
			result['horse'] = 29999-20999
		else
			result['horse'] = self.attribute.HORSEID-20999
		end
	elseif self.attribute.HORSEID==0 then
		result['horse'] = 1
	end
	if isReturn then
		return result['horse']
	end
	self:updateSyncMsg({i=result})
end

--- 同步角色info
-- @param adjTime float - 調整時間
-- @param isReturn bool - 直接返回結果, 不廣播
-- @return infoMsg table - 角色info
function SActor:__getInfo(adjTime,isReturn,zz)
	if adjTime==nil then adjTime = 0 end
	if isReturn==nil then isReturn = false end
	if zz==nil then zz=0 end
	-- local result = {i=self.itemID,hp=self.world.mFloor(self.attribute.HP),hpe=self.world.mFloor(self.attribute.HPEXTRA),mp=self.world.mFloor(self.attribute.MP),
	local result = {i=self.itemID,hp=self.world.mFloor(self.attribute.HP),mp=self.world.mFloor(self.attribute.MP),
		s=(self:isDead() and 9 or 0),d=adjTime}
	--debuglog('jaylog __getInfo : '..self.world.cjson.encode(isReturn)..' '..self.world.cjson.encode(result))
	if zz>0 then
		--debuglog("fenglog 回血  只有自己看到 其他人看不到 3 "..self.itemID.." zz "..zz)
		result['zz']=zz
	end
	if isReturn then
		return result
	end
	self:updateSyncMsg({i=result})
	return result	
end



--- 子彈被取消callback
-- @param bulletID int - 子彈ID
-- @return null
function SActor:cancelBullet(bulletID)

end

--- 子彈完結callback
-- @param bulletID int - 子彈ID
-- @return null
function SActor:endBullet(bulletID)
end

--- 子彈擊中callback
-- @param bulletID int - 子彈ID
-- @param adjTime float - 調整時間
-- @return null
function SActor:dirtyBullet(bulletID,adjTime)

end


--- 重新計算所有有效buff
-- @return null
function SActor:reCalBuff()
	-- clean all buff
	if self.attribute.buffAttribute==nil then
		self:E('release problem buffAttribute recalBuff ',debug.traceback("", 2))
	end

	local status = self.world.gameRoomSetting.sendToClientStatusList
	local statusBuff = self.world.gameRoomSetting.sendToClientStatusBuffList

	-- get buff value before run buff
	local tmp1, tmp2, tmp3, tmpStatusNum, tmpStartTime, tmpRemainTime, buffValue, ok, buffName

	local beforeStatus = self.world.gameRoomSetting.checkEffectStatusList
	local beforeStatusValue = {}
	for k,v in pairs(beforeStatus) do
		tmpStatusNum = status[v]
		if tmpStatusNum~=nil then
			if self.statusList[tmpStatusNum]~=nil then
				beforeStatusValue[v] = self.statusList[tmpStatusNum]['r']+self.statusList[tmpStatusNum]['t']
			else
				beforeStatusValue[v] = 0
			end
		else
			if self.attribute.buffAttribute==nil then
				self:E('release problem reCalBuff '..self.itemID)
			end
			beforeStatusValue[v] = self.attribute.buffAttribute[v]
		end
	end
	local maxBuffTime = 0

	local plusBuff 
	local minusBuff
	local statusHas
	local keys
	local statusBuffHas = {}

	-- analysis buff list
	plusBuff, minusBuff, statusHas, keys, maxBuffTime = self:__analysisBuff()

	local gameTime = self.world:getGameTime()
	--- merge debuff and buff
	self.attribute.buffAttribute.func:reset()
	for k,v in pairs(keys) do

		buffValue = plusBuff.func:getVar(v) + minusBuff.func:getVar(v)
		-- if buffValue~=0 then
		if buffValue~=nil and self.attribute.baseTable[v]~=nil and (buffValue + self.attribute.baseTable[v])<0 then
			buffValue = - self.attribute.baseTable[v]
		end
		-- if v=="DEF" or v=="MDEF" or v=="MSPD" then
		-- 	debuglog("MK 测试 v:"..v.." buffValue:"..buffValue.." 基础属性:"..self.attribute[v])
		-- end
		self.attribute.buffAttribute.func:setVar(v,buffValue)
		-- if v=="DEF" or v=="MDEF" or v=="MSPD" then
		-- 	debuglog("MK 测试1 v:"..v.." buffValue:"..buffValue.." 基础属性:"..self.attribute[v])
		-- end
		
		if v=="MaxHP" and self.attribute.MaxHP~=self.attribute.baseTable.MaxHP then
			self:D("生命封锁添加 itemID:",self.itemID," self.attribute.MaxHP:",self.attribute.MaxHP," baseTable.MaxHP:",self.attribute.baseTable.MaxHP," p1:",self.world.mCeil((self.attribute.MaxHP/self.attribute.baseTable.MaxHP)*100))
			self:addStatusList({s=53,r=self.world:getGameTime(),t=99999,i=self.itemID,p1=self.world.mCeil((1-self.attribute.MaxHP/self.attribute.baseTable.MaxHP)*100)},0.2)
		end
		if v=="MaxHP" and self.attribute.MaxHP==self.attribute.baseTable.MaxHP then
			self:D("生命封锁取消")
			self:removeStatusList(53)
		end

		if buffValue~=0 then
			if buffValue>0 then
				buffName = v.."_UP"
			else
				buffName = v.."_DOWN"
			end
			if statusBuff[buffName]~=nil then
				tmpStatusNum = statusBuff[buffName]
				statusBuffHas[tmpStatusNum] = 1
				if self.statusList[tmpStatusNum]==nil or (self.statusList[tmpStatusNum]['r']+self.statusList[tmpStatusNum]['t']-gameTime)<maxBuffTime then
					if v=="MSPD" then
						self:addStatusList({s=tmpStatusNum,r=gameTime,t=maxBuffTime,i=self.itemID,p1=self.attribute.MSPD / self.world.setting.walkingSpeed * 100})
					else
						self:addStatusList({s=tmpStatusNum,r=gameTime,t=maxBuffTime,i=self.itemID})
					end
				end
			end
		end
	end

	--- remove statuslist
	for k,v in pairs(status) do
		if statusHas[v]==nil and self.statusList[v]~=nil then
			self:removeStatusList(v)
		end
	end
	for k,v in pairs(statusBuff) do
		if statusBuffHas[v]==nil and self.statusList[v]~=nil then
			self:removeStatusList(v)
		end
	end

	local statusListKeys = table.keys(self.statusList)
	if self.lastBulletID>0 and self.world.bulletList[self.lastBulletID] and self.world.bulletList[self.lastBulletID].mode>0 and (self.world.bulletList[self.lastBulletID].allowCancel==1 or self.world.bulletList[self.lastBulletID].allowStop==1) then
		if self.world.bulletList[self.lastBulletID]:checkAllowCancel(statusListKeys) then
			self.lastBulletID = 0
			self:setCoolDownTime(gameTime)
		end
	end

	tmpStatusNum = status['SILIENCE']
	if self.statusList[tmpStatusNum]~=nil then
		self.silentTimeSkill = self.statusList[tmpStatusNum]['r'] + self.statusList[tmpStatusNum]['t']
	else
		self.silentTimeSkill=0
	end
	for k,v in pairs({'DIZZY','FROZEN','SLEEP','PARALYSIS','STONE','DIZZYNOEFFECT'}) do
		if beforeStatusValue[v]>0 and self.statusList[status[v]]==nil then
			self.lastCoolDownTime = gameTime
		end
	end
	self.silentTime=0
	local tmpCDTime = self.lastCoolDownTime
	--debuglog("SHero:_autoFight reCalBuff前  lastCoolDownTime......."..self.lastCoolDownTime)
	--debuglog("测试晕眩 status:"..self.world.cjson.encode(status))
	for k,v in pairs({'DIZZY','FROZEN','SLEEP','PARALYSIS','STONE','DIZZYNOEFFECT'}) do
		tmpStatusNum = status[v]
		if self.statusList[tmpStatusNum]~=nil then
			if beforeStatusValue[v]==0 and not empty(self.paths) then
				self.lastCoolDownTime = gameTime
				self:moveTo(self.posX,self.posY)
			end
			self.lastStandByAttackTime=0
			self:removeSkillAttackMode7()
			if tmpCDTime<self.statusList[tmpStatusNum]['r']+self.statusList[tmpStatusNum]['t'] then
				tmpCDTime = self.statusList[tmpStatusNum]['r'] + self.statusList[tmpStatusNum]['t']
				--debuglog("测试晕眩 SHero:_autoFight reCalBuff中"..v.."    tmpCDTime......."..tmpCDTime)
			end
			if self.silentTime<self.statusList[tmpStatusNum]['r']+self.statusList[tmpStatusNum]['t'] then
				self.silentTime = self.statusList[tmpStatusNum]['r'] + self.statusList[tmpStatusNum]['t']
			end
			--debuglog("测试晕眩 晕眩数值 silentTime:"..self.silentTime.." gameTime:"..self.world:getGameTime())
			--运行反噬猫女
			if self.attribute.energyBoard~=nil and not self:isDead() then
				self.attribute.energyBoard:run("BITE",{})
			end
			--debuglog("测试晕眩 task 引导技能 打断 v:"..v)
			self:removeSkillAttackMode9()
		end
	end
	self:setCoolDownTime(tmpCDTime)
	--debuglog("SHero:_autoFight reCalBuff后  lastCoolDownTime......."..self.lastCoolDownTime)


	tmpStatusNum = status['STOPMOVE']
	if self.statusList[tmpStatusNum]~=nil then
		self:removeSkillAttackMode7()
		self.attribute.buffAttribute.func:setVar("MSPD",1 -  self.attribute.MSPD)
		self:D("STOPMOVE.............buffAttribute.MSPD:",self.attribute.buffAttribute.MSPD)
		self:D("STOPMOVE..............MSPD:",self.attribute.MSPD)
	elseif beforeStatusValue['STOPMOVE']>0 and self.statusList[tmpStatusNum]==nil then
		self.targetPosition.x = self.posX
		self.targetPosition.y = self.posY
	end
	--- mspd
	if beforeStatusValue['MSPD']~=self.attribute.buffAttribute.MSPD then
		--self:debuglog('jaylog check MSPD before:',beforeStatusValue['MSPD'],' now:',self.attribute.buffAttribute.MSPD,' mspd:',self.attribute.MSPD)
		--self:D('jaylog check MSPD before:',beforeStatusValue['MSPD'],' now:',self.attribute.buffAttribute.MSPD,' mspd:',self.attribute.MSPD)
		if self.attribute.buffAttribute.MSPD>beforeStatusValue['MSPD'] then
			self.checkOverLapTime = 0
		end
		
		if not self.world.map:equalPoint(self.targetPosition,self.posX,self.posY) then
			self:moveTo(self.targetPosition.x,self.targetPosition.y,true)
		end
	end
	--self:debuglog('jaylog check MSPD before:',beforeStatusValue['MSPD'],' now:',self.attribute.buffAttribute.MSPD,' mspd:',self.attribute.MSPD)
	self.outOfCtlTime = 0
	--- out of ctl

	tmpStatusNum = status['OUTCTL']
	if self.statusList[tmpStatusNum]~=nil then
		if self.attribute.actorType==0 or self.attribute.actorType==1 then
			self.prepareSkillAttackNum = 0
			self.attackTarget = 0
		end
		self:removeSkillAttackMode7()
		self:D("有没有添加outOfCtlTime")
		self.outOfCtlTime = self.statusList[tmpStatusNum]['r'] + self.statusList[tmpStatusNum]['t']
		--运行反噬猫女
		if self.attribute.energyBoard~=nil and not self:isDead() then
			self.attribute.energyBoard:run("BITE",{})
		end
		self:D("task 引导技能 打断 OUTCTL")
		self:removeSkillAttackMode9()
	end

	tmpStatusNum = status['INVICINBLE']
	if beforeStatusValue['INVICINBLE']>0 and self.invincibleTime<=beforeStatusValue['INVICINBLE'] then
		self.invincibleTime = 0
	end
	if self.statusList[tmpStatusNum]~=nil then
		if self.attribute.actorType==0 then
			self.prepareSkillAttackNum = 0
		end
		self:D("有没有添加invincibleTime")
		self.invincibleTime = self.statusList[tmpStatusNum]['r'] + self.statusList[tmpStatusNum]['t']
		self:D("invincibleTime :",self.invincibleTime," gameTime:"..self.world:getGameTime()," gameTime:",self.world.gameTime)
	end

	-- --- extra hp
	if beforeStatusValue['HPEXTRA']==nil or beforeStatusValue['HPEXTRA']~=self.attribute.buffAttribute.HPEXTRA then
		if beforeStatusValue['HPEXTRA']==nil then
			beforeStatusValue['HPEXTRA'] = 0
		end

		self:D("护盾 HPEXTRA :",beforeStatusValue['HPEXTRA']," _ ",self.attribute.buffAttribute.HPEXTRA)
		if beforeStatusValue['HPEXTRA']>self.attribute.buffAttribute.HPEXTRA then
			if self.attribute.HPEXTRA>self.attribute.buffAttribute.HPEXTRA then
				self.attribute.HPEXTRA = self.attribute.buffAttribute.HPEXTRA
			end
		else
			self.attribute.HPEXTRA = self.attribute.HPEXTRA + self.attribute.buffAttribute.HPEXTRA - beforeStatusValue['HPEXTRA']
		end
		self.attribute.MaxHPEXTRA = self.attribute.buffAttribute.HPEXTRA
		self:adjHP(0)
		--self:__getInfo()
		--self.syncMsg['i']['mhpe'] = self.attribute.MaxHPEXTRA
	end
	if self.attribute.buffAttribute==nil then
		self:E('release problem buffAttribute recalBuff ',debug.traceback("", 2))
	end

end


--- 調整HP
-- @param hp float - HP
-- @param forceSync bool - 強制同步
-- @param must bool - 必定傷HP
-- @param zz -- zz=1 廣播時自己收不到(主要在即時返回用) zz=3  廣播時其他人收不到
-- @return success bool - true = ok
function SActor:adjHP(hp,forceSync,must,zz)
	--self.world:debuglog('jaylog SActor:adjHP before roleId',self.attribute.roleId,' itemID',self.itemID,' hp:',self.attribute.HP,' maxHP:',self.attribute.MaxHP,' bhp:',self.attribute.baseTable.HP,' bmaxHP:',self.attribute.baseTable.MaxHP)
	if forceSync==nil then forceSync = false end
	if must==nil then must = false end
	if zz==nil then zz = 0 end

	if hp>0 and self.status==9 then return false end
	if self.attribute.HPEXTRA>0 and hp<0 then
		self:D("护盾厚度为:",self.attribute.HPEXTRA)
		if self.attribute.HPEXTRA+hp>0 then
			self.attribute.HPEXTRA = self.attribute.HPEXTRA + hp 
			self:D("剩余护盾:",self.attribute.HPEXTRA)
			hp = 0
		else
			self.attribute.HPEXTRA = 0
			hp = self.attribute.HPEXTRA + hp
			self:D("护盾没了 剩余伤害:",hp)
		end
	end

	local old = self.attribute.HP
	self.attribute.HP = math.round(self.attribute.HP + hp, 1)
	if self.attribute.HP>self.attribute:getMaxHP() then self.attribute.HP = self.attribute:getMaxHP() end

	if self.attribute.HP<1 then 
		self.attribute.HP = 0 
	end
	--测试专用
	if forceSync then --or (self.attribute.actorType==0 and old~=self.attribute.HP and not self:isDead()) then
		--debuglog("fenglog 回血  只有自己看到 其他人看不到 2 "..self.itemID.." zz "..zz)
		--满血直接同步
		if self.attribute.HP ==self.attribute.MaxHP then
			zz=0
		end
		self:__getInfo(0,false,zz)
	end

	if self.attribute.actorType==0 then
		self:D("heroHp itemID:",self.itemID," boss 当前血量为:",self.attribute.HP," maxHP:",self.attribute.MaxHP)
	end
	--self.world:debuglog('jaylog SActor:adjHP after roleId',self.attribute.roleId,' itemID',self.itemID,' hp:',self.attribute.HP,' maxHP:',self.attribute.MaxHP,' bhp:',self.attribute.baseTable.HP,' bmaxHP:',self.attribute.baseTable.MaxHP)

	return true
end


--- 調整ABSORDCURE 
-- @param hp float - ABSORDCURE
-- @param forceSync bool - 強制同步
-- @param must bool - 必定傷HP
-- @return success bool - true = ok
function SActor:adjABSORDCURE(hp,forceSync,must)
	--self.world:debuglog('jaylog SActor:adjHP before roleId',self.attribute.roleId,' itemID',self.itemID,' hp:',self.attribute.HP,' maxHP:',self.attribute.MaxHP,' bhp:',self.attribute.baseTable.HP,' bmaxHP:',self.attribute.baseTable.MaxHP)
	if forceSync==nil then forceSync = false end
	if must==nil then must = false end


	local old = self.attribute.ABSORDCURE
	self.attribute.ABSORDCURE = math.round(self.attribute.ABSORDCURE + hp, 1)
	if self.attribute.ABSORDCURE>self.attribute.MAXABSORDCURE then self.attribute.ABSORDCURE = self.attribute.MAXABSORDCURE end

	if self.attribute.ABSORDCURE<1 then 
		self.attribute.ABSORDCURE = 0 
	end

	if self.attribute.ABSORDCURE==0 then
		self:removeBUff("MAXABSORDCURE")
	end


	self:D("ABSORDCURE adjABSORDCURE:",self.attribute.ABSORDCURE," k:",hp)

	return true
end

--- 調整HURTDESTROY
-- @param hp float - HURTDESTROY
-- @param forceSync bool - 強制同步
-- @param must bool - 必定傷HP
-- @return success bool - true = ok
function SActor:adjHURTDESTROY(hp,forceSync,must)
	--self.world:debuglog('jaylog SActor:adjHP before roleId',self.attribute.roleId,' itemID',self.itemID,' hp:',self.attribute.HP,' maxHP:',self.attribute.MaxHP,' bhp:',self.attribute.baseTable.HP,' bmaxHP:',self.attribute.baseTable.MaxHP)
	if forceSync==nil then forceSync = false end
	if must==nil then must = false end


	local old = self.attribute.HURTDESTROY
	self.attribute.HURTDESTROY = math.round(self.attribute.HURTDESTROY + hp, 1)
	if self.attribute.HURTDESTROY>self.attribute.MAXHURTDESTROY then self.attribute.HURTDESTROY = self.attribute.MAXHURTDESTROY end

	if self.attribute.HURTDESTROY<1 then 
		self.attribute.HURTDESTROY = 0 
	end

	if self.attribute.HURTDESTROY==0 then
		self:removeBUff("MAXHURTDESTROY")
	end

	return true
end

--- 調整MP
-- @param mp float - MP
-- @param forceSync bool - 強制同步
-- @param must bool - 必定傷MP
-- @return success bool - true = ok
function SActor:adjMP(mp,forceSync,must)
	--debuglog("MP 变化前:"..self.attribute.MP)
	if forceSync==nil then forceSync = false end
	if must==nil then must = false end
	local old = self.attribute.MP
	self.attribute.MP = self.attribute.MP + mp
	if self.attribute.MP>self.attribute:getMaxMP() then self.attribute.MP = self.attribute:getMaxMP() end
	if self.attribute.MP<0 then self.attribute.MP = 0 end
	if forceSync or (self.attribute.actorType==0 and old~=self.attribute.MP and not self:isDead()) then
		self:__getInfo()
	end
	self:D("MP 变化后:",self.attribute.MP)	
	return true
end

--- 計算傷害
-- @param itemID int - 攻擊方itemID
-- @param hitValue table - 計算參數
-- @return hurt float - 傷害值
function SActor:calHurted(itemID,hitValue)
	-- self:I(self.itemID.." 被打 "..itemID )
	-- self:I("calHurted hitValue ",self.world.cjson.encode(hitValue))
	local hurt,aphurt,adhurt = 0 , 0 , 0
	local formula = self.world.formula
	local attribute = self.attribute
	--傷害定值
	local obj = self.world.allItemList[itemID]

	--先计算命中率~~~
	--self.world:setRandomSeed()
	local isHit = formula:isHIT(hitValue,attribute)

	if (hitValue['INEVITABLEHIT']~=nil and hitValue['INEVITABLEHIT']==1) or (obj~=nil and self.teamOrig==obj.teamOrig) then
		
		--self:D("强制命中调整........")
		isHit = true
	end
	
	--强制闪避
	if hitValue['CERTAINLDODGE']~=nil then
		isHit = false
	end

	if isHit then
		--下面计算普通攻击伤害
		hurt,aphurt,adhurt = formula:allHurt(hitValue,obj.attribute,attribute)
		--self:I("总伤害是 被打方itemID:",self.itemID," 攻击方:",itemID," hurt:",hurt)
		--计算暴击率

		local isCRI = formula:isCRI(hitValue,obj.attribute,attribute)

		--强制暴击
		if attribute.buffAttribute==nil then
			self:E('release problem buffAttribute.SENSE ',self.itemID)
		end
		if attribute.buffAttribute.SENSE>0 then
			isCRI = true
			--self:D("强制暴击 SENSE.............")
		end
		--强制暴击
		if hitValue['INEVITABLECRI']~=nil and hitValue['INEVITABLECRI']==1 then
			isCRI = true
		end	

		if  hurt ~=0 and isCRI  then
			--暴击伤害翻倍
			--self:D("这里需要暴击.....")
			hurt = hurt + hurt
			--if hitValue['Effect']==nil then
			hitValue['Effect'] = 1
			--end
		end

		--计算多段伤害 --计算普通攻击额外的暴击伤害
		hurt = hurt * (hitValue['SEPARATE']*0.01) * hitValue['CRIhurt']
		-- --计算普通攻击额外的暴击伤害
		-- hurt = hurt * hitValue['CRIhurt']

		--计算多段伤害 --计算普通攻击额外的暴击伤害
		aphurt = aphurt * (hitValue['SEPARATE']*0.01) * hitValue['CRIhurt']
		-- --计算普通攻击额外的暴击伤害
		-- aphurt = aphurt * hitValue['CRIhurt']
		--计算多段伤害
		adhurt = adhurt * (hitValue['SEPARATE']*0.01) * hitValue['CRIhurt']
		-- --计算普通攻击额外的暴击伤害
		-- adhurt = adhurt * hitValue['CRIhurt']
	else
		if hitValue['FIXHURT']==0 and hitValue['FIXREHP']==0 and self.itemID~=itemID and (obj~=nil and self.teamOrig~=obj.teamOrig) then
			self:D("这里需要闪避/.........")
			if hitValue['Effect']==nil or hitValue['Effect']>=0 then
				hitValue['Effect'] = 2
				hitValue['BUFFTIME']=0
			end
		end
	end

	if hitValue['FIXHURT']~=nil then
		--self:D("流血......FIXHURT:",hitValue['FIXHURT'])
		if hitValue['FIXHURT']>attribute.HP and self.itemID==itemID then
			--hitValue['FIXHURT'] = self.attribute.HP-6
			--self:D("流血过度......FIXHURT:",hitValue['FIXHURT'])
			if attribute.HP>0 then
				hitValue['FIXHURT'] = attribute.HP-1
			end
		end
		--hurt = hurt + hitValue['FIXHURT']
		if hitValue['ISPVP']>0 then
			if hitValue['ISVAMPIREAD']==nil then
				--hurt = hurt - hitValue['FIXREHP']*self.world.formula:getTenacity(hitValue['ISPVP'],self.attribute.level)
				hurt = hurt + hitValue['FIXHURT']*self.world.formula:getTenacity(obj.attribute.actorType,self.attribute.actorType,self.attribute.level)
			else
				hurt = hurt + hitValue['FIXHURT']
			end
		else
			if hitValue['ISVAMPIREAD']==nil then
				hurt = hurt + hitValue['FIXHURT']*self.world.formula:getGVBREHPTenacity(obj.attribute.level)
			else
				hurt = hurt + hitValue['FIXHURT']
			end
		end
	end

	--self:D("hurted invincibleTime :"..self.invincibleTime.." gameTime:"..self.world:getGameTime().." gameTime:"..self.world.gameTime,self.world.cjson.encode(self.statusList[73]))
	--无敌
	if self.invincibleTime~=nil and self.invincibleTime>=self.world:getGameTime() and self.statusList[4007]==nil and self.teamOrig~=obj.teamOrig and (hitValue['Effect']==nil or hitValue['Effect']>=0) then
		hurt = 0
		-- if self.statusList[73]==nil then
		if not self:safe() then
			hitValue['Effect'] = 3
		end
		--self:D("触发无敌")
	end

	--回血定值
	if hitValue['FIXREHP']~=nil  and hitValue['FIXREHP']>0 then
		--计算治疗量降低
		if attribute.BECURE>0 then
			--self:D("BECURE 治疗吸收:",attribute.BECURE," 减少前是:"..hitValue['FIXREHP'])
			hitValue['FIXREHP'] = hitValue['FIXREHP'] * attribute.BECURE
			--self:D("BECURE 治疗吸收:",attribute.BECURE," 减少后是:"..hitValue['FIXREHP'])
			if hitValue['FIXREHP']<0 then
				hitValue['FIXREHP'] = 0
			end
		end
		--计算治疗量全吸收
		if attribute.ABSORDCURE>0 then
			local oldFIXREHP  = hitValue['FIXREHP']
			hitValue['FIXREHP'] = hitValue['FIXREHP'] - attribute.ABSORDCURE
			--self.attribute.ABSORDCURE = self.attribute.ABSORDCURE - oldFIXREHP
			self:adjABSORDCURE(-oldFIXREHP)
			if hitValue['FIXREHP']<0 then
				hitValue['FIXREHP'] = 0
			end
			--self:D("ABSORDCURE 护盾值还剩:",attribute.ABSORDCURE,'itemID',self.itemID,'roleId',attribute.roleId)
		end
		if obj~=nil then
			hurt = hurt - hitValue['FIXREHP']
			-- if hitValue['ISPVP']>0 then
			-- 	if hitValue['ISVAMPIREAD']==nil then
			-- 		--hurt = hurt - hitValue['FIXREHP']*self.world.formula:getTenacity(hitValue['ISPVP'],self.attribute.level)
			-- 		hurt = hurt - hitValue['FIXREHP']*formula:getTenacity(obj.attribute.actorType,attribute.actorType,attribute.level)
			-- 	else
			-- 		hurt = hurt - hitValue['FIXREHP']
			-- 	end
			-- else
			-- 	if hitValue['ISVAMPIREAD']==nil then
			-- 		hurt = hurt - hitValue['FIXREHP']*formula:getGVBREHPTenacity(obj.attribute.level)
			-- 	else
			-- 		hurt = hurt - hitValue['FIXREHP']
			-- 	end
			-- end
		end
	end

	hurt = self.world.mCeil(hurt)


	if aphurt>0 and attribute.REFLECTAP>0 and self.itemID~=obj.itemID and hitValue['NOREBOUND']==nil then
		--self:D("魔法伤害反弹  反弹比例:",attribute.REFLECTAP," 源伤害:",aphurt," 反弹伤害:",(aphurt*attribute.REFLECTAP*0.01))
		obj:adjHP(-aphurt*attribute.REFLECTAP*0.01)
		obj:updateSyncMsg({h={{i=obj.itemID,t=0,d=adjTime,h=self.world.mFloor(aphurt*attribute.REFLECTAP*0.01),hp=self.world.mFloor(obj.attribute.HP),hpe=0,ti=itemID,m=1,s=0}}})
		hurt = hurt - aphurt
		hitValue['Effect'] = 4
	end
	if adhurt>0 and attribute.REFLECTAD>0 and self.itemID~=obj.itemID and hitValue['NOREBOUND']==nil then
		--self:D("物理伤害反弹  反弹比例:",attribute.REFLECTAD.." 源伤害:"..adhurt.." 反弹伤害:"..(adhurt*attribute.REFLECTAD*0.01))
		obj:adjHP(-adhurt*attribute.REFLECTAD*0.01)
		obj:updateSyncMsg({h={{i=obj.itemID,t=0,d=adjTime,h=self.world.mFloor(adhurt*attribute.REFLECTAD*0.01),hp=self.world.mFloor(obj.attribute.HP),hpe=0,ti=itemID,m=1,s=0}}})
		hurt = hurt - adhurt
		hitValue['Effect'] = 5
	end

	--物理伤害
	if hurt>0 then
		--计算物理伤害承受
		if attribute.HURTDESTROY>0 then
			self:adjHURTDESTROY(-hurt)
			--self:D("HURTDESTROY 护盾值还剩:",attribute.HURTDESTROY)
		end
	end


	local csstr = ""
	for k,v in pairs(self.attribute) do
		if type(v)~="table" and type(v)~="userdata" then
			csstr = csstr.." "..k..":"..v
		end	
	end

	if hitValue['BEHEADEDHURT']~=nil and hitValue['BEHEADEDHURT']~=0 and obj.attribute.parameterArr['BEHEADEDHP']~=nil then
		-- 狂战士第4技能击中血量少于20%的玩家会就5位伤害
		self:D('jaylog hurted BEHEADEDHURT:',hitValue['BEHEADEDHURT'],obj.attribute.parameterArr['BEHEADEDHP'],self.attribute.HP,self.attribute.MaxHP)
		if self.attribute.HP<self.attribute.MaxHP*obj.attribute.parameterArr['BEHEADEDHP']*0.01 then
			hurt = hurt * hitValue['BEHEADEDHURT']
			self:D('jaylog hurted hurt:',hurt)
		end
	end

	self:D("计算伤害 攻击方itemID:",itemID," mode:",hitValue['mode']," hitValue:",self.world.cjson.encode(hitValue)," 被打方itemID:",
	self.itemID,"属性:",csstr," 是否暴击:",(hitValue['Effect']==1 and "是" or " 否")
	," 是否闪避:",(hitValue['Effect']==2 and "是" or " 否")," hurt:",hurt," 剩余血量:",(self.attribute.HP-hurt))
	
	-- hurt = 1
	return hurt

end

--- 直接傷害
-- @param itemID int - 攻擊方itemID
-- @param mode int - 技能1-7
-- @param hitValueNew table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SActor:directHurt(itemID,mode,hitValueNew,adjTime)
	--self:D("directHurt: itemID:",itemID,mode,self.world.cjson.encode(hitValueNew))
	if mode==0 then mode=1 end

	local hitValue = self:createhitValue()
	

	for k,v in pairs(hitValueNew) do
		hitValue[k] = v
	end

	if hitValue['changeMode']~=nil then
		mode = hitValue['changeMode']
		debuglog("changeMode mode"..mode)
	end

	hurt = self:hurted(itemID,0,mode,hitValue,adjTime)

	if itemID>0 and self.world.allItemList[itemID]~=nil then
		--self.world:D("directHurt: itemID directHurtCallBack:"..itemID,mode,self.world.cjson.encode(hitValueNew))
		self.world.allItemList[itemID]:directHurtCallBack(self.itemID,mode,hitValue,adjTime,hurt)
	end

	return hurt
end

--- 直接傷害callBack
-- @param itemID int - 受傷害方itemID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @param hurt float - 傷害值
-- @return null
function SActor:directHurtCallBack(itemID,mode,hitValue,adjTime,hurt)

end

--- 受傷害計算
-- @param itemID int - 攻擊方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SActor:hurted(itemID,bulletID,mode,hitValue,adjTime)
	--安全区不让打人
	-- if self.statusList[73]~=nil or self.statusList[76]~=nil then
	if self.itemID~=itemID and (self:safe() or self.statusList[76]~=nil) then
		return 0
	end
	local obj = self.world.allItemList[itemID]
	--新手保护
	if not self:newbieProtection(obj.attribute.actorType,obj.attribute.level,obj.teamOrig,self.attribute.actorType,self.attribute.level,self.teamOrig,self.lastREHPattackTime) then
		self:D("被攻击触发新手保护 攻击方:",obj.attribute.actorType,obj.attribute.level,obj.teamOrig,"防御方:",self.attribute.actorType,self.attribute.level,self.teamOrig,"地图:",self.world.gamePort)
		return 0
	end

	-- self:I(self.itemID.." 被 "..itemID.." 打".." bulletID:"..bulletID)
	local origEffect = 0
	local hurt = 0
	local specialEffect = 0


	local notDead = false
	if not self:isDead() then
		notDead = true
	end

	hitValue['adjTime'] = adjTime

	--魔法免疫
	if self.statusList~=nil and self.statusList[33]~=nil and hitValue['APADJ']>0 then
		hitValue['APADJ'] = 0
		hitValue['APS'] = 0
		hitValue['Effect'] = 4
	end
	--物理免疫
	if self.statusList~=nil and self.statusList[34]~=nil and hitValue['ADADJ']>0 then
		hitValue['ADADJ'] = 0
		hitValue['ADS'] = 0
		hitValue['Effect'] = 5
	end

	--清除目标身上的status
	if hitValue['CLEANTARGETSTATUS']~=nil and self.statusList[hitValue['CLEANTARGETSTATUS']]~=nil then
		--self:removeStatusList(hitValue['CLEANTARGETSTATUS'])
		self:removeStatusListNoNext(hitValue['CLEANTARGETSTATUS'])
	end

	local alist = {"A","B","C","D","E","F"}
	for i=1,#alist do
		if hitValue['SCLEANTARGETSTATUS'..alist[i]]~=nil and self.statusList[hitValue['SCLEANTARGETSTATUS'..alist[i]]]~=nil then
			--self:removeStatusList(hitValue['CLEANTARGETSTATUS'])
			self:removeStatusListNoNext(hitValue['SCLEANTARGETSTATUS'..alist[i]])
		end
	end

	-- --计算伤害数值
	hurt = self:calHurted(itemID,hitValue)

	if hitValue['BEHEADEDHURT']~=nil and hitValue['BEHEADEDHURT']~=0 and obj.attribute.parameterArr['BEHEADEDHP']~=nil then
		self:D('jaylog hurted BEHEADEDHURT Effect6:',hitValue['BEHEADEDHURT'],obj.attribute.parameterArr['BEHEADEDHP'],self.attribute.HP,self.attribute.MaxHP,'itemID:',self.itemID,obj.itemID)
		if self.attribute.HP<self.attribute.MaxHP*obj.attribute.parameterArr['BEHEADEDHP']*0.01 then
			-- 增加致死标记
			hitValue['Effect'] = 6
			self:D('jaylog hurted add Effect6')
		end
	end
	-- --假如是免疫 取消负面状态
	if hurt==0 and (hitValue['Effect']==5 or hitValue['Effect']==4 or hitValue['Effect']==3) then
		self:D("免疫 取消负面buff")
		local IMMUNECONTROLtb = {
			DIZZY = 0,
			DIZZYNOEFFECT = 0,
			SILIENCE = 0,
			OUTCTL = 0,
			STONE = 0,
			PARALYSIS = 0,
			FROZEN = 0,
			SLEEP = 0,
		}

		local IMMUNEDEBUFFtb = {
			POISON = 0,
			BLEED = 0,
			BURN = 0,
			DEF = 0,
			CRI = 0,
			ATK = 0,
			MSPD = 0,
			MDEF = 0,
			HP = 0,
			HIT = 0,
			DODGE = 0,
			ATKDIS = 0,
		}
		for k,v in pairs(IMMUNEDEBUFFtb) do
			if hitValue[k..'_DOWN_RATE']~=nil and hitValue[k..'_DOWN_RATE']>0 then
				hitValue[k..'_DOWN_RATE']=0
			end
			if hitValue[k..'_DOWNFIX_RATE']~=nil and hitValue[k..'_DOWNFIX_RATE']>0 then
				hitValue[k..'_DOWNFIX_RATE']=0
			end	
		end
		for k,v in pairs(IMMUNECONTROLtb) do
			if hitValue[k..'_RATE']~=nil and hitValue[k..'_RATE']>0 then
				hitValue[k..'_RATE']=0
			end
		end

	end



	--自动添加状态
	if hitValue['ADDSTATUS']~=nil and hitValue['ADDSTATUS']>0 then
		self:D("add status 自动添加状态:",hitValue['ADDSTATUS'])
		if hitValue["TRIGGERSTATUS"]~=nil and hitValue["TRIGGERSTATUS"] > 0 then	
			self:D("add status 自动添加状态 2层:",hitValue['TRIGGERSTATUS'])
			self:D("remove status list find nextStatus add time :",self.world.gameTime," mode:",mode)
			self:addScheduleStatusList(0,{s=hitValue['ADDSTATUS'],t=hitValue['ADDSTATUSTIME']},{s=hitValue["TRIGGERSTATUS"],t=hitValue['TRIGGERSTATUSTIME']})	
		else
			self:D("add status 自动添加状态1:",hitValue['ADDSTATUS'])
			self:addStatusList({s=hitValue['ADDSTATUS'],r=self.world.gameTime,t=hitValue['ADDSTATUSTIME'],i=self.itemID},0)
		end
	end


	local alist = {"A","B","C","D","E","F"}
	for i=1,#alist do
		--自动添加状态 全自动加状态
		if hitValue['SADDSTATUS'..alist[i]]~=nil and hitValue['SADDSTATUS'..alist[i]]>0 then
			self:D("add status 自动添加状态:",hitValue['SADDSTATUS'..alist[i]])

			if hitValue["STRIGGERSTATUS"..alist[i]]~=nil and hitValue["STRIGGERSTATUS"..alist[i]] > 0 then	
				self:D("add status 自动添加状态 2层:",hitValue['STRIGGERSTATUS'..alist[i]])
				self:D("remove status list find nextStatus add time :",self.world.gameTime," mode:",mode)
				local s = {s=hitValue['SADDSTATUS'..alist[i]],t=hitValue['SADDSTATUSTIME']..alist[i]}
				if s['s']==41 and hitValue['CHANTSHOW']~=nil then
					s['p4'] = hitValue['CHANTSHOW']
				end
				local s1 = {s=hitValue["STRIGGERSTATUS"..alist[i]],t=hitValue['STRIGGERSTATUSTIME'..alist[i]]}
				if s1['s']==41 and hitValue['CHANTSHOW']~=nil then
					s1['p4'] = hitValue['CHANTSHOW']
				end
				self:addScheduleStatusList(0,s,s1)	
			else
				self:D("add status 自动添加状态1:",hitValue['SADDSTATUS'..alist[i]])
				local s = {s=hitValue['SADDSTATUS'..alist[i]],r=self.world.gameTime,t=hitValue['SADDSTATUSTIME'..alist[i]],i=self.itemID}
				if s['s']==41 and hitValue['CHANTSHOW']~=nil then
					s['p4'] = hitValue['CHANTSHOW']
				end
				self:addStatusList(s,0)
			end
		end	

	end


	--反弹计算 百分比
	if self.attribute.REBOUND~=nil and self.attribute.REBOUND>0 and hurt>0 and self.teamOrig~=obj.teamOrig and hitValue['NOREBOUND']==nil then
		local hitValueNew = {}
		hitValueNew['FIXHURT']  = (self.attribute.REBOUND/100)*hurt
		obj:directHurt(itemID,mode,hitValueNew,0) 
		self:D("反弹计算 百分比........... 被打:",self.itemID," GJ:",itemID,hitValueNew['FIXHURT'])
	end
	--反弹计算 定值
	if self.attribute.REBOUNDFIX~=nil and self.attribute.REBOUNDFIX>0 and hurt>0 and self.teamOrig~=obj.teamOrig and hitValue['NOREBOUND']==nil then
		local hitValueNew = {}
		hitValueNew['FIXHURT']  = self.attribute.REBOUNDFIX
		obj:directHurt(itemID,mode,hitValueNew,0) 
		--self:D("反弹计算 定值........... 被打:",self.itemID," GJ:",itemID)
	end

	--计算触发boss攻击时间
	if hurt>0 and self.world.gameRemainStartTime==0 and (self.attribute.actorType==2 or obj.attribute.actorType==2) then
		self.world.gameRemainStartTime = self.world.gameTime
	end
	--添加仇恨值列表--伤害
	if self.itemID~=itemID and self.teamOrig~=obj.teamOrig and hurt>0 and mode>0 then
		--self:D("仇恨 mode:"..mode)
		if self.startHurtTime==0 then
			self.startHurtTime = self.world.gameTime
			if self.world.gameRoomSetting['ISGVB']==1 and self.world.startCalDPSTime==0 then
				self.world.startCalDPSTime = self.world.gameTime
			end
		end
		local skill = obj.attribute.skills[mode] 
		local hurtThreatFixValue = 1
		if skill==nil then
			hurtThreatFixValue = 1
		else
			hurtThreatFixValue = skill.hurtThreatFixValue
		end
		--将bb转换成主人攻击
		if obj.parent~=nil and obj.parent.attribute~=nil and  obj.parent.attribute.actorType==0 and self.itemID~=itemID then
			self.Hatredlist[""..obj.parent.itemID] = (self.Hatredlist[""..obj.parent.itemID]~=nil and self.Hatredlist[""..obj.parent.itemID] or 0) + hurt * (hurtThreatFixValue*self.attribute.THREATFIXVALUE)
		else
			self.Hatredlist[""..itemID] = (self.Hatredlist[""..itemID]~=nil and self.Hatredlist[""..itemID] or 0) + hurt * (hurtThreatFixValue*self.attribute.THREATFIXVALUE)
		end
		--self.Hatredlist[""..itemID] = (self.Hatredlist[""..itemID]~=nil and self.Hatredlist[""..itemID] or 0) + hurt * (hurtThreatFixValue*self.attribute.THREATFIXVALUE)
		--self:D("itemID:",self.itemID," 仇恨列表:",self.world.cjson.encode(self.Hatredlist))
	end
	--添加仇恨值列表--治疗
	if self.teamOrig==obj.teamOrig and hurt<0 and mode>0 and hitValue['FIXREHP']>0 then
		local dlist = {}
		if (self.teamOrig~="B") then
		  dlist = self.world.itemListFilter.teamB
		else  
		  dlist = self.world.itemListFilter.teamA
		end
		local skill = obj.attribute.skills[mode]
		local healThreatFixValue = 1
		if skill==nil then
			healThreatFixValue = 1
		else
			healThreatFixValue = skill.healThreatFixValue
		end
		for k,v in pairs(dlist) do
			--被治疗的人 在其他人的仇恨列表里面则增加奶妈的仇恨
			if v.Hatredlist[""..self.itemID]~=nil then
				v.Hatredlist[""..itemID] = (v.Hatredlist[""..itemID]~=nil and v.Hatredlist[""..itemID] or 0) - hurt * healThreatFixValue
				--self:D("itemID:",self.itemID,"治疗 仇恨列表:",self.world.cjson.encode(v.Hatredlist))
			end
		end
	end

	--标记十秒内被谁打了
	if self.lastHurtItemID~=0 and self.lastHurtTime+10<self.world:getGameTime() then
		self.lastHurtItemID = 0
	end
	if hurt>0 and itemID~=self.itemID and self.lastHurtTime+10<self.world:getGameTime() then
		if obj.attribute.actorType==0 then
			self.lastHurtItemID = itemID
			self.lastHurtTime = self.world:getGameTime()
		end
	end

	--标记十秒内被谁打了
	if self.lastHurtAllID~=0 and self.lastHurtAllTime+10<self.world:getGameTime() then
		self.lastHurtAllID = 0
	end
	if hurt>0 and itemID~=self.itemID  then
		self.lastHurtAllID = itemID
		self.lastHurtAllTime = self.world:getGameTime()
	end

	--进入战斗状态 被打
	if (hurt~=0 or hitValue['APADJ']>0 or hitValue['ADADJ']>0 or hitValue['Effect']>0) then
		self.lastREHPHurtTime = self.world:getGameTime()
	end

	--不死 self.attribute.buffAttribute.SENSE
	local NODEADHP = -1
	if self.attribute.buffAttribute==nil then
		self:E('release problem hurted ',self.itemID)
	end
	if self.attribute.buffAttribute.NODEAD>0 and hurt>self.attribute.HP then
		--debuglog("猫女 触发不死")
		if self.attribute.HP>0 then
			NODEADHP = self.attribute.HP-1
		end
	end


	if self.changePartHP~=0 and (self.attribute.HP-self.changePartHP)<hurt then
		local sHP = self.attribute.HP - self.changePartHP
		self:D('jaylog SActor:hurted changePartHP:',self.changePartHP,' hp:',self.attribute.HP,' hurt:',hurt,' sHP:',sHP,' itemID:',self.itemID)
		if self:adjHP(-sHP)==false then
			--hurt = 0
		end
	else
		if  NODEADHP<0 then
			self:adjHP(-hurt)
		else
			self:adjHP(-NODEADHP)
		end
	end

	--收集任务数据
	if hitValue['FIXREHP']>0 then
		if obj~=nil and obj.attribute.HP<obj.attribute.MaxHP then
			obj:setCounter("cure",hitValue['FIXREHP'])
		end
	end
 	if itemID~=self.itemID then
 		local realHurt = obj.attribute.ATK*(hitValue['APADJ']+hitValue['ADADJ'])*0.01*self.world.formula:getTenacity(obj.attribute.actorType,self.attribute.actorType,self.attribute.level)* (hitValue['SEPARATE']*0.01) * hitValue['CRIhurt']
		self:D("真实伤害 :",obj.attribute.ATK,(hitValue['APADJ']+hitValue['ADADJ']),self.world.formula:getTenacity(obj.attribute.actorType,self.attribute.actorType,self.attribute.level),(hitValue['SEPARATE']*0.01) * hitValue['CRIhurt'],obj.itemID,self.itemID,mode)
		if hitValue['Effect']==1 then
			realHurt = realHurt * 2
		end
		if realHurt<0 then
			-- if obj~=nil and obj.attribute.HP<obj.attribute.MaxHP then
			-- 	obj:setCounter("cure",-hurt)
			-- end
		else
			self:setCounter("hurted",realHurt)
			if self.world.startCalDPSTime>0 then
				self:setCounter("hurtedBoss",realHurt)
			end
			if obj~=nil then
				obj:setCounter("hurt",realHurt)
				if obj.parent~=nil then
					obj.parent:setCounter("hurt",realHurt)
				end
				if self.world.startCalDPSTime>0 then
					obj:setCounter("hurtBoss",realHurt)
				end
			end
		end
	else
		-- if hurt<0 then
		-- 	if self.attribute.HP<self.attribute.MaxHP then
		-- 		self:setCounter("cure",-hurt)
		-- 	end
		-- end
	end

	--共享生命	
	if self.sharedID>0  then
		local obj = self.world.allItemList[self.sharedID]
		--FIXHURT
		if obj~=nil and not obj:isDead() then
			if obj.changePartHP~=0 and (obj.attribute.HP-obj.changePartHP)<hurt then
				local sHP = obj.attribute.HP - obj.changePartHP
				obj:adjHP(-sHP)
			else
				obj:adjHP(-hurt)
			end
			if hurt~=0 then
				if obj.parent~=nil then
					itemID = obj.parent.itemID
				end
				obj:updateSyncMsg({h={{i=obj.itemID,t=0,d=adjTime,h=self.world.mFloor(hurt),hp=self.world.mFloor(obj.attribute.HP),hpe=0,ti=itemID,m=1,s=0}}})
			end
		end
		
	end



	if hitValue['Effect']~=nil then
		if ((hitValue['Effect']==2) and hurt~=0) or ((hitValue['Effect']==1) and hurt==0) then
			specialEffect = 0
		else
			specialEffect = hitValue['Effect']
		end
	end

	if mode==1 and hitValue['mode1step']~=nil and self.world.tonumber(hitValue['mode1step'])>0 then
		local abclist = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"}
		local step = hitValue['mode1step'] 
	 	debuglog("stepxx:"..step)
		if self.mode1type>0 then
			step=string.upper(abclist[self.world.tonumber(step)])
		else
			step=abclist[self.world.tonumber(step)]
		end
		hitValue['step'] = step
		debuglog("step:"..step)
		-- if hitValue['attackP']~=nil and step~=nil then
		-- 	hitValue['attackP'] = step..","..hitValue['attackP']
		-- 	debuglog("attackP:"..hitValue['attackP'])
		-- end
	end

	--hurt=1
	if self.attribute.HP<1 and self.status~=9 then
		self.status = 9
		if hurt~=0 then
			hurt = self.world.mFloor(hurt + 1)
		end
		local targetObj = self.world.allItemList[itemID]
		local itemID2 = itemID
		fromID = itemID
		if targetObj.parent~=nil then
			fromID = targetObj.parent.itemID
		end

		local bonusInt = {}
		self:goToDead(itemID2,mode,adjTime,bonus)
		--共享生命	
		if self.sharedID>0 then
			local obj = self.world.allItemList[self.sharedID]
			if obj.attribute.HP<1 then
				obj.status = 9
				obj:goToDead(itemID2,mode,adjTime,bonus)
			end
		end
		if hitValue['changeMode']~=nil then
			mode = hitValue['changeMode']
		end
		--h.p2 父类的itemID或者本身 p3传魔灵ID
		self:updateSyncMsg({h={{i=self.itemID,t=0,d=adjTime,h=self.world.mFloor(hurt),hp=self.world.mFloor(self.attribute.HP),hpe=0,ti=itemID2,m=mode,g=10,e=11,s=specialEffect,b=nil,p1=self.world.tonumber(hitValue['attackZXP']),p=hitValue['step'],p2=fromID,p3=self.world.tonumber(hitValue['DATKP'])}}})
	elseif self.attribute.HP>=1 then
		local buff
		if hitValue['BUFFTIME']~=nil and hitValue['BUFFTIME']>0 then
			-- buff = require("gameroomcore.SBuff").new(self.world,self:__skillID2buffID(hitValue['skillID']),hitValue,hitValue['BUFFTIME'],{},bulletID,itemID,self.itemID,adjTime)
			buff = self.world:createBuff(self:__skillID2buffID(hitValue['skillID']),hitValue,hitValue['BUFFTIME'],{},bulletID,itemID,self.itemID,adjTime)
			self:addBuff(buff)
		end
		local targetObj = self.world.allItemList[itemID]
		local itemID2 = itemID
		fromID = itemID
		if targetObj.parent~=nil then
			fromID = targetObj.parent.itemID
		end
		self:D("伤害异常:",self.itemID,self.world.mFloor(hurt))
		if ((hurt~=0) or (specialEffect>0 and specialEffect<99)) then
			if hitValue['changeMode']~=nil then
				mode = hitValue['changeMode']
			end
			--掉钱跟enemy
			--h.p2 父类的itemID或者本身
			self:updateSyncMsg({h={{i=self.itemID,t=0,d=adjTime,h=self.world.mFloor(hurt),hp=self.world.mFloor(self.attribute.HP),hpe=0,ti=itemID2,g=nil,e=nil,m=mode,s=specialEffect,p1=self.world.tonumber(hitValue['attackZXP']),p=hitValue['step'],p2=fromID,p3=self.world.tonumber(hitValue['DATKP'])}}})
		end
	end


	local targetObj = self.world.allItemList[itemID]
	--分身计counter
	if targetObj.parent~=nil and targetObj.parent.attribute~=nil then
		targetObj = targetObj.parent
	end
	--task setcounter
	if notDead and self:isDead() and targetObj.attribute.actorType==0 then
		if self.attribute.actorType==0 then
			targetObj.counterObj:setCounter("hero_"..self.attribute.roleId)
		end
		if self.attribute.actorType==1 then
			targetObj.counterObj:setCounter("enemy_"..self.attribute.roleId)
		end
		if self.attribute.actorType==2 then
			targetObj.counterObj:setCounter("boss_"..self.attribute.roleId)
		end
	end


	--运行猫女的铁卫
	if hitValue['ADADJ']>0 and not self:isDead() then
		if self.attribute.energyBoard~=nil then
			self.attribute.energyBoard:run("IRON",{})
		end
	end

	return hurt
end

--- 唤醒英雄
-- @param null
-- @return null
function SActor:sleepOff()


	if self.statusList[22]~=nil and self.statusList[4001]==nil then	-- or self.attribute.actorType==0 then
		self:D("唤醒睡眠.........................1 itemID:",self.itemID)
		self:removeBUff('SLEEP')
	end
end

--- 清除指定buff
-- @param name str - 需要清除buff的
function SActor:removeBUff(name,isRemove)
	if isRemove==nil then isRemove = false end

	local status = self.world.gameRoomSetting.sendToClientStatusList
	local tmpStatusNum = status[name]
	-- if self.statusList[tmpStatusNum]~=nil then
	-- 	self.world:debuglog('jaylog removeBUff: tsn',tmpStatusNum,'r',self.statusList[tmpStatusNum]['r'],'gt',self.world.gameTime,' st:',self.world.cjson.encode(self.statusList[tmpStatusNum]))
	-- end
	-- if self.statusList[tmpStatusNum]==nil or (self.statusList[tmpStatusNum]~=nil and self.statusList[tmpStatusNum]['r']<self.world.gameTime) then

	if (self.statusList[tmpStatusNum]~=nil and self.statusList[tmpStatusNum]['r']<self.world.gameTime) or isRemove then
		--self:D("removeBUff1:",name)
	--if (self.statusList[tmpStatusNum]~=nil and self.statusList[tmpStatusNum]['r']<self.world.gameTime) then
		--debuglog("removeBUff name:"..name.." gameTime:"..self.world.gameTime)
		for k,v in pairs(self.buffList) do
			if v.buffAttribute.func:getVar(name)~=0 then
				v.buffAttribute.func:setVar(name,0)
				local isDirty=v.buffAttribute.func:checkDirty()
				if not isDirty then
					v.isRemove=1
				end
			end
		end
		self:reCalBuff()
		--self.world:debuglog('jaylog removeBUff st:',self.world.cjson.encode(self.statusList[tmpStatusNum]))
	end
end

---清除指定buff 根据buffID清
-- @param buffID str - 需要清除buff的ID
function SActor:removeBuffToID(buffID)
	--self:D('jaylog SActor:removeBuffToID buffID',buffID)
	if self.buffList[buffID]~=nil then
		self:D('jaylog SActor:removeBuffToID nil',buffID)
		self.buffList[buffID].isRemove = 1
	end
	self:reCalBuff()
end

---创建一个空的hitValue用于buff和子弹初始化
-- @param null
-- @return null
function SActor:createhitValue()
	local hitValue = {
		mode = 0,
		skillID = 0,
		EXCEPATKDIS = 0,
		APADJ = 0,
		ADADJ = 0,
		CDTIME = 0,
		BLEED_RATE = 0,
		BLEED_HURT = 0,
		REMP = 0,
		DEF_DOWN = 0,
		DEF_UP = 0,
		BUFFTIME = 0,
		ATKDIS_UP = 0,
		ATKDIS_DOWN = 0,
		MANA_DOWN = 0,
		MANA_UP = 0,
		DIZZY_RATE = 0,
		DIZZYNOEFFECT_RATE = 0,
		REHP = 0,
		ATK_UP = 0,
		ATK_DOWN = 0,
		LOSSHP = 0,
		DIZZY = 0,
		MSPD_DOWN = 0,
		MSPD_UP = 0,
		OUTCTL = 0,
		HP_UP = 0,
		HP_DOWN = 0,
		MDEF_UP = 0,
		MDEF_DOWN = 0,
		APADJ2 = 0,
		ADADJ2 = 0,
		REBOUNDADHURT = 0,
		FROZEN = 0,
		APS = 0,
		ADS = 0,
		APS2 = 0,
		ADS2 = 0,
		BACKWARD = 0,
		REBOUNDRATE = 0,
		HURTAD = 0,
		HURTAP = 0,
		INTERVALTIME = 0,
		CRI_UP = 0,
		CRI_DOWN = 0,
		PARALYSIS = 0,
		DEAD = 0,
		HURTAD_RATE = 0,
		HURTAP_RATE = 0,
		MDEF_RATE = 0,
		DEF_RATE = 0,

		DIZZY_RATE= 0,
		VAMPIREAD_RATE= 0,
		VAMPIREAD= 0,
		BLEED_HURTFIX_RATE= 0,
		BLEED_HURTFIX= 0,

		SILIENCE_RATE = 0,
		SHIELD_RATE = 0,
		SHIELD = 0,
		SENSE_RATE = 0,
		DATKP = 0,
		SHIELD_UPFIX_RATE = 0,
		ATK = 0,
		MDEF = 0,
		DEF = 0,
		HIT = 0,
		DODGE = 0,
		CRI = 0,
		ASPD = 0,
		MSPD = 0,

		FIRER = 0,
		ICER = 0,
		LIGHTR = 0,
		POISONR = 0,
		Effect = 0,
		--新加的 用来改变普通攻击的暴击伤害
		CRIhurt = 1,
		--多段伤害比例
		SEPARATE = 100,
		--FIXHURT
		FIXHURT = 0,
		--FIXREHP
		FIXREHP = 0,
		--random系数
		ADJTIME = 0, 
		-- attRng = 0,
		-- visRng = 0,
		--是不是pvp
		ISPVP=0,
		--斩杀对象受伤倍数
		BEHEADEDHURT = 0,
	}

	return hitValue
end


--- 準備攻擊參數
-- @param mode int - 技能1-7
-- @param adjTime float - 調整時間
-- @param buff bool - 是否buff
-- @return hitValue table - 攻擊參數
function SActor:prepareHit(mode,adjTime,buff)
	if buff==nil then buff = false end
	--self:D(string.gsub(debug.traceback("", 2), "\n", " "))
	self:D("prepareHit itemID",self.itemID," mode",mode,self.AImode)
	-- self:D("prepareHit mode",mode)
	local hitValue = self:createhitValue()
	if mode>100 then
		mode = mode - 100
	end

	--add 基础属性
	for k,v in pairs(self.attribute) do
		if hitValue[k]~=nil and hitValue[k]~="table" then
			hitValue[k] = self.attribute[k]
		end
	end
	--random系数
	hitValue['ADJTIME'] = adjTime*1000
	--add sKill 属性 普通攻击要特殊处理
	hitValue['skillID'] = self.attribute.skills[mode].skillID
	hitValue['mode'] = mode
	self:D("prepareHit prepareHit:",self.world.cjson.encode(self.attribute.skills[mode].parameters))
	for k,v in pairs(self.attribute.skills[mode].parameters) do
		if hitValue[k]==nil then
			hitValue[k] = v
		else
			hitValue[k] = hitValue[k] + v
		end
	end
	--self:D("prepareHit hitValue:",self.world.cjson.encode(hitValue))
	self:D("prepareHit 释放itemID:",self.itemID," roleId:",self.attribute.roleId," mode:",mode," hitValue:",self.world.cjson.encode(hitValue))
	for k,v in pairs(self.statusList) do
		self:D("cs--skill1 自身statusList id:"..k.." v:"..self.world.cjson.encode(v))
	end

	--判断是不是pvp
	hitValue['ISPVP']=self.world.gameRoomSetting.ISPVP
	
	
	--清除自身status
	if hitValue['CLEANSELFSTATUS']~=nil and self.statusList[hitValue['CLEANSELFSTATUS']]~=nil then
		self:D( " CLEANSELFSTATUS : ",hitValue['CLEANSELFSTATUS'])
		--self.statusList[self.world.tonumber(hitValue['CLEANSELFSTATUS'])]=nil
		--self:removeStatusList(self.world.tonumber(hitValue['CLEANSELFSTATUS']))
		self:removeStatusListNoNext(self.world.tonumber(hitValue['CLEANSELFSTATUS']))
	end

	for i=1,3 do
		if hitValue['CLEANSELFSTATUS'..i]~=nil and self.statusList[hitValue['CLEANSELFSTATUS'..i]]~=nil then
			self:D( " CLEANSELFSTATUS : ",hitValue['CLEANSELFSTATUS'..i])
			--self.statusList[self.world.tonumber(hitValue['CLEANSELFSTATUS'..i])]=nil
			--self:removeStatusList(self.world.tonumber(hitValue['CLEANSELFSTATUS'..i]))
			self:removeStatusListNoNext(self.world.tonumber(hitValue['CLEANSELFSTATUS'..i]))
		end
	end
	--召唤物
	self:callCreature(hitValue,mode)
	--自动添加状态
	if hitValue['ADDSELFSTATUS']~=nil and hitValue['ADDSELFSTATUS']>0 then
		self:D("add SELFstatus 自动添加状态:",hitValue['ADDSELFSTATUS'])
		if hitValue["TRIGGERSELFSTATUS"]~=nil and hitValue["TRIGGERSELFSTATUS"] > 0 then	
			self:D("add SELFstatus 自动添加状态 2层:",hitValue['TRIGGERSELFSTATUS']," remove status list find nextStatus add time :",self.world.gameTime," mode:",mode)
			--self:D("remove status list find nextStatus add time :",self.world.gameTime," mode:",mode)
			self:addScheduleStatusList(0,{s=hitValue['ADDSELFSTATUS'],t=hitValue['ADDSELFSTATUSTIME']},{s=hitValue["TRIGGERSELFSTATUS"],t=hitValue['TRIGGERSELFSTATUSTIME']})	
		else
			self:D("add SELFstatus 自动添加状态1:",hitValue['ADDSELFSTATUS'])
			self:addStatusList({s=hitValue['ADDSELFSTATUS'],r=self.world.gameTime,t=hitValue['ADDSELFSTATUSTIME'],i=self.itemID},0)
		end
	end

	local alist = {"A","B","C","D","E","F"}
	for i=1,#alist do
		--自动添加状态 全自动加状态
		if hitValue['SADDSELFSTATUS'..alist[i]]~=nil and hitValue['SADDSELFSTATUS'..alist[i]]>0 then
			self:D("add SELFstatusA 自动添加状态:",hitValue['SADDSELFSTATUS'..alist[i]])

			if hitValue["STRIGGERSELFSTATUS"..alist[i]]~=nil and hitValue["STRIGGERSELFSTATUS"..alist[i]] > 0 then	
				self:D("add SELFstatusA 自动添加状态 2层:",hitValue['STRIGGERSELFSTATUS'..alist[i]])
				self:D("remove SELFstatusA list find nextStatus add time :",self.world.gameTime," mode:",mode)
				local s = {s=hitValue['SADDSELFSTATUS'..alist[i]],t=hitValue['SADDSELFSTATUSTIME'..alist[i]]}
				local s1 = {s=hitValue["STRIGGERSELFSTATUS"..alist[i]],t=hitValue['STRIGGERSELFSTATUSTIME'..alist[i]]}
				self:addScheduleStatusList(0,s,s1)	
			else
				self:D("add SELFstatusA 自动添加状态1:",hitValue['SADDSELFSTATUS'..alist[i]])
				local s = {s=hitValue['SADDSELFSTATUS'..alist[i]],r=self.world.gameTime,t=hitValue['SADDSELFSTATUSTIME'..alist[i]],i=self.itemID}
				if hitValue['CHANTSHOW']~=nil then
					s['p4'] = hitValue['CHANTSHOW']
				end
				if hitValue['ENDCLEANSTATUS']~=nil then
					s['p1'] = hitValue['ENDCLEANSTATUS']
				end
				if hitValue['ONETIME']~=nil then
					if self.statusList[s['s']]==nil then
						self:addStatusList(s,0)
					end
				else
					self:addStatusList(s,0)
				end
			end
		end	

	end

	--boss强制命中
	if self.attribute.actorType==2 and hitValue['INEVITABLEHIT']==nil and mode>1 then
		hitValue['INEVITABLEHIT']=1
	end

	-- if self.attribute.actorType==0 and mode==1 then
	-- 	hitValue['DIZZYNOEFFECT_RATE'] =100
	-- 	hitValue['BUFFTIME'] = 5
	-- end
	--传入普通攻击的攻击模式
	if mode==1 then
		hitValue['mode1step'] = self.mode1step
	end
	-- if  (self.world.gamePort=="2820") and  self.itemID == 1 then
		
	-- 	-- self.attribute.ATK =30000
	-- 	self.attribute.HP =30000000
	-- 	self.attribute.MaxHP =30000000
	-- 	self.attribute.baseTable.MaxHP=30000000
	-- 	self.attribute.DEF =3000000000
	-- 	self.attribute.MDEF =3000000000
	-- 	hitValue['ATK'] = 30000
	-- 	hitValue['REHP'] = 100
	-- 	hitValue['ATK'] = hitValue['ATK']*30
	-- end	
	--逗比安和逗比🐑的直线攻击暴炸
	if self.attribute.skills[mode].attackMode == 4 and  self.attribute.skills[mode].maxEnemy==1 then
		hitValue['attackZXP'] = "1"
	end

	return hitValue
end

--- 通过hitValue参数召唤小怪
-- @param hitValue table - 伤害基础参数
-- @param mode int - call些function的技能ID
-- @return null
function SActor:callCreature(hitValue,mode)
	if hitValue['ADDATTACK']~=nil then
		local skill = self.attribute.skills[mode]
		hitValue['MODE'] = mode
		hitValue['BULLETSPEED'] = skill.bulletSpeed
	end
	self.world:callCreature(hitValue,self)
end


--- 获得準備攻擊參數
-- @param null
-- @return hitValue table - 伤害基础参数
function SActor:getPrepareHithitValue()
	local hitValue = self:createhitValue()

	--add 基础属性
	for k,v in pairs(self.attribute) do
		if hitValue[k]~=nil and hitValue[k]~="table" then
			hitValue[k] = self.attribute[k]
		end
	end
	--random系数
	hitValue['ADJTIME'] = 0.25*1000

	return hitValue
end

--- 發動攻擊
-- @param itemID int - 受傷害方itemID
-- @param bulletID int - 子彈ID
-- @param mode int - 技能1-7
-- @param hitValue table - 計算參數
-- @param adjTime float - 調整時間
-- @return hurt float - 傷害值
function SActor:hitTarget(itemID,bulletID,mode,hitValue,adjTime)
	--安全区打不中人
	-- if self.statusList[73]~=nil then
	if  self.itemID~=itemID and self:safe() then
		return 0
	end

	local obj = self.world.allItemList[itemID]
	--新手保护
	local newbie 
	if self.parent~=nil and  self.parent.attribute~=nil and self.parent.attribute.actorType==0 then
		newbie = self:newbieProtection(self.parent.attribute.actorType,self.attribute.level,self.teamOrig,obj.attribute.actorType,obj.attribute.level,obj.teamOrig,obj.lastREHPattackTime) 
	else
		newbie = self:newbieProtection(self.attribute.actorType,self.attribute.level,self.teamOrig,obj.attribute.actorType,obj.attribute.level,obj.teamOrig,obj.lastREHPattackTime) 
	end
	

	if not newbie then
		self:D("攻击触发新手保护 攻击方:",self.attribute.actorType,self.attribute.level,self.teamOrig,"防御方:",obj.attribute.actorType,obj.attribute.level,obj.teamOrig,"地图:",self.world.gamePort)
		return 0
	end
	--self:D("hitTarget 受傷害方itemID",itemID)
	if obj==nil then
		self.world:D("子弹空了............",itemID,bulletID,mode,self.world.cjson.encode(hitValue))
	end
	obj:sleepOff()

	--播放击退动画
	if  self.parent==nil and obj.attribute.actorType==1 and  hitValue['STIFFRATE']~=nil and hitValue['STIFFRATE']>0 then
		local rand = math.random(1,100)	
		if hitValue['STIFFRATE']>rand then
			hitValue['Effect'] = 96
			local path = obj:moveTo(obj.posX,obj.posY) 	
			obj.syncMsg['m'] = nil
		end
	end
	
	-- self:D("MaxHP 修改前:",obj.attribute.MaxHP,itemID)
	local hurt = obj:hurted(self.itemID,bulletID,mode,hitValue,adjTime)
	--local hurt = 1
	--self:D("MaxHP 修改后:"..obj.attribute.MaxHP)

	--self:D("SActor:hitTarget	self.mode1order :"..self.mode1order )
	--普通攻击恢复生命值
	if mode==1 then
		-- debuglog("itemID:"..self.itemID.."普通攻击回魔回血 REMP:"..hitValue['REMP'].." oldMP:"..self.attribute.MP)
		-- debuglog("itemID:"..self.itemID.."普通攻击回魔回血 REHP:"..hitValue['REHP'].." oldHP:"..self.attribute.HP)
		if hitValue['REMP']>0 then
			self:adjMP(hitValue['REMP']/100*self.attribute:getMaxMP(),true,true)
			--self:D("itemID:"..self.itemID.."普通攻击回魔回血 REMP:"..hitValue['REMP'].." MP:"..self.attribute.MP)
		end
		if hitValue['REHP']>0 then
			self:adjHP(hitValue['REHP']/100*self.attribute:getMaxHP(),true,true)
			--self:D("itemID:"..self.itemID.."普通攻击回魔回血 REHP:"..hitValue['REHP'].." HP:"..self.attribute.HP)
		end
	end


	if hitValue['VAMPIREAD']~=nil and hitValue['VAMPIREAD']>0 then

		local hitValueNew = {}
		--hitValueNew['FIXHURT']  = -hurt * hitValue['VAMPIREAD'] * 0.01
		hitValueNew['FIXHURT']  = -hurt * hitValue['VAMPIREAD'] * 0.01
		hitValueNew['ISVAMPIREAD'] = 1
		self:directHurt(self.itemID,mode,hitValueNew,0) 
		self:D("吸血 回血...........",hitValueNew['FIXHURT'])
	end
	--and (self.lastAttackID~=itemID or self.lastAttackTime+3<self.world.gameTime)
	if hurt>0 and self.itemID~=itemID and self.teamOrig~=obj.teamOrig  then
		self.lastAttackID = itemID
		self.lastAttackTime = self.world:getGameTime()
	end

	--判断是不是要清CD 
	if  hitValue['CLEARSKILLCDRATE']~=nil and hitValue['CLEARSKILLCDTIME']~=nil and (self.clearSkillCDList[""..mode]==nil or self.world.gameTime>self.clearSkillCDList[""..mode]) then
		local rand = math.random(1,100)	
		self:D("清除CD ",rand,hitValue['CLEARSKILLCDRATE'],mode)
		if hitValue['CLEARSKILLCDRATE']>rand then
			self.clearSkillCDList[""..mode] = self.world.gameTime + hitValue['CLEARSKILLCDTIME']
			--清cd
			self.attribute.skills[mode].lastCoolDownTime = self.world:getGameTime() 
			self:syncSkill(0)

		end
	end

	--清除自身status
	-- if hitValue['ENDCLEANSELFSTATUS']~=nil and self.statusList[hitValue['ENDCLEANSELFSTATUS']]~=nil then
	-- 	self:D( " ENDCLEANSELFSTATUS : ",hitValue['ENDCLEANSELFSTATUS'])
	-- 	--self.statusList[self.world.tonumber(hitValue['CLEANSELFSTATUS'])]=nil
	-- 	self:removeStatusList(self.world.tonumber(hitValue['ENDCLEANSELFSTATUS']))
	-- end

	-- for i=1,3 do
	-- 	if hitValue['ENDCLEANSELFSTATUS'..i]~=nil and self.statusList[hitValue['ENDCLEANSELFSTATUS'..i]]~=nil then
	-- 		self:D( " ENDCLEANSELFSTATUS : ",hitValue['ENDCLEANSELFSTATUS'..i])
	-- 		--self.statusList[self.world.tonumber(hitValue['CLEANSELFSTATUS'..i])]=nil
	-- 		self:removeStatusList(self.world.tonumber(hitValue['ENDCLEANSELFSTATUS'..i]))
	-- 	end
	-- end

	if hurt~=0 then
		--进入战斗状态
		self.lastREHPattackTime = self.world:getGameTime()
	end

	return hurt
end

--- buff 完結 callback
-- @param buffID int - buff ID
-- @param itemID int - 受傷害方itemID
-- @return null
function SActor:buffCallBack(skill,itemID)

end

--- 取得某遊戲統計
-- @param name string - 名稱
-- @return counter int - 數值
function SActor:getCounter(name)
	if self.counter[name]==nil then
		return 0
	end
	return self.counter[name]
end

--- 累加某遊戲統計 只用于抢旗
-- @param name string - 名稱
-- @param addValue int - 加值 預設+1
-- @return counter int - 數值
function SActor:setCounter(name,addValue)
	if addValue==nil then addValue = 1 end
	if self.counter[name]==nil then self.counter[name] = 0 end
	--self:debuglog('jaylog SActor:setCounter name:'..name..' addValue:'..addValue..' itemID:'..self.itemID)
	self.counter[name] = self.counter[name] + addValue
end


function SActor:getAttRange() 
	return {posX=self.posX,posY=self.posY,radius=self.attribute.ATTRNG/self.world.setting.AdjustAttRange}
end

function SActor:getVisRange() 
	return {posX=self.posX,posY=self.posY,radius=self.attribute.VISRNG/self.world.setting.AdjustVisRange}
end

function SActor:getCircle() 
	return {posX=self.posX,posY=self.posY,radius=self.attribute.width}
end

--- 加buff
-- @param buff SBuff - buff object
-- @return null
function SActor:addBuff(buff)
	-- if (self.anitDeBuffTime>self.world:getGameTime() or self.invincibleTime>self.world:getGameTime())
	-- 	and buff.buffID<10000 and (buff.fromID==0 or 
	-- 	(self.world.allItemList[buff.fromID]~=nil and self.world.allItemList[buff.toID]~=nil
	-- 		and self.world.allItemList[buff.fromID].team~=self.world.allItemList[buff.toID].team)) then
	-- 	buff:release()
	-- 	return nil
	-- end
	if not buff.buffAttribute.func:isDirty() then
-- debuglog('=============== addBuff fail ... not dirty '..buff.buffID)
		buff:release()
		return nil
	end
	if self.buffList[buff.buffID]~=nil and self.buffList[buff.buffID].startTime+self.buffList[buff.buffID].duration>buff.startTime+buff.duration and self.buffList[buff.buffID].isRemove==0 then
-- debuglog('=============== addBuff duplicate '..buff.buffID)
		buff:release()
		return nil
	end
	local HPBuffList = buff.buffAttribute.func:getHPBuff()
	for k,v in pairs(self.buffList) do
		if v.fromID==buff.fromID and v.skillID==buff.skillID then
			v:removeHPBuff(HPBuffList)
		end
	end
	if self.buffList[buff.buffID]~=nil then
		self.buffList[buff.buffID]:release()
	end
	self.buffList[buff.buffID] = buff
	local statusNum = self:__buffID2StatusNum(buff.buffID,buff.buffParameter['statusnum'])
	if statusNum>0 then
		local adjTime = buff.startTime - self.world.gameTime
		local status = {s=statusNum,r=buff.startTime,t=buff.duration,i=self.itemID}
		if buff.buffParameter['statusparameter']~=nil then
			for k,v in pairs(buff.buffParameter['statusparameter']) do
				status[k] = v
			end
		end
		self:addStatusList(status,adjTime)
	end
-- debuglog('=============== addBuff ok '..buff.buffID)
	self:reCalBuff()
end
--ATKMOVEDIS_S1=80;ATKMOVEDIS_S2=80;ATKMOVEDIS_S3=160;ATKMOVEDIS_S4=80;ATKMOVEDIS_S5=0;ATKMOVEDIS_S6=0;CDTIME1=0.5;CDTIME2=0.5;CDTIME3=0.76;CDTIME4=0.46;CDTIME5=0.53;CDTIME6=0.76;PREATKRANGE=800;PREATKFLYTIME1=0.2;PREATKFLYTIME2=0.2;PREATKMODE1=5;PREATKMODE2=6;PREATKNUM=2;PREATKTOTARGETDIS=200;PREATKCAROM5=0;PREATKCAROM6=0;PREATKCAROMINTERVAL1=0.4;PREATKCAROMINTERVAL2=0.46
---skill1 1号技能处理正在出第几招和CD 数值由前端传过来
-- @param order int - 第几招
-- @param isMove bool - 是否需要移动
-- @param actionNum int - 动作ID
-- @return interval,step,cdtime int - 间隔,第几招,cd
function SActor:skillAttackMode1(order,isMove,actionNum)
	--debuglog("mode1 skillAttackMode1")
	-- if self.attribute.roleId==1 then
	-- 	debuglog("mode1 skillAttackMode1")
	-- end
	if order~=nil then
		self:D("mode1  前端控制的.. order:",order," isMove:",(isMove and "true" or "false"))
		self.mode1order = order
	end

		local interval = 0.5
		local step = "1"
		local cdtime = 0.5
		--debuglog("self.attribute.actorType : "..self.attribute.actorType)
	if  self.attribute.actorType==0 then 
		--重置普通攻击
		if self.mode1atktime+0.5<=self.world:getGameTime() and order==nil then
			self.mode1order = 0
		end

		local caromlist = self.attribute.skills[1].carom
		if caromlist[self.mode1order]==nil and order==nil then
			--阶段上限
			self.mode1order = 0
		end

		--切换阶段 阶段+1
		if order==nil then
			if  caromlist[self.mode1order+1]~=nil then
				self.mode1order = self.mode1order + 1
				--debuglog("阶段加一。。。。。。。。。。。"..self.mode1order)
			else	
				self.mode1order = 1
			end
		end



		local skill = self.attribute.skills[1] 
		local parameters = skill.parameters 

		if self.mode1order>0 then
			local caromlist = skill.carom
			local caromCrilist = string.split(caromlist[self.mode1order],",")
			--获得间隔时间
			local caromitvlist = skill.carom_interval
			local caromitvtimelist = string.splitNumber(caromitvlist[self.mode1order],",")

			local caromstlist = skill.carom_step
			local caromsteplist = string.splitNumber(caromstlist[self.mode1order],",")

			step = self.world.tostring(caromsteplist[1])
			cdtime = parameters['CDTIME'..step]
			if 	self.AImode==1 and  not self.autoBlocked then
				--ai状态下用来代替cdtime
				self.AIlastATKTime = self.world:getGameTime() + parameters['MOVECDTIME'..step] - 0.1
				self.islastATK = true
			end
			interval = caromitvtimelist[1]
		else
			step = actionNum
			cdtime = parameters['CDTIME'..step]
			if 	self.AImode==1 and  not self.autoBlocked then
				--ai状态下用来代替cdtime
				self.AIlastATKTime = self.world:getGameTime() + parameters['MOVECDTIME'..step] - 0.1
				self.islastATK = true
			end
			interval = 0
		end
		--记录正在使用哪招
		self.mode1step = step
	
		local moveAttk = true
		self.mode1type = 0
		if self.statusList[43]~=nil then
			moveAttk = false
		elseif self.lastBulletTarget~=nil and self.world.allItemList[self.lastBulletTarget]~=nil and self.lastBulletTarget~=self.itemID then
			local obj=self.world.allItemList[self.lastBulletTarget]
			local d =self.world.mPow(self.world.mPow(self.posX-obj.posX,2) + self.world.mPow(self.posY-obj.posY,2),0.5)
			--debuglog("可以移动攻击.............d:"..d.." width:"..obj.attribute.width.." lastBulletTarget:"..self.lastBulletTarget)
			if d<=obj.attribute.width+skill.atkDis then
				moveAttk = false
			end
		end
		--攻击前移
		if (parameters['ATKMOVEDIS_S'..step]~=nil and moveAttk and isMove==nil) or (isMove~=nil and isMove) then
			local toX,toY = self.world.map:getXYLength(self.posX,self.posY,self.lastBulletPositionX,self.lastBulletPositionY,parameters['ATKMOVEDIS_S'..step]/self.world.setting.AdjustAttRange)
			local ret

			ret,toX,toY=self.world.map:findPointStraightLineNearest(self.posX,self.posY,self.posX+toX,self.posY+toY) 

			self:setPosition(toX,toY)
			self:moveTo(toX,toY)
			self.syncMsg['m'] = nil
			self.mode1type = 5
		end

		self.mode1atktime = self.world:getGameTime()+cdtime
	end

	--转化成字母
	--debuglog("step:"..step)
	local abclist = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"}
	if self.mode1type>0 then
		step=string.upper(abclist[tonumber(step)])
	else
		step=abclist[tonumber(step)]
	end
--	print("SHero:_autoFight skillAttackMode1 interval:"..interval.." step:"..step.." cdtime:"..cdtime)
	return interval,step,cdtime
end

--设置共享生命id 
--- 设置共享生命id
-- @param id int - 共享生命的id
-- @param hppro int - 共享比例
-- @return null
function SActor:setShared(id,hppro)
	if hppro==nil then hppro=1 end
	self.sharedID = id
	self.sharedproHP = hppro
end


function SActor:checkMana(mode)


	-- return true
	local skill = self.attribute.skills[mode]
	--debuglog(" skill.mana:"..skill.mana.." attribute.MP:"..self.attribute.MP)
	if skill.mana<=0 or self.attribute.MP>=skill.mana then
		return true
	else
		return false
	end
end

function SActor:useMana(mode)
	local skill = self.attribute.skills[mode]
	if skill~=nil and skill.demonObj~=nil then
		self:adjMP(-skill.mana,false,true)
		self:D("魔灵扣篮 :",mode,skill.mana,self.attribute.MP)
	end
end

function SActor:useCDTime(skill)

end

--- 准备攻击前置设置，在prepareHit之前执行
-- @param mode int - 技能1-7
-- @param target obj - 目标对象
-- @param x int - x坐标
-- @param y int - y坐标
-- @param adjtime float - 设置时间
-- @param syncMsg table - call back synMsg
function SActor:prepareSkillAttackCustom(mode,target,x,y,adjtime,syncMsg)
	--debuglog("prepareSkillAttackCustom prepareSkillAttackCustom")
end

--- 智能判断释放技能，由电脑操控
-- @param mode int - 技能1-7
-- @param itemID int - 目标itemID
-- @param x int - 施放技能目的地x坐标
-- @param y int - 施放技能目的地y坐标
function SActor:skillAttackAI(mode,itemID,x,y)
	if itemID ==nil then
		itemID = 0
	end
	if x ==nil then
		x = 0
	end
	if y ==nil then
		y =0
	end
	local skill=self.attribute.skills[mode]
	local lock=true
	local xy=false
	local visRange=self:getVisRange()
	local notIncludeSelf=false
	local isSelfTeam=false
	local notIncludeSelfSoldier=false
	local includeTower=false
	local enemy=nil
	local sortKey={}
	local sortItemID={}
	local minD=999999
	local attackDistance = 0
	local visDistance = 0
	local d=0
	local towers = nil
	local continue=true
	visRange['radius']=visRange['radius']+8
	if ((skill.attackMode==2 or skill.attackMode==8 or skill.attackMode==9)) then
		if (itemID==0) then
			lock=false
		elseif (  self.world.allItemList[itemID] == nil ) then
			lock=false
		elseif (skill.targetType~=6 and skill.targetType~=7) and (self.world.allItemList[itemID].className=="SSTower") then
			lock=false
		elseif ( skill.targetType==0 and self.world.allItemList[itemID].attribute.actorType~=0) then
			lock=false
		elseif ( skill.targetType==1 and self.world.allItemList[itemID].team==self.team) then
			lock=false
		elseif ( skill.targetType==2 and (self.world.allItemList[itemID].attribute.actorType~=0 or self.world.allItemList[itemID].team==self.team) ) then
			lock=false
		elseif ( skill.targetType==4 and (self.world.allItemList[itemID].attribute.actorType~=0 or self.world.allItemList[itemID].team~=self.team) ) then
			lock=false
		elseif (skill.targetType==5 and self.world.allItemList[itemID].team~=self.team) then
			lock=false
		elseif (skill.targetType==6 and self.world.allItemList[itemID].team==self.team) then
			lock=false
		elseif (skill.targetType==7 and (self.world.allItemList[itemID].team==self.team or self.world.allItemList[itemID].className ~="SSTower")) then
			lock=false
		elseif (skill.targetType==8 and itemID==self.itemID) then
			lock=false
		elseif (skill.targetType==9 and (itemID==self.itemID or (self.world.allItemList[itemID].team==self.team and self.world.allItemList[itemID].className=="SSoldier"))) then
			lock=false
		elseif ( self.world.allItemList[itemID].className =="SSTower") and ( self.world.allItemList[itemID].isVisible==2) then
			lock=false
		end
	elseif (skill.attackMode~=7) then
		if (x==0 and y==0 and itemID==0) then
			lock=false
			xy=true
		else
			if ( itemID>0 and self.world.allItemList[itemID]~=nil and self.world.allItemList[itemID].className =="SSTower" and self.world.allItemList[itemID].isVisible==2 
				and self.world.allItemList[itemID]:colliding(visRange,0,0,self.itemID)<0) then
				lock=false
				xy=true
			end
		end
	end
	if (not lock) then
		if ( xy and ( not empty(self.paths) ) ) then
			x=self.paths[1].posX
			y=self.paths[1].posY
		else
			itemID=0
			notIncludeSelf=false
			isSelfTeam=false
			notIncludeSelfSoldier=false
			includeTower=false
			local options = {notIncludeSelf=false,isSelfTeam=false,notIncludeSelfSoldier=false,includeTower=false}
			enemy=self.world:getTarget(skill.targetType,self.team,self.itemID,options)
			notIncludeSelf = options['notIncludeSelf']
			isSelfTeam = options['isSelfTeam']
			notIncludeSelfSoldier = options['notIncludeSelfSoldier']
			includeTower = options['includeTower']
			sortKey={}
			sortItemID={}
			minD=999999
			attackDistance = skill.useDis/self.world.setting.AdjustVisRange
			visDistance = ( self.attribute.VISRNG/self.world.setting.AdjustVisRange ) *  2
			for kk,value in pairs(enemy) do
				continue=true
				if notIncludeSelf and (value.itemID==self.itemID) then
					continue=false
				end
				if ( isSelfTeam and value.team~=self.team) then
					continue=false
				end
				if ( value.className =="SSTower") then
					continue=false
				end
				if ( value.className=="SEye") then
					continue=false
				end
				if (value:isDead()) then
					continue=false
				end
				if ( value.team~=self.team and value.isVisible==2 and (  (self.statusList[576] == nil ) or ( value.isGrass==1 and self.isGrass==0) ) and (self.visibleList[self.attackTarget] == nil )  ) then
					continue=false
				end

				if ( notIncludeSelfSoldier and value.team==self.team and value.attribute.actorType==1) then
					continue=false
				end
				if ( value.attribute.actorType~=0 and (self.world.mAbs(value.posX-self.posX)>minD or self.world.mAbs(value.posY-self.posY)>minD) ) then
					continue=false
				end
				d = value:distance(self.posX,self.posY,self.itemID)
				if( d>=0 and d> visDistance ) then
					continue=false
				end
				if (continue and d>=0) then
					if (d<minD) then
						minD=d
					end
					if (value.attribute.actorType~=0 or d>attackDistance) then
						d=d+1000
					end
					sortKey[#sortKey +1]=d
					sortItemID[#sortItemID +1]=value.itemID
				end
			end
			if ( not empty(sortItemID) ) then
			-- array_multisort(sortKey,sortItemID)
			self.world.tSort( sortKey ,function(a,b) return a<b end )
			self.world.tSort( sortItemID ,function(a,b) return a<b end)
			itemID=sortItemID[1]

			x=self.world.allItemList[itemID].posX
			y=self.world.allItemList[itemID].posY

			else
			
			end
		end --if ( xy and ( not empty(self.paths) ) ) then
	end -- if (not lock) then

	--debuglog("SAI skillAttackAI...itemID:"..itemID.." x:"..x.." y:"..y)
	return itemID,x,y

end --  SBoss:skillAttackAI
-- end

--- 失控攻击流程
-- @param null
-- @return null
function SActor:outOfCtlFight()
	
	if self.outOfCtlTime<self.world:getGameTime() then return false end
	if self.world.allItemList[self.attackTarget]==nil or self.world.allItemList[self.attackTarget]:isDead() then
		self.attackTarget = nil
		self:moveTo(self.posX,self.posY)
		if self.status~=9 then
			self.status = 0
		end
	end
	
	if self.attackTarget~=nil then
	
		--- check can fight or not
		local distance = self:__canFight()
		if distance~=nil and type(distance) == "number" and distance>=0 then
		
			--- stop move ...
			if not self.world.map:equalPoint(self.targetPosition,self.posX,self.posY) or self.paths~=nil then
				self:moveTo(self.posX,self.posY)
				--- client side guy says don't send stop action and attack action together
				self.syncMsg['m'] = nil
			end
			self:D("失控攻击:",self.itemID)
			returnObj = self:skillAttack(1,self.attackTarget,0,0,true)
			if self.syncMsg['m']~=nil then
				self.syncMsg['m']['zz'] = nil
			end
			if self.syncMsg['a']~=nil then
				self.syncMsg['a'][#self.syncMsg['a']]['zz'] = nil
			end
		end
	end
end

--- 检查是否可攻击，不可攻击则移动到目标位置
-- @param null
-- @return d int - 碰撞距离
function SActor:__canFight()

	local skill = self.attribute.skills[1]
	local attRange = {posX=self.posX,posY=self.posY,radius=skill.atkDis/self.world.setting.AdjustVisRange}
	local d = self.world.allItemList[self.attackTarget]:colliding(attRange,0,0,self.itemID)
	if d>=0 then
		if self.lastCoolDownTime<=self.world:getGameTime() then
			return  self.world.tonumber(d) 
		end
	elseif self.lastCoolDownTime<=self.world:getGameTime() then
		--- follow attack target position (next) ...
		local targetObj=self.world.allItemList[self.attackTarget]
		if targetObj~=nil then
			local pos = {x=targetObj.nextPosition.x,y=targetObj.nextPosition.y}
			if pos~=nil and not self.world.map:equalPoint(pos,self.targetPosition.x,self.targetPosition.y) then
				local pos = {x=targetObj.nextPosition.x,y=targetObj.nextPosition.y}
				return self:moveTo(pos.x,pos.y)
			end
		end
	end
	return nil
end



--- 第7招上馬和下馬
-- @param updateMove boolean - 强制移动重算
-- @return returnObj obj - 移动信息
function SActor:prepareSkillAttackMode7(updateMove)
	if self.world.gameRoomSetting['ISYW']==0 then
		return nil
	end
	local skill = self.attribute.skills[7] 

	-- for k,v in pairs(skill) do
	-- 	debuglog("k :"..k.." v :"..self.world.cjson.encode(v))
	-- end
	-- if self.statusList[602]~=nil and ((self.world.mapModel==506 and self.attribute.school==1) or (self.world.mapModel==106 and self.attribute.school==2)) then
	if self.statusList[602]~=nil then
		return nil
	end
	if (self.attribute.actorType==0 and self.statusList[50]==nil and self.prepareSkillAttackNum==0 and self.attribute.HORSEID>0) or (self.attribute.actorType==0 and self.statusList[50]==nil and self.statusList[603]~=nil) then
		if (self.lastSPFightTime+skill.parameters.CDTIME<self.world:getGameTime() and self.lastSPFightTime+skill.parameters.CDTIME<self.world:getGameTime()
		and self.lastCoolDownTime+skill.parameters.CDTIME<self.world:getGameTime()) or 
		(self.lastStartMoveTime>0 and self.lastStartMoveTime+skill.parameters.CDTIME2<self.world:getGameTime() and self.lastCoolDownTime+skill.parameters.CDTIME2<self.world:getGameTime()) or 
		(self.attribute.actorType==0 and self.statusList[50]==nil and self.horseNow) or
		(self.statusList[603]~=nil) 
		-- 	and (self.lastBulletID<=0 or self.world.bulletList[self.lastBulletID]==nil or self.world.bulletList[self.lastBulletID]:isDead()
		-- 	 or self.world.bulletList[self.lastBulletID]._attackMode~=7))
			then
			if self.statusList[603]~=nil then
				self:addStatusList({s=50,r=self.world:getGameTime(),t=999,i=self.itemID,p1=29999})
			else
				self:addStatusList({s=50,r=self.world:getGameTime(),t=999,i=self.itemID,p1=self.attribute.HORSEID})
			end
			self.horseNow = false
			--self.attribute.MSPDorg = self.attribute.MSPD
			--self.attribute.MSPD = self.attribute.HORSEMSPD

			self:__getHorseInfo()

			local returnObj={}
			local s = self:moveTo(self.targetPosition.x,self.targetPosition.y,true)
			-- local time = 0
			-- if type(s)=="table" and #s['m']>0 then
			-- 	time = s['m'][#s['m']].t
			-- end
			-- if type(s)=="table" and (self.AImode==0 or self.autoBlocked) then
			-- 	self.syncMsg['m']['zz']=1
			-- 	returnObj['m'] = s
			-- end
			-- debuglog('======= addSkillAttackMode7 mspd'..self.attribute.MSPD..' org:'..self.attribute.MSPDorg)
			-- return returnObj
		end
	end

end

--- 第7招上馬取消
-- @param null
-- @return null
function SActor:removeSkillAttackMode7()
	if self.statusList[50]~=nil and self.statusList[603]==nil then
		self:D("下馬 removeSkillAttackMode7")
		-- self:D('jaylog removeSkillAttackMode7 ',string.gsub(debug.traceback("", 2), "\n", " "))
		self.lastStartMoveTime = 0
		self.lastStartMoveTime2 = 0
		self:removeStatusList(50)
		self:__getHorseInfo()
		local s = self:moveTo(self.targetPosition.x,self.targetPosition.y,true)
	end
	--self:removeSkillAttackMode9()
end

--- 第9招读条 
-- @param null
-- @return null
function SActor:removeSkillAttackMode9() 
	--debuglog("task 引导技能 打断1 ")
	if self.statusList[41]~=nil then
		--print(debug.traceback("", 2))
		self:D("task 引导技能 打断")
		--self.statusList[41] = nil
		self:removeStatusList(41)
		self:removeStatusList(605)
	end
	if self.statusList[100]~=nil then
		--print(debug.traceback("", 2))
		self:D("jaylog 引导技能 100 打断")
		--self.statusList[41] = nil
		self:removeStatusList(100)
	end
end

function SActor:prepareSkillAttackMode9(p)
	if p==nil then p = 0 end
	--debuglog("task 引导技能 释放")
	if self.statusList[999]~=nil then -- p1=self.world.tonumber(tlist[2]),p2=self.world.tonumber(TaskIDlist[3])
		self:D("task 引导技能 释放 p1:",self.statusList[999]['p1']," p2:",self.statusList[999]['p2'],self.world.cjson.encode(self.statusList[999]))
		--self.statusList[999]['p2'] = 5
		if self.statusList[999]['p5']~=nil and self.statusList[999]['p5']>0 then
			self:addStatusList({zz=3,s=41,r=self.world.gameTime,t=self.statusList[999]['p2'],p1=self.statusList[999]['p1'],p3=tonumber(p),p5=self.statusList[999]['p3']})
		else
			self:addStatusList({zz=3,s=41,r=self.world.gameTime,t=self.statusList[999]['p2'],p1=self.statusList[999]['p1'],p2=self.statusList[999]['p3'],p3=tonumber(p),p6=self.statusList[999]['p6']})
		end
		if self.statusList[607]~=nil then
			-- 指向采集的itemID
			self:addStatusList({zz=3,s=605,r=self.world.gameTime,t=self.statusList[999]['p2'],p1=self.statusList[607]['p1']})
		end
		self:removeStatusList(999)
		self:removeStatusList(607)
		self:moveTo(self.posX,self.posY)
		--- client side guy says don't send stop action and attack action together
		self.syncMsg['m'] = nil
	end
	if self.statusList[984]~=nil then
		self:D("jaylog 引导技能 984 释放 p1:",self.statusList[984]['p1']," p2:",self.statusList[984]['p2'],self.world.cjson.encode(self.statusList[984]))
		--self.statusList[999]['p2'] = 5
		self:addStatusList({zz=3,s=100,r=self.world.gameTime,t=self.statusList[984]['p2'],p1=self.statusList[984]['p1'],p2=self.statusList[984]['p3'],p3=self.statusList[984]['p4']})
		self:removeStatusList(984)
		self.world:addSyncMsg({gameinfo={{part=9,mType=3}}})
		-- self:moveTo(self.posX,self.posY)
		--- client side guy says don't send stop action and attack action together
		self.syncMsg['m'] = nil
	end
end

--- status结束时call的function
-- @param itemID int - itemID
-- @return null
function SActor:end605CallBack(itemID)
	self:addStatusList({zz=3,s=606,r=self.world.gameTime,t=1,p1=itemID})
end

--- 第8招滚动技能準備攻擊參數
-- @param updateMove bool － 是否計劃當前位置
-- @return result table - sync msg
function SActor:prepareSkillAttackMode8(updateMove)
--- in SHeroBase
end


-- function SActor:prepareSkillAttack(updateMove,fromClientSide,nPara,pPara)
-- 	return SActor.super.prepareSkillAttack(self,updateMove,fromClientSide,nPara,pPara)
-- end

function SActor:getEnemylist()
	if atkNoBeFight==nil then atkNoBeFight=false end		
	local list = {}
	list =  self:findTargetlist(true)
	return list
end

function SActor:getTeammatelist(atkNoBeFight)
	if atkNoBeFight==nil then atkNoBeFight=false end
	local list = {}
	list =  self:findTargetlist(false,atkNoBeFight)
	return list
end


function SActor:findTargetlist(isEnemy,atkNoBeFight)
	
	--local cacheID = self.attribute.actorType.."_"..(isEnemy and "true" or "false")

	--获得缓存的目标
	-- if self.world.AITargetList[cacheID]~=nil and (self.world.AITargetList[cacheID]['cacheTime']+1)>self.world.gameTime then
	-- 	local targetList = self.world.AITargetList[cacheID]['targetList']
	-- 	--debuglog("SAI cacheID:"..cacheID.." targetList:"..self.world.cjson.encode(targetList).." itemID:"..self.AIobj.itemID)
	-- 	return targetList
	-- else
	-- 	--debuglog("SAI NO cacheID:"..cacheID)
	-- 	self.world.AITargetList[cacheID] = {}
	-- end



	local list = {}
	-- local ok = true
	-- local enemy = {}
	-- if self.attribute.actorType==1 then
	-- 	enemy = self.world.itemListFilter.heroList
	-- else
	-- 	enemy = self.world.allItemList
	-- end
	-- if 	isEnemy then
	-- 	if self.teamOrig=="A" then
	-- 		enemy = self.world.itemListFilter.teamB
	-- 	end
	-- 	if self.teamOrig=="B" then
	-- 		enemy = self.world.itemListFilter.teamA
	-- 	end
	-- 	if self.teamOrig=="" then
	-- 		enemy = self.world.itemListFilter.teamABMemberList
	-- 	end
	-- 	-- print("teamOrig:",self.teamOrig)
	-- 	-- print("teamOrig: enemy:",self.world.cjson.encode(enemy))
	-- else

	-- 	if self.teamOrig=="A" then
	-- 		enemy = self.world.itemListFilter.teamAMemberList
	-- 	end
	-- 	if self.teamOrig=="B" then
	-- 		enemy = self.world.itemListFilter.teamBMemberList
	-- 	end
	-- 	if self.teamOrig=="" then
	-- 		enemy = self.world.itemListFilter.teamCMemberList
	-- 	end
		
	-- 	if atkNoBeFight then
	-- 		--debuglog("atkNoBeFight")
	-- 		if self.teamOrig=="A" then
	-- 			--debuglog("atkNoBeFight A")
	-- 			if table.nums(self.world.itemListFilter.noBeFightTeamA)>0 then
	-- 				table.merge(enemy,self.world.itemListFilter.noBeFightTeamA)
	-- 			end
	-- 		end
	-- 		if self.teamOrig=="B" then
	-- 			--debuglog("atkNoBeFight B")
	-- 			if table.nums(self.world.itemListFilter.noBeFightTeamB)>0 then
	-- 				table.merge(enemy,self.world.itemListFilter.noBeFightTeamB)
	-- 			end
	-- 		end
	-- 		if self.teamOrig=="" then
	-- 			-- debuglog("atkNoBeFight C")
	-- 			-- for k,v in pairs(self.world.itemListFilter.noBeFightTeamC) do
	-- 			-- 	debuglog("atkNoBeFight C k:"..k)
	-- 			-- end
	-- 			if table.nums(self.world.itemListFilter.noBeFightTeamC)>0 then
	-- 				table.merge(enemy,self.world.itemListFilter.noBeFightTeamC)
	-- 			end
	-- 		end
	-- 	end
	-- end

	-- --重新load一个新table  假如有动态处理的buff才需要重新加载table
	-- local isload = false
	-- if table.nums(self.world.itemListFilter.noBeFightBuffList)>0 then
	-- 	for k,v in pairs(self.world.itemListFilter.noBeFightBuffList) do
	-- 		if isload==false then
	-- 			local obj = self.world.allItemList[self.world.tonumber(k)]
	-- 			for k1,v1 in pairs(v) do
	-- 				if obj~=nil and obj.statusList[self.world.tonumber(k1)]~=nil then
	-- 					isload = true
	-- 				else
	-- 					table.remove(v,k1)
	-- 				end
	-- 			end
	-- 		end
	-- 	end
	-- end

	-- --400*400
	-- if isload then
	-- 	for k,obj in pairs(enemy) do
	-- 		ok = true
	-- 		if obj.statusList~=nil and obj.statusList[4007]~=nil and obj.attribute.actorType==0 then
	-- 			ok = false 
	-- 			--debuglog("SAI boss 搜敌 itemID:"..obj.itemID.." 排除目标")
	-- 		end
	-- 		if ok then
	-- 			list[#list+1]=obj
	-- 		end
	-- 	end
	-- else
	-- 	list = enemy
	-- end

	-- if self.world.AITargetList[cacheID]==nil then
	-- 	self.world.AITargetList[cacheID] = {}
	-- end
	-- self.world.AITargetList[cacheID]['cacheTime'] = self.world.gameTime
	-- self.world.AITargetList[cacheID]['targetList'] = list
	-- if self.attribute.roleId==1001 then
	-- 	debuglog('jaylog SActor:findTargetlist self itemID:'..self.itemID..' self roleId:'..self.attribute.roleId..' noBeFightBuffList:'..self.world.cjson.encode(self.world.itemListFilter.noBeFightBuffList)..' num:'..#self.world.itemListFilter.noBeFightBuffList)
	-- 	for k,v in pairs(list) do
	-- 		debuglog('jaylog SActor:findTargetlist itemID:'..v.itemID..' roleId:'..v.attribute.roleId)
	-- 	end
	-- end


	--function WorldBase:runTargetTypeFilter(targetType,team,thisID,options,func,...)
	if isEnemy then
		self.world:runTargetTypeFilter(1,self.team,self.itemID,{},
		function(obj)
		 	list[#list+1] = obj
		end
		)
	else

		if atkNoBeFight then
			self.world:runTargetTypeFilter(11,self.team,self.itemID,{},
			function(obj)
			 	list[#list+1] = obj
			end
			)
		else
			self.world:runTargetTypeFilter(5,self.team,self.itemID,{},
			function(obj)
			 	list[#list+1] = obj
			end
			)
		end

	end



	return list
end



function SActor:addStatusList(statusArray, adjTime)
	-- debuglog("jaylog addStatusList iD:"..self.world.cjson.encode(statusArray).." roleId:"..self.attribute.roleId)
	if statusArray~=nil and statusArray['s']==4007 then
		if self.world.itemListFilter.noBeFightBuffList[""..self.itemID]==nil then
			self.world.itemListFilter.noBeFightBuffList[""..self.itemID] = {}
		end
		self.world.itemListFilter.noBeFightBuffList[""..self.itemID][""..4007]=1
	end

	local statusList = self.world.sSplitNumber(self.world.setting['alwaysBroadcastBuff'],',')
	for k,v in pairs(statusList) do
		if statusArray['s']==v then
			if statusArray['zz']==nil then
				statusArray['zz'] = 10
			else
				statusArray['zz'] = statusArray['zz'] + 10
			end
			break
		end
	end

	return SActor.super.addStatusList(self,statusArray, adjTime)
end



function SActor:removeStatusList( statusNum, adjTime )
	-- debuglog("jaylog removeStatusList iD:"..self.world.cjson.encode(self.statusList[statusNum]).." roleId:"..self.attribute.roleId)
	if statusNum==4007 then
		self.world.itemListFilter.noBeFightBuffList[""..self.itemID][""..4007]=nil
		self:D("removeStatusList statusNum1:",statusNum,table.nums(self.world.itemListFilter.noBeFightBuffList[""..self.itemID]))
		if table.nums(self.world.itemListFilter.noBeFightBuffList[""..self.itemID])<1 then
			self.world.itemListFilter.noBeFightBuffList[""..self.itemID]=nil
		end
	end

	-- if statusNum==73 then
	-- 	self:updateSyncMsg({bc={{zz=3,mid=101,i=self.itemID}}})
	-- end
	self:endStatusCallBack(statusNum)

	return SActor.super.removeStatusList(self,statusNum, adjTime)
end

function SActor:removeStatusListNoNext(statusNum,adjTime)
	return SActor.super.removeStatusListNoNext(self,statusNum, adjTime)
end

--结束status的callBack
function SActor:endStatusCallBack(statusNum)
	-- body
end
--单纯加属性的buff
-- function SActor:addAttrBuff(toID,bufftime,adjTime,attributes)
-- 	--local attributes={} --buff屬性按buffAttributeclass內容,按buff的執⾏行規則填寫 attributes['CRI_UPFIX_RATE'] = 50
-- 	if attributes==nil then attributes={} end
-- 	--attributes['CRI_UPFIX'] = 22
-- 	--local bufftime = 5 -- buff 持續時間
-- 	local buffID = self:__skillID2buffID(0) -- buffID, 每個object 的buffList 中同時持續唯⼀一⼀一個 buffID
-- 	local fromID = self.itemID -- 施放者ID
-- 	-- local toID = toID -- 受buff者ID
-- 	-- local adjTime = 0.1 -- 延遲時間 , 不能太⾧長 最好少於world update間格


-- 	local obj  = self.world.allItemList[toID]
-- 	local buff = require("gameroomcore.SBuff").new( self.world , buffID , attributes , bufftime , {} , 0 , fromID , toID , adjTime )
-- 	obj:addBuff(buff) -- 加⼊入受buff者
-- end

--加群体AOE
--buffParameter=>
--attributes['buffParameter']['RANGE']=1000 -- 攻擊範圍等同skill.atkDis 
--attributes['buffParameter']['buffType'] = 1 -- 攻擊⺫⽬目標類型 等同skill.targetType
--attributes['buffParameter']['APADJ'] = 20 -- 攻擊参数   
--假如添加持续性的buff 例如燃烧需要加bufftime
--attributes['buffParameter']['APADJ'] = 20 -- 被攻击方buff持续时间  
--extraParameter=>
-- attributes['buffParameter']['buffIntervalTime'] = 0.5 — (*可不填) 計算間格, 預設0.5 attributes['buffParameter']['buffTargetPosX'] = 25 — (*可不填) 施放落點(中⼼心點)X, 預設受buff者⾃自⾝身座 標
-- attributes['buffParameter']['buffTargetPosY'] = 125— (*可不填) 施放落點(中⼼心點)Y, 預設受buff者⾃自⾝身 座標
-- attributes['buffParameter']['buffAtleastOnce'] = true — (*可不填) 執⾏行週期, 最少執⾏行⼀一次(因為施放者 死了buff會取消) 預設false
-- attributes['buffParameter']['buffNeedCallBack'] = true — (*可不填) buff release時會回調 施放者 buffCallBack(buffID,toID) 預設false
-- attributes['buffParameter']['buffChangeHurtMode'] = 1 — (*可不填) 改變 hurt mode h.m , 預設為1

-- function SActor:addAOEBuff(toID,bufftime,adjTime,buffParameter,skillID,extraParameter)
-- 	--持續AOE攻擊(加⾎血,加buff) , 由受buff者⾃自⾝身放出⼀一個AOE攻擊(包括加⾎血,加屬性buff), 使⽤用 bullet:directFightAura() 和 obj:directHurt() 發出攻擊
-- 	local attributes = {}
-- 	attributes['BUFFONLY']=1 -- 必填, 使內容不是空的

-- 	local hitValue = self:getPrepareHithitValue()
-- 	attributes['buffParameter'] = hitValue
-- 	if buffParameter~=nil then 
-- 		--attributes['buffParameter']=buffParameter
-- 		for k,v in pairs(buffParameter) do
-- 			if attributes['buffParameter'][k]~=nil then
-- 				attributes['buffParameter'][k] = attributes['buffParameter'][k] + v
-- 			else
-- 				attributes['buffParameter'][k] = v
-- 			end
-- 		 end 
-- 	end

-- 	if extraParameter~=nil then
-- 		for k,v in pairs(extraParameter) do
-- 			attributes['buffParameter'][k] = v
-- 		end
-- 	end

-- 	--local bufftime = bufftime --buff 持續時間
-- 	local buffID = self:__skillID2buffID(skillID) -- buffID, 每個object 的buffList 中同時持續唯⼀一⼀一個 buffID
-- 	local fromID = self.itemID -- 施放者ID
-- 	-- local toID = toID -- 受buff者ID
-- 	-- local adjTime = adjTime --— 延遲時間 , 不能太⾧長 最好少於world update間格


-- 	local obj  = self.world.allItemList[toID]
-- 	local buff = require("gameroomcore.SBuff").new( self.world , buffID , attributes , bufftime , {99} ,0 , 0 , fromID , toID , adjTime )
-- 	obj:addBuff(buff) -- 加⼊入受buff者
-- end

--单次buff伤害 type, attackRange, hitValue, angle, degree, toID
-- attributes['buffParameter']['buffTargetPosX']=float *可不填 1-50技能回調,98,99 施放落點X
-- attributes['buffParameter']['buffTargetPosY']=float *可不填 1-50技能回調,98,99 施放落點Y
--attackRange: table - 範圍 {posX=,posY=,radius=}

-- function SActor:directFightAuraBuff(type, attackRange, hitValue, angle, degree, toID)
-- 	--持續AOE攻擊(加⾎血,加buff) , 由受buff者⾃自⾝身放出⼀一個AOE攻擊(包括加⾎血,加屬性buff), 使⽤用 bullet:directFightAura() 和 obj:directHurt() 發出攻擊
-- 	local attributes = {}
-- 	attributes['BUFFONLY']=1 -- 必填, 使內容不是空的

-- 	local hitValue = self:getPrepareHithitValue()
-- 	attributes['buffParameter'] = hitValue
-- 	attributes['buffParameter']['RANGE'] = attackRange
-- 	attributes['buffParameter']['buffType'] = type
-- 	attributes['buffParameter']['ADADJ'] = 100
-- 	attributes['buffParameter']['buffAtleastOnce'] = true




-- 	if buffParameter~=nil then 
-- 		--attributes['buffParameter']=buffParameter
-- 		for k,v in pairs(buffParameter) do
-- 			if attributes['buffParameter'][k]~=nil then
-- 				attributes['buffParameter'][k] = attributes['buffParameter'][k] + v
-- 			else
-- 				attributes['buffParameter'][k] = v
-- 			end
-- 		 end 
-- 	end

-- 	if extraParameter~=nil then
-- 		for k,v in pairs(extraParameter) do
-- 			attributes['buffParameter'][k] = v
-- 		end
-- 	end

-- 	--local bufftime = bufftime --buff 持續時間directFightAuratoDalay
-- 	local buffID = self:__skillID2buffID(0) -- buffID, 每個object 的buffList 中同時持續唯⼀一⼀一個 buffID
-- 	local fromID = self.itemID -- 施放者ID
-- 	-- local toID = toID -- 受buff者ID
-- 	-- local adjTime = adjTime --— 延遲時間 , 不能太⾧長 最好少於world update間格
-- end


--群体伤害延时
--- 群体伤害延时
-- @param mode int - 技能id
-- @param itemID int - 目标id
-- @param hitValue table - 攻击参数
-- @param attackRange table - {posX=self.posX,posY=self.posY,RANGE=skill.atkDis}
-- @param adjtime int - 延迟时间
function SActor:directFightAuratoDalay(mode,itemID,hitValue,attackRange, adjtime)
	local targetType = 1
	if self.itemID == itemID then
		targetType=5
	end
	if itemID>0 then
		local obj  = self.world.allItemList[itemID]
		if self.itemID ~= itemID and obj.teamOrig==self.teamOrig then
			targetType=5
		end
	end
	local customize = self.world:createSkillValue()
	customize['attackMode'] = 3
	customize['atkDis'] = attackRange['RANGE']
	customize['bulletSpeed'] = 99999
	customize['targetType'] = targetType
	self:D("directFightAuratoDalay customize:",self.world.cjson.encode(customize) )
	local bulletID = self.world:addBullet(mode,self.itemID,self.world.gameTime+adjtime,itemID,attackRange['posX'],attackRange['posY'],false,hitValue,customize) 
	--self.world.bulletList[bulletID].debug=true
end

--- 单体伤害延时
-- @param mode int - 技能id
-- @param itemID int - 目标id
-- @param hitValue table - 攻击参数
-- @param adjtime int - 延迟时间
function SActor:directHurtToDalay(mode,itemID, hitValue, adjtime)
	local targetType = 1
	if self.itemID == itemID then
		targetType=3
	end
	local obj  = self.world.allItemList[itemID]
	if self.itemID ~= itemID and obj.teamOrig==self.teamOrig then
		targetType=5
	end

	local customize = self.world:createSkillValue()
	customize['attackMode'] = 2
	customize['bulletSpeed'] = 99999
	customize['targetType'] = targetType
	local bulletID = self.world:addBullet(mode,self.itemID,self.world.gameTime+adjtime,obj.itemID,obj.posX,obj.posY,false,hitValue,customize) 
	-- self.world.bulletList[bulletID].debug=true
end


--添加非aoe buff
--buffParameter=>
--attributes['buffParameter']['APADJ'] = 20 -- 攻擊参数   
--extraParameter=>
-- attributes['buffParameter']['buffIntervalTime'] = 0.5 — (*可不填) 計算間格, 預設0.5
-- attributes['buffParameter']['buffAtleastOnce'] = true — (*可不填) 執⾏行週期, 最少執⾏行⼀一次(因為施放者 死了buff會取消) 預設false
-- attributes['buffParameter']['buffNeedCallBack'] = true — (*可不填) buff release時會回調 施放者 buffCallBack(buffID,toID) 預設false
-- attributes['buffParameter']['buffChangeHurtMode'] = 1 — (*可不填) 改變 hurt mode h.m , 預設為1
--可能和上面一样 续缩减
-- function SActor:addNOAOEBuff(toID,bufftime,adjTime,buffParameter,skillID,extraParameter)
-- 	--持續傷害(加⾎血) buff , 使⽤用obj:directHurt() 發出攻擊
-- 	local attributes = {}
-- 	attributes['BUFFONLY']=1 -- 必填, 使內容不是空的

-- 	local hitValue = self:getPrepareHithitValue()
-- 	attributes['buffParameter'] = hitValue
-- 	if buffParameter~=nil then 
-- 		--attributes['buffParameter']=buffParameter
-- 		for k,v in pairs(buffParameter) do
-- 		 	if attributes['buffParameter'][k]~=nil then
-- 		 		attributes['buffParameter'][k] = attributes['buffParameter'][k] + v
-- 		 	else
-- 		 		attributes['buffParameter'][k] = v
-- 		 	end
-- 		 end 
-- 	end

-- 	if extraParameter~=nil then
-- 		for k,v in pairs(extraParameter) do
-- 			attributes['buffParameter'][k] = v
-- 		end
-- 	end

-- 	--local bufftime = bufftime --buff 持續時間
-- 	local buffID = self:__skillID2buffID(skillID) -- buffID, 每個object 的buffList 中同時持續唯⼀一⼀一個 buffID
-- 	local fromID = self.itemID -- 施放者ID
-- 	-- local toID = toID -- 受buff者ID
-- 	-- local adjTime = adjTime --— 延遲時間 , 不能太⾧長 最好少於world update間格


-- 	local obj  = self.world.allItemList[toID]
-- 	local buff = require("gameroomcore.SBuff").new( self.world , buffID , attributes , bufftime , {99} ,0 , 0 , fromID , toID , adjTime )
-- 	obj:addBuff(buff) — 加⼊入受buff者
-- 	--持續回調技能攻擊 , 由受buff者⾃自⾝身回調技能攻擊, 按技能obj:prepareHit(mode+100,adjTime,true) (*注 mode+100) 返回hitValue內容 , ⽤用⼦子彈bullet 發動攻擊, 和 技能攻擊流程⼀一樣

-- end

--buffParameter=>
--attributes['buffParameter']['RANGE']=1000 -- 攻擊範圍等同skill.atkDis 
--attributes['buffParameter']['buffType'] = 1 -- 攻擊⺫⽬目標類型 等同skill.targetType
--attributes['buffParameter']['APADJ'] = 20 -- 攻擊参数   
--extraParameter=>
-- attributes['buffParameter']['buffHitTime'] = 0.2 — (*可不填) 延遲執⾏行⼦子彈(準備動作), 預設0 
-- attributes['buffParameter']['buffIntervalTime'] = 0.5 — (*可不填) 計算間格, 預設0.5 
-- attributes['buffParameter']['buffTargetPosX'] = 25 — (*可不填) 施放落點(中⼼心點)X, 預設受buff者⾃自⾝身座 標
-- attributes['buffParameter']['buffTargetPosY'] = 125— (*可不填) 施放落點(中⼼心點)Y, 預設受buff者⾃自⾝身 座標
-- attributes['buffParameter']['buffAtleastOnce'] = true — (*可不填) 執⾏行週期, 最少執⾏行⼀一次(因為施放者 死了buff會取消) 預設false
-- attributes['buffParameter']['buffNeedCallBack'] = true — (*可不填) buff release時會回調 施放者 buffCallBack(buffID,toID) 預設false
-- attributes['buffParameter']['buffChangeHurtMode'] = 1 — (*可不填) 改變 hurt mode h.m , 預設為1

-- function SActor:addLoopBuff(toID,bufftime,adjTime,buffParameter,skillID,extraParameter,modes)
-- 	local attributes = {}
-- 	attributes['BUFFONLY']=1 -- 必填, 使內容不是空的

-- 	local hitValue = self:getPrepareHithitValue()
-- 	attributes['buffParameter'] = hitValue
-- 	if buffParameter~=nil then 
-- 		--attributes['buffParameter']=buffParameter
-- 		for k,v in pairs(buffParameter) do
-- 			if attributes['buffParameter'][k]~=nil then
-- 				attributes['buffParameter'][k] = attributes['buffParameter'][k] + v
-- 			else
-- 				attributes['buffParameter'][k] = v
-- 			end
-- 		 end 
-- 	end

-- 	if extraParameter~=nil then
-- 		for k,v in pairs(extraParameter) do
-- 			attributes['buffParameter'][k] = v
-- 		end
-- 	end

-- 	local buffID = self:__skillID2buffID(skillID) -- buffID, 每個object 的buffList 中同時持續唯⼀一⼀一個 buffID
-- 	local fromID = self.itemID -- 施放者ID
-- 	--local modes = {modes} -- 技能3 的回調, 回調 obj:prepareHit( 3+100 , adjTime , true )
-- 	local buff = require("gameroomcore.SBuff").new( obj.world , buffID , attributes , bufftime , {modes} ,0 , 0 , fromID , toID , adjTime )
-- 	obj:addBuff(buff) -- 加⼊入受buff者
-- end

--- 设置别名
-- @param name string - 别名
function SActor:setSubName(name)
	if name==nil then
		name = ''
	end
	self.subName = name
end



--- 返回玩家当前的参数例如地址 血量 等等
-- @param null
function SActor:getCurrentAttr()
	local ret = {}
	ret['posX']=self.posX
	ret['posY']=self.posY
	ret['HP']=self.attribute.HP
	ret['MP']=self.attribute.MP
	ret['mapMode']=self.world.mapModel
	ret['mapPort']=self.world.mapPort

	return ret
end

function SActor:setBlockLenWidth(len,width)
	self:D('jaylog SActor:setBlockLenWidth len:',len,' width:',width)
	if len==nil then
		len = 0
	end
	if width==nil then
		width = 0
	end
	self.blockLen = len
	self.blockWidth = width
	local result = self:getAllInfo()
	self:updateSyncMsg({i=result})
end



--设置共存id
function SActor:setCoexistID(id)
	self.coexistID = id
end

function SActor:calculateHatredList(from,current)
	for k,v in pairs(self.Hatredlist) do
		if self.HatredlistRecord[k]==nil then self.HatredlistRecord[k] = {} end
		local t = self.HatredlistRecord[k]
		t[current-1] = v - (t[current-1]~=nil and t[current-1] or 0)
		if t[from]~=nil then
				self.Hatredlist[k] = v - t[from]
				if self.Hatredlist[k]<=0 then self.Hatredlist[k] = 1 end
				t[from] = nil
		end
		t[current] = self.Hatredlist[k]
	end
end

function SActor:setAuto()
	-- body
end

--新手保护规则
function SActor:newbieProtection(fromType,fromLv,fromTeam,toType,toLv,toTeam,toLastREHPattackTime)
	if toType == nil then toType=-1 end
	if toLv == nil then toLv=0 end
	if toTeam == nil then toTeam='' end
	if toLastREHPattackTime == nil then lastREHPattackTime = 0 end
	local mapMode = self.world.mapModel

	-- return true

	-- self:D("新手保护")
	-- --同队享受原有规则
	if fromTeam==toTeam then
		self:D("新手保护 同队享受原有规则")
		return true
	end
	
	if self.world.gameRoomSetting['ISYW']==0 then
		return true
	end
	 
	-- if self.world.setting.ProtectType~=nil and self.world.setting.ProtectType==1 then
	
	-- else
	-- 	return true
	-- end

	--攻击方和防御方有一方不属于英雄享受原有规则
	if fromType~=0 or toType~=0 then
		self:D("新手保护 攻击方和防御方有一方不属于英雄享受原有规则")
		return true
	end

	--主城敌法只能被打
	if mapMode=='10' or mapMode=='60' then
		if (mapMode=='10' and toTeam=="A" ) or (mapMode=='60' and toTeam=="B" ) then
			return true
		else
			return false
		end
	end

	-- --小于15级的玩家在地方主城不享受保护
	if toLv<=self.world.setting.ProtectLevel then
		-- if ((toTeam=='A' and mapMode=="60") or (toTeam=='B' and mapMode=="10")) then
		-- 	self:D("新手保护 小于15级的玩家在敌方主城不享受保护")
		-- 	return true
		-- else
		-- 	self:D("新手保护 小于15级的玩家在非敌方主城享受保护")
		-- 	return false
		-- end
		return false
	end

	--小于15级的玩家在地方主城不享受保护 可以攻击
	if fromLv<=self.world.setting.ProtectLevel then
		-- if  ((fromTeam=='A' and mapMode=="60") or (fromTeam=='B' and mapMode=="10")) then
		-- 	self:D("新手保护 小于15级的玩家在敌方主城可以攻击")
		-- 	return true
		-- else
		-- 	self:D("新手保护 小于15级的玩家在非敌方主城不可以攻击")
		-- 	return false
		-- end
		return false
	end

	-- --玩家在主城的时候相互攻击 自己方主城享有主动攻击以后才被攻击的保护
	-- self:D("新手保护 玩家在主城内最近30秒开了主动攻击 " , toTeam , mapMode , type(mapMode) , toLastREHPattackTime)
	-- if ((toTeam=='A' and mapMode=="10") or (toTeam=='B' and mapMode=="60")) then
	-- 	if toLastREHPattackTime>0 and (toLastREHPattackTime+30)>self.world:getGameTime() then
	-- 		self:D("新手保护 玩家在主城内最近30秒开了主动攻击 可以攻击",toLastREHPattackTime)
	-- 		return true
	-- 	else
	-- 		self:D("新手保护 玩家在主城内最近30秒未开主动攻击 不可以攻击")
	-- 		return false
	-- 	end
	-- end

	--野外保护
	if self.world.setting.ProtectType~=nil and self.world.setting.ProtectType==1 then
		local ProtectYWLevel = self.world.setting.ProtectYWLevel
		if (((toTeam=="A" and toLv<=ProtectYWLevel) or (fromTeam=="A" and fromLv<=ProtectYWLevel)) and self.world.tonumber(mapMode)<500) or (((toTeam=="B" and toLv<=ProtectYWLevel) or (fromTeam=="B" and fromLv<=ProtectYWLevel)) and self.world.tonumber(mapMode)>500) then
			self:D("新手保护 野外保护 不可以攻击",self.world.setting.ProtectType,self.world.setting.ProtectType,self.world.setting.ProtectYWLevel)
			return false
		else
			self:D("新手保护 野外保护 可以攻击",self.world.setting.ProtectType,self.world.setting.ProtectType,self.world.setting.ProtectYWLevel)
			return true
		end 
	end

	-- if mapMode=="105" or mapMode=="505" then
	-- 	if (((toTeam=="A" and toLv<15) or (fromTeam=="A" and fromLv<15)) and mapMode=="105") or (((toTeam=="B" and toLv<15) or (fromTeam=="A" and fromLv<15)) and mapMode=="505") then
	-- 		return false
	-- 	else
	-- 		return true
	-- 	end 
	-- end

	-- if mapMode=="102" or mapMode=="502" then
	-- 	if (((toTeam=="A" and toLv<20) or (fromTeam=="A" and fromLv<20)) and mapMode=="102") or (((toTeam=="B" and toLv<20) or (fromTeam=="A" and fromLv<20)) and mapMode=="502") then
	-- 		return false
	-- 	else
	-- 		return true
	-- 	end 
	-- end

	-- if mapMode=="103" or mapMode=="503" then
	-- 	if (((toTeam=="A" and toLv<25) or (fromTeam=="A" and fromLv<25)) and mapMode=="103") or (((toTeam=="B" and toLv<25) or (fromTeam=="A" and fromLv<25)) and mapMode=="503") then
	-- 		return false
	-- 	else
	-- 		return true
	-- 	end 
	-- end
	-- -- if mapMode=="104" or mapMode=="504" then
	-- -- 	if (((toTeam=="A" and toLv<30) or (fromTeam=="A" and fromLv<30)) and mapMode=="104") or (((toTeam=="B" and toLv<30) or (fromTeam=="A" and fromLv<30)) and mapMode=="504") then
	-- -- 		return false
	-- -- 	else
	-- -- 		return true
	-- -- 	end 
	-- -- end

	-- if mapMode=="106" or mapMode=="506" then
	-- 	if (((toTeam=="A" and toLv<35) or (fromTeam=="A" and fromLv<35)) and mapMode=="106") or (((toTeam=="B" and toLv<35) or (fromTeam=="A" and fromLv<35)) and mapMode=="506") then
	-- 		return false
	-- 	else
	-- 		return true
	-- 	end 
	-- end
	--永恒 枢纽101 冰图105 水图102 林图103 火图104 边境106   涅槃 枢纽501 冰图505 水图502 林图503 火图504 边境506


	return true
end

--- 是否安全状态
-- @param null
-- @return boolean
function SActor:safe()
	--if self.statusList[73]~=nil or self.world.mapModel=='10' or self.world.mapModel=='60' then
	if self.statusList[73]~=nil then	
		return true
	end
	return false
end

--- 99状态清除其他状态回调
-- @param status integer - 需要清除的状态
-- @return null
function SActor:status99CallBack(status)
	if status==nil or status==0 then
		return nil
	end
	self:D("status99CallBack...............清状态:",status)
	if self.statusList[status]~=nil then
		self:removeStatusList(status)
	end
end

--- 這個function 會在 執行前搖時call 當skill.delayCalTime>0
-- @param skill skillobj - skillobj
function SActor:prepareSkillAttackDelayInit(skill)

	local hitValue = self:createhitValue()
	local mode = skill.rank

	--add 基础属性
	for k,v in pairs(self.attribute) do
		if hitValue[k]~=nil and hitValue[k]~="table" then
			hitValue[k] = self.attribute[k]
		end
	end
	--random系数
	hitValue['ADJTIME'] = 0
	--add sKill 属性 普通攻击要特殊处理
	hitValue['skillID'] = skill.skillID
	hitValue['mode'] = mode
	self:D("prepareSkillAttackDelayInit prepareSkillAttackDelayInit:",self.world.cjson.encode(skill.parameters))
	for k,v in pairs(skill.parameters) do
		if hitValue[k]==nil then
			hitValue[k] = v
		else
			hitValue[k] = hitValue[k] + v
		end
	end

	local alist = {"A","B","C","D","E","F"}
	for i=1,#alist do
		--自动添加状态 全自动加状态
		if hitValue['PREADDSELFSTATUS'..alist[i]]~=nil and hitValue['PREADDSELFSTATUS'..alist[i]]>0 then
			self:D("add PRESELFstatusA 自动添加状态:",hitValue['PREADDSELFSTATUS'..alist[i]])

			if hitValue["PRETRIGGERSELFSTATUS"..alist[i]]~=nil and hitValue["PRETRIGGERSELFSTATUS"..alist[i]] > 0 then	
				self:D("add PRESELFstatusA 自动添加状态 2层:",hitValue['PRESTRIGGERSELFSTATUS'..alist[i]])
				self:D("remove PRESELFstatusA list find nextStatus add time :",self.world.gameTime," mode:",mode)
				local s = {s=hitValue['PREADDSELFSTATUS'..alist[i]],t=hitValue['PREADDSELFSTATUSTIME']..alist[i]}
				local s1 = {s=hitValue["PRETRIGGERSELFSTATUS"..alist[i]],t=hitValue['PRETRIGGERSELFSTATUSTIME'..alist[i]]}
				self:addScheduleStatusList(0,s,s1)	
			else
				self:D("add PRESELFstatusA 自动添加状态1:",hitValue['PREADDSELFSTATUS'..alist[i]])
				local s = {s=hitValue['PREADDSELFSTATUS'..alist[i]],r=self.world.gameTime,t=hitValue['PREADDSELFSTATUSTIME'..alist[i]],i=self.itemID}
				if hitValue['CHANTSHOW']~=nil then
					s['p4'] = hitValue['CHANTSHOW']
				end
				if hitValue['ENDCLEANSTATUS']~=nil then
					s['p1'] = hitValue['ENDCLEANSTATUS']
				end
				self:addStatusList(s,0)
			end
		end	
	end

	return hitValue
end

--- 设置自动跟随
-- @param itemID int - 目标ID，itemID>0开启跟随，不填或0取消跟随
-- @return null
function SActor:setAutoFollow(itemID)
	if itemID==nil then
		itemID = 0
	end
	if itemID>0 then
		self.autoFollow = true
		local targetObj = self.world.allItemList[itemID]
		if targetObj.sharedID>0 then
			self.autoFollowTargetID = targetObj.sharedID
		else
			self.autoFollowTargetID = itemID
		end
		self:addStatusList({s=994,r=self.world.gameTime,t=9999})
	else
		self.autoFollow = false
		self.autoFollowTargetID = 0
		self:removeStatusList(994)
	end
end

--- 设置自动跟随到达后停止并且不参状态
-- @param itemID int - 目标ID，itemID>0开启跟随，不填或0取消跟随
-- @param stopType int - 停止类型，0=手动停止，1=自动停止
-- @return null
function SActor:setAutoTo(itemID,stopType)
	if itemID==nil then
		itemID = 0
	end
	if stopType==nil then
		stopType = 0
	end
	if itemID>0 then
		self.autoTo = true
		self.autoToTargetID = itemID
	else
		self.autoTo = false
		self.autoToTargetID = 0
		self:setAutoToCallBack(stopType)
	end
end

--- 设置自动跟随到达后回调
-- @param stopType int - 停止类型，0=手动停止，1=自动停止
-- @return null
function SActor:setAutoToCallBack(stopType)
	
end

--- 是否AI
-- @param null
-- @return result boolean - true或false
function SActor:isAIObj()
end

---设置AI攻击目标
-- @param auto bool - 开启集火
-- @param itemID int - 集火目标
-- @param time int - 集火时长
-- @return null
function SActor:setAITagretID(auto,itemID,time)
	if time==nil or time==0 then
		time=999999
	end

	if auto then
		self.AITargetTime = self.world:getGameTime() + time
	else
		self.AITargetTime = 0
	end
	self.AITargetAuto = auto
	--没填目标就继续集火上一个目标
	if itemID~=nil then
		self.AITargetItemID = itemID
	end
	
	self:D("setAITagretID :",auto,itemID,time)
end

return SActor
