local formula = class("formula")

function formula:ctor()
	self.randomNum = 1
end

--- 是否命中
-- @param ghitValue table - 攻击方的参数
-- @param f table - 防御方也即是被攻击方 的属性
-- @return true or false
function formula:isHIT(ghitValue,f)
	local gHIT = ghitValue.HIT
	local gHIT_UP = ghitValue.HIT_UP
	local gHIT_DOWN = ghitValue.gHIT_DOWN
	local fDODGE = f.DODGE

	local ptHITs=1
	if fDODGE~=0 then
		ptHITs = 1.392^(gHIT/fDODGE) - 0.642 
	end
	
	
	local HITs = ptHITs 
	--命中率的区间为100%~50%。即当最终命中率大于100%，则去100%，小于50%则取50%。
	
	if HITs>1 then
		HITs = 1
	end
	if HITs<0.5 then
		HITs = 0.5
	end
	----debuglog("命中率测试.....攻击方命中值:"..gHIT.." 防御方的闪避:"..fDODGE.." 结果:"..HITs)
	local rand = self:getRandnum()
	----debuglog("命中率测试.....随机值:"..rand)

	if rand>HITs*100 then
		--返回miss
		return false
	else
		return true
	end

end



--- 是否暴击
-- @param ghitValue table - 攻击方的参数
-- @param g table  - 攻击方 的属性
-- @param f table  - 防御方也即是被攻击方 的属性
-- @return true or false
function formula:isCRI(ghitValue,g,f)
	local gCRI = ghitValue.CRI
	--local CRIs = (0.5*gCRI+250)/(gCRI+5000)*1.1^((g.level-f.level)/5)
	local CRIs = 0
	if g.level>30 then
	 	CRIs = gCRI/(26.581*g.level^2+(-554.2)*g.level+4994.8)*(1.1^((g.level-f.level)/5))	
	else
		CRIs = gCRI/(17.403*g.level^2-152.79*g.level+817.63)*(1.1^((g.level-f.level)/5))	
	end
	if CRIs>0.7 then
		CRIs=0.7
	end
	----debuglog("暴击率测试.....攻击方暴击值:"..gCRI.."攻击方等级:"..g.level.." 防御方等级:"..f.level.." 暴击值:"..CRIs)
	local rand = self:getRandnum()
	----debuglog("暴击率测试.....随机值:"..rand)
	if rand<=CRIs*100 then
		--暴击伤害翻倍
		return true
	else
		return false
	end
end


--- 计算所有的伤害
-- @param ghitValue table - 攻击方的参数
-- @param g table  - 攻击方 的属性
-- @param f table  - 防御方也即是被攻击方 的属性
-- @return hurt  伤害
function formula:allHurt(ghitValue,g,f)

	local gATK = ghitValue.ATK
	local fDEF = f.DEF
	local fMDEF = f.MDEF
	local pvp = ghitValue.ISPVP

	local aphurt = 1
	local adhurt = 1
	local pthurtad = 1
	local pthurtap = 1
	local mCeil = math.ceil 

	--韧性
	local tenacity = 1
	-- if pvp>0 then
		tenacity = self:getTenacity(g.actorType,f.actorType,f.level)
	--end

	if fDEF==0 or gATK/fDEF<1.053 then
		-- pthurtad =  math.ceil((1.25^(gATK*0.8/fDEF-1))*(0.64*(gATK^2)/fDEF))	
		pthurtad = mCeil(gATK*0.05)
	else
		pthurtad = gATK-fDEF
	end

	if fMDEF==0 or gATK/fMDEF<1.053 then
		--pthurtap =  math.ceil((1.25^(gATK*0.8/fMDEF-1))*(0.64*(gATK^2)/fMDEF))	
		pthurtap = mCeil(gATK*0.05)
	else
		pthurtap = gATK-fMDEF
	end
	
	aphurt = pthurtap*(ghitValue.APADJ*0.01)*(f.BEAPHURT)*(g.APHURT)
	adhurt = pthurtad*(ghitValue.ADADJ*0.01)*(f.BEADHURT)*(g.ADHURT)

	--计算格挡伤害减免
	-- if ghitValue['HURTAD_HURT'] ~=nil then
	-- 	--debuglog("格挡 减伤前ad..."..adhurt)
	-- 	adhurt = adhurt * (1-ghitValue['HURTAD_HURT']/100)
	-- 	--debuglog("格挡 减伤前ad..."..adhurt)
	-- end
	-- if ghitValue['HURTAP_HURT'] ~=nil then
	-- 	--debuglog("格挡 减伤前ap..."..aphurt)
	-- 	adhurt = adhurt * (1-ghitValue['HURTAP_HURT']/100)
	-- 	--debuglog("格挡 减伤前ap..."..aphurt)
	-- end
	--最终伤害

	all =  (aphurt+adhurt)*tenacity*(f.BEALLHURT)*(g.ALLHURT)
	allAphurt = (aphurt)*tenacity*(f.BEALLHURT)*(g.ALLHURT)
	allAdhurt = (adhurt)*tenacity*(f.BEALLHURT)*(g.ALLHURT)

	if g.actorType==0 or f.actorType==0  then
		debuglog("总伤害计算..攻击roleID:"..g.roleId.." 攻击方攻击力:"..gATK.." 攻击方等级:"..g.level.." 攻击方ADADJ:"..ghitValue.ADADJ.." 攻击方APADJ:"
			..ghitValue.APADJ.."攻击方APHURT"..g.APHURT.."攻击方ADHURT"..g.ADHURT.."攻击方ALLHURT"..g.ALLHURT.." 防御roldID:"..f.roleId.." 敌方等级:"..f.level.." 敌方DEF:"..fDEF.." 敌方MDEF:"..fMDEF
			.."防御方BEAPHURT"..f.BEAPHURT.."防御方BEADHURT"..f.BEADHURT.."防御方BEALLHURT"..f.BEALLHURT.." 韧性:"..tenacity.." pthurtad:"..pthurtad.." pthurtap:"..pthurtap.." aphurt:"..aphurt
			.." adhurt:"..adhurt.." allHurt:"..all.." ISPVP"..pvp)
	end

	return all,allAphurt,allAdhurt
end

--获得韧性
-- function formula:getTenacity(pvp,level)
-- 	local tenacity = 1
-- 	if pvp>0 then
-- 		tenacity = 1 - 0.382*level^0.1864	
-- 	else
-- 		tenacity = tenacity * 0.1
-- 	end

-- 	return tenacity
-- end

function formula:getTenacity(gActorType,fActorType,level)
	local tenacity = 1
	if gActorType==0 and fActorType==0 then
		tenacity = 1 - 0.6531*level^0.0682	
	else
		tenacity = tenacity * 0.2
	end

	return tenacity
end

--gvb治疗衰减
function formula:getGVBREHPTenacity(level)
	local tenacity = 1
	tenacity = (0.017*level^2+(-2.0987*level)+128)*0.01
	--debuglog("getGVBREHPTenacity :"..tenacity)
	return tenacity
end

--- 计算所有的伤害
-- @param ghitValue table - 攻击方的参数
-- @param Probability int  - 异常附加概率
-- @param f table  - 防御方也即是被攻击方 的属性
-- @return true or false
function formula:isAbnormalState(name,Probability,f)
	local state = Probability*(1-(f[name..'_resistance']*0.0001))

	self:resetRandnum()

	--math.randomseed(os.time()+state*1888) 
	--math.randomseed(os.time()+state*self.randnum)
	local rand = self:getRandnum()
	if rand<=state*100 then
		--异常几率触发
		return true
	else
		return false
	end
end

---普通攻击的暴击伤害
-- @param hitType int - 普通攻击的类型
-- @return true or false
function formula:modeCriHurt(hitType)
	local CRIHurt = 1
	--self:resetRandnum()

	--math.randomseed(os.time()+hitType*67435) 
	--math.randomseed(os.time()+hitType*self.randnum)
	if hitType==0 then
		--CRIHurt = math.random(80,120) / 100
		CRIHurt = self:getRandnum(80,120) / 100
	end
	if hitType==1 then
		--CRIHurt = math.random(80,110) / 100
		CRIHurt = self:getRandnum(80,110) / 100
	end
	if hitType==2 then
		--CRIHurt = math.random(90,120) / 100
		CRIHurt = self:getRandnum(90,120) / 100
	end
	if hitType==3 then
		CRIHurt = 1.2
	end
	if hitType==4 then
		CRIHurt = 0.6
	end

	return CRIHurt
end

---刷新随机种子
function formula:getRandnum(startNum,endNum)
	if self.randomNum==nil then
		self.randomNum = 1
	end
	if startNum==nil then
		startNum = 1
	end
	if endNum==nil then
		endNum = 100
	end
	math.randomseed(os.time()+self.randomNum*1888)
	self.randomNum = self.randomNum + 1
	local rand = math.random(startNum,endNum)
	return rand
end


---随机园内取点 CircleBool=true 选取圆上的点
function formula:getRandomCirclePoint(intX,intY,R,CircleBool)
	if CircleBool==nil then CircleBool = false end
	-- 0<=theta<360
	local theta = self:getRandnum(0,360)
	--0<=r<=R
	local r = R
	if not CircleBool then
		r = math.sqrt(self:getRandnum(0,100)*0.01)*R
		----debuglog("getRandomCirclePoint  有没有园内随机 r:"..r)
	end
	-- r = math.sqrt(r)
	local x = r*math.sin(math.rad(theta))
	local y = r*math.cos(math.rad(theta))

	----debuglog("getRandomCirclePoint x:"..x.." y:"..y.." theta:"..theta.." r:"..r.." R:"..R)
	return x+intX,y+intY
end


---阵法摆法
function formula:formationPoint(zftype,r,average,CircleBool)
	if average==nil then
		average=false
	end
	if CircleBool==nil then
		CircleBool = false
	end
	
	local randlist = {{-r,0},{r,0},{0,r},{0,-r},{r*0.7,r*0.7},{-r*0.7,r*0.7},{r*0.7,-r*0.7},{-r*0.7,-r*0.7},
						{-r,0},{r,0},{0,r},{0,-r},{r*0.5,r*0.87},{-r*0.5,r*0.87},{r*0.5,-r*0.87},{-r*0.5,-r*0.87},
						{r*0.87,r*0.5},{-r*0.87,r*0.5},{r*0.87,-r*0.5},{-r*0.87,-r*0.5}}

	if not average then
		if zftype==12 then
			randlist = {{-r,0},{r,0},{0,r},{0,-r},{r*0.5,r*0.87},{-r*0.5,r*0.87},{r*0.5,-r*0.87},{-r*0.5,-r*0.87},
							{r*0.87,r*0.5},{-r*0.87,r*0.5},{r*0.87,-r*0.5},{-r*0.87,-r*0.5}}
		elseif zftype==8 then
			randlist = {{-r,0},{r,0},{0,r},{0,-r},{r*0.7,r*0.7},{-r*0.7,r*0.7},{r*0.7,-r*0.7},{-r*0.7,-r*0.7}}
		elseif zftype==5 then
			randlist = {{r*0.7,r*0.7},{-r*0.7,r*0.7},{r*0.7,-r*0.7},{-r*0.7,-r*0.7},{0,0}}
		else
			randlist = {}
			for i=1,zftype do
				local x,y = self:getRandomCirclePoint(0,0,r,CircleBool)
				randlist[#randlist+1]={x,y}
			end
		end
	else
		randlist = {}
		--均等分
		for i=1,zftype do
			randlist[#randlist+1]={r*math.cos(math.rad((360/zftype)*i)),r*math.sin(math.rad((360/zftype)*i))}
		end
		randlist=table.deepcopy(randlist)
	end

	----debuglog("formationPoint zftype:"..zftype.." r:"..r)

	return randlist
end

--返回需要开启log的列表
function formula:isLog(roleID)
	local loglist = {}
	--需要开启log 添加在该列表就行
	--loglist["114"] = 1	
	loglist["1"] = 1	
	loglist["2"] = 1	
	loglist["3"] = 1	
	loglist["4"] = 1	
	loglist["5"] = 1
	loglist["6"] = 1	
	loglist["7"] = 1	
	loglist["8"] = 1	
	loglist["9"] = 1	
	loglist["10"] = 1	
	loglist["6001"] = 1
	loglist["8002"] = 1
	loglist["8003"] = 1
	loglist["8004"] = 1
	loglist["8005"] = 1
	loglist["8006"] = 1
	loglist["2012"] = 1
	loglist["3002"] = 1
	loglist["3005"] = 1
	loglist['5002'] = 1


	loglist["537"] = 1
 	loglist["347"] = 1
 	loglist["764"] = 1
 	loglist["753"] = 1











	local ret = 0
	if roleID~=nil and loglist[""..roleID]~=nil  then
		ret = 1
	end

	if roleID~=nil then
		--debuglog("formula:isLog .. roleID:"..roleID.." ret:"..ret)
	end
	return ret
end

function formula:isDebugRoom(port)
	local roomPort = {}
	roomPort['3030'] = 1

	local ret = 0
	if roomPort[''..port]~=nil then
		ret = 1
	end
	return ret
end

return formula
