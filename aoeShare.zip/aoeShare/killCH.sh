#!/bin/bash

ps aux |grep 'main 284' |grep -v grep | awk '{print "kill "$2}'|sh
ps aux |grep 'main 285' |grep -v grep | awk '{print "kill "$2}'|sh

/var/aoe/MasterGame.sh
