#!/bin/bash

ps aux |grep 'main 23'|grep -v grep |grep "main" |awk '{print "kill "$2}' |sh
ps aux |grep 'main 24'|grep -v grep |grep "main" |awk '{print "kill "$2}' |sh
