#!/bin/bash


if [ "$1" != "" ];then
ps aux |grep 3000 |grep "main" |awk '{print "kill "$2}' |sh

sleep 1

/var/aoe/MasterGame.sh
else
/usr/bin/php /home/aoeShare/kill3000.php
fi
