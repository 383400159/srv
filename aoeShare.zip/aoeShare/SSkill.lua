local SSkill = class("SSkill")


function SSkill:ctor(data)

	self.skillID = 0
	--self.demonID = 0 --魔灵id
	self.roleID = 0   -- 对应英雄ID
	self.rank = 0   -- 技能顺序（1=普通攻击、2=第1主动技、3=第2主动技能、4=第3主动技能、5=必杀技A、6=必杀技B、7=反击技
	self.name = ""   -- 技能名称
	self.description = ""   -- 技能描述介绍

	--self.parameters = {}   -- 參數
	-- self.CDtimeArr = {}   -- 冷却时间
	-- self.CDtimeArrMin = {}   -- 冷却时间 Minimum

	self.mana = 0  -- 魔法消耗
	self.cdTime = 0 --冷却时间

	-- self.effect = 0   --
	self.allowStandByAttack = 0   -- 允許移動持續鎖敵
	
	
	-- self.level = 0
	self.buffParameter = {}
	self.lastCoolDownTime = 0
	self.lastCoolDownValue = 0



	self.type = 0   --	
	self.useDis = 0   -- 施法范围
	self.atkDis = 0   -- 攻击范围
	self.degree = 0   -- 攻击范围角度
	self.duration = 0
	self.duration2 = 0

	self.hurtThreatFixValue = 0 --伤害仇恨修正值（伤害仇恨值 = 伤害 * 修正值）
	self.healThreatFixValue = 0 --治疗仇恨修正值（治疗仇恨值 = 治疗 * 修正值）

	self.carom_step = 0
	self.carom_step_backward = ''
	self.delayCalTime = 0 --前摇时间

	self.attackMode = 0   -- 攻擊模式:1-近身範圍,2-目標敌人,3-遠程範圍,4-直線範圍,5-自身,6-被動技能,7-自身范围,8-目標队友,9-目標所有
	self.animationTime = 0   -- 動畫播放時間
	self.hitTime = 0   -- 出招時間
	self.hitTimeCS = 0 --客户端子弹出现时间
	self.bulletSpeed = 0   -- 子彈速度
	self.bulletTimeInterval = 0   --子彈間格時間
	self.bulletTimeInterval2 = 0
	self.callBackTimeIntervalList = {}
	self.numOfBullet = 0   -- 發出子彈數目
	self.allowCancel = 0   -- 允許取消
	self.allowMove = 0   -- 允許移動出招
	self.allowStop = 0   -- 允许被打断
	self.atkDisShowTime = 0 --【前端】攻击范围显示时间

	self.cutTime = 0
	self.allowSuperCancel=0

	self.moveToTarget = 0
	self.targetType = 0   -- 0=所有hero,1=敵方,2=敵方hero,3=自身,4=隊友hero,5＝所有隊友	
	self.maxEnemy = 0

	--carom 0=无连击;1=随机80%~110%;2=随机90%~120%;3=120%
	self.carom  = ''
	self.carom_interval = ''
	self.hitInterval = 0
	self.sendAttackCmd = false

	self.allowCancelList = {}

	self.lastCoolDownValue = self.cdTime

	self.demonObj = nil

	for k,v in pairs(data) do
		if k=="useDis_s" then
			self['useDis'] = v
		end

		if k=="callBackTimeInterval" then
			local t = string.splitNumber(v,",")
			v = t[1]
			if v>0 or #t>1 then
				self.callBackTimeIntervalList = t
			end
		end

		if self[k]~=nil then
			if(k=='useDis' and self[k]==0) or k~='useDis' then
				self[k] = v
			end
		end

		if k=="carom" then
			local caromlist = string.split(v,";")
			self[k]=caromlist
		end

		if k=="carom_step" then
			local carom_steplist = string.split(v,";")
			self[k]=carom_steplist
		end

		if k=="carom_interval" then
			local carom_interval = string.split(v,";")
			self[k]=carom_interval
		end

	end

	self.parameters = {}
	
end


function SSkill:createSkillValue()
	return {
		skillID = 0,
		duration = 0,
		atkDis = 0,
		degree = 0,
		attackMode = 0,
		bulletSpeed = 0,
		bulletTimeInterval = 0,
		numOfBullet = 0,
		allowCancel = 0,
		allowMove = 0,
		allowStop = 0,
		moveToTarget = 0,
		targetType = 0,
		maxEnemy = 0,
		hitInterval = 0,
		sendAttackCmd = false,
		allowCancelList = {},
	}
end

return SSkill
