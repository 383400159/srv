#!/bin/bash

ps aux |grep 'main 27' |grep -v grep |grep "main" |awk '{print "kill "$2}' |sh

ps aux |grep 'main 26'|grep -v grep |grep "main" |awk '{print "kill "$2}' |sh
ps aux |grep 'main 25'|grep -v grep |grep "main" |awk '{print "kill "$2}' |sh
