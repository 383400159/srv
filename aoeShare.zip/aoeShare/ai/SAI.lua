local SAI = class('SAI')

function SAI:ctor(obj)
	if self.className==nil then
		self.className="SAI"
	end 
	self.AImode = true --开启AI模式
	self.AIobj = obj
	self.world = obj.world
	self.worldNum = self.world.sSub(self.world.className,6)
	--绑定AI寄主
	self.itemID = obj.itemID
	self.condition = {}             --总条件列表
	self.selfCond = {}         --检测自己条件列表
	self.searchCond = {}       --检测场上目标条件列表
	self.teamCond = {}      --检测场上自己队友条件列表
	self.targetSort = {}            --最终同条件排序方式
	self.needTargetNum = {}         --需要符合目标总数
	self.canCastTime = {}           --最大可施放次数
	self.getTargetNum = 0           --流程判断后的目标总数
	self.targetList = {}            --检测条件时获得的目标列表
	self.noAutoPatrol = false					--不用巡逻 一般用于boss
	
	if self.AIobj.attribute.TYPEATK==1 then
		self.runAI = true               --控制AI是否运行
		debuglog("开启了AI roleId:"..self.AIobj.attribute.roleId)
	else
		self.runAI = false 
		debuglog("mei开启了AI roleId:"..self.AIobj.attribute.roleId)
	end
	if self.AIobj.attribute.parameterArr['NOMOVEAI']~=nil or self.AIobj.attribute.parameterArr['NOMOVE']~=nil then
		-- debuglog("fenglog 暂停移动AI",self.AIobj.itemID)
		self.NOMOVEAI = true
		self.runMoveAI = false 
	else
		self.NOMOVEAI = false
		self.runMoveAI = true               --控制AIMOVE是否运行
	end
	self.forceLost = false
	self.AISKillUseList = {}        --AI技能使用列表有CDtime useNum
	--self.world.posTargetList = {} 				--缓存AI位置上所拥有的目标 单个循环才用 减少相同位置的AI 使用量
	-- if worldForHero~=3 then
	-- 	self.grid = 8 									--野外 统计格大小  用于缓存AI目标
	-- 	self.AICDTime = 1								--AI间隔
	-- else
	-- 	self.grid = 1 									--boss房 统计格大小  用于缓存AI目标
	-- 	self.AICDTime = 0.5							--AI间隔
	-- 	self.runAI = true  
	-- end
	if self.world.gameRoomSetting.ISGVB==1 then
		self.grid = 8 									--野外 统计格大小  用于缓存AI目标
		self.AICDTime = 1								--AI间隔
	else
		self.grid = 1 									--boss房 统计格大小  用于缓存AI目标
		self.AICDTime = 0.5							--AI间隔
	end
	self.grid = 1 									--boss房 统计格大小  用于缓存AI目标
	self.AICDTime = 0.5							--AI间隔
	-- self.runAI = true  
	--下一个AI移动的坐标
	self.nextPosX=self.world.formula:getRandnum(-5,5)
	self.nextPosY=self.world.formula:getRandnum(-5,5)
	--滚雷的撞墙次数
	self.ROLLDESTROYTIME=0

	self:__load()
end


 --迭代器
function SAI:pairsByKeys(t)      
    local a = {}      
    for n in pairs(t) do          
        a[#a+1] = n      
    end      
    table.sort(a)      
    local i = 0      
    return function()          
    i = i + 1          
    return a[i], t[a[i]]      
    end  
end

---执行AI操作
--return targetID,skillID
function SAI:execute()

	--清空目标列表
	self.needTargetNum = {}

	self.AIobj:D("fenglog fenglog SAI itemID:",self.AIobj.itemID," :execute itemID:",self.itemID)

	local targetID = 0
	local skillID = 1
	local cdTime = self.AICDTime
	--self.AIobj = self.world.allItemList[self.itemID]
	--满足条件即跳出
	if self.AIobj.prepareSkillAttackNum~=0 then
		self.AIobj:D('fenglog SAI:excute one',self.AIobj.prepareSkillAttackNum)
		
		return targetID,skillID,cdTime 
	end

	if self.condition[self.world.partType]==nil then
		self.AIobj:D("fenglog fenglog SAI itemID:",self.AIobj.itemID,"roleID",self.AIobj.attribute.roleId,"  DB没数据..........",self.world.partType)
		return targetID,skillID,cdTime
	end

	local ok  = true
	local AISKillUseList = self.AISKillUseList[self.world.partType]~=nil and self.AISKillUseList[self.world.partType] or {}
	--self.AIobj:D("fenglog fenglog SAI===== itemID:"..self.AIobj.itemID.."  condition  :"..self.world.cjson.encode(self.condition))
	-- for k,v in pairs(self.condition[self.world.partType]) do
	-- 	self.AIobj:D("fenglog AI测试 k:"..k.." "..type(k))
	-- end
	-- for key, value in pairsByKeys(self.condition[self.world.partType]) do      
	-- 	   self.AIobj:D("fenglog AI测试 key:"..key.." "..type(key))
	-- end 
	--for k, v in pairsByKeys(self.condition[self.world.partType]) do  
	for key,v in pairs(self.condition[self.world.partType]) do
		k = v['priority']
		--self.AIobj:D("fenglog AI111测试 k:"..k)
		if self.AIobj.statusList~=nil then
			local tb = {}
			for k,v in pairs(self.AIobj.statusList) do
				tb[#tb+1]=k
			end
			local tbstr=implode(',',tb)
			self.AIobj:D("fenglog 策划 fenglog SAI===== 现有状态:",tbstr)
		else
			self.AIobj:D("fenglog 策划 fenglog SAI===== 状态列表:nil")
		end
		self.AIobj:D("fenglog 策划 fenglog SAI===== roleId:",self.AIobj.attribute.roleId," itemID:",self.AIobj.itemID,"  condition k:",k," v:",self.world.cjson.encode(v))
	 	
		if ok then
			local checkself = false

			--获得之前释放的数据
			--前置条件
			local start  = false
			if AISKillUseList[k]==nil or (AISKillUseList[k]~=nil and AISKillUseList[k]["nextTime"]<=self.world:getGameTime() and AISKillUseList[k]["useNum"]<v['canCastTime']) then
				start = true
			end  

			--self.AIobj:D("fenglog fenglog checkBOSS k:"..k.." HP:"..self.AIobj.attribute.HP)
			if AISKillUseList[k]~=nil then
				self.AIobj:D("fenglog 策划 fenglog checkBOSS k:",k," nextTime:",AISKillUseList[k]["nextTime"]," getGameTime:",self.world:getGameTime()," useNum:",AISKillUseList[k]["useNum"])
				-- self.AIobj:D("fenglog 策划 fenglog checkBOSS k:",k," getGameTime:",self.world:getGameTime())
				-- self.AIobj:D("fenglog 策划 fenglog checkBOSS k:",k," useNum:",AISKillUseList[k]["useNum"])
				
			end

			--第一层需要满足自己所需要的条件列表
			--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." :execute ")
			if start and self:checkSelfCondition(k) then
				self.AIobj:D("fenglog 策划 fenglog SAI itemID:",self.AIobj.itemID," :execute 第一层通过")
				checkself = true
			else
				self.AIobj:D("fenglog 策划 fenglog SAI itemID:",self.AIobj.itemID," :execute 第一层失败")
			end
			--self.AIobj:D("fenglog 策划 fenglog SAI itemID:",self.AIobj.itemID," :execute 第一层完结")
			self.AIobj:D("fenglog 策划 fenglog SAI itemID:",self.AIobj.itemID," :execute 第一层完结 第二层开始 队友层开始")

			if checkself then
				teamRet , teamList = self:checkSearch1Condition(k,v['teamRange'],v['needTeamNum'])
				if teamRet then
					checkself = true
					self.AIobj:D("fenglog 策划 fenglog SAI itemID:",self.AIobj.itemID," :execute 第二层开始 队友层开始 通过")
				else
					checkself = false
					self.AIobj:D("fenglog 策划 fenglog SAI itemID:",self.AIobj.itemID," :execute 第二层开始 队友层开始 未通过")
				end
			end
			-- if checkself and self:checkSearch1Condition(k,v['teamRange'],v['needTeamNum']) then
			-- 	checkself = true
			-- 	self.AIobj:D("fenglog 策划 fenglog SAI itemID:"..self.AIobj.itemID.." :execute 第二层开始 队友层开始 通过")
			-- else
			-- 	checkself = false
			-- 	self.AIobj:D("fenglog 策划 fenglog SAI itemID:"..self.AIobj.itemID.." :execute 第二层开始 队友层开始 未通过")
			-- end
			self.AIobj:D("fenglog 策划 fenglog SAI itemID:",self.AIobj.itemID," :execute 第二层开始 队友层结束")

			if checkself  then
				self.AIobj:D("fenglog 策划 fenglog SAI itemID:",self.AIobj.itemID," :execute 第二层 敌方层开始")
				self.needTargetNum[k] = self:checkSearchCondition(k,v['searchRange'])
			end
			
			--self.AIobj:D("fenglog 策划 fenglog SAI noBeFightBuffList:",self.world.cjson.encode(self.world.itemListFilter.noBeFightBuffList))
			
			self.AIobj:D("fenglog 策划 fenglog SAI itemID:",self.AIobj.itemID," :execute 第二层 敌方层完结 k：",k)
			if self.needTargetNum[k]~=nil and ((v['needTargetNum']>0 and #(self.needTargetNum[k])>=v['needTargetNum'] and #(self.needTargetNum[k])>0) or (v['needTargetNum']<0 and #(self.needTargetNum[k])<=-v['needTargetNum'])) then
				self.AIobj:D("fenglog 策划 fenglog SAI itemID:",self.AIobj.itemID," :execute 第三层开始 k：",k)
				
				if #(self.needTargetNum[k])==0 then
					targetID = self.AIobj.itemID
				else
					if v['targetType']==0 then
						targetID = self:sortTarget(self.needTargetNum[k],v['targetSort'],v['targetRange'])
					end
					if v['targetType']==1 then
						targetID = self:sortTarget(teamList,v['targetSort'],v['targetRange'])
					end
					if v['targetType']==2 then
						targetID = self.AIobj.itemID
					end
				end

				skillID = v['skillID']
				ok=false
				
				if self.AISKillUseList[self.world.partType]==nil then
					self.AISKillUseList[self.world.partType] = {}
				end
				if self.AISKillUseList[self.world.partType][k]==nil then
					self.AISKillUseList[self.world.partType][k] = {}
				end
				self.AIobj:D("fenglog 策划 fenglog SAI cd倍数:",self.AIobj.attribute.BOSSREDUCECD," 变化前:",v['cdTime'])
				self.AIobj:D("fenglog 策划 fenglog SAI cd倍数:",self.AIobj.attribute.BOSSREDUCECD," 变化后:",v['cdTime']*self.AIobj.attribute.BOSSREDUCECD)
				self.AISKillUseList[self.world.partType][k]["nextTime"] = self.world:getGameTime()+v['cdTime']*self.AIobj.attribute.BOSSREDUCECD
				self.AISKillUseList[self.world.partType][k]["useNum"] = (self.AISKillUseList[self.world.partType][k]["useNum"]~=nil and self.AISKillUseList[self.world.partType][k]["useNum"] or 0) + 1


				--阶段AI处理
				--self.stageList[self.world.partType][k]['runNum'] = self.world.mFloor(self.AISKillUseList[self.world.partType][k]["useNum"]/v['canCastTime'])

				if v['stage']~=nil and v['stage']~="" and table.nums(v['stage'])<7 then
					self.AIobj:D("fenglog lua error 多阶段参数不足 fenglog SAI priority:",k," stage:",self.world.cjson.encode(v))	
				end

				--阶段处理
				if v['stage']~=nil and v['stage']~="" and table.nums(v['stage'])>5 then			
					if self.AISKillUseList[self.world.partType][k]["useNum"]>=v['canCastTime'] then
						local list = v['stage']
						-- Fri Mar 18 12:08:36 2016	SAI stage:[""]
						-- Fri Mar 18 12:08:36 2016	SAI stage1:null

						-- for k,v in pairs(self) do
						-- 	self.AIobj:D("fenglog fenglog SAI stage k:"..k)
						-- end
						self.AIobj:D("fenglog fenglog SAI priority:",k," stage:",self.world.cjson.encode(list))
						if list[5]~=k then
							list[5]=k
							self.AIobj:D("fenglog 策划 fenglog checkBOSS  你个逗比优先级又错了.....................")
						end
						--修改原来的值
						--self.AIobj:D("fenglog fenglog SAI stage1:"..self.world.cjson.encode(self[list[3]]))

						-- for k,v in pairs(self[list[3]]) do
						-- 	self.AIobj:D("fenglog k:"..k.." v:"..self.world.cjson.encode(v))
						-- end
						--self.AIobj:D("fenglog fenglog SAI stage2:"..self.world.cjson.encode(self[list[3]][self.world.tonumber(list[4])]))
						self.AIobj:D("fenglog fenglog SAI stage3:",self.world.cjson.encode(self[list[3]][self.world.tonumber(list[4])][self.world.tonumber(list[5])]))
						self.AIobj:D("fenglog fenglog SAI stage31:",self.world.cjson.encode(self[list[3]][self.world.tonumber(list[4])][self.world.tonumber(list[5])][list[6]]))
						self.AIobj:D("fenglog fenglog SAI stage3: num1:",self.world.tonumber(self[list[3]][self.world.tonumber(list[4])][self.world.tonumber(list[5])][list[6]][list[7]][1])," num2:",self.world.tonumber(list[2])," num1:",self.world.tonumber(list[1]))
						if self.world.tonumber(self[list[3]][self.world.tonumber(list[4])][self.world.tonumber(list[5])][list[6]][list[7]][1]) + self.world.tonumber(list[2]) > self.world.tonumber(list[1]) then
							self[list[3]][self.world.tonumber(list[4])][self.world.tonumber(list[5])][list[6]][list[7]][1] = self.world.tonumber(self[list[3]][self.world.tonumber(list[4])][self.world.tonumber(list[5])][list[6]][list[7]][1]) + self.world.tonumber(list[2]) 
							self.AISKillUseList[self.world.partType][k]["useNum"]=0
							self.AIobj:D("fenglog fenglog SAI stage4 触发阶段处理.........")
						end
						
					end

				end

				local obj = self.world.allItemList[targetID]
				self.AIobj:D("fenglog 策划 fenglog checkBOSS k:",k," 目标HP:",obj.attribute.HP," 成功 SAI partType:",self.world.partType," 成功 SAI skillID:",skillID)

				-- self.AIobj:D("fenglog 策划 fenglog checkBOSS k:",k," 成功 SAI partType:",self.world.partType)
				-- self.AIobj:D("fenglog 策划 fenglog checkBOSS k:",k," 成功 SAI k:",k)
				-- self.AIobj:D("fenglog 策划 fenglog checkBOSS k:",k," 成功 SAI skillID:",skillID)
				--self.AIobj:D("fenglog fenglog checkBOSS k:"..k.." 成功 SAI nextTime:"..self.AISKillUseList[self.world.partType][k]["nextTime"])
				--self.AIobj:D("fenglog fenglog checkBOSS k:"..k.." 成功 SAI useNum:"..self.AISKillUseList[self.world.partType][k]["useNum"])
			end

		else
			self.AIobj:D("fenglog 策划 fenglog SAI  已经放了其他技能")
		end
		self.AIobj:D("fenglog 策划 fenglog SAI itemID:",self.AIobj.itemID," :execute 第三层完结")
	end

	--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.."  targetID:"..targetID)
	--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.."  itemID:"..self.AIobj.itemID.." 释放技能为:"..skillID)
	--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.."  cdTime:"..cdTime)

	return targetID,skillID,cdTime
end

-- ex : condition[roleID+part+priority][AND/OR/NOT] = {HP_LESS=100,MP_MORE=500}
--- 由数据库获取AI数据并保存到condition中
-- @param null
-- @return null
function SAI:__load()
	local sql = "select * from (select * from AI_condition where roleID='"..self.AIobj.attribute.roleId.."' and world='"..self.worldNum.."' and AIGroup in('0','"..self.world.gameRoomSetting['genAIGroup'].."') and block=0 union all select * from AI_condition_YW where roleID='"..self.AIobj.attribute.roleId.."' and world='"..self.worldNum.."' and AIGroup in('0','"..self.world.gameRoomSetting['genAIGroup'].."') and block=0) a order by roleID,part,priority,AIGroup desc"
	--local sql = "select * from AI_condition where roleID='"..self.AIobj.attribute.roleId.."' and world='"..self.worldNum.."' and AIGroup in('0','"..self.world.gameRoomSetting['genAIGroup'].."') and block=0 order by roleID,part,priority,AIGroup desc"
	local sql2 = "select * from AI_condition_YW where roleID='"..self.AIobj.attribute.roleId.."' and world='"..self.worldNum.."' and AIGroup='0' and block=0"
	local sql3 = "select * from AI_condition_DJ where roleID='"..self.AIobj.attribute.roleId.."' and world='"..self.worldNum.."' and AIGroup='0' and block=0"
	if self.world.gameRoomSetting.ISLOCAL==1 then
		sql = sql2
	end
	local data = self.world:getDBData(sql,sql2,sql3)
	if self.world.gameRoomSetting.ISLOCAL==1 and (data==nil or empty(data) or self.world.tNums(data)==0) then
		sql = sql3
		data = self.world:getDBData(sql)
	end
	local priority = 0
	for num,rowValue in pairs(data) do
		local goOn = true
		if self.condition[rowValue['part']]==nil then
			self.condition[rowValue['part']] = {}
		end
		priority = #self.condition[rowValue['part']]+1
		for ck,cv in pairs(self.condition[rowValue['part']]) do
			if self.condition[rowValue['part']][ck]['priority']==rowValue['priority'] then
				goOn = false
			end
		end
		if goOn then
			for k,v in pairs(rowValue) do
				if self.condition[rowValue['part']][priority]==nil then
					self.condition[rowValue['part']][priority] = {priority=rowValue['priority']}
				end
				if self.condition[rowValue['part']][priority][k]==nil then
					self.condition[rowValue['part']][priority][k] = {}
				end
				if k=='selfCondAnd' or k=='selfCondOr' or k=='selfCondNot' 
					or k=='searchCondAnd' or k=='searchCondOr' or k=='searchCondNot' 
					or k=='teamCondAnd' or k=='teamCondOr' or k=='teamCondNot' then
					local condMapKey = ''
					local condHeadKey = ''
					if self.world.sSub(k,1,4)=='self' or self.world.sSub(k,1,4)=='team' then
						condMapKey = self.world.sSub(k,9)
						condHeadKey = self.world.sSub(k,1,8)
					-- elseif self.world.sSub(k,-1)=='1' then
					-- 	condMapKey = self.world.sSub(k,11,-2)
					-- 	condHeadKey = self.world.sSub(k,1,10)..'1'
					else
						condMapKey = self.world.sSub(k,11)
						condHeadKey = self.world.sSub(k,1,10)
					end
					--self.world:self.AIobj:D(' jaylog condHeadKey:',condHeadKey,' condMapKey:',condMapKey,' value:',v)
					--local condTable = {}
					--if v~='' then
						local condTable = string.split(v,';')
					--end
					-- init
					if self[condHeadKey][rowValue['part']]==nil then
						self[condHeadKey][rowValue['part']] = {}
					end
					if self[condHeadKey][rowValue['part']][rowValue['priority']]==nil then
						self[condHeadKey][rowValue['part']][rowValue['priority']] = {}
					end
					if self[condHeadKey][rowValue['part']][rowValue['priority']][condMapKey]==nil or self[condHeadKey][rowValue['part']][rowValue['priority']][condMapKey]~=nil then
						self[condHeadKey][rowValue['part']][rowValue['priority']][condMapKey] = {}
					end
					for key,value in pairs(condTable) do
						local param = string.split(value,'=')
						
						-- set value
						if self.condition[rowValue['part']][priority][k][param[1]]==nil then
							self.condition[rowValue['part']][priority][k][param[1]] = {}
						end
						if self[condHeadKey][rowValue['part']][rowValue['priority']][condMapKey][param[1]]==nil then
							self[condHeadKey][rowValue['part']][rowValue['priority']][condMapKey][param[1]] = {}
						end
						--if (rowValue['roleID']..rowValue['part'])==(self.AIobj.attribute.roleId..self.world.partType) then
							if param[1]=="OTHER_POSXYR" or self.world.sFind(param[1],"SELFNUM") or self.world.sFind(param[1],"ALLSTATUS") then
								--self.AIobj:D(' jaylog load data condHeadKey:'..condHeadKey..' condMapKey:'..condMapKey..' param2:'..param[2]..' param1:'..param[1])
								local str = string.split(param[2],'|')
								local len = 0
								for strK,strV in pairs(str) do
									len = #self[condHeadKey][rowValue['part']][rowValue['priority']][condMapKey][param[1]]
									self.condition[rowValue['part']][priority][k][param[1]][len+1] = string.splitNumber(strV,',')
									self[condHeadKey][rowValue['part']][rowValue['priority']][condMapKey][param[1]][len+1] = string.splitNumber(strV,',')
								end
								-- if self.world.sFind(param[1],"ALLSTATUS") then
								-- 	--self.AIobj:D(' jaylog SAI:__load ALLSTATUS:'..self.world.cjson.encode(self[condHeadKey][rowValue['part']][""..rowValue['priority']][condMapKey][param[1]]))
								-- end
							else
								--self.AIobj:D(' jaylog load data condHeadKey:'..condHeadKey..' condMapKey:'..condMapKey..' value:'..value)--..' param2:'..param[2]..' param1:'..param[1])
								self.condition[rowValue['part']][priority][k][param[1]] = string.splitNumber(param[2],',')
								self[condHeadKey][rowValue['part']][rowValue['priority']][condMapKey][param[1]] = string.splitNumber(param[2],',')
							end
						--end
					end
				else
					-- targetSort
					if k=='targetSort' or k=='stage' then
						if self.targetSort[rowValue['part']]==nil then
							self.targetSort[rowValue['part']] = {}
						end
						if self.targetSort[rowValue['part']][rowValue['priority']]==nil then
							self.targetSort[rowValue['part']][rowValue['priority']] = {}
						end
						if (rowValue['roleID']..rowValue['part'])==(self.AIobj.attribute.roleId..self.world.partType) then
							self.targetSort[rowValue['part']][rowValue['priority']] = string.split(v,',')
						end
						self.condition[rowValue['part']][priority][k] = string.split(v,',')
					else
						if (rowValue['roleID']..rowValue['part'])==(self.AIobj.attribute.roleId..self.world.partType) then
							if self[k]~=nil then
								if self[k][rowValue['part']]==nil then
									self[k][rowValue['part']] = {}
								end
								self[k][rowValue['part']][rowValue['priority']] = v
							end
						end
						self.condition[rowValue['part']][priority][k] = v
					end
				end
			end
		end
		--self.world:self.AIobj:D(' jaylog SAI:__load ',self.AIobj.attribute.roleId,self.worldNum,self.world.gameRoomSetting['genAIGroup'],' selfCond:',self.world.cjson.encode(self.selfCond),' searchCond:',self.world.cjson.encode(self.searchCond),' teamCond:',self.world.cjson.encode(self.teamCond))
	end
	--self.world:self.AIobj:D(' jaylog SAI:__load ',self.world.cjson.encode(self.condition),' sql:',sql)
	--self.world:self.AIobj:D(' jaylog SAI:__load selfCond:',self.world.cjson.encode(self.selfCond),' searchCond:',self.world.cjson.encode(self.searchCond),' teamCond:',self.world.cjson.encode(self.teamCond))
	--self.AIobj:D(' jaylog AI load condition:'..self.world.cjson.encode(self.condition[1])..' self:'..self.world.cjson.encode(self.selfCond[1]))
end


function SAI:checkCondition(obj,p,cond)
		-- for k,v in pairs(cond) do		
		-- 		-- cond[k]["1"]["Not"]={}
		-- 		-- cond[k]["1"]["Not"][""]={}
		-- 		-- cond[k]["1"]["Or"]={}
		-- 		-- cond[k]["1"]["Or"][""]={}
		-- 		-- cond[k]["1"]["And"]={}
		-- 		-- cond[k]["1"]["And"][""]={}
		--   self.AIobj:D("fenglog SAI itemID:"..self.AIobj.itemID.." :checkCondition Value:"..self.world.cjson.encode(v)..' key:'..k)
		-- end
		--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." :checkCondition:"..self.world.cjson.encode(cond))
		if obj==nil then
			--排除掉由于时间差导致的obj为nil
			return false
		end
		local checkstate = false
		local checkstate1 = false
		local checkstate2 = false
		local checkstate3 = false


		--需要优化
		local checktype = "And"
		if cond[obj.world.partType]~=nil and cond[obj.world.partType][p]~=nil and cond[obj.world.partType][p][checktype]~=nil then
			local condition = cond[obj.world.partType][p][checktype]
			local checkNum = 1
			self.AIobj:D("fenglog 策划 fenglog SAI itemID:",self.AIobj.itemID," :And condition:",self.world.cjson.encode(condition))
			for k,v in pairs(condition) do
				--多个同类型参数用table装起来
				for key,value in pairs(v) do
					checkNum = checkNum * self:check(obj,k,value)
					if checkNum==0 then
						self.AIobj:D("fenglog 策划 fenglog SAI and失败",k)
					end
					--达成条件提前断掉
					if checkNum==0 then
						break
					end

				end
			end
			self.AIobj:D("fenglog fenglog SAI itemID:",self.AIobj.itemID," and checkNum",checkNum)
			if checkNum>0 then
				checkstate1 = true
			end
		end

		if checkstate1==false then
			return checkstate1
		end

		local checktype = "Or"
		if cond[obj.world.partType]~=nil and cond[obj.world.partType][p]~=nil and cond[obj.world.partType][p][checktype]~=nil then
			local condition = cond[obj.world.partType][p][checktype]
			local checkNum = 1
			self.AIobj:D("fenglog 策划 fenglog SAI itemID:",self.AIobj.itemID," :OR condition:",self.world.cjson.encode(condition))
			for k,v in pairs(condition) do
				for key,value in pairs(v) do
					local retOr = self:check(obj,k,value)
					if retOr==0 then
						retOr = -1
					end
					if retOr==1 then
						retOr = 10
					end
					checkNum = checkNum + retOr
					if checkNum>0 then
						self.AIobj:D("fenglog 策划 fenglog SAI or失败",k)
					end
					--达成条件提前断掉
					if checkNum>0 then
						break
					end
					
				end
			end
			self.AIobj:D("fenglog SAI itemID:",self.AIobj.itemID," or checkNum",checkNum)
			if checkNum>=1 then
				checkstate2 = true
			end
		end

		if checkstate2==false then
			return checkstate2
		end

		local checktype = "Not"
		if cond[obj.world.partType]~=nil and cond[obj.world.partType][p]~=nil and cond[obj.world.partType][p][checktype]~=nil then
			local condition = cond[obj.world.partType][p][checktype]
			local checkNum = 0
			self.AIobj:D("fenglog 策划 fenglog SAI itemID:",self.AIobj.itemID," :NOT condition:",self.world.cjson.encode(condition))
			for k,v in pairs(condition) do
				for key,value in pairs(v) do
						checkNum = checkNum + self:check(obj,k,value)
				end 
				if checkNum>0 then
						self.AIobj:D("fenglog 策划 fenglog SAI not失败",k)
				end
				-- --达成条件提前断掉
				if checkNum>0 then
					break
				end

			end
			self.AIobj:D("fenglog 策划 fenglog SAI itemID:",self.AIobj.itemID," Not checkNum",checkNum)
			if checkNum<=0 then
				checkstate3 = true
			end
		end

		if checkstate3==false then
			return checkstate3
		end

		if checkstate1 and checkstate2 and checkstate3 then
			checkstate = true
			--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." :checkCondition 条件通过")
		end

		return checkstate
end

function SAI:check(obj,k,v)
	--self.AIobj:D("fenglog SAI itemID:"..self.AIobj.itemID.." :check")
	local ret = 0
	if self.world.sFind(k,"OTHER")~=nil then
		--检测状态 
		if self.world.sFind(k,"STATUS")~=nil then
			ret=self:checkSTATUS(obj,k,v)
		end
		--检测某一边的状态 
		if self.world.sFind(k,"ALLSTATUS")~=nil then
			ret=self:checkALLSTATUS(obj,k,v)
		end
		--检测游戏时间
		if self.world.sFind(k,"GAMETIME")~=nil then
			ret=self:checkGAMETIME(obj,k,v)
		end
		--检测游戏时间
		if self.world.sFind(k,"BOSSGAMETIME")~=nil then
			ret=self:checkBOSSGAMETIME(obj,k,v)
		end

		--self.AIobj:D("fenglog SAI k:"..k)
		--检测自己同类型
		if self.world.sFind(k,"SELFNUM")~=nil then
			ret=self:checkSELFNUM(obj,k,v)
		end
		if self.world.sFind(k,"ALLSELFNUM")~=nil then
			ret=self:checkAllSELFNUM(obj,k,v)
		end
		--检测某个坐标的范围内合适的目标数量
		if self.world.sFind(k,"POSXYR")~=nil then
			ret=self:checkPOSXYR(obj,k,v)
		end
		--检查boss现在有没有被嘲讽
		if self.world.sFind(k,"BOSSBEMOCK")~=nil then
			ret=self:checkBOSSBEMOCK(obj,k,v)
		end
		-- --BOSS自身x范围内敌人数量等于此值
		-- if self.world.sFind(k,"NUMINSIDE") then
		-- 	ret=self:checkNUMINSIDE(obj,k,v)
		-- end
		-- --BOSS自身x范围外敌人数量等于此值
		-- if self.world.sFind(k,"NUMOUTSIDE") then
		-- 	ret=self:checkNUMOUTSIDE(obj,k,v)
		-- end

	else
			ret=self:checkAttribute(obj,k,v)
	end

	return ret
end

function SAI:checkBOSSBEMOCK(obj,key,statusID)
	if self.AIobj.attribute.actorType==2 and #self.AIobj.BossHatredlist>0 then
		self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." 被嘲讽")
		return 1
	end
	return 0
end


function SAI:checkNUMINSIDE(obj,key,table)
	local list = string.split(key,'_')
	local ret = 0

	--local enemy = self.AIobj:getEnemylist()
	--此处预留给skill;视野范围
	local visRange={posX=self.AIobj.posX,posY=self.AIobj.posY,radius=table[1]/self.world.setting.AdjustVisRange}
	--范围内
	local targetList = self:__findTarget(1,visRange)

	local compareNum = #targetList
	if list[3]=='LESS' then
		if compareNum<=table[2] then
			ret = 1
		end
	end
	if list[3]=='MORE' then
		if compareNum>=table[2] then
			ret = 1
		end
	end

	return ret
end

function SAI:checkNUMOUTSIDE(obj,key,table)
	local list = string.split(key,'_')
	local ret = 0

	--local enemy = self.AIobj:getEnemylist()
	--此处预留给skill;视野范围
	local visRange={posX=self.AIobj.posX,posY=self.AIobj.posY,radius=table[1]/self.world.setting.AdjustVisRange}
	--范围外
	local targetList = self:__findTarget(1,visRange,true)

	local compareNum = #targetList
	if list[3]=='LESS' then
		if compareNum<=table[2] then
			ret = 1
		end
	end
	if list[3]=='MORE' then
		if compareNum>=table[2] then
			ret = 1
		end
	end

	return ret
end

function SAI:checkSTATUS(obj,key,statusID)
	--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." :checkSTATUS:.."..statusID)
	if obj.statusList[statusID]~=nil then
		self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." :checkSTATUS:.."..statusID.."存在............")
		return 1
	end
	--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." :checkSTATUS:.."..statusID.."不存在............")
	return 0
end

function SAI:checkALLSTATUS(obj,key,table)
	--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." key:"..key.." :checkALLSTATUS:.."..self.world.cjson.encode(table))

	local list = string.split(key,'_')
	local ret = 0
	local compareNum = 0

	for k,v in pairs(self.world.allItemList) do
		--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." v.attribute.roleId:"..v.attribute.roleId.." type:"..type(v.attribute.roleId).." table[1]:"..table[1].." type:"..type(table[1]))
		if not v:isDead() and obj.teamOrig==v.teamOrig and v.statusList[table[1]]~=nil then
			compareNum = compareNum + 1
			--self.AIobj:D("fenglog fenglog SAI  checkALLSTATUS itemID:"..self.AIobj.itemID.." compareNum+:"..compareNum)
		end  
	end
	if list[3]=='LESS' then
		if compareNum<=table[2] then
			ret = 1
		end
	end
	if list[3]=='MORE' then
		if compareNum>=table[2] then
			ret = 1
		end
	end
	self.AIobj:D("fenglog fenglog SAI  checkALLSTATUS itemID:"..self.AIobj.itemID.." :compareNum:.."..compareNum.." num:"..table[2])
	return ret

end

function SAI:checkGAMETIME(obj,key,GAMETIME)
	--self.AIobj:D("fenglog SAI itemID:"..self.AIobj.itemID.." :checkGAMETIME:.."..GAMETIME)
	local list = string.split(key,'_')
	local ret = 0
	if self.world.gameRemainStartTime==0 then
		return ret
	end
	local compareNum = self.world:getGameTime() - self.world.gameRemainStartTime
	if list[3]=='LESS' then
		if compareNum<=GAMETIME then
			ret = 1
		end
	end
	if list[3]=='MORE' then
		if compareNum>=GAMETIME then
			ret = 1
		end
	end
	--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.."  游戏时间:"..compareNum.." 须比较的时间:"..GAMETIME)
	return ret
end

function SAI:checkBOSSGAMETIME(obj,key,GAMETIME)
	--self.AIobj:D("fenglog SAI itemID:"..self.AIobj.itemID.." :checkGAMETIME:.."..GAMETIME)
	local list = string.split(key,'_')
	local ret = 0
	if self.AIobj.startHurtTime==0 then
		return ret
	end
	local compareNum = self.world:getGameTime() - self.AIobj.startHurtTime
	if list[3]=='LESS' then
		if compareNum<=GAMETIME then
			ret = 1
		end
	end
	if list[3]=='MORE' then
		if compareNum>=GAMETIME then
			ret = 1
		end
	end
	--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.."  游戏时间:"..compareNum.." 须比较的时间:"..GAMETIME)
	return ret
end

function SAI:checkSELFNUM(obj,key,table)
	--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." :checkSELFNUM:.."..self.world.cjson.encode(table))
	local list = string.split(key,'_')
	local ret = 0
	local compareNum = 0

	--需要优化 local tmp = tostring(table[1])
	local tmp = table[1]
	for k,v in pairs(self.world.allItemList) do
		--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." v.attribute.roleId:"..v.attribute.roleId.." type:"..type(v.attribute.roleId).." table[1]:"..table[1].." type:"..type(table[1]))
		if not v:isDead() and self.world.tonumber(v.attribute.roleId)==tmp then
			compareNum = compareNum + 1
			--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." compareNum+:"..compareNum)
		end  
	end
	if list[3]=='LESS' then
		if compareNum<=table[2] then
			ret = 1
		end
	end
	if list[3]=='MORE' then
		if compareNum>=table[2] then
			ret = 1
		end
	end
	--self.AIobj:D("fenglog 策划 checkSELFNUM fenglog SAI itemID:"..self.AIobj.itemID.." roleId:"..table[1].." :compareNum:.."..compareNum.." num:"..table[2])
	return ret

end

function SAI:checkAllSELFNUM(obj,key,table)
	--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." :checkSELFNUM:.."..self.world.cjson.encode(table))
	local list = string.split(key,'_')
	local ret = 0
	local compareNum = 0

	--需要优化 local tmp = tonumber(table[1])
	local tmp = table[1]
	for k,v in pairs(self.world.allItemList) do
		--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." v.attribute.roleId:"..v.attribute.roleId.." type:"..type(v.attribute.roleId).." table[1]:"..table[1].." type:"..type(table[1]))
		if  self.world.tonumber(v.attribute.roleId)==tmp then
			compareNum = compareNum + 1
			--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." compareNum+:"..compareNum)
		end  
	end
	if list[3]=='LESS' then
		if compareNum<=table[2] then
			ret = 1
		end
	end
	if list[3]=='MORE' then
		if compareNum>=table[2] then
			ret = 1
		end
	end
	--self.AIobj:D("fenglog 策划 checkAllSELFNUM fenglog SAI itemID:"..self.AIobj.itemID.." :compareNum:.."..compareNum.." num:"..table[2])
	return ret

end

--检测坐标范围内是否有检测的目标
function SAI:checkPOSXYR(obj,key,table)
	local d=self.world.map:distance(table[1],table[2],obj.posX,obj.posY) 
	local ret=0
	--self.AIobj:D("fenglog d:"..d.." 目标:"..obj.itemID)
	if d<=table[3] then
		ret=1
	end
	return ret
end

function SAI:checkAttribute(obj,key,num)
	--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." :checkAttribute key:"..key.." num:"..num)
	local list = string.split(key,'_')
	local ret = 0
	local compareNum = 0
	--定值
	--if list[2]=='FIX' then
	if  self.world.sFind(list[2],"FIX")  then
		compareNum = obj.attribute[list[1]]
		if self.world.sFind(list[1],"roleId") then
			--self.AIobj:D("fenglog 策划 SAI fenglog compareNum:"..compareNum.." num:"..num.." roleId:"..obj.attribute.roleId)
		end
	end 

	--百分比
	if list[2]=='RATE' then
		compareNum = obj.attribute[list[1]]/obj.attribute["Max"..list[1]]
		num = num * 0.01
		--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.."  RETE: compareNum:"..compareNum.." num:"..num)
	end
	
	--等于
	if list[3]~='LESS' and list[3]~='MORE' then
		if  self.world.tonumber(compareNum)==self.world.tonumber(num) then
			ret = 1
		end
	end
	if list[3]=='LESS' then
		if compareNum<=num then
			ret = 1
		end
	end
	if list[3]=='MORE' then
		if compareNum>=num then
			ret = 1
		end
	end


	return ret
end

--寻找敌方目标列表
function SAI:__findEnemyTarget(vis,p) 

		--enemy=self.AIobj:getEnemylist()
		--此处预留给skill;视野范围
		local visRange={posX=self.AIobj.posX,posY=self.AIobj.posY,radius=vis/self.world.setting.AdjustVisRange}
		--local attRange=self.AIobj:getAttRange()
		local targetList = self:__findTarget(1,visRange,false)
		--self.AIobj:D("fenglog 可攻击的目标有:"..self.world.cjson.encode(targetList))
		return targetList
end

function SAI:__findTeammateTarget(vis,p)
		--local enemy=self.AIobj:getTeammatelist(true)
		--此处预留给skill;视野范围
		local visRange={posX=self.AIobj.posX,posY=self.AIobj.posY,radius=vis/self.world.setting.AdjustVisRange}
		--local attRange=self.AIobj:getAttRange()
		--local targetList = self:__findTarget(enemy,visRange,false,true)
		local targetList = self:__findTarget(11,visRange,false,true)
		return targetList
end

function SAI:__findTarget(targetType,visRange,n,isTeammate)
		--n is true 用来表示范围外
		if n==nil then
			n = false
		end
		if isTeammate==nil then
			isTeammate = false
		end
		--visRange['estimate']=true
		local targetList = {}
		local cacheID = self.world.mCeil(self.AIobj.posX/self.grid).."-"..self.world.mCeil(self.AIobj.posY/self.grid).."_"..(n==true and "true" or "false").."_"..self.AIobj.attribute.actorType.."_"..visRange.radius

		--获得缓存的目标
		if self.world.className=="World5" and self.world.posTargetList[cacheID]~=nil and (self.world.posTargetList[cacheID]['cacheTime']+self.AICDTime)>self.world.gameTime then
			targetList = self.world.posTargetList[cacheID]['targetList']
			--self.AIobj:D("fenglog SAI cacheID:"..cacheID.." targetList:"..self.world.cjson.encode(targetList).." itemID:"..self.AIobj.itemID)
			return targetList
		else
			--self.AIobj:D("fenglog SAI NO cacheID:"..cacheID)
			self.world.posTargetList[cacheID] = {}
		end
		
		local ok = true
		local enemy = self.world:runTargetTypeFilter(targetType,self.AIobj.team,self.AIobj.itemID,{},
		function(value)
		 	ok = true
			if (value:isDead()) then ok =false end
			if (value.itemID==self.AIobj.itemID) then ok =false end
			if (value.statusList[76]~=nil ) then ok = false end
			if (value.statusList[603]~=nil ) then ok = false end
			if (self.AIobj.attribute.TYPEATK==1 and value.statusList[602]~=nil ) then ok = false end
			if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil and (not isTeammate or (isTeammate and value.attribute.parameterArr['NOBEFIGHT_FORAI']==nil))) then ok = false end
			if ok then
				local d = value:colliding(visRange,0,0,self.AIobj.itemID)
				--self.AIobj:D("fenglog fenglog checkBOSS  d:"..d.." 目标:"..value.itemID)
				--—未实装—【排序】角色优先级排序，roleSort=roleID,sortTure,sortFalse，这种roleID的优先攻，如果有相同则根绝sortTrue来排序，如果没有该ID，则按sortFalse来排序所有
				local minR=0
				if self.AIobj.attribute.parameterArr['MINIATKRANGE']~=nil then
					minR = self.AIobj.attribute.parameterArr['MINIATKRANGE']/self.world.setting.AdjustVisRange
					self.AIobj:D("764 MINIATKRANGE:",self.AIobj.attribute.parameterArr['MINIATKRANGE'],minR)
				end
				if d>=0 and d>=minR and n==false then
					targetList[#targetList+1] = {itemID=value.itemID,DIS=d,HP=value.attribute.HP,roleID=self.world.tonumber(value.attribute.roleId)}
				end
				if d==-1 and n then
					targetList[#targetList+1] = {itemID=value.itemID,DIS=d,HP=value.attribute.HP,roleID=self.world.tonumber(value.attribute.roleId)}
				end

			end
		end
		)


		-- local ok = true
		-- for k,value in pairs(enemylist) do
		-- 	ok = true
		-- 	if (value:isDead()) then ok =false end
		-- 	if (value.itemID==self.AIobj.itemID) then ok =false end
		-- 	if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil and (not isTeammate or (isTeammate and value.attribute.parameterArr['NOBEFIGHT_FORAI']==nil))) then ok = false end
		-- 	if ok then
		-- 		local d = value:colliding(visRange,0,0,self.AIobj.itemID)
		-- 		--self.AIobj:D("fenglog fenglog checkBOSS  d:"..d.." 目标:"..value.itemID)
		-- 		--—未实装—【排序】角色优先级排序，roleSort=roleID,sortTure,sortFalse，这种roleID的优先攻，如果有相同则根绝sortTrue来排序，如果没有该ID，则按sortFalse来排序所有
		-- 		if d>=0 and n==false then
		-- 			targetList[#targetList+1] = {itemID=value.itemID,DIS=d,HP=value.attribute.HP,roleID=value.attribute.roleId}
		-- 		end
		-- 		if d==-1 and n then
		-- 			targetList[#targetList+1] = {itemID=value.itemID,DIS=d,HP=value.attribute.HP,roleID=value.attribute.roleId}
		-- 		end

		-- 	end
		-- end


		--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." __findTarget 可选择的敌方目标有:"..self.world.cjson.encode(targetList))

		--缓存目标
		if self.world.posTargetList[cacheID]==nil then
			self.world.posTargetList[cacheID] = {}
		end
		self.world.posTargetList[cacheID]['cacheTime'] = self.world.gameTime
		self.world.posTargetList[cacheID]['targetList'] = targetList
		--self.AIobj:D("fenglog SAI newcacheID:"..cacheID.." targetList:"..self.world.cjson.encode(targetList).." itemID:"..self.AIobj.itemID)


		return targetList
end

-- function SAI:__findTarget(enemylist,visRange,n,isTeammate)
-- 		--n is true 用来表示范围外
-- 		if n==nil then
-- 			n = false
-- 		end
-- 		if isTeammate==nil then
-- 			isTeammate = false
-- 		end
-- 		--visRange['estimate']=true
-- 		local targetList = {}
-- 		local cacheID = self.world.mCeil(self.AIobj.posX/self.grid).."-"..self.world.mCeil(self.AIobj.posY/self.grid).."_"..(n==true and "true" or "false").."_"..self.AIobj.attribute.actorType.."_"..visRange.radius

-- 		--获得缓存的目标
-- 		if self.world.className=="World5" and self.world.posTargetList[cacheID]~=nil and (self.world.posTargetList[cacheID]['cacheTime']+self.AICDTime)>self.world.gameTime then
-- 			targetList = self.world.posTargetList[cacheID]['targetList']
-- 			--self.AIobj:D("fenglog SAI cacheID:"..cacheID.." targetList:"..self.world.cjson.encode(targetList).." itemID:"..self.AIobj.itemID)
-- 			return targetList
-- 		else
-- 			--self.AIobj:D("fenglog SAI NO cacheID:"..cacheID)
-- 			self.world.posTargetList[cacheID] = {}
-- 		end
		
-- 		local ok = true
-- 		for k,value in pairs(enemylist) do
-- 			ok = true
-- 			if (value:isDead()) then ok =false end
-- 			if (value.itemID==self.AIobj.itemID) then ok =false end
-- 			if (value.attribute.actorType==1 and value.attribute.parameterArr['NOBEFIGHT']~=nil and (not isTeammate or (isTeammate and value.attribute.parameterArr['NOBEFIGHT_FORAI']==nil))) then ok = false end
-- 			if ok then
-- 				local d = value:colliding(visRange,0,0,self.AIobj.itemID)
-- 				--self.AIobj:D("fenglog fenglog checkBOSS  d:"..d.." 目标:"..value.itemID)
-- 				--—未实装—【排序】角色优先级排序，roleSort=roleID,sortTure,sortFalse，这种roleID的优先攻，如果有相同则根绝sortTrue来排序，如果没有该ID，则按sortFalse来排序所有
-- 				if d>=0 and n==false then
-- 					targetList[#targetList+1] = {itemID=value.itemID,DIS=d,HP=value.attribute.HP,roleID=value.attribute.roleId}
-- 				end
-- 				if d==-1 and n then
-- 					targetList[#targetList+1] = {itemID=value.itemID,DIS=d,HP=value.attribute.HP,roleID=value.attribute.roleId}
-- 				end

-- 			end
-- 		end

		
-- 		--self.AIobj:D("fenglog fenglog SAI itemID:"..self.AIobj.itemID.." __findTarget 可选择的敌方目标有:"..self.world.cjson.encode(targetList))

-- 		--缓存目标
-- 		if self.world.posTargetList[cacheID]==nil then
-- 			self.world.posTargetList[cacheID] = {}
-- 		end
-- 		self.world.posTargetList[cacheID]['cacheTime'] = self.world.gameTime
-- 		self.world.posTargetList[cacheID]['targetList'] = targetList
-- 		--self.AIobj:D("fenglog SAI newcacheID:"..cacheID.." targetList:"..self.world.cjson.encode(targetList).." itemID:"..self.AIobj.itemID)


-- 		return targetList
-- end


-- 检测自身条件
-- @return boolean - true
function SAI:checkSelfCondition(p)
	self.AIobj:D("fenglog fenglog SAI 自己层计算 ")
	local checkstate=self:checkCondition(self.AIobj,p,self.selfCond)
	return checkstate
end


-- 检测场上敌对目标条件
-- @return boolean - true
function SAI:checkSearchCondition(p,vis)
	--self.AIobj:D("fenglog SAI itemID:"..self.AIobj.itemID.." :checkSearchCondition")
	local targetList = self:__findEnemyTarget(vis,p)
	--符合选择结果的list
	local retlist = {}
	--self.AIobj:D("fenglog SAI itemID:"..self.AIobj.itemID.." :checkSearchCondition targetList:"..self.world.cjson.encode(targetList))
	for k,v in pairs(targetList) do
		--self.AIobj:D("fenglog 需要加载ID 对手:"..v["itemID"])
		local obj = self.world.allItemList[v["itemID"]]
		local checkstate = self:checkCondition(obj,p,self.searchCond)
		if checkstate then
			--self.AIobj:D("fenglog 添加对手 对手:"..v["itemID"])
			retlist[#retlist+1] = targetList[k]
		end 
	end
	self.AIobj:D("fenglog  SAI itemID:"..self.AIobj.itemID.." :checkSearchCondition retlist:"..self.world.cjson.encode(retlist))
	return retlist
end

--- 检测场上同队目标条件
-- @param p table - 内部传参
-- @param vis table - 范围
-- @param needTeamNum int - 需要数量
-- @return null
function SAI:checkSearch1Condition(p,vis,needTeamNum)
	self.AIobj:D("fenglog fenglog 队友层计算 ")

	local targetList = self:__findTeammateTarget(vis,p)
	--符合选择结果的list
	local ret = false
	local retlist = {}
	for k,v in pairs(targetList) do
		local obj = self.world.allItemList[v["itemID"]]
		local checkstate = self:checkCondition(obj,p,self.teamCond)
		if checkstate then
			retlist[#retlist+1] = targetList[k]
		end 
	end
	--需符搜队友数目时才通过，负数为小于，正数为大于
	if #targetList>0 and ((needTeamNum>=0 and #(retlist)>=needTeamNum) or (needTeamNum<0 and #(retlist)<-needTeamNum) ) then
		ret = true
	end
	if #targetList==0 and needTeamNum==0 then
		ret = true
	end
	if needTeamNum==0 then
		ret = true
	end
	--self.AIobj:D("fenglog 策划 SAI itemID:"..self.AIobj.itemID.." targetList:"..self.world.cjson.encode(targetList).." :execute 第二层+队友层赛选结果为:"..self.world.cjson.encode(retlist))
	return ret,retlist
end

--- 相同玩家排序
-- @param sortlist table 需要排序的列表
-- @param targetSort table 排序方式
-- @param targetRange table 某些排序需要的范围
-- @return null
function SAI:sortTarget(sortlist,targetSort,targetRange)
	--self.AIobj:D("fenglog SAI itemID:"..self.AIobj.itemID.." :sortTarget")
	local list = string.split(v,'_')
	local newatklist = {}


	--self.AIobj:D("fenglog SAI itemID:"..self.AIobj.itemID.." :execute 第三层赛选结果为:"..self.world.cjson.encode(sortlist))
	--self.AIobj:D("fenglog SAI itemID:"..self.AIobj.itemID.." :execute 第三层BOSS仇恨列表:"..self.world.cjson.encode(self.AIobj.Hatredlist))

	for k,v in pairs(sortlist) do
		if self.AIobj.Hatredlist[""..v["itemID"]]~=nil then
			sortlist[k]["THREAT"] = self.AIobj.Hatredlist[""..v["itemID"]]
		else
			local obj = self.world.allItemList[v["itemID"]]
			sortlist[k]["THREAT"] = 0
			self.AIobj:D("狗头开始第一下 需要打矮子",self.AIobj.itemID,obj.attribute.roleId)
			if obj~=nil and  obj.attribute~=nil and obj.attribute.roleId%5==2 and self.AIobj.attribute.actorType==2  then
				sortlist[k]["THREAT"] = 1
				self.AIobj.Hatredlist[""..v["itemID"]]=1
			end
		end
	end

	--添加对boss的伤害仇恨 TOTALHURT
	local obj = self.world.allItemList[sortlist[1]["itemID"]]
	local enemylist = obj:getEnemylist()
	local boslllist = {}
	for k,v in pairs(enemylist) do
		if not v:isDead() and v.attribute.actorType==2 then
			boslllist[#boslllist+1] = v
		end
	end

	for k,v in pairs(sortlist) do
		for key,value in pairs(boslllist) do
			if value.Hatredlist[""..v["itemID"]]~=nil then
				sortlist[k]["TOTALHURT"] = (sortlist[k]["TOTALHURT"]~=nil and sortlist[k]["TOTALHURT"] or 0) + value.Hatredlist[""..v["itemID"]]
			else
				sortlist[k]["TOTALHURT"] = 0
			end
		end
	end

	--NUMINSIDE_500_DECREASE,
	--计算目标范围内的玩家
	if targetRange>0 then
		for k,v in pairs(sortlist) do
			local obj = self.world.allItemList[v["itemID"]]
			--local enemy=obj:getTeammatelist()
			--此处预留给skill;视野范围
			local visRange={posX=obj.posX,posY=obj.posY,radius=targetRange/self.world.setting.AdjustVisRange}
			--local attRange=self.AIobj:getAttRange()
			local targetList = self:__findTarget(5,visRange)
			if #targetList>0 then
				sortlist[k]["NUMINSIDE"] = #targetList
			else
				sortlist[k]["NUMINSIDE"] = 0
			end
			self.AIobj:D("fenglog SAI itemID:"..self.AIobj.itemID.." 身边的友方数量为:"..sortlist[k]["NUMINSIDE"])
		end

	end
	self.AIobj:D("fenglog SAI itemID:"..self.AIobj.itemID.." :execute 第三层赛选结果+仇恨值为:"..self.world.cjson.encode(sortlist))

	for k,v in pairs(targetSort) do
		local list = string.split(v,"_")

		--按着所需ID排序
		if self.world.sFind(v,"ROLESORT")~=nil then
			 local sortkeylist=string.split(v,'=')
			 local roleSortlist = string.split(roleSortlist,',')
			-- self.AIobj:D("fenglog ROLESORT 排序之前: sortlist:"..self.world.cjson.encode(sortlist))
			 self.world.tSort(sortlist,function( a1,b1 )
					return (a1['roleID']==sortkeylist[2] and 1 or 0) > (a1['roleID']==sortkeylist[2] and 1 or 0)
				end)
			 --self.AIobj:D("fenglog ROLESORT 排序之后: sortlist:"..self.world.cjson.encode(sortlist))
		end

		if self.world.sFind(v,"DECREASE")~=nil  then
			--self.AIobj:D("fenglog SAI itemID:"..self.AIobj.itemID.."  "..list[1].."从大到小")
				self.world.tSort(sortlist,function( a1,b1 )
					return a1[list[1]] > b1[list[1]]
				end)
		end 
		if self.world.sFind(v,"INCREASE")~=nil then
			--self.AIobj:D("fenglog SAI itemID:"..self.AIobj.itemID.."  "..list[1].."从小到大")
				self.world.tSort(sortlist,function( a1,b1 )
					return a1[list[1]] < b1[list[1]]
				end)
		end 

		--全随即模式
		if v=='RANDOM' then
			sortlist=table.shuffle(sortlist)
		end

		

	end

	local targetID = sortlist[1]["itemID"]
	--假如是boss 而且正在被嘲讽中 则强制切换目标
	if self.AIobj.attribute.actorType==2 and #self.AIobj.BossHatredlist>0 and self.AIobj.statusList[102]==nil then
		local obj = self.world.allItemList[self.AIobj.BossHatredlist[#self.AIobj.BossHatredlist]['itemID']]
		if  obj.statusList[4007]==nil then
				targetID = self.AIobj.BossHatredlist[#self.AIobj.BossHatredlist]['itemID']
		end
		self.AIobj:D("fenglog boss被嘲讽....切换目标")
	end


	if self.AIobj.AITargetAuto and self.AIobj.AITargetTime>self.world:getGameTime() then
		local obj = self.world.allItemList[self.AIobj.AITargetItemID]
		if obj~=nil and not obj:isDead() then
			targetID = self.AIobj.AITargetItemID
		end
	end

	--self.AIobj:D("fenglog SAI itemID:"..self.AIobj.itemID.." :execute 第三层赛选结果+仇恨值 排序以后的值为:"..self.world.cjson.encode(sortlist))
	return targetID
end

---AI 自动移动 包括脱离和巡逻
-- @param null
-- @return null
function SAI:autoMove()
	
		local r = self.AIobj.attribute.PATROLRANGE/self.AIobj.world.setting.AdjustVisRange
		local cr = self.AIobj.attribute.CHASERANGE/self.AIobj.world.setting.AdjustVisRange
		-- local r = 10
		-- local cr = 15  
		--self.AIobj:D("fenglog SAI boss脱离前 self.AIobj.initX:"..self.AIobj.initX.." initY:"..self.AIobj.initY.." posX:"..self.AIobj.posX.." posY:"..self.AIobj.posY)
		local d = self.world.map:distance(self.AIobj.initX,self.AIobj.initY,self.AIobj.posX,self.AIobj.posY) 
		--local d=r
		--脱离模式
		--self.AIobj:D("fenglog SAI AIlastAutoMove:"..self.AIobj.AIlastAutoMove.." autoMove d:"..d.." cr:"..cr)
		if d>=cr then
			self:autoLostTarget(d,cr)
			self.forceLost=false
		end

		if self.AIobj.AIlastAutoMove<self.world.gameTime and self.world.gameTime>0 then
		--巡逻模式
		if d<cr and self.noAutoPatrol==false and self.AIobj.autoFightAI.runMoveAI and not self.NOMOVEAI and self.AIobj.attribute.actorType~=3 and (self.AIobj.attribute.actorType==0 or (self.AIobj.attribute.actorType~=0 and self.AIobj.attribute.parameterArr["NOAI"]==nil) ) then
			self:autoPatrol(d,r)
		end
		--self:autoPatrol1(d,r)
		--未在巡逻范围内的脱离
		if d>r and self.AIobj.autoFightAI.runMoveAI and not self.NOMOVEAI  then
			self:autoLostTarget(d,r)
		end

		end

end

---自动脱离
-- @param d int - 实际相隔距离
-- @param cr int - 需要比较的距离
-- @return null
function SAI:autoLostTarget(d,cr)
		--debuglog("fenglog 暂停移动AI 自动脱离",self.AIobj.itemID,self.runMoveAI)
		self.AIobj:D("fenglog SAI boss脱离了初始位太远需要回归.........d:"..d.." cr:"..cr.." TYPEATK:"..self.AIobj.attribute.TYPEATK)
		self.AIobj:moveTo(self.AIobj.initX,self.AIobj.initY)
		if self.AIobj.paths~=nil and #self.AIobj.paths>0 then
			self.AIobj.AIlastAutoMove = self.AIobj.paths[#self.AIobj.paths].t
			self.AIobj.autoFightAI.runMoveAI = false
			self.AIobj.prepareSkillAttackNum = 0
		end
		self.AIobj.attackTarget = nil
		if self.AIobj.attribute.TYPEATK==2 then
			self.runAI = false 
			self.AIobj.Hatredlist={}
		--	self.AIobj:D("fenglog 是否有清除仇恨列表............. roleID:"..self.AIobj.attribute.roleId)
		end

		-- self.outOfCtlTime = self.paths[#self.paths].t
		if self.AIobj.paths~=nil and #self.AIobj.paths>0 then
			--self.AIobj.AIlastCoolDown = self.AIobj.paths[#self.AIobj.paths].t
			self.AIobj:setOutOfCtlAllTime(self.AIobj.paths[#self.AIobj.paths].t) 
		end
		--self.AIobj:D("fenglog SAI boss脱离前...... outOfCtlTime:"..self.AIobj.outOfCtlTime.." gameTime:"..self.world.gameTime.." getGameTime:"..self.world:getGameTime())
		-- local attributes = {}
		-- --attributes['OUTCTL_RATE'] = 100
		-- attributes['INVICINBLE_RATE'] = 100 
		-- if self.AIobj.paths~=nil and #self.AIobj.paths>0 then

		-- 	self.AIobj:D("fenglog SAI boss脱离zhong self.AIobj.initX:"..self.AIobj.initX.." initY:"..self.AIobj.initY.." posX:"..self.AIobj.posX.." posY:"..self.AIobj.posY)
		-- 	self.AIobj:D("fenglog SAI boss脱离zhong debugPaths:"..self.AIobj.world.cjson.encode(self.AIobj.debugPaths))
		-- 	self.AIobj:D("fenglog SAI boss脱离zhong paths:"..self.AIobj.world.cjson.encode(self.AIobj.paths))
		-- 	self.AIobj:D("fenglog SAI boss脱离zhong t:"..self.AIobj.paths[#self.AIobj.paths].t)
		-- 	local buff = require("gameroomcore.SBuff").new(self.world,self.AIobj:__skillID2buffID(0),attributes,(self.AIobj.paths[#self.AIobj.paths].t-self.world.gameTime),{},0,self.AIobj.itemID,self.AIobj.itemID,0.1)
		-- 	self.AIobj:addBuff(buff)
		-- 	self.AIobj:D("fenglog SAI boss脱离后...... outOfCtlTime:"..self.AIobj.outOfCtlTime.." gameTime:"..self.world.gameTime.." getGameTime:"..self.world:getGameTime())
		-- end
end

---自动巡逻
-- @param d int  - 实际相隔距离
-- @param cr int - 需要比较的距离
-- @return null
function SAI:autoPatrol(d,r)
	--debuglog("fenglog 暂停移动AI 自动巡逻",self.AIobj.itemID,self.runMoveAI)
	--self.AIobj:D("fenglog boss X:"..self.AIobj.posX.." Y:"..self.AIobj.posY.." 0.6R:"..(0.6*r))
		--self.AIobj:D("fenglog 是否进入巡逻.............")
		local x,y = self.world.formula:getRandomCirclePoint(self.AIobj.initX,self.AIobj.initY,r)
		-- local x = self.AIobj.posX+1
		-- local y = self.AIobj.posY+1
		self.AIobj:moveTo(x,y)

		if self.world.gameRoomSetting['ISYW']==1 then
			--self.world:self.AIobj:D("fenglog 触发 boss回血...... roleId:",self.AIobj.attribute.roleId)
			local isUpdate = false
			if self.AIobj.attribute.HP~=self.AIobj.attribute.MaxHP then
				isUpdate = true
			end
			self.AIobj.attribute.HP = self.AIobj.attribute.MaxHP
			if isUpdate then
				local result = self.AIobj:getAllInfo()
				self.AIobj:updateSyncMsg({i=result})
			end
		end


		if self.AIobj.attribute.TYPEATK==2 then
			self.runAI = false 
			self.AIobj.Hatredlist={}
			--self.AIobj:D("fenglog 巡逻 是否有清除仇恨列表............. roleID:"..self.AIobj.attribute.roleId)
		end

		--self.AIobj:D("fenglog SAI itemID:"..self.AIobj.itemID.." 巡逻到 X:"..x.." Y:"..y.." actorType:"..self.AIobj.attribute.actorType.." roleId:"..self.AIobj.attribute.roleId)
		--self.AIobj:D("fenglog paths:"..self.world.cjson.encode(self.AIobj.paths))
		if self.AIobj.paths~=nil and #self.AIobj.paths>0 then
			self.AIobj.AIlastAutoMove = self.AIobj.paths[#self.AIobj.paths].t + self.world.mRandom(1,self.AIobj.attribute.PATROLCD)
		end
		--self.AIobj:D("fenglog SAI AIlastAutoMove:"..self.AIobj.AIlastAutoMove.." PATROLCD:"..self.AIobj.attribute.PATROLCD)
end



---自动巡逻 直线运动遇到障碍物反弹
-- @param null
-- @return null
function SAI:autoPatrol1()

		--self.AIobj:D("fenglog SAI:autoPatrol1 old nextPosX:"..self.nextPosX.." nextPosY:"..self.nextPosY)
		local toX,toY = self.world.map:getXYLength(self.AIobj.posX,self.AIobj.posY,self.nextPosX,self.nextPosY,100000/self.world.setting.AdjustAttRange)
		ret,toX,toY=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,self.AIobj.posX+toX,self.AIobj.posY+toY) 
		--self.AIobj:D("fenglog autoPatrol1 posX:"..self.AIobj.posX.." posY:"..self.AIobj.posY.." toX:"..toX.." toY:"..toY)
		--self.AIobj:D("fenglog autoPatrol1 outOfCtlAllTime:"..self.AIobj.outOfCtlAllTime.." gameTime:"..self.world.gameTime)
		self.AIobj:moveTo(toX,toY)
		--需要计算出下个移动的坐标
		if self.AIobj.posX==toX and self.AIobj.posY==toY then
			toX = toX + 1
			toY = toY + 1
		end

		local ret, gx, gy , gx2 ,gy2 = self.world.map:findReflectionPoint(self.AIobj.posX,self.AIobj.posY,toX,toY,1000)
		self.nextPosX = gx2
		self.nextPosY = gy2

		-- self.nextPosX = self.world.formula:getRandnum(-1000,1000)
		-- self.nextPosY = self.world.formula:getRandnum(-1000,1000)

		--self.AIobj:D("fenglog SAI:autoPatrol1  nextPosX:"..self.nextPosX.." nextPosY:"..self.nextPosY)

		self.AIobj.AIlastAutoMove = self.AIobj.moveToEndTime 
		--self.AIobj:D("fenglog autoPatrol1 AIlastAutoMove:"..self.AIobj.AIlastAutoMove.." gameTime:"..self.world.gameTime)
		self.ROLLDESTROYTIME = self.ROLLDESTROYTIME + 1
		return self.ROLLDESTROYTIME
end



---自动攻击 适用于英雄
function SAI:autoFightToHero()
		--选敌
		--local enemy=self.AIobj:getEnemylist()
		--此处预留给skill;视野范围
		local visRange={posX=self.AIobj.posX,posY=self.AIobj.posY,radius=10000/self.world.setting.AdjustVisRange}
		local targetList = self:__findTarget(1,visRange,false)
		local targetID = 0
		local cdTime = 0
		
		if #targetList>0 then
			self.world.tSort(targetList,function( a1,b1 )
						return a1['DIS'] < b1['DIS']
					end)
			targetID = targetList[1]["itemID"]
			
			local skill = self.AIobj.attribute.skills[1] 
			cdTime = 0

	  	end

	  return targetID,1,cdTime
end

---跟随模式
---自动适配移动  跟随模式
-- @param null
-- @return null
function SAI:autoMoveToFollowed(maxDis,minDis,disType)
	if disType==nil then disType=3 end

	if self.AIobj.parent~=nil then
		local d = self.AIobj:distance(self.AIobj.parent.posX,self.AIobj.parent.posY)
		if d>maxDis then
			self.AIobj:D("新弓箭手 maxDis:",maxDis,"minDis:",minDis,"d:",d)
			local toX,toY 
			local newtoX,newtoY
			if disType==1 then
				toX,toY = self.world.map:getXYLengthCross(self.AIobj.posX,self.AIobj.posY,self.AIobj.parent.posX+self.world.formula:getRandnum(-100,100)*0.01,self.AIobj.parent.posY+self.world.formula:getRandnum(-100,100)*0.01,minDis) 
				newtoX,newtoY=(self.AIobj.parent.posX+toX),(self.AIobj.parent.posY+toY)
			end

			if disType==2 then
				toX,toY = self.world.map:getXYLengthCross(self.AIobj.posX,self.AIobj.posY,self.AIobj.parent.posX+self.world.formula:getRandnum(-100,100)*0.01,self.AIobj.parent.posY+self.world.formula:getRandnum(-100,100)*0.01,-minDis) 
				newtoX,newtoY=(self.AIobj.parent.posX+toX),(self.AIobj.parent.posY+toY)
			end

			if disType==3 then
				toX,toY = self.world.map:getXYLength(self.AIobj.posX,self.AIobj.posY,self.AIobj.parent.posX+self.world.formula:getRandnum(-100,100)*0.01,self.AIobj.parent.posY+self.world.formula:getRandnum(-100,100)*0.01,d-minDis) 
				newtoX,newtoY=(self.AIobj.posX+toX),(self.AIobj.posY+toY)
			end

			--local toX,toY = self.world.map:getXYLengthCross(self.AIobj.posX,self.AIobj.posY,self.AIobj.parent.posX+self.world.formula:getRandnum(-100,100)*0.01,self.AIobj.parent.posY+self.world.formula:getRandnum(-100,100)*0.01,d-minDis) 
			--local newtoX,newtoY=(self.AIobj.posX+toX),(self.AIobj.posY+toY)
			--local ret,newtoX,newtoY=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,self.AIobj.posX+toX,self.AIobj.posY+toY) 
			
			if newtoX~=nil and newtoY~=nil and self.AIobj.lastCoolDownTime<self.world:getGameTime() then
				self.AIobj:clearSkillAttack()
				if d<30 then
					self.AIobj:setMoveTarget(newtoX,newtoY)
				else
					self.AIobj:moveTo(newtoX,newtoY,true,1)
				end
				
				self.AIobj.AIlastATKTime = self.AIobj.moveToEndTime + 0.5
				return true
			end
		end
	end
	return false
end


return SAI
