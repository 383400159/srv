local SAIHero = class("SAIHero", require("gameroom.ai.SAI"))
--- Constructor
-- @param world object - world object
-- @param heroObj int - hero Obj
-- @param skillObj int - skill obj
-- @return null
function SAIHero:ctor(obj) 
	if (self.className==nil) then 
		self.className = "SAIHero" 
	end
	SAIHero.super.ctor(self,obj) 
	self.nextMoveTargetTime = 0
	self.autoMoveToAlerTime = 0
	self.autoMoveToDEFTime = 0



	--AI当时的行为 0为不作为
	self.worldAIMode=0
	--AI逗留时间
	self.worldAIDead=999999
	--AI切换下次行为的时间
	self.worldAINextModeTime=0
	--AI开始时间
	self.worldAIStartTime=0
	--AI正在执行动作 下次允许执行新动作的时间
	self.worldAINextTime=0
	--AI攻击开始时间
	self.worldAIATKStartTime=0
	--AI攻击结束时间
	self.worldAIATKEndTime=0
	--AI接近移动间隔
	self.worldAIATKMoveEndTime = 0
	--AI被打还击
	self.worldAICounterAttack=0
	--AI下线时间
	self.worldAIOfflineTime=0
	--AI调整站位
	self.nextBehindTime = 0
	--AI调整站位灵敏度
	self.behindTimes = self.world.formula:getRandnum(100,300)*0.01
	--绑定当场boos对象
	self.GVBBOSSObj=0
	--开关自动站背后AI
	self.isBehindAI = true
end 

---自动攻击 适用于英雄
-- @param null
-- @return null
function SAIHero:autoFightToHero(newSkillList)


		--记录英雄适合放的技能
		local heroSkillList = self.AIobj.attribute.AIRoleSetting['normalSkillList']
		local atkHeroSoce = self.AIobj.attribute.AIRoleSetting['targetRolePower']
		
		if newSkillList~=nil then
			heroSkillList=newSkillList
		end

		local r1 = self.world.formula:getRandnum(0,100)
		if r1>self.AIobj.gxAIlist.skillRate then
			--技能失误率
			self.AIobj:D("fenglog 失误 技能失误率 itemID:",self.AIobj.itemID,r1,self.AIobj.gxAIlist.skillRate)
			heroSkillList = {}
		end
		--self.AIobj:D("fenglog 一段时间内限制技能次数  阻止放技能 autoFightToHero itemID:",self.AIobj.itemID,self.world.AIUseSkillNum,self.world.AIUseSkillTime,self.world:getGameTime(),self.world.mapModel)
		if self.world.AIUseSkillTime~=nil and self.world.mapModel=="9006" then
			if self.world.AIUseSkillTime>self.world:getGameTime() then
				if self.world.AIUseSkillNum>self.world.setting.AISkillFrequencyXinshou then
					--超过了一秒内放技能的次数 相对于所有的AI
					self.AIobj:D("fenglog 一段时间内限制技能次数 到间隔释放次数了 阻止放技能  itemID:",self.AIobj.itemID,self.world.AIUseSkillNum,self.world.AIUseSkillTime,self.world:getGameTime())
					heroSkillList = {}
				end
			else
				self.world.AIUseSkillNum = 0
				--下次切换的时间
				self.world.AIUseSkillTime = self.world:getGameTime()+self.world.setting.AISkillDurationXinshou 
			end
		end


		if self.AIobj:isDead() then
			return 0,0,0.5
		end
		--选敌
		--local enemy=self.AIobj:getEnemylist()
		--此处预留给skill;视野范围
		local vis = 1000000
		if self.world.gameRoomSetting.ISYW==1 then
			vis=3000
			self.AIobj:D("fenglog AI调整视野....",self.AIobj.itemID)
		end
		--假设为分身 则调整攻击范围
		if self.AIobj.parent~=nil then
			vis = 2100
		end

		local visRange={posX=self.AIobj.posX,posY=self.AIobj.posY,radius=vis/self.world.setting.AdjustVisRange}
		local targetList = self:__findTarget(1,visRange,false)
		local targetID = 0
		local cdTime = 0.1
		
		if #targetList>0 then
			--同一个波动区段内的都当做同一个距离
			for k,v in pairs(targetList) do
				--这里
				local obj  = self.world.allItemList[v["itemID"]]
				local width=self.AIobj.attribute.AIRoleSetting['targetRangeSection']*0.01
				v['DIS'] = self.world.mCeil(v['DIS']/width)
				
				if obj.attribute.actorType==0 then
					--self.AIobj:D("autoFightToHero 取余:"..obj.attribute.roleId%5)
					if obj.attribute.roleId==5 or obj.attribute.roleId==10 then
						v['threat'] = v['DIS']*atkHeroSoce[5]
					else
						v['threat'] = v['DIS']*atkHeroSoce[obj.attribute.roleId%5]
					end	
					--让AI在怪堆优先攻击英雄				
					if obj.itemID==self.AIobj.lastHurtItemID then
						v['DIS'] = v['DIS'] / 5
					else
						v['DIS'] = v['DIS'] / 2
					end
				else
					v['threat'] = 1
				end


				if self.AIobj.atkTaskList[obj.attribute.roleId]~=nil then
					--优先攻击任务怪
					v['DIS'] = v['DIS'] / 5
				end

			end
			self.world.tSort(targetList,function( a1,b1 )
						return a1['threat'] > b1['threat']
					end)
			self.world.tSort(targetList,function( a1,b1 )
						return a1['DIS'] < b1['DIS']
					end)
			targetID = targetList[1]["itemID"]
	  	end
	  	--判断释放距离够不够
	  	local d = 0
	  	--判断是否要进攻物免魔免怪
	  	local IMMUNEAD=0
		local IMMUNEAP=0
	  	if targetID>0 then
	  		local obj  = self.world.allItemList[targetID]
	  		d = obj:distance(self.AIobj.posX,self.AIobj.posY)
	  		IMMUNEAD = self.AIobj.attribute.buffAttribute.IMMUNEAD
	  		IMMUNEAP = self.AIobj.attribute.buffAttribute.IMMUNEAP
	  	end

	  	local sk = self.AIobj.attribute.skills
		local gt = self.world:getGameTime()
		--可释放技能列表
		local skList = {}
		for k,v in pairs(heroSkillList) do
			if sk[v] ~=nil then
				--self.AIobj:D("不为空:"..i.." lastCoolDownTime:"..sk[i].lastCoolDownTime.." gt:"..gt)
				local parameters = sk[v].parameters
				--if sk[v].lastCoolDownTime<gt and self.AIobj:checkMana(v) and (sk[v].useDis*0.8>=d*100 or v==5 or sk[1].useDis*0.8>=d*100) and (IMMUNEAD==0 or (IMMUNEAD>0 and parameters.APADJ~=nil and parameters.APADJ>0) ) and (IMMUNEAP==0 or (IMMUNEAP>0 and parameters.ADADJ~=nil and parameters.ADADJ>0) )  then
				if (self.AIobj.attribute.SKILLOPEN[v]==nil or self.AIobj.attribute.SKILLOPEN[v]==1) and self.AIobj.lastAttackID>0 and sk[v].lastCoolDownTime<gt and self.AIobj:checkMana(v) and ( (self.AIobj.attribute.roleId~=4 or v~=4) or (self.AIobj.attribute.roleId==4 and v==4 and sk[v].useDis*0.8>=d*100) ) and (IMMUNEAD==0 or (IMMUNEAD>0 and parameters.APADJ~=nil and parameters.APADJ>0) ) and (IMMUNEAP==0 or (IMMUNEAP>0 and parameters.ADADJ~=nil and parameters.ADADJ>0) )  then
					skList[#skList+1]=v	
				end
			end
		end
		--随机一个技能
		--self.AIobj:D(" skList:"..self.world.cjson.encode(skList))
		skList=table.shuffle(skList)
		local skillsID=1
		cdTime=0.1
		if #skList>0 then
			skillsID = skList[1]
			cdTime = sk[skillsID].animationTime
		end


	  	--矮子强行只打boss 判断有没有boss 有boss切换目标
	  	if (self.AIobj.attribute.roleId%5==2) and self.world.tonumber(self.world.mapModel)~=2 then
			for k,v in pairs(targetList) do
				local obj  = self.world.allItemList[v["itemID"]]
				if obj.attribute.actorType==2 then
					targetID = v["itemID"]
					self.AIobj:D("autoFightToHero 强行攻击boss")
				end
			end
		end


	  	--阿文用来替换ai攻击
	  	if self.world.heroNeedSkillID~=nil and self.world.heroNeedSkillID>0 then
	  		skillsID = self.world.heroNeedSkillID
	  		if self.world.heroNeedSkillTime>0 then
	  			cdTime = self.world.heroNeedSkillTime
	  		else
	  			cdTime = sk[skillsID].animationTime
	  		end
	  	end

	  	if skillsID>1 then
	  		self.nextMoveTargetTime = self.world:getGameTime() + sk[skillsID].animationTime+1
	  	end
	  	--self.AIobj:D('jaylog targetID:'..targetID..' skillsID:'..skillsID..' cdTime'..cdTime)

	  	local r1 = self.world.formula:getRandnum(0,100)
		if r1>self.AIobj.gxAIlist.normalAtkRate then
			--技能失误率
			skillsID=0
			targetID=0
			self.AIobj:D("fenglog 失误 普攻失误率 itemID:",self.AIobj.itemID,r1,self.AIobj.gxAIlist.normalAtkRate)
		end
		
		--天启者特殊处理
		if self.AIobj.attribute.roleId%5==4 and skillsID==1 and self.AIobj.mode1ATKMode==10 then
			skillsID = 10
			cdTime = sk[skillsID].animationTime
		end

		if self.AIobj.AITargetAuto and self.AIobj.AITargetTime>self.world:getGameTime() then
			local obj = self.world.allItemList[self.AIobj.AITargetItemID]
			if obj~=nil and not obj:isDead() then
				targetID = self.AIobj.AITargetItemID
				self.AIobj:D("fenglog 触发集火AI:",obj.itemID,self.AIobj.itemID)
			end
		end

		self.AIobj:D("feng heroAI: targetID:",targetID," skillsID:",skillsID,"itemID:",self.AIobj.itemID)
	  return targetID,skillsID,cdTime
end

--检测(posX,posY) 在点(x1,y1)(x2,y2)的左方还是右方 
function SAIHero:_checkBehind(x1,y1,x2,y2,posX,posY,isRightAngles) 
	if isRightAngles==nil then isRightAngles=false end	
	local k = 0
	if isRightAngles then
		k = -(x2-x1)/(y2-y1)
	else
		k = (y2-y1)/(x2-x1)
	end

	local ret = (posY-y1) - k*(posX-x1)

	self.AIobj:D("_checkBehind ",x1,y1,x2,y2,posX,posY,isRightAngles,ret)
	return ret
end

--自动移动到指定对象后方
function SAIHero:autoMoveToBehind()
	if not self.isBehindAI then
		return false
	end

	if self.GVBBOSSObj==0 or self.GVBBOSSObj==nil then
		self.GVBBOSSObj = self:getBossObj()
	end
	self.AIobj:D("AI站位 autoMoveToBehind")
	if self.GVBBOSSObj~=0 and self.GVBBOSSObj~=nil then
		local isMove = false
		local bossObj = self.GVBBOSSObj
		if bossObj==nil then
			self.AIobj:D("AI站位 bossObj nil")
		end
		if bossObj~=nil  and  not bossObj:isDead() then
			self.AIobj:D("AI站位 isDead",bossObj.itemID,bossObj:isDead(),bossObj.attackTarget)
			local obj  = self.world.allItemList[bossObj.attackTarget]
			if obj~=nil and obj.attribute.roleId%5==2 and obj.isAI then
				--boss的真在攻击矮子 需要调整自己的站位
				isMove = true
			end
		end
		self.AIobj:D("AI站位 ",isMove)
		if isMove and self.AIobj.attribute.roleId%5~=2 then
			--先确认矮子在boss的哪边
			local obj  = self.world.allItemList[bossObj.attackTarget]
			local ret1 = self:_checkBehind(bossObj.posX,bossObj.posY,obj.posX,obj.posY,obj.posX,obj.posY,true)
			local ret2 = self:_checkBehind(bossObj.posX,bossObj.posY,obj.posX,obj.posY,self.AIobj.posX,self.AIobj.posY,true)
			self.AIobj:D("AI站位 boss:",bossObj.posX,bossObj.posY," 矮子",obj.itemID,obj.posX,obj.posY," 自己的站位:",self.AIobj.itemID,self.AIobj.posX,self.AIobj.posY,ret1,ret2)
			
			if (ret1==ret2 or (ret1>0 and  ret2>0) or (ret1<0 and  ret2<0)) and (obj.setBehindTime==nil or (obj.setBehindTime+self.behindTimes)<self.world:getGameTime()) then
				self.AIobj:D("AI站位 同一方位 boss:",bossObj.posX,bossObj.posY," 矮子",obj.itemID,obj.posX,obj.posY," 自己的站位:",self.AIobj.itemID,self.AIobj.posX,self.AIobj.posY,ret1,ret2)
				--移动去对立位
				local toX,toY = self.world.map:getXYLength(obj.posX,obj.posY,bossObj.posX,bossObj.posY,1000/self.world.setting.AdjustAttRange)
				ret,newtoX,newtoY=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,obj.posX+toX,obj.posY+toY) 
				local d = bossObj:distance(newtoX,newtoX)
				if d>7 or (self.world.gameRoomSetting['ISWF']==1 and d>4)  then
						self.AIobj:D("AI站位 调整移动:"..self.AIobj.itemID,bossObj.posX,bossObj.posY,newtoX,newtoX,d,self.AIobj.posX,self.AIobj.posY)
						self.AIobj:moveTo(newtoX,newtoY)
					--self.AIobj:D("AI站位 调整移动后:"..self.AIobj.itemID,bossObj.posX,bossObj.posY,newtoX,newtoX,d,self.AIobj.posX,self.AIobj.posY)
						self.nextBehindTime = self.world:getGameTime() + 3
				end
				return true
			end
		end

		--矮子需要移动动到离墙近那边
		if isMove and self.AIobj.attribute.roleId%5==2 then
			debuglog("AI站位 xxxx22xxxxxxxxxxxxx44")
			local toX,toY = self.world.map:getXYLength(self.AIobj.posX,self.AIobj.posY,bossObj.posX,bossObj.posY,5000/self.world.setting.AdjustAttRange)
			ret,newtoX,newtoY=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,self.AIobj.posX+toX,self.AIobj.posY+toY) 
			self.AIobj:D("AI矮子站位 数据:",self.AIobj.posX,self.AIobj.posY,bossObj.posX,bossObj.posY,5000/self.world.setting.AdjustAttRange,self.AIobj.posX+toX,self.AIobj.posY+toY,ret,newtoX,newtoY)
			if (self.AIobj.posX==newtoX and self.AIobj.posY==newtoY) then
				self.AIobj:D("AI矮子站位 此处不可行1")
				newtoX,newtoY = bossObj.posX,bossObj.posY
			end
			local d = bossObj:distance(newtoX,newtoX)
			
			local toX,toY = self.world.map:getXYLength(self.AIobj.posX,self.AIobj.posY,bossObj.posX,bossObj.posY,-5000/self.world.setting.AdjustAttRange)
			ret,newtoX1,newtoY1=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,self.AIobj.posX+toX,self.AIobj.posY+toY) 
			if  (self.AIobj.posX==newtoX1 and self.AIobj.posY==newtoY1) then
				self.AIobj:D("AI矮子站位 此处不可行2")
				newtoX1,newtoY1 = bossObj.posX,bossObj.posY
			end
			local d1 = bossObj:distance(newtoX1,newtoY1)

			local toX,toY = self.world.map:getXYLengthCross(self.AIobj.posX,self.AIobj.posY,bossObj.posX,bossObj.posY,-5000/self.world.setting.AdjustAttRange)
			ret,newtoX2,newtoY2=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,self.AIobj.posX+toX,self.AIobj.posY+toY) 
			if  (self.AIobj.posX==newtoX2 and self.AIobj.posY==newtoY2) then
				self.AIobj:D("AI矮子站位 此处不可行3")
				newtoX2,newtoY2 = bossObj.posX,bossObj.posY
			end
			local d2 = bossObj:distance(newtoX2,newtoY2)

			local toX,toY = self.world.map:getXYLengthCross(self.AIobj.posX,self.AIobj.posY,bossObj.posX,bossObj.posY,5000/self.world.setting.AdjustAttRange)
			ret,newtoX3,newtoY3=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,self.AIobj.posX+toX,self.AIobj.posY+toY) 
			if  (self.AIobj.posX==newtoX3 and self.AIobj.posY==newtoY3) then
				self.AIobj:D("AI矮子站位 此处不可行4")
				newtoX3,newtoY3 = bossObj.posX,bossObj.posY
			end
			local d3 = bossObj:distance(newtoX3,newtoY3)

			self.AIobj:D("AI矮子站位 :",d,d1)

			--判断去哪个方向
			local fx = 0
			if d<d1 then
				fx = 1
			end
			if d>d1 then
				fx = -1
			end
			if self.world.gameRoomSetting['ISWF']==1 then
				if d<10 or d1<10 or d2<10  or d3<10 then
					fx = 3
				end
			else
				if d<13 or d1<13 or d2<13  or d3<13 then
					fx = 3
				end
			end
			

			if fx==1 then
				local toX,toY = self.world.map:getXYLength(self.AIobj.posX,self.AIobj.posY,bossObj.posX,bossObj.posY,fx*bossObj.attribute.width*0.75)
				ret,newtoX,newtoY=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,self.AIobj.posX+toX,self.AIobj.posY+toY) 
				self.AIobj:moveTo(newtoX,newtoY)
				self.nextBehindTime = self.world:getGameTime() + 5 
				self.AIobj.AIlastMoveTime = self.AIobj.moveToEndTime 
				self.AIobj.setBehindTime = self.world:getGameTime() 
			end

			if fx==3  then
				-- local toX,toY = self.world.map:getXYLength(self.AIobj.posX,self.AIobj.posY,bossObj.posX,bossObj.posY,-d1/2)
				-- ret,newtoX,newtoY=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,self.AIobj.posX+toX,self.AIobj.posY+toY) 
				-- self.AIobj:moveTo(newtoX,newtoY)
				-- self.nextBehindTime = self.world:getGameTime() + 5 
				-- self.nextMoveTargetTime = self.AIobj.moveToEndTime 
				-- self.AIobj.setBehindTime = self.world:getGameTime()
				local safeDis  = 50
				local ret,newtoX,newtoY
				local toX1,toY1,newtoX1,newtoY1,toX2,toY2,newtoX2,newtoY2,toX3,toY3,newtoX3,newtoY3
				local toX,toY = self.world.map:getXYLength(self.AIobj.posX,self.AIobj.posY,bossObj.posX,bossObj.posY,safeDis)
				ret,newtoX,newtoY=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,self.AIobj.posX+toX,self.AIobj.posY+toY) 
				self.AIobj:D("AI矮子站位 old d1:".." newtoX:"..newtoX.." newtoY:"..newtoY.." d:0",ret)
				if (self.AIobj.posX==newtoX and self.AIobj.posY==newtoY) then
					newtoX,newtoY = self.AIobj.posX,self.AIobj.posY
				end
				local d = self.AIobj:distance(newtoX,newtoY)
				self.AIobj:D("AI矮子站位 d1:".." newtoX:"..newtoX.." newtoY:"..newtoY.." d:"..d,ret)

				--碰到障碍物 需要判断左右
				toX1,toY1 = self.world.map:getXYLengthCross(self.AIobj.posX,self.AIobj.posY,bossObj.posX,bossObj.posY,safeDis) 
				ret,newtoX1,newtoY1=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,self.AIobj.posX+toX1,self.AIobj.posY+toY1) 
				self.AIobj:D("AI矮子站位 old d2:".." newtoX:"..newtoX1.." newtoY:"..newtoY1.." d:0",ret)
				if (self.AIobj.posX==newtoX1 and self.AIobj.posY==newtoY1) then
					newtoX1,newtoY1 = self.AIobj.posX,self.AIobj.posY
				end
				local d1 = self.AIobj:distance(newtoX1,newtoY1)
				self.AIobj:D("AI矮子站位 d2:".." newtoX1:"..newtoX1.." newtoY:"..newtoY1.." d:"..d1,ret)

				toX2,toY2 = self.world.map:getXYLengthCross(self.AIobj.posX,self.AIobj.posY,bossObj.posX,bossObj.posY,-safeDis) 
				ret,newtoX2,newtoY2=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,self.AIobj.posX+toX2,self.AIobj.posY+toY2) 
				self.AIobj:D("AI矮子站位 old d3:".." newtoX:"..newtoX2.." newtoY:"..newtoY2.." d:0",ret)
				if (self.AIobj.posX==newtoX2 and self.AIobj.posY==newtoY2) then
					newtoX2,newtoY2 = self.AIobj.posX,self.AIobj.posY
				end
				local d2 = self.AIobj:distance(newtoX2,newtoY2)
				self.AIobj:D("AI矮子站位 d3:".." newtoX2:"..newtoX2.." newtoY2:"..newtoY2.." d:"..d2,ret)

				toX3,toY3 = self.world.map:getXYLength(self.AIobj.posX,self.AIobj.posY,bossObj.posX,bossObj.posY,-safeDis) 
				ret,newtoX3,newtoY3=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,self.AIobj.posX+toX3,self.AIobj.posY+toY3) 
				self.AIobj:D("AI矮子站位 old d4:".." newtoX:"..newtoX3.." newtoY:"..newtoY3.." d:0",ret)
				if  (self.AIobj.posX==newtoX3 and self.AIobj.posY==newtoY3) then
					newtoX3,newtoY3 = self.AIobj.posX,self.AIobj.posY
				end
				local d3 = self.AIobj:distance(newtoX3,newtoY3)
				self.AIobj:D("AI矮子站位 d4:".." newtoX3:"..newtoX3.." newtoY3:"..newtoY3.." d:"..d3,ret)

				local solist = {{d=d,x=newtoX,y=newtoY,n=1},{d=d1,x=newtoX1,y=newtoY1,n=2},{d=d2,x=newtoX2,y=newtoY2,n=3},{d=d3,x=newtoX3,y=newtoY3,n=4}}
				self.world.tSort(solist,function( a1,b1 )
					return a1['d'] > b1['d']
				end)

				local n = solist[1]['n']
				local toX,toY 
				local safeDis = 18
				if self.world.gameRoomSetting['ISWF']==1 then
					safeDis = 12
				end
				if n==1 then
					toX,toY = self.world.map:getXYLength(self.AIobj.posX,self.AIobj.posY,bossObj.posX,bossObj.posY,safeDis)	
				end
				if n==2 then
					toX,toY  = self.world.map:getXYLengthCross(self.AIobj.posX,self.AIobj.posY,bossObj.posX,bossObj.posY,safeDis) 
				end
				if n==3 then
					toX,toY  = self.world.map:getXYLengthCross(self.AIobj.posX,self.AIobj.posY,bossObj.posX,bossObj.posY,-safeDis) 
				end
				if n==4 then
					toX,toY  = self.world.map:getXYLength(self.AIobj.posX,self.AIobj.posY,bossObj.posX,bossObj.posY,-safeDis) 
				end
				ret,newtoX,newtoY=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,self.AIobj.posX+toX,self.AIobj.posY+toY) 
				-- newtoX = solist[1]['x']
				-- newtoY = solist[1]['y']
				self.AIobj:D("AI矮子站位 zz".." newtoX:"..newtoX.." newtoY:"..newtoY.." d:"..solist[1]['d'])

				local randX = self.world.formula:getRandnum(-200,200)*0.01
				local randY = self.world.formula:getRandnum(-200,200)*0.01

				self.AIobj:moveTo(newtoX+randX,newtoY+randY)
				self.nextBehindTime = self.world:getGameTime() + 5 
				self.AIobj.AIlastMoveTime = self.AIobj.moveToEndTime + 1
				self.AIobj.setBehindTime = self.world:getGameTime()
			end
		end


		if  not isMove and self.AIobj.attribute.roleId%5==2 then
			self.nextBehindTime = self.world:getGameTime()-0.1
			self.AIobj.AIlastMoveTime = self.world:getGameTime()-0.1
		end
	end

	return false
end

function SAIHero:getBossObj()
	local obj = self.world:getObjBySubName("BOSS1",self.world.itemListFilter.heroList)
	return obj
end

---自动适配移动  适用于英雄 防御
-- @param null
-- @return null
function SAIHero:autoMoveToHero()

	if self.AIobj.isAI==nil or not self.AIobj.isAI  then
		return false
	end
	
	local r1 = self.world.formula:getRandnum(0,100)
	if r1>self.AIobj.gxAIlist.defRate and self.autoMoveToDEFTime<self.world:getGameTime() then
		--防御移动失误率
		self.AIobj:D("fenglog 失误 防御移动失误率 itemID:",self.AIobj.itemID,r1,self.AIobj.gxAIlist.defRate)
		self.autoMoveToDEFTime = self.world:getGameTime() + 0.5
		return false
	end

	--if self.AIobj.attackTarget~=nil and self.AIobj.attackTarget>0 and self.world.gameRoomSetting.ISPVP==1 then
	if self.AIobj.attackTarget~=nil and self.AIobj.attackTarget>0 and self.world.gameRoomSetting.ISYW~=1 and self.autoMoveToDEFTime<self.world:getGameTime() then
		local targetID = self.AIobj.attackTarget
		local obj  = self.world.allItemList[targetID]

		if obj==nil or obj.attribute.actorType==1 then
			return false
		end

		self.AIobj:D("英雄移动AI1 attackTarget:"..self.AIobj.attackTarget.." objX:"..obj.posX.." objY:"..obj.posY)
		--假设安全距离为10
		local safeDis = self.AIobj.attribute.AIRoleSetting['safeRange']
		if self.AIobj.attribute.parameterArr~=nil and self.AIobj.attribute.parameterArr['SAFERANGE']~=nil then
			self.AIobj:D("parameterArr SAFERANGE:"..self.AIobj.attribute.parameterArr['SAFERANGE'])
			safeDis = self.AIobj.attribute.parameterArr['SAFERANGE']
		else
			self.AIobj:D("parameterArr SAFERANGE 异常:"..self.AIobj.itemID)
		end

		local d = obj:distance(self.AIobj.posX,self.AIobj.posY)
		--判断距离小于安全距离才需要脱离
		self.AIobj:D("相隔距离 d:"..d.." safeDis:"..safeDis/self.world.setting.AdjustAttRange)
		if d<(safeDis/self.world.setting.AdjustAttRange) then
			local randX = self.world.formula:getRandnum(-2,2)
			local randY = self.world.formula:getRandnum(-2,2)
			local toX,toY = self.world.map:getXYLength(obj.posX,obj.posY,self.AIobj.posX+randX,self.AIobj.posY+randY,safeDis/self.world.setting.AdjustAttRange)
			local ret,newtoX,newtoY
			local toX1,toY1,newtoX1,newtoY1,toX2,toY2,newtoX2,newtoY2,toX3,toY3,newtoX3,newtoY3
			self.AIobj:D("英雄移动AI1".." toX:"..toX.." toY:"..toY)
			ret,newtoX,newtoY=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,obj.posX+toX,obj.posY+toY) 
			local d = self.AIobj:distance(newtoX,newtoY)
			self.AIobj:D("英雄移动AI2".." newtoX:"..newtoX.." newtoY:"..newtoY.." d:"..d)
			--碰到障碍物 需要判断左右
			if toX~=newtoX or toY~=newtoY then
				toX1,toY1 = self.world.map:getXYLengthCross(obj.posX,obj.posY,newtoX,newtoY,safeDis/self.world.setting.AdjustAttRange) 
				ret,newtoX1,newtoY1=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,newtoX+toX1,newtoY+toY1) 
				local d1 = self.AIobj:distance(newtoX1,newtoY1)
				self.AIobj:D("英雄移动AI3".." newtoX1:"..newtoX1.." newtoY:"..newtoY1.." d:"..d1)
				toX2,toY2 = self.world.map:getXYLengthCross(obj.posX,obj.posY,newtoX,newtoY,-safeDis/self.world.setting.AdjustAttRange) 
				ret,newtoX2,newtoY2=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,newtoX+toX2,newtoY+toY2) 
				local d2 = self.AIobj:distance(newtoX2,newtoY2)
				self.AIobj:D("英雄移动AI4".." newtoX2:"..newtoX2.." newtoY2:"..newtoY2.." d:"..d2)
				toX3,toY3 = self.world.map:getXYLength(obj.posX,obj.posY,newtoX,newtoY,-safeDis/self.world.setting.AdjustAttRange) 
				ret,newtoX3,newtoY3=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,newtoX+toX3,newtoY+toY3) 
				local d3 = self.AIobj:distance(newtoX3,newtoY3)
				self.AIobj:D("英雄移动AI5".." newtoX3:"..newtoX3.." newtoY3:"..newtoY3.." d:"..d3)


				local solist = {{d=d,x=newtoX,y=newtoY},{d=d1,x=newtoX1,y=newtoY1},{d=d2,x=newtoX2,y=newtoY2},{d=d3*0.3,x=newtoX3,y=newtoY3}}
				self.world.tSort(solist,function( a1,b1 )
					return a1['d'] > b1['d']
				end)
				newtoX = solist[1]['x']
				newtoY = solist[1]['y']

				self.AIobj:D("英雄移动AI6".." newtoX:"..newtoX.." newtoY:"..newtoY.." d:"..solist[1]['d'])
			end

			--判断是翻滚还是跑动
			local sk = self.AIobj.attribute.skills[8]
			local gt = self.world:getGameTime()
			if sk.lastCoolDownTime<gt and self.AIobj.AIlastATKTime<gt  and  (self.AIobj.attribute.SKILLOPEN[8]==nil or self.AIobj.attribute.SKILLOPEN[8]==1) then
					self.AIobj:skillAttack(8,0,newtoX,newtoY,false,true)
			else
				if self.AIobj.attribute.roleId%5==1 then
					--狂战士会用冲刺逃跑
					local sk = self.AIobj.attribute.skills[2]
					local gt = self.world:getGameTime()
					if sk.lastCoolDownTime<gt and false then
						self.AIobj:skillAttack(2,0,newtoX,newtoY,false,true)
					else
						self.AIobj:moveTo(newtoX,newtoY)
					end
				else
					--正常逃跑
					self.AIobj:moveTo(newtoX,newtoY)
				end
			end

			--测试
			self.autoMoveToDEFTime = self.AIobj.moveToEndTime + 0
		end                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
	end
end

---自动适配移动  适用于英雄 攻击
-- @param null
-- @return null
function SAIHero:autoMoveToATKHero(type)
	if self.AIobj.isAI==nil or not self.AIobj.isAI  then
		return false
	end

	if type==nil then type=1 end
	if type==1 then
		local r1 = self.world.formula:getRandnum(0,100)
		if r1>self.AIobj.gxAIlist.atkARate then
			--进攻移动1失误率
			self.AIobj:D("fenglog 失误 进攻移动1失误率 itemID:",self.AIobj.itemID,r1,self.AIobj.gxAIlist.atkARate)
			self.AIobj.AIlastATKTime = self.world:getGameTime() + 0.5
			return false
		end
	end

	if type==2 then
		local r1 = self.world.formula:getRandnum(0,100)
		if r1>self.AIobj.gxAIlist.atkBRate then
			self.AIobj:D("fenglog 失误 进攻移动2失误率 itemID:",self.AIobj.itemID,r1,self.AIobj.gxAIlist.atkBRate)
			self.AIobj.AIlastATKTime = self.world:getGameTime() + 0.5
			--进攻移动2失误率
			return false
		end
	end

	if self.AIobj.attackTarget~=nil and self.AIobj.attackTarget>0 and self.AIobj.AIlastATKTime<self.world:getGameTime() and self.AIobj.lastCoolDownTime<self.world:getGameTime() and self.worldAIATKMoveEndTime<=self.world:getGameTime() then

		local ret,newtoX,newtoY
		local targetID = self.AIobj.attackTarget
		local obj  = self.world.allItemList[targetID]
		if obj==nil then
			return false
		end
		
		self.AIobj:D("英雄移动AI1 attackTarget:"..self.AIobj.attackTarget.." objX:"..obj.posX.." objY:"..obj.posY)
		--假设安全距离为10
		local safeDis = self.AIobj.attribute.AIRoleSetting['atkRange']
		if self.AIobj.attribute.parameterArr~=nil and self.AIobj.attribute.parameterArr['SAFERANGE']~=nil then
			self.AIobj:D("parameterArr SAFERANGE:"..self.AIobj.attribute.parameterArr['SAFERANGE'])
			safeDis = self.AIobj.attribute.parameterArr['SAFERANGE']
		else
			self.AIobj:D("parameterArr SAFERANGE 异常:"..self.AIobj.itemID)
		end
		-- local safeDis = 300

		local d = obj:distance(self.AIobj.posX,self.AIobj.posY)
		--判断距离大于安全距离才需要贴近
		self.AIobj:D("相隔距离 d:"..d.." safeDis:"..(safeDis/self.world.setting.AdjustAttRange+self.AIobj.attribute.width))
		if  d>((safeDis/self.world.setting.AdjustAttRange)+obj.attribute.width) then
			local randX = 0
			local randY = 0
			local toX,toY = self.world.map:getXYLength(obj.posX,obj.posY,self.AIobj.posX+randX,self.AIobj.posY+randY,(safeDis/self.world.setting.AdjustAttRange+self.AIobj.attribute.width))
			local ret
			self.AIobj:D("英雄移动AI1".." toX:"..toX.." toY:"..toY)
			ret,newtoX,newtoY=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,obj.posX+toX,obj.posY+toY) 
			local d = self.AIobj:distance(newtoX,newtoY)
			self.AIobj:D("英雄移动AI2".." newtoX:"..newtoX.." newtoY:"..newtoY.." d:"..d)
			
			--判断是翻滚还是跑动
			local sk = self.AIobj.attribute.skills[8]
			local gt = self.world:getGameTime()
			if sk.lastCoolDownTime<gt and d*100>=sk.atkDis and  (self.AIobj.attribute.SKILLOPEN[8]==nil or self.AIobj.attribute.SKILLOPEN[8]==1)   then
				--SHeroBase:skillAttack(mode,itemID,positionX,positionY,force,fromClientSide,nPara,pPara)
				self.AIobj:D("翻滚:",self.AIobj.itemID,self.world.cjson.encode(self.AIobj.attribute.SKILLOPEN))
				self.AIobj:skillAttack(8,0,newtoX,newtoY,false,true)
			else
				if (self.AIobj.attribute.roleId==1 or self.AIobj.attribute.roleId==6) then
					--狂战士会用冲刺贴近
					local sk = self.AIobj.attribute.skills[2]
					local gt = self.world:getGameTime()
					if sk.lastCoolDownTime<gt and false then
						self.AIobj:skillAttack(2,0,newtoX,newtoY,false,true)
					else
						self.AIobj:moveTo(newtoX,newtoY)
					end
				else
					--正常贴近
					self.AIobj:moveTo(newtoX,newtoY)
				end
				self.worldAIATKMoveEndTime = self.AIobj.moveToEndTime - 0.1
			end
		end                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
	end

end


---自动适配移动  适用于英雄预警
-- @param null
-- @return null
function SAIHero:autoMoveToAlerted()
	if self.AIobj.isAI==nil or not self.AIobj.isAI  then
		return false
	end

	local r1 = self.world.formula:getRandnum(0,100)
	if r1>self.AIobj.gxAIlist.warnRate then
		--预警失误率
		self.AIobj:D("fenglog 失误 预警失误率 itemID:",self.AIobj.itemID,r1,self.AIobj.gxAIlist.warnRate)
		if self.autoMoveToAlerTime<self.world:getGameTime() then
			self.autoMoveToAlerTime = self.world:getGameTime() + 0.5
		end
		return false
	end


	if self.world.gameRoomSetting.ISGVB==1  and self.autoMoveToAlerTime<self.world:getGameTime() and self.nextBehindTime<self.world:getGameTime() then
		self:autoMoveToBehind()
	end


	local moveRet=false
	local ret,newtoX,newtoY
	local targetX,targetY
	local ret,x,y,r,line = self.world:checkWarningArea(self.AIobj.posX,self.AIobj.posY)
	if line then
		self.AIobj:D("英雄预警  需要躲避直线攻击")
	end
		--检测地上有没有致命伤害 进行躲避
	if ret and self.autoMoveToAlerTime<self.world:getGameTime() and self.AIobj.statusList[4007]==nil then
		--需要远离
		-- local targetID = self.AIobj.statusList['996']['p1']
		-- local obj  = self.world.allItemList[targetID]
		targetX = x
		targetY = y
		self.AIobj:D("英雄预警 适用于英雄预警: objX:"..targetX.." objY:"..targetY.." r:"..r)
		--假设安全距离为10
		local safeDis = r
		local d =self.world.mPow(self.world.mPow(targetX-self.AIobj.posX,2) + self.world.mPow(targetY-self.AIobj.posY,2),0.5)
		--local d = obj:distance(self.AIobj.posX,self.AIobj.posY)
		--判断距离小于安全距离才需要脱离
		self.AIobj:D("英雄预警 相隔距离 d:"..d.." safeDis:"..safeDis)
		if d<safeDis or line then
			-- local randX = self.world.formula:getRandnum(-2,2)
			-- local randY = self.world.formula:getRandnum(-2,2)
			local randX = 0
			local randY = 0
			local toX,toY = self.world.map:getXYLength(targetX,targetY,self.AIobj.posX+randX,self.AIobj.posY+randY,safeDis)
			local ret
			self.AIobj:D("英雄预警1".." toX:"..toX.." toY:"..toY)
			ret,newtoX,newtoY=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,targetX+toX,targetY+toY) 
			local d = self.AIobj:distance(newtoX,newtoY)
			self.AIobj:D("英雄预警2".." newtoX:"..newtoX.." newtoY:"..newtoY.." d:"..d)
			
			local toX1,toY1,newtoX1,newtoY1,toX2,toY2,newtoX2,newtoY2,toX3,toY3,newtoX3,newtoY3
			--碰到障碍物 需要判断左右
			if toX~=newtoX or toY~=newtoY or line then
				toX1,toY1 = self.world.map:getXYLengthCross(targetX,targetY,newtoX,newtoY,safeDis) 
				ret,newtoX1,newtoY1=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,newtoX+toX1,newtoY+toY1) 
				local d1 = self.AIobj:distance(newtoX1,newtoY1)
				self.AIobj:D("英雄预警3".." newtoX1:"..newtoX1.." newtoY:"..newtoY1.." d:"..d1)
				toX2,toY2 = self.world.map:getXYLengthCross(targetX,targetY,newtoX,newtoY,-safeDis) 
				ret,newtoX2,newtoY2=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,newtoX+toX2,newtoY+toY2) 
				local d2 = self.AIobj:distance(newtoX2,newtoY2)
				self.AIobj:D("英雄预警4".." newtoX2:"..newtoX2.." newtoY2:"..newtoY2.." d:"..d2)
				toX3,toY3 = self.world.map:getXYLength(targetX,targetY,newtoX,newtoY,-safeDis) 
				ret,newtoX3,newtoY3=self.world.map:findPointStraightLineNearest(self.AIobj.posX,self.AIobj.posY,newtoX+toX3,newtoY+toY3) 
				local d3 = self.AIobj:distance(newtoX3,newtoY3)
				self.AIobj:D("英雄预警5".." newtoX3:"..newtoX3.." newtoY3:"..newtoY3.." d:"..d3)
				if line then
					--假如是直线则屏蔽和直线的平行方向
					d=0
					d3=0
					self.AIobj:D("英雄预警  躲避直线攻击")
				end

				local solist = {{d=d,x=newtoX,y=newtoY},{d=d1,x=newtoX1,y=newtoY1},{d=d2,x=newtoX2,y=newtoY2},{d=d3*0.3,x=newtoX3,y=newtoY3}}
				self.world.tSort(solist,function( a1,b1 )
					return a1['d'] > b1['d']
				end)
				newtoX = solist[1]['x']
				newtoY = solist[1]['y']

				self.AIobj:D("英雄预警6".." newtoX:"..newtoX.." newtoY:"..newtoY.." d:"..solist[1]['d'])
			end
		end

		--判断是翻滚还是跑动
		local sk = self.AIobj.attribute.skills[8]
		local gt = self.world:getGameTime()
		if sk.lastCoolDownTime<gt and  (self.AIobj.attribute.SKILLOPEN[8]==nil or self.AIobj.attribute.SKILLOPEN[8]==1) then
			--SHeroBase:skillAttack(mode,itemID,positionX,positionY,force,fromClientSide,nPara,pPara)
			self.AIobj:D("翻滚:",self.AIobj.itemID,self.world.cjson.encode(self.AIobj.attribute.SKILLOPEN))
			self.AIobj:skillAttack(8,0,newtoX,newtoY,false,true)
		else
			if newtoX~=nil and newtoY~=nil then
				self.AIobj:moveTo(newtoX,newtoY)
			end
		end
		self.AIobj.AIlastATKTime = self.AIobj.moveToEndTime + 0.5
		self.autoMoveToAlerTime = self.AIobj.moveToEndTime  + self.AIobj.gxAIlist.warnReactionTime   
		moveRet = true
	end
	return moveRet
end

--野外1号方案AI
function SAIHero:world101AutoFight()
	if self.AIobj.isAI and (self.worldAIStartTime + self.worldAIDead) > self.world:getGameTime() then

		self.worldAIATKStartTime=self.AIobj.moveToEndTime

		--打怪AI开启战斗
		if self.worldAIATKStartTime<self.world:getGameTime() and self.worldAIATKEndTime>self.world:getGameTime() then
			--执行战斗AI
			return false
		end

		--被人攻击开启AI
		if self.AIobj.lastHurtItemID>0  then
			local obj = self.world.allItemList[self.AIobj.lastHurtItemID]
			if obj~=nil and not obj:isDead() and (self.AIobj.lastHurtTime+10)>self.world:getGameTime() then
				self.worldAICounterAttack=self.AIobj.lastHurtItemID
				return false
			end
		end
		--恢复正常地图AI
		self.worldAICounterAttack=0


		return true
	else
		return false
	end
end

--野外闲逛ai
function SAIHero:world101AutoMove()
	--AI溜达够了
	if self.world:getGameTime()>(self.worldAIStartTime + self.worldAIDead) or (self.worldAIOfflineTime>0 and self.world:getGameTime()>self.worldAIOfflineTime) then
		--需要擦除AI
		self.world.playerList[self.AIobj.itemID]['online'] = false
		self.world.playerList[self.AIobj.itemID]['offLineTime']=self.world.gameTime-self.world.gameRoomSetting.offlineRemoveWaitTime
		self.AIobj:D("地图AI 离线 itemID:"..self.AIobj.itemID,self.AIobj.posX,self.AIobj.posY)
		return true
	end


	if self.AIobj.isAI and (self.worldAIStartTime + self.worldAIDead) > self.world:getGameTime() and self.worldAINextTime <  self.world:getGameTime() and self.worldAICounterAttack==0 then
		--切换AI的行为
		if self.world:getGameTime()>self.worldAINextModeTime then
			self.worldAIMode = self.world.formula:getRandnum(1,5)
			self.worldAINextModeTime = self.world:getGameTime() + self.world.formula:getRandnum(45,75)
			self.AIobj:D("地图AI itemID:"..self.AIobj.itemID," 切换模式为:",self.worldAIMode," 下次切换模式时间为:",self.worldAINextModeTime," 当前时间为:",self.world:getGameTime(),self.AIobj.posX,self.AIobj.posY)
		end

		--跑出生点
		if self.worldAIMode==1 then
			local toX,toY = self:getWorldAIPOS(1)
			self.AIobj:setMoveTarget(toX,toY)
			local ret,x,y = self.world.map:checkBlock(self.AIobj.posX,self.AIobj.posY,toX,toY)
			self.AIobj:D("地图AI itemID:"..self.AIobj.itemID," 跑出生点",toX,toY,self.AIobj.posX,self.AIobj.posY,ret,x,y)
			self.worldAINextTime=self.AIobj.moveToEndTime + self.world.formula:getRandnum(self.world.setting.world1AIPOS1Time[1],self.world.setting.world1AIPOS1Time[2])
			self.worldAINextModeTime=self.AIobj.moveToEndTime + self.world.formula:getRandnum(2,5)
		end
		--散步
		if self.worldAIMode==2 then
			local toX,toY = self:getWorldAIPOS(2)
			self.AIobj:setMoveTarget(toX,toY)
			local ret,x,y = self.world.map:checkBlock(self.AIobj.posX,self.AIobj.posY,toX,toY)
			self.AIobj:D("地图AI itemID:"..self.AIobj.itemID," 散步",toX,toY,self.AIobj.posX,self.AIobj.posY,ret,x,y)
			self.worldAINextTime=self.AIobj.moveToEndTime + self.world.formula:getRandnum(self.world.setting.world1AIPOS2Time[1],self.world.setting.world1AIPOS2Time[2])
		end
		--找npc
		if self.worldAIMode==3 then
			local toX,toY = self:getWorldAIPOS(3)
			self.AIobj:setMoveTarget(toX,toY)
			local ret,x,y = self.world.map:checkBlock(self.AIobj.posX,self.AIobj.posY,toX,toY)
			self.AIobj:D("地图AI itemID:"..self.AIobj.itemID," 找npc",toX,toY,self.AIobj.posX,self.AIobj.posY,ret,x,y)
			self.worldAINextTime=self.AIobj.moveToEndTime + self.world.formula:getRandnum(self.world.setting.world1AIPOS3Time[1],self.world.setting.world1AIPOS3Time[2])
		end
		--找小怪点
		if self.worldAIMode==4 then
			local toX,toY = self:getWorldAIPOS(4)
			self.AIobj:setMoveTarget(toX,toY)
			local ret,x,y = self.world.map:checkBlock(self.AIobj.posX,self.AIobj.posY,toX,toY)
			self.AIobj:D("地图AI itemID:"..self.AIobj.itemID," 找小怪点",toX,toY,self.AIobj.posX,self.AIobj.posY,ret,x,y)
			self.worldAINextTime=self.AIobj.moveToEndTime + self.world.formula:getRandnum(self.world.setting.world1AIPOS4Time[1],self.world.setting.world1AIPOS4Time[2])
			self.worldAIATKStartTime=self.AIobj.moveToEndTime
			self.worldAIATKEndTime=self.worldAINextTime
		end
		--挂机 然后下线
		if self.worldAIMode==5 then
			local toX,toY = self:getWorldAIPOS(2)
			self.AIobj:setMoveTarget(toX,toY)
			local ret,x,y = self.world.map:checkBlock(self.AIobj.posX,self.AIobj.posY,toX,toY)
			self.AIobj:D("地图AI itemID:"..self.AIobj.itemID," 挂机散步",toX,toY,self.AIobj.posX,self.AIobj.posY,ret,x,y)
			self.worldAINextTime=self.AIobj.moveToEndTime + self.world.formula:getRandnum(120,150)
			self.worldAIOfflineTime=self.AIobj.moveToEndTime + self.world.formula:getRandnum(30,60)
		end

		return true
	else
		--self.AIobj:D("地图AI itemID:"..self.AIobj.itemID,"失败",self.AIobj.isAI,(self.worldAIStartTime + self.worldAIDead),self.worldAINextTime ,self.world:getGameTime(),self.worldAICounterAttack)
		return false
	end
end

function SAIHero:cleanWorldAI()
	self.worldAINextTime = 0
	self.worldAICounterAttack = 0
end

function SAIHero:getWorldAIPOS(type)
	-- body
	-- local alist = {{60,50}}
	-- local blist = {{150,60},{55,280},{150,275},{140,190}}
	-- local clist = {{65,45},{85,228},{108,208},{111,230}}
	-- local dlist = {{61,105},{49,214},{145,122},{104,270},{146,271}}
	local alist = self.world.setting.world1AIPOS1 
	local blist = self.world.setting.world1AIPOS2
	local clist = self.world.setting.world1AIPOS3
	local dlist = self.world.setting.world1AIPOS4

	local list = {}

	if type==1 then
		list = alist
	end
	if type==2 then
		list = blist
	end
	if type==3 then
		list = clist
	end
	if type==4 then
		list = dlist
	end

	self.AIobj:D("地图AI list",self.world.cjson.encode(list))
	local r = self.world.formula:getRandnum(1,#list)
	local randX = self.world.formula:getRandnum(-500,500)
	local randY = self.world.formula:getRandnum(-500,500)

	return list[r][1]+randX*0.01,list[r][2]+randY*0.01
end


--野外1号方案AI
function SAIHero:world1001AutoFight()
	
	if self.AIobj.statusList[41]~=nil or self.worldAIMode==5 then
		--self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 采集状态不动 护送回去")
		--采集状态不动 护送回去
		return true
	end

	if self.AIobj.isAI then

		--抢水晶
		if self.worldAIATKStartTime<self.world:getGameTime() and self.worldAIATKEndTime>self.world:getGameTime() and (self.worldAIMode==2 or self.worldAIMode==3) and self.AIobj.statusList[41]==nil then
			--self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 只抢水晶 释放采集")
			self.AIobj:skillAttack(9)
			return true
		end

		--AI开启战斗
		if self.worldAIATKStartTime<self.world:getGameTime() and self.worldAIATKEndTime>self.world:getGameTime() and self.worldAIMode==1 and self.worldAIMode~=5 then
			--执行战斗AI
			--self.AIobj:D("地图AI AI开启战斗")
			return false
		end
		--被人攻击开启AI
		if self.AIobj.lastHurtItemID>0 and self.worldAIMode~=5  then
			local obj = self.world.allItemList[self.AIobj.lastHurtItemID]

			local lastTime = 10
			if self.worldAIMode==2 then
				lastTime = 3
			end
			if  obj~=nil and not obj:isDead() and (self.AIobj.lastHurtTime+lastTime)>self.world:getGameTime() then
				self.worldAICounterAttack=self.AIobj.lastHurtItemID
				--self.AIobj:D("地图AI AI开启反击")
				return false
			end
		end
		--恢复正常地图AI
		self.worldAICounterAttack=0

		--self.AIobj:D("地图AI 不开AI开启反击")
		return true
	else
		return false
	end
end

--1001房抢水晶AI
function SAIHero:world1001AutoMove()

	--假如AI站在台子上 走下来
	if self.world.mAbs(self.AIobj.posX-self.AIobj.initX)<=2  and self.world.mAbs(self.AIobj.posY-self.AIobj.initY)<=2 then
		if self.AIobj.teamOrig=="A" then
			self.AIobj:moveTo(self.AIobj.initX+self.world.formula:getRandnum(-8,8),self.AIobj.initY+20,false,10)
		else
			self.AIobj:moveTo(self.AIobj.initX+self.world.formula:getRandnum(-8,8),self.AIobj.initY-20,false,10)
		end
		self.worldAINextModeTime=self.AIobj.moveToEndTime 
		self.worldAINextTime=self.worldAINextModeTime

		self.worldAIMode=0
		self.worldAICounterAttack=0
		self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 从复活点跑出来")
	end

	if ((self.AIobj.teamOrig=="A" and self.AIobj.statusList[51]~=nil) or (self.AIobj.teamOrig=="B" and self.AIobj.statusList[37]~=nil)) then
		self.worldAINextTime = 0
		self.worldAICounterAttack=0
		self.AIobj:D("地图AI  身上拿着水晶:"..self.AIobj.itemID)
	end

	--行为切换
	if self.AIobj.isAI  and self.worldAINextTime <  self.world:getGameTime() and self.worldAICounterAttack==0 and self.AIobj.statusList[41]==nil then

		--护送回去
		if (self.AIobj.teamOrig=="A" and self.AIobj.statusList[51]~=nil) or (self.AIobj.teamOrig=="B" and self.AIobj.statusList[37]~=nil) then
			self.worldAIMode=4
			local itemID=0
			if self.AIobj.teamOrig=="A" then
			    itemID=self.world.gameFlag['flag'.."A"..'ID']
			else
				itemID=self.world.gameFlag['flag'.."B"..'ID']
			end
			local obj = self.world.allItemList[itemID] 
			if obj~=nil and  not obj:isDead() and (
				   (self.AIobj.teamOrig=='A' and obj.attribute.roleId~=138) 
				or (self.AIobj.teamOrig=='B' and obj.attribute.roleId~=139) )   then
				self.AIobj:setMoveTarget(obj.posX+2,obj.posY+2)
				self.worldAINextTime = self.AIobj.moveToEndTime
				self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 护送水晶回去")
				self.worldAIMode=5
			else
				--家里的台子被人抢了 打架去
				self.worldAIMode=1
				self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 家里的台子被人抢了 打架去")
			end
		else
			local itemID=0
			if self.AIobj.teamOrig=="A" then
			    itemID=self.world.gameFlag['flag'.."B"..'ID']
			else
				itemID=self.world.gameFlag['flag'.."A"..'ID']
			end
			--self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 只抢水晶 跑去抢水晶 itemID:",itemID)
			local obj = self.world.allItemList[itemID] 

			if obj~=nil and  not obj:isDead() and (
				   (self.AIobj.teamOrig=='B' and obj.attribute.roleId==101) 
				or (self.AIobj.teamOrig=='A' and obj.attribute.roleId==137) ) then
				--self.worldAIMode = 21
			else
				--水晶被人拿了 打架去
				self.worldAIMode = 1
			end

		end

		--切换AI的行为
		if self.world:getGameTime()>self.worldAINextModeTime and self.worldAIMode~=5 then
			self.worldAIMode = self.world.formula:getRandnum(1,3)
			--self.worldAIMode = 2
			self.worldAINextModeTime = self.world:getGameTime() + self.world.formula:getRandnum(40,60)
			self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 切换模式为:",self.worldAIMode," 下次切换模式时间为:",self.worldAINextModeTime," 当前时间为:",self.world:getGameTime())
		end

		--只打架
		if self.worldAIMode==1 then
			self.worldAINextTime=self.worldAINextModeTime
			self.worldAIATKStartTime=self.world:getGameTime()
			self.worldAIATKEndTime=self.worldAINextTime
			self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 只打架",self.worldAIATKStartTime,self.worldAIATKEndTime)
		end
		--只抢水晶
		if self.worldAIMode==2 then
			local itemID=0
			if self.AIobj.teamOrig=="A" then
			    itemID=self.world.gameFlag['flag'.."B"..'ID']
			else
				itemID=self.world.gameFlag['flag'.."A"..'ID']
			end
			--self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 只抢水晶 跑去抢水晶 itemID:",itemID)
			local obj = self.world.allItemList[itemID] 

			if obj~=nil and  not obj:isDead() and (
				   (self.AIobj.teamOrig=='B' and obj.attribute.roleId==101) 
				or (self.AIobj.teamOrig=='A' and obj.attribute.roleId==137) ) and (self.world.isNoAITeam==nil or (self.world.isNoAITeam~=nil and self.AIobj.teamOrig==self.world.isNoAITeam ) ) and (self.world.gameFlag.pvpPickUp==nil or self.world.gameFlag.pvpPickUp) then
				self.AIobj:setMoveTarget(obj.posX+self.world.formula:getRandnum(-200,200)*0.01,obj.posY+self.world.formula:getRandnum(-200,200)*0.01)
				self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 只抢水晶 跑去抢水晶",obj.posX,obj.posY,obj.attribute.roleId,self.AIobj.teamOrig,self.world.isNoAITeam)
				self.worldAINextTime=self.AIobj.moveToEndTime + self.world.formula:getRandnum(2,3)
				self.worldAIATKStartTime=self.AIobj.moveToEndTime
				self.worldAIATKEndTime=self.worldAINextTime
			else
				--水晶被人拿了 打架去
				self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 水晶被人拿了 打架去")
				self.worldAIMode=1
				self.worldAINextTime=self.worldAINextModeTime
				self.worldAIATKStartTime=self.world:getGameTime()
				self.worldAIATKEndTime=self.worldAINextTime
			end
		end

		--自己家水晶掉了。。。捡回来
		if self.worldAIMode==3 then
			local itemID=0
			if self.AIobj.teamOrig=="A" then
			    itemID=self.world.gameFlag['flag'.."A"..'ID']
			else
				itemID=self.world.gameFlag['flag'.."B"..'ID']
			end
			--self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 只抢水晶 跑去抢水晶 itemID:",itemID)
			local obj = self.world.allItemList[itemID] 

			
			 if obj~=nil and  not obj:isDead() and (
				   (self.AIobj.teamOrig=='A' and obj.attribute.roleId==138) 
				or (self.AIobj.teamOrig=='B' and obj.attribute.roleId==139) ) and (self.world.isNoAITeam==nil or (self.world.isNoAITeam~=nil and self.AIobj.teamOrig==self.world.isNoAITeam ) ) and (self.world.gameFlag.pvpPickUp==nil or self.world.gameFlag.pvpPickUp) then

				self.AIobj:setMoveTarget(obj.posX+1,obj.posY+1)
				self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 自己家水晶掉了。。。捡回来",obj.posX,obj.posY)
				self.worldAINextTime=self.AIobj.moveToEndTime + self.world.formula:getRandnum(1,2)
				self.worldAIATKStartTime=self.world:getGameTime()
				self.worldAIATKEndTime=self.worldAINextTime
			else
				--水晶没掉 打架去
				if (self.AIobj.teamOrig=="A") then
					teamlist=self.world.itemListFilter.heroTeamBList
				else
					teamlist=self.world.itemListFilter.heroTeamAList
				end

				local toatk=false
				for k,v in pairs(teamlist) do
					if (v.teamOrig=="A" and v.statusList[51]~=nil) or (v.teamOrig=="B" and v.statusList[37]~=nil) then
						local d = self.AIobj:distance(v.posX,v.posY)
						if d>8 then
							self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 水晶被人拿了 去追",v.posX,v.posY)
							self.AIobj:setMoveTarget(v.posX,v.posY)
							toatk=true
						else
							self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 水晶被人拿了  追到了 打架",self.world.isNoAITeam,self.AIobj.teamOrig)	
							self.worldAIMode=1
							self.worldAINextTime=self.worldAINextModeTime
							self.worldAIATKStartTime=self.world:getGameTime()
							self.worldAIATKEndTime=self.worldAINextTime
							toatk=true
						end
					end 
				end

				--水晶已归位 打架去
				if not toatk then
					self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 水晶已归位 打架去",self.world.isNoAITeam,self.AIobj.teamOrig)	
					self.worldAIMode=1
					self.worldAINextTime=self.worldAINextModeTime
					self.worldAIATKStartTime=self.world:getGameTime()
					self.worldAIATKEndTime=self.worldAINextTime
				end

			end
		end
		-- roleId==101 or roleId==138  A队水晶
		-- roleId==137 or roleId==139  B队水晶
		-- local itemID=0
		-- if self.AIobj.teamOrig=="A" then
		--     itemID=self.world.gameFlag['getFlag'.."B"..'ID']
		-- else
		-- 	itemID=self.world.gameFlag['getFlag'.."A"..'ID']
		-- end
		-- --护送
		-- if self.worldAIMode==3 then
		-- 	local toX,toY = self:getWorldAIPOS(3)
		-- 	self.AIobj:setMoveTarget(toX,toY)
		-- 	self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 找npc",toX,toY)
		-- 	self.worldAINextTime=self.AIobj.moveToEndTime + self.world.formula:getRandnum(1,7)
		-- end
		-- --找小怪点
		-- if self.worldAIMode==4 then
		-- 	local toX,toY = self:getWorldAIPOS(4)
		-- 	self.AIobj:setMoveTarget(toX,toY)
		-- 	self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 找小怪点",toX,toY)
		-- 	self.worldAINextTime=self.AIobj.moveToEndTime + self.world.formula:getRandnum(10,30)
		-- 	self.worldAIATKStartTime=self.AIobj.moveToEndTime
		-- 	self.worldAIATKEndTime=self.worldAINextTime
		-- end
		-- --挂机 然后下线
		-- if self.worldAIMode==5 then
		-- 	local toX,toY = self:getWorldAIPOS(2)
		-- 	self.AIobj:setMoveTarget(toX,toY)
		-- 	self.AIobj:D("地图AI itemID:",self.AIobj.itemID," 挂机散步",toX,toY)
		-- 	self.worldAINextTime=self.AIobj.moveToEndTime + self.world.formula:getRandnum(300,600)
		-- 	self.worldAIOfflineTime=self.AIobj.moveToEndTime + self.world.formula:getRandnum(30,60)
		-- end

		return true
	else
		return false
	end
end

return SAIHero 
