#!/bin/bash

touch /tmp/kill3000
touch /tmp/kill3001
touch /tmp/kill3002
touch /tmp/kill3003
touch /tmp/kill3004
touch /tmp/kill3007
touch /tmp/kill3008
touch /tmp/kill3010
touch /tmp/kill3012
touch /tmp/kill3013
touch /tmp/kill3014
touch /tmp/kill3015
touch /tmp/kill3016
touch /tmp/kill3017
touch /tmp/kill3018
touch /tmp/killJS
touch /tmp/killCH
touch /tmp/killTEST
touch /tmp/killALL
