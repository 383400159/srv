local SBuffAttribute = class("SBuffAttribute")


--- Constructor
-- @param SAttribute attribute - attribute object
-- @return null
function SBuffAttribute:ctor(attribute,readonly)
	if self.className==nil then
		self.className = "SBuffAttribute"
	end

	self.attribute = attribute
	self.readonly = readonly or false
	self.mIsDirty = false

	self.attr = {}
	self:__createAttr()

	self.buffValue = 0
	self.HPBuff = {}
	self.sSub = string.sub 
	self.tonumber = tonumber 
	--重设相关参数  IMMUNECONTROL 免疫控制技能（击飞、击倒、眩晕DIZZY、沉默SILIENCE、嘲讽OUTCTL、石化STONE、麻痹PARALYSIS、冰封FROZEN、睡眠SLEEP）
	-- IMMUNEDEBUFF 免疫负面效果（中毒POISON、出血BLEED、灼伤BURN、属性下降DEF,CRI,ATK,MSPD,MDEF,HP,HIT,DODGE,ATKDIS）
	self.IMMUNECONTROLtb = {
		DIZZY = 0,
		DIZZYNOEFFECT = 0,
		SILIENCE = 0,
		OUTCTL = 0,
		STONE = 0,
		PARALYSIS = 0,
		FROZEN = 0,
		SLEEP = 0,
	}
	self.IMMUNEDEBUFFtb = {
		POISON = 0,
		BLEED = 0,
		BURN = 0,
		DEF = 0,
		CRI = 0,
		ATK = 0,
		MSPD = 0,
		MDEF = 0,
		HP = 0,
		HIT = 0,
		DODGE = 0,
		ATKDIS = 0,
	}

end


--- Reuse
-- @param SAttribute attribute - attribute object
-- @return null
function SBuffAttribute:reuse(attribute,readonly)
	self:reset()
	self.attribute = attribute
	self.readonly = readonly or false
end


--- reset value
-- @return null
function SBuffAttribute:reset()
	self.buffValue = 0
	self.mIsDirty = false
	self:__createAttr()
	self.HPBuff = {}
end

function SBuffAttribute:__createAttr()
	local attr = self.attr
	--物理防御
	attr.DEF=0
	--晕眩
	attr.DIZZY = 0
	attr.DIZZYNOEFFECT = 0
	--暴击率提升	
	attr.CRI = 0
	--攻击力
	attr.ATK = 0
	--移动速度
	attr.MSPD = 0
	--魔法防御
	attr.MDEF = 0
	--生命值
	attr.HP = 0
	--命中率
	attr.HIT = 0
	--额外生命值
	attr.HPEXTRA = 0
	--闪避率提升
	attr.DODGE = 0

	--最大值
	attr.MaxHP = 0
	attr.MaxMP = 0

	--被治疗量降低 不是吸收
	attr.BECURE = 0
	--所受物理伤害增加 比例
	attr.BEADHURT = 0
	attr.BEAPHURT = 0
	attr.BEALLHURT = 0
	--全吸收治疗量
	attr.ABSORDCURE = 0
	attr.MAXABSORDCURE = 0
	--物理吸收 但是不减少伤害
	attr.HURTDESTROY = 0
	attr.MAXHURTDESTROY = 0
	--造成的仇恨值增加
	attr.THREATFIXVALUE = 0
	--造成的物理伤害提高
	attr.ADHURT = 0
	attr.APHURT = 0
	attr.ALLHURT = 0
	attr.BOSSREDUCECD=0
	--冰封
	attr.FROZEN = 0
	--中毒
	attr.POISON = 0
	--灼烧
	attr.BURN = 0
	--睡眠
	attr.SLEEP = 0
	--失控
	attr.OUTCTL = 0
	--出血
	attr.BLEED = 0
	--反噬
	attr.BITE = 0
	--反弹伤害 百分比
	attr.REBOUND = 0
	--反弹伤害 定值
	attr.REBOUNDFIX = 0
	--魔法反弹
	attr.REFLECTAP = 0
	attr.REFLECTAD = 0
 
	attr.LOSSHP = 0
	attr.AURA = 0
	--物理伤害减免
	attr.HURTAD=0
	attr.HURTAP=0
	--吸血
	attr.VAMPIREAD = 0
	attr.ATKDIS = 0
	attr.BUFFONLY = 0

	--击中减CD
	attr.CDTIMECLEARFIX = 0
	--不死
	attr.NODEAD = 0

	attr.SHIELD = 0
	attr.SENSE = 0

	attr.CHECKBULLETID = 0

	attr.PARALYSIS =0
	attr.IMMUNEAP = 0
	attr.IMMUNEAD = 0
	attr.SILIENCE = 0
	attr.STONE = 0
	--5技能特殊buff显示
	attr.ROLEBUFFSKILLA=0
	attr.IMMUNECONTROL = 0
	attr.IMMUNEDEBUFF = 0
	attr.INVICINBLE=0
	attr.NOINVICINBLE=0
	attr.STOPMOVE=0
	attr.className = self.className
	attr.func = self
	attr.buffParameter = {FIXHURT=0,FIXREHP=0}

	--每秒恢复HP MP的增加值
	attr.REHP = 0
	attr.REMP = 0

end

--- release
-- @return null
function SBuffAttribute:release()
	--print(debug.traceback("", 2))
	self.attribute.parent:D('jaylog SBuffAttribute:release')
	self.attribute = nil
end	

--- is de-buff
-- @return bool isDeBuff
function SBuffAttribute:isDeBuff()
	if self.buffValue<=0 then return true end
	return false
end


--- 检测有没有这个buff属性
-- @param string name - 需检测的name
-- @return bool 
function SBuffAttribute:isBuffAttribute(name)
	if self.attr[name]==nil then
		return false
	end
	return true
end


--- 检测有没有这个buff状态 例如晕眩 燃烧之类
-- @param string name - 需检测的name
-- @return bool 
function SBuffAttribute:isAttribute(name)
	if table.inTable(self.parent.world.gameRoomSetting.checkEffectStatusList,name) then
		return false
	end
	return true
end

--[[--

get this name attribute value
@param string name - attribute name
@return float value

]]
--- 获得buff参数的值 有则返回 没有返回0
-- @param string name - 需获得参数的name
-- @return int  
function SBuffAttribute:getVar(name)
	if self.attr[name]==nil then
		self.attribute.parent:D("missing attribute get "..name)
		return 0
	end
	return self.attr[name]
end

--[[--

set value to this name attribute 
@param string name - attribute name
@param float value - attribute value
@param bool isPercentage - is percentage
@return null

]]

--- 获得buff参数的值 有则返回 没有返回0
-- @param name string - 需获得参数的name
-- @param value int - 需获得参数的值
-- @return int 
function SBuffAttribute:setVar(name,value,rate,bufftime)
	local nameArr = string.split(name,'_')
	local debuff = false
	local name1 = nameArr[1]
	local name2 = nameArr[2]
	local name3 = nameArr[3]
	-- if #nameArr>0 then
	-- 	self.attribute.parent:D("SBuffAttribute:setVar name1:"..name1.." name2:"..(name2~=nil and name2 or "nil").." name3:"..(name3~=nil and name3 or "nil").." value:"..value)
	-- endsSub
	if (name3~=nil and (name3=='RATE' or self.tonumber(self.sSub(name3,-1))>0)) then
		return false
	end
	if (name2~=nil and self.tonumber(self.sSub(name2,-1))>0) then
		return false
	end
	if (name2~=nil and name2=='RATE') then
		rate = value
		value = bufftime
		debuff = true
	end
	if not self:isBuffAttribute(name1) then
		-- self.attribute.parent:D("missing attribute set "..name)
		return false
	end

	if (rate~=nil and rate>0) then
		math.randomseed(os.time())
		--self.world:setRandomSeed()
		local rand = math.random(1,100)
		--self.attribute.parent:D("SBuffAttribute name:"..name.." rand:"..rand.."  rate:"..rate.." roleId:"..self.attribute.roleId)
		self.attribute.parent.world:D("SBuffAttribute name:"..name.." rand:"..rand.."  rate:"..rate.." roleId:"..self.attribute.roleId)
		if rand>rate then return false end
	end

	if (name2=='DOWN' or name2=='DOWNFIX') then
		value = value * -1 
		self.attribute.parent:D("SBuffAttribute MaxHP value:"..value.." rold:"..self.attribute.roleId)
	end

	if (name2=='UP' or name2=='UPFIX') then
		value = value 
		self.attribute.parent:D("SBuffAttribute MaxHP value:"..value.." rold:"..self.attribute.roleId)
	end


	if self.attribute~=nil and self.attribute.baseTable[name1]~=nil and (name2=='UP' or name2=='DOWN') then
		value = self.attribute.baseTable[name1] * value * 0.01
	end
	if (name2=="BITEHURT") then
		self.attr.buffParameter[name1] = value
	end

	if (name2=='HURT') then
		value = self.attribute.baseTable.MaxHP * value * 0.01
		-- self.attribute.parent:D("HURT        MaxHP:"..self.attribute.baseTable.MaxHP )
		-- self.attribute.parent:D("HURT        value:"..value )
		self.attr.buffParameter.FIXHURT = self.attr.buffParameter.FIXHURT + value
		debuff = true
		self.HPBuff[name1..'_HURT'] = value
	end
	if (name2=='HURTFIX') then
		self.attr.buffParameter.FIXHURT = self.attr.buffParameter.FIXHURT + value
		debuff = true
		self.HPBuff[name1..'_HURT'] = value
	end
	if (name2=='REHP') then
		value = self.attribute.baseTable.MaxHP * value * 0.01
		self.attr.buffParameter.FIXREHP = self.attr.buffParameter.FIXREHP + value
		self.HPBuff[name1..'_REHP'] = value
	end
	if (name2=='REHPFIX') then
		self.attr.buffParameter.FIXREHP = self.attr.buffParameter.FIXREHP + value
		self.HPBuff[name1..'_REHP'] = value
	end
	if debuff then
		self.buffValue = self.buffValue - value
	else
		self.buffValue = self.buffValue + value		
	end

	--self.attribute.parent:D("setVar name1:"..name1)
	--刷新免控之类 NOINVICINBLE 忽视免控 只限软控制
	if (self.attribute.buffAttribute['IMMUNEDEBUFF']>0 or (self.attribute.buffAttribute['NOINVICINBLE']==0 and self.attribute.buffAttribute['INVICINBLE']>0) or self.attribute.parent.invincibleTime>self.attribute.parent.world.gameTime ) and (self.IMMUNEDEBUFFtb[name1]~=nil and (name2~=nil and (name2=='HURT' or name2 =='HURTFIX' or name2=='DOWN' )) ) then
		self.attribute.parent:D("刷新免疫负面效果（中毒POISON、出血BLEED、灼伤BURN、属性下降DEF name1:"..name1)
		--翻滚没办法免疫沉默
		if self.attribute.parent.world.gameRoomSetting.ISGVB~=1 or (self.attribute.parent.world.gameRoomSetting.ISGVB==1 and name1~="SILIENCE") then
			return false
		end 
	end

	if (self.attribute.buffAttribute['IMMUNECONTROL']>0 or self.attribute.buffAttribute['INVICINBLE']>0 or self.attribute.parent.invincibleTime>self.attribute.parent.world.gameTime ) and self.IMMUNECONTROLtb[name1]~=nil then
		-- self.attribute.parent:D("刷新免疫控制技能（击飞、击倒、眩晕DIZZY、沉默SILIENCE、嘲讽OUTCTL、石化STONE、麻痹PARALYSIS、冰封FROZEN、睡眠SLEEP）name1:"..name1)
		-- if self.attribute.buffAttribute['IMMUNECONTROL']>0 then
		-- 	self.attribute.parent:D("刷新免疫控制技能 IMMUNECONTROL"..self.attribute.buffAttribute['IMMUNECONTROL'])
		-- end
		-- if self.attribute.buffAttribute['INVICINBLE']>0 then
		-- 	self.attribute.parent:D("刷新免疫控制技能 INVICINBLE"..self.attribute.buffAttribute['INVICINBLE'])
		-- end
		-- if self.attribute.parent.invincibleTime>0 then
		-- 	self.attribute.parent:D("刷新免疫控制技能 invincibleTime"..self.attribute.parent.invincibleTime)
		-- end

		return false
	end

	self.attr[name1] = value

	--刷新总的参数
	if self.attribute~=nil and self.attribute.baseTable[name1] and not self.readonly then
		self.attribute:setValue(name1)
	end
	if value~=0 then
		self.mIsDirty = true
	end

	return true
end

--- 去掉持續 加減HP buff
-- @param HPBuffList table - 加減HP buff
-- @return clear bool - true = all clear
function SBuffAttribute:removeHPBuff(HPBuffList)
	--self.attribute.parent:D("removeHPBuff............feng")
	self.attr.buffParameter.FIXHURT = 0
	self.attr.buffParameter.FIXREHP = 0
	for k,v in pairs(self.HPBuff) do
		self.attribute.parent:D("removeHPBuff............feng.oldk",k)
		if table.inTable(HPBuffList,v)~=nil then
			self.HPBuff[k] = nil
			self.attribute.parent:D("removeHPBuff............feng.oldk set nil",k)
		elseif string.find(k,'_HURT')~=nil then
			self.attr.buffParameter.FIXHURT = self.attr.buffParameter.FIXHURT + v
		elseif string.find(k,'_REHP')~=nil then
			self.attr.buffParameter.FIXREHP = self.attr.buffParameter.FIXREHP + v
		end
	end
	if self.attr.buffParameter.FIXHURT>0 or self.attr.buffParameter.FIXREHP>0 then
		return false
	end
	return true
end
--- 去掉DEBUFF
function SBuffAttribute:removeDEBUFF()
	self.attribute.parent:D("removeDEBUFF..........................")
	self.attr.buffParameter.FIXHURT = 0

	for k,v in pairs(self.IMMUNEDEBUFFtb) do
		self.attr[k] = 0
	end
	if self.attr.buffParameter.FIXHURT>0 or self.attr.buffParameter.FIXREHP>0 then
		return false
	end
	return true
end

--- 取得 加減HP buff
-- @return HPBuffList table - 加減HP buff
function SBuffAttribute:getHPBuff()
	-- self.attribute.parent:D("getHPBuff............feng")
	return self.HPBuff
end


--- 是否有數值的buff
-- @return isDirty bool - 有true
function SBuffAttribute:isDirty()
	return self.mIsDirty
end

function SBuffAttribute:checkDirty()
	local num = 0
	for k,v in pairs(self.attr) do
		if type(v)=='number' then
			num = num + v
		end
	end
	if num==0 then
		self.mIsDirty = false
	else
		self.mIsDirty = true
	end
	return self.mIsDirty
end


return SBuffAttribute
