
local SAttributeBoss = class("SAttributeBoss", require("gameroom.attribute.SAttribute"))

--- Constructor 
-- @param id int - obj ID
-- @param level int - level
-- @param parent obj - 父类
function SAttributeBoss:ctor(id,level,parent)

	if self.className==nil then
		self.className="SAttributeBoss"
	end
	self.skills={}
	SAttributeBoss.super.ctor(self,id,level,parent)
	self.actorType = 2

	if parent~=nil then
		self:__skills(id,parent)
	end
end




return SAttributeBoss
