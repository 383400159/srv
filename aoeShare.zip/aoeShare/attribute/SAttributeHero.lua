
local SAttributeHero = class("SAttributeHero", require("gameroom.attribute.SAttribute"))

--- Constructor 
-- @param id int - obj ID
-- @param level int - level
-- @param parent obj - 父类
function SAttributeHero:ctor(id,level,parent)

	if self.className==nil then
		self.className="SAttributeHero"
	end
	self.skills={}
	self.actorType = 0
	SAttributeHero.super.ctor(self,id,level,parent)
	self.parent=parent
	self.AIRoleSetting = {}
	if parent~=nil then
		self:__skills(id,parent)
	end

	-- parent.world.playerList[parent.itemID]['playerJson']['energyData']={}
	-- parent.world.playerList[parent.itemID]['playerJson']['energyData']['1'] = {angelKey='TRIGGERLOWER_HP',parameter={NODEAD_RATE=100,BUFFTIME=15,CDTIME=15}}
	-- parent.world.playerList[parent.itemID]['playerJson']['energyData']['2'] = {angelKey='BITE',parameter={BITE_RATE=100,REBOUND_HURT=100,BUFFTIME=15,CDTIME=5}}
	-- parent.world.playerList[parent.itemID]['playerJson']['energyData']['3'] = {angelKey='IRON',parameter={IRON_RATE=100,IMMUNEAD_RATE=100,BUFFTIME=15,CDTIME=5}}
	self.energyBoard = require("gameroom.SEnergyBoard").new(parent,parent.world.playerList[parent.itemID]['playerJson']['energyData'])

	--self.parent:D('jaylog SAttributeHero:ctor end')

end

function SAttributeHero:__load(id)
	--if self.parent.itemID<self.parent.world.gameRoomSetting['maxPlayer'] then
		-- print("playerList:",self.parent.world.cjson.encode(self.parent.world.playerList))
		-- print("itemID:",self.parent.itemID)
		local data = self.parent.world.playerList[self.parent.itemID]['playerJson']['Player']

		--self.parent:D('jaylog SAttributeHero:__load '..id..'====='..self.parent.world.cjson.encode(self.parent.world.playerList[self.parent.itemID]['playerJson']['Player']))

		self:__assignAttribute(data)
	--end
end

function SAttributeHero:__skills(id,parent)

	--加载普通技能
	local sql = ''
	if parent.world.sFind(parent.loginID,'xiaomazv')~=nil then
		sql = "select * from role_skill3 where roleID = '"..id.."' order by rank"
	else
	-- if parent.world.sFind(parent.loginID,'newskill')~=nil then
	-- 	sql = "select * from role_skill2 where roleID = '"..id.."' order by rank"
	-- else
		sql = "select * from role_skill where roleID = '"..id.."' order by rank"
	-- end
	end
	local data = parent.world:getDBData(sql)
	--print(debug.traceback("", 2))

	self.parent:D('__skills:'..id..' '..self.parent.world.cjson.encode(data))

	--print("data",self.parent.world.cjson.encode(data)) 
	table.sort(data,function( a1,b1 )
		return a1['rank'] < b1['rank']
	end)

	for k,v in pairs(data) do
		v['rank'] = tonumber(v['rank'])
		self.parent:D("v['rank']",v['rank'])
		--self.parent:D('skills new:'..self.parent.world.cjson.encode(v))
		self.skills[v["rank"]] = require("gameroom.SSkill").new(v)
		
		if self.skills[v["rank"]]['parameters']==nil then
			self.skills[v["rank"]]['parameters'] = {}
		end

		if self.skills[v["rank"]] ~=nil and v["rank"]<90 then
			self.parent:D("skillParam",parent.world.cjson.encode(self.parent.world.playerList[self.parent.itemID]['playerJson']['skillParam']))
			self.skills[v["rank"]]['parameters']=self.parent.world.playerList[self.parent.itemID]['playerJson']['skillParam'][""..v["rank"]]
			--self.parent:D('skill Params:'..self.parent.world.cjson.encode(self.parent.world.playerList[self.parent.itemID]['playerJson']['skillParam'][v["rank"]]))
		end
		-- for k1,v1 in pairs(self.skills[v["rank"]]) do
		-- 	if self.skills[v["rank"]]['parameters'][k1]~=nil then
		-- 		self.skills[v["rank"]][k1] = self.skills[v["rank"]][k1]+self.skills[v["rank"]]['parameters'][k1]
		-- 	end
		-- end

	end

		-- if v['parameter']~=nil then
		-- 	local l1=string.split(v['parameter'],';')
		-- 	for kl1,vl1 in pairs(l1) do
		-- 		local l2=string.splitNumber(vl1,'=')
		-- 		--加载英雄的PARA
		-- 		self.skills[v['rank']]['parameterArr'][l2[1]]=l2[2]
		-- 	end
		-- end

	--判断有没有魔灵
	-- self.parent.world.playerList[self.parent.itemID]['playerJson']['demonSkill']={}
	-- self.parent.world.playerList[self.parent.itemID]['playerJson']['demonSkill']['4'] = {demonID=6001,parameters={ATKDIS_UPFIX=100,CDTIME=15,APADJ=150,BACKWARD=300,BACKWARDSPEED=1500}}

		-- 14={demonID=6002,parameters={APADJ=150,BACKWARD=300,BACKWARDSPEED=1500}}
		-- 15={demonID=7001,parameters={APADJ=150,BACKWARD=300,BACKWARDSPEED=1500}}
		-- 16={demonID=7002,parameters={APADJ=150,BACKWARD=300,BACKWARDSPEED=1500}}
	-- self.parent:D("魔灵数据加载....."..self.parent.world.cjson.encode(self.parent.world.playerList[self.parent.itemID]['playerJson']))
	-- self.parent.world.playerList[self.parent.itemID]['playerJson']['skillDemon']={}
	-- -- self.parent.world.playerList[self.parent.itemID]['playerJson']['skillDemon']['11']={SILIENCE_RATE=100,BUFFTIME=5,demonID="6002",CDTIME=5,ADADJ=100}
	-- -- self.parent.world.playerList[self.parent.itemID]['playerJson']['skillDemon']['12']={APADJ=100,ATKDIS_UPFIX=100,CDTIME=5,demonID="6001"}
	-- self.parent.world.playerList[self.parent.itemID]['playerJson']['skillDemon']['13']={APADJ=100,CHAOS_RATE=100,DELAYTIME=2,BUFFTIME=5,CDTIME=5,demonID="7002"}
	-- self.parent.world.playerList[self.parent.itemID]['playerJson']['skillDemon']['14']={DELAYTIME=10,MSPD_DOWNFIX=0,MSPD_DOWNFIX_RATE=100,REINJUREDTIME2=3,demonID="7003",APADJ3=200,APADJ=100,BUFFTIME2=3,CDTIME=5,DIZZY_RATE2=100}
	-- --SLEEP_RATE=100;BUFFTIME=5;DELAYTIME=2;CDTIME=5
	-- self.parent.world.playerList[self.parent.itemID]['playerJson']['skillDemon']['11']={demonID="6003",CDTIME=5,ADADJ=1}
	-- self.parent.world.playerList[self.parent.itemID]['playerJson']['skillDemon']['12']={demonID="7001",CDTIME=5,ADADJ=1,SLEEP_RATE=100,BUFFTIME=5,REVIVEHP2=50,APADJ2=50}



	if  self.parent.world.playerList[self.parent.itemID]['playerJson']['skillDemon']~=nil then
		self.parent:D("魔灵数据加载....."..self.parent.world.cjson.encode(self.parent.world.playerList[self.parent.itemID]['playerJson']['skillDemon']))
		local skillDemon = self.parent.world.playerList[self.parent.itemID]['playerJson']['skillDemon']
		for k,v in pairs(skillDemon) do
			self.parent:D("魔灵数据加载 K:"..k.." V:"..self.parent.world.cjson.encode(v))
			local rank = tonumber(k)
			local demonID = v['demonID']
			local demonPara = v
			local sql = "select * from demon_skill where roleID = '"..demonID.."'"
			local data = parent.world:getDBData(sql)
			self.skills[rank] = require("gameroom.SSkill").new(data[1])
			self.skills[rank]['rank'] = rank
			self.skills[rank]['parameters'] = demonPara
			self.skills[rank]['demonID'] = demonID
			--添加魔灵obj world,heroObj,skillObj
			self.parent:D("新的 attributeHero")
			-- local demonList = {5001,5002,5003,6001,6002,6003,6004,6005,6006,6007,6008,6009,7001,7002,7003,7004,7005,7006}
			-- local newDemonID = 0
			-- for k,v in pairs(demonList) do
			-- 	if v==self.parent.world.tonumber(demonID) then
			-- 		newDemonID = demonID
			-- 	end
			-- end
			--self.skills[rank].demonObj = require("gameroom.demon.SDemon"..newDemonID).new(self.parent.world,self.parent,self.skills[rank])
			self.skills[rank].demonObj = require("gameroom.demon.SDemon"..demonID).new(self.parent.world,self.parent,self.skills[rank])
		end
	end

	local sql = "select * from AI_role where roleID = '"..id.."' and AIMode='"..self.parent.world.gameRoomInfo['worldMode'].."' and teamMode='0' "
	if self.parent.world.gameRoomInfo['worldSubMode']==1 then
		local teamMode = 0
		if self.parent.team=='A' then
			teamMode = 1
		else
			teamMode = 2
		end
		sql = "select * from AI_role where roleID = '"..id.."' and AIMode='5' and teamMode='"..teamMode.."'"
	end
	local data = parent.world:getDBData(sql)
	--self.parent:D("AIRoleSetting data:"..self.parent.world.cjson.encode(data))
	local newdata = data[1]
	--self.parent:D("AIRoleSetting newdata:"..self.parent.world.cjson.encode(newdata))
	self.AIRoleSetting=newdata
	self.AIRoleSetting['targetRolePower'] = string.splitNumber(self.AIRoleSetting['targetRolePower'], ',')
	self.AIRoleSetting['normalSkillList'] = string.splitNumber(self.AIRoleSetting['normalSkillList'], ',')
	self.AIRoleSetting['switchAtkModeA'] = string.splitNumber(self.AIRoleSetting['switchAtkModeA'], ',')
	self.AIRoleSetting['switchAtkModeB'] = string.splitNumber(self.AIRoleSetting['switchAtkModeB'], ',')
	self.AIRoleSetting['warnReactionTime'] = string.splitNumber(self.AIRoleSetting['warnReactionTime'], ',')
	self.AIRoleSetting['warnRate'] = string.splitNumber(self.AIRoleSetting['warnRate'], ',')
	self.AIRoleSetting['atkARate'] = string.splitNumber(self.AIRoleSetting['atkARate'], ',')
	self.AIRoleSetting['defRate'] = string.splitNumber(self.AIRoleSetting['defRate'], ',')
	self.AIRoleSetting['atkBRate'] = string.splitNumber(self.AIRoleSetting['atkBRate'], ',')
	self.AIRoleSetting['skillRate'] = string.splitNumber(self.AIRoleSetting['skillRate'], ',')
	self.AIRoleSetting['normalAtkRate'] = string.splitNumber(self.AIRoleSetting['normalAtkRate'], ',')
	self.parent:D("AIRoleSetting:"..self.parent.world.cjson.encode(self.AIRoleSetting))

end

function SAttributeHero:setSkillBaseValue(attr)
	self.parent:D("setSkillBaseValue  attr:"..self.parent.world.cjson.encode(attr))
	for k,v in pairs(attr) do
		local skillKey = tonumber(k)
		if self.skills[skillKey] ~=nil and skillKey<90 then
			self.parent:D("setSkillBaseValue k:"..skillKey.." v:"..self.parent.world.cjson.encode(v))
			self.skills[skillKey]['parameters']=v
		end
	end
end

--- 重刷圣灵数据
-- @param attr table - playerList[itemID]['playerJson']['skillDemon']
-- @return nil
function SAttributeHero:setDemonBaseValue(attr)
	local keepCD = {}
	for k,v in pairs(attr) do
		for k1,v1 in pairs(self.skills) do
			if v['demonID']==v1['parameters']['demonID'] then
				keepCD[tonumber(k)] = v1.cdtime
			end
		end
	end
	local num = self.parent.world.tNums(attr)
	local snum = 0
	for k,v in pairs(self.skills) do
		if k>=91 and k<=94 then
			snum = snum + 1
		end
	end
	if num<snum then
		for i=(94+num-snum),94 do
			self.skills[i] = nil
		end
	end
	for k,v in pairs(attr) do
		local rank = tonumber(k)
		local demonID = v['demonID']
		local demonPara = v
		local sql = "select * from demon_skill where roleID = '"..demonID.."'"
		local data = self.parent.world:getDBData(sql)
		self.skills[rank] = nil
		self.skills[rank] = require("gameroom.SSkill").new(data[1])
		self.skills[rank]['rank'] = rank
		self.skills[rank]['parameters'] = demonPara
		self.skills[rank]['demonID'] = demonID
		if keepCD[rank]~=nil then
			self.skills[rank].cdtime = keepCD[rank]
		end
		--添加魔灵obj world,heroObj,skillObj
		self.skills[rank].demonObj = require("gameroom.demon.SDemon"..demonID).new(self.parent.world,self.parent,self.skills[rank])
	end


	self.parent:syncSkill()
end


return SAttributeHero
