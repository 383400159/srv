
local SAttributeEnemy = class("SAttributeEnemy", require("gameroom.attribute.SAttribute"))

--- Constructor 
-- @param id int - obj ID
-- @param level int - level
-- @param parent obj - 父类
function SAttributeEnemy:ctor(id,level,parent)

	if self.className==nil then
		self.className="SAttributeEnemy"
	end

	-- self.enemyID = 0
	-- self.eType = 0
	-- self.moveMode = 0
	-- self.attackMode = 0
	
	self.parameterArr = {}
	-- 怪类型
	self.actorType = 1
	-- self.BulletSpeed = 1
	-- self.fightTime = 1
	self.skills = {}
	 
	SAttributeEnemy.super.ctor( self, id, level, parent)

	if parent~=nil then
		self:__skills(id,parent)
	end

	--加载parameterArr
	--if self.parent.world.enemyAll~=nil then
		--debuglog("加载怪物属性的parameterArr:"..self.parent.world.cjson.encode(self.parameterArr)..'  '..self.parent.world.cjson.encode(self.parent.world.enemyAll))
	--	self.parameterArr = self.parent.world.enemyAll[""..id].PARAM
	--end

	--self.buffAttribute = require("gameroom.attribute.SBuffAttribute").new(self).attr

end



return SAttributeEnemy
