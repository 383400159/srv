local SAttribute = class("SAttribute")


--- Constructor 
-- @param id int - obj ID
-- @param level int - level
-- @param parent obj - 父类
function SAttribute:ctor(id,level,parent)

	if self.className==nil then
		self.className="SAttribute"
	end

	
	self.parent = parent

	-- self.roleId = 1  -- 英雄ID
	self.roleId = id
	self.level = 0
	self.school = 0
	self.rebirth = 1
	self.rebirthTeam = 1
	self.HP = 100 
	self.MP = 9999
	self.HPEXTRA = 0
	self.MaxHPEXTRA = 0
	self.SHIELD = 0
	self.MaxHP =9999
	self.MaxMP =10000
	self.ATK = 100 
	self.DEF = 100
	self.EXCEPATKDIS=0
	self.MDEF = 100
	self.HIT = 100 
	self.DODGE = 100 
	self.CRI = 100 
	self.ASPD = 100
	self.ATKDIS = 1
	self.MSPD =100 
	self.REMP = 0
	self.REHP = 0
	self.FIRE = 0 
	self.ICE = 0 
	self.LIGHT = 0 
	self.POISON = 0
	self.HURTAD = 0
	self.HURTAP = 0
	self.AUTOHP = 0
	self.AUTOMP = 0
	--被治疗量降低 不是吸收
	self.BECURE = 1
	--所受物理伤害增加 比例
	self.BEADHURT = 1
	self.BEAPHURT = 1
	self.BEALLHURT = 1
	--全吸收治疗量
	self.ABSORDCURE = 0
	self.MAXABSORDCURE = 0
	--物理吸收 但是不减少伤害
	self.HURTDESTROY = 0
	self.MAXHURTDESTROY=0
	--造成的仇恨值增加
	self.THREATFIXVALUE = 1
	--造成的仇恨值增加
	self.THREAT = 0
	--造成的物理伤害提高
	self.ADHURT = 1
	self.APHURT = 1
	self.ALLHURT = 1
	--boss狂暴减cd
	self.BOSSREDUCECD = 1


	--半径 
	self.width = 1
	
	self.PATROLCD = 0
	self.PATROLRANGE = 7
	self.CHASERANGE = 7
	self.TYPEATK = 0
	self.ATTRNG = 1000 
	self.VISRNG = 1000

	self.HORSEID = 0
	self.HORSEMSPD = 0

	self.MSPDorg = 0
	--翅膀id
	self.WINGID = 0
	self.WINGSTAGE = 1
	self.WEAPONID = 0
	self.WINGHIDE = 0
	--魔灵
	self.DEMON1 = 0
	self.DEMON2 = 0
	self.DEMON3 = 0
	self.DEMON4 = 0
	--军阶
	self.GRADELEVEL = 0
	--同屏显示系数
	self.COEFFICIENT = 0
	--角色初始角度
	self.STANDPOINT = 0
	--圣灵
	self.ANGEL = ''
	--反弹伤害 百分比
	self.REBOUND = 0
	--反弹伤害 定值
	self.REBOUNDFIX = 0
	--反弹伤害 物理 百分比
	self.REFLECTAD = 0
	self.REFLECTAP = 0

	self.WEAPONLID = 0 --左手武器
	self.WEAPONRID = 0 --右手武器
	self.WEAPONLSTAGE = 0 --左手神装武器等级
	self.WEAPONRSTAGE = 0 --右手神装武器等级
	--攻击命中目标减cd（只限一个目标 不论击中多少人）
	self.CDTIMECLEARFIX = 0
	--是否有耐久为0的装备
	self.BADEQUIP = 0
	--技能开放列表
	self.SKILLOPEN = {}
	--忽视软控
	self.NOINVICINBLE = 0	
	--角色的parameter参数
	self.parameterArr = {}

	--基础参数table
	self.baseTable = {
		HP = 0 ,
		MP = 0 ,
		level = 0,
		school = 0,
		rebirth = 1,
		SHIELD = 0,
		HPEXTRA = 0,
		MaxHPEXTRA = 0,
		MaxHP =9999 ,
		MaxMP =1000 ,
		ATK = 0 ,
		ATKDIS = 1,
		EXCEPATKDIS=0,
		DEF = 0 ,
		MDEF = 0 ,
		HIT = 0 ,
		DODGE = 0 , 
		CRI = 0 ,
		ASPD = 0 ,
		MSPD = 0 ,
		FIRE = 0 ,
		REMP = 0 ,
		REHP = 0 ,
		AUTOHP = 0,
		AUTOMP = 0,

		--被治疗量降低 不是吸收
		BECURE = 1,
		--所受物理伤害增加 比例
		BEADHURT = 1,
		BEAPHURT = 1,
		BEALLHURT = 1,
		--全吸收治疗量
		ABSORDCURE = 0,
		MAXABSORDCURE = 0,
		--物理吸收 但是不减少伤害
		HURTDESTROY = 0,
		MAXHURTDESTROY = 0,
		--造成的仇恨值增加
		THREATFIXVALUE = 1,
		--造成的物理伤害提高
		ADHURT = 1,
		APHURT = 1,
		ALLHURT = 1,
		BOSSREDUCECD=1,

		--反弹伤害 物理 百分比
		REFLECTAD = 0,
		REFLECTAP = 0,

		ICE = 0 ,
		LIGHT = 0 , 
		POISON = 0 ,
		HURTAD = 0 ,
		HURTAP = 0 ,
		--半径 
		width = 1 ,
		PATROLCD = 0,
		PATROLRANGE = 7,
		CHASERANGE = 7,
		TYPEATK = 0,
		ATTRNG = 1000 ,
		VISRNG = 1000 ,
		CDTIMECLEARFIX = 0,
		WEAPONLID = 0 ,
		WEAPONRID = 0 ,
		WEAPONLSTAGE = 0, --左手神装武器等级
		WEAPONRSTAGE = 0, --右手神装武器等级

		REBOUND=0,
		REBOUNDFIX=0,
		HORSEID = 0,
		HORSEMSPD = 0,
		--翅膀id
		WINGID = 0,
		WINGSTAGE = 1,
		WINGHIDE = 0,
		--魔灵
		DEMON1 = 0,
		DEMON2 = 0,
		DEMON3 = 0,
		DEMON4 = 0,
		--军阶
		GRADELEVEL = 0,
		--同屏显示系数
		COEFFICIENT = 0,
		--角色初始角度
		STANDPOINT = 0,
		--是否有耐久为0的装备
		BADEQUIP = 0,
		--技能开放列表
		SKILLOPEN = {},
		--忽视软控
		NOINVICINBLE= 0,	
	}

	-- 我被这个pk杀了
	self.killByPlayerID = 0

	self.partType = 1 			--boss进入状态 1=P1 2=P2 3=P3
	self.partTypeStartTime = 0 			--boss进入状态的起始时间

	if self.actorType==nil then
		--self.actorType = 0 -- type (0=hero  = 0 1=enemy)
		self['actorType'] = 0
	end

	self.roleIdChange = 99999			--roleID转换，SActor:getAllInfo如此值不为99999则将roleId转为roleIdChange
	self.actorTypeChange = 99999	--actorType转换，SActor:getAllInfo如此值不为99999则将actorType转为actorTypeChange
	self.loginIDNotShow = 0				--名字不显示
	self.bloodNotShow = 0				--血条不显示

	self:__load(id)

	-- self.HP = self:getMaxHP()
	-- self.HPEXTRA = 0
	-- self.MaxHPEXTRA = 0
	-- self.MP = self:getMaxMP()
	--debuglog('jaylog SAttribute:ctor end')
end

--- 基础属性的最后结果 例如 HP = HP * (1+HP_UP-HP_DOWN) + ...... 
-- @param str string - value name
function SAttribute:setValue(str)
	if (str~='HP' and str~='MP' and str~='ABSORDCURE' and str~='HURTDESTROY' and str~='HPEXTRA') and self.buffAttribute[str]~=nil and self.baseTable[str]~=nil then
		self[str] = self.baseTable[str] + self.buffAttribute[str]
		if str=="MaxHP" and self.actorType==0 then
			if self.MaxHP<self.HP then
				self.HP=self.MaxHP
			end
			--debuglog("SAttribute:setValue str :"..str.." baseTable:"..self.baseTable[str].." buffAttribute:"..self.buffAttribute[str].." self:"..self[str])
		end

	end

end


--- 加载obj的属性参数
-- @param id int - obj ID
function SAttribute:__load(id)
	--获得服务端传来的playerJson

	local data = self.parent.world.attrData[""..id]
	if data==nil then
		data = {}
	end
	self:__assignAttribute(data)
end

--- 分配obj的属性参数
-- @param data table - db Data
function SAttribute:__assignAttribute(data)
	--加载db基础值
	for k,v in pairs(data) do
		if self.parent.world.gameRoomSetting['ISYW']==0 and k=='HP' then
			v = data['MaxHP']
		end
		if self.baseTable[k]~=nil then
			self.baseTable[k] = v
		end
		if self[k]~=nil then
			self[k] = v
		end 
		-- self.parent.world:D('jaylog SAttribute:__assignAttribute ',k,v)
		if k=="skillOpen" and v~=nil and v~='' then
			local idx = 1
			for i=8,1,-1 do
				self.baseTable['SKILLOPEN'][idx] = self.parent.world.tonumber(self.parent.world.sSub(v,i,i))
				self['SKILLOPEN'][idx] = self.parent.world.tonumber(self.parent.world.sSub(v,i,i))
				idx = idx + 1
				-- self.parent.world:D('jaylog SAttribute:__assignAttribute set skillOpen ',self.parent.world.cjson.encode(self.baseTable['SKILLOPEN']),self.parent.world.cjson.encode(self['SKILLOPEN']))
			end
		end
		-- if k=="HP" or k=="MP" then
		-- 	self.baseTable["Max"..k] = v
		-- 	self["Max"..k] = v
		-- end
		-- print("data k",k)
		-- print("data v",v)
	end

	self.buffAttribute = require("gameroom.attribute.SBuffAttribute").new(self).attr
	self.buffList = {}
	self.buffParameter = {}
end

--- 加载skill数据
-- @param id int - roleID
-- @return null
function SAttribute:__skills(id,parent)
	--debuglog("加载怪物属性:"..id)
	if self.parent.world.attrSkill[""..id]~=nil then
		for k,v in pairs(self.parent.world.attrSkill[""..id]) do
			v['rank'] = self.parent.world.tonumber(v['rank'])
			-- print("v['rank']",v['rank'])
			-- debuglog('enemy skills new:'..self.parent.world.cjson.encode(v))
			--self.skills[v["rank"]] = require("gameroom.SSkillB").new(v)
			self.skills[v["rank"]] = require("gameroom.SSkill").new(v)

			if self.skills[v["rank"]]['parameters']==nil then
				self.skills[v["rank"]]['parameters'] = {}
			end

			if self.skills[v["rank"]] ~=nil then
				--print("skillParam",	self.parent.world.enemySkillAll[v['enemyID']])
				self.skills[v["rank"]]['parameters']=v['PARAM']
			end
		end
	else
		for i=1,4 do
			--self.skills[i] = require("gameroom.SSkillB").new({})
			self.skills[i] = require("gameroom.SSkill").new({})
			if self.skills[i]['parameters']==nil then
				self.skills[i]['parameters'] = {}
			end
		end
	end
end

--- Release actor object
-- @return null
function SAttribute:release()
	-- if self.skills~=nil then
	-- 	for k,v in pairs(self.skills) do
	-- 		self.skills[k] = nil
	-- 	end
	-- end
	-- self.buffAttribute = nil
	--debuglog("SAttribute:release itemID:"..self.parent.itemID)
	--debuglog("SAttribute:release itemID:"..self.parent.itemID)
end	

--- __clone actor object
-- @return null
function SAttribute:__clone()
	return table.deepcopy(self)
end



--进game房取消level exp 相关
function SAttribute:addExp(exp)

end
--进game房取消level level 相关
function SAttribute:levelup(level)

end

function SAttribute:setHP(value)
	--self.HP = value
end

function SAttribute:setMP(value)
	--self.MP = value
end

--- 取最大HP值
-- @return HP int - 角色最大HP值
function SAttribute:getMaxHP()
	--self.parent:D("getMaxHP:",self.parent.itemID,self.MaxHP)
	return self.MaxHP  
end

--- 取最大MP值
-- @return MP int - 角色最大MP值
function SAttribute:getMaxMP()
	-- if self.FixMaxMP>0 then
	-- 	return self.FixMaxMP
	-- end
	return self.MaxMP 
end

function SAttribute:setBaseValue(attr)
	for k,v in pairs(attr) do
		if self.baseTable[k]~=nil then
			self.baseTable[k]=v
			self[k]=v
			self:setValue(k)
		end
	end
end

function SAttribute:cloneProperty(targetObj)
	for k,v in pairs(self.baseTable) do
		if self[k]~=nil then
			targetObj.attribute[k] = self[k]
			targetObj.attribute.baseTable[k] = v
		end
	end
	targetObj.attribute['level'] = self['level']
	local result = targetObj:getAllInfo()
	targetObj:updateSyncMsg({i=result})
end

return SAttribute
