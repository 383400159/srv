
local SAttributeNPC = class("SAttributeNPC", require("gameroom.attribute.SAttribute"))

--- Constructor 
-- @param id int - obj ID
-- @param level int - level
-- @param parent obj - 父类
function SAttributeNPC:ctor(id,level,parent)

	if self.className==nil then
		self.className="SAttributeNPC"
	end
	self.skills={}
	self.parameterArr = {}
	SAttributeNPC.super.ctor(self,id,level,parent)
	self.actorType = 3

	-- if parent~=nil then
	-- 	self:__skills(id,parent)
	-- end

	--debuglog("SAttributeNPC id:"..id)

end


return SAttributeNPC
