#!/bin/bash
cd /var/aoe_test/

timestr='1 2 3 4 5 6 7 8 9 10'
for i in ${timestr}; do

if [ -f "/tmp/kill3002" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3002 |grep "main" |awk '{print "sudo kill "$2}' |sh

#sleep 1

#sudo /var/aoe_test/MasterGame.sh

rm -f /tmp/kill3002
#else
#/usr/bin/php /home/aoeShare/kill3000.php

fi

if [ -f "/tmp/kill3000" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3000 |grep "main" |awk '{print "sudo kill "$2}' |sh

#sleep 1

sudo /var/aoe/MasterGame-now.sh

rm -f /tmp/kill3000
#else
#/usr/bin/php /home/aoeShare/kill3000.php

fi

if [ -f "/tmp/kill3004" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3004 |grep "main" |awk '{print "sudo kill "$2}' |sh

#sleep 1

sudo /var/aoe/MasterGame.sh

rm -f /tmp/kill3004
#else
#/usr/bin/php /home/aoeShare/kill3000.php

fi

if [ -f "/tmp/kill3001" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3001 |grep "main" |awk '{print "sudo kill "$2}' |sh
#sudo /var/aoe_w5test/MasterGame.sh
rm -f /tmp/kill3001
fi

if [ -f "/tmp/kill3003" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3003 |grep "main" |awk '{print "sudo kill "$2}' |sh
#sudo /var/aoe_w6test/MasterGame.sh
rm -f /tmp/kill3003
fi

if [ -f "/tmp/kill3007" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3007 |grep "main" |awk '{print "sudo kill "$2}' |sh
#sudo /var/aoe_w5/MasterGame.sh
rm -f /tmp/kill3007
fi

if [ -f "/tmp/kill3008" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3008 |grep "main" |awk '{print "sudo kill "$2}' |sh
#sudo /var/aoe_w6/MasterGame.sh
rm -f /tmp/kill3008
fi

if [ -f "/tmp/kill3010" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3010 |grep "main" |awk '{print "sudo kill "$2}' |sh
#sudo /var/aoe_w103/MasterGame.sh
rm -f /tmp/kill3010
fi

if [ -f "/tmp/kill3012" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3012 |grep "main" |awk '{print "sudo kill "$2}' |sh
sudo /var/aoe_pvp2/MasterGame.sh
rm -f /tmp/kill3012
fi

if [ -f "/tmp/kill3013" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3013 |grep "main" |awk '{print "sudo kill "$2}' |sh
#sudo /var/aoe_gvb2/MasterGame.sh
rm -f /tmp/kill3013
fi

if [ -f "/tmp/kill3014" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3014 |grep "main" |awk '{print "sudo kill "$2}' |sh
#sudo /var/aoe_gvb3/MasterGame.sh
rm -f /tmp/kill3014
fi

if [ -f "/tmp/kill3015" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3015 |grep "main" |awk '{print "sudo kill "$2}' |sh
#sudo /var/aoe_gvb4/MasterGame.sh
rm -f /tmp/kill3015
fi

if [ -f "/tmp/kill3016" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3016 |grep "main" |awk '{print "sudo kill "$2}' |sh
#sudo /var/aoe_gvbr5/MasterGame.sh
rm -f /tmp/kill3016
fi

if [ -f "/tmp/kill3017" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3017 |grep "main" |awk '{print "sudo kill "$2}' |sh
#sudo /var/aoe_gvb5/MasterGame.sh
rm -f /tmp/kill3017
fi

if [ -f "/tmp/kill3078" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3078 |grep "main" |awk '{print "sudo kill "$2}' |sh
sudo /var/aoe_gvb/MasterGame.sh
rm -f /tmp/kill3078
fi

if [ -f "/tmp/kill3018" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3018 |grep "main" |awk '{print "sudo kill "$2}' |sh
sudo /var/aoe_yw/MasterGame.sh
rm -f /tmp/kill3018
fi

if [ -f "/tmp/kill3019" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3019 |grep "main" |awk '{print "sudo kill "$2}' |sh
sudo /var/aoe_yw/MasterGame.sh
rm -f /tmp/kill3019
fi

if [ -f "/tmp/kill3069" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3069 |grep "main" |awk '{print "sudo kill "$2}' |sh
sudo /var/aoe_yw/MasterGame.sh
rm -f /tmp/kill3069
fi

if [ -f "/tmp/kill3071" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3071 |grep "main" |awk '{print "sudo kill "$2}' |sh
sudo /var/aoe_yw/MasterGame.sh
rm -f /tmp/kill3071
fi

if [ -f "/tmp/kill3072" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3072 |grep "main" |awk '{print "sudo kill "$2}' |sh
sudo /var/aoe_yw/MasterGame.sh
rm -f /tmp/kill3072
fi

if [ -f "/tmp/kill3073" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3073 |grep "main" |awk '{print "sudo kill "$2}' |sh
sudo /var/aoe_yw/MasterGame.sh
rm -f /tmp/kill3073
fi

if [ -f "/tmp/kill3074" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3074 |grep "main" |awk '{print "sudo kill "$2}' |sh
sudo /var/aoe_yw/MasterGame.sh
rm -f /tmp/kill3074
fi

if [ -f "/tmp/kill3075" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3075 |grep "main" |awk '{print "sudo kill "$2}' |sh
sudo /var/aoe_yw/MasterGame.sh
rm -f /tmp/kill3075
fi

if [ -f "/tmp/kill3076" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3076 |grep "main" |awk '{print "sudo kill "$2}' |sh
sudo /var/aoe_yw/MasterGame.sh
rm -f /tmp/kill3076
fi

if [ -f "/tmp/kill3077" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3077 |grep "main" |awk '{print "sudo kill "$2}' |sh
sudo /var/aoe_yw/MasterGame.sh
rm -f /tmp/kill3077
fi

if [ -f "/tmp/killJS" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3030 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3033 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3036 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3039 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3042 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3045 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3048 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3051 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3054 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3057 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3060 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3079 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3082 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3085 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3088 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3091 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3094 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3097 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3100 |grep "main" |awk '{print "sudo kill "$2}' |sh
#sudo /var/aoe_gvbjs/MasterGame.sh
#sudo /var/aoe_gvb2js/MasterGame.sh
#sudo /var/aoe_pvp2js/MasterGame.sh
#sudo /var/aoe_w5js/MasterGame.sh
#sudo /var/aoe_w6js/MasterGame.sh
#sudo /var/aoe_gvb3js/MasterGame.sh
#sudo /var/aoe_gvb4/MasterGame.sh
#sudo /var/aoe_gvb5/MasterGame.sh
sudo /var/aoe_gvb/MasterGame.sh
rm -f /tmp/killJS
fi

if [ -f "/tmp/killCH" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3211 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3212 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3213 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3214 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3215 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3216 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3217 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3218 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3219 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3220 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3011 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3063 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3064 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3065 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3066 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3067 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3068 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3031 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3034 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3037 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3040 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3043 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3046 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3049 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3052 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3055 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3058 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3061 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3080 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3083 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3086 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3089 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3092 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3095 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3098 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3101 |grep "main" |awk '{print "sudo kill "$2}' |sh
#sudo /var/aoe_gvbch/MasterGame.sh
#sudo /var/aoe_gvb2ch/MasterGame.sh
#sudo /var/aoe_pvp2ch/MasterGame.sh
#sudo /var/aoe_w5ch/MasterGame.sh
#sudo /var/aoe_w6ch/MasterGame.sh
#sudo /var/aoe_gvb3ch/MasterGame.sh
#sudo /var/aoe_gvb4/MasterGame.sh
#sudo /var/aoe_gvb5/MasterGame.sh
sudo /var/aoe_gvb/MasterGame.sh
rm -f /tmp/killCH
fi

if [ -f "/tmp/killTEST" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 3032 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3035 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3038 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3041 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3044 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3047 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3050 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3053 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3056 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3059 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3062 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3081 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3084 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3087 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3090 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3093 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3096 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3099 |grep "main" |awk '{print "sudo kill "$2}' |sh
ps aux |grep 3102 |grep "main" |awk '{print "sudo kill "$2}' |sh
#sudo /var/aoe_gvbtest/MasterGame.sh
#sudo /var/aoe_gvb2test/MasterGame.sh
#sudo /var/aoe_pvp2test/MasterGame.sh
#sudo /var/aoe_w5test/MasterGame.sh
#sudo /var/aoe_w6test/MasterGame.sh
#sudo /var/aoe_gvb4/MasterGame.sh
#sudo /var/aoe_gvb5/MasterGame.sh
sudo /var/aoe_gvb/MasterGame.sh
rm -f /tmp/killTEST
fi

if [ -f "/tmp/killALL" ];then
date +'%Y%m%d%H%m%S'
ps aux |grep 'main 3' |grep -v grep |awk '{print "sudo kill "$2}' |sh
ps aux |grep 'main 28' |grep -v grep |awk '{print "sudo kill "$2}' |sh
rm -f /tmp/killALL
fi

sleep 3

done
