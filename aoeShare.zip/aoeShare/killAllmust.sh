#!/bin/bash

ps aux |grep 'main 3' |grep -v grep |grep "main" |awk '{print "kill -9 "$2}' |sh

ps aux |grep 'main 28'|grep -v grep |grep "main" |awk '{print "kill -9 "$2}' |sh
ps aux |grep 'main 29'|grep -v grep |grep "main" |awk '{print "kill -9 "$2}' |sh
