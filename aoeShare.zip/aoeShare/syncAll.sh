#!/bin/bash
cd /home/aoeShare/
folder=`ls -1 /var/ |grep 'aoe' |grep -v 'aoe_test' |grep -v 'aoe_fb' |grep -v 'aoe_js' |grep -v 'aoe_dev2' |grep -v 'aoe_gvb' |grep -v 'aoe_ch' |grep -v 'aoe_pvp2'`

date
for name in ${folder}
do
echo "test:"$name
#ls -1 *.lua | awk -v var=$name '{ print "luajit -bg " $1 " /var/"var"/gameroom/" $1 } '
ls -1 *.lua | awk -v var=$name '{ print "luajit -bg " $1 " /var/"var"/gameroom/" $1 } ' | sh
ls -1 */*.lua | awk -v var=$name '{ print "luajit -bg " $1 " /var/"var"/gameroom/" $1 } ' | sh
done

date
sudo chown -R jay.staff /home/aoeShare/*
sudo chmod -R 770 /home/aoeShare/*
sudo chown -R jay.staff /var/aoe*/gameroom/*
sudo chmod -R 770 /var/aoe*/gameroom/*

date
if [ "$1" = "nokill" ];then
echo nokill
elif [ "$1" != "" -a "$1" != "nokill" ];then
sh /var/aoe/kill.sh $1
else
ps aux |grep 'main 3' | grep -v grep | awk '{print "sudo kill "$2 }'|sh
ps aux |grep 'main 28' | grep -v grep | awk '{print "sudo kill "$2 }'|sh
ps aux |grep 'main 29' | grep -v grep | awk '{print "sudo kill "$2 }'|sh
for name in ${folder}
do
echo "masterGame:"$name
sh /var/${name}/MasterGame.sh
done
fi
date
