#!/bin/bash
cd /home/aoeShare/

ls -1 *.lua | awk '{ print "luajit -bg " $1 " /var/aoe/gameroom/" $1 } ' | sh
ls -1 */*.lua | awk '{ print "luajit -bg " $1 " /var/aoe/gameroom/" $1 } ' | sh

#chown -R feng.staff /var/aoe/gameroom/*
#chmod -R 770 /var/aoe/gameroom/*
