local WorldBase = class("WorldBase",require("gameroomcore.World"))

worldForHero = 1

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function WorldBase:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="WorldBase"
	end

	--base math function
	self.mAbs = math.abs 
	self.mAcos = math.acos 
	self.mAsin = math.asin 
	self.mAtan = math.atan 
	self.mAtan2 = math.atan2 
	self.mCeil = math.ceil 
	self.mCos = math.cos 
	self.mDeg = math.deg 
	self.mExp = math.exp 
	self.mFloor = math.floor 
	self.mFrexp = math.frexp 
	self.mLdexp = math.ldexp 
	self.mLog = math.log 
	self.mLog10 = math.log10 
	self.mMax = math.max 
	self.mMin = math.min 
	self.mMod = math.mod 
	self.mRad = math.rad 
	self.mRandom = math.random 
	self.mRandomseed = math.randomseed 
	self.mRound = math.round 
	self.mSin = math.sin 
	self.mSqrt = math.sqrt 
	self.mTan = math.tan 
	self.mPow = math.pow 
	self.mPI = math.pi 
	self.sFormat = string.format 
	self.sFind = string.find 
	self.sSub = string.sub 
	self.sUpper = string.upper 
	self.sSplit = string.split 
	self.sSplitNumber = string.splitNumber 
	self.sMatch = string.match 
	self.sLen = string.len 
	self.tonumber = tonumber 
	self.tostring = tostring
	self.empty = table.empty
	self.gType = type 
	self.tSort = table.sort 
	self.tRemove = table.remove 
	self.tDeepcopy = table.deepcopy 
	self.tNums = table.nums 
	self.tMaxn = table.maxn 
	self.tInTable = table.inTable 
	self.tMerge = table.merge 

	self.Config = Config
	self.formula = require("gameroom.formula")
	self.socket = require("socket")

	WorldBase.super.ctor(self,gamePort,gameID,callBack)
	self.worldNum = 0
	
	-- 房间设置
	self.gameRoomSetting = {
		version = "1.0",
		byPassStatus = {},
		modelMaxRevive = 0,
		gameLimitedTime = 1800,
		maxPlayer = 10,
		gameStartPlayer = 1,
		soldierLevel = {S8M=944,S1town=955,S12M=966,S2town=977,S15M=988,Snotown=999},
		sendToClientStatusList = {DIZZY=3,FROZEN=19,POISON=20,BURN=21,SLEEP=22,PARALYSIS=23,BLEED=24,OUTCTL=32,IMMUNEAP=33,IMMUNEAD=34,SILIENCE=35,STONE=36,INVICINBLE=38,IMMUNECONTROL=39,IMMUNEDEBUFF=40,STOPMOVE=43,SENSE=46,MAXABSORDCURE=54,MAXHURTDESTROY=55,REFLECTAD=56,REFLECTAP=57,DIZZYNOEFFECT=103,ROLEBUFFSKILLA=993},
		checkEffectStatusList = {'DIZZY','FROZEN','POISON','BURN','SLEEP','PARALYSIS','BLEED','OUTCTL','IMMUNEAP','IMMUNEAD','SILIENCE','STONE','INVICINBLE','IMMUNECONTROL','IMMUNEDEBUFF','STOPMOVE','SENSE','ROLEBUFFSKILLA','MSPD','MAXABSORDCURE','MAXHURTDESTROY','REFLECTAD','REFLECTAP','HPEXTRA','ABSORDCURE','HURTDESTROY','DIZZYNOEFFECT'},
		cancelBulletStatus = {3,22,23,32,35,36,103},
		sendToClientStatusBuffList = {DEF_DOWN=1,DEF_UP=2,CRI_UP=4,CRI_DOWN=5,ATK_UP=6,ATK_DOWN=7,MSPD_UP=8,MSPD_DOWN=10,MDEF_DOWN=11,MDEF_UP=12,
		HP_UP=13,HP_DOWN=14,HIT_UP=15,HIT_DOWN=16,DODGE_UP=17,DODGE_DOWN=18,ATKDIS_DOWN=27,ATKDIS_UP=28,HURTAD_HURT=29,HURTAP_HURT=30,HPEXTRA_UP=58},
		modelall_maxRevive = 3,
		model9_maxRevive = 5,
		model10_maxRevive = 9,
		model10_needGold = 20,
		gameLimitedPoints = 500,
		enemyEnergy = 200,
		killEnergy = 1,
		sameTeam = false,
		teamMode = 1,
		hasVisibleZone = false,
		hasMapZone = false,
		genAIGroup = 1,
		ISPVP = 0,
		ISGVB = 0,
		ISYW = 0,
		ISLOCAL = 0,
		ISDEV = 0,
		ISWF = 0,
		ISSQLCACHE = 0,
		autoAddCreature = false,
		offlineRemoveWaitTime = 60,
		mIDIsLocalServer = {},	--7001
		sendToClientStatusListFinalSync = {3,5,8,10,19,20,21,22,23,24,32,36,26,37,51,38,41,42,43,44,50,53,54,55,56,57,58,103,994,995,996,997,999,993,4006,4007,4008,4010,4090,4113,4114,4115,4116,9,9001,9002,9003,9005},
		processCompleteEndStatusList = {41,991,99,100,605},
		extraEnemy = {146,151,152,154,157,159,261,266,269,270,272,273,280,281,282,285,286,287,288,289,290,299,300,301,303,308,310,311,312,314,319,345,356,357,358,501,502,503,504,505,506,507,508,509,510,511,512,537,547,701,702,703,751,752,753,754,764,801,802,803,903,920,964,970,978},
		extraNPC = {32008,32009,32010,32011,32012},
		moveEnemyINVICINBLE = {"109","114","166"},
		loadNoTeamAIWorld = {1001,1005,1006,1008},
		genAIPVPWorld = {1001,1005,1006,1007,1008},
		worldAIDefaultClose = {1001,1005,1006,1007,1008,3017,3014,3015,3011,3012,3013,2003,2007,2006},
		runningSpeed = 1,
		callTipsApiWaitTime = 2,
	}

	self.syncMsg = {} -- sync to client message
	
	--common list
	self.playerList = {}  -- player info
	self.kickedPlayerList = {}
	self.monitorPlayerList = {}
	self.bulletList = {}  -- bullet
	self.equipList = {}  -- equip item list ( preload item )
	self.allItemList = {}  -- all items

	self.itemListFilter = {	--以下所有list
		teamA = {},  -- team A (not team B, include monster)，不包括属性中包含NOBEFIGHT的角色
		teamB = {},  -- team B (not team A, include monster)，不包括属性中包含NOBEFIGHT的角色
		heroList = {},  -- heroes
		heroTeamAList = {},  -- team A hero
		heroTeamBList = {},  -- team B hero
		soldierList = {},  -- soldiers (not hero, include monster, tower)，不包括属性中包含NOBEFIGHT的角色
		towerList = {},  -- towers
		towerAList = {},  -- team A tower
		towerBList = {},  -- team B tower
		teamAMemberList = {},  -- team A exclude Tower/npc，不包括属性中包含NOBEFIGHT的角色
		teamBMemberList = {},  --team B exclude Tower/npc，不包括属性中包含NOBEFIGHT的角色
		teamCMemberList = {},	--team '' exclude Tower/npc，不包括属性中包含NOBEFIGHT的角色
		teamABMemberList = {}, -- AB队所有人，除了中立和npc，不包括属性中包含NOBEFIGHT的角色
		potionOnMapList = {},  -- map items
		npcList = {},
		noBeFightList = {}, -- 属性中带NOBEFIGHT的角色
		noBeFightBuffList = {}, -- 加了NOBEFIGHT BUFF时的角色
		noBeFightTeamA = {},
		noBeFightTeamB = {},
		noBeFightTeamC = {},
	}

	-- two teams points counter
	self.gameCounter = {
		pointsA = 0,
		pointsB = 0,
		towerA = 0,
		towerB = 0,
		towerC = 0,
		numOfKillA = 0,
		numOfKillB = 0,
		star = 3,
		timeStar = 1,
		deadStar = 2,
		heroA = 0,
		heroB = 0,
	}

	-- game over msg, pass to client
	self.gameOverMsg = {
		game = {
			--start=1,
			d=0,
			reset=1,
			pointsA = 0,  --team A points
			pointsB = 0,  --team B points
			w = 0,   --winner team
			gameTime = 0, --game total time
			star = 3,
			--bonus = {}  --all player's get: bonus
		}
	}

	--游戏内时间项
	self.waitingTime = 99         --匹配时等待时间
	self.gameTime = 0     --游戏时间
	self.roomStartTime = 0	--房间实际开始时间
	self.gameStartTime = 0	--游戏实际开始时间
	self.gameRemainStartTime = 0 --BOSS狂暴开始倒数时间
	self.gameRemainTime = 0	--游戏剩余时间
	self.serverTime = 0   --服务器时间
	self.startTime = 0    --开始时间
	self.readyTime = 0    --准备时间
	self.startWaitingTime = 0     
	self.syncRoomInfoTime = 0
	self.genMonsterTime = 0
	self.waitQuit = 0
	self.gameOverTime = 0     --游戏结算时间
	self.gameOverWaitTime = 0     --游戏结算等待时间
	self.AISpecialSkillTime = 0
	self.goToSiteCheckTime = 0 		--召回场内检测时间
	self.startCalDPSTime = 0 			--开始计算伤害时间
	self.startSyncEquipLosses = 0 		--开始sync装备损耗时间
	self.reviveTmpHeroTime = 0 			--重生AI HERO的时间

	--common setting
	self.bulletID = 1
	self.getEnergyPlayerID = 0    --记录当前取得水晶的玩家ID
	self.trySurrender = 0         --尝试投降
	self.status = self.WAITB      --游戏状态
	self.gameModel = 0            --游戏地图
	self.map = nil
	self.mapSize = 0
	self.mapModel = nil
	self.forceUpdate = false
	self.forceUpdateSoldier = false
	self.AIHelper = false
	self.lastSyncPingTime = 0
	--common boss setting GVB mode use
	self.partType = 1         --第几阶段 1、2、3、4
	self.partSubType = 1			--第几阶段的中间串插阶段
	self.partFinish = true		--阶段完成
	self.hadExcuteFlow = true	--执行成功
	self.partStartTime = 0    --阶段开始时间
	self.partMoveEndTime = 0 	--阶段中移动执行完毕的时间
	self.guideStep = 0 			--新手引导步骤ID
	self.guideStepNext = 0 		--下一步新手引导步骤ID
	self.guideStepFinish = false 	--引导步骤完成
	self.guideStepSetAutoBlock = false		--设置guildStep/flow时停止手动开启AI功能
	self.UIID = 0
	self.UIBoss = {}
	self.UIStep = 0

	self.gameOverURL = ""

	--game flow common setting
	-- self.genSoldierTime = 10
	-- self.genSoldierLastTime = 10
	-- self.genSoldier = {}
	-- self.genSoldierLevel = {}
	-- self.genSoldierType = 1
	-- self.genSoldierCount = 0
	
	-- self.surrenderWaitTime = 0
	-- self.surrenderTeam = ""
	-- self.surrenderTime = {}

	--获得中央水晶状态标记
	self.energyStatus = {
		s=37,
		t=300,
		r=300,
	}
	--game flag
	self.gameFlag = {
		getEnergyPlayerID = 0,
		lastCountTime = 0,
		killB1ID = 0, --杀中间水晶怪物的玩家
		lastEnergyID = 0, --上次站在水晶位置的玩家
		lastEnergyTime = 0, --上次开始咏唱的时间
		passTransitDoorNum = 0, --通过传送门人数
		passTransitDoorLastNum = 0,  --通过传送门剩余人数
		passTransitDoorID = {},
		isWin = 0,
		winTeam = '',
		firstKill = false,
		isGameOver = false,
		isGameOverTime = 0,
		readyGameOver = false,
		readyGameOverTime = 0,
		busyFlag = false,
		busyStart = false,
		resetHatredTime = 0,
		star1del = false,	--第一星已减标记
		star2del = false,	--第二星已减标记
		star3del = false,	--第三星已减标记
		pvpPickUp = true,	--pvp AI抢水晶开关
		pvpTakeTime = 0,
		pvpHeroReviveDelayStart = false,
		pvpHeroAReviveDelay = 0,
		pvpHeroBReviveDelay = 0,
		pvpHeroAReviveTime = 0,
		pvpHeroBReviveTime = 0,
		pvpAIFirstGoToEnergy = true,
		goToSiteItemID = 0,
	}

	--common flag
	self.comFlag = {
		debug = true,
		teamDebug = false,
	}

	--common attribute data
	self.attrData = {}
	self.attrSkill = {}
	--enemy data
	self.enemyAll = {}            --所有怪物的基础数据
	self.enemySkillAll = {}       --所有怪物的技能数据
	--boss data
	self.bossAll = {}
	self.bossSkillAll = {}
	self.bossFlow = {}						--boss房的流程设置
	--npc data
	self.npcAll = {}
	--仇恨列表
	self.HatredGrouplist = {}
	--怪物分组信息记录
	self.genMonster = {}
	self.genMonsterGroup = {}
	self.genMonsterGroupLevel = {}
	self.genMonsterGroupOrder = {}
	self.getMonsterIDInGroup = {}
	--野外地图生成物品List start
	--野外按group分组 记录分组数据
	self.genMonsterInGroup = {}
	--记录野怪生成的id
	self.getMonsterIDInGroup = {}
	--野怪检测刷新
	self.genItemTime = 0
	--缓存即将刷新的野怪list
	self.reviveMonsterlist = {}
	--野外genMonster
	self.genYWMonster = {}
	--野外按group分组 记录分组数据 Boss
	self.genBossInGroup = {}
	--记录野怪生成的id
	self.getBossIDInGroup = {}
	--缓存即将刷新的野怪list
	self.reviveBosslist = {}
	--野外genMonster
	self.genYWBoss = {}
	--野外genNPC
	self.genYWNPC = {}
	--野外按group分组 记录分组数据
	self.genEnemyAloneInGroup = {}
	--记录野怪生成的id
	self.genEnemyAloneIDInGroup = {}
	--缓存即将刷新的野怪list
	self.revivEnemyAlonelist = {}
	--野外genMonster
	self.genYWEnemyAlone = {}
	--野外地图生成物品List end
	--地上物品分组信息记录
	self.genPotion = {}
	self.genPotionGroup = {}
	--地图上检查生成AI英雄时间
	self.genTmpHeroTime = 0
	--地图上生成的AI英雄
	self.genTmpHero = {}
	--任务分组
	self.groupMapping = {}
	--AI posTargetList
	self.posTargetList = {}
	self.AITargetList = {}
	--status waiting for progress
	self.waitForProcessStatus = {}
	--AI Plan Data
	self.AIPlanData = {}
	--flow初始化的英雄和BOSS信息
	self.initHeroInfo = {}
	--hero AI need skillID 用于策划测试用
	self.heroNeedSkillID = 0
	self.heroNeedSkillTime = 0
	--用于记录login到start8的时间
	self.loginTime1 = 0
	self.loginTime2 = 0
	self.loginTimeTB1 = {}
	self.loginTimeTB2 = {}
	--记录SUBNAME汇总
	self.subNameDeadCounter = {}

	self.redirectWait = 0

	-- self.gameflow = require("gameroom.GameFlow").new(self)
	-- self.chatmsg = require("gameroom.ChatMessage").new(self)
	self.gameRoomInfoAll = callBack.gameRoomInfoAll
	self.gameRoomInfo = callBack.gameRoomInfo
	--self:D('jaylog WorldBase:ctor ',self.cjson.encode(self.gameRoomInfo))
	self:setMapModel(self.tostring(self.gameRoomInfo['mID']))
	self:D('jaylog WorldBase:ctor gameRoomInfo worldMode:',self.gameRoomInfo['worldMode'])
	if self.gameRoomInfo['worldMode']==2 then
		self.gameRoomSetting['ISGVB'] = 1
	elseif self.gameRoomInfo['worldMode']==3 then
		self.gameRoomSetting['ISPVP'] = 1
	else
		self.gameRoomSetting['ISYW'] = 1
		self.gameRoomSetting['hasMapZone'] = true
	end
	if self.tonumber(self.gameRoomInfo['mID'])>7000 and self.tonumber(self.gameRoomInfo['mID'])<9000 then
		self.gameRoomSetting['ISWF'] = 1
	end
	self.gameRoomSetting['maxPlayer'] = self.tonumber(self.gameRoomInfo['maxPlayer'])
	self.gameRoomSetting['AIMaxPlayer'] = self.tonumber(self.gameRoomInfo['AIMaxPlayer'])
	self.gameRoomSetting['teamMode'] = self.gameRoomInfo['teamMode']
	self.maxPlayer = self.gameRoomSetting['maxPlayer']
	self:setBaseClass()
	-- self.transfer = require("gameroom.Transfer").new(self)
	-- self.mp = require('MessagePack')
	-- if self.gameRoomSetting.ISDEV==nil or self.gameRoomSetting.ISDEV~=1 then
	-- 	self.debug = false
	-- end
end

function WorldBase:setBaseClass()
	self.gameflow = require("gameroom.GameFlow").new(self)
	self.chatmsg = require("gameroom.ChatMessage").new(self)
	self.transfer = require("gameroom.Transfer").new(self)
end

--- 接收client端发送数据
-- @param data table - 发送的数据table
-- @param serverTime float - 游戏时间
-- @return null
function WorldBase:receiveMsg(data,serverTime)
	if self.status==self.RUNNING then
		self:setGameTime(serverTime)
	end
	if data ==nil then
		return nil
		-- data = {}
	end

	local ret = nil
	self:D('jaylog WorldBase:receiveMsg == ',self.cjson.encode(data))
	for k,v in pairs(data) do
		if self.tonumber(data['roleID'])>0 and self.itemListFilter.heroList[data['roleID']]==nil then
			ret = {l={i=-1}}
			self:I('jaylog playerNotExist ',self.cjson.encode(ret),self.cjson.encode(data))
			-- 如果retrun -1，client会给mc操作，会导致跳图吾够快直接退出登录界面
			-- return ret
			return nil
		end
		if k=='apimsgc' then
			local vdata = self.cjson.decode(v['rq'])
			self:D('jaylog WorldBase:receiveMsg vdata:',self.cjson.encode(vdata),'ctrl',v['ctrl'],'act',v['act'],' itemID',data['roleID'])	--,' roleID',self.itemListFilter.heroList[data['roleID']].attribute.roleId)
			-- if vdata['rtype']=='autoMove' and vdata['taskID']~=nil and vdata['taskID']~=0 and vdata['taskID']~='' then
			-- 	self.allItemList[data['roleID']]:setAutoMove(self.tonumber(vdata['taskID']))
			-- end
			-- if vdata['rtype']=='autoMove' and vdata['pID']~=nil and vdata['pID']~=0 and vdata['pID']~='' then
			-- 	self:D('jaylog setAutoFollow roleID',data['roleID'],' pID',vdata['pID'])
			-- 	self.allItemList[data['roleID']]:setAutoFollow(self.tonumber(vdata['pID']))
			-- end
			-- if vdata['rtype']=='gift' and self.itemListFilter.heroList[data['roleID']].actorType==0 then
			-- 	self.itemListFilter.heroList[data['roleID']]:addApiJobGetGift(vdata['taskID'])
			-- 	self.itemListFilter.heroList[data['roleID']]:setAutoMove()
			-- end
			if v['ctrl']~=nil and v['act']~=nil then
				if v['ctrl']=='autoMove' and v['act']=='autoMove' then
					if not self.allItemList[data['roleID']]:isDead() then
						if vdata['taskID']~=nil and vdata['taskID']~=0 and vdata['taskID']~='' and self.gameRoomSetting['ISYW']==1 and self.allItemList[data['roleID']].taskObj.taskList~=nil then
							--self.allItemList[data['roleID']]:getTaskPath(vdata['taskID'])
							local obj = self.itemListFilter.heroList[data['roleID']]
							local synAll = true
							for tk,tv in pairs(obj.taskObj.taskList) do
								for ttk,ttv in pairs(tv) do
									if ttv['taskID']==vdata['taskID'] then
										synAll = false
										break
									end
								end
							end
							if syncAll then
								obj.taskObj:taskToFontbp(obj.taskObj.taskList)
							end
							self.allItemList[data['roleID']].autoMoveTaskID = self.tonumber(vdata['taskID'])
							self.allItemList[data['roleID']]:setAuto(false)
							self.allItemList[data['roleID']]:setAutoMove(self.tonumber(vdata['taskID']))
						end
						if vdata['pID']~=nil and vdata['pID']~=0 and vdata['pID']~='' then
							self.allItemList[data['roleID']]:setAutoFollow(self.tonumber(vdata['pID']))
							self.allItemList[data['roleID']]:setAutoTo()
						end
						if vdata['tID']~=nil and vdata['tID']~=0 and vdata['tID']~='' then
							self.allItemList[data['roleID']]:setAutoTo(self.tonumber(vdata['tID']))
							self.allItemList[data['roleID']]:setAutoFollow()
						end
					end
				elseif v['ctrl']=='queue' and v['act']=='friendList' then
					local flist = self:getOnlineFriendStatus(data['roleID'])
					local msg = {}
					msg[#msg+1] = {
						zz=3,
						i=data['roleID'],
						rp=self.cjson.encode({data={onLine=flist}}),
					}
					ret = {apimsg=msg}
				elseif v['ctrl']=='queue' and v['act']=='invite' then
					local mID = vdata['mID']
					-- if self.tonumber(vdata['mID'])==101001 then
					-- 	mID = 1005
					-- end
					-- if self.tonumber(vdata['mID'])==1005 and self.playerList[data['roleID']]['playerJson']['Player']['isFirstPVP']==nil then
					-- 	mID = 1001
					-- end
					local teamInfo = self:inviteTeamRequest(data['roleID'],self.tonumber(mID),vdata['friendID'])
					local msg = {}
					msg[#msg+1] = {
						zz=3,
						i=data['roleID'],
						rp=self.cjson.encode({data={teamInfo=teamInfo}}),
					}
					self:addSyncMsg({apimsg=msg})					
				elseif v['ctrl']=='queue' and v['act']=='accept' then
					self.itemListFilter.heroList[data['roleID']]:acceptTeamInvite(vdata['teamID'])
				elseif v['ctrl']=='queue' and v['act']=='reject' then
					self.itemListFilter.heroList[data['roleID']]:rejectTeamInvite(vdata['teamID'])
				elseif v['ctrl']=='queue' and v['act']=='quit' then
					self.itemListFilter.heroList[data['roleID']]:quitTeamInvite()
				elseif v['ctrl']=='queue' and v['act']=='match' then
					self.itemListFilter.heroList[data['roleID']]:startTeamMatching(vdata['teamID'])
				elseif v['ctrl']=='queue' and v['act']=='chat' then
					self.itemListFilter.heroList[data['roleID']]:chatMsgToTeam(vdata['teamID'],vdata['msg'])
				else
					if self.itemListFilter.heroList[data['roleID']].actorType==0 then
						-- if self.gameRoomSetting['ISYW']==1 and v['ctrl']=='task' and v['act']=='getTaskGift' then
						-- 	self.itemListFilter.heroList[data['roleID']]:updateInfo()
						-- end
						if self.gameRoomSetting['ISYW']==0 and v['ctrl']=='task' and v['act']=='getTaskGift' then
						else
							local canCall = true
							if v['ctrl']=='player' and v['act']=='rebirth' then
								local obj = self.itemListFilter.heroList[data['roleID']]
								if vdata['ID']~=nil and self.playerList[self.tonumber(vdata['ID'])]~=nil and self.tonumber(vdata['rebirthType'])==6 then
									local itemID = self.tonumber(vdata['ID'])
									if obj.rebirthLockGVB[itemID]==nil then
										vdata['rebirthTime'] = obj.attribute.rebirth
										vdata['oid'] = self.playerList[itemID]['p']
										obj.rebirthLockGVB[itemID] = {x=obj.posX,y=obj.posY}
									else
										canCall = false
									end
								end
								if self.tonumber(vdata['rebirthType'])==7 then
									vdata['oidlist'] = {}
									for k1,v1 in pairs(self.playerList) do
										if self.itemListFilter.heroList[k1]:isDead() then
											vdata['rebirthTime'] = obj.attribute.rebirthTeam
											vdata['oidlist'][#vdata['oidlist']+1] = self.playerList[k1]['p']
											obj.rebirthLockGVB[k1] = {x=obj.posX,y=obj.posY}
										end
									end
								end
								if self.tonumber(vdata['rebirthType'])==5 then
									vdata['rebirthTime'] = obj.attribute.rebirth
								end
							end
							if v['ctrl']=='localGVB' and v['act']=='battle' then
								self.itemListFilter.heroList[data['roleID']]:updateInfo()
								self.itemListFilter.heroList[data['roleID']]:executeAPICall(true)
								local mID = self.tonumber(vdata['mid'])
								if mID>100000 then
									mID = mID - 100000
								end
								local sendData = self:getSendData(data['roleID'],mID)
								local localServerData,roomData = self:getLocalServerData(data['roleID'],mID,sendData)
								self.playerList[data['roleID']]['online'] = false
								self.playerList[data['roleID']]['offLineTime'] = self.gameTime - self.gameRoomSetting.offlineRemoveWaitTime
								local response2 = string.base64encode(self.cjson.encode(roomData))
								local response = string.base64encode(self.cjson.encode({errcode=0,mes='',data=localServerData}))
								local msg = {{zz=3,i=data['roleID'],rtype=1,rp=response},{zz=3,i=data['roleID'],rtype=3,rp=response2}}
								ret = {apimsg=msg}
								canCall = false
							end
							if v['ctrl']=='task' and v['act']=='getTaskGift' then
								local obj = self.itemListFilter.heroList[data['roleID']]
								local synAll = true
								for tk,tv in pairs(obj.taskObj.taskList) do
									for ttk,ttv in pairs(tv) do
										if ttv['taskID']==vdata['taskID'] then
											synAll = false
											break
										end
									end
								end
								if syncAll then
									obj.taskObj:taskToFontbp(obj.taskObj.taskList)
								end
							end
							if canCall then
								self.itemListFilter.heroList[data['roleID']]:addApiCall(vdata,v['ctrl'],v['act'])
								self.itemListFilter.heroList[data['roleID']]:executeAPICall(true)
							end
						end
						if self.gameRoomSetting['ISYW']==1 then
							-- if v['ctrl']=='task' and v['act']=='trigerFinish' then
							-- 	self.itemListFilter.heroList[data['roleID']]:removeSkillAttackMode9()
							-- end
							if v['ctrl']=='task' and v['act']=='replaceTask' then
								self.itemListFilter.heroList[data['roleID']]:setAutoMove(self.tonumber(vdata['taskID']))
							end
							if v['ctrl']=='task' and v['act']=='addPlayerTask' then
								self.itemListFilter.heroList[data['roleID']].taskUpdateAutoMoveID = self.tonumber(vdata['taskID'])
							end
						end
						-- if v['ctrl']=='task' and v['act']=='getTaskGift' then
						-- 	self.itemListFilter.heroList[data['roleID']]:setAutoMove()
						-- 	self.itemListFilter.heroList[data['roleID']]:setAuto(false)
						-- end
					end
				end
			end
		end
		if k=='1' then
			self.loginTimeTB2[data['roleID']] = self.callBack:getServerTime()
			if (self.loginTimeTB2[data['roleID']]-self.loginTimeTB1[data['roleID']])>1 then
				self:D('jaylog redirectRoom waitTime too long ',self.loginTimeTB2[data['roleID']],self.loginTimeTB1[data['roleID']],(self.loginTimeTB2[data['roleID']]-self.loginTimeTB1[data['roleID']]))
			end
			self:D('jaylog WorldBase:receiveMsg data:',self.cjson.encode(data))
			local port=1330+((self.tonumber(self.playerList[data['roleID']]['p'])%5)*2);
			-- if self.gameRoomSetting['ISUAT']==1 then
			-- 	port = port + 3000
			-- end
			port = port + self.tonumber(self.Config.tcpPortAdd)
			local result = {i={zz=3,i=data['roleID'],host=v['l']['commip'],roomid=data['port'],port=port,pid=v['l']['p'],mapid=v['l']['m']}}
			self:D('jaylog WorldBase:receiveMsg updateSyncMsg:',self.cjson.encode(result))
			self:addSyncMsg(result)
			--self.allItemList[data['roleID']]:moveTo(130,55)
			self.playerList[data['roleID']]['online'] = false
			self.playerList[data['roleID']]['offLineTime']=self.gameTime-self.gameRoomSetting.offlineRemoveWaitTime
			self.playerList[data['roleID']]['redirectEndTime'] = 0
			self.allItemList[data['roleID']].__waitQueue = 0
		end
		if k=='l' then
			self:login(data)
			ret = data
		end
		if k=='game' and data['roleID']~=nil then
			if data['game']['step']~=nil then
				self.guideStep = data['game']['step']
				ret = {flow={{i=1,step=data['game']['step'],param='step=ok'}}}
			else
				ret = self:clientGameInit(data)
			end
		end
		if k=='ping' and data['roleID']~=nil and self.itemListFilter.heroList[data['roleID']]~=nil then
			self.itemListFilter.heroList[data['roleID']]:setPing(data['ping'])
		end

		if  data~=nil and  data['roleID']~=nil and self.playerList[data['roleID']]~=nil and self.playerList[data['roleID']]['apm'] ==nil then
			self.playerList[data['roleID']]['apm'] = 0
		end

		if self.status==self.RUNNING and k=='mc' and data['roleID'] ~=nil then
			if self.itemListFilter.heroList[data['roleID']]~=nil then
				self.itemListFilter.heroList[data['roleID']]:control()
				self.itemListFilter.heroList[data['roleID']]:suspendAI()
				-- if self.itemListFilter.heroList[data['roleID']].statusList[41]~=nil then
				-- 	self.itemListFilter.heroList[data['roleID']]:removeStatusList(41,0) --移动删除咏唱状态
				-- 	self.gameFlag['lastEnergyID'] = 0
				-- 	self.gameFlag['lastEnergyTime'] = 0
				-- end
				self.itemListFilter.heroList[data['roleID']].lastMoveTime = self.gameTime
				self.itemListFilter.heroList[data['roleID']]:removeSkillAttackMode9()
				self.itemListFilter.heroList[data['roleID']]:setAutoMove()
				self.itemListFilter.heroList[data['roleID']]:setAutoFollow()
				self.itemListFilter.heroList[data['roleID']]:setAutoTo()
				-- self:D('jaylog mc setAuto ',self.itemListFilter.heroList[data['roleID']].className,self.itemListFilter.heroList[data['roleID']].attribute.roleId,data['roleID'])
				-- if self.itemListFilter.heroList[data['roleID']].attribute.level<=6 then
				if self.tonumber(self.playerList[data['roleID']]['playerJson']['Player']['aiOpen'])~=1 then
					self.itemListFilter.heroList[data['roleID']]:setAuto(false)
				end
			end
			if  data['roleID']~=nil and data['mc']['j']==nil then
				data['mc']['j'] = 0
			end
			local a = self:moveHero(data['roleID'],data['mc']['x'],data['mc']['y'],data['mc']['j'])
			if self.playerList[data['roleID']]~=nil then
				self.playerList[data['roleID']]['apm'] = self.playerList[data['roleID']]['apm'] + 1
			end
			if type(a)=="table" then
				ret = {t=self.gameTime,m={{i=data['roleID'],m=a['m'],d=a['d']}}}
			else
				ret = nil
			end
		end
		if self.status==self.RUNNING and k=='ac' and data['roleID'] ~=nil then
			local msg = {}
			if self.itemListFilter.heroList[data['roleID']]~=nil then
				self.itemListFilter.heroList[data['roleID']]:control()
				self.itemListFilter.heroList[data['roleID']]:suspendAI()
				self.itemListFilter.heroList[data['roleID']]:setAutoMove()
				self.itemListFilter.heroList[data['roleID']]:setAutoFollow()
				self.itemListFilter.heroList[data['roleID']]:setAutoTo()
				-- if self.itemListFilter.heroList[data['roleID']].attribute.level<=6 then
				if self.tonumber(self.playerList[data['roleID']]['playerJson']['Player']['aiOpen'])~=1 then
					self.itemListFilter.heroList[data['roleID']]:setAuto(false)
				end
				-- if v['m']~=9 then
					-- self:D('jaylog ac removeSkillAttackMode9 ',self.cjson.encode(data),self.itemListFilter.heroList[data['roleID']].posX,self.itemListFilter.heroList[data['roleID']].posY)
					self.itemListFilter.heroList[data['roleID']]:removeSkillAttackMode9()
				-- end
				-- if self.itemListFilter.heroList[data['roleID']].loginID=='谨慎的贝权' or self.itemListFilter.heroList[data['roleID']].loginID=='漂亮的笪婉儿' then 	--and v['m']==2
				-- 	-- local sendData = self:getSendData(data['roleID'],5005)
				-- 	-- local localServerData = self:getLocalServerData(data['roleID'],5005,sendData)
				-- 	-- local response = string.base64encode(self.cjson.encode({errcode=0,mes='',data=localServerData}))
				-- 	-- msg = {{zz=3,i=data['roleID'],rtype=1,rp=response}}
				-- 	-- self:D('jaylog ac=2 msg:',self.cjson.encode(msg))
				-- 	self.chatmsg:setMsg(self.itemListFilter.heroList[data['roleID']].loginID..' 测试1 现在输入类型：'..v['m'],v['m'],data['roleID'])
				-- end
				if self.gameRoomSetting.ISDEV~=nil and self.gameRoomSetting.ISDEV==1 and v['m']==5 and (self.itemListFilter.heroList[data['roleID']].loginID=='寡言的梅颜萍' or self.itemListFilter.heroList[data['roleID']].loginID=='mk1109狂') then
					local roomID,roomStart,roomEnd = 0,2970,2990
					roomStart = roomStart - self.tonumber(self.Config.roomIDAdd)
					roomEnd = roomEnd - self.tonumber(self.Config.roomIDAdd)
					roomID = self:findEmptyRoomPort(roomStart,roomEnd,8011)
					self:redirectRoom(data['roleID'],8011,roomID,nil,self.itemListFilter.heroList[data['roleID']].posX,self.itemListFilter.heroList[data['roleID']].posY,nil,true,false,true)
				end
				if self.gameRoomSetting.ISDEV~=nil and self.gameRoomSetting.ISDEV==1 and v['m']==5 and self.itemListFilter.heroList[data['roleID']].loginID=='skks' then
					self:addBoss(2018,self.itemListFilter.heroList[data['roleID']].team,self.itemListFilter.heroList[data['roleID']].loginID,self.itemListFilter.heroList[data['roleID']].posX,self.itemListFilter.heroList[data['roleID']].posY,0,data['roleID'])
				end
				-- if self.itemListFilter.heroList[data['roleID']].loginID=='kk333' then
				-- 	if v['m']==4 then
				-- 		local attributes = {}
				-- 		attributes['OUTCTL_RATE'] = 100
				-- 		attributes['BUFFTIME'] = 999
				-- 		local buff = require("gameroomcore.SBuff").new(self,self.itemListFilter.heroList[data['roleID']]:__skillID2buffID(0),attributes,attributes['BUFFTIME'],{},0,self.itemListFilter.heroList[data['roleID']].itemID,self.itemListFilter.heroList[data['roleID']].itemID)
				-- 		self.itemListFilter.heroList[data['roleID']]:addBuff(buff)
				-- 	end
				-- 	-- self.itemListFilter.heroList[data['roleID']].attribute.MaxHP=self.itemListFilter.heroList[data['roleID']].attribute.MaxHP+1000
				-- 	-- self.itemListFilter.heroList[data['roleID']].attribute.baseTable.MaxHP=self.itemListFilter.heroList[data['roleID']].attribute.MaxHP+1000

				-- 	-- local result=self.itemListFilter.heroList[data['roleID']]:getAllInfo(0,true)
				-- 	-- self.itemListFilter.heroList[data['roleID']]:updateSyncMsg({i=result})
				-- 	-- local toX,toY = self.map:getXYLength(0,0,0,0,10)
				-- 	-- self:D('jaylog test getXYLength ',toX,toY)
				-- 	-- local num = self.formula:getRandnum(1,10)
				-- 	-- if num>5 then
				-- 	-- 	self.itemListFilter.heroList[data['roleID']]:addStatusList({zz=3,s=88,r=self.gameTime,t=99999,p1=11111111,p2=8,p3=2})
				-- 	-- else
				-- 	-- 	self.itemListFilter.heroList[data['roleID']]:addStatusList({zz=3,s=88,r=self.gameTime,t=99999,p1=11111011,p2=8,p3=2})
				-- 	-- end
				-- 	-- if v['m']==1 then
				-- 	-- 	local fileinfo = io.readfile('SQLCACHE'..self.mapModel..'.dat')
				-- 	-- 	self:D('jaylog fileinfo : ',fileinfo)
				-- 	-- 	-- local unp = self.mp.unpack(fileinfo)
				-- 	-- 	-- self:D('jaylog unp : ',self.cjson.encode(unp))
				-- 	-- end
				-- end
			end

			self:D('jaylog WorldBase:receiveMsg roleID:'..data['roleID'])
			if (self.itemListFilter.heroList[data['roleID']]~=nil) then
				self:D('jaylog WorldBase:receiveMsg hero:'..self.itemListFilter.heroList[data['roleID']].attribute.roleId)
			else
				for k,v in pairs(self.itemListFilter.heroList) do
					self:D('jaylog WorldBase:receiveMsg hero exist:'..k..' roleID:'..v.attribute.roleId)
				end
			end
			local a = self:attackHero(data['roleID'],data['ac'])
			if self.playerList[data['roleID']]~=nil then
				self.playerList[data['roleID']]['apm'] = self.playerList[data['roleID']]['apm'] + 1
			end
			if type(a)=="table" then
				ret = a
			else
				ret = nil
			end
			if msg~=nil and not empty(msg) then
				if ret==nil then
					ret = {}
				end
				ret['apimsg'] = msg
			end
		end
		if k=='st' and data['roleID'] ~=nil  then
			if self.itemListFilter.heroList[data['roleID']]~=nil then
				self.itemListFilter.heroList[data['roleID']]:control()
			end
			local id,id2
			if data['roleID']>90 and self.itemListFilter.heroList[data['roleID']-90]~=nil then
				id = data['roleID']-90
			else
				id = data['roleID']
			end
			if data['st']['i']>90 then
				id2 = data['st']['i']-90
			else
				id2 = data['st']['i']
			end
			local a = self:heroInfo(id,id2)
			if type(a)=="table" then
				self:D('jaylog start return heroInfo : ',self.cjson.encode(a))
				ret = a
			else
				ret = nil
			end
		end
		if k=='lo' then
			if self.itemListFilter.heroList[data['roleID']]~=nil then
				self.itemListFilter.heroList[data['roleID']]:setAutoMove()
			end
			self.pendingUpdateCache=true
			data = self:logout(data)
			self.pendingUpdateCache=false
		end
		if k=='ric' and data['roleID'] ~=nil then
			if self.playerList[data['roleID']]~=nil then
			data = self:selectHero(data)
			end
		end
		if k=='rcc' and data['roleID'] ~=nil then
			if self.itemListFilter.heroList[data['roleID']]~=nil then
				self.itemListFilter.heroList[data['roleID']]:control()
			end
			if self.playerList[data['roleID']]~=nil then
				if self.playerList[data['roleID']]['ok']~=nil then
					delay = -1
				else
					delay = self.waitingTime - (self.serverTime - self.startWaitingTime)
				end
				if data['rcc']['t']==nil then data['rcc']['t'] = "" end
				if data['rcc']['rType']==nil then data['rcc']['rType'] = 1 end
				-- if data['rcc']['t']~='A' and data['rcc']['t']~='B' and data['rcc']['t']~='' then
					local mp3id = self.chatmsg:setMsg(data['rcc']['m'],data['rcc']['rType'],data['roleID'])
				-- end
				local rc = {i=data['roleID'],m=data['rcc']['m'],t=data['rcc']['t'],rType=data['rcc']['rType'],d=delay}
				if mp3id~=nil then
					rc['id'] = ''..mp3id
				end
				if data['rcc']['t']~="" then
					rc['zz'] = 2
				end
				self:addSyncMsg({rc={rc}})
			end
		end
		if k=='cmc' and data['roleID'] ~=nil then

		end
		if k=='auto' and data['roleID'] ~=nil then
			-- if self.is3V3 then
			-- 	data['auto'] = 1
			-- 	ret = data
			-- end
			if self.itemListFilter.heroList[data['roleID']]~=nil and not self.guideStepSetAutoBlock then
				self.itemListFilter.heroList[data['roleID']]:setAuto(data['auto']==2)
				self.itemListFilter.heroList[data['roleID']]:setAutoMove()
			end
			ret = data
		end
		if k=='automsgc' and data['roleID']~=nil then
			if self.itemListFilter.heroList[data['roleID']]~=nil and not self.guideStepSetAutoBlock then
				self.itemListFilter.heroList[data['roleID']]:setAuto(v['auto']==2)
				self.itemListFilter.heroList[data['roleID']]:setAutoMove()
			end
		end
		if k=='extra' and data['extra']['closeRoom']~=nil and data['extra']['closeRoom']=="now" then
			self.gameRoomSetting['gameLimitedTime'] = self.gameTime
			ret = data
		end
		if k=='reinfo' and data['roleID']~=nil then
			ret = self:getObjectInfos(data['reinfo'],data['roleID'])
		end
		if k=='queue' and data['roleID']~=nil then
			self:D('jaylog receiveMsg queue:',self.cjson.encode(data))
			if v['m']==nil or v['m']==0 then
				self.itemListFilter.heroList[data['roleID']]:removeWaitQueue()
				self.playerList[data['roleID']]['online'] = true
				self.playerList[data['roleID']]['offLineTime'] = 0
			else
				local mID = v['m']
				-- if self.tonumber(v['m'])==101001 then
				-- 	mID = 1005
				-- end
				-- if self.tonumber(v['m'])==1005 and self.playerList[data['roleID']]['playerJson']['Player']['isFirstPVP']==nil then
				-- 	mID = 1001
				-- end
				self.itemListFilter.heroList[data['roleID']]:addWaitQueue(mID)
				-- self.playerList[data['roleID']]['online'] = false
				-- self.playerList[data['roleID']]['offLineTime'] = self.gameTime
			end
		end
		if k=='flowc' and data['roleID']~=nil then
			if v['step']~=nil then
				self.itemListFilter.heroList[data['roleID']].guideStep = v['step']
				self.itemListFilter.heroList[data['roleID']].guideStepFinish = true
				self.guideStepSetAutoBlock = false
				self.guideStep = v['step']
				self:D('jaylog WorldBase:receiveMsg flowc:',data['roleID'],k,v['step'])
				self:addSyncMsg({flow={{i=data['roleID'],step=v['step'],param='step=ok'}}})
				if self.guideStepNext==v['step'] then
					self.guideStepNext = 0
				end
			end
		end
		--self:D('jaylog receiveMsg:k',k,' v',self.cjson.encode(v))
		if k=='extra' and v['closeRoom']=='now' then
			--self:D('jaylog receiveMsg after:k',k,' v',self.cjson.encode(v))
			self.callBack:exitGame()
			--self:exitErrorGame()
			os.exit()
			do return end
		end
	end
	return ret
end



--- client端初始化房间设置
-- @param data table - client传上来的数据
-- @return data table - 原数据返回
function WorldBase:clientGameInit(data)
	self:D('start clientGameInit status:'..self.status..' data:'..self.cjson.encode(data))

	if data['roleID']~=nil and self.playerList[data['roleID']]~=nil and self.status==self.READY and data['game']['start']~=nil and data['game']['start']==1 then
		local items = {}
		for k,v in pairs(self.itemListFilter.heroList) do
			items[#items+1] = v:getAllInfo()
		end
		for k,v in pairs(self.itemListFilter.towerList) do
			items[#items+1] = v:getAllInfo()
		end
		self.playerList[data['roleID']]['ok']=1
		return {zz=1,i=items,t=self:getGameTime()}
	end

	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==1 then
		local loginTime1 = self.callBack:getServerTime()

		self:D('jaylog WorldBase 439 roleID '..data['roleID'])
		--self:D('jaylog WorldBase 439 roleId1 '..self.itemListFilter.heroList["1"].attribute.roleId)
		self:D('jaylog WorldBase 439 roleId2 '..self.itemListFilter.heroList[data['roleID']].attribute.roleId)
		--self.itemListFilter.heroList[data['roleID']]:addApiJobGetTask()

		local result = {i={self.itemListFilter.heroList[data['roleID']]:getAllInfo(0,true)}}
		if result['i'][1]['s']==0 then
			result['i'][1]['s'] = 1
		end
		result['zz']=1
		result['game']={start=2,msize=self.mapSize}

		local loginTime2 = self.callBack:getServerTime()
		-- self:DC('jaylog loginTime start1:',self.mFloor((loginTime2-loginTime1)*10000)/10000,loginTime1,loginTime2)

		return result
	end
	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==2 then
		local loginTime1 = self.callBack:getServerTime()

		-- if self.gameRoomSetting['ISYW']==0 then
			local result = {zz=1,game={start=3,msize=self.mapSize}}
			result['i'] = self.initHeroInfo
			-- self:D('jaylog initHeroInfo:',self.cjson.encode(result))

			local loginTime2 = self.callBack:getServerTime()
			-- self:DC('jaylog loginTime start2:',self.mFloor((loginTime2-loginTime1)*10000)/10000,loginTime1,loginTime2)

			return result
		-- else
		-- 	local obj = self.itemListFilter.heroList[data['roleID']]
		-- 	-- self:D('jaylog start 2 clientInitLoopNum ',obj.clientInitLoopNum,'data:',self.cjson.encode(data))
		-- 	if obj.clientInitLoopNum~=0 and (self.gameTime-obj.clientInitLoopNum)>self.tonumber(self.setting['clientInitWaitTime']) then
		-- 		local result = {}
		-- 		result['zz']=1
		-- 		result['game']={start=3,msize=self.mapSize}
		-- 		-- self:D('jaylog start 2 clientInitLoopNum ',obj.clientInitLoopNum,self.cjson.encode(result))
		-- 		self.itemListFilter.heroList[data['roleID']].clientInitLoopNum = 0

		-- 		local loginTime2 = self.callBack:getServerTime()
		-- 		self:DC('jaylog loginTime start2:',self.mFloor((loginTime2-loginTime1)*10000)/10000,loginTime1,loginTime2)
		-- 		return result
		-- 	else
		-- 		-- self:D('jaylog start 2 clientInitLoopNum ',obj.clientInitLoopNum)
		-- 		if obj.clientInitLoopNum==0 then
		-- 			obj.clientInitLoopNum = self.gameTime
		-- 		end

		-- 		local loginTime2 = self.callBack:getServerTime()
		-- 		self:DC('jaylog loginTime start2:',self.mFloor((loginTime2-loginTime1)*10000)/10000,loginTime1,loginTime2)

		-- 		return {zz=1,game={start=2,msize=self.mapSize}}
		-- 	end
		-- end
	end
	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==3 then
		local loginTime1 = self.callBack:getServerTime()

		local resultTmp = self:getHeroObjectInfos(data['roleID'],true)
		local obj = self.itemListFilter.heroList[data['roleID']]
		local result = {}
		result = resultTmp
		for k,v in pairs(result['i']) do
			if v['i']~=data['roleID'] then
				if result['i'][k]['s']==0 then
					result['i'][k]['s'] = 1
				end
				result['i'][k]['aspdr'] = nil
				result['i'][k]['mspdr'] = nil
				result['i'][k]['angel'] = nil
				result['i'][k]['dm1'] = nil
				result['i'][k]['dm2'] = nil
				result['i'][k]['dm3'] = nil
				result['i'][k]['dm4'] = nil
			end
		end
		result['zz']=1
		result['game']={start=5,msize=self.mapSize}
		if self.gameRoomSetting['ISYW']==0 then
			if self.roomStartTime>0 then
				result['game']['gss'] = 1
				result['game']['gst'] = self.roomStartTime
			else
				result['game']['gss'] = 2
				result['game']['gst'] = 0
			end
			if self.gameRemainStartTime>0 then
				result['game']['grs'] = 1
				result['game']['grt'] = self.gameRemainStartTime+self.gameRemainTime
			else
				result['game']['grs'] = 2
				result['game']['grt'] = 0
			end
		else
			result['game']['gss'] = 1
			result['game']['gst'] = 0
			result['game']['grs'] = 2
			result['game']['grt'] = 0
		end
		if self.gameRoomSetting['ISGVB']==1 then
			result['game']['star'] = self.gameCounter['star']
		end
		-- if obj.clientInitLoopNum3==0 then
		-- 	local resultHero = resultTmp['i']
		-- 	for k,v in pairs(resultHero) do
		-- 		if v['i']~=data['roleID'] then
		-- 			resultHero[k]['aspdr'] = nil
		-- 			resultHero[k]['mspdr'] = nil
		-- 			resultHero[k]['angel'] = nil
		-- 			resultHero[k]['dm1'] = nil
		-- 			resultHero[k]['dm2'] = nil
		-- 			resultHero[k]['dm3'] = nil
		-- 			resultHero[k]['dm4'] = nil
		-- 		end
		-- 	end
		-- 	result['i'] = resultTmp['i']
		-- 	result['game']={start=3,msize=self.mapSize}
		-- 	obj.clientInitLoopNum3 = obj.clientInitLoopNum3 + 1
		-- elseif obj.clientInitLoopNum3==1 then
		-- 	result['m'] = resultTmp['m']
		-- 	result['game']={start=3,msize=self.mapSize}
		-- 	obj.clientInitLoopNum3 = obj.clientInitLoopNum3 + 1
		-- elseif obj.clientInitLoopNum3==2 then
		-- 	resultTmp['i'] = nil
		-- 	resultTmp['m'] = nil
		-- 	result = resultTmp
		-- 	obj.clientInitLoopNum3 = 0
		-- 	result['game']={start=5,msize=self.mapSize}
		-- 	if self.gameRoomSetting['ISYW']==0 then
		-- 		if self.roomStartTime>0 then
		-- 			result['game']['gss'] = 1
		-- 			result['game']['gst'] = self.roomStartTime
		-- 		else
		-- 			result['game']['gss'] = 2
		-- 			result['game']['gst'] = 0
		-- 		end
		-- 		if self.gameRemainStartTime>0 then
		-- 			result['game']['grs'] = 1
		-- 			result['game']['grt'] = self.gameRemainStartTime+self.gameRemainTime
		-- 		else
		-- 			result['game']['grs'] = 2
		-- 			result['game']['grt'] = 0
		-- 		end
		-- 	else
		-- 		result['game']['gss'] = 1
		-- 		result['game']['gst'] = 0
		-- 		result['game']['grs'] = 2
		-- 		result['game']['grt'] = 0
		-- 	end
		-- 	if self.gameRoomSetting['ISGVB']==1 then
		-- 		result['game']['star'] = self.gameCounter['star']
		-- 	end
		-- end

		local loginTime2 = self.callBack:getServerTime()
		-- self:DC('jaylog loginTime start3:',self.mFloor((loginTime2-loginTime1)*10000)/10000,loginTime1,loginTime2)

		return result
	end
	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==5 then
		local loginTime1 = self.callBack:getServerTime()

		local resultTmp = self:getNonHeroObjectInfos(data['roleID'],true)
		local obj = self.itemListFilter.heroList[data['roleID']]
		local result = {}
		if self.gameRoomInfo['worldSubMode']==1 then
			result = resultTmp
			local auto = 1
			if self.itemListFilter.heroList[data['roleID']].AImode>0 then
				auto = 2
			end
			result['game']={start=6,msize=self.mapSize}
			if self.UIID~=0 then
				result['gameinfo'] = {{part=self.UIID,partBoss=self.UIBoss,step=self.UIStep,mType=3}}
				-- result['gameinfo']['part'] = self.UIID
				-- result['gameinfo']['partBoss'] = self.UIBoss
				-- result['gameinfo']['mType'] = 3
			end
			if self.gameRoomSetting['ISYW']==0 then
				local teamAID = {}
				local teamBID = {}
				for k,v in pairs(self.itemListFilter.heroList) do
					if v.actorType==0 and v.teamOrig=='A' and v.parent==nil and (v.isSmallAI==nil or not v.isSmallAI) then
						teamAID[#teamAID+1] = k
					end
					if v.actorType==0 and v.teamOrig=='B' and v.parent==nil and (v.isSmallAI==nil or not v.isSmallAI) then
						teamBID[#teamBID+1] = k
					end
				end
				if not empty(teamAID) then
					result['game']['teamAID'] = teamAID
				end
				if not empty(teamBID) then
					result['game']['teamBID'] = teamBID
				end
			end
			result['auto']=auto
			result['automsg']={{auto=obj.AImode+1,i=obj.itemID,zz=3}}
		else
			if obj.clientInitLoopNum5==0 then
				result['game'] = {start=5,msize=self.mapSize}
				result['i'] = {}
				if resultTmp['i']~=nil then
					for k,v in pairs(resultTmp['i']) do
						if v['i']==0 then
							result['i'][#result['i']+1] = v
						end
					end
				end
				obj.clientInitLoopNum5 = obj.clientInitLoopNum5 + 1
			elseif obj.clientInitLoopNum5==1 then
			-- 	result['game'] = {start=5,msize=self.mapSize}
			-- 	result['m'] = resultTmp['m']
			-- 	obj.clientInitLoopNum5 = obj.clientInitLoopNum5 + 1
			-- elseif obj.clientInitLoopNum5==2 then
				-- resultTmp['i'] = nil
				-- resultTmp['m'] = nil
				-- result = resultTmp
				result['i'] = {}
				if resultTmp['i']~=nil then
					for k,v in pairs(resultTmp['i']) do
						if v['i']~=0 then
							result['i'][#result['i']+1] = v
						end
					end
				end
				resultTmp['i'] = nil
				for k,v in pairs(resultTmp) do
					result[k] = v
				end
				obj.clientInitLoopNum5 = 0
				local auto = 1
				if self.itemListFilter.heroList[data['roleID']].AImode>0 then
					auto = 2
				end
				result['game']={start=6,msize=self.mapSize}
				if self.UIID~=0 then
					result['gameinfo'] = {{part=self.UIID,partBoss=self.UIBoss,step=self.UIStep,mType=3}}
					-- result['gameinfo']['part'] = self.UIID
					-- result['gameinfo']['partBoss'] = self.UIBoss
					-- result['gameinfo']['mType'] = 3
				end
				if self.gameRoomSetting['ISYW']==0 then
					local teamAID = {}
					local teamBID = {}
					for k,v in pairs(self.itemListFilter.heroList) do
						if v.actorType==0 and v.teamOrig=='A' and v.parent==nil and (v.isSmallAI==nil or not v.isSmallAI) then
							teamAID[#teamAID+1] = k
						end
						if v.actorType==0 and v.teamOrig=='B' and v.parent==nil and (v.isSmallAI==nil or not v.isSmallAI) then
							teamBID[#teamBID+1] = k
						end
					end
					if not empty(teamAID) then
						result['game']['teamAID'] = teamAID
					end
					if not empty(teamBID) then
						result['game']['teamBID'] = teamBID
					end
				end
				-- self:syncGameInfoOnece()
				result['auto']=auto
				result['automsg']={{auto=obj.AImode+1,i=obj.itemID,zz=3}}
			end
		end
		result['zz']=1
		--self.forceUpdate = true
		
		-- if self.itemListFilter.heroList[data['roleID']].redirectUpdataTask then
		-- 	self.itemListFilter.heroList[data['roleID']]:addApiJobGetTask()
		-- 	self.itemListFilter.heroList[data['roleID']].redirectUpdataTask = false
		-- end
		-- if empty(self.itemListFilter.heroList[data['roleID']].taskObj.taskList) then
		-- 	self.itemListFilter.heroList[data['roleID']]:addApiJobGetTask()
		-- end
		local loginTime2 = self.callBack:getServerTime()
		-- self:DC('jaylog loginTime start5:',self.mFloor((loginTime2-loginTime1)*10000)/10000,loginTime1,loginTime2)

		return result
	end
	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==6 then
		local loginTime1 = self.callBack:getServerTime()

		local result = {}
		result['game'] = {start=7,msize=self.mapSize}
		local obj = self.itemListFilter.heroList[data['roleID']]
		-- if not obj.firstAdd or self.gameRoomSetting['ISYW']==0 then
		-- 	local response = self.cjson.encode({errcode=0,mes='',data={task=obj.taskObj.taskList}})
		-- 	local msg = {{zz=3,i=data['roleID'],rp=response}}
		-- 	result['apimsg'] = msg
		-- end
		if self.gameRoomSetting['ISYW']==1 then
			self.playerList[data['roleID']]['online'] = true
			local oldOffTime = self.playerList[data['roleID']]['offLineTime']
			self.playerList[data['roleID']]['offLineTime']=0
			self.itemListFilter.heroList[data['roleID']]:checkAPICallBack()
			if self.gameRoomSetting['ISYW']==1 then
				if obj.taskObj.taskList~=nil then
					local tasklists = obj.taskObj:taskToFontbp(obj.taskObj.taskList)
					result['tasklists'] = tasklists
				end
			end
			if obj.syncMsg['bc']~=nil then
				result['bc'] = self.tDeepcopy(obj.syncMsg['bc'])
				obj.syncMsg['bc'] = nil
			end
			if obj.syncMsg['apimsg']~=nil then
				result['apimsg'] = self.tDeepcopy(obj.syncMsg['apimsg'])
				obj.syncMsg['apimsg'] = nil
			end
			self.playerList[data['roleID']]['online'] = false
			self.playerList[data['roleID']]['offLineTime']=oldOffTime
		end
		if obj.taskObj~=nil and obj.taskObj.taskList~=nil and obj.taskObj.taskList["1"]~=nil and (obj.taskObj.taskList["1"]["1010"]~=nil or obj.taskObj.taskList["1"]["50001010"]~=nil) then
			if self.gameRoomSetting['ISYW']==1 then
				result['auto'] = 100
				local obj = self.itemListFilter.heroList[data['roleID']]
				if obj.taskObj.taskList~=nil and obj.taskObj.taskList["1"]~=nil and (obj.taskObj.taskList["1"]["1010"]~=nil or obj.taskObj.taskList["1"]["50001010"]~=nil) then
					for k,v in pairs(obj.taskObj.taskList["1"]) do
						if k=='1010' or k=='50001010' then
							for k1,v1 in pairs(v) do
								if k1=='tasks' then
									for k2,v2 in pairs(v1) do
										self:D('jaylog firstTask4 need moveTo ',v2['X'],v2['Y']+3)
										obj:moveTo(v2['X'],v2['Y']+3,true,1,99999)
									end
								end
							end
						end
					end
					result['m'] = {obj.syncMsg['m']}
				end
			end
		end

		self:D('jaylog start 6 result',self.cjson.encode(result),self.itemListFilter.heroList[data['roleID']].firstAdd)

		local loginTime2 = self.callBack:getServerTime()
		-- self:DC('jaylog loginTime start6:',self.mFloor((loginTime2-loginTime1)*10000)/10000,loginTime1,loginTime2)
		return result
	end
	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==7 then
		local loginTime1 = self.callBack:getServerTime()
		local obj = self.itemListFilter.heroList[data['roleID']]
		local result = {}
		result['game'] = {start=8,msize=self.mapSize}
		-- self.playerList[data['roleID']]['online'] = true
		-- local oldOffTime = self.playerList[data['roleID']]['offLineTime']
		-- self.playerList[data['roleID']]['offLineTime']=0
		-- self.itemListFilter.heroList[data['roleID']]:checkAPICallBack()
		-- if self.gameRoomSetting['ISYW']==1 then
		-- 	if obj.taskObj.taskList~=nil then
		-- 		local tasklists = obj.taskObj:taskToFontbp(obj.taskObj.taskList)
		-- 		result['tasklists'] = tasklists
		-- 	end
		-- end
		-- if obj.syncMsg['bc']~=nil then
		-- 	result['bc'] = obj.syncMsg['bc']
		-- end
		-- self.playerList[data['roleID']]['online'] = false
		-- self.playerList[data['roleID']]['offLineTime']=oldOffTime
		-- if obj.taskObj.taskList~=nil and obj.taskObj.taskList["1"]~=nil and (obj.taskObj.taskList["1"]["1010"]~=nil or obj.taskObj.taskList["1"]["50001010"]~=nil) then
		-- 	if self.gameRoomSetting['ISYW']==1 then
		-- 		result['auto'] = 100
		-- 		local obj = self.itemListFilter.heroList[data['roleID']]
		-- 		if obj.taskObj.taskList~=nil and obj.taskObj.taskList["1"]~=nil and (obj.taskObj.taskList["1"]["1010"]~=nil or obj.taskObj.taskList["1"]["50001010"]~=nil) then
		-- 			for k,v in pairs(obj.taskObj.taskList["1"]) do
		-- 				if k=='1010' or k=='50001010' then
		-- 					for k1,v1 in pairs(v) do
		-- 						if k1=='tasks' then
		-- 							for k2,v2 in pairs(v1) do
		-- 								self:D('jaylog firstTask4 need moveTo ',v2['X'],v2['Y']+3)
		-- 								obj:moveTo(v2['X'],v2['Y']+3,true,1,99999)
		-- 							end
		-- 						end
		-- 					end
		-- 				end
		-- 			end
		-- 			result['m'] = {obj.syncMsg['m']}
		-- 		end
		-- 	end
		-- end
		local loginTime2 = self.callBack:getServerTime()
		-- self:DC('jaylog loginTime start7:',self.mFloor((loginTime2-loginTime1)*10000)/10000,loginTime1,loginTime2)
		return result
	end
	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==8 then
		local loginTime1 = self.callBack:getServerTime()

		-- if self.gameRoomSetting['ISYW']==1 then
		-- 	self.itemListFilter.heroList[data['roleID']]:updateInfo()
		-- end
		-- self.itemListFilter.heroList[data['roleID']]:addApiJobGetTask()
		local result = {}
		if self.itemListFilter.heroList[data['roleID']].actorType==0 then
			result['apimsg'] = {}
			self.playerList[data['roleID']]['online'] = true
			self.playerList[data['roleID']]['offLineTime']=0
			self.itemListFilter.heroList[data['roleID']].__customTeamIDWaiting = 0
			self.itemListFilter.heroList[data['roleID']]:checkAPICallBack()
			if self.itemListFilter.heroList[data['roleID']]:getCustomTeamID()>0 then
				local msg = self.itemListFilter.heroList[data['roleID']]:updateTeamInfo(self.itemListFilter.heroList[data['roleID']]:getCustomTeamID(),nil,false)
				result['apimsg'] = msg['apimsg']
			end
		end
		-- if self.itemListFilter.heroList[data['roleID']].autoMove then
		self:D('jaylog start 8 set autoMoveStartTime:',self.itemListFilter.heroList[data['roleID']].autoMoveStartTime,self.gameTime,data['roleID'])
		self.itemListFilter.heroList[data['roleID']].autoMoveStartTime = self:getGameTime() --+3
		-- end
		if not self.itemListFilter.heroList[data['roleID']].firstAdd or self.gameRoomSetting['ISYW']==0 then
			-- self.itemListFilter.heroList[data['roleID']]:activeTaskSyncMsg()
		else
			self.itemListFilter.heroList[data['roleID']].firstAdd = false
		end
		if self.gameRoomSetting['ISYW']==1 and self.itemListFilter.heroList[data['roleID']].attribute.BADEQUIP==1 then
			-- 重连时弹请修理或替换装备
			self.itemListFilter.heroList[data['roleID']]:updateSyncMsg({bc={{zz=3,mid=103,i=data['roleID']}}})
		end
		--设置牧师的正邪印
		local obj = self.itemListFilter.heroList[data['roleID']]
		if ''..obj.attribute.roleId=='4' or ''..obj.attribute.roleId=='9' then
			obj:refMode2ATKMode()
		end
		-- if self.gameRoomSetting['ISYW']==1 then
		-- 	local obj = self.itemListFilter.heroList[data['roleID']]
		-- 	if obj.taskObj.taskList~=nil and obj.taskObj.taskList["1"]~=nil and (obj.taskObj.taskList["1"]["1010"]~=nil or obj.taskObj.taskList["1"]["50001010"]~=nil) then
		-- 		for k,v in pairs(obj.taskObj.taskList["1"]) do
		-- 			if k=='1010' or k=='50001010' then
		-- 				for k1,v1 in pairs(v) do
		-- 					if k1=='tasks' then
		-- 						for k2,v2 in pairs(v1) do
		-- 							self:D('jaylog firstTask4 need moveTo ',v2['X'],v2['Y']+3)
		-- 							obj:moveTo(v2['X'],v2['Y']+3,true,1,99999)
		-- 						end
		-- 					end
		-- 				end
		-- 			end
		-- 		end
		-- 	end
		-- end
		-- local firstTaskData = self:memcacheLocalGet('firstTaskData'..self.playerList[data['roleID']]['p'])
		-- self:D('jaylog firstTaskData ',firstTaskData)
		-- if firstTaskData~=nil then
		-- 	local msg2 = result['apimsg']
		-- 	msg2[#msg2+1] = {
		-- 		zz=3,
		-- 		i=self.itemID,
		-- 		rp=firstTaskData,
		-- 	}
		-- end

		if self.guideStepNext~=0 then
			result['flow'] = {{i=data['roleID'],step=self.guideStepNext}}
		end

		if self.gameRoomSetting['ISYW']==0 and ((self.tonumber(self.mapModel)==1005) or (self.tonumber(self.mapModel)==1006) or (self.tonumber(self.mapModel)>=5000 and self.tonumber(self.mapModel)<=5010) or (self.tonumber(self.mapModel)>=8000 and self.tonumber(self.mapModel)<=8006) or self.tonumber(self.mapModel)==9006) then-- and self.gameRoomSetting['ISSQLCACHE']==1
			io.writefile('SQLCACHE'..self.mapModel..'.dat',self.cjson.encode(self.callBack.cache))
		end

		local loginTime2 = self.callBack:getServerTime()
		self.loginTime2 = self.callBack:getServerTime()
		-- self:DC('jaylog loginTime start8:',self.mFloor((loginTime2-loginTime1)*10000)/10000,loginTime1,loginTime2,self.mFloor((self.loginTime2-self.loginTime1)*10000)/10000)

		return result
	end
	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==10 then
		local result1 = self:getHeroObjectInfos(data['roleID'],true)
		local resultHero = result1['i']
		for k,v in pairs(resultHero) do
			if v['i']~=data['roleID'] then
				resultHero[k]['aspdr'] = nil
				resultHero[k]['mspdr'] = nil
				resultHero[k]['angel'] = nil
				resultHero[k]['dm1'] = nil
				resultHero[k]['dm2'] = nil
				resultHero[k]['dm3'] = nil
				resultHero[k]['dm4'] = nil
			end
		end
		--self:D('jaylog gameStart 10 result1:',self.cjson.encode(result1),data['roleID'])
		local result2 = self:getNonHeroObjectInfos(data['roleID'],true)
		--self:D('jaylog gameStart 10 result1:',self.cjson.encode(result2),data['roleID'])
		local result = result1
		for k,v in pairs(result2) do
			if type(v)=="table" then
				for k1,v1 in pairs(v) do
					if result[k]==nil then
						result[k]={}
						result[k][#result[k]+1] = v1
					else
						result[k][#result[k]+1] = v1
					end
				end
			end
		end
		result['zz']=1
		result['game'] = {start=11,msize=self.mapSize}
		if self.gameRoomSetting['ISYW']==0 then
			if self.roomStartTime>0 then
				result['game']['gss'] = 1
				result['game']['gst'] = self.roomStartTime
			else
				result['game']['gss'] = 2
				result['game']['gst'] = 0
			end
			if self.gameRemainStartTime>0 then
				result['game']['grs'] = 1
				result['game']['grt'] = self.gameRemainStartTime+self.gameRemainTime
			else
				result['game']['grs'] = 2
				result['game']['grt'] = 0
			end
		else
			result['game']['gss'] = 1
			result['game']['gst'] = 0
			result['game']['grs'] = 2
			result['game']['grt'] = 0
		end
		local auto = 1
		if self.itemListFilter.heroList[data['roleID']].AImode>0 then
			auto = 2
		end
		if self.UIID~=0 then
			result['gameinfo'] = {{part=self.UIID,partBoss=self.UIBoss,step=self.UIStep,mType=3}}
			-- result['gameinfo']['part'] = self.UIID
			-- result['gameinfo']['partBoss'] = self.UIBoss
			-- result['gameinfo']['mType'] = 3
		end
		result['auto']=auto
		--self.forceUpdate = true
		self.playerList[data['roleID']]['online'] = true
		self.playerList[data['roleID']]['offLineTime']=0
		self.itemListFilter.heroList[data['roleID']]:checkAPICallBack()
		return result
	end

	-- local team = ""
	-- local teamlist = {}
	-- local surrenderTime = 0
	-- if (self.status==self.RUNNING and isset(data['game']['reset']) and data['game']['reset']==2 and (self.setting.surrender_time>self.gameTime and  ISDEV==nil and  ISUAT==nil) ) then

	-- 	self:addSyncMsg({bc={{mid=46,zz=3,i=data['roleID']}}})
	-- elseif (self.status==self.RUNNING and data['game']['reset']~=nil and data['game']['reset']==2) then

	-- 		if (self.playerList[data['roleID']]['t']~="B") then
	-- 			team="A"
	-- 			teamlist=self.itemListFilter.heroTeamAList
	-- 		else
	-- 			team="B"
	-- 			teamlist=self.itemListFilter.heroTeamBList
	-- 		end

	-- 		if (self.lastSurrenderTime[team]>self.gameTime and  ISDEV==nil and  ISUAT==nil) then

	-- 			self:addSyncMsg({bc={{mid=47,zz=3,i=data['roleID']}}})
	-- 		else

	-- 		surrenderTime1=15
	-- 		--self:D("SET 投降时间 surrenderTime"..self.cjson.encode(self.surrenderTime))
	-- 		if (self.surrenderTime[team]==0 or self.surrenderTime[team]==nil) then
	-- 			self.surrenderTime[team]=self:getGameTime()+surrenderTime1
	-- 			--self:D("SET 投降时间 1surrenderTime"..self.cjson.encode(self.surrenderTime))
	-- 			self.trySurrender = self.trySurrender + 1
	-- 			for k,value in pairs(teamlist) do
	-- 				--self:D("投降那队的id:"..value.itemID)
	-- 				if (value.teamOrig==team) then
	-- 				if (value.itemID==data['roleID']) then
	-- 					value.isSurrender=true
	-- 					value.surrenderOrder=1
	-- 				else
	-- 					value.isSurrender=nil
	-- 					value.surrenderOrder=0
	-- 				end
	-- 				if value.syncMsg['s'] == nil then
	-- 					value.syncMsg['s'] = {}
	-- 				end
	-- 				--self:D("投降p1",1)
	-- 				--self:D("投降p2",(value.isSurrender==nil and 0 or 1))

	-- 				value.syncMsg['s'][#value.syncMsg['s']+1]={s=31,r=surrenderTime1-1,t=surrenderTime1,i=value.itemID,d=0,p1=1,p2=(value.isSurrender==nil and 0 or 1)}
	-- 				--value.statusList[31]={s=31,r=self.gameTime,t=surrenderTime1+1,i=value.itemID,p1=1,p2=(value.isSurrender==nil and 0 or 1)}
	-- 				value:addStatusList({s=31,r=self.gameTime,t=surrenderTime1+1,i=value.itemID,p1=1,p2=(value.isSurrender==nil and 0 or 1)})
	-- 				end
	-- 			end

	-- 		else

	-- 			local obj=self.allItemList[data['roleID']]
	-- 			if (obj.statusList[31]~=nil and obj.isSurrender==nil) then
	-- 				obj.isSurrender=true
	-- 				--self:D("同意投降.................")
	-- 				surrenderTime=15
	-- 				local numOfA=0
	-- 				local numOfD=0
	-- 				local orderlist={}

	-- 				for k,value in pairs(teamlist) do
	-- 					if (value.teamOrig==team) then
	-- 					if (value.isSurrender==false) then
	-- 						numOfD = numOfD + 1
	-- 						if (value.surrenderOrder>0) then
	-- 							orderlist[value.surrenderOrder]=2
	-- 						end
	-- 					elseif (value.isSurrender==true) then
	-- 						numOfA = numOfA + 1
	-- 						if (value.surrenderOrder>0) then
	-- 							orderlist[value.surrenderOrder]=1
	-- 						end
	-- 					end
	-- 					end
	-- 				end
	-- 				--self:D("投降35")
	-- 				table.sort(orderlist)
	-- 				local p1=1
	-- 				for kk,vv in pairs(orderlist) do
	-- 					p1=p1+math.pow(10,(numOfD+numOfA-kk))*vv
	-- 					--self:D("投降xp1",p1)
	-- 				end

	-- 				obj.surrenderOrder=numOfD+numOfA
	-- 				obj.statusList[31]['p2']=1
	-- 				for k,value in pairs(teamlist) do
	-- 					if (value.teamOrig==team) then
	-- 						if (isset(value.statusList[31])) then
	-- 							if value.syncMsg['s'] == nil then
	-- 								value.syncMsg['s'] ={}
	-- 							end
	-- 							 --如果在status r = 結束時間 t = total 時間
	-- 							value.syncMsg['s'][#value.syncMsg['s']+1]={s=31,r=surrenderTime-(self.gameTime-value.statusList[31]['r'])-1,t=surrenderTime-(self.gameTime-value.statusList[31]['r']),i=value.itemID,p1=p1,p2=(value.isSurrender==nil and 0 or 1)}
	-- 							value:addStatusList({s=31,r=value.statusList[31].r,t=value.statusList[31].t,i=value.statusList[31].i,p1=p1,p2=(value.isSurrender==nil and 0 or 1)})
	-- 						end
	-- 					end
	-- 				end

	-- 			end
	-- 		end
	-- 	end
	-- end

	-- if (self.status==self.RUNNING and data['game']['reset']~=nil and data['game']['reset']==3) then
	-- 	if (self.playerList[data['roleID']]['t']~="B") then
	-- 		team="A"
	-- 		teamlist=self.itemListFilter.heroTeamAList
	-- 	else
	-- 		team="B"
	-- 		teamlist=self.itemListFilter.heroTeamBList
	-- 	end
	-- 	surrenderTime=15
	-- 	if (self.surrenderTime[team]>0) then
	-- 		local obj=self.allItemList[data['roleID']]
	-- 		if (isset(obj.statusList[31]) and obj.isSurrender==nil) then
	-- 			obj.isSurrender=false
	-- 			local numOfA=0
	-- 			local numOfD=0
	-- 			local orderlist={}
	-- 			for k,value in pairs(teamlist) do
	-- 				if (value.teamOrig==team) then
	-- 				if (value.isSurrender==false) then
	-- 					numOfD = numOfD + 1
	-- 					if (value.surrenderOrder>0) then
	-- 						orderlist[value.surrenderOrder]=2
	-- 					end
	-- 				elseif (value.isSurrender==true) then
	-- 					numOfA = numOfA + 1
	-- 					if (value.surrenderOrder>0) then
	-- 						orderlist[value.surrenderOrder]=1
	-- 					end
	-- 				end
	-- 				end
	-- 			end
	-- 			local p1=2
	-- 			table.sort(orderlist)
	-- 			for kk,vv in pairs(orderlist) do
	-- 				p1=p1+math.pow(10,(numOfD+numOfA-kk))*vv
	-- 			end

	-- 			obj.surrenderOrder=numOfD+numOfA
	-- 			obj.statusList[31]['p2']=1
	-- 			for k,value in pairs(teamlist) do
	-- 				if (value.teamOrig==team and isset(value.statusList[31])) then
	-- 					if value.syncMsg['s'] == nil then
	-- 							value.syncMsg['s'] ={}
	-- 					end
	-- 					value.syncMsg['s'][#value.syncMsg['s']+1]={s=31,r=surrenderTime-(self.gameTime-value.statusList[31]['r'])-1,t=surrenderTime-(self.gameTime-value.statusList[31]['r']),i=value.itemID,p1=p1,p2=(value.isSurrender==nil and 0 or 1)}
	-- 					value.statusList[31]['p1']=p1
	-- 				end
	-- 			end
	-- 		end
	-- 	end
	-- end

	return data
end

-- 通过pid获取玩家Cache
function WorldBase:getPlayerCache(pid)
end
	
--- 注册玩家信息，玩家信息由匹配程序传入
-- @param pdata table -- 匹配程序传入的玩家信息
-- @return data table -- 由loginWaitingList返回
function WorldBase:registerPlayer(pdata)
	local firstTime = self.callBack:getServerTime()
	-- self:DC('jaylog checkRegisterTime registerPlayer ',self.callBack:getServerTime())
	local retdata = {}
	local data = {}
	self:D('jaylog WorldBase registerPlayer pdata:'..self.cjson.encode(pdata),self.callBack:getServerTime())
	for k,data in pairs(pdata) do
		-- local ret = self:redisCall('sismember','room0',data['p'])
		-- self:D('jaylog WorldBase:registerPlayer '..self.__waitQueue.." "..data['p'].." : ",ret)
		-- if ret==true then
		-- 	self:D('==== waitQueue room0')
		-- 	local dataTmp = self:memcacheLocalGet('tcphold'..string.base64encode(data['id']))
		-- 	local dataPlayer = self.cjson.decode(dataTmp)
		-- 	if (dataPlayer['m']~=self.sSub(self.className,6)) then
		-- 	-- local heroObj = self.allItemList[dataPlayer['i']]
		-- 	-- heroObj:goToGameRoom()
		-- 		--return nil
		-- 	end
		-- end

		-- if self.status>=self.READY then
		-- 	retdata[#retdata+1] = data
		-- end

		local found = false
		data['ri'] = {}
		if data['l']==nil then
			data['l'] = {}
		end

		if data['l']['isAI']~=nil and data['l']['isAI']==1 then
			self:createHeroAI(data['l']['a'],data['l']['level'],data['l']['team'],nil,nil,nil,data['l']['id'])
		else

			-- self:DC('jaylog checkRegisterTime registerPlayer before check exist ',self.callBack:getServerTime())

			-- player exist in room
			for i=1,self.gameRoomSetting['maxPlayer'] do
				if (isset(self.playerList[i])) then
					if (isset(self.playerList[i]['id'])) then
						if (self.playerList[i]['id']==data['l']['id']) then
							found=true
							data['l']['i']=i
							data['l']['a']=self.playerList[i]['a']
							data['l']['t'] = self:getPlayerTeam(i,data['l']['p'])
							data['l']['mid']=self.gameID
							data['l']['m']=self.playerList[i]['m']
							data['l']['msize']=self.mapSize
							-- if self.itemListFilter.heroList[i].actorType==0 then
							-- 	self.itemListFilter.heroList[i]:addApiJobGetTask()
							-- end
							if self.playerList[i]['recnt'] ==nil then
								self.playerList[i]['recnt'] =0
							end
							self.playerList[i]['online']=false
							self.playerList[i]['offLineTime']=0
							self.playerList[i]['redirectEndTime'] = 0
							self.playerList[i]['recnt']  =  self.playerList[i]['recnt'] + 1
							--self.playerList[i]['ip']=data['l']['ip']
							self.playerList[i]['s'] = data['l']['s']
							self.playerList[i]['ip'] = '192.168.1.123'
							if (isset(self.allItemList[i])) then
								--self:D("setIPaddress:"..data['l']['ip'])
								--self.allItemList[i]:setIPaddress(data['l']['ip'])
								self.allItemList[i]:setIPaddress('192.168.1.123')
								--self.allItemList[i]:setAI(0)
							end
						end
					end
				end
			end

			-- self:DC('jaylog checkRegisterTime registerPlayer after check exist ',self.callBack:getServerTime())

			--for i=1,self.gameRoomSetting['maxPlayer'] do
				if not found then
					if self.tNums(self.playerList)==self.gameRoomSetting['maxPlayer'] then
						data['l']['i'] = -1
						return data
					end
					local i = 0
					-- if data['l']['id']=='bossJay4' then
					-- 	i = self:getItemID()
					-- else
						i = self:getHeroItemID()
					-- end
					if self.playerList[i]==nil then
						found = true
						data['l']['i'] = i
						data['l']['t'] = self:getPlayerTeam(i,data['l']['p'],data['l']['id'])
						data['l']['mid'] = self.gameID
						data['l']['msize'] = self.mapSize
						--self:D('add to room0 '..data['l']['p']);
						-- self:D('jaylog WorldBase:register hasMapZone '..self.cjson.encode(self.gameRoomSetting['hasMapZone']))
						if self.gameRoomSetting['hasMapZone']~=true and (self.tonumber(data['l']['p'])>0) then
							self:D('add to room0 '..data['l']['p']);
							self:redisCall('sadd','room0',self.tonumber(data['l']['p']))
							self:redisCall('srem','onlinePlayer',self.tonumber(data['l']['p']))
						else
							self:D('add to onlinePlayer '..data['l']['p']);
							self:redisCall('sadd','onlinePlayer',self.tonumber(data['l']['p']))
						end
						--self:D('ready to set playerList data:'..self.cjson.encode(data))
						self.playerList[i] = table.deepcopy(data['l'])
						self.playerList[i]['online'] = false
						self.playerList[i]['offLineTime']=0
						self.playerList[i]['redirectEndTime']=0
						self.playerList[i]['recnt'] = 0
						self.playerList[i]['apm'] = 0

						if self.playerList[i]['recnt']==nil then
							self.playerList[i]['recnt'] = 0
						end

						local tcphold={
							i=data['l']['i'],
							m=data['l']['m'],
							sip=data['l']['commip'],
							s=data['l']['s'],
							t=data['l']['t'],
							c=0,
							p=self.gamePort
						}
						self:D("jaylog data..:"..self.cjson.encode(data),self.callBack:getServerTime());
						self:D("jaylog set tcphold:i ",data['l']['i'],' p:',data['l']['p'],' id:',data['l']['id'])
						self:D("jaylog tcphold--base64encode pidx:"..data['l']['i']..' '..data['l']['id'].." tcphold .. : "..self.cjson.encode(tcphold))
						-- self:D("jaylog tcphold--base64encode :"..'tcphold'..data['l']['p'])
						--self:memcacheLocalSet('tcphold'..string.base64encode(data['l']['p']..data['l']['id']),self.cjson.encode(tcphold))
						self:memcacheLocalSet('tcphold'..data['l']['p'],self.cjson.encode(tcphold))
						-- if self.status==self.RUNNING then
						-- 	self:addHero(self.playerList[i]['a'],self.playerList[i]['t'],self.playerList[i]['id'],nil,nil,nil,i)
						-- end
					end
				end
			--end

			-- self:DC('jaylog checkRegisterTime registerPlayer after set tcphold ',self.callBack:getServerTime())

			if found then
				retdata[#retdata+1] = data
				--self:addHero()
			end

			local tmparr = {}
			-- self:D('jaylog start set playerJson:',data['l']['i'],' playerList:',self.cjson.encode(self.playerList[data['l']['i']]),' p:',data['l']['p'],' data:',self.cjson.encode(data['l']))
			if (self.playerList[data['l']['i']]['playerJson']==nil and self.tonumber(data['l']['p'])>0) then
				local i=data['l']['i']
				local playerinfo=self:memcacheLocalGet('playerJson'..self.tonumber(data['l']['p']))
				local cleanDemon = false
				local lockDemon = 3
				local playerData
				if self.tonumber(self.mapModel)==1005 or self.tonumber(self.mapModel)==1006 then
					playerData = self.cjson.decode(playerinfo)
					if playerData['Player']['isFirstPVP']==nil and (playerData['skillDemon']==nil or self.tNums(playerData['skillDemon'])==0) then
						cleanDemon = true
					end
					if (playerData['skillDemon']~=nil and self.tNums(playerData['skillDemon'])~=0) or self.tonumber(playerData['Player']['dmOpen'])==1 then
						lockDemon = 1
					end
					self:D("jaylog 1005 playerInfo:",self.cjson.encode(playerData),cleanDemon)
					playerinfo = self:getAIData(self.mapModel,playerData['Player']['roleId'],playerData['Player']['level'],self.playerList[i]['t'])
				end
				self:D("jaylog 设置playerList:"..i..' '..data['l']['p']..' playerInfo:'..self.cjson.encode(playerinfo),self.callBack:getServerTime())
				if self.playerList[i] == nil then
					self.playerList[i] = {}
				end
				if (playerinfo~=false and playerinfo~="") then
					self.playerList[i]['playerJson']=require(Config.cjson).decode(playerinfo)
					if self.tonumber(self.mapModel)==1001 or self.tonumber(self.mapModel)==1005 or self.tonumber(self.mapModel)==1006 or self.tonumber(self.mapModel)==1008 then
						self.playerList[i]['playerJson']['Player']['aiOpen'] = 2
					end
					if self.tonumber(self.mapModel)==1005 or self.tonumber(self.mapModel)==1006 then
						self.playerList[i]['playerJson']['Player']['skillOpen'] = playerData['Player']['skillOpen']
						self.playerList[i]['playerJson']['Player']['dmOpen'] = lockDemon
						if cleanDemon then
							self.playerList[i]['playerJson']['Player']['DEMON1'] = 0
							self.playerList[i]['playerJson']['Player']['DEMON2'] = 0
							self.playerList[i]['playerJson']['Player']['DEMON3'] = 0
							self.playerList[i]['playerJson']['Player']['DEMON4'] = 0
							self.playerList[i]['playerJson']['skillDemon'] = {}
						end
					end
					if (self.tonumber(self.mapModel)==1005 or self.tonumber(self.mapModel)==1006) and (self.tonumber(self.playerList[i]['a'])==4 or self.tonumber(self.playerList[i]['a'])==9) then
						self.playerList[i]['playerJson']['Player']['ATK'] = self.playerList[i]['playerJson']['Player']['ATK'] * 1.25
					end
					self.playerList[i]['rank']=self.playerList[i]['playerJson']['Player']['rank']
					self.playerList[i]['level']=self.playerList[i]['playerJson']['Player']['level']

					if self.playerList[i]['recnt'] ==nil then self.playerList[i]['recnt'] =0 end

					if ( isset(data['l']['m']) and data['l']['m']>0) then
						self.gameModel=data['l']['m']
					end

				else
					--拿不到玩家数据 call api拿
					local url=self.webapiurl..'getPlayerObj/?playerID='..data['l']['p']..'&version=999'
					webresult=self:saveURLData(url)
					if (webresult==false) then
						url=self.webapiurl2..'getPlayerObj/?playerID='..data['l']['p']..'&version=999'
						webresult=self:saveURLData(url)
					end
					self.playerList[i]['playerJson']=require(Config.cjson).decode(webresult,true)
					if self.playerList[i]['playerJson']['Player']['isFirstPVP']==nil and (playerData['skillDemon']==nil or self.tNums(playerData['skillDemon'])==0) then
						cleanDemon = true
					end
					if (playerData['skillDemon']~=nil and self.tNums(playerData['skillDemon'])~=0) or self.tonumber(playerData['dmOpen'])==1 then
						lockDemon = 1
					end
					if self.tonumber(self.mapModel)==1001 or self.tonumber(self.mapModel)==1005 or self.tonumber(self.mapModel)==1006 or self.tonumber(self.mapModel)==1008 then
						self.playerList[i]['playerJson']['Player']['aiOpen'] = 2
					end
					if self.tonumber(self.mapModel)==1005 or self.tonumber(self.mapModel)==1006 then
						self.playerList[i]['playerJson']['Player']['skillOpen'] = playerData['Player']['skillOpen']
						self.playerList[i]['playerJson']['Player']['dmOpen'] = lockDemon
						if cleanDemon then
							self.playerList[i]['playerJson']['Player']['DEMON1'] = 0
							self.playerList[i]['playerJson']['Player']['DEMON2'] = 0
							self.playerList[i]['playerJson']['Player']['DEMON3'] = 0
							self.playerList[i]['playerJson']['Player']['DEMON4'] = 0
							self.playerList[i]['playerJson']['skillDemon'] = {}
						end
					end
					if (self.tonumber(self.mapModel)==1005 or self.tonumber(self.mapModel)==1006) and self.tonumber(self.playerList[i]['a'])==9 then
						self.playerList[i]['playerJson']['Player']['ATK'] = self.playerList[i]['playerJson']['Player']['ATK'] * 1.25
					end
					self.playerList[i]['rank']=self.playerList[i]['playerJson']['Player']['RANK']
					self.playerList[i]['level']=self.playerList[i]['playerJson']['Player']['level']

					if (isset(data['l']['m']) and data['l']['m']>0) then
						self.gameModel=data['l']['m']
					end

				end
				-- self:DC('jaylog checkRegisterTime registerPlayer after set playerJson ',self.callBack:getServerTime())
				local oh={}
				local ohlvl={}
				local ph={}
				self.playerList[i]['nowtime']=os.time()
				self.playerList[i]['usedtimes']={}
				local hh={}

				data['l']['oh']=oh
				data['l']['ohlvl']=ohlvl
				data['l']['ph']=table.values(ph)
				data['l']['hh']=table.values(hh)
				self.playerList[i]['oh']=oh
				self.playerList[i]['ohlvl']=ohlvl
				self.playerList[i]['ph']=table.values(ph)
				self.playerList[i]['hh']=table.values(hh)
				if self.playerList[i]['recnt'] ==nil then self.playerList[i]['recnt'] =0 end
				--if self.status==self.RUNNING and self.allItemList[i]==nil then
				if self.allItemList[i]==nil then
					if data['l']['id']=='' then
						
					else
						if self.tonumber(self.mapModel)==1005 or self.tonumber(self.mapModel)==1006 then
							self:D("jaylog 1005 playerInfo end:",self.cjson.encode(self.playerList[i]['playerJson']))
						end
						-- self:DC('jaylog change posxy ',self.cjson.encode(data['l']),self.playerList[i]['id'])
						if data['l']['xxxxx']~=nil and data['l']['yyyyy']~=nil and data['l']['xxxxx']~=0 and data['l']['yyyyy']~=0 then
							data['l']['x'] = data['l']['xxxxx']
							data['l']['y'] = data['l']['yyyyy']
						end
						local hero
						if self.gameRoomSetting.ISDEV~=nil and self.gameRoomSetting.ISDEV==1 and self.sFind(data['l']['id'],'testBOSS')~=nil then
							hero = self:addBoss(2018,self.playerList[i]['t'],self.playerList[i]['id'],data['l']['x'],data['l']['y'],0,i)
							hero.AImode = 0
						else
							hero = self.addHero(self,self.playerList[i]['a'],self.playerList[i]['t'],self.playerList[i]['id'],data['l']['x'],data['l']['y'],nil,i)
						end
						if self.tonumber(self.mapModel)==1005 or self.tonumber(self.mapModel)==1006 or self.tonumber(self.mapModel)==1001 or self.tonumber(self.mapModel)==1008 then
							hero:addStatusList({zz=3,s=609,r=self.gameTime,t=99999})
						end
						hero.lastAutoCallApiTime = self.gameTime + 60
						--设置牧师的正邪印
						if ''..hero.attribute.roleId=='4' or ''..hero.attribute.roleId=='9' then
							if hero.attribute.SKILLOPEN[2]==1 then
								hero:setMode2ATKMode(self.tonumber(self.playerList[i]['playerJson']['Player']['skillStatus']))
							end
						end
						-- if self.gameRoomSetting.ISDEV~=nil and self.gameRoomSetting.ISDEV==1 and data['l']['id']=='jaysd42' or data['l']['id']=='浪漫的尤洛霆' then
							if self.gameRoomSetting['ISYW']==1 and (data['l']['isApi']~=nil and data['l']['isApi']==1) or (data['l']['isFromWF']~=nil and data['l']['isFromWF']==1) then
								hero:addApiCall({},'player','updateAfterGVB')
								hero:addApiJobGetTask()
								hero:addApiCall({},'player','getTipsStatusList')
							end
							if self.gameRoomSetting['ISYW']==1 and (data['l']['isMatch']~=nil and data['l']['isMatch']==1) then --or (data['l']['isWF']~=nil and data['l']['isWF']==1)
								hero:updateTask()
							end
							if data['l']['isFromWF']~=nil and data['l']['isFromWF']==1 then
								hero.redirectRoomTime = self.gameTime + 2
							end
						-- else
							-- hero:addApiJobGetTask()
						-- end
						hero:executeAPICall(true)
						if data['l']['fm']~=nil and data['l']['fm']~=0 then
							self.playerList[i]['fm'] = data['l']['fm']
						end
						if data['l']['fmX']~=nil and data['l']['fmX']~=0 then
							self.playerList[i]['fmX'] = data['l']['fmX']
						end
						if data['l']['fmY']~=nil and data['l']['fmY']~=0 then
							self.playerList[i]['fmY'] = data['l']['fmY']
						end
						-- if self.gameRoomSetting['ISYW']==1 then
						-- 	self.itemListFilter.heroList[i]:updateInfo()
						-- end
						-- if self.sFind(hero.loginID,'jyTest')~=nil or self.sFind(hero.loginID,'npTest')~=nil then
						-- 	hero:setAuto(true)
						-- end
						-- 加危险区域提示
						if self.gameRoomSetting['ISYW']==1 then
							local mapNum = self.tonumber(self.mapModel)
							-- if hero.attribute.school==1 and mapNum>100 and mapNum<200 then
							-- 	hero:addStatusList({s=74,r=self.gameTime,t=20})
							-- end
							-- if hero.attribute.school==2 and mapNum>500 and mapNum<700 then
							-- 	hero:addStatusList({s=74,r=self.gameTime,t=20})
							-- end
							if hero.attribute.school==1 and ((mapNum>=60 and mapNum<100) or (mapNum>500 and mapNum<700)) then
								hero:addStatusList({zz=3,s=75,r=self.gameTime,t=20})
							end
							if hero.attribute.school==2 and ((mapNum>=10 and mapNum<60) or (mapNum>100 and mapNum<200)) then
								hero:addStatusList({zz=3,s=75,r=self.gameTime,t=20})
							end
							if self.playerList[hero.itemID]['playerJson']['Player']['addStatus']~=nil then
								for ask,asv in pairs(self.playerList[hero.itemID]['playerJson']['Player']['addStatus']) do
									hero:addStatusList({zz=3,s=self.tonumber(asv),r=self.gameTime,t=99999})
									if self.tonumber(asv)==603 then
										local attributes = {}
										attributes['MSPD_DOWN_RATE'] = 100
										attributes['MSPD_DOWN'] = 50
										attributes['BUFFTIME'] = 99999
										local duration = 99999
										local buff = require("gameroomcore.SBuff").new(self,hero:__skillID2buffID(1),attributes,duration,{},0,hero.itemID,hero.itemID)
										hero:addBuff(buff)
									end
								end
							end
						end
						-- 增加技能锁定状态
						local skillOpen = self.tonumber(self.playerList[i]['playerJson']['Player']['skillOpen'])
						local aiOpen = self.tonumber(self.playerList[hero.itemID]['playerJson']['Player']['aiOpen'])
						local dmOpen = self.tonumber(self.playerList[hero.itemID]['playerJson']['Player']['dmOpen'])
						if self.gameRoomSetting['ISGVB']==1 then
							dmOpen = 2
						end
						local extraOpen = dmOpen*10+aiOpen
						hero:addStatusList({zz=3,s=88,r=self.gameTime,t=99999,p1=skillOpen,p2=8,p3=extraOpen,p4=1})
						-- GVB增加流程转换表功能
						if self.gameRoomSetting['ISGVB']==1 then
							self:__loadFlowMapping(hero.attribute.roleId)
							if self:isWFRoom() then
								-- 无缝记录上次AI按钮开启情况，本次无缝继续上次AI按钮开启	情况
								if self.tonumber(self.playerList[i]['playerJson']['Player']['AImode'])>(hero.AImode+1) then
									hero:setAuto(true)
								elseif self.tonumber(self.playerList[i]['playerJson']['Player']['AImode'])<(hero.AImode+1) then
									hero:setAuto(false)
								end
							end
						end
					end
				end
				-- self:DC('jaylog checkRegisterTime registerPlayer after add hero ',self.callBack:getServerTime())
				if (data['l']['isMatch']~=nil and data['l']['isMatch']==1) or (data['l']['isWF']~=nil and data['l']['isWF']==1) then
					self.allItemList[data['l']['i']].firstAdd = false
				else
					self.allItemList[data['l']['i']].firstAdd = true
				end
			else
				self.allItemList[data['l']['i']].firstAdd = false
			end
			self:D('jaylog register after set playerJson:',self.callBack:getServerTime())
			-- self:DC('jaylog checkRegisterTime registerPlayer after set playerJson and add hero ',self.callBack:getServerTime())

			if data['l']['rd']~=nil and data['l']['rd']=='yes' then
				local tcphold={
					i=data['l']['i'],
					m=data['l']['m'],
					sip=data['l']['commip'],
					t=data['l']['t'],
					c=1,
					p=self.gamePort
				}
				self:D("jaylog tcphold--redirect rewrite pidx:"..data['l']['i']..' '..data['l']['id'].." tcphold .. : "..self.cjson.encode(tcphold)..' data-l:'..self.cjson.encode(data))
				self:memcacheLocalSet('tcphold'..data['l']['p'],self.cjson.encode(tcphold))
				-- if empty(self.allItemList[data['l']['i']].taskObj.taskList) then
				-- 	self.allItemList[data['l']['i']]:addApiJobGetTask()
				-- end
				-- if data['l']['rftask']~=nil and data['l']['rftask'] then
				-- 	self.allItemList[data['l']['i']].redirectUpdataTask = true
				-- end
				self.transfer:getPathCache(data['l']['i'])
				if self.gameRoomSetting['ISYW']==0 then
					data['l']['autoMove'] = 0
				end
				--self.itemListFilter.heroList[data['l']['i']].taskObj:getMemcache()
				--self.itemListFilter.heroList[data['l']['i']].counterObj:getMemcache()
				self.allItemList[data['l']['i']].autoMove = data['l']['autoMove']==1 and true or false
				self.allItemList[data['l']['i']].autoMoveStartAI = data['l']['autoMoveStartAI']==1 and true or false
				self:D('jaylog WorldBase:registerPlayer rd:autoMove',data['l']['i'],data['l']['autoMove'],self.allItemList[data['l']['i']].autoMove)
				data['l']['rd'] = nil
				self.playerList[data['l']['i']]['rd'] = nil
				if data['l']['autoMove']==1 then
					self.allItemList[data['l']['i']].autoMoveStartTime = self.gameTime+9999
					self.allItemList[data['l']['i']]:addStatusList({zz=3,s=996,r=self.gameTime,t=9999})
				else
					self.allItemList[data['l']['i']]:removeStatusList(996)
				end
			end

			if data['l']['crc']~=nil then
				-- self:D('jaylog WorldBase:registerPlayer crc:',self.cjson.encode(data['l']['crc']),' data:',self.cjson.encode(data))
				self.allItemList[data['l']['i']]:setChangeRoomCacheData(data['l']['crc'])
			end
		end
	end

	-- self:DC('jaylog checkRegisterTime registerPlayer ',self.callBack:getServerTime(),(self.callBack:getServerTime()-firstTime))

	return self:loginWaitingList(retdata)
end

--- 获取队伍名
-- @param itemID integer - 玩家itemID
-- @param pid integer - 玩家playerID
-- @param loginID string - 玩家loginID
-- @return team string - 队伍名，"A" or "B"
function WorldBase:getPlayerTeam(itemID,pid,loginID)
	--self:D('jaylog WorldBase:getPlayerTeam id'..itemID..' p'..pid)
	if loginID==nil then
		if self.playerList[itemID]==nil then
			loginID = ""
		else
			loginID = self.playerList[itemID]['id']
		end
	end
	local playerJson = self:getPlayerJson(itemID,pid)
	local team = "A"
	if self.gameRoomSetting['teamMode']==2 then
		team = "A"
	elseif self.gameRoomSetting['teamMode']==3 then
		local genAI = false
		for k,v in pairs(self.gameRoomSetting['genAIPVPWorld']) do
			if self.tonumber(self.mapModel)==v then
				genAI = true
			end
		end
		if genAI then
			if playerJson['Player']['school']==1 then
				team = "B"
			elseif playerJson['Player']['school']==2 then
				team = "A"
			end
		else
			if playerJson['Player']['school']==1 then
				team = "A"
			elseif playerJson['Player']['school']==2 then
				team = "B"
			end
		end
	else
		team = ((itemID%2==1) and "A" or "B")
	end
	self:D('jaylog WorldBase:getPlayerTeam id',itemID,' p',pid,' team:',team,self.gameRoomSetting['teamMode'])
	return team
end

function WorldBase:getPlayerJson(itemID,pid)
	if self.playerList[itemID]==nil or (self.playerList[itemID]['playerJson']==nil and self.tonumber(pid)>0) then
		local playerinfo=self:memcacheLocalGet('playerJson'..self.tonumber(pid))
		if (playerinfo~=false and playerinfo~="") then
			return self.cjson.decode(playerinfo)
		else
			--拿不到玩家数据 call api拿
			local url=self.webapiurl..'getPlayerObj/?playerID='..data['l']['p']..'&version=999'
			webresult=self:saveURLData(url)
			if (webresult==false) then
				url=self.webapiurl2..'getPlayerObj/?playerID='..data['l']['p']..'&version=999'
				webresult=self:saveURLData(url)
			end
			self:D('jaylog getPlayerJson webresult:',webresult)
			return self.cjson.decode(webresult,true)
		end
	else
		-- self:D('jaylog WorldBase:getPlayerObj ',itemID,self.cjson.encode(self.playerList[itemID]['playerJson']))
		return self.playerList[itemID]['playerJson']
	end
end

--- syncRoomInfo to client when register
-- @param isReturn bool - 是否只返回数据
-- @return data table - 如果isReturn=true,则返回data,否则不返回
function WorldBase:syncRoomInfo(isReturn)
	if isReturn==nil then
		isReturn = false
	end
	for i=1,self.gameRoomSetting['maxPlayer'] do
		if (self.playerList[i]~=nil) then
			local data = {}
			-- data['ri'] = {
			-- 	id = self.playerList[i]['id'],
			-- 	i = self.playerList[i]['i'],
			-- 	a = self.playerList[i]['a'],
			-- 	t = self.playerList[i]['t']
			-- }
			--self:D('jaylog start syn roomInfo : '..self.cjson.encode(datari)..' i:'..i)
			if not isReturn then
				self:addSyncMsg(data)
			end
		end
	end
	if isReturn then
		return data
	end
end

---转房间
-- @param itemID integer - 玩家ID
-- @param map integer - mapID
-- @param roomID integer - roomID port
-- @param host integer - room host
-- @param x integer - X
-- @param y integer - Y
-- @param gameID integer - 单机用的gameID
-- @param isWF boolean - 是否跳到无缝
-- @param isFromWF boolean - 是否由无缝而来
-- @param noCheckUat boolean - 不检测是否uat
-- @return redirectSuccess boolean - 转房成功
function WorldBase:redirectRoom(itemID,map,roomID,host,x,y,gameID,isWF,isFromWF,noCheckUat)
	self.loginTimeTB1[itemID] = self.callBack:getServerTime()
	local queueNum = self.itemListFilter.heroList[itemID]:getWaitQueue()
	if queueNum>0 then
		self.itemListFilter.heroList[itemID]:updateSyncMsg({bc={{zz=3,mid=107,i=itemID}}})
		return nil
	end
	--local socket = require("socket")
	if host==nil then
		host = "127.0.0.1"
	end
	if roomID==nil then
		roomID = 3007
	end
	if noCheckUat==nil then
		noCheckUat = false
	end
	-- if self.gameRoomSetting['ISUAT']==1 and not noCheckUat then
	-- 	roomID = roomID - 300
	-- end
	if not noCheckUat then
		roomID = roomID - self.tonumber(self.Config.roomIDAdd)
	end
	-- local obj = self.allItemList[itemID]
	-- if obj~=nil and obj.actorType==0 and not obj.isAI then
	-- 	obj:updateInfo()
	-- end
	-- con = assert(self.socket.connect(host,roomID))

	-- local sendData = {lbatch={}}
	-- sendData['lbatch'][#sendData['lbatch']+1]={
	-- 	l={
	-- 		m=map,
	-- 		ver='skip',
	-- 		id=self.playerList[itemID]['id'],
	-- 		p=self.playerList[itemID]['p'],
	-- 		commip=self.playerList[itemID]['commip'],
	-- 		a=self.playerList[itemID]['a'],
	-- 		s=self.playerList[itemID]['s'],
	-- 		rd='yes',
	-- 		autoMove=(self.allItemList[itemID].autoMove and 1 or 0),
	-- 		autoMoveStartAI=(self.allItemList[itemID].autoMoveStartAI and 1 or 0),
	-- 		x=x,
	-- 		y=y,
	-- 		fm=(self.gameRoomSetting['ISYW']==1 and self.mapModel or 0),	--from map
	-- 		fmX=(self.gameRoomSetting['ISYW']==1 and self.allItemList[itemID].initX or 0),
	-- 		fmY=(self.gameRoomSetting['ISYW']==1 and self.allItemList[itemID].initY or 0),
	-- 		isWF=isWF and 1 or 0,
	-- 		isFromWF=isFromWF and 1 or 0,
	-- 		serverID=self.playerList[itemID]['serverID'],
	-- 		crc=self.allItemList[itemID]:getChangeRoomCacheData((isWF~=nil and isWF)),
	-- 	}
	-- }
	-- sendData['mID'] = map
	local sendData = self:getSendData(itemID,map,roomID,host,x,y,gameID,isWF,isFromWF,noCheckUat)
	
	self:D('jaylog redirectRoom con:',self.cjson.encode(sendData),host,'roomID:',roomID,'itemID:',itemID,'map:',map,'worldSubMode:',self.gameRoomInfoAll[map]['worldSubMode'],self.allItemList[itemID].autoMove,self.cjson.encode(self.playerList[itemID]))
	-- con:send(self.cjson.encode(sendData).."\n")
	-- local ret,status,partial = con:receive()
	-- self:D('jaylog receive: ret:',ret,' status:',status,' partial:',partial)
	-- con:close()
	-- local result = self.cjson.decode(ret)
	-- self:D('jaylog redirectRoom ret:'..ret..' result:'..self.cjson.encode(result))
	-- return result['1']
	self.transfer:savePathCache(itemID)
	-- self.itemListFilter.heroList[itemID].taskObj:setMemcache()
	-- self.itemListFilter.heroList[itemID].counterObj:setMemcache()
	if (self.gameRoomSetting.mIDIsLocalServer~=nil and table.inTable(self.gameRoomSetting.mIDIsLocalServer,map)) or self.tonumber(self.gameRoomInfoAll[map]['worldSubMode'])==1 then
		-- for k,v in pairs(sendData['lbatch']) do
		-- 	if sendData['lbatch'][k]['l']['crc']['taskList']~=nil then
		-- 		sendData['lbatch'][k]['l']['crc']['taskList'] = {}
		-- 	end
		-- end
		-- self:memcacheSet('gameID'..self.playerList[itemID]['p'],self.formula:getRandnum(10000,99999)..self.playerList[itemID]['p'])
		-- gameID = self:memcacheGet('gameID'..self.playerList[itemID]['p'])
		-- sendData['gameID'] = gameID
		-- self:D('jaylog set gameID ',gameID,'gameID'..self.playerList[itemID]['p'])
		-- local localdata = {command=sendData,memcache={},mID=map,gameID=gameID}
		-- localdata['memcache']['aoePlayerData'..self.playerList[itemID]['p']] = self.playerList[itemID]['playerJson']
		-- self:D('jaylog redirectRoom localdata ',self.cjson.encode(localdata),self.playerList[itemID]['p'])
		self.allItemList[itemID]:updateInfo()
		self.allItemList[itemID]:executeAPICall(true)
		local localServerData,localRoomData = self:getLocalServerData(itemID,map,sendData)
		self:D('jaylog redirectRoom localServerData',self.cjson.encode(localServerData),' localRoomData',self.cjson.encode(localRoomData))
		-- local response = self.cjson.encode({errcode=0,mes='',data={localServer={roomData=self.cjson.encode(localdata),mID=map,gameID=gameID}}})
		local response = string.base64encode(self.cjson.encode({errcode=0,mes='',data=localServerData}))
		local response2 = string.base64encode(self.cjson.encode(localRoomData))
		self.allItemList[itemID]:removeWaitQueue()
		self.allItemList[itemID]:activeSyncMsg(response2,3)
		self.allItemList[itemID]:activeSyncMsg(response,1)
		self.playerList[itemID]['online'] = false
		self.playerList[itemID]['offLineTime'] = self.gameTime - self.gameRoomSetting.offlineRemoveWaitTime
		-- self:D('jaylog redirectRoom syncMsg:',self.cjson.encode(self.allItemList[itemID].syncMsg))
	else
		self.playerList[itemID]['redirectEndTime'] = self:getGameTime() + 1
		self:sendtoOtherGameRoom(sendData,host,roomID,itemID)
	end
	return self.redirectSuccess
end

--- 获取sendData
-- @param itemID integer - 玩家ID
-- @param map integer - mapID
-- @param roomID integer - roomID port
-- @param host integer - room host
-- @param x integer - X
-- @param y integer - Y
-- @param gameID integer - 单机用的gameID
-- @param isWF boolean - 是否跳到无缝
-- @param isFromWF boolean - 是否由无缝而来
-- @param noCheckUat boolean - 不检测是否uat
-- @return sendData table - sendData数据
function WorldBase:getSendData(itemID,map,roomID,host,x,y,gameID,isWF,isFromWF,noCheckUat)
	if host==nil then
		host = "127.0.0.1"
	end
	if roomID==nil then
		roomID = 3007
	end
	if noCheckUat==nil then
		noCheckUat = false
	end
	local sendData = {lbatch={}}
	sendData['lbatch'][#sendData['lbatch']+1]={
		l={
			m=map,
			ver='skip',
			id=self.playerList[itemID]['id'],
			p=self.playerList[itemID]['p'],
			commip=self.playerList[itemID]['commip'],
			a=self.playerList[itemID]['a'],
			s=self.playerList[itemID]['s'],
			rd='yes',
			autoMove=(self.allItemList[itemID].autoMove and 1 or 0),
			autoMoveStartAI=(self.allItemList[itemID].autoMoveStartAI and 1 or 0),
			x=x,
			y=y,
			xxxxx=0,
			yyyyy=0,
			fm=(self.gameRoomSetting['ISYW']==1 and self.mapModel or 0),	--from map
			fmX=(self.gameRoomSetting['ISYW']==1 and self.allItemList[itemID].initX or 0),
			fmY=(self.gameRoomSetting['ISYW']==1 and self.allItemList[itemID].initY or 0),
			isWF=isWF and 1 or 0,
			isFromWF=isFromWF and 1 or 0,
			serverID=self.playerList[itemID]['serverID'],
			crc=self.allItemList[itemID]:getChangeRoomCacheData((isWF~=nil and isWF)),
		}
	}
	sendData['mID'] = map
	sendData['fm']=(self.gameRoomSetting['ISYW']==1 and self.mapModel or 0)
	if isWF then
		self:memcacheSet('gameID'..self.playerList[itemID]['p'],self.formula:getRandnum(10000,99999)..self.playerList[itemID]['p'])
	end
	return sendData
end

--- 获取localServerData
-- @param itemID integer - 玩家ID
-- @param map integer - mapID
-- @param sendData table - sendData数据
-- @return ret,ret2 table,table - localServerData数据
function WorldBase:getLocalServerData(itemID,map,sendData)
	for k,v in pairs(sendData['lbatch']) do
		if sendData['lbatch'][k]['l']['crc']['taskList']~=nil then
			sendData['lbatch'][k]['l']['crc']['taskList'] = {}
		end
	end
	self:memcacheSet('gameID'..self.playerList[itemID]['p'],self.formula:getRandnum(10000,99999)..self.playerList[itemID]['p'])
	gameID = self:memcacheGet('gameID'..self.playerList[itemID]['p'])
	sendData['gameID'] = gameID
	self:D('jaylog set gameID ',gameID,'gameID'..self.playerList[itemID]['p'])
	local localdata = {command=sendData,memcache={},mID=map,gameID=gameID}
	localdata['memcache']['aoePlayerData'..self.playerList[itemID]['p']] = self.playerList[itemID]['playerJson']
	self:D('jaylog redirectRoom localdata ',self.cjson.encode(localdata),self.playerList[itemID]['p'])
	local ret = {localServer={mID=map,gameID=gameID}}	--roomData=self.cjson.encode(localdata),
	local ret2 = localdata
	-- local ret = {localServer={roomData=localdata,mID=map,gameID=gameID}}
	self:D('jaylog getLocalServerData ret',self.cjson.encode(ret),' ret2',self.cjson.encode(ret2))
	return ret,ret2
end

--- 用于执行ready和init流程
function WorldBase:initStep()
	self:__initSQLCache()
	self:randAIPlan()
	self:setupGameMap()
	self:setMapSize(self.gameRoomSetting['maxPlayer'])
	self.worldNum = string.sub(self.className,6)
	if self.status<self.READY then
		self:ready()
	end
	if self.status==self.INIT then
		self:init()
	end
end

--- 设置准备完成状态
-- @param null
-- @return null
function WorldBase:ready()
	--self:D('ready playerJson == all : '..self.cjson.encode(self.playerList))
	local firstTime = self.callBack:getServerTime()
	-- self:DC('jaylog checkRegisterTime ready ',self.callBack:getServerTime())
	self:__loadData()

	self.status = self.READY
	-- self:DC('jaylog checkRegisterTime ready ',self.callBack:getServerTime(),(self.callBack:getServerTime()-firstTime))
	--self.readyTime = self.serverTime
	-- self:memcacheSet('gameServerLivePort'..self.gamePort,2)
end

--- load初始数据function
-- @param null
-- @return null
function WorldBase:__loadData()
	--self:__loadEnemy()
	--self:__loadEnemySkill()
	--self:__loadBoss()
	--self:__loadBossSkill()
	--self:__loadNPC()
	self:__loadFlow()
end

--- init sql cache from file
-- @param mapModel int - 地图ID
-- @param roleID int - 角色ID
-- @return null
function WorldBase:__initSQLCache()
	if (self.gameRoomSetting['ISYW']==0 and ((self.tonumber(self.mapModel)==1005) or (self.tonumber(self.mapModel)==1006) or (self.tonumber(self.mapModel)>=5005 and self.tonumber(self.mapModel)<=5008) or (self.tonumber(self.mapModel)>=8000 and self.tonumber(self.mapModel)<=8006) or self.tonumber(self.mapModel)==9006)) or self.gameRoomSetting.ISLOCAL==1 then-- and self.gameRoomSetting['ISSQLCACHE']==1
		local path = ''
		if self.gameRoomSetting.ISLOCAL==1 then
			path = SCRIPTSPATH.."/m"
		end
		local filename = path..'SQLCACHE'..self.mapModel..'.dat'
		-- self:DC('jaylog WorldBase:__initSQLCache 1:',filename)
		local info = io.readfile(filename)
		if info~=nil then
			-- self:DC('jaylog WorldBase:__initSQLCache 2:',filename,self.sLen(info))
			if self.gameRoomSetting.ISLOCAL==1 then
				local mp = require("gameroom.MessagePack")
				self.callBack.cache = mp.unpack(info)
			else
				self.callBack.cache = self.cjson.decode(info)
			end
		end
	end
end

---设置地图size
-- @param total int - 游戏房间人数
-- @return null
function WorldBase:setMapSize(total)
	self.mapSize = math.floor(total/2)
end

---设置地图ID
-- @param mapModel int - 地图ID
-- @return null
function WorldBase:setMapModel(mapModel)
	self:D('jaylog WorldBase:setMapModel mapModel:'..mapModel)
	self.mapModel = mapModel
end

-- status等于READY时执行
function WorldBase:statusREADY()
	-- self:D('start ready status')
	-- local ok = true
	-- for i=1,self.gameRoomSetting['maxPlayer'] do
	-- 	if self.playerList[i]~=nil and self.status~=self.RUNNING then
	-- 		self:setItemID(i)
	-- 		self:D('jayLog statusREADY addHero:'..self.cjson.encode(self.playerList))
	-- 		self:addHero(self.playerList[i]['a'],self.playerList[i]['t'],self.playerList[i]['id'])	   --,self.playerList[i]['si']
	-- 	end
	-- end
	-- self:setItemID(101)
	self.status = self.INIT
end

--- 登录返回信息
-- @param data table -- 登录或注册时传入的玩家信息
-- @return data table -- 玩家或玩家+游戏房信息
function WorldBase:loginWaitingList(data)
	-- data['ri'] = {}
	local players = {}
	local guildList = {A=0,B=0}
	local total = 0
	local delay = -1
	self:D('loginWaitingList firstIn : ',self.cjson.encode(data),self.callBack:getServerTime())
	--self:D('loginWait playerList : '..self.cjson.encode(self.playerList))
	for i=1,self.gameRoomSetting['maxPlayer'] do
		if self.playerList[i]~=nil then
			total = total + 1
			delay = -1
			if self.playerList[i]['ok']==nil then
				delay = self.waitingTime - (self.serverTime - self.startWaitingTime)
			end

			if self.playerList[i]['id']~=nil and self.playerList[i]['p'] ~=nil then

				-- data['ri'][#data['ri']+1] = {
				-- 	id=self.playerList[i]['id'],
				-- 	i=self.playerList[i]['i'],
				-- 	a=self.playerList[i]['a'],
				-- 	t=self.playerList[i]['t']
				-- --,tf=self.playerList[i]['tf'],eg=self.playerList[i]['eg'],si=self.playerList[i]['si'],d=delay,gn=self.playerList[i]['guildName'],ba=self.playerList[i]['ba']
				-- }
				players[self.tostring(self.playerList[i]['p'])] = {}
				players[self.tostring(self.playerList[i]['p'])] = table.deepcopy(self.playerList[i])

			end
		end
	end
	--self:D("players .. : "..self.cjson.encode(players))
	--设置玩家自己的roominfo
	-- if ( data['l'] ~=nil and isset(data['l']['id'])) then
	-- 	delay=math.round(self.waitingTime-(self.serverTime-self.startWaitingTime),2)
	-- end

	self:setPlayerListMemcache(players)
	if (#(self.playerList)>=self.gameRoomSetting['maxPlayer']) then
		self:D("loginWaitingList set gameServerLivePort is 2  ")
		self:memcacheSet('gameServerLivePort'..self.gamePort,-self.gameRoomInfo['mID'])
	end
	if (isset(data['l']) and data['l']['ver']=="skip") then
		--data['ri']=nil
	end

	self:D('loginWaitingList return data:',self.cjson.encode(data),self.callBack:getServerTime())
	return data
end

-- 设置玩家Cache
function WorldBase:setRoomCache(players)
	self:memcacheSet('gameServerLivePort'..self.gamePort,-self.gameRoomInfo['mID'])
	self:setPlayerListMemcache(players)
end

--- status等于init时执行
-- @param null
-- @return null
function WorldBase:init()
	local firstTime = self.callBack:getServerTime()
	-- self:DC('jaylog checkRegisterTime init ',self.callBack:getServerTime())
	self:D("jaylog enter init ",self.status)
	--初始化itemID
	self.itemHeroID = 1
	self.itemID = 1001
	--self.forceUpdate = true
	self.startTime = self.serverTime
	self:setGameTime(self.serverTime)

	self:gengameRoomSetting()
	self:genMonsterSetting()

	if self.gameRoomSetting['ISYW']==1 or self.gameRoomSetting['autoAddCreature'] then
		self:genTransitDoor()
		self:createYWAllEnemy()
		self:createYWAllBoss()
		self:createYWAllNPC()
		self:createYWAllEnemyAlone()
		-- if self.tonumber(self.mapModel)==101 or self.tonumber(self.mapModel)==10 or self.tonumber(self.mapModel)==501 then
			self:createTmpHero()
		-- end
	end
	self.status = self.RUNNING

	--统一处理gameSetting的拆分
	self:splitGameSetting()
	-- self:DC('jaylog checkRegisterTime init ',self.callBack:getServerTime(),(self.callBack:getServerTime()-firstTime))
end

function WorldBase:splitGameSetting()

	if self.setting.world1AIPOS2~=nil and self.setting.world1AIPOS2~="" then
		self:D("WorldBase:splitGameSetting ",self.setting.world1AIPOS2)
		local sp1 = string.split(self.setting.world1AIPOS2,';')
		local sp2 = {}
		for k,v in pairs(sp1) do
			sp2[#sp2+1]=string.splitNumber(v,',')
		end
		self.setting.world1AIPOS2 = sp2
		self.setting.world1AIPOS2Time = string.splitNumber(self.setting.world1AIPOS2Time,',')
	end

	if self.setting.world1AIPOS1~=nil and self.setting.world1AIPOS1~="" then
		self:D("WorldBase:splitGameSetting ",self.setting.world1AIPOS1)
		local sp1 = string.split(self.setting.world1AIPOS1,';')
		local sp2 = {}
		for k,v in pairs(sp1) do
			sp2[#sp2+1]=string.splitNumber(v,',')
		end
		self.setting.world1AIPOS1 = sp2
		self.setting.world1AIPOS1Time = string.splitNumber(self.setting.world1AIPOS1Time,',')
	else
		self.setting.world1AIPOS1 = self.setting.world1AIPOS2
		self.setting.world1AIPOS1Time = self.setting.world1AIPOS2Time
	end




	if self.setting.world1AIPOS3~=nil and self.setting.world1AIPOS3~="" then
		self:D("WorldBase:splitGameSetting ",self.setting.world1AIPOS3)
		local sp1 = string.split(self.setting.world1AIPOS3,';')
		local sp2 = {}
		for k,v in pairs(sp1) do
			sp2[#sp2+1]=string.splitNumber(v,',')
		end
		self.setting.world1AIPOS3 = sp2
		self.setting.world1AIPOS3Time = string.splitNumber(self.setting.world1AIPOS3Time,',')
	else
		self.setting.world1AIPOS3 = self.setting.world1AIPOS2
		self.setting.world1AIPOS3Time = self.setting.world1AIPOS2Time
	end
	
	if self.setting.world1AIPOS4~=nil and self.setting.world1AIPOS4~="" then
		self:D("WorldBase:splitGameSetting ",self.setting.world1AIPOS4)
		local sp1 = string.split(self.setting.world1AIPOS4,';')
		local sp2 = {}
		for k,v in pairs(sp1) do
			sp2[#sp2+1]=string.splitNumber(v,',')
		end
		self.setting.world1AIPOS4 = sp2
		self.setting.world1AIPOS4Time = string.splitNumber(self.setting.world1AIPOS4Time,',')
	else
		self.setting.world1AIPOS4 = self.setting.world1AIPOS2
		self.setting.world1AIPOS4Time = self.setting.world1AIPOS2Time
	end
end

--- 玩家断线后设置玩家离线
-- @param data table - clinent发送的数据
-- @return data table - 原数据返回
function WorldBase:logout(data)
	self:D('jaylog logout data:',self.cjson.encode(data),self.playerList[data['roleID']]['online'],self.playerList[data['roleID']]['offLineTime'])
	if data['roleID']==nil or data['loginID']==nil then
		return data
	end
	if not self.playerList[data['roleID']]['online'] and self.playerList[data['roleID']]['offLineTime']>0 then
		return data
	end
	if self.playerList[data['roleID']]~=nil then
		local dataTmp = self:memcacheLocalGet('tcphold'..self.playerList[data['roleID']]['p'])
		local dataTmp2 = self.cjson.decode(dataTmp)
		if self.gameRoomSetting['ISYW']==1 then
			self.playerList[data['roleID']]['online'] = false
			self.playerList[data['roleID']]['offLineTime']=self.gameTime
			-- self:D('jaylog logout ready updateInfo ISYW:',self.gameRoomSetting['ISYW'])
			if self.itemListFilter.heroList[data['roleID']].actorType==0 and (dataTmp2['p']==self.gamePort or self.gameRoomInfoAll[dataTmp2['m']]['worldMode']~=1) then
				-- local task = self.itemListFilter.heroList[data['roleID']]:getTaskData()
				-- local counter = self.itemListFilter.heroList[data['roleID']]:getObjCounter()
				self.itemListFilter.heroList[data['roleID']]:updateInfo(true)
				self.itemListFilter.heroList[data['roleID']]:updateEquipLose()
				self.itemListFilter.heroList[data['roleID']]:addApiJobUpdateTask()
				self.itemListFilter.heroList[data['roleID']]:addApiJobUpdateCounter()
			end
		end
	end
	if self.status>=self.READY and self.status<self.GAMEOVER then
		return data
	end
end

--- 玩家登录或重连时执行
-- @param data table - client发送的数据
-- @return data table - 原数据返回
function WorldBase:login(data)
	-- self:D("...................lua 版的login  2222 \n")
	-- self:D("login status star : "..self.status)
	-- self:D("login GAMEOVER star : "..self.GAMEOVER)
	-- self:D("login WAITB star : "..self.WAITB)
	-- self:D("login gameModel star : "..self.gameModel)
	-- self:D("login READY star : "..self.READY)
	-- self:D("call 没 call.......................")
	local loginTime1 = self.callBack:getServerTime()
	self.loginTime1 = self.callBack:getServerTime()

	local ver1 = 2
	local ver2 = 2
	if (self.status>=self.GAMEOVER) or data['l']['ver']==nil or (ver1<ver2) then
		data['l'] = {}
		data['l']['t'] = 'C'
		if data['l']['ver']==nil or (ver1<ver2) then
			data['l']['i'] = -4
		else
			data['l']['i'] = -3
			if data['i']~=nil and self.playerList[data['i']]~=nil and self.playerList[data['i']]['p']==data['l']['p'] then
				self.playerList[data['i']] = nil
				players = {}
				for i=1,self.gameRoomSetting['maxPlayer'] do
					if self.playerList[i]~=nil then
						players[self.playerList[i]['p']] = table.deepcopy(self.playerList[i])
					end
				end
				self:setPlayerListMemcache(players)
			end
		end
		return data
	end

	data['l']['i'] = -1
	local found = false

	data['ri'] = {}
	--data['l']['i'] = -2
	local guildList = {A=0,B=0}
	local delay = -1
	for i=1,self.gameRoomSetting['maxPlayer'] do
		if self.playerList[i]~=nil and self.playerList[i]['id']~=nil then
			delay = -1

			-- data['ri'][#data['ri']+1] = {
			-- 	id=self.playerList[i]['id'],
			-- 	i=self.playerList[i]['i'],
			-- 	a=self.playerList[i]['a'],
			-- 	t=self.playerList[i]['t'],
			-- }
			if self.playerList[i]['id']==data['l']['id'] then
				found = true
				data['l']['i']=i
				data['l']['a']=self.playerList[i]['a']
				-- if self.gameRoomSetting['sameTeam'] then
				-- 	data['l']['t']="A"
				-- else
				-- 	data['l']['t']=((i%2==1) and "A" or "B")
				-- end
				data['l']['t'] = self:getPlayerTeam(i,data['l']['p'])
				data['l']['mid']=self.gameID
				data['l']['m']=self.playerList[i]['m']
				data['l']['msize']=self.mapSize

				-- self.playerList[i]['online'] = true
				self.playerList[i]['recnt'] = self.playerList[i]['recnt'] + 1
				self.playerList[i]['ip'] = data['l']['ip']
				if isset(self.allItemList[i]) then
					self.allItemList[i]:setIPaddress(data['l']['ip'])
				end
			end
		end
	end
	--self:D("skinHeroes  world1 data-ph"..self.cjson.encode(data['l']['ph']))
	data['l']['run'] = 1
	data['l']['hostchat'] = self.Config.commUdpChatServer
	data['l']['portchat'] = self.Config.commUdpChatServerPort

	local loginTime2 = self.callBack:getServerTime()
	self:D('jaylog loginTime login:',self.mFloor((loginTime2-loginTime1)*10000)/10000,loginTime1,loginTime2,self.status,self.READY,self.cjson.encode(data))

	if self.status>=self.READY then
		 return data
	end
end

--- clientside操作 取得英雄資料
-- @param id int - 玩家的itemID
-- @param hero int - 查看的英雄itemID, 如無 全部英雄
-- @return heroInfo table - 英雄資料訊息
function WorldBase:heroInfo(id,hero)
	if self.itemListFilter.heroList[id]~=nil then
		local statistic = {}
		if hero==0 then
			if self.gameOverStatistic~=nil then
				statistic = table.deepcopy(self.gameOverStatistic)
			else
				local hurtedTotal,hurtTotal,cureTotal = 0,0,0
				local hurtedinallLast,hurtinallLast,cureinallLast = 0,0,0
				local hurtedP,hurtP,cureP = 0,0,0
				local hurtedMax,hurtMax,cureMax = 0,0,0
				for k,v in pairs(self.itemListFilter.heroList) do
					if v.actorType==0 and v.parent==nil then
						self:D('jaylog heroInfo1 loginID',v.loginID)
						hurtedTotal = hurtedTotal + self.mAbs(v:getCounter('hurted'))
						hurtTotal = hurtTotal + self.mAbs(v:getCounter('hurt'))
						cureTotal = cureTotal + self.mAbs(v:getCounter('cure'))
					end
				end
				-- self:D('jaylog heroInfo het:',hurtedTotal,' ht:',hurtTotal,' ct:',cureTotal)
				for k,v in pairs(self.itemListFilter.heroList) do
					if v.actorType==0 and v.parent==nil then
						self:D('jaylog heroInfo2 loginID',v.loginID)
						local hurtedinall,hurtinall,cureinall = 0,0,0
						if hurtedTotal~=0 then
							hurtedinall = self.mFloor(self.mAbs(v:getCounter('hurted'))/hurtedTotal*100)
							hurtedP = hurtedP + hurtedinall
							if hurtedinallLast<hurtedinall then
								hurtedMax = v:getID()
								hurtedinallLast = hurtedinall
							end
							-- self:D('jaylog heroInfo ',self.mAbs(v:getCounter('hurted'))/hurtedTotal)
						end
						if hurtTotal~=0 then
							hurtinall = self.mFloor(self.mAbs(v:getCounter('hurt'))/hurtTotal*100)
							hurtP = hurtP + hurtinall
							if hurtinallLast<hurtinall then
								hurtMax = v:getID()
								hurtinallLast = hurtinall
							end
							-- self:D('jaylog heroInfo ',self.mAbs(v:getCounter('hurt'))/hurtTotal)
						end
						if cureTotal~=0 then
							cureinall = self.mFloor(self.mAbs(v:getCounter('cure'))/cureTotal*100)
							cureP = cureP + cureinall
							if cureinallLast<cureinall then
								cureMax = v:getID()
								cureinallLast = cureinall
							end
							-- self:D('jaylog heroInfo ',self.mAbs(v:getCounter('cure'))/cureTotal)
						end
						-- statistic[v:getID()] = {i=v:getID(),kh=v:getCounter('killhero'),ks=v:getCounter('killsoldier')+v:getCounter('killmonster'),
						-- kd=v:getCounter('killed'),ka=v:getCounter('killassistant'),eq1=v.equipList[1],eq2=v.equipList[2],eq3=v.equipList[3],eq4=v.equipList[4],
						-- eq5=v.equipList[5],eq6=v.equipList[6],eq7=v.equipList[7],l=v.attribute.level,t=v.teamOrig,
						-- hurted=self.mAbs(v:getCounter('hurted')),hurt=v:getCounter('hurt'),cure=self.mAbs(v:getCounter('cure')),
						-- getFlag=v:getCounter('getFlag'),points=v:getCounter('points')}
						-- self:D('jaylog heroInfo id:',k,' roleId:',v.attribute.roleId,' cure',v:getCounter('cure'),' hurted',self.mAbs(v:getCounter('hurted')),' hurt',self.mAbs(v:getCounter('hurt')),' cure',self.mAbs(v:getCounter('cure')))
						statistic[v:getID()] = {i=v:getID(),kh=v:getCounter('killhero'),ks=v:getCounter('killsoldier')+v:getCounter('killmonster'),
						kd=v:getCounter('killed'),ka=v:getCounter('killassistant'),l=v.attribute.level,t=v.teamOrig,kb=v:getCounter('killboss'),
						hurted=self.mAbs(v:getCounter('hurted')),hurt=v:getCounter('hurt'),cure=self.mAbs(v:getCounter('cure')),
						getFlag=v:getCounter('getFlag'),points=v:getCounter('points'),hurtedinall=hurtedinall,hurtinall=hurtinall,cureinall=cureinall,
						scorefin=v.attribute.school}
						self:D('jaylog heroInfo statistic:',self.cjson.encode(statistic))
					end
				end
				if hurtedP<100 and statistic[hurtedMax]~=nil and statistic[hurtedMax]['hurtedinall']~=nil then
					statistic[hurtedMax]['hurtedinall'] = statistic[hurtedMax]['hurtedinall']+100-hurtedP
				end
				if hurtP<100 and statistic[hurtMax]~=nil and statistic[hurtMax]['hurtinall']~=nil then
					statistic[hurtMax]['hurtinall'] = statistic[hurtMax]['hurtinall']+100-hurtP
				end
				if cureP<100 and statistic[cureMax]~=nil and statistic[cureMax]['cureinall']~=nil then
					statistic[cureMax]['cureinall'] = statistic[cureMax]['cureinall']+100-cureP
				end
			end
			local t = {}
			t[#t+1] = statistic[id]
			for k,v in pairs(statistic) do
				if v['t']==self.itemListFilter.heroList[id].teamOrig and k~=id then
					t[#t+1] = v
				end
			end
			for k,v in pairs(statistic) do
				if v['t']~=self.itemListFilter.heroList[id].teamOrig and k~=id then
					t[#t+1] = v
				end
			end
			statistic = t
		end
		local result = self.itemListFilter.heroList[id]:getAttribute()
		result['hi']['st'] = statistic
		if self.gameOverStatistic~=nil then
			for k,v in pairs(result['hi']['st']) do
				if v['fd'][id]~=nil then
					v['fd'] = v['fd'][id]
				end
			end
		end
		return result
	end
end

--- 加英雄在地圖
-- @param id int - 英雄角色id
-- @param team char - "A" or "B"
-- @param loginID string - 玩家名稱
-- @param posX integer - 出生x坐标
-- @param posY integer - 出生y坐标
-- @param actorID integer - 玩家ID
-- @param isAI boolean - 是否AI
-- @param noAddPos boolean - 是否位置做增量
-- @return heroObj SHero - 英雄object
function WorldBase:addHero(id,team,loginID,posX,posY,skin,actorID,isAI,noAddPos)
	-- for k,v in pairs(self.setting) do
	-- 	self:D('jaylog self.setting ',k)
	-- end
	-- if self.tonumber(self.mapModel)==5001 and isAI then
	-- 	loginID = '小红红'..actorID
	-- 	self.playerList[actorID]['id'] = '小红红'..actorID
	-- end
	self:D('jaylog WorldBase:addHero',id,team,loginID,posX,posY,skin,actorID,isAI,noAddPos)
	local pos
	if team=="A" then
		pos = string.splitNumber(self.setting['heroAInitialPosition'], ',')
	else
		if self.setting['heroBInitialPosition']~=nil then
			pos = string.splitNumber(self.setting['heroBInitialPosition'], ',')
		else
			pos = string.splitNumber(self.setting['heroAInitialPosition'], ',')
		end
	end
	if posX==nil or posY==nil or posX==0 or posY==0 then
		self.gameCounter['hero'..team] = self.gameCounter['hero'..team] + 1
	end
	-- self:D('jaylog WorldBase:addHero id:',id,' team:',team,' x:',posX,' y:',posY,' loginID:',loginID,' skin:',skin,' pos:',self.cjson.encode(pos),' actorID:',actorID,' isAI:',isAI)
	if posX==nil or posY==nil or posX==0 or posY==0 then
		posX = pos[1]
		posY = pos[2]
	end

	if skin==nil then
		skin = 0
	end

	if noAddPos==nil then
		noAddPos = false
	end

	if self.gameRoomSetting['ISYW']==0 and not noAddPos and self.gameCounter['hero'..team]>0 then
		local pos9 = {{posX,posY},{posX-2,posY-2},{posX,posY-2},{posX+2,posY-2},{posX-2,posY},{posX+2,posY},{posX-2,posY+2},{posX,posY+2},{posX+2,posY+2}}
		posX = pos9[self.gameCounter['hero'..team]][1]
		posY = pos9[self.gameCounter['hero'..team]][2]
		-- local addNum = self.mMod(self.gameCounter['hero'..team],3)
		-- if addNum==1 then
		-- 	if self.gameCounter['hero'..team]>0 and self.gameCounter['hero'..team]<=3 then
		-- 		addNum = 0
		-- 	elseif self.gameCounter['hero'..team]>3 and self.gameCounter['hero'..team]<=6 then
		-- 		addNum = 1
		-- 	else
		-- 		addNum = 2
		-- 	end
		-- end
		-- local addY = addNum*2
		-- -- if addY>2 then
		-- -- 	addY = addY - 2
		-- -- end
		-- posY = posY + addY
		-- local addX = self.mMod(actorID,3)
		-- if addX==1 then
		-- 	posX = posX - 2
		-- elseif addX==2 then
		-- 	posX = posX + 2
		-- end
	end

	self:D('jaylog =====ready to create Hero id:',id,' team:',team,' x:',posX,' y:',posY,' loginID:',loginID,' skin:',skin,' pos:',self.cjson.encode(pos),' actorID:',actorID,' isAI:',isAI)
	--self:D('jaylog getItemID:',self:getItemID())
	local hero = self:createHero(id,team,posX,posY,loginID,skin,actorID)
	if isAI==nil then
		isAI = false
	end
	hero.isAI = isAI
	-- self:D('jaylog WorldBase:addHero after createHero '..hero.itemID..' lw:'..hero.attribute.WEAPONLID..' rw:'..hero.attribute.WEAPONRID)
	hero:createInit()
	self:addItem(hero,0.05)
	hero:setSubName('ROLE'..id)

	if self.gameRoomSetting['ISGVB']==1 then
		hero:updateRebirthStatus()
	end

	return hero
end

--- 游戏房结算,结算sql,组织gameOverMsg,call api结算统计
-- @param null
-- @return null
function WorldBase:gameOver()
	--self:D(debug.traceback("", 2))
	self:D("jaylog start  gameOver...")
	-- new game over step start
	local winner = self.gameFlag['winTeam']
	local winarr = {}
	local winStr = ''
	local teamWinStr = {A='0',B='0'}
	local newAPIparameterArray = {}
	--local bonus = {}
	--local bonusStr = ''
	--local tmpbonus = {}
	local dpsTime = 0
	if self.startCalDPSTime>0 then
		dpsTime = self.gameTime-self.startCalDPSTime
	end
	-- if self.gameCounter.pointsA>=self.gameRoomSetting['gameLimitedPoints'] then
	-- 	winner = 'A'
	-- end
	-- if self.gameCounter.pointsB>=self.gameRoomSetting['gameLimitedPoints'] then
	-- 	winner = 'B'
	-- end
	for k,v in pairs(self.itemListFilter.heroList) do
		winarr[""..v.itemID] = 0
		if v.actorType==0 then
			if v.team==winner then
				winarr[""..v.itemID] = 1
				winStr = winStr..'1'
				if teamWinStr[v.team]=='0' then
					teamWinStr[v.team] = '1'
				end
			else
				-- PVP胜利
				if winner=='' and self.gameRoomSetting['ISPVP']==1 then
					if self.gameCounter['pointsA']==self.gameCounter['pointsB'] then
						winarr[""..v.itemID] = 2
						winStr = winStr..'2'
						winner = ''
						if teamWinStr[v.team]=='0' then
							teamWinStr[v.team] = '2'
						end
					elseif self.gameCounter['pointsA']>self.gameCounter['pointsB'] then
						if v.team=='A' then
							winarr[""..v.itemID] = 1
							winStr = winStr..'1'
							winner = 'A'
							if teamWinStr[v.team]=='0' then
								teamWinStr[v.team] = '1'
							end
						else
							winarr[""..v.itemID] = 0
							winStr = winStr..'0'
						end
					elseif self.gameCounter['pointsA']<self.gameCounter['pointsB'] then
						if v.team=='B' then
							winarr[""..v.itemID] = 1
							winStr = winStr..'1'
							winner = 'B'
							if teamWinStr[v.team]=='0' then
								teamWinStr[v.team] = '1'
							end
						else
							winarr[""..v.itemID] = 1
							winStr = winStr..'0'
						end
					else
						winStr = winStr..'0'
					end
				else
					winStr = winStr..'0'
				end
			end
		end
		-- if self.gameCounter.pointsA>=self.gameRoomSetting['gameLimitedPoints'] and v.team=='A' then
		-- 	winarr[""..v.itemID] = 1
		-- end
		-- if self.gameCounter.pointsB>=self.gameRoomSetting['gameLimitedPoints'] and v.team=='B' then
		-- 	winarr[""..v.itemID] = 1
		-- end
		-- if (bonus[v.itemID]==nil) then
		-- 	bonus[v.itemID] = {}
		-- end
		-- bonus[v.itemID][#bonus[v.itemID]+1] = {
		-- 	d=1,
		-- 	i=55001,
		-- 	q=1
		-- }
	end
	-- for kkk,vvv in pairs(bonus) do
	-- 	for kkk2,vvv2 in pairs(vvv) do
	-- 		tmpbonus[#tmpbonus+1]=vvv2['i']..","..vvv2['q']
	-- 	end
	-- end
	-- bonusStr=implode(';',tmpbonus)

	if self.gameRoomSetting['AIMaxPlayer']>0 then
		self.gameRoomSetting['maxPlayer'] = self.gameRoomSetting['maxPlayer'] + self.gameRoomSetting['AIMaxPlayer']
	end

	local peopleCount=0
	-- for i=1,self.gameRoomSetting['maxPlayer'] do
	for i,v in pairs(self.playerList) do
		if (isset(self.playerList[i])) and self.allItemList[i].parent==nil then
			peopleCount = peopleCount + 1
		end
	end

	-- gameScore table --
	local gameOverMsgScore = {}
	self.gameOverMsg['game']['reset'] = 1
	self.gameOverMsg['game']['pointsA'] = self.gameCounter['pointsA']
	self.gameOverMsg['game']['pointsB'] = self.gameCounter['pointsB']
	self.gameOverMsg['game']['gameTime'] = self.mCeil(self.gameTime)
	local teamWinStrAll = teamWinStr['A']..teamWinStr['B']
	self:D('jaylog teamWinStrAll',teamWinStrAll)
	if teamWinStrAll=='10' then
		self.gameOverMsg['game']['w'] = 1
	elseif teamWinStrAll=='01' or teamWinStrAll=='00' then
		self.gameOverMsg['game']['w'] = 2
	elseif teamWinStrAll=='22' then
		self.gameOverMsg['game']['w'] = 3
	else
		self.gameOverMsg['game']['w'] = 4
	end
	-- self.gameOverMsg['game']['w'] = self.tonumber('9'..winStr) 	--winarr
	if self.gameFlag['star1del'] and self.gameCounter['star']>1 then
		self:setGameCounter('star',-1)
	end
	self.gameOverMsg['game']['star'] = self.gameCounter['star']
	--self.gameOverMsg['game']['bonus'] = bonus
	--[[
	local bonus = {}
	for i=1,self.maxPlayer do
		if (bonus[i]==nil) then
			bonus[i] = {}
		end
		bonus[i][#bonus[i]+1] = {
			type=1,
			id=1,
			qty=1
		}
	end
	]]
	newAPIparameterArray['sum'] = {
		game_id=self.gameID,
		startTime=os.date("%Y%m%d%H%M%S",(os.time()-math.ceil(self.startTime))),
		gameTime=self.gameTime,
		endTime=os.date("%Y%m%d%H%M%S",os.time()),
		mapModel=self.mapModel,
		mapmodel=self.mapModel,
		outcome=winner,
		scoreA=self.gameCounter['pointsA'],
		scoreB=self.gameCounter['pointsB'],
		peopleCount=peopleCount,
		game=self.gameOverMsg['game'],
	}
	-- for i=1,self.gameRoomSetting['maxPlayer'] do
	for i,v in pairs(self.playerList) do
		if (isset(self.playerList[i])) and self.allItemList[i].parent==nil then
			--[[
			local gameScore = {
				i = self.playerList[i]['i'],
				id = self.playerList[i]['id'],
				p = self.playerList[i]['p'],
				t = self.playerList[i]['t'],
				points = self.allItemList[i]['counter']['points'],
				bonus = bonus[i]
			}
			gameOverMsgScore[i]=gameScore
			]]
			local StartStr='1'
			local exp = 0
			local heroexp = 0
			local adjGold = 0
			local penalty = 0
			local newRank = 0
			local powreduce = 0
			local mvpplayerid = 0
			local point = 0
			local gold = 0
			local isWin = 0
			--local bonusStr = ''
			--local tmpbonus = {}
			local serverIP=""
			if (isset(self.playerList[i]['commip'])) then
				serverIP=self.playerList[i]['commip']
			end

			if winner=='' then
				isWin = 2
			elseif self.allItemList[i].team==winner then
				isWin = 1
				--newRank = 5
			else
				if self.gameRoomSetting['ISGVB']==1 then
					self.gameCounter['star'] = 0
				end
				--newRank = 1
			end

			local angel1,angel2,angel3 = 0,0,0
			self:D('jaylog start set angel ',self.allItemList[i].attribute.energyBoard~=nil)
			if self.allItemList[i].attribute.energyBoard~=nil then
				self:D('jaylog start set angel ',self.cjson.encode(self.allItemList[i].attribute.energyBoard.energyBoardList))
				angel1 = self.allItemList[i].attribute.energyBoard.energyBoardList['1']==nil and 0 or self.allItemList[i].attribute.energyBoard.energyBoardList['1'].angelID
				angel2 = self.allItemList[i].attribute.energyBoard.energyBoardList['2']==nil and 0 or self.allItemList[i].attribute.energyBoard.energyBoardList['2'].angelID
				angel3 = self.allItemList[i].attribute.energyBoard.energyBoardList['3']==nil and 0 or self.allItemList[i].attribute.energyBoard.energyBoardList['3'].angelID
			end

			local newAPIparameter = {
						start=StartStr,
						game_id=self.gameID,
						camp=self.allItemList[i].teamOrig,
						level=self.allItemList[i].attribute.level,
						hero_id=self.playerList[i]['a'],
						serverID=self.playerList[i]['playerJson']['Player']['serverID'],
						play_win=isWin,
						play_lose=isWin==0 and 1 or 0,
						play_draw=isWin==2 and 1 or 0,
						--penalty=(penalty>0 and 1 or 0),
						play_hero_kill=self.allItemList[i]:getCounter('killhero'),
						play_assist_kill=0,							--self.gameCounter['killassistant']
						play_dead=self.allItemList[i]:getCounter('killed'),
						play_boss_kill=self.allItemList[i]:getCounter('killboss'),
						play_hurted=self.mAbs(self.allItemList[i]:getCounter('hurted')),
						play_hurt=self.mAbs(self.allItemList[i]:getCounter('hurt')),
						play_getFlag=self.allItemList[i]:getCounter('getFlag'),
						play_cure=self.mAbs(self.allItemList[i]:getCounter('cure')),
						play_hurtedBoss=self.mAbs(self.allItemList[i]:getCounter('hurtedBoss')),
						play_hurtBoss=self.mAbs(self.allItemList[i]:getCounter('hurtBoss')),
						dpsTime=dpsTime,
						ipaddr=self.allItemList[i].ipaddress,
						ping=self.allItemList[i].pingtime,
						totalIdle=self.allItemList[i].totalIdleTime,
						maxIdle=self.allItemList[i].maxIdleTime,
						serverIP=serverIP,
						prizeOperate=(self.allItemList[i].skinNum~=nil and self.allItemList[i].skinNum or 0),
						star=self.gameCounter['star'],
						--play_vs_random=(self.gameModel~=nil and self.gameModel==10) and 0 or (gamemode==1 and 1 or 0),
						--play_vs_33=(self.gameModel~=nil and self.gameModel==10) and 0 or (gamemode==2 and 1 or 0),
						--play_vs_ai=gamemode==3 and 1 or 0,
						--play_vs_guild=gamemode==4 and 1 or 0,
						--play_vs_training=(self.gameModel~=nil and self.gameModel==10) and 0 or (gamemode==6 and 1 or 0),
						--play_vs_team=self.isTeam and 1 or 0,
						--play_vs_gambling=(self.gameModel~=nil and self.gameModel==10) and 1 or 0,
						--rank=newRank,
						play_isdead=self.allItemList[i]:isDead() and 1 or 0,
						school=self.playerList[i]['playerJson']['Player']['school'],
						play_time=self.gameTime,
						play_realtime=self.gameTime-self.roomStartTime,
						--powreduce=powreduce,
						mapModel=self.gameModel,
						mapmodel=self.gameModel,
						player_rebirth=self.allItemList[i].counter['revive'],
						--adjCoin=1000,				--adjCoin
						mvplist=0,				--mvpplayerid
						star=self.gameCounter['star'],
						itemID=i,
						isAI=self.allItemList[i].isAI and 1 or 0,
						dm1=self.allItemList[i].attribute.DEMON1,
						dm2=self.allItemList[i].attribute.DEMON2,
						dm3=self.allItemList[i].attribute.DEMON3,
						dm4=self.allItemList[i].attribute.DEMON4,
						angel1=angel1,
						angel2=angel2,
						angel3=angel3,
			}
			if self:isWFRoom() then
				newAPIparameter['AImode'] = self.allItemList[i].AImode+1
			end
			-- if bonus[i]~=nil then
			-- 	for kkk,vvv in pairs(bonus[i]) do
			-- 		tmpbonus[#tmpbonus+1]=vvv['i']..","..vvv['q']
			-- 		--newAPIparameter['itemAchieve_'..vvv['i']] = vvv['q']
			-- 	end
			-- 	bonusStr=implode(';',tmpbonus)
			-- end
			if self.tonumber(self.playerList[i]['p'])<99999999 then
				newAPIparameterArray[self.sFormat(self.playerList[i]['p'])] = newAPIparameter
			else
				if self.mapModel~='8011' then
					newAPIparameterArray[self.sFormat(self.playerList[i]['p']..i)] = newAPIparameter
				end
			end
			--self:D('start to save newAPIparameterArray'..self.cjson.encode(newAPIparameter)..'   '..self.playerList[i]['p']..'  '..self.cjson.encode(newAPIparameterArray))

			if self.playerList[i]['recnt'] ==nil then
				self.playerList[i]['recnt'] =0
			end
			self:D('jaylog newAPIparameter : ',self.cjson.encode(newAPIparameter) ,' p: ',self.cjson.encode(self.playerList[i]['p']))
		end
	end
	
	--self.gameOverMsg['game']['gameScore'] = gameOverMsgScore
	self:D('jaylog gameOverMsg : ',self.cjson.encode(self.gameOverMsg))

	self.gameOverStatistic={}
	for k,value in pairs(self.itemListFilter.heroList) do
		self.gameOverStatistic[value.itemID] = {
			i = value.itemID,
			killhero = value.counter['killhero'],
			hilled = value.counter['killed'],
			hurted = value.counter['hurted'],
			hurt = value.counter['hurt'],
			cure = value.counter['cure'],
			getFlag = value.counter['getFlag'],
			points = value.counter['points']
		}
	end

	--战斗结算call api
	local finishapi = self.webapiurl..'internalapi/finishGameRoomMutil'
	local finishapi2 = self.webapiurl2..'internalapi/finishGameRoomMutil'
	if self.gameRoomSetting.ISLOCAL==1 then
		finishapi = 'http://dev8.zharev.com/AOEApi/pve/finishLocalGVB'
		finishapi2 = 'http://dev8.zharev.com/AOEApi/pve/finishLocalGVB'
	end
	self:D('jaylog newAPIparameterArray...........:' , self.cjson.encode( newAPIparameterArray ) )
	local url=''
	if self.gameRoomSetting.ISLOCAL==1 then
		url = finishapi..'/?data='..string.urlencode(string.base64encode(self.cjson.encode(newAPIparameterArray)))..'&version=999'
	else
		url = finishapi..'/?data='..string.urlencode(self.cjson.encode(newAPIparameterArray))..'&version=999'
	end

	if self.gameRoomSetting.ISLOCAL==1 then
		self.gameOverURL = url
	else
		local webresult=self:file_get_contents(url)
		if (webresult==false) then
			if self.gameRoomSetting.ISLOCAL==1 then
				url=finishapi2..'/?data='..string.urlencode(string.base64encode(self.cjson.encode(newAPIparameterArray)))..'&version=999'
			else
				url=finishapi2..'/?data='..string.urlencode(self.cjson.encode(newAPIparameterArray))..'&version=999'
			end
			webresult=self:file_get_contents(url)
		end
		self:I('url : ',url,' result:',webresult)

		-- 玩家离开清除房间玩家数据 --
		local players={}
		-- for i=1,self.gameRoomSetting['maxPlayer'] do
		for i,v in pairs(self.playerList) do
			if (isset(self.playerList[i]) and self.playerList[i]['online']==false) then
				if self.gameRoomSetting['hasMapZone']~=true and (self.tonumber(self.playerList[i]['p'])>0) then
					self:redisCall('srem','room0',self.playerList[i]['p'])
				end
				if (self.tonumber(self.playerList[i]['p'])>12) then
					rc = {{i=0,m=self.playerList[i]['id'].." 离开了房间",t="",d=0}}
					self:addSyncMsg({rc=rc})
				end
				--self.playerList[i]=nil
			elseif (isset(self.playerList[i])) then
				players[self.playerList[i]['p']]=self.playerList[i]
				if self.gameRoomSetting['hasMapZone']~=true and (self.tonumber(self.playerList[i]['p'])>0) then
					self:redisCall('srem','room0',self.playerList[i]['p'])
				end
			end
		end

		if self.gameRoomSetting['AIMaxPlayer']>0 then
			self.gameRoomSetting['maxPlayer'] = self.gameRoomSetting['maxPlayer'] + self.gameRoomSetting['AIMaxPlayer']
		end
		players['END']=true
		self:setPlayerListMemcache(players)
	end
	self:I("jaylog 有没有call到结束/////////////")
	self.gameOverTime = self.gameTime
	self.status=self.GAMEOVER

	-- if self.gameRoomSetting['ISYW']==0 and self.gameRoomSetting['ISSQLCACHE']==1 then
	-- 	-- self:D('jaylog gameOverMsg cache:',self.cjson.encode(self.callBack.cache))
	-- 	io.writefile('SQLCACHE'..self.mapModel..'.dat',self.cjson.encode(self.callBack.cache))
	-- 	-- io.writefile('jaytest.txt',self.mp.pack(self,self.callBack.cache))
	-- end
	-- new game over step end
end

--- 取api返回数据
-- @param rUrl string - 整个url,包括所有参数
-- @return b string - call url返回的结果
function WorldBase:file_get_contents( rUrl )
	if self.gameRoomSetting.ISLOCAL==1 then
		local rUrlArr = self.sSplit(self.sSub(rUrl,8),'/')
		local url = ''
		for k,v in pairs(rUrlArr) do
			if k==1 then
				url = self.webapiurl3
			elseif k==2 then
			elseif k==3 then
				url = url..v
			else
				url = url..'/'..v
			end
		end
		rUrl = url
	end
	local ret = self.callBack:file_get_contents( rUrl )
	if ret~=nil and ret~="" then
		self:D("file_get_contents 成功...",rUrl)
	else
		self:D("file_get_contents 失敗...",rUrl)
	end
	return ret
end

--- GAMEOVER 游戏结束时执行
-- @param null
-- @return null
function WorldBase:statusGAMEOVER()

	if (self.gameOverTime<=self.gameTime and self.gameOverWaitTime<=self.gameTime and self.gameOverMsg~=nil) then

		if self.gameRoomSetting.ISLOCAL==1 then
			local webresult=self:file_get_contents(self.gameOverURL)
		end

		self:D('jayLog start syn gameOverMsg:'..self.cjson.encode(self.gameOverMsg))
		self:addSyncMsg(self.gameOverMsg)
		self.gameOverWaitTime = self.gameTime + 1
	end

	if (self.gameOverTime+5<=self.gameTime) then
		self.gameOverMsg = nil
		os.exit()
	end
end

--- RUNNING 遊戲loop
-- @return null
function WorldBase:statusRUNNING()
	-- if self.status~=self.GAMEOVER and self.gameRoomSetting['gameLimitedTime']<=self:getGameTime() then
	-- 	self:gameOver()
	-- 	return nil
	-- end
	-- self:D('jaylog redirectRoom start RUNNING')

	local checkTime = {}
	local time = self.callBack:getServerTime()
	if self.comFlag['debug'] then
		checkTime[#checkTime+1] = self.callBack:getServerTime()
		--self:D('jaylog checkSpeed 1 gameOverCheck:'..self.callBack:getServerTime()-time..'----------')
	end
	if self:gameOverCheck() then
		self:gameOver()
		return nil
	end

	if not self.gameFlag.busyFlag and self.gameRoomSetting['ISGVB']==1 then
		local pos = string.splitNumber(self.setting['heroAInitialPosition'], ',')
		local distance = 0
		for k,v in pairs(self.itemListFilter.heroList) do
			distance = self.map:distance(v.posX,v.posY,pos[1],pos[2])
			if v.actorType==0 and distance>5 then
				self.gameFlag.busyStart = true
			end
		end
	end

	if not self.gameFlag.busyFlag and (self.gameTime>=0 or self.gameRoomSetting['hasMapZone']==true or self.gameFlag.busyStart or self.gameRoomSetting['maxPlayer']==1) then
		self.gameFlag.busyFlag = true
		self:memcacheSet('gameServerLivePort'..self.gamePort,-self.gameRoomInfo['mID'])
		self:addHeroAI()
	end

	--------  start core world

	self.numOfKillA = 0
	self.numOfKillB = 0

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 2 moveCalculation:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end
	-- all item move calculation
	self:moveCalculation()

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 3 soldierList move loop:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end

	for k,v in pairs(self.allItemList) do
		if not v:isDead() then
			v:checkStatusList()
		end
	end



	local tmpResetHatredTime = self.mFloor(self.gameTime/10) 
	if tmpResetHatredTime>self.gameFlag.resetHatredTime then
		for k,v in pairs(self.allItemList) do
			if v.actorType~=4 then
				-- self:D('resetHatredTime before ',v.itemID,v.actorType)
				v:calculateHatredList(tmpResetHatredTime-6,tmpResetHatredTime)
				-- self:D('resetHatredTime ',v.itemID,self.cjson.encode(v.Hatredlist))
			end
		end
		self.gameFlag.resetHatredTime = tmpResetHatredTime
	end

	-- hero and soldier move and update loop
	for k,v in pairs(self.itemListFilter.soldierList) do
		if self.forceUpdateSoldier then
				v.dirty = true
		end
		v:syncInfo()
		if not v:isDead() then
			v:move()
			if v.autoToPos then
				v:setMoveTarget(v.autoToPosX,v.autoToPosY,0,11)
				local dist = v:distance(v.autoToPosX,v.autoToPosY)
				if dist<=1 then
					v.autoToPos = false
					v.autoToPosX = 0
					v.autoToPosY = 0
				end
			end
		end
	end
	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 4 npcList move loop:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end
	for k,v in pairs(self.itemListFilter.npcList) do
		if self.forceUpdateSoldier then
				v.dirty = true
		end
		v:syncInfo()
		if not v:isDead() then
			v:move()
			if v.autoToPos then
				v:setMoveTarget(v.autoToPosX,v.autoToPosY,0,11)
				local dist = v:distance(v.autoToPosX,v.autoToPosY)
				if dist<=1 then
					v.autoToPos = false
					v.autoToPosX = 0
					v.autoToPosY = 0
				end
			end
		end
	end
	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 5 noBeFightList move loop:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end
	for k,v in pairs(self.itemListFilter.noBeFightList) do
		if self.forceUpdateSoldier then
				v.dirty = true
		end
		v:syncInfo()
		if not v:isDead() then
			v:move()
			if v.autoToPos then
				v:setMoveTarget(v.autoToPosX,v.autoToPosY,0,11)
				local dist = v:distance(v.autoToPosX,v.autoToPosY)
				if dist<=1 then
					v.autoToPos = false
					v.autoToPosX = 0
					v.autoToPosY = 0
				end
			end
		end
	end
	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 6 heroList move loop:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end
	for k,v in pairs(self.itemListFilter.heroList) do
		if self.forceUpdate then
			v.dirty = true
		end
		v:syncInfo()
		if not v:isDead() then
			v:move()
			if v.autoMove then
				-- self:D('jaylog autoMove condition:',v.autoMove,'amst:',v.autoMoveStartTime,'gt:',self.gameTime,'isyw:',self.gameRoomSetting['ISYW'],'lscdt:',v.lastCoolDownTime)
			end
			if v.autoMove and v.autoMoveStartTime<self.gameTime and self.gameRoomSetting['ISYW']==1 and (v.lastCoolDownTime==nil or v.lastCoolDownTime<self.gameTime) then
				local path = v.movePath[""..self.mapModel]
				self:D('jaylog autoMove ',self.mapModel,' ',self.cjson.encode(v.movePath),' x:',v.posX,' y:',v.posY,' autoMoveStartAI:',v.autoMoveStartAI,self.gameTime)
				if path~=nil then
					-- v:moveTo(path['toX'],path['toY'],false,11)
					v:setMoveTarget(path['toX'],path['toY'],0,11)
					if path['isLast']~=nil and path['isLast']==1 then
						local dist = self.map:distance(v.posX,v.posY,path['toX'],path['toY'])
						-- local skill = v.attribute.skills[1]
						if v.autoMoveStartAI then
							if dist<8 then
								v:setAuto(true)
								v:setAutoMove()
							end
						else
							if v.WFTaskID~=0 and v.autoMoveTaskID~=0 and v.WFTaskID==v.autoMoveTaskID then
							--if v.posX<=path['toX']+2 and v.posX>=path['toX']-2 and v.posY<=path['toY']+2 and v.posY>=path['toY']-2 then
								if dist<10 then
									v:setAutoMove()
									local toX,toY = self.map:getXYLength(path['toX'],path['toY'],v.posX,v.posY,4)
									self:D('jaylog autoMove WFTaskID:',v.loginID,v.WFTaskID,v.autoMoveTaskID,path['toX']+toX,path['toY']+toY)
									v:setMoveTarget(path['toX']+toX,path['toY']+toY,0,11)
								end
							else
								if dist<10 then
									v:setAutoMove()
									local toX,toY = self.map:getXYLength(path['toX'],path['toY'],v.posX,v.posY,3)
									self:D('jaylog autoMove not WFTaskID:',v.loginID,v.WFTaskID,v.autoMoveTaskID,path['toX']+toX,path['toY']+toY)
									v:setMoveTarget(path['toX']+toX,path['toY']+toY,0,11)
								end
							end
						end
					end
				else
					v:setAutoMove()
				end
			elseif v.autoFollow then
				local x,y = 0,0
				local targetObj = self.allItemList[v.autoFollowTargetID]
				if targetObj==nil or targetObj:isDead() then
					v:setAutoFollow()
				else
					local len = self.setting['followStopRange']/self.setting['AdjustVisRange']
					local dist = self.setting['autoFollowRange']/self.setting['AdjustVisRange']
					if v:distance(targetObj.nextPosition.x,targetObj.nextPosition.y,v.autoFollowTargetID)>dist and v.autoFollowTime<self.gameTime then
						x = v.posX - targetObj.nextPosition.x
						y = v.posY - targetObj.nextPosition.y
						if x<0 then
							x = targetObj.nextPosition.x-len
						elseif x==0 then
							x = targetObj.nextPosition.x
						else
							x = targetObj.nextPosition.x+len
						end
						if y<0 then
							y = targetObj.nextPosition.y-len
						elseif y==0 then
							y = targetObj.nextPosition.y
						else
							y = targetObj.nextPosition.y+len
						end
						-- v:moveTo(x,y)
						v:setMoveTarget(x,y)
						v.autoFollowTime = self.gameTime + 1
					end
				end
			elseif v.autoTo then
				local targetObj = self.allItemList[v.autoToTargetID]
				if targetObj==nil or targetObj:isDead() then
					v:setAutoTo()
				else
					local dist = v:distance(targetObj.posX,targetObj.posY)
					local toX,toY = self.map:getXYLength(targetObj.posX,targetObj.posY,v.posX,v.posY,targetObj.attribute.width)
					v:setMoveTarget(targetObj.posX+toX,targetObj.posY+toY,0,11)
					if dist<=targetObj.attribute.width then
						v:setAutoTo(0,1)
					end
				end
			elseif v.autoToPos then
				v:setMoveTarget(v.autoToPosX,v.autoToPosY,0,11)
				local dist = v:distance(v.autoToPosX,v.autoToPosY)
				if dist<=1 then
					v.autoToPos = false
					v.autoToPosX = 0
					v.autoToPosY = 0
				end
			elseif self.gameRoomSetting['ISGVB']==1 and v.sharedID>0 and v.attribute.actorType==0 and v.statusList[4007]~=nil then
				--self:D('jaylog ISGVB find shareObj')
				if (self.gameTime-v.lastMoveTime)>4 then
					--self:D('jaylog ISGVB find shareObj start',self.gameTime,v.lastMoveTime,v.sharedID,shareObj.posX,shareObj.posY)
					local shareObj = self.allItemList[v.sharedID]
					if shareObj~=nil then
						-- v:moveTo(shareObj.posX,shareObj.posY,false,10)
						v:setMoveTarget(shareObj.posX,shareObj.posY,0,10)
					end
				end
			end
		end
	end

	self:processCompletedEndStatus()

	-- calcutation visible or not
	--self:calVisible()

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 7 heroList fight loop:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end
	-- hero fight loop
	for k,v in pairs(self.itemListFilter.heroList) do
		if not v:isDead() then
			v:fight()
		else
			v:revive()
		end
	end

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 8 soldierList fight loop:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end
	-- soldier fight loop
	local killID = 0
	for k,v in pairs(self.itemListFilter.soldierList) do
		if not v:isDead() then
			v:fight()
		else
			v:revive()
		end
	end

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 9 npcList fight loop:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end
	for k,v in pairs(self.itemListFilter.npcList) do
		if not v:isDead() then
			v:fight()
		end
	end

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 10 noBeFightList fight loop:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end
	for k,v in pairs(self.itemListFilter.noBeFightList) do
		if not v:isDead() then
			v:fight()
		end
	end

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 11 bulletFight:'..self.callBack:getServerTime()-time)
		for k,v in pairs(self.allItemList) do
			v.debugchecktime = nil
		end
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end
	-- bullet calculation
	local checkbullettime = self:bulletFight()

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 12 genItem:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end
	self:genItem()
	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 13 genSomeInfo:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end
	self:genSomeInfo()

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 14 syncItemMsgAndremoveItem:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end
	-- sync ping time to players
	self:syncPingTime()

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 15 check allLeft:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end

	self:checkHeroOffLine()

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 16 check allLeft:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end

	self:goToSite()

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 17 check allLeft:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end

	self:syncGameInfo()

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 18 check allLeft:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end

	self:syncHeroInfo()

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 19 check allLeft:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end

	self:excuteFlow()

	--------  end core world

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 20 check allLeft:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end

	-- remove item and output item msg
	self:syncItemMsgAndremoveItem()

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 21 init heroList lastHeroAttack:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end
	-- clear hero flag
	for k,v in pairs(self.itemListFilter.heroList) do
		v.lastHeroAttack = -1
		v.lastHeroAttackForTower = -1
	end

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 22 addSyncMsg:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end

	-- check any player still in gameroom or not .. if no one here .. exit game, start
	-- local allLeft = true
	-- for i=1,self.gameRoomSetting['maxPlayer'] do
	-- 	if self.playerList[i]~=nil and (self.playerList[i]['online']==nil or self.playerList[i]['online']) then
	-- 		allLeft = false
	-- 		if self.gameTime>1800 and self.playerList[i]['id']=='aoeJay1' then
	-- 			self.itemListFilter.heroList[i].deadTime = self.gameTime-15
	-- 		end
	-- 	end
	-- end

	if self.comFlag['debug'] then
		--self:D('jaylog checkSpeed 23 end:'..self.callBack:getServerTime()-time)
		checkTime[#checkTime+1] = self.callBack:getServerTime()
	end

	if self.comFlag['debug'] then
		if (checkTime[#checkTime]-checkTime[1])>0.1 then
			for k,v in pairs(checkTime) do
				if k~=1 then
					self:D('jaylog checkSpeed A key:',k,' v:',self.mFloor((v-checkTime[k-1])*10000)/10000)
				end
			end
			for k,v in pairs(checkbullettime) do
				self:D('jaylog checkSpeed B key:',k,' v:',self.mFloor((v)*10000)/10000)
			end
			local debugchecktime = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
			for k,v in pairs(self.allItemList) do
				if v.debugchecktime~=nil then
					for i=21,40 do
						if v.debugchecktime[i]~=nil and v.debugchecktime[i]>0 and v.debugchecktime[i-1]~=nil and v.debugchecktime[i-1]>0 then
							debugchecktime[i-20] = debugchecktime[i-20] + (v.debugchecktime[i] - v.debugchecktime[i-1])
						end
					end
					debugchecktime[24] = debugchecktime[24] + 1
				end
				v.debugchecktime = nil
			end
			for k,v in pairs(debugchecktime) do
					self:D('jaylog checkSpeed C key:',k,' v:',self.mFloor((v)*10000)/10000)
			end
		end
	end

	-- self:D('jaylog redirectRoom end RUNNING ',self.cjson.encode(self.syncMsg))

	-- if not allLeft then
	-- 	self.waitQuit = -1
	-- elseif self.waitQuit<0 then
	-- 	self:D('waitQuit add 60')
	-- 	self.waitQuit = self:getGameTime()+60
	-- elseif self.waitQuit<self:getGameTime() then
	-- 	self:gameOver()
	-- end
	-- check any player still in gameroom or not .. if no one here .. exit game, end
end

--- sync ping time
-- @param null
-- @return null
function WorldBase:syncPingTime()
	if self.gameRoomSetting['ISYW']==0 and self.lastSyncPingTime<self:getGameTime() then
		self.lastSyncPingTime = self:getGameTime() + 5
		local pt = {}
		for k,v in pairs(self.itemListFilter.heroList) do
			local ping = v.lastpingtime
			if ping>5 then ping = 5 end
			if v.actorType==0 and self.playerList[k]['online']~=nil and not self.playerList[k]['online'] then
				ping = 0
			end
			if v.actorType==0 and not v:isAIObj() then
				pt[#pt+1] = {i=v.itemID,t=ping}
			end
		end
		self:addSyncMsg({pt=pt})
	end
end

--- RUNNING gameOver 检查
-- @return null
function WorldBase:gameOverCheck()
	local result = false
	if self.status~=self.GAMEOVER and self.gameFlag['isGameOver'] then
		result = true
		if self.gameRoomSetting['ISGVB']==1 and self.gameRoomSetting['teamMode']==2 then
			self.gameFlag['winTeam'] = 'A'
		end
	end

	-- if self.gameRoomSetting['ISPVP']==1 and self.itemListFilter.heroList[1]~=nil and self.itemListFilter.heroList[1].loginID=='sn01' and self:getGameTime()>70 then
	-- 	result = true
	-- end

	if not result and self.gameRoomSetting['ISGVB']==1 then
		local maxOffLineTime = 0
		local maxIdleTime = 0
		local allOffLine = true
		local allIdle = true
		local isSetAuto = false
		for k,v in pairs(self.itemListFilter.heroList) do
			if v.actorType==0 then
				if self.playerList[k]['offLineTime']~=nil and self.playerList[k]['offLineTime']>0 then
					if self.playerList[k]['offLineTime']>maxOffLineTime then
						maxOffLineTime = self.playerList[k]['offLineTime']
					end
				end
				if self.playerList[k]['offLineTime']==nil or self.playerList[k]['offLineTime']==0 then
					allOffLine = false
				end
				if v.heroIdleTime~=0 and v.heroIdleTime>maxIdleTime and v.AImode==0 then
					maxIdleTime = v.heroIdleTime
				end
				if v.heroIdleTime==0 then
					allIdle = false
				end
				if not v:isAIObj() and v.AImode==1 then
					isSetAuto = true
				end
			end
		end
		-- gameOver when all player off line
		if allOffLine and maxOffLineTime>0 and self.setting['comsetTime']~=nil and (self.gameTime-maxOffLineTime)>self.tonumber(self.setting['comsetTime']) then
			result = true
			self:I('jaylog gameOverCheck allOffLine')
		end
		-- gameOver when all player Idle
		if not result and not isSetAuto and allIdle and maxIdleTime>0 and self.setting['hookoffTime']~=nil and (self.gameTime-maxIdleTime)>self.tonumber(self.setting['hookoffTime']) then
			result = true
			self:I('jaylog gameOverCheck allIdle')
		end

		-- gameOver when all player dead
		local deadNum = 0
		if not result and self.tNums(self.playerList)>0 then
			for k,v in pairs(self.itemListFilter.heroList) do
				if v.teamOrig=='A' and (v:isDead() or (self.gameRoomSetting['ISGVB']==1 and self.gameRoomInfo['worldSubMode']==1 and v:isAIObj())) then
					deadNum = deadNum + 1
				end
			end
			if deadNum==table.nums(self.playerList) then
				if not self.gameFlag['readyGameOver'] then
					self.gameFlag['readyGameOverTime'] = self.gameTime + 10.5
				end
				self.gameFlag['readyGameOver'] = true
			else
				self.gameFlag['readyGameOver'] = false
				self.gameFlag['readyGameOverTime'] = 0
			end
		end

		if self.gameFlag['readyGameOver'] then
			if self.gameFlag['readyGameOverTime']<=self.gameTime+10.3 then
				for k,v in pairs(self.itemListFilter.heroList) do
					if v.actorType==0 and v.statusList[82]==nil then
						v:addStatusList({s=82,r=self.gameTime,t=10,i=v.itemID,zz=3})
					end
				end
			end
		else
			for k,v in pairs(self.itemListFilter.heroList) do
				if v.actorType==0 and v.statusList[82]~=nil then
					v:removeStatusList(82)
				end
			end
		end

		if self.gameFlag['readyGameOver'] and self.gameFlag['readyGameOverTime']~=0 and self.gameFlag['readyGameOverTime']<self.gameTime then
			result = true
			if self.gameRoomSetting['ISGVB']==1 and self.gameRoomSetting['teamMode']==2 then
				self.gameFlag['winTeam'] = 'B'
			end
			self:I('jaylog gameOverCheck allDead ',self.gameFlag['readyGameOver'],self.gameFlag['readyGameOverTime'])
		end
	end

	return result
end

---用于gen地图自动生成的物品
-- @param null
-- @return null
function WorldBase:genItem()
	if self.gameRoomSetting['ISYW']==1 or self.gameRoomSetting['autoAddCreature'] then
		if self.genItemTime<self.gameTime then
			--野怪复活
			for k,grouplist in pairs(self.getMonsterIDInGroup) do
				local isdead = 1
				for j,v in pairs(grouplist) do
					local obj = self.allItemList[v['itemID']] 
					if obj==nil or obj~=nil and obj:isDead() then
						isdead = isdead*1
					else
						isdead = isdead*0
					end
				end
				if isdead==1 then
					--self:D("需要重新生成:"..k)
					self.getMonsterIDInGroup[k]=nil
					self.reviveMonsterlist[#self.reviveMonsterlist+1]={group=k,time=self.gameTime+self.genMonsterInGroup[k][1]['reviveTime']}
					--self:reviveYWAllEnemy(k)
				end
			end
			
			for r,v in pairs(self.reviveMonsterlist) do
				if v['time']<self.gameTime then
					--self:D("时间到 执行复活...")
					self:reviveYWAllEnemy(v['group'])
					table.remove(self.reviveMonsterlist,r)
				end
			end

			--boss复活
			for k,grouplist in pairs(self.getBossIDInGroup) do
				local isdead = 1
				for j,v in pairs(grouplist) do
					local obj = self.allItemList[v['itemID']] 
					if obj==nil or obj~=nil and obj:isDead() then
						isdead = isdead*1
					else
						isdead = isdead*0
					end
				end
				if isdead==1 then
					--self:D("需要重新生成:"..k)
					self.getBossIDInGroup[k]=nil
					self.reviveBosslist[#self.reviveBosslist+1]={group=k,time=self.gameTime+self.genBossInGroup[k][1]['reviveTime']}
					--self:reviveYWAllEnemy(k)
				end
			end
			
			for r,v in pairs(self.reviveBosslist) do
				if v['time']<self.gameTime then
					--self:D("时间到 执行复活BOSS...")
					self:reviveYWAllBoss(v['group'])
					table.remove(self.reviveBosslist,r)
				end
			end

			--散落怪生成
			for k,grouplist in pairs(self.genEnemyAloneIDInGroup) do
				local isdead = 1
				for j,v in pairs(grouplist) do
					local obj = self.allItemList[v['itemID']] 
					if obj==nil or obj~=nil and obj:isDead() then
						isdead = isdead*1
						table.remove(grouplist,j)
						--self:D("需要EnemyAlone重新生成:"..k)
						self.revivEnemyAlonelist[#self.revivEnemyAlonelist+1]={group=k,time=self.gameTime+self.genEnemyAloneInGroup[k][1]['reviveTime']}
					else
						isdead = isdead*0
					end							
					--剔除死亡的	
				end
			end

			for r,v in pairs(self.revivEnemyAlonelist) do
				if v['time']<self.gameTime then
					--self:D("时间到 执行复活...")
					self:reviveYWAllEnemyAlone(v['group'])
					table.remove(self.revivEnemyAlonelist,r)
				end
			end
			self.genItemTime = self.gameTime+1
		end
		if self.genTmpHeroTime+10<self.gameTime then
			self:reviveTmpHero()
			self.genTmpHeroTime = self.gameTime
		end
	end
end

--- 生成怪物
-- @param id int - 怪物ID
-- @param x int - 怪物出生点x坐标
-- @param y int - 怪物出生点y坐标
-- @param group string - 怪物的组别，每个点的怪物可分成一组
-- @param level int - 怪物出生的级别
-- @param team string - 战场中的分队
-- @param adjtime int - 调整时间
-- @return itemID int - 怪物ID
function WorldBase:addMonster(id,x,y,group,level,team,adjtime)
	self:D('jaylog WorldBase:addMonster',id,x,y,group,level,team,adjtime)
	self:checkCacheModule("gameroom.enemy.SMonster")
	local monster = require("gameroom.enemy.SMonster").new(self,id,team,x,y,level)
	if group~=nil then
		monster.monsterGroup = group
		local key = table.inTable(self.genMonsterGroupOrder, group)
		if key==nil then
			self.genMonsterGroupOrder[#self.genMonsterGroupOrder+1] = group
			key = #self.genMonsterGroupOrder
		end
		monster.attribute.nextexp = key
	end
	self:addItem(monster,adjtime)
	monster:createInit()
	monster.outOfCtlAllTime = self.gameTime+1
	return monster.itemID
end

--- 生成物品
-- @param id int - 怪物ID
-- @param team string - 战场中的分队
-- @param x int - 怪物出生点x坐标
-- @param y int - 怪物出生点y坐标
-- @param parentObj obj - 父类对象
-- @param level int - 怪物出生的级别
-- @param adjtime int - 调整时间
-- @param oID int - 假装成的roleID
-- @param actorType int - 假装成的actorType
-- @return itemID int - 游戏角色的顺序号
function WorldBase:addCreature(id,team,x,y,parentObj,level,adjtime,oID,actorType)
	self:D('jaylog WorldBase:addCreature ',id,team,x,y,level,adjtime,oID,actorType)
	if adjtime==nil then
		adjtime = 0
	end
	local creature
	local ok = false
	for k,v in pairs(self.gameRoomSetting['extraEnemy']) do
		if self.tonumber(id)==v then
			ok = true
		end
	end
	if ok then
		self:checkCacheModule("gameroom.enemy.SCreature"..id)
		-- self:D('jaylog WorldBase:addCreature add ',"SCreature"..id,'team',team,'x',x,'y',y,'level',level)
		creature = require("gameroom.enemy.SCreature"..id).new(self,id,team,x,y,level)
	else
		self:checkCacheModule("gameroom.enemy.SCreature")
		creature = require("gameroom.enemy.SCreature").new(self,id,team,x,y,level)
	end
	if oID~=nil and oID>0 then
		creature.attribute.roleIdChange = oID
	end
	if actorType~=nil and actorType>=0 then
		creature.attribute.actorTypeChange = actorType
	end
	creature:setParent(parentObj)
	self:D('jaylog WorldBase:addCreature itemID:',creature.itemID)
	self:addItem(creature,adjtime)
	creature.createTime = self.gameTime + adjtime
	creature:createInit()
	creature:setOutOfCtlAllTime(self.gameTime+1)
	return creature.itemID
end

--- 生成npc
-- @param id int - 怪物ID
-- @param team string - 战场中的分队
-- @param x int - 怪物出生点x坐标
-- @param y int - 怪物出生点y坐标
-- @param parentObj obj - 父类对象
-- @param level int - 怪物出生的级别
-- @param adjtime int - 调整时间
-- @param oID int - 假装成的roleID
-- @param actorType int - 假装成的actorType
-- @return itemID int - 游戏中的角色顺序号
function WorldBase:addNPC(id,team,x,y,parentObj,level,adjtime,oID,actorType)
	-- local NPC = require("gameroom.SNPC").new(self,id,team,x,y,level)
	local ok = false
	for k,v in pairs(self.gameRoomSetting['extraNPC']) do
		if self.tonumber(id)==v then
			ok = true
		end
	end
	if ok then
		self:checkCacheModule("gameroom.enemy.SNPC"..id)
		-- self:D('jaylog WorldBase:addCreature add ',"SCreature"..id,'team',team,'x',x,'y',y,'level',level)
		NPC = require("gameroom.enemy.SNPC"..id).new(self,id,team,x,y,level)
	else
		self:checkCacheModule("gameroom.SNPC")
		NPC = require("gameroom.SNPC").new(self,id,team,x,y,level)
	end
	-- if oID~=nil then
	-- 	self:D('jaylog now addCreature oID:'..oID..' oIDtype:'..type(oID))
	-- end
	-- if actorType~=nil then
	-- 	self:D('jaylog now addCreature actorType:'..actorType..' actorTypeType:'..type(actorType))
	-- end
	self:D('jaylog WorldBase:addNPC',id,team,x,y,parentObj,level,adjtime,oID,actorType)
	if oID~=nil and oID>0 then
		NPC.attribute.roleIdChange = oID
	end
	if actorType~=nil and actorType>=0 then
		NPC.attribute.actorTypeChange = actorType
	end
	self:addItem(NPC,adjtime)
	NPC:createInit()
	NPC.outOfCtlAllTime = self.gameTime+1
	return NPC.itemID
end

--- load enemy data when ready
-- @param roleID
-- @return null
function WorldBase:__loadEnemy(roleID)
	--self:D('start loadEnemy')
	if self.attrData[""..roleID]==nil then
		local keyMap = {type='eType',fire_resistance='FIRER',ice_resistance='ICER',lightning_resistance='LIGHTR',poison_resistance='POISONR',attRange='ATTRNGR',visRange='VISRNGR'}
		--local sql = "select roleID,name,parameter,lv level,HP,HP MaxHP,ATK,MDEF,DEF,HIT,DODGE,CRI,ASPD,MSPD,fire_resistance FIRER,ice_resistance ICER,lightning_resistance LIGHTR,poison_resistance POISONR,visRange VISRNG,width,patrolCD PATROLCD,patrolRange PATROLRANGE,typeAtk TYPEATK,chaseRange CHASERANGE from enemy where roleID='"..roleID.."'"
		local sql = "select roleID,refRoleSkill,name,parameter,lv,HP,ATK,MDEF,DEF,HIT,DODGE,CRI,ASPD,MSPD,fire_resistance,ice_resistance,lightning_resistance,poison_resistance,visRange,width,patrolCD,patrolRange,typeAtk,chaseRange from enemy where roleID='"..roleID.."'"
		local data = self:getDBData(sql)
		self:D('jaylog WorldBase:__loadEnemy ',self.cjson.encode(data))
		local enemyTmp = {}
		local paramTmp,paramTmp2,param
		--self:D('end dataAll : '..self.cjson.encode(data))
		for k,v in pairs(data) do
			v['MaxHP'] = v['HP']
			v['level'] = v['lv']
			v['FIRER'] = v['fire_resistance']
			v['ICER'] = v['ice_resistance']
			v['LIGHTR'] = v['lightning_resistance']
			v['POISONR'] = v['poison_resistance']
			v['VISRNG'] = v['visRange']
			v['PATROLCD'] = v['patrolCD']
			v['PATROLRANGE'] = v['patrolRange']
			v['TYPEATK'] = v['typeAtk']
			v['CHASERANGE'] = v['chaseRange']
			v['lv'] = nil
			v['fire_resistance'] = nil
			v['ice_resistance'] = nil
			v['lightning_resistance'] = nil
			v['poison_resistance'] = nil
			v['visRange'] = nil
			v['patrolCD'] = nil
			v['patrolRange'] = nil
			v['typeAtk'] = nil
			v['chaseRange'] = nil
			param = {}
			for k1,v1 in pairs(v) do
				if(isset(keyMap[k1])) then
					--self:D('keyMap')
					enemyTmp[keyMap[k1]] = v1
				elseif(k1=='parameter') then
					paramTmp = string.split(v1,';')
					for k2,v2 in pairs(paramTmp) do
						paramTmp2 = string.split(v2,'=')
						param[paramTmp2[1]] = self.tonumber(paramTmp2[2])
					end
					--self:D('start calculate parameter '..v1..' parm:'..self.cjson.encode(param))
					if param~=nil then
						enemyTmp['parameterArr'] = table.deepcopy(param)
					else
						enemyTmp['parameterArr'] = {}
					end
				else
					--self:D('not keyMap')
					enemyTmp[k1] = v1
				end
			end
			--enemyTmp['HP'] = 30000 --1000
			--enemyTmp['ATK'] = 500
			enemyTmp['MaxHP'] = enemyTmp['HP']
			enemyTmp['MaxMP'] = enemyTmp['MP']
			--self.enemyAll[""..v['roleID']] = table.deepcopy(enemyTmp)
			--self:D('enemyAll : '..self.cjson.encode(self.enemyAll[""..v['enemyID']]))
			self.attrData[""..v['roleID']] = table.deepcopy(enemyTmp)
		end
	end
	-- self:D('end enemyAll : '..self.cjson.encode(self.attrData[""..roleID]))
end

--- load enemy skill when ready
-- @param roleID
-- @return null
function WorldBase:__loadEnemySkill(roleID)
	--self:D('start load Enemy Skill')
	if self.attrSkill[""..roleID]==nil then
		local lastRoleID = 0
		if self.attrData[""..roleID]~=nil and self.attrData[""..roleID]['refRoleSkill']~=0 then
			--取相关roleID的技能数据
			lastRoleID = roleID
			roleID = self.attrData[""..roleID]['refRoleSkill']
		end
		local keyMap = {}
		local sql = "select * from enemy_skill where roleID='"..roleID.."'"
		local data = self:getDBData(sql)
		--self:D('enemySkillAll data : '..self.cjson.encode(data))
		local paramTmp,paramTmp2,paramTmp3,param
		for k,v in pairs(data) do
			if lastRoleID~=0 then
				v['roleID'] = lastRoleID
			end
			--self:D('every row data : '..k..'   '..self.cjson.encode(v))
			local enemySkillTmp = {}
			local param = {}
			for k1,v1 in pairs(v) do
				if (isset(keyMap[k1])) then
					enemySkillTmp[keyMap[k1]] = v1
				elseif (k1=='parameter' or k1=='parameter1' or k1=='parameter2' or k1=='parameter3' or k1=='parameter4') then
					paramTmp = string.split(v1,';')
					for k2,v2 in pairs(paramTmp) do
						if v2~="" and v2~='0' then
							paramTmp2 = string.split(v2,'=')
							paramTmp3 = string.split(paramTmp2[1],'_')
							if paramTmp3[1]=='TABLE' then
								param[paramTmp2[1]] = string.splitNumber(paramTmp2[2],',')
							else
								if (isset(param[paramTmp2[1]])) then
									param[paramTmp2[1]] = param[paramTmp2[1]] + self.tonumber(paramTmp2[2])
								else
									param[paramTmp2[1]] = self.tonumber(paramTmp2[2])
								end
							end
						end
					end
					enemySkillTmp['PARAM'] = param
				else
					enemySkillTmp[k1] = v1
				end
				--self:D('enemySkillTmp : '..self.cjson.encode(enemySkillTmp))
			end
			if self.gameRoomSetting['ISGVB']==1 then
				if self.AIPlanData[""..roleID]~=nil and self.AIPlanData[""..roleID][""..v['rank']]~=nil then
					for k1,v1 in pairs(self.AIPlanData[""..roleID][""..v['rank']]) do
						enemySkillTmp['PARAM'][k1] = v1
					end
				end
			end
			local paramTmp,paramTmp2,paramTmp3,paramTmp4,paramTmp5 = {},{},{},{},{}
			if v['parameter_s']~=nil and v['parameter_s']~='' then
				paramTmp = self.sSplit(v['parameter_s'],';')
				for k2,v2 in pairs(paramTmp) do
					paramTmp2,paramTmp3,paramTmp4,paramTmp5 = {},{},{},{}
					if v2~='' and v2~='0' then
						paramTmp2 = self.sSplit(v2,'=')
						if self.sFind(paramTmp2[2],':')~=nil then
							paramTmp4 = self.sSplit(paramTmp2[2],',')
							for k3,v3 in pairs(paramTmp4) do
								paramTmp5 = self.sSplit(v3,':')
								paramTmp3[paramTmp5[1]] = self.tonumber(paramTmp5[2])
							end
						else
							if self.sFind(paramTmp2[2],',')~=nil then
								paramTmp3 = self.sSplitNumber(paramTmp2[2],',')
							else
								if self.sMatch(paramTmp2[2],'[a-zA-Z]')~=nil then
									paramTmp3 = paramTmp2[2]
								else
									paramTmp3 = self.tonumber(paramTmp2[2])
								end
							end
						end
						if self.gType(paramTmp3)=='table' then
							enemySkillTmp['PARAM'][paramTmp2[1]] = self.tDeepcopy(paramTmp3)
						else
							enemySkillTmp['PARAM'][paramTmp2[1]] = paramTmp3
						end
					end
				end
			end
			--if (self.enemySkillAll[""..v['roleID']]==nil) then
			--	self.enemySkillAll[""..v['roleID']] = {}
			--end
			--self.enemySkillAll[""..v['roleID']][v['rank']] = self.tDeepcopy(enemySkillTmp)
			--self:D('jaylog enemySkillAll : ',self.cjson.encode(enemySkillTmp))
			if (self.attrSkill[""..v['roleID']]==nil) then
				self.attrSkill[""..v['roleID']] = {}
			end
			self.attrSkill[""..v['roleID']][v['rank']] = self.tDeepcopy(enemySkillTmp)
		end
	end
	--self:D('enemySkillAll : '..self.cjson.encode(self.enemySkillAll))
end

--- 随机AI plan
-- @return null
function WorldBase:randAIPlan()
	if self.gameRoomSetting['ISGVB']==1 then
		local sql = "select * from AI_plan where world='"..self.sSub(self.className,6).."'"
		local data = self:getDBData(sql)
		local planID = {}
		local planData = {}
		local param,paramTmp,paramTmp2
		for k,v in pairs(data) do
			planID[#planID+1] = v['AIGroup']
			if planData[""..v['AIGroup']]==nil then
				planData[""..v['AIGroup']] = {}
			end
			if planData[""..v['AIGroup']][""..v['roleID']]==nil then
				planData[""..v['AIGroup']][""..v['roleID']] = {}
			end
			if planData[""..v['AIGroup']][""..v['roleID']][""..v['skillID']]==nil then
				planData[""..v['AIGroup']][""..v['roleID']][""..v['skillID']] = {}
			end
			--param = {}
			paramTmp = self.sSplit(v['parameter'],';')
			for k1,v1 in pairs(paramTmp) do
				paramTmp2 = self.sSplit(v1,'=')
				--param[paramTmp2[1]] = self.tonumber(paramTmp2[2])
				planData[""..v['AIGroup']][""..v['roleID']][""..v['skillID']][paramTmp2[1]] = self.tonumber(paramTmp2[2])
			end
			-- self:D('jaylog plan:',self.cjson.encode(planData))
		end
		if not empty(planID) then
			local num = self.formula:getRandnum(1,self.tNums(planID))
			self.AIPlanData = self.tDeepcopy(planData[""..planID[num]])
			-- self:D('jaylog WorldBase:randAIPlan num:',num,' AIGroup',planID[num],' planData:',self.cjson.encode(self.AIPlanData),' planID',self.cjson.encode(planID),' wn:',self.sSub(self.className,6))
			self.gameRoomSetting['genAIGroup'] = planID[num]
			if self.setting['AI_plan']~=nil then
				self.gameRoomSetting['genAIGroup'] = self.tonumber(self.setting['AI_plan'])
			end
			-- self:D('jaylog WorldBase:randAIPlan genAIGroup:'..self.gameRoomSetting['genAIGroup'])
		end
	end
end

--- load enemy data when ready
-- @param roleID
-- @return null
function WorldBase:__loadBoss(roleID)
	--self:D('jaylog start loadBoss')
	if self.attrData[""..roleID]==nil then
		local keyMap = {type='eType',fire_resistance='FIRER',ice_resistance='ICER',lightning_resistance='LIGHTR',poison_resistance='POISONR',attRange='ATTRNGR',visRange='VISRNGR'}
		-- local sql = "select roleID,name,parameter,lv level,HP,HP MaxHP,ATK,MDEF,DEF,HIT,DODGE,CRI,ASPD,MSPD,fire_resistance FIRER,ice_resistance ICER,lightning_resistance LIGHTR,poison_resistance POISONR,visRange VISRNG,width,patrolCD PATROLCD,patrolRange PATROLRANGE,typeAtk TYPEATK,chaseRange CHASERANGE from boss where roleID='"..roleID.."'"
		local sql = "select roleID,name,parameter,lv,HP,ATK,MDEF,DEF,HIT,DODGE,CRI,ASPD,MSPD,fire_resistance,ice_resistance,lightning_resistance,poison_resistance,visRange,width,patrolCD,patrolRange,typeAtk,chaseRange from boss where roleID='"..roleID.."'"
		local data = self:getDBData(sql)
		local bossTmp = {}
		local paramTmp,paramTmp2,param
		--self:D('end dataAll : '..self.cjson.encode(data))
		for k,v in pairs(data) do
			v['MaxHP'] = v['HP']
			v['level'] = v['lv']
			v['FIRER'] = v['fire_resistance']
			v['ICER'] = v['ice_resistance']
			v['LIGHTR'] = v['lightning_resistance']
			v['POISONR'] = v['poison_resistance']
			v['VISRNG'] = v['visRange']
			v['PATROLCD'] = v['patrolCD']
			v['PATROLRANGE'] = v['patrolRange']
			v['TYPEATK'] = v['typeAtk']
			v['CHASERANGE'] = v['chaseRange']
			v['lv'] = nil
			v['fire_resistance'] = nil
			v['ice_resistance'] = nil
			v['lightning_resistance'] = nil
			v['poison_resistance'] = nil
			v['visRange'] = nil
			v['patrolCD'] = nil
			v['patrolRange'] = nil
			v['typeAtk'] = nil
			v['chaseRange'] = nil
			param = {}
			for k1,v1 in pairs(v) do
				if(isset(keyMap[k1])) then
					--self:D('keyMap')
					bossTmp[keyMap[k1]] = v1
				elseif(k1=='parameter') then
					paramTmp = string.split(v1,';')
					for k2,v2 in pairs(paramTmp) do
						paramTmp2 = string.split(v2,'=')
						param[paramTmp2[1]] = paramTmp2[2]
					end
					--self:D('start calculate parameter '..v1..' parm:'..self.cjson.encode(param))
					if param~=nil then
						bossTmp['parameterArr'] = table.deepcopy(param)
					else
						bossTmp['parameterArr'] = {}
					end
				else
					--self:D('not keyMap')
					bossTmp[k1] = v1
				end
			end
			--bossTmp['HP'] = 30000 --1000
			--enemyTmp['ATK'] = 500
			bossTmp['MaxHP'] = bossTmp['HP']
			bossTmp['MaxMP'] = bossTmp['MP']
			--bossTmp['HP'] = 3500
			--bossTmp['ATK'] = 500
			--self.bossAll[""..v['roleID']] = table.deepcopy(bossTmp)
			--self:D('enemyAll : '..self.cjson.encode(self.enemyAll[""..v['enemyID']]))
			self.attrData[""..v['roleID']] = table.deepcopy(bossTmp)
		end
	end
	-- self:D('jaylog end bossAll : '..self.cjson.encode(self.attrData[""..roleID]))
end

--- load enemy skill when ready
-- @param roleID
-- @return null
function WorldBase:__loadBossSkill(roleID)
	--self:D('jaylog start load Boss Skill')
	if self.attrSkill[""..roleID]==nil then
		local keyMap = {}
		local sql = "select * from boss_skill where roleID='"..roleID.."'"
		local data = self:getDBData(sql)
		--self:D('enemySkillAll data : '..self.cjson.encode(data))
		local paramTmp,paramTmp2,paramTmp3,param
		for k,v in pairs(data) do
			--self:D('every row data : '..k..'   '..self.cjson.encode(v))
			local bossSkillTmp = {}
			local param = {}
			local paramTmp,paramTmp2,paramTmp3
			for k1,v1 in pairs(v) do
				if (isset(keyMap[k1])) then
					bossSkillTmp[keyMap[k1]] = v1
				elseif (k1=='parameter' or k1=='parameter1' or k1=='parameter2' or k1=='parameter3' or k1=='parameter4') then
					paramTmp = string.split(v1,';')
					--self:D('jaylog bossskill param:'..self.cjson.encode(paramTmp))
					for k2,v2 in pairs(paramTmp) do
						if v2~="" and v2~='0' then
							paramTmp2 = string.split(v2,'=')
							paramTmp3 = string.split(paramTmp2[1],'_')  --拆分参数名，如果以TABLE开头则拆分成顺序号的TABLE
							if paramTmp3[1]=='TABLE' then
								param[paramTmp2[1]] = string.splitNumber(paramTmp2[2],',')
							else
								if (isset(param[paramTmp2[1]])) then
									param[paramTmp2[1]] = param[paramTmp2[1]] + self.tonumber(paramTmp2[2])
								else
									param[paramTmp2[1]] = self.tonumber(paramTmp2[2])
								end
							end
						end
						--self:D('jaylog bossskill param end:'..self.cjson.encode(param))
					end
					bossSkillTmp['PARAM'] = param
				else
					bossSkillTmp[k1] = v1
				end
				--self:D('bossSkillTmp : '..self.cjson.encode(bossSkillTmp))
			end
			if self.gameRoomSetting['ISGVB']==1 then
				if self.AIPlanData[""..roleID]~=nil and self.AIPlanData[""..roleID][""..v['rank']]~=nil then
					for k1,v1 in pairs(self.AIPlanData[""..roleID][""..v['rank']]) do
						bossSkillTmp['PARAM'][k1] = v1
					end
				end
			end
			local paramTmp,paramTmp2,paramTmp3,paramTmp4,paramTmp5 = {},{},{},{},{}
			if v['parameter_s']~=nil and v['parameter_s']~='' then
				paramTmp = self.sSplit(v['parameter_s'],';')
				for k2,v2 in pairs(paramTmp) do
					paramTmp2,paramTmp3,paramTmp4,paramTmp5 = {},{},{},{}
					if v2~='' and v2~='0' then
						paramTmp2 = self.sSplit(v2,'=')
						if self.sFind(paramTmp2[2],':')~=nil then
							paramTmp4 = self.sSplit(paramTmp2[2],',')
							for k3,v3 in pairs(paramTmp4) do
								paramTmp5 = self.sSplit(v3,':')
								paramTmp3[paramTmp5[1]] = self.tonumber(paramTmp5[2])
							end
						else
							if self.sFind(paramTmp2[2],',')~=nil then
								paramTmp3 = self.sSplitNumber(paramTmp2[2],',')
							else
								if self.sMatch(paramTmp2[2],'[a-zA-Z]')~=nil then
									paramTmp3 = paramTmp2[2]
								else
									paramTmp3 = self.tonumber(paramTmp2[2])
								end
							end
						end
						if self.gType(paramTmp3)=='table' then
							bossSkillTmp['PARAM'][paramTmp2[1]] = self.tDeepcopy(paramTmp3)
						else
							bossSkillTmp['PARAM'][paramTmp2[1]] = paramTmp3
						end
					end
				end
			end
			-- if (self.bossSkillAll[""..v['roleID']]==nil) then
			-- 	self.bossSkillAll[""..v['roleID']] = {}
			-- end
			-- self.bossSkillAll[""..v['roleID']][v['rank']] = self.tDeepcopy(bossSkillTmp)
			--self:D('enemySkillAll : '..self.cjson.encode(self.enemySkillAll))
			if (self.attrSkill[""..v['roleID']]==nil) then
				self.attrSkill[""..v['roleID']] = {}
			end
			self.attrSkill[""..v['roleID']][v['rank']] = self.tDeepcopy(bossSkillTmp)
		end
	end
	-- self:D('jaylog bossSkillAll : '..self.cjson.encode(self.attrSkill[""..roleID]))
end

--- load enemy data when ready
-- @param roleID
-- @return null
function WorldBase:__loadNPC(roleID)
	--self:D('start loadEnemy')
	if self.attrData[""..roleID]==nil then
		local keyMap = {type='eType',fire_resistance='FIRER',ice_resistance='ICER',lightning_resistance='LIGHTR',poison_resistance='POISONR',attRange='ATTRNGR',visRange='VISRNGR'}
		-- local sql = "select roleID,name,parameter,lv level,HP,HP MaxHP,ATK,MDEF,DEF,HIT,DODGE,CRI,ASPD,MSPD,fire_resistance FIRER,ice_resistance ICER,lightning_resistance LIGHTR,poison_resistance POISONR,visRange VISRNG,width,patrolCD PATROLCD,patrolRange PATROLRANGE,typeAtk TYPEATK,chaseRange CHASERANGE from npc where roleID='"..roleID.."'"
		local sql = "select roleID,name,parameter,lv,HP,ATK,MDEF,DEF,HIT,DODGE,CRI,ASPD,MSPD,fire_resistance,ice_resistance,lightning_resistance,poison_resistance,visRange,width,patrolCD,patrolRange,typeAtk,chaseRange from npc where roleID='"..roleID.."'"
		local data = self:getDBData(sql)
		local npcTmp = {}
		local paramTmp,paramTmp2,param
		--self:D('end dataAll : '..self.cjson.encode(data))
		for k,v in pairs(data) do
			v['MaxHP'] = v['HP']
			v['level'] = v['lv']
			v['FIRER'] = v['fire_resistance']
			v['ICER'] = v['ice_resistance']
			v['LIGHTR'] = v['lightning_resistance']
			v['POISONR'] = v['poison_resistance']
			v['VISRNG'] = v['visRange']
			v['PATROLCD'] = v['patrolCD']
			v['PATROLRANGE'] = v['patrolRange']
			v['TYPEATK'] = v['typeAtk']
			v['CHASERANGE'] = v['chaseRange']
			v['lv'] = nil
			v['fire_resistance'] = nil
			v['ice_resistance'] = nil
			v['lightning_resistance'] = nil
			v['poison_resistance'] = nil
			v['visRange'] = nil
			v['patrolCD'] = nil
			v['patrolRange'] = nil
			v['typeAtk'] = nil
			v['chaseRange'] = nil
			param = {}
			for k1,v1 in pairs(v) do
				if(isset(keyMap[k1])) then
					--self:D('keyMap')
					npcTmp[keyMap[k1]] = v1
				elseif(k1=='parameter') then
					paramTmp = string.split(v1,';')
					for k2,v2 in pairs(paramTmp) do
						paramTmp2 = string.split(v2,'=')
						param[paramTmp2[1]] = paramTmp2[2]
					end
					--self:D('start calculate parameter '..v1..' parm:'..self.cjson.encode(param))
					if param~=nil then
						npcTmp['parameterArr'] = table.deepcopy(param)
					else
						npcTmp['parameterArr'] = {}
					end
				else
					--self:D('not keyMap')
					npcTmp[k1] = v1
				end
			end
			--enemyTmp['HP'] = 30000 --1000
			--enemyTmp['ATK'] = 500
			npcTmp['MaxHP'] = npcTmp['HP']
			npcTmp['MaxMP'] = npcTmp['MP']
			--self.npcAll[""..v['roleID']] = table.deepcopy(npcTmp)
			--self:D('jaylog npcAll : '..self.cjson.encode(self.npcAll[""..v['roleID']]))
			self.attrData[""..v['roleID']] = table.deepcopy(npcTmp)
		end
	end
	--self:D('end npcAll : '..self.cjson.encode(self.npcAll))
	--self:D('end attrAll : '..self.cjson.encode(self.attrData))
end

--- load boss房的流程数据
-- @param null
-- @return null
function WorldBase:__loadFlow()
	-- self:DC('jaylog __loadFlow start ',self.callBack:getServerTime())
	-- self:D('jaylog start WorldBase:__loadFlow')
	--local keyMap = {type='eType',fire_resistance='FIRER',ice_resistance='ICER',lightning_resistance='LIGHTR',poison_resistance='POISONR',attRange='ATTRNGR',visRange='VISRNGR'}
	local sql = "select * from flow_condition where world='"..self.sSub(self.className,6).."' order by part,step"
	local data = self:getDBData(sql)
	-- self:DC('jaylog __loadFlow after getDBData flow_condition ',self.callBack:getServerTime())
	-- self:D('jaylog World3:__loadFlow data:',self.cjson.encode(data))
	local flowTmp = {}
	local paramTmp,paramTmp2,paramTmp3,paramTmp4,param
	--self:D('end dataAll : '..self.cjson.encode(data))
	for k,v in pairs(data) do
		flowTmp = {}
		flowTmp = self:__loadFlowGetFlowTmp(v)
		self:__genInitHeroInfo(flowTmp)
		-- for k1,v1 in pairs(v) do
		-- 	param = {}
		-- 	if k1=='extraCondition' then
		-- 		if v1~='' then
		-- 			paramTmp = self.sSplit(v1,';')
		-- 			for k2,v2 in pairs(paramTmp) do
		-- 				paramTmp2 = self.sSplit(v2,'=')
		-- 				if self.sFind(paramTmp2[2],'_')~=nil then
		-- 					paramTmp3 = self.sSplit(paramTmp2[2],'_')
		-- 					for k3,v3 in pairs(paramTmp3) do
		-- 						if param[paramTmp2[1]]==nil then
		-- 							param[paramTmp2[1]] = {}
		-- 						end
		-- 						param[paramTmp2[1]][#param[paramTmp2[1]]+1] = self.sSplitNumber(v3,',')
		-- 					end
		-- 				else
		-- 					if self.sFind(paramTmp2[1],'SUBNAME')~=nil or self.sFind(paramTmp2[1],'BUFFNAME')~=nil or self.sFind(paramTmp2[1],'TEAM')~=nil or self.sFind(paramTmp2[1],'GUIDESTEP')~=nil then
		-- 						param[paramTmp2[1]] = self.sSplit(paramTmp2[2],',')
		-- 					else
		-- 						param[paramTmp2[1]] = self.sSplitNumber(paramTmp2[2],',')
		-- 					end
		-- 				end
		-- 			end
		-- 			flowTmp['extraCondition'] = self.tDeepcopy(param)
		-- 		else
		-- 			flowTmp['extraCondition'] = {}
		-- 		end
		-- 	elseif (k1=='extraParam') then
		-- 		if self.sFind(v1,'SUMMON')~=nil then
		-- 			paramTmp = self.sSplit(v1,';')
		-- 			for k2,v2 in pairs(paramTmp) do
		-- 				paramTmp2 = self.sSplit(v2,'=')
		-- 				if self.sFind(paramTmp2[2],':')~=nil then
		-- 					paramTmp3 = self.sSplit(paramTmp2[2],',')
		-- 					for k3,v3 in pairs(paramTmp3) do
		-- 						paramTmp4 = self.sSplit(v3,':')
		-- 						if param[paramTmp2[1]]==nil then
		-- 							param[paramTmp2[1]] = {}
		-- 						end
		-- 						param[paramTmp2[1]][paramTmp4[1]] = self.tonumber(paramTmp4[2])
		-- 					end
		-- 				elseif self.sFind(paramTmp2[1],'SUBNAME')~=nil or self.sFind(paramTmp2[1],'BUFFNAME')~=nil or self.sFind(paramTmp2[1],'TEAM')~=nil then
		-- 					param[paramTmp2[1]] = self.sSplit(paramTmp2[2],',')
		-- 				else
		-- 					param[paramTmp2[1]] = self.sSplitNumber(paramTmp2[2],',')
		-- 				end
		-- 			end
		-- 			flowTmp['extraParam'] = self.tDeepcopy(param)
		-- 			--self:D('jaylog __loadFlow:',self.cjson.encode(flowTmp['extraParam']))
		-- 		elseif v1~='' then
		-- 			paramTmp = self.sSplit(v1,';')
		-- 			for k2,v2 in pairs(paramTmp) do
		-- 				paramTmp2 = self.sSplit(v2,'=')
		-- 				if self.sFind(paramTmp2[2],'_')~=nil then
		-- 					paramTmp3 = self.sSplit(paramTmp2[2],'_')
		-- 					for k3,v3 in pairs(paramTmp3) do
		-- 						if param[paramTmp2[1]]==nil then
		-- 							param[paramTmp2[1]] = {}
		-- 						end
		-- 						param[paramTmp2[1]][#param[paramTmp2[1]]+1] = self.sSplitNumber(v3,',')
		-- 					end
		-- 				else
		-- 					if self.sFind(paramTmp2[1],'SUBNAME')~=nil or self.sFind(paramTmp2[1],'BUFFNAME')~=nil or self.sFind(paramTmp2[1],'TEAM')~=nil then
		-- 						param[paramTmp2[1]] = self.sSplit(paramTmp2[2],',')
		-- 					else
		-- 						param[paramTmp2[1]] = self.sSplitNumber(paramTmp2[2],',')
		-- 					end
		-- 				end
		-- 			end
		-- 			flowTmp['extraParam'] = self.tDeepcopy(param)
		-- 		else
		-- 			flowTmp['extraParam'] = {}
		-- 		end
		-- 	elseif k1=='parameter' then
		-- 		if v1~='' then
		-- 			flowTmp['parameter'] = self.sSplit(v1,',')
		-- 		else
		-- 			flowTmp['parameter'] = {}
		-- 		end
		-- 	elseif k1=='condition' then
		-- 		if v1~='' then
		-- 			flowTmp['condition'] = self.sSplit(v1,',')
		-- 		else
		-- 			flowTmp['condition'] = {}
		-- 		end
		-- 	else
		-- 		flowTmp[k1] = v1
		-- 	end
		-- end
		if self.bossFlow[v['part']]==nil then
			self.bossFlow[v['part']] = {}
		end
		self.bossFlow[v['part']][v['step']] = self.tDeepcopy(flowTmp)
	end
	-- self:DC('jaylog __loadFlow after setTable flow_condition ',self.callBack:getServerTime())
	local sql2 = "select * from flow_condition_YW where world='"..self.sSub(self.className,6).."' order by part,step"
	local data2 = self:getDBData(sql2)
	-- self:DC('jaylog __loadFlow after getDBData flow_condition_YW ',self.callBack:getServerTime())
	for k,v in pairs(data2) do
		flowTmp = {}
		flowTmp = self:__loadFlowGetFlowTmp(v)
		self:__genInitHeroInfo(flowTmp)
		if self.bossFlow[v['part']]==nil then
			self.bossFlow[v['part']] = {}
		end
		self.bossFlow[v['part']][v['step']] = self.tDeepcopy(flowTmp)
	end
	-- self:DC('jaylog __loadFlow after setTable flow_condition_YW ',self.callBack:getServerTime())
	local sql3 = "select * from flow_condition_DJ where world='"..self.sSub(self.className,6).."' order by part,step"
	local data3 = self:getDBData(sql3)
	-- self:DC('jaylog __loadFlow after getDBData flow_condition_DJ ',self.callBack:getServerTime())
	for k,v in pairs(data3) do
		flowTmp = {}
		flowTmp = self:__loadFlowGetFlowTmp(v)
		self:__genInitHeroInfo(flowTmp)
		if self.bossFlow[v['part']]==nil then
			self.bossFlow[v['part']] = {}
		end
		self.bossFlow[v['part']][v['step']] = self.tDeepcopy(flowTmp)
	end
	-- self:DC('jaylog __loadFlow after setTable flow_condition_DJ ',self.callBack:getServerTime())
	-- self:D('jaylog initHeroInfo:',self.cjson.encode(self.initHeroInfo))
	-- self:D('jaylog end bossFlowAll : '..self.cjson.encode(self.bossFlow))
end

--- 整合拆分流程的结构
-- @param v string - 需要拆解的数据字符串
-- @return flowTmp table - 拆解后的table
function WorldBase:__loadFlowGetFlowTmp(v)
	local flowTmp = {}
	local paramTmp,paramTmp2,paramTmp3,paramTmp4,param
	for k1,v1 in pairs(v) do
		param = {}
		if k1=='extraCondition' then
			if v1~='' then
				paramTmp = self.sSplit(v1,';')
				for k2,v2 in pairs(paramTmp) do
					paramTmp2 = self.sSplit(v2,'=')
					if self.sFind(paramTmp2[2],'_')~=nil then
						paramTmp3 = self.sSplit(paramTmp2[2],'_')
						for k3,v3 in pairs(paramTmp3) do
							if param[paramTmp2[1]]==nil then
								param[paramTmp2[1]] = {}
							end
							param[paramTmp2[1]][#param[paramTmp2[1]]+1] = self.sSplitNumber(v3,',')
						end
					else
						if self.sFind(paramTmp2[1],'SUBNAME')~=nil or self.sFind(paramTmp2[1],'CHANGENAME')~=nil or self.sFind(paramTmp2[1],'TARGETSUBNAME')~=nil or self.sFind(paramTmp2[1],'BUFFNAME')~=nil or self.sFind(paramTmp2[1],'TEAM')~=nil or self.sFind(paramTmp2[1],'GUIDESTEP')~=nil or self.sFind(paramTmp2[1],'MATCHKEY')~=nil then
							param[paramTmp2[1]] = self.sSplit(paramTmp2[2],',')
						else
							param[paramTmp2[1]] = self.sSplitNumber(paramTmp2[2],',')
						end
					end
				end
				flowTmp['extraCondition'] = self.tDeepcopy(param)
			else
				flowTmp['extraCondition'] = {}
			end
		elseif (k1=='extraParam') then
			if self.sFind(v1,'SUMMON')~=nil then
				paramTmp = self.sSplit(v1,';')
				for k2,v2 in pairs(paramTmp) do
					paramTmp2 = self.sSplit(v2,'=')
					if self.sFind(paramTmp2[2],':')~=nil then
						paramTmp3 = self.sSplit(paramTmp2[2],',')
						for k3,v3 in pairs(paramTmp3) do
							paramTmp4 = self.sSplit(v3,':')
							if param[paramTmp2[1]]==nil then
								param[paramTmp2[1]] = {}
							end
							param[paramTmp2[1]][paramTmp4[1]] = self.tonumber(paramTmp4[2])
						end
					elseif self.sFind(paramTmp2[1],'SUBNAME')~=nil or self.sFind(paramTmp2[1],'CHANGENAME')~=nil or self.sFind(paramTmp2[1],'BUFFNAME')~=nil or self.sFind(paramTmp2[1],'TEAM')~=nil or self.sFind(paramTmp2[1],'MATCHKEY')~=nil then
						param[paramTmp2[1]] = self.sSplit(paramTmp2[2],',')
					else
						param[paramTmp2[1]] = self.sSplitNumber(paramTmp2[2],',')
					end
				end
				flowTmp['extraParam'] = self.tDeepcopy(param)
				--self:D('jaylog __loadFlow:',self.cjson.encode(flowTmp['extraParam']))
			elseif v1~='' then
				paramTmp = self.sSplit(v1,';')
				for k2,v2 in pairs(paramTmp) do
					if v2~=nil and v2~='' then
						paramTmp2 = self.sSplit(v2,'=')
						if self.sFind(paramTmp2[2],'_')~=nil then
							paramTmp3 = self.sSplit(paramTmp2[2],'_')
							for k3,v3 in pairs(paramTmp3) do
								if param[paramTmp2[1]]==nil then
									param[paramTmp2[1]] = {}
								end
								param[paramTmp2[1]][#param[paramTmp2[1]]+1] = self.sSplitNumber(v3,',')
							end
						else
							if self.sFind(paramTmp2[1],'SUBNAME')~=nil or self.sFind(paramTmp2[1],'CHANGENAME')~=nil or self.sFind(paramTmp2[1],'BUFFNAME')~=nil or self.sFind(paramTmp2[1],'TEAM')~=nil or self.sFind(paramTmp2[1],'MATCHKEY')~=nil then
								param[paramTmp2[1]] = self.sSplit(paramTmp2[2],',')
							else
								param[paramTmp2[1]] = self.sSplitNumber(paramTmp2[2],',')
							end
						end
					end
				end
				flowTmp['extraParam'] = self.tDeepcopy(param)
			else
				flowTmp['extraParam'] = {}
			end
		elseif k1=='parameter' then
			if v1~='' then
				flowTmp['parameter'] = self.sSplit(v1,',')
			else
				flowTmp['parameter'] = {}
			end
		elseif k1=='condition' then
			if v1~='' then
				flowTmp['condition'] = self.sSplit(v1,',')
			else
				flowTmp['condition'] = {}
			end
		else
			flowTmp[k1] = v1
		end
	end
	return flowTmp
end

--- load boss房的流程mapping数据
-- @param null
-- @return null
function WorldBase:__loadFlowMapping(roleID)
	-- self:D('jaylog start WorldBase:__loadFlow')
	--local keyMap = {type='eType',fire_resistance='FIRER',ice_resistance='ICER',lightning_resistance='LIGHTR',poison_resistance='POISONR',attRange='ATTRNGR',visRange='VISRNGR'}
	local sql = "select * from flow_condition_mapping where world='"..self.sSub(self.className,6).."' and roleID='"..roleID.."' order by part,step"
	local data = self:getDBData(sql)
	self:D('jaylog WorldBase:__loadFlowMapping data:',self.cjson.encode(data))
	local flowTmp = {}
	local paramTmp,paramTmp2,paramTmp3,paramTmp4,param
	--self:D('end dataAll : '..self.cjson.encode(data))
	for k,v in pairs(data) do
		flowTmp = {}
		flowTmp = self:__loadFlowGetFlowTmp(v)
		self:__genInitHeroInfo(flowTmp)
		if self.bossFlow[v['part']]==nil then
			self.bossFlow[v['part']] = {}
		end
		self.bossFlow[v['part']][v['step']] = self.tDeepcopy(flowTmp)
	end
	-- self:D('jaylog __loadFlowMapping initHeroInfo:',self.cjson.encode(self.initHeroInfo))
	-- self:D('jaylog end bossFlowAll : ',self.cjson.encode(self.bossFlow))
end

--- load room_chat的数据
-- @param rcID int - room_chat的顺序ID
-- @return msg string - room_chat的对应内容
function WorldBase:loadRoomChat(rcID)
	local sql = "select * from room_chat where rcID='"..rcID.."'"
	local data = self:getDBData(sql)
	local msg = ''
	for k,v in pairs(data) do
		msg = v['msg']
	end
	return msg
end

--- 组织缓冲池INFO
-- @param flowTmp table - flow数据
-- @return null
function WorldBase:__genInitHeroInfo(flowTmp)
	if flowTmp~=nil and flowTmp['parameter']~=nil and flowTmp['parameter'][1]~=nil and self.sFind(flowTmp['parameter'][1],'NEW')~=nil then
		-- self:D('jaylog ',flowTmp['parameter'][1])
		if flowTmp['parameter'][1]~='NEWOTHER' then
			if flowTmp['extraParam']['ID']~=nil then
				-- self:D('jaylog ',flowTmp['extraParam']['ID'][1])
				if flowTmp['extraParam']['ID'][1]<99 then
					local playerInfo = self:getAIData(self.mapModel,flowTmp['extraParam']['ID'][1],flowTmp['extraParam']['LEVEL'][1],'A')
					local playerInfoJson = self.cjson.decode(playerInfo)
					local roleID = self.tonumber(playerInfoJson['Player']['roleId'])
					local wing,wingStage = 1,0
					if self.tonumber(playerInfoJson['Player']['WINGID'])~=0 and self.tonumber(playerInfoJson['Player']['WINGHIDE'])==0 then
						wing = self.tonumber(playerInfoJson['Player']['WINGID'])-29999
						wingStage = self.tonumber(playerInfoJson['Player']['WINGSTAGE'])
					end
					local lw,rw,lwStage,rwStage = 1,1,0,0
					if self.tonumber(playerInfoJson['Player']['WEAPONLID'])~=0 then
						lw = self.tonumber(playerInfoJson['Player']['WEAPONLID'])-90999
						lwStage = self.tonumber(playerInfoJson['Player']['WEAPONLSTAGE'])
					end
					if self.tonumber(playerInfoJson['Player']['WEAPONRID'])~=0 then
						rw = self.tonumber(playerInfoJson['Player']['WEAPONRID'])-90999
						rwStage = self.tonumber(playerInfoJson['Player']['WEAPONRSTAGE'])
					end
					self.initHeroInfo[#self.initHeroInfo+1] = {i=0,a=roleID,at=0,si=0,wing=wing,wingStage=wingStage,lw=lw,lwStage=lwStage,rw=rw,rwStage=rwStage}
				end
				if flowTmp['extraParam']['ID'][1]>1000 and flowTmp['extraParam']['ID'][1]<9999 then
					local skinno = 0
					if flowTmp['extraParam']['SKINNO']~=nil then
						skinno = flowTmp['extraParam']['SKINNO'][1]
					end
					self.initHeroInfo[#self.initHeroInfo+1] = {i=0,a=flowTmp['extraParam']['ID'][1],at=2,si=skinno}
				end
			end
		else
			for i=1,10 do
				local playerInfo = self:getAIData(self.mapModel,i,flowTmp['extraParam']['LEVEL'][1],'A')
				local playerInfoJson = self.cjson.decode(playerInfo)
				local roleID = self.tonumber(playerInfoJson['Player']['roleId'])
				local wing,wingStage = 1,0
				if self.tonumber(playerInfoJson['Player']['WINGID'])~=0 and self.tonumber(playerInfoJson['Player']['WINGHIDE'])==0 then
					wing = self.tonumber(playerInfoJson['Player']['WINGID'])-29999
					wingStage = self.tonumber(playerInfoJson['Player']['WINGSTAGE'])
				end
				local lw,rw,lwStage,rwStage = 1,1,0,0
				if self.tonumber(playerInfoJson['Player']['WEAPONLID'])~=0 then
					lw = self.tonumber(playerInfoJson['Player']['WEAPONLID'])-90999
					lwStage = self.tonumber(playerInfoJson['Player']['WEAPONLSTAGE'])
				end
				if self.tonumber(playerInfoJson['Player']['WEAPONRID'])~=0 then
					rw = self.tonumber(playerInfoJson['Player']['WEAPONRID'])-90999
					rwStage = self.tonumber(playerInfoJson['Player']['WEAPONRSTAGE'])
				end
				self.initHeroInfo[#self.initHeroInfo+1] = {i=0,a=roleID,at=0,si=0,wing=wing,wingStage=wingStage,lw=lw,lwStage=lwStage,rw=rw,rwStage=rwStage}
			end
		end
	end
end

--- 额外的流程检查
-- @param null
-- @return null
function WorldBase:runExtraCheck()
	return true
end

--- excuteParam时执行的额外处理
-- @param extraParam table - 条件参数
-- @return boolean
function WorldBase:runExtraParam(extraParam)
end

--- 执行条件检测与实际执行动作
function WorldBase:excuteFlow()
	while(self.hadExcuteFlow)
	do
		self.hadExcuteFlow = false
		local flowCond
		if self.bossFlow[self.partType]~=nil then
			flowCond = self.bossFlow[self.partType][self.partSubType]
		end
		local condition
		if flowCond~=nil then
			condition = flowCond['condition']
			extraCondition = flowCond['extraCondition']
		end
		-- self:D('jaylog World3:excuteFlow cond:',self.cjson.encode(flowCond))
		if condition~=nil then
			if self.partFinish then
				-- self:D('jaylog WorldBase:excuteFlow checkTime ',self.callBack:getServerTime())
				local ret = self.gameflow:checkCondition(condition,extraCondition)
				if ret then
					self:D('jaylog WorldBase:excuteFlow checkCondition ok ',self.partStartTime,' ',self.gameTime,' ',self.cjson.encode(self.partFinish),' ',self.cjson.encode(condition),' ',self.cjson.encode(extraCondition),' checkTime:',self.callBack:getServerTime())
					self.partStartTime = self.gameTime + flowCond['delay']
					self.partFinish = false
				end
			end
			if self.partStartTime<=self.gameTime and self.partMoveEndTime<=self.gameTime and (not self.partFinish) then
				local parameter = flowCond['parameter']
				local extraParam = flowCond['extraParam']
				self.bossFlow[self.partType][self.partSubType]['parameter'] = self.gameflow:excuteParam(parameter,extraParam)
				self:D('jaylog WorldBase:excuteFlow start excuteParam:',self.partStartTime,self.partMoveEndTime,self.gameTime,'---',self.cjson.encode(parameter),' ',self.cjson.encode(extraParam),' paramNum:',self.tNums(self.bossFlow[self.partType][self.partSubType]['parameter']),' part:',self.partType,' step:',self.partSubType,' nextPart:',flowCond['nextPart'],' nextStep:',flowCond['nextStep'],' checkTime:',self.callBack:getServerTime())
				if self.tNums(self.bossFlow[self.partType][self.partSubType]['parameter'])==0 then
					self.partType = flowCond['nextPart']
					self.partSubType = flowCond['nextStep']
					self.partFinish = true
					self.hadExcuteFlow = true
				end
			end
		end
	end
	self.hadExcuteFlow = true
end

--- init时部分游戏房设置赋setting值
-- @param null
-- @return null
function WorldBase:gengameRoomSetting()
	if self.setting['mode_Time']~=nil then
		self.gameRoomSetting['gameLimitedTime'] = self.setting['mode_Time']
	end
end

--- init时生成地图出生怪物设置
-- @param null
-- @return null
function WorldBase:genMonsterSetting()
	--self:D('jaylog genMonsterSetting ',self.gameRoomSetting['ISGVB'])
	local settingLocal = self.setting
	if self.gameRoomSetting['ISYW']==1 or self.gameRoomSetting['autoAddCreature'] then
		--self:D("getMonsterSetting........................")
		--增加野怪
		local dowhile = true
		local l = 0
		while (dowhile) do
			if settingLocal["enemy"..(l+1).."ID"]~=nil and settingLocal["enemy"..(l+1).."ID"]~='' then
				l = l + 1
			else
				dowhile = false
			end
		end

		if l>0 then
			--self:D("fenglog 野外地图 l："..l)
			for i=1,l do
				--self:D("fenglog 野外地图 enemylist:"..settingLocal["enemy"..i.."ID"])
				local list = string.split(settingLocal["enemy"..i.."ID"],';')
				local randlist = {}
				local enemyAllNum = 0
				for k,v in pairs(list) do
					local enemy1IDlist = string.split(v,',')
					local enemyType = enemy1IDlist[1]
					local enemyNum = enemy1IDlist[2]
					enemyAllNum = enemyAllNum + enemyNum
				end
				local enemy1Typelist = string.split(settingLocal["enemy"..i.."Type"],',')

				for k,v in pairs(list) do
					local enemy1IDlist = string.split(v,',')
					local enemyType = enemy1IDlist[1]
					local enemyNum = enemy1IDlist[2]
					for j=1,enemyNum do
						table.remove(randlist,1)
						self.genYWMonster[#self.genYWMonster+1] = {
							type = enemyType,
							time = 60,
							posX = enemy1Typelist[1],
							posY = enemy1Typelist[2],
							group = 'A'..i,
							team = '',
							groupID = i,
							reviveTime = self.tonumber(enemy1Typelist[4])
						}
						if self.genMonsterInGroup['A'..i]==nil then
							self.genMonsterInGroup['A'..i] = {}
						end
						self.genMonsterInGroup['A'..i][#self.genMonsterInGroup['A'..i]+1] =  self.genYWMonster[#self.genYWMonster]
					end
					self.genMonsterGroup['A'..i] = 60   --怪物死后刷新时间
					self.genMonsterGroupLevel['A'..i] = 1               --按组设置级别
				end
			end
		end

		--boss
		local dowhile = true
		local l = 0
		while (dowhile) do
			if settingLocal["boss"..(l+1).."ID"]~=nil and settingLocal["boss"..(l+1).."ID"]~='' then
				l = l + 1
			else
				dowhile = false
			end
		end

		if l>0 then
			--self:D("fenglog 野外地图 l："..l)
			for i=1,l do
				--self:D("fenglog 野外地图 enemylist:"..settingLocal["boss"..i.."ID"])
				local list = string.split(settingLocal["boss"..i.."ID"],';')
				local randlist = {}
				local enemyAllNum = 0
				for k,v in pairs(list) do
					local enemy1IDlist = string.split(v,',')
					local enemyType = enemy1IDlist[1]
					local enemyNum = enemy1IDlist[2]
					enemyAllNum = enemyAllNum + enemyNum
				end
				local enemy1Typelist = string.split(settingLocal["boss"..i.."Type"],',')

				for k,v in pairs(list) do
					local enemy1IDlist = string.split(v,',')
					local enemyType = enemy1IDlist[1]
					local enemyNum = enemy1IDlist[2]
					for j=1,enemyNum do
						table.remove(randlist,1)
						self.genYWBoss[#self.genYWBoss+1] = {
							type = enemyType,
							time = 60,
							posX = enemy1Typelist[1],
							posY = enemy1Typelist[2],
							--itemID = 0,
							--last = 0,
							group = 'B'..i,
							team = '',
							groupID = i,
							reviveTime = self.tonumber(enemy1Typelist[4])
						}
						if self.genBossInGroup['B'..i]==nil then
							self.genBossInGroup['B'..i] = {}
						end
						self.genBossInGroup['B'..i][#self.genBossInGroup['B'..i]+1] =  self.genYWBoss[#self.genYWBoss]
					end
				end
			end
		end

		--添加散落小怪
		local dowhile = true
		local l = 0
		while (dowhile) do
			if settingLocal["enemyAlone"..(l+1).."ID"]~=nil and settingLocal["enemyAlone"..(l+1).."ID"]~='' then
				l = l + 1
			else
				dowhile = false
			end
		end

		if l>0 then
			self:D("fenglog 野外地图 enemyAlone l："..l)
			for i=1,l do
				self:D("fenglog 野外地图 enemyAlone:"..settingLocal["enemyAlone"..i.."ID"])
				local enemy1Typelist = string.split(settingLocal["enemyAlone"..i.."ID"],',')
				local enemy1Type = enemy1Typelist[1]
				local enemyNum = enemy1Typelist[2]
				local enemy1Typelist = string.split(settingLocal["enemyAlone"..i.."Type"],',')
				
				for j=1,enemyNum do
					self.genYWEnemyAlone[#self.genYWEnemyAlone+1] = {
						type = enemy1Type,
						time = 5,
						posX = enemy1Typelist[1],
						posY = enemy1Typelist[2],
						group = 'enemyAlone'..i,
						groupID = i,
						team = '',
						--reviveTime = self.tonumber(enemy1Typelist[4])
						reviveTime = 2
					}
					if self.genEnemyAloneInGroup['enemyAlone'..i]==nil then
							self.genEnemyAloneInGroup['enemyAlone'..i] = {}
					end
					self.genEnemyAloneInGroup['enemyAlone'..i][#self.genEnemyAloneInGroup['enemyAlone'..i]+1] =  self.genYWEnemyAlone[#self.genYWEnemyAlone]

				end
			end
		end
	end
	--添加NPC npc1ID
	local dowhile = true
	local l = 0
	while (dowhile) do
		if settingLocal["npc"..(l+1).."ID"]~=nil and settingLocal["npc"..(l+1).."ID"]~='' then
			l = l + 1
		else
			dowhile = false
		end
	end

	if l>0 then
		--self:D("fenglog 野外地图 l："..l)
		for i=1,l do
			--self:D("fenglog 野外地图 npclist:"..settingLocal["npc"..i.."ID"])
			local NPCType = settingLocal["npc"..i.."ID"]
			local enemy1Typelist = string.split(settingLocal["npc"..i.."Type"],',')
			--20000永恒；30000涅槃；40000中立
			local npcTeam = ''
			if NPCType>=20000 and NPCType<30000 then
				npcTeam = 'A'
			end

			if NPCType>=30000 and NPCType<40000 then
				npcTeam = 'B'
			end

			if NPCType>=40000 and NPCType<50000 then
				npcTeam = ''
			end

			self.genYWNPC[#self.genYWNPC+1] = {
				type = NPCType,
				time = 60,
				posX = enemy1Typelist[1],
				posY = enemy1Typelist[2],
				standPoint = self.tonumber(enemy1Typelist[3]),
				--itemID = 0,
				--last = 0,
				group = 'N'..i,
				team = npcTeam,
			}
		end
	end
end

--- 加BOSS在地圖
-- @param id int - BOSS角色id
-- @param team char - "A" or "B" or ""
-- @param posX integer - 出生x坐标
-- @param posY integer - 出生y坐标
-- @param loginID string - BOSS名稱
-- @param skin integer - BOSS皮肤
-- @return heroObj SHero - BOSS object
function WorldBase:createBoss(id,team,posX,posY,loginID,skin,actorID)
	local numFlag = self.tonumber(self.sSub(self.tostring(id),2))
	local flagArr = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N'}
	local num = self.sSub(self.tostring(id),1,1)
	local flag = flagArr[self.tonumber(num)]
	--if self.mMod(id,1000)==1 then
		--numFlag = '1A'
	--else
		numFlag = numFlag..flag
	--end
	self:D('jaylog createBoss ',numFlag,id,team,posX,posY,loginID,skin,actorID)
	self:checkCacheModule("gameroom.boss.SBoss"..numFlag)
	local boss = require("gameroom.boss.SBoss"..numFlag).new(self,id,team,posX,posY,loginID,skin,actorID)
	return boss
end

--- 加Boss在地圖
-- @param id int - boss角色id
-- @param team char - "A" or "B"
-- @param loginID string - 玩家名稱
-- @param posX integer - 出生x坐标
-- @param posY integer - 出生y坐标
-- @return heroObj SHero - 英雄object
function WorldBase:addBoss(id,team,loginID,posX,posY,skin,actorID)
	--local boss = require("gameroom.boss.SBoss").new(self,id,team,120,80)
	local pos
	if team=="A" or self.gameRoomSetting['ISYW']==1 then
		pos = string.splitNumber(self.setting['heroAInitialPosition'], ',')
	else
		pos = string.splitNumber(self.setting['heroBInitialPosition'], ',')
	end
	if posX==nil or posY==nil or posX==0 or posY==0 then
		posX = pos[1]
		posY = pos[2]
	end

	if skin==nil then
		skin = 0
	end
	self:D('jaylog WorldBase addBoss:id',id,' t',team,' lid',loginID,' x',posX,' y',posY,' sk',skin)
	local boss = self:createBoss(id,team,posX,posY,loginID,skin,actorID)
	boss.debug = true
	self:addItem(boss)
	--self:setItemID(201)
	--self:addMonster(107,120,100,'B2',1,'B')
	boss:addIMMUNECONTROLBUFF()
	boss:createInit()
	boss.outOfCtlAllTime = self.gameTime+1
	return boss
end

-- function WorldBase:removePlayer(id)
	-- 	self.allItemList[id] = nil
	-- 	self.playerList[id] = nil
	-- 	self.itemListFilter.heroList[id] = nil
	-- 	self.itemListFilter.teamA[id] = nil
	-- 	self.itemListFilter.teamB[id] = nil
-- end

--- 在游戏loop中生成某些信息
-- @param null
-- @return null
function WorldBase:genSomeInfo()
end

--- 由groupid获取task_group对应的itemid
-- @param groupid char - 'GE1'
-- @return groupMapping table - {em_1,boss_1}
function WorldBase:getIDByGroup(groupid)
	if (table.nums(self.groupMapping)==0) then
		local sql = "select * from task_group"
		local data = self:getDBData(sql)
		for k,v in pairs(data) do
			local idList = string.split(v['subKey'],',')
			self.groupMapping[v['groupID']] = table.deepcopy(idList)
		end
	end
	return self.groupMapping[groupid]
end

-- function WorldBase:memcacheLocalSet (key,value)
-- 	--self:D('jaylog memcacheLocalSet:'..value)
-- 	local valueExt = self.cjson.decode(value)
-- 	valueExt['updateTime'] = self.serverTime
-- 	WorldBase.super.memcacheLocalSet(self,key,self.cjson.encode(valueExt))
-- end

--- 生成传送门
-- @param null
-- @return null
function WorldBase:genTransitDoor()
	self:D('jaylog WorldBase:genTransitDoor ',self.mapModel)
	if self.gameRoomSetting['ISYW']==1 then
		local mapDoor = self.transfer:getMapDoor(self.mapModel)
		if mapDoor~=nil then
			self:D('jaylog WorldBase:genTransitDoor ',self.cjson.encode(mapDoor))
			for k,v in pairs(mapDoor) do
				local npcID = self:addNPC(self.tostring(996),'',v['X'],v['Y'],nil,1,0.2)
				local obj1  = self.allItemList[npcID]
				-- 初始面向
				-- obj1.attribute.STANDPOINT = self.tonumber(v['standPoint'])
				-- obj1.syncMsg['i']['jd'] = self.tonumber(v['standPoint'])
				-- 安全门弧度
				-- obj1.attribute.level = self.tonumber(v['safeRadian'])
				-- obj1.syncMsg['i']['l'] = self.tonumber(v['safeRadian'])
				obj1.attribute.DEMON1 = v['safeWidth']
				obj1.attribute.DEMON2 = v['safeRadian']
				obj1.attribute.DEMON3 = v['safeRadian1']
				obj1.attribute.DEMON4 = v['safeNum']
				obj1.syncMsg['i']['dm1'] = obj1.attribute.DEMON1
				obj1.syncMsg['i']['dm2'] = obj1.attribute.DEMON2
				obj1.syncMsg['i']['dm3'] = obj1.attribute.DEMON3
				obj1.syncMsg['i']['dm4'] = obj1.attribute.DEMON4
				obj1.toMap = v['toMap']
				obj1.toRoomID = self.tonumber(self.gameRoomInfoAll[self.tonumber(v['toMap'])]['port'])
				obj1.toMapX = v['toX']
				obj1.toMapY = v['toY']
				local lifeTime=99999
				local attributes = {}
				attributes['buffParameter']={isTransitDoor=1}
				attributes['BUFFONLY']=1
				attributes['INEVITABLEHIT'] = 1
				attributes['buffParameter']['RANGE'] = v['tranWidth']
				attributes['buffParameter']['creatureDirectHurCallBack'] = npcID
				attributes['buffParameter']['buffType'] = 1
				attributes['buffParameter']['buffIntervalTime'] = 1
				attributes['buffParameter']['Effect'] = -1
				attributes['BUFFTIME'] = 99999
				local buff = require("gameroomcore.SBuff").new(self,obj1:__skillID2buffID(1,0),attributes,lifeTime,{99},0,npcID,npcID)
				--buff.debug = true
				obj1:addBuff(buff)
				--obj1:setDeadTime(lifeTime) 
				local lifeTime2 = 99999
				local attributes2 = {}
				local hitValue = obj1:createhitValue()
				hitValue['isSafeRange'] = 1
				attributes2['buffParameter'] = hitValue
				-- attributes2['buffParameter']['INVICINBLE_RATE'] = 100
				-- attributes2['buffParameter']['BUFFTIME'] = 0.5
				-- -- attributes2['buffParameter']['ADDSTATUS'] = 73
				-- -- attributes2['buffParameter']['ADDSTATUSTIME'] = 1
				attributes2['BUFFONLY']=1
				attributes2['INEVITABLEHIT'] = 1
				attributes2['buffParameter']['RANGE'] = v['safeWidth']
				attributes2['buffParameter']['creatureDirectHurCallBack'] = npcID
				attributes2['buffParameter']['buffType'] = 1
				attributes2['buffParameter']['buffIntervalTime'] = 0.2
				attributes2['buffParameter']['Effect'] = -1
				attributes2['BUFFTIME'] = 99999
				local buff2 = require("gameroomcore.SBuff").new(self,obj1:__skillID2buffID(2,0),attributes2,lifeTime2,{99},0,npcID,npcID)
				--buff.debug = true
				obj1:addBuff(buff2)
			end
		end
	end
end

--- 设置游戏房中数量统计值
-- @param name char - key name
-- @param addNum int - 增加的值
-- @return null
function WorldBase:setGameCounter(name,addNum)
	if addNum==nil then
		addNum = 0
	end
	self.gameCounter[name] = self.gameCounter[name] + addNum
end

--- 获取游戏房指定键名数量统计值
-- @param name char - key name
-- @return num int - 统计值
function WorldBase:getGameCounter(name)
	return self.gameCounter[name]
end

function WorldBase:getTableValueMin(data)
	local min = 99999
	--self:D('jaylog WorldBase:getTableValueMin data:'..self.cjson.encode(data))
	--if type(data)=='table' then
		for k,v in pairs(data) do
			if min>v then
				min = v
			end
		end
	--end
	return min
end

function WorldBase:getTableValueMax(data)
	local max = 0
	--self:D('jaylog WorldBase:getTableValueMax data:'..self.cjson.encode(data))
	--if type(data)=='table' then
		for k,v in pairs(data) do
			if max>v then
				max = v
			end
		end
	--end
	return max
end

--- 按目標類型取得目標itemList
-- @param targetType int - 目標類型取
-- @param team char - 施放者team
-- @param thisID int - 施放者itemID
-- @param options table - 參數 {notIncludeSelf=不包括自己,isSelfTeam=只限友方,notIncludeSelfSoldier=不包括友方士兵,includeTower=包括塔}
-- @return itemList table - 目標itemList
function WorldBase:getTarget(targetType,team,thisID,options)
	local enemy = {}
	if options==nil then options={} end
	options['notIncludeSelf']=false
	options['isSelfTeam']=false
	options['notIncludeSelfSoldier']=false
	options['includeTower']=false
	if team=="AA" or team=="BB" then
		if targetType=="C" then
			enemy = self.itemListFilter.soldierList
		elseif targetType=="A" or targetType=="B" then
			enemy = self.allItemList
		elseif targetType==0 then
			enemy = self.itemListFilter.heroList
		elseif targetType==1 or targetType==6 or targetType==8 or targetType==9 or targetType==10 then
			options['notIncludeSelf'] = true
			enemy = self.allItemList
		elseif targetType==2 then
			options['notIncludeSelf'] = true
			enemy = self.itemListFilter.heroList
		elseif targetType==7 then
			enemy = self.itemListFilter.towerList
		elseif targetType==3 or targetType==4 or targetType==5 then
			options['isSelfTeam'] = true
			enemy = {}
			enemy[thisID] = self.allItemList[thisID]
		end
	else
		if targetType=="C" then
			enemy = self.itemListFilter.soldierList
		elseif targetType=="A" then
			enemy = self.itemListFilter.teamAMemberList
		elseif targetType=="B" then
			enemy = self.itemListFilter.teamBMemberList
		elseif targetType==0 then
			options['isSelfTeam']=nil
			enemy = self.itemListFilter.heroList
		elseif targetType==1 then
			options['notIncludeSelf'] = true
			if team=="" then
				enemy = self.allItemList
			elseif team=="B" then
				enemy = self.itemListFilter.teamAMemberList
			else
				enemy = self.itemListFilter.teamBMemberList
			end
		elseif targetType==2 then
			options['notIncludeSelf'] = true
			if team=="" then
				enemy = self.allItemList
			elseif team=="B" then
				enemy = self.itemListFilter.heroTeamAList
			else
				enemy = self.itemListFilter.heroTeamBList
			end
		elseif targetType==3 then
			enemy = {}
			enemy[thisID] = self.allItemList[thisID]
		elseif targetType==4 then
			options['isSelfTeam'] = true
			if team=="" then
				enemy = self.allItemList
			elseif team=="B" then
				enemy = self.itemListFilter.heroTeamBList
			else
				enemy = self.itemListFilter.heroTeamAList
			end
		elseif targetType==5 then
			options['isSelfTeam'] = true
			if team=="" then
				enemy = self.allItemList
			elseif team=="B" then
				enemy = self.itemListFilter.teamBMemberList
			else
				enemy = self.itemListFilter.teamAMemberList
			end
		elseif targetType==6 then
			options['notIncludeSelf'] = true
			options['includeTower'] = true
			if team=="" then
				enemy = self.allItemList
			elseif team=="B" then
				enemy = self.itemListFilter.teamA
			else
				enemy = self.itemListFilter.teamB
			end
		elseif targetType==7 then
			options['notIncludeSelf'] = true
			if team=="B" then
				enemy = self.itemListFilter.towerAList
			else
				enemy = self.itemListFilter.towerBList
			end
		elseif targetType==8 then
			options['notIncludeSelf'] = true
			options['isSelfTeam']=nil
			enemy = self.allItemList
		elseif targetType==9 then
			options['notIncludeSelf'] = true
			options['isSelfTeam']=nil
			options['notIncludeSelfSoldier'] = true
			enemy = self.allItemList
		elseif targetType==10 then
			options['isSelfTeam']=nil
			enemy = self.allItemList
		elseif targetType==11 then
			options['notIncludeSelf'] = true
			enemy = self.itemListFilter.teamCMemberList
		elseif targetType==12 then
			options['notIncludeSelf'] = true
			enemy = self.itemListFilter.teamABMemberList
		elseif targetType==13 then
			options['notIncludeSelf'] = true
			if team=="" then
				enemy = self.itemListFilter.noBeFightTeamC
			elseif team=="B" then
				enemy = self.itemListFilter.noBeFightTeamB
			else
				enemy = self.itemListFilter.noBeFightTeamA
			end
		elseif targetType==14 then
			options['notIncludeSelf'] = true
			options['isSelfTeam'] = true
			if team=="" then
				enemy = self.allItemList
			elseif team=="B" then
				enemy = self.itemListFilter.teamBMemberList
			else
				enemy = self.itemListFilter.teamAMemberList
			end
		end
	end
	-- for k,v in pairs(enemy) do
	-- 	self:D('jaylog WorldBase:getTarget enemy list:k'..k..' itemID:'..v.itemID..' roleId:'..v.attribute.roleId)
	-- end
	-- self:D('jaylog WorldBase:getTarget '..targetType..' '..team..' '..thisID..' '..self.cjson.encode(options))
	return enemy
end

--- 在地圖上加入gameobject
-- @param obj object - game object ( SActor , SPotionOnMap )
-- @param delay float - delay time
-- @return null
function WorldBase:addItem(obj,delay)
	if delay==nil then delay = 0 end
	if obj.className=="SPotionOnMap" then
		self.itemListFilter.potionOnMapList[obj:getID()] = obj
		self.allItemList[obj:getID()] = obj
		obj:updateSyncMsg({i=obj:getAllInfo(delay)})
		return nil
	end
	if obj.attribute.actorType==0 or obj.attribute.actorType==2 then
		self.itemListFilter.heroList[obj:getID()] = obj
		if obj.teamOrig~="B" then
			self.itemListFilter.heroTeamAList[obj:getID()] = obj
		end
		if obj.teamOrig~="A" then
			self.itemListFilter.heroTeamBList[obj:getID()] = obj
		end
	elseif obj.className=="STower" then
		self.itemListFilter.towerList[obj:getID()] = obj
	-- elseif obj.className=="SSoldier" or obj.className=="SMonster" or obj.className=="SEye" or obj.className=="SCreature" or obj.className=="SNpc" then
	elseif obj.attribute.parameterArr['NOBEFIGHT']~=nil then
		self.itemListFilter.noBeFightList[obj:getID()] = obj
		if obj.attribute.parameterArr['NOBEFIGHT_FORAI']~=nil then
			if obj.teamOrig=="A" then
				self.itemListFilter.noBeFightTeamA[obj:getID()] = obj
			end
			if obj.teamOrig=="B" then
				self.itemListFilter.noBeFightTeamB[obj:getID()] = obj
			end
			if obj.teamOrig=="" then
				self.itemListFilter.noBeFightTeamC[obj:getID()] = obj
			end
		end
	else
		self.itemListFilter.soldierList[obj:getID()] = obj
	end
	if obj.teamOrig~="B" and obj.attribute.parameterArr['NOBEFIGHT']==nil and obj.attribute.actorType~=3 then
		--self:D("jaylog WorldBase:addItem A ",obj.itemID," , ",obj.teamOrig," : ",obj.team,' ',obj:getID())
		self.itemListFilter.teamA[obj:getID()] = obj
		if obj.className=="STower" then
			self.itemListFilter.towerAList[obj:getID()] = obj
		else
			self.itemListFilter.teamAMemberList[obj:getID()] = obj
		end
	end
	if obj.teamOrig~="A" and obj.attribute.parameterArr['NOBEFIGHT']==nil and obj.attribute.actorType~=3 then
		--self:D("jaylog WorldBase:addItem B ",obj.itemID," , ",obj.teamOrig," : ",obj.team,' ',obj:getID())
		self.itemListFilter.teamB[obj:getID()] = obj
		if obj.className=="STower" then
			self.itemListFilter.towerBList[obj:getID()] = obj
		else
			self.itemListFilter.teamBMemberList[obj:getID()] = obj
		end
	end
	if obj.teamOrig~="" and obj.attribute.actorType~=3 and obj.attribute.parameterArr['NOBEFIGHT']==nil then
		self.itemListFilter.teamABMemberList[obj:getID()] = obj
	end
	if obj.teamOrig=="" and obj.attribute.actorType~=3 and obj.attribute.parameterArr['NOBEFIGHT']==nil then
		self.itemListFilter.teamCMemberList[obj:getID()] = obj
	end
	--self:D('jaylog WorldBase:addItem itemID:'..obj.itemID..' roleID:'..obj.attribute.roleId..self.cjson.encode(obj.attribute.parameterArr))
	--for k,v in pairs(self.itemListFilter.noBeFightList) do
	--	self:D('jaylog WorldBase:addItem noBeFightList itemID:'..v.itemID..' roleID:'..v.attribute.roleId)
	--end
	self.allItemList[obj:getID()] = obj
	obj:updateSyncMsg({i=obj:getAllInfo(delay)})
	if (self.formula:isLog(obj.attribute.roleId)==1 or self.formula:isLog(obj.loginID)==1) and (not obj.isAI or self.tonumber(self.mapModel)==10300) then
		obj.debug = true
	end
	local logMap = {['1999']=1,['1998']=1,['1997']=1,['9006']=0,['8004']=0,['8006']=0,['1005']=1}
	if logMap[self.mapModel]~=nil and logMap[self.mapModel]==1 then
		-- obj.debug = true
	end
	if self.mapModel=='1999' or self.mapModel=='1998' or self.mapModel=='1997' or self.mapModel=='9006' or self.mapModel=='8004' or self.mapModel=='8006' then
		-- obj.debug = true
	end
	--self:D('============== check add item ',self.cjson.encode(obj.syncMsg),obj:getID(),obj:isDead(),obj.deadTime)
	--self:D('============== add item '..self.cjson.encode(self.syncMsg).." , "..self.cjson.encode(obj:getAllInfo(delay)))
end

--- 在地圖上刪除gameobject
-- @param obj object - game object ( SActor , SPotionOnMap )
-- @return null
function WorldBase:removeItem(obj)
	if obj.className=="SPotionOnMap" then
		self:addSyncMsg({i={i=obj:getID(),s=2}})--,a=obj.equipID,st=obj.lastItemID,at=2}})
	else
		local info = obj.syncMsg['i']
		if info==nil then
			info={i=obj:getID(),s=2}
		else
			info['s'] = 2
		end
		self:addSyncMsg({i=info})--,a=obj.attribute.ID,at=obj.attribute.actorType}})
	end
	if obj.className=="SPotionOnMap" then
		obj:release()
		self.itemListFilter.potionOnMapList[obj:getID()] = nil
		self.allItemList[obj:getID()] = nil
		return
	end
	local reuseID = obj.attribute.ID
	if obj.attribute.actorType==0 or obj.attribute.actorType==2 then
		self.itemListFilter.heroList[obj:getID()] = nil
		if obj.teamOrig=="A" then
			self.itemListFilter.heroTeamAList[obj:getID()] = nil
		else
			self.itemListFilter.heroTeamBList[obj:getID()] = nil
		end
	elseif obj.className=="STower" then
		self.itemListFilter.towerList[obj:getID()] = nil
	-- elseif obj.className=="SSoldier" or obj.className=="SMonster" or obj.className=="SEye" or obj.className=="SCreature" or obj.className=="SNpc" then
	elseif obj.attribute.parameterArr['NOBEFIGHT']~=nil then
		self.itemListFilter.noBeFightList[obj:getID()] = nil
	else
		self.itemListFilter.soldierList[obj:getID()] = nil
	end
	-- elseif obj.className=="SSoldier" or obj.className=="SMonster" or obj.className=="SEye" or obj.className=="SCreature" then
	-- 	self.itemListFilter.soldierList[obj:getID()] = nil
	-- elseif obj.className=="STower" then
	-- 	self.itemListFilter.towerList[obj:getID()] = nil
	-- end
	if obj.teamOrig~="B" then
		self.itemListFilter.teamA[obj:getID()] = nil
		if obj.className=="STower" then
			self.itemListFilter.towerAList[obj:getID()] = nil
		end
		self.itemListFilter.teamAMemberList[obj:getID()] = nil
		self.itemListFilter.teamABMemberList[obj:getID()] = nil
	end
	if obj.teamOrig~="A" then
		self.itemListFilter.teamB[obj:getID()] = nil
		if obj.className=="STower" then
			self.itemListFilter.towerBList[obj:getID()] = nil
		end
		self.itemListFilter.teamBMemberList[obj:getID()] = nil
		self.itemListFilter.teamABMemberList[obj:getID()] = nil
	end
	if obj.teamOrig=="" then
		self.itemListFilter.teamCMemberList[obj:getID()] = nil
	end
	if obj.attribute.parameterArr['NOBEFIGHT']~=nil then
		self.itemListFilter.noBeFightList[obj:getID()] = nil
		if obj.attribute.parameterArr['NOBEFIGHT_FORAI']~=nil then
			if obj.teamOrig=="A" then
				self.itemListFilter.noBeFightTeamA[obj:getID()] = nil
			end
			if obj.teamOrig=="B" then
				self.itemListFilter.noBeFightTeamB[obj:getID()] = nil
			end
			if obj.teamOrig=="" then
				self.itemListFilter.noBeFightTeamC[obj:getID()] = nil
			end
		end
	end
	if self.itemListFilter.noBeFightBuffList[''..obj:getID()]~=nil then
		self.itemListFilter.noBeFightBuffList[''..obj:getID()] = nil
	end
	if obj.attribute.actorType==0 and obj:getID()==self.itemHeroID then
		self.itemHeroID = self.itemHeroID + 1
	end
	if obj.attribute.actorType~=0 and obj:getID()==self.itemID then
		self.itemID = self.itemID + 1
	end
	if obj.actorType==0 then
		self:D('jaylog WorldBase:removeItem before obj:release',obj:getID())--,debug.traceback("", 2)
	end
	obj:release()
	self.allItemList[obj:getID()] = nil
end

--- 加入處理完整完成的狀態
-- @param status table - status table
-- @return null
function WorldBase:addCompletedEndStatus(status,itemID)
	local statusTmp = self.tDeepcopy(status)
	statusTmp['gt'] = statusTmp['r'] + statusTmp['t']
	statusTmp['i'] = itemID
	self.waitForProcessStatus[#self.waitForProcessStatus+1] = statusTmp
end

--- 處理完整完成的狀態
-- @return null
function WorldBase:processCompletedEndStatus()
	if #self.waitForProcessStatus==0 then
		return nil
	end
	table.sort(self.waitForProcessStatus,function(a1,b1)
		return a1['gt'] < b1['gt']
	end)
	self:D('jaylog WorldBase:processCompletedEndStatus '..self.cjson.encode(self.waitForProcessStatus))
	for k,v in pairs(self.waitForProcessStatus) do
		if v['s']==41 then
			self.allItemList[v['i']]:skillAttackMode9CallBack(v['p1'],v['p2'],v['p3'])
		end
		if v['s']==991 then
			self.allItemList[v['i']]:processCallBack(v['p1'])
		end
		if v['s']==99 then
			self.allItemList[v['i']]:status99CallBack(v['p1'])
		end
		if v['s']==100 then
			self.allItemList[v['i']]:skillAttackMode9CallBack(v['p1'],v['p2'],v['p3'])
		end
		if v['s']==605 then
			self.allItemList[v['i']]:end605CallBack(v['p1'])
		end
	end
	self.waitForProcessStatus = {}
end

--- 在地圖 加入藥水
-- @param id int - 藥水id
-- @param x float - 位置x
-- @param y float - 位置y
-- @param group int - 藥水id
-- @return itemID int - 藥水id
function WorldBase:addPotionOnMap(id,x,y,group)
	if group==nil then
		group=""
	end
	local potion = require("gameroomcore.SPotionOnMap").new(self,id,x,y,group)
	self:addItem(potion)
	return potion.itemID
end

--- 创建一个召唤物
function WorldBase:crateCreature(id,centersNum,range,posType,subName,parent,isExtra,isBuffID,noAI)
	-- range = {{posX=self.posX,posY=self.posY},
	-- 		 {posX=self.posX,posY=self.posY,radius1=(skill.useDis/self.world.setting.AdjustAttRange)},
	-- 		 --rNum用来表示是多少个半径 pNum1用来表示随机的范围
	-- 		 {posX=self.posX,posY=self.posY,radius1=5,radius2=2,rNum=2,pNum1=8,pNum2=12}}
	
	-- 		--1
	-- 		range = {
	-- 			{posX=self.posX,posY=self.posY},
	-- 			{posX=self.posX,posY=self.posY},
	-- 			{posX=self.posX,posY=self.posY},
	-- 		}
	-- 		--2
	-- 		range = {
	-- 			{posX=self.posX,posY=self.posY,radius1=1,num=1},
	-- 			{posX=self.posX,posY=self.posY,radius1=1,num=1},
	-- 			{posX=self.posX,posY=self.posY,radius1=1,num=1},
	-- 		}
	-- 		--3
	-- 		range = {
	-- 			{posX=self.posX,posY=self.posY,radius1=5,radius2=2,rNum=2,pNum1=8,pNum2=12,num=8},
	-- 			{posX=self.posX,posY=self.posY,radius1=5,radius2=2,rNum=2,pNum1=8,pNum2=12,num=6},
	-- 			{posX=self.posX,posY=self.posY,radius1=5,radius2=2,rNum=2,pNum1=8,pNum2=12,num=5},
	-- 		}
	self:D('jaylog WorldBase:crateCreature range:',self.cjson.encode(range),' id:',id,' posType:',posType,' centersNum:',centersNum,' subName:',subName," isBuffID",isBuffID)
	local creatureIDList = {}
	if posType==1 or posType==2 then
		for i=1,centersNum do
			local toX=0
			local toY=0
			--定值
			if posType==1 then
				toX=range[i]['POSX']
				toY=range[i]['POSY']
				local hitTime = 0
				if range[i]['HITTIME']~=nil then
					hitTime = range[i]['HITTIME']
				end
				local delayTime = 0
				if range[i]['DELAYTIME']~=nil then
					delayTime = range[i]['DELAYTIME']
				end
				local showNum = 0
				if range[i]['SHOWNUM']~=nil then
					showNum = range[i]['SHOWNUM']
				end
				local showInterval = 0
				if range[i]['SHOWINTERVAL']~=nil then
					showInterval = range[i]['SHOWINTERVAL']
				end 
				--local creatureID=self:addCreature(self.tostring(100+id),'',toX,toY,nil,1,hitTime+i*delayTime) 
				local lifeTime = range[i]['LIFETIME']
				local creatureID

				-- if parent~=nil then
				-- 	creatureID=self:addCreature(self.tostring(id),'',toX,toY,parent,1,hitTime+i*delayTime) 
				-- else
				-- 	creatureID=self:addMonster(id,toX,toY,'group',1,'',hitTime+i*delayTime)
				-- end
				local creatureID=self:adjCreature(id,toX,toY,hitTime+i*delayTime,subName,lifeTime,parent,isExtra,isBuffID,noAI)
				-- local obj  = self.allItemList[creatureID]
				-- obj:setSubName(subName) 
				--self.creatureList[#self.creatureList+1]=creatureID 
				creatureIDList[#creatureIDList+1]=creatureID 
			end
			--随机值 园内随机
			if posType==2 then
				local sNum,sDelay = 0,0
				for k=1,range[i]['num'] do
					local x = range[i]['POSX']
					local y = range[i]['POSY']
					toX,toY = self.formula:getRandomCirclePoint(0,0,range[i]['radius1'],false)
					local hitTime = range[i]['HITTIME']
					local delayTime = range[i]['DELAYTIME']
					local lifeTime = range[i]['LIFETIME']
					local showNum = 0
					if range[i]['SHOWNUM']~=nil then
						showNum = range[i]['SHOWNUM']
					end
					local showInterval = 0
					if range[i]['SHOWINTERVAL']~=nil then
						showInterval = range[i]['SHOWINTERVAL']
					end 
					local ret,toX,toY=self.map:findPointStraightLineNearest(x,y,x+toX,y+toY)
					if range[i]['CHECKEXIST']~=nil then
						local checkdis = 0
						if range[i]['CHECKDIS']~=nil and range[i]['CHECKDIS']~=0 then
							checkdis = range[i]['CHECKDIS']
						end
						for cei=1,3 do
							local existPos = false
							for k1,v1 in pairs(self.allItemList) do
								if v1.actorType==1 and self.tonumber(v1.attribute.roleId)==self.tonumber(id) then
									if self.map:distance(v1.posX,v1.posY,x+toX,y+toY)<checkdis then
										existPos = true
										break
									end
								end
							end
							if existPos then
								toX,toY = self.formula:getRandomCirclePoint(0,0,range[i]['radius1'],false)
								ret,toX,toY=self.map:findPointStraightLineNearest(x,y,x+toX,y+toY)
							else
								break
							end
						end
						local existPos = false
						local existX,existY = 0,0
						local existLen = self.formula:getRandnum(2,6)
						for k1,v1 in pairs(self.allItemList) do
							if v1.actorType==1 and self.tonumber(v1.attribute.roleId)==self.tonumber(id) then
								if self.map:distance(v1.posX,v1.posY,toX,toY)<checkdis then
									existPos = true
									existX,existY = v1.posX,v1.posY
									break
								end
							end
						end
						if existPos then
							toX,toY = self.map:getXYLength(existX,existY,toX,toY,existLen)
							toX,toY = existX+toX,existY+toY
						end
					end
					self:D('jaylog x:',x,' y:',y,' i:',i,' toX:',toX,' toY:',toY,' range:',self.cjson.encode(range))
					if parent~=nil and not ret then
						local a,b,c = self:notPass(parent.posX,parent.posY,toX,toY)
						self:D('jaylog WorldBase:crateCreature posType2 check notPass:',a,b,c)
					end
					if range[i]['SHOWNUM']~=nil then
						sNum = sNum + 1
						if sNum==showNum then
							sNum = 0
							sDelay = sDelay + showInterval
						end
					end
					local creatureID=self:adjCreature(id,toX,toY,hitTime+i*delayTime+sDelay,subName,lifeTime,parent,isExtra,isBuffID,noAI)
					creatureIDList[#creatureIDList+1]=creatureID 	
				end
			end
		end
	end

	if posType==3 then
		local syncMsg = {}
		syncMsg['a'] = {}
		--固定随机圆上点...
		for i=1,centersNum do
			local randlist = {}
			local changelist = {}
			self:D(" range:"..self.cjson.encode(range))
			for j=1,range[i]['rNum'] do
				list = self.formula:formationPoint(range[i]['pNum'..j],range[i]['radius'..j],true,true)
				for k,v in pairs(list) do
					randlist[#randlist+1]=v
				end
				if range[i]['radius'..j]>3 then
					list = self.formula:formationPoint(range[i]['pNum'..j],range[i]['radius'..j]-2,true,true)
				else
					list = self.formula:formationPoint(range[i]['pNum'..j],range[i]['radius'..j],true,true)
				end
				--list = self.formula:formationPoint(range[i]['pNum'..j],range[i]['radius'..j],true,true)
				for k,v in pairs(list) do
					changelist[#changelist+1]=v
				end
			end
			self:D("WorldBase:crateCreature randlist:"..self.cjson.encode(randlist))
			self:D("WorldBase:crateCreature changelist:"..self.cjson.encode(changelist))
			for k=1,range[i]['num'] do
				local rand = self.formula:getRandnum(1,#randlist)
				self:D("WorldBase:crateCreature 召唤物坐标偏移坐标:x"..randlist[rand][1].." y:"..randlist[rand][2],k)
				local x = range[i]['POSX']
				local y = range[i]['POSY']
				local hitTime = range[i]['HITTIME']
				local delayTime = range[i]['DELAYTIME']

				local lifeTime = range[i]['LIFETIME']
				toX = x+randlist[rand][1]
				toY = y+randlist[rand][2]
				self:D('jaylog WorldBase:crateCreature checkexist:',range[i]['CHECKEXIST'],' randlist:',self.cjson.encode(randlist),rand)
				if range[i]['CHECKEXIST']~=nil then
					local noChange = true
					local checkdis = 0
					if range[i]['CHECKDIS']~=nil and range[i]['CHECKDIS']~=0 then
						checkdis = range[i]['CHECKDIS']
					end
					for ck,cv in pairs(self.allItemList) do
						if self.tonumber(cv.attribute.roleId)==self.tonumber(id) and not cv:isDead() then
							noChange = true
							local distance = self.map:distance(cv.posX,cv.posY,toX,toY)
							-- self:D('jaylog WorldBase:crateCreature sx:',cv.posX,cv.posY,' tx:',toX,toY,' dis:',distance,cv.attribute.roleId,id)
							if self.tonumber(cv.attribute.roleId)==self.tonumber(id) and ((cv.posX==toX and cv.posY==toY) or (distance>=0 and distance<3)) then
								self:D('jaylog WorldBase:crateCreature distance is less than 2 ',id,cv.posX,cv.posY,toX,toY)
								noChange = false
								table.remove(changelist, rand)
							end
							if not noChange and not empty(changelist) then
								local rand1 = self.formula:getRandnum(1,#changelist)
								toX = x+changelist[rand1][1]
								toY = y+changelist[rand1][2]
								self:D('jaylog WorldBase:crateCreature rand:',rand1,' randlist:',self.cjson.encode(randlist))
							end
						end
					end
				end
				--local ret,toX,toY=self.world.map:findNearestIdlePoint(x,y,x+randlist[rand][1],y+randlist[rand][2],2)
				table.remove(randlist, rand)
				self:D("adjCreature : id:"..id.." toX:"..toX.." toY:"..toY)
				-- if parent~=nil then
				-- 	local a,b,c = self:notPass(parent.posX,parent.posY,toX,toY)
				-- 	self:D('jaylog WorldBase:crateCreature posType3 check notPass:',a,b,c)
				-- end
				local creatureID = 0
				if range[i]['ADDATTACK']~=nil and range[i]['BULLETSPEED']~=nil and range[i]['MODE']~=nil and range[i]['ADDATTACK']>0 and range[i]['BULLETSPEED']>0 and range[i]['MODE']>0 then
					local distance = self.map:distance(parent.posX,parent.posY,toX,toY)
					local hurtTime = math.round( ( (distance ) / range[i]['BULLETSPEED'] ) * self.setting.walkingSpeed, 2)
					delayTime = delayTime + hurtTime 
					self:D("adjCreature delayTime:",delayTime)
					creatureID=self:adjCreature(id,toX,toY,hitTime+delayTime,subName,lifeTime,parent,isExtra,isBuffID,noAI)
				else
					creatureID=self:adjCreature(id,toX,toY,hitTime+i*delayTime,subName,lifeTime,parent,isExtra,isBuffID,noAI)
				end
				creatureIDList[#creatureIDList+1]=creatureID 
				local creatureObj = self.allItemList[creatureID]
				if range[i]['ADDCREATURESTATUS']~=nil and range[i]['ADDCREATURESTATUSTIME'] then
					creatureObj:addStatusList({s=range[i]['ADDCREATURESTATUS'],r=self:getGameTime(),t=range[i]['ADDCREATURESTATUSTIME'],i=parent.itemID})
				end
				if range[i]['ADDATTACK']~=nil and range[i]['BULLETSPEED']~=nil and range[i]['MODE']~=nil and range[i]['ADDATTACK']>0 and range[i]['BULLETSPEED']>0 and range[i]['MODE']>0 then
					local distance = creatureObj:distance(parent.posX,parent.posY,parent.itemID)
					local hurtTime = math.round( ( (distance ) / range[i]['BULLETSPEED'] ) * self.setting.walkingSpeed, 2)
					--local syncMsg = {a={}}
					syncMsg['a'][#syncMsg['a']+1] = {x=creatureObj.posX,y=creatureObj.posY,sx=parent.posX,sy=parent.posY,ht=hurtTime,ti=creatureID,m=range[i]['MODE'],i=parent.itemID}  
					-- syncMsg['a'][#syncMsg['a']+1] = {x=creatureObj.posX,y=creatureObj.posY,sx=parent.posX,sy=parent.posY,ht=hurtTime,ti=parent.itemID,m=range[i]['MODE'],i=creatureID} 
					-- creatureObj:updateSyncMsg(syncMsg)
				end
			end
			if range[i]['ADDATTACK']~=nil and range[i]['BULLETSPEED']~=nil and range[i]['MODE']~=nil and range[i]['ADDATTACK']>0 and range[i]['BULLETSPEED']>0 and range[i]['MODE']>0 and syncMsg['a']~=nil and not empty(syncMsg['a']) then
				self:D('jaylog WorldBase:crateCreature updateSyncMsg:',self.cjson.encode(syncMsg))
				parent:updateSyncMsg(syncMsg)
				self:D('jaylog WorldBase:crateCreature updateSyncMsg after:',self.cjson.encode(parent.syncMsg))
			end
		end
	end

	return creatureIDList
end

--- 加到地图上
function WorldBase:adjCreature( id,toX,toY,hitTime,subName,lifeTime,parent,isExtra,isBuffID,noAI)
	if subName==nil then
		subName=''
	end
	self:D("jaylog adjCreature id:",id," toX:",toX," toY:",toY," hitTime:",hitTime,' subName:',subName,' isBuffID:',isBuffID,' lifeTime:',lifeTime)
	--local creatureID=self:addCreature(self.tostring(id),'',toX,toY,nil,1,hitTime) 
	for k,v in pairs(self.gameRoomSetting['extraEnemy']) do
		if v==self.tonumber(id) then
			isExtra = true
		end
	end
	local creatureID
	if isExtra~=nil or (parent==nil and lifeTime>0) then
		creatureID=self:addCreature(self.tostring(id),'',toX,toY,parent,1,hitTime)
	elseif parent~=nil then
		creatureID=self:addCreature(self.tostring(id),parent.teamOrig,toX,toY,parent,1,hitTime)
	else
		creatureID=self:addMonster(self.tostring(id),toX,toY,'group',1,'',hitTime)
	end
	local obj  = self.allItemList[creatureID]
	if hitTime>0 then
		self.allItemList[creatureID].AIlastCoolDown = self.gameTime + hitTime
		local attributes = {}
		attributes['INVICINBLE_RATE']=100
		attributes['Effect']=-1
		local buff = self:createBuff(obj:__skillID2buffID(0),attributes,hitTime,{},0,obj.itemID,obj.itemID)
		obj:addBuff(buff)
	end
	if noAI==1 then
		self.allItemList[creatureID].autoFightAI.runAI = false
		self.allItemList[creatureID].autoFightAI.runMoveAI = false
		self.allItemList[creatureID].autoFightAI.noAutoPatrol = true
	end
	--self.creatureList[#self.creatureList+1]=creatureID

	obj:setSubName(subName)
	local attributes = {}
	attributes['INVICINBLE_RATE'] = 100 
	-- local buff = require("gameroomcore.SBuff").new(self,obj:__skillID2buffID(0),attributes,0.5,{},0,obj.itemID,obj.itemID)
	local buff = self:createBuff(obj:__skillID2buffID(0),attributes,0.5,{},0,obj.itemID,obj.itemID)
	obj:addBuff(buff)
	local attributes2 = {}
	if isBuffID==1 then
		attributes2['IMMUNEAD_RATE'] = 100 
	end
	if isBuffID==2 then
		attributes2['IMMUNEAP_RATE'] = 100 
	end
	--	local buff2 = require("gameroomcore.SBuff").new(self,obj:__skillID2buffID(0),attributes2,9999,{},0,obj.itemID,obj.itemID)
	local buff2 = self:createBuff(obj:__skillID2buffID(0),attributes2,9999,{},0,obj.itemID,obj.itemID)
	obj:addBuff(buff2)
	if lifeTime>0 then
		obj:setDeadTime(lifeTime) 
	end
	return creatureID
end

--- 起始创建召唤物函数
function WorldBase:callCreature(hitValueBoth,parent,isExtra,noAI)
	-- 定点 3(圆心数量),160(ID),0(0代表DB取值 1代表目标 2代表自己),1(0,正常可不填,1物免,2魔免)
	-- SUMMONPOINT=3,160,0;CIRCLE1=POSX:100,POSY:50;CIRCLE1=POSX:100,POSY:50
	-- --随机园内点
	-- SUMMONCIRCLE=1,150,0;CIRCLE1=POSX:100,POSY:50,R1:10,SUMMONNUM:10,HITTIME:10,DELAYTIME:0
	-- --随机固定点
	-- SUMMONRING=2,110,1;CIRCLE1=POSX:100,POSY:50,CIRCLENUM:2,R1:5,R2:50,POINTNUM1:5,POINTNUM2:8,SUMMONNUM:10,HITTIME:10,DELAYTIME:0;
	-- CIRCLE2=POSX:20,POSY:500,CIRCLENUM:1,R1:5,POINTNUM1:5,SUMMONNUM:3,HITTIME:10,DELAYTIME:1
	-- SUMMONRING=2,122,2;CIRCLE1=POSX:1,POSY:1,CIRCLENUM:1,R1:500,POINTNUM1:6,SUMMONNUM:6,HITTIME:0.5,DELAYTIME:0;CIRCLE2=POSX:1,POSY:1,
	-- CIRCLENUM:1,R1:800,POINTNUM1:10,SUMMONNUM:10,HITTIME:1.5,DELAYTIME:0.2
	-- if hitValueBoth~=nil and mode==3 and self.attribute.roleId==3 then
	
		if hitValueBoth['SUBNAME']==nil then
			hitValueBoth['SUBNAME'] = {''}
		end
		if self.gType(hitValueBoth['SUBNAME'])=='string' then
			local subName = hitValueBoth['SUBNAME']
			hitValueBoth['SUBNAME'] = {subName}
			--self:D('jaylog WorldBase:callCreature SUBNAME STRING',self.cjson.encode(hitValueBoth['SUBNAME']),self.gType(hitValueBoth['SUBNAME']))
		end
		--self:D('jaylog WorldBase:callCreature subName',self.cjson.encode(hitValueBoth['SUBNAME']),self.gType(hitValueBoth['SUBNAME']))
		--self:D('jaylog WorldBase:callCreature hitValueBoth:',self.cjson.encode(hitValueBoth))
		--随机固定点
		if hitValueBoth['SUMMONRING']~=nil then
			--几个圆心
			local cList = hitValueBoth['SUMMONRING']
			local isBuffID = 0
			if cList[4]~=nil then
				isBuffID = cList[4]
			end
			local range = {}
			for i=1,cList[1] do
				local CIRCLE = hitValueBoth['CIRCLE'..i]
				local x,y=0,0
				--取坐标
				if parent~=nil then
					if cList[3]==1 then
						x,y = parent.lastBulletPositionX,parent.lastBulletPositionY
					end
					if cList[3]==2 then
						x,y = parent.posX,parent.posY
					end
				end
				
				if cList[3]==0 then
					x,y = CIRCLE['POSX'],CIRCLE['POSY']
				end
				--几个园环 ◎
				local CIRCLENUM = 1
				if CIRCLE['CIRCLENUM']~=nil then
					CIRCLENUM = CIRCLE['CIRCLENUM']
				end
				self:D('jaylog WorldBase:callCreature CIRCLENUM ',CIRCLENUM)
				range[i]={POSX=x,POSY=y}
				for k=1,CIRCLENUM do
					range[i]['radius'..k]=CIRCLE['R'..k]
					range[i]['pNum'..k]=self.tonumber(CIRCLE['POINTNUM'..k])
				end
				range[i]['rNum'] = CIRCLENUM
				range[i]['num'] = self.tonumber(CIRCLE['SUMMONNUM'])
				range[i]['HITTIME'] = CIRCLE['HITTIME']
				range[i]['DELAYTIME'] = CIRCLE['DELAYTIME']
				if CIRCLE['LIFETIME']~=nil then
					range[i]['LIFETIME'] = CIRCLE['LIFETIME']
				else
					range[i]['LIFETIME'] = -1
				end
				if CIRCLE['CHECKEXIST']~=nil and CIRCLE['CHECKEXIST']~=0 then
					range[i]['CHECKEXIST'] = CIRCLE['CHECKEXIST']
				end
				if CIRCLE['CHECKDIS']~=nil and CIRCLE['CHECKDIS']~=0 then
					range[i]['CHECKDIS'] = CIRCLE['CHECKDIS']
				end
				if hitValueBoth['ADDATTACK']~=nil and hitValueBoth['ADDATTACK']~=0 then
					range[i]['ADDATTACK'] = hitValueBoth['ADDATTACK']
					if hitValueBoth['MODE']~=nil then
						range[i]['MODE'] = hitValueBoth['MODE']
					end
					if hitValueBoth['BULLETSPEED']~=nil then
						range[i]['BULLETSPEED'] = hitValueBoth['BULLETSPEED']
					end
				end
				if hitValueBoth['SHOWNUM']~=nil and hitValueBoth['SHOWNUM']~=0 then
					range[i]['SHOWNUM'] = hitValueBoth['SHOWNUM']
				end
				if hitValueBoth['SHOWINTERVAL']~=nil and hitValueBoth['SHOWINTERVAL']~=0 then
					range[i]['SHOWINTERVAL'] = hitValueBoth['SHOWINTERVAL']
				end
				if hitValueBoth['ADDCREATURESTATUS']~=nil and hitValueBoth['ADDCREATURESTATUS']~=0 and hitValueBoth['ADDCREATURESTATUSTIME']~=nil and hitValueBoth['ADDCREATURESTATUSTIME']~=0 then
					range[i]['ADDCREATURESTATUS'] = hitValueBoth['ADDCREATURESTATUS']
					range[i]['ADDCREATURESTATUSTIME'] = hitValueBoth['ADDCREATURESTATUSTIME']
				end
			end
			self:D("jaylog range:"..self.cjson.encode(range))
			hitValueBoth['autoCreatureIDList']=self:crateCreature(cList[2],cList[1],range,3,hitValueBoth['SUBNAME'][1],parent,isExtra,isBuffID,noAI)
		end

		--随机园内点	SUMMONCIRCLE=1,150,0;CIRCLE1=POSX:100,POSY:50,R1:10,SUMMONNUM:10,HITTIME:10,DELAYTIME:0
		if hitValueBoth['SUMMONCIRCLE']~=nil then
			--几个圆心
			local cList = hitValueBoth['SUMMONCIRCLE']
			local isBuffID = 0
			if cList[4]~=nil then
				isBuffID = cList[4]
			end
			local range = {}
			for i=1,cList[1] do
				local CIRCLE = hitValueBoth['CIRCLE'..i]
				local x,y=0,0
				--取坐标
				if parent~=nil then
					if cList[3]==1 then
						x,y = parent.lastBulletPositionX,parent.lastBulletPositionY
					end
					if cList[3]==2 then
						x,y = parent.posX,parent.posY
					end
				end
				if cList[3]==0 then
					self:D('jaylog WorldBase:callCreature CIRCLE:',self.cjson.encode(CIRCLE))
					x,y = CIRCLE['POSX'],CIRCLE['POSY']
				end
				range[i]={POSX=x,POSY=y}
				range[i]['radius1']=CIRCLE['R1']
				range[i]['num'] = self.tonumber(CIRCLE['SUMMONNUM'])
				range[i]['HITTIME'] = CIRCLE['HITTIME']
				range[i]['DELAYTIME'] = CIRCLE['DELAYTIME']
				if CIRCLE['LIFETIME']~=nil then
					range[i]['LIFETIME'] = CIRCLE['LIFETIME']
				else
					range[i]['LIFETIME'] = -1
				end
				if CIRCLE['CHECKEXIST']~=nil and CIRCLE['CHECKEXIST']~=0 then
					range[i]['CHECKEXIST'] = CIRCLE['CHECKEXIST']
				end
				if CIRCLE['CHECKDIS']~=nil and CIRCLE['CHECKDIS']~=0 then
					range[i]['CHECKDIS'] = CIRCLE['CHECKDIS']
				end
				if hitValueBoth['SHOWNUM']~=nil and hitValueBoth['SHOWNUM']~=0 then
					range[i]['SHOWNUM'] = hitValueBoth['SHOWNUM']
				end
				if hitValueBoth['SHOWINTERVAL']~=nil and hitValueBoth['SHOWINTERVAL']~=0 then
					range[i]['SHOWINTERVAL'] = hitValueBoth['SHOWINTERVAL']
				end
			end
			hitValueBoth['autoCreatureIDList']=self:crateCreature(cList[2],cList[1],range,2,hitValueBoth['SUBNAME'][1],parent,isExtra,isBuffID,noAI)
		end

		--随机园内点-- SUMMONPOINT=3,160,0;CIRCLE1=POSX:100,POSY:50;CIRCLE1=POSX:100,POSY:50
		if hitValueBoth['SUMMONPOINT']~=nil then
			self:D("")
			--几个圆心
			local cList = hitValueBoth['SUMMONPOINT']
			local isBuffID = 0
			if cList[4]~=nil then
				isBuffID = cList[4]
			end
			local range = {}
			for i=1,cList[1] do
				local CIRCLE = hitValueBoth['CIRCLE'..i]
				local x,y=0,0
				--取坐标
				if parent~=nil then
					if cList[3]==1 then
						x,y = parent.lastBulletPositionX,parent.lastBulletPositionY
					end
					if cList[3]==2 then
						x,y = parent.posX,parent.posY
					end
				end
				if cList[3]==0 then
					x,y = CIRCLE['POSX'],CIRCLE['POSY']
				end
				---- SUMMONCIRCLE=1,150,0;CIRCLE1=POSX:100,POSY:50,R1:10,SUMMONNUM:10,HITTIME:10,DELAYTIME:0
				range[i]={POSX=x,POSY=y}
				range[i]['HITTIME'] = CIRCLE['HITTIME']
				range[i]['DELAYTIME'] = CIRCLE['DELAYTIME']
				if CIRCLE['LIFETIME']~=nil then
					range[i]['LIFETIME'] = CIRCLE['LIFETIME']
				else
					range[i]['LIFETIME'] = -1
				end
				if CIRCLE['CHECKEXIST']~=nil and CIRCLE['CHECKEXIST']~=0 then
					range[i]['CHECKEXIST'] = CIRCLE['CHECKEXIST']
				end
				if CIRCLE['CHECKDIS']~=nil and CIRCLE['CHECKDIS']~=0 then
					range[i]['CHECKDIS'] = CIRCLE['CHECKDIS']
				end
				if hitValueBoth['SHOWNUM']~=nil and hitValueBoth['SHOWNUM']~=0 then
					range[i]['SHOWNUM'] = hitValueBoth['SHOWNUM']
				end
				if hitValueBoth['SHOWINTERVAL']~=nil and hitValueBoth['SHOWINTERVAL']~=0 then
					range[i]['SHOWINTERVAL'] = hitValueBoth['SHOWINTERVAL']
				end
			end
			hitValueBoth['autoCreatureIDList']=self:crateCreature(cList[2],cList[1],range,1,hitValueBoth['SUBNAME'][1],parent,isExtra,isBuffID,noAI)
		end
end

--- 检测玩家是否离线
-- @param null
-- @return null
function WorldBase:checkHeroOffLine()
	if self.gameRoomSetting['ISYW']==1 then
		local queueNum = 0
		for k,v in pairs(self.playerList) do
			-- self:D('jaylog WorldBase:checkHeroOffLine before1 removeItem offLineTime:',v['offLineTime'],' gameTime:',self.gameTime,self.playerList[k]['id'])
			if self.itemListFilter.heroList[k]~=nil and not v['online'] and v['offLineTime']~=nil and v['offLineTime']~=0 and (self.gameTime-v['offLineTime'])>self.gameRoomSetting.offlineRemoveWaitTime then
				-- self:D('jaylog WorldBase:checkHeroOffLine before2 removeItem offLineTime:',v['offLineTime'],' gameTime:',self.gameTime,self.playerList[k]['id'])
				queueNum = self.itemListFilter.heroList[k]:getWaitQueue()
				if queueNum>0 then
					self.itemListFilter.heroList[k]:removeWaitQueue()
					-- self.playerList[k]['online'] = true
					-- self.playerList[k]['offLineTime'] = 0
					self.playerList[k]['offLineTime'] = self.gameTime - self.gameRoomSetting.offlineRemoveWaitTime + 2
				else
					self:D('jaylog WorldBase:checkHeroOffLine removeItem offLineTime:',v['offLineTime'],' gameTime:',self.gameTime,self.playerList[k]['id'])
					local dataTmp = self:memcacheLocalGet('tcphold'..self.playerList[k]['p'])
					dataTmp = self.cjson.decode(dataTmp)
					if dataTmp~=nil and self.tonumber(dataTmp['p'])==self.tonumber(self.gamePort) then
						self:D('srem','onlinePlayer',self.tonumber(self.playerList[k]['p']))
						self:redisCall('srem','onlinePlayer',self.tonumber(self.playerList[k]['p']))
						if self.itemListFilter.heroList[k]:getCustomTeamID()>0 then
							self.itemListFilter.heroList[k]:quitTeamInvite()
						end
					end
					local obj = self.itemListFilter.heroList[k]
					if obj.attribute.roleId==5 or obj.attribute.roleId==10 then
						if obj.CWID~=nil and obj.CWID>0 then
							local cwObj = self.allItemList[obj.CWID]
							if cwObj~=nil then
								cwObj.attribute.HP = 0
								cwObj:directHurt(obj.CWID,1,{})
							end
							self:D('jaylog WorldBase:checkHeroOffLine removeCWobj ',obj.itemID,obj.CWID,cwObj.attribute.roleId)
						end
					end
					self:removeItem(self.itemListFilter.heroList[k])
				end
			end
		end
	end
	if self.gameRoomSetting['ISGVB']==1 then
		for k,v in pairs(self.playerList) do
			-- self:D('jaylog WorldBase:checkHeroOffLine before1 removeItem offLineTime:',v['offLineTime'],' gameTime:',self.gameTime,self.playerList[k]['id'])
			if self.itemListFilter.heroList[k]~=nil and self.itemListFilter.heroList[k]:isAIObj() and not v['online'] and v['offLineTime']~=nil and v['offLineTime']~=0 and (self.gameTime-v['offLineTime'])>self.gameRoomSetting.offlineRemoveWaitTime then
				self:D('jaylog GVB WorldBase:checkHeroOffLine removeItem offLineTime:',v['offLineTime'],' gameTime:',self.gameTime,self.playerList[k]['id'])
				local obj = self.itemListFilter.heroList[k]
				if obj.attribute.roleId==5 or obj.attribute.roleId==10 then
					if obj.CWID~=nil and obj.CWID>0 then
						local cwObj = self.allItemList[obj.CWID]
						if cwObj~=nil then
							cwObj.attribute.HP = 0
							cwObj:directHurt(obj.CWID,1,{})
						end
						self:D('jaylog GVB WorldBase:checkHeroOffLine removeCWobj ',obj.itemID,obj.CWID,cwObj.attribute.roleId)
					end
				end
				self:removeItem(self.itemListFilter.heroList[k])
			end
		end
	end
end

--- 通过roleID找OBJ
-- @param roleID int - 角色ID
-- @return roleList table - 找到的obj列表
function WorldBase:getRoleList(roleID)
	if roleID==nil then
		roleID = 0
	end
	local roleList = {}
	if roleID~=0 then
		if roleID<11 or roleID>1000 then
			for k,v in pairs(self.itemList.heroList) do
				if v.attribute.roleId==roleID then
					roleList[#roleList+1] = v.itemID
				end
			end
		elseif roleID>100 and roleID<1000 then
			for k,v in pairs(self.itemList.soldierList) do
				if v.attribute.roleId==roleID then
					roleList[#roleList+1] = v.itemID
				end
			end
		end
	end
	return roleList
end

--- 如果无法到达战场中的指定点，直接拉那到那一点
-- @param null
-- @return null
function WorldBase:goToSite()
	if self.gameRoomSetting['ISGVB']==1 and self.gameStartTime>0 and self.goToSiteCheckTime<self.gameTime and self.tonumber(self.worldNum)~=2001 then
		local step = 0
		if self.setting['PreventproblemID']~=nil then
			local pos = self.sSplitNumber(self.setting['PreventproblemID'],',')
			for k,v in pairs(self.itemListFilter.heroList) do
				--self:D('jaylog WorldBase:goToSite real before ',self.cjson.encode(pos),v.itemID,v.attribute.roleId,'x',v.posX,'y',v.posY)
				if v.actorType==0 and (v.posX<(pos[1]-2) or v.posX>(pos[1]+2) or v.posY<(pos[2]-2) or v.posY>(pos[2]+2)) then
					local paths = self.map:getPaths(v.posX,v.posY,pos[1],pos[2],0,step)
					--self:D('jaylog WorldBase:goToSite before ',self.cjson.encode(pos),v.itemID,v.attribute.roleId,paths:size(),'x',v.posX,'y',v.posY)
					if paths:size()<=1 then
						self:D('jaylog WorldBase:goToSite hero after ',self.cjson.encode(pos),v.itemID,v.attribute.roleId,paths:size(),'x',v.posX,'y',v.posY)
						if v:isAIObj() then
							if v.stopAITime<self:getGameTime() then
								v:moveTo(pos[1],pos[2],true,10)
								v:setAutoBlocked(false,1.5)
							end
						else
							v:moveTo(pos[1],pos[2],true,1,99999)
						end
					end
				end
			end
			for k,v in pairs(self.itemListFilter.soldierList) do
				--self:D('jaylog WorldBase:goToSite real before ',self.cjson.encode(pos),v.itemID,v.attribute.roleId,'x',v.posX,'y',v.posY)
				if v.attribute.parameterArr['NOMOVEAI']~=nil and not v:isDead() and v.AIlastCoolDown<self:getGameTime() and (v.posX<(pos[1]-2) or v.posX>(pos[1]+2) or v.posY<(pos[2]-2) or v.posY>(pos[2]+2)) then
					local paths = self.map:getPaths(v.posX,v.posY,pos[1],pos[2],0,step)
					--self:D('jaylog WorldBase:goToSite before ',self.cjson.encode(pos),v.itemID,v.attribute.roleId,paths:size(),'x',v.posX,'y',v.posY)
					if paths:size()<=1 then
						self:D('jaylog WorldBase:goToSite enemy after ',self.cjson.encode(pos),v.itemID,v.attribute.roleId,paths:size(),'x',v.posX,'y',v.posY)
						v:moveTo(pos[1],pos[2],true,10)
						v.AIlastCoolDown = self:getGameTime() + 1.5
					end
				end
			end
			self.goToSiteCheckTime = self.gameTime + 1
		else
			if self.gameFlag['goToSiteItemID']==0 then
				for k,v in pairs(self.itemListFilter.noBeFightList) do
					if self.tonumber(v.attribute.roleId)==920 and not v:isDead() then
						self.gameFlag['goToSiteItemID'] = v.itemID
						self:D('jaylog WorldBase:goToSiteItemID itemID:',self.gameFlag['goToSiteItemID'])
					end
				end
			end
			if self.gameFlag['goToSiteItemID']~=0 and self.allItemList[self.gameFlag['goToSiteItemID']]~=nil and not self.allItemList[self.gameFlag['goToSiteItemID']]:isDead() then
				local pos = {self.allItemList[self.gameFlag['goToSiteItemID']].posX,self.allItemList[self.gameFlag['goToSiteItemID']].posY}
				for k,v in pairs(self.itemListFilter.heroList) do
					self:D('jaylog WorldBase:goToSite heroList real before ',self.cjson.encode(pos),v.itemID,v.attribute.roleId,'x',v.posX,'y',v.posY)
					if v.actorType==0 and not v:isDead() and (v.posX<(pos[1]-2) or v.posX>(pos[1]+2) or v.posY<(pos[2]-2) or v.posY>(pos[2]+2)) then
						local paths = self.map:getPaths(v.posX,v.posY,pos[1],pos[2],0,step)
						--self:D('jaylog WorldBase:goToSite before ',self.cjson.encode(pos),v.itemID,v.attribute.roleId,paths:size(),'x',v.posX,'y',v.posY)
						if paths:size()<=1 then
							self:D('jaylog WorldBase:goToSiteItemID hero after ',self.cjson.encode(pos),v.itemID,v.attribute.roleId,paths:size(),'x',v.posX,'y',v.posY)
							if v:isAIObj() then
								if v.stopAITime<self:getGameTime() then
									v:moveTo(pos[1],pos[2],true,10)
									v:setAutoBlocked(false,1.5)
								end
							else
								v:moveTo(pos[1],pos[2],true,10)
							end
							self:D('jaylog WorldBase:goToSiteItemID hero moveTo syncMsg:',self.cjson.encode(v.syncMsg))
						end
					end
					if v.CWID~=nil and v.CWID>0 and v.AIlastCoolDown<self:getGameTime() then
						local obj = self.allItemList[v.CWID]
						local paths = self.map:getPaths(obj.posX,obj.posY,pos[1],pos[2],0,step)
						if paths:size()<=1 then
							obj:moveTo(pos[1],pos[2],true,10)
							obj.AIlastCoolDown = self:getGameTime() + 1.5
							self:D('jaylog WorldBase:goToSiteItemID CWID moveTo syncMsg:',obj.itemID,obj.parent.itemID,self.cjson.encode(obj.syncMsg))
						end
					end
				end
				for k,v in pairs(self.itemListFilter.soldierList) do
					self:D('jaylog WorldBase:goToSite soldierList real before ',self.cjson.encode(pos),v.itemID,v.attribute.roleId,'x',v.posX,'y',v.posY)
					if v.attribute.parameterArr['NOPULLINTO']==nil and not v:isDead() and v.AIlastCoolDown<self:getGameTime() and (v.posX<(pos[1]-2) or v.posX>(pos[1]+2) or v.posY<(pos[2]-2) or v.posY>(pos[2]+2)) then
						local paths = self.map:getPaths(v.posX,v.posY,pos[1],pos[2],0,step)
						--self:D('jaylog WorldBase:goToSite before ',self.cjson.encode(pos),v.itemID,v.attribute.roleId,paths:size(),'x',v.posX,'y',v.posY)
						if paths:size()<=1 then
							self:D('jaylog WorldBase:goToSiteItemID soldierList after ',self.cjson.encode(pos),v.itemID,v.attribute.roleId,paths:size(),'x',v.posX,'y',v.posY)
							v:moveTo(pos[1],pos[2],true,10)
							v.AIlastCoolDown = self:getGameTime() + 1.5 
						end
					end
				end
				self.goToSiteCheckTime = self.gameTime + 1
			end
		end
	end
end

--- 是否可到达安全点
-- @param x int - 起始X
-- @param y int - 起始Y
-- @return result boolean - 是否
function WorldBase:canPass(x,y)
	if (self.setting['PreventproblemID']==nil or self.setting['PreventproblemID']=='') and self.gameFlag['goToSiteItemID']==0 then
		-- self:D('jaylog WorldBase:canPass not savePoint')
		return true
	else
		local step = 0
		if self.setting['PreventproblemID']~=nil and self.setting['PreventproblemID']~='' then
			local pos = self.sSplitNumber(self.setting['PreventproblemID'],',')
			local paths = self.map:getPaths(x,y,pos[1],pos[2],0,step)
			-- self:D('jaylog WorldBase:canPass PreventproblemID ',self.gameFlag['goToSiteItemID'],self.cjson.encode(pos),self.cjson.encode(paths),x,y)
			if paths:size()<=1 then
				return false
			end
		end
		if self.gameFlag['goToSiteItemID']~=0 and self.allItemList[self.gameFlag['goToSiteItemID']]~=nil and not self.allItemList[self.gameFlag['goToSiteItemID']]:isDead() then
			local pos = {self.allItemList[self.gameFlag['goToSiteItemID']].posX,self.allItemList[self.gameFlag['goToSiteItemID']].posY}
			local paths = self.map:getPaths(x,y,pos[1],pos[2],0,step)
			-- self:D('jaylog WorldBase:canPass goToSiteItemID ',self.gameFlag['goToSiteItemID'],self.cjson.encode(pos),self.cjson.encode(paths),x,y)
			if paths:size()<=1 then
				return false
			end
		end
	end
	return true
end

--- 取两点是否可达到
-- @param fromX int - 起始X
-- @param fromY int - 起始Y
-- @param toX int - 目标X
-- @param toY int - 目标Y
-- @param mode int - 模式 0=只做判断，1=找最近一点
function WorldBase:notPass(fromX,fromY,toX,toY,mode)
	if mode==nil then
		mode = 0
	end
	local x,y = 0,0
	if fromX~=toX and fromY~=toY then
		if mode==0 then
			local step = 0
			local paths = self.map:getPaths(math.floor(fromX+0.5),math.floor(fromY+0.5),math.floor(toX+0.5),math.floor(toY+0.5),10,step)
			if paths:size()<=1 then
				return true,fromX,fromY
			end
		else
			local ret,x,y = findPointStraightLineNeares(fromX,fromY,toX,toY)
			self:D('jaylog WorldBase:notPass',ret,x,y)
			if not ret then
				return true,fromX,fromY
			else
				return ret,x,y
			end
		end
	end
	return false,toX,toY
end

--- 通过别名找obj
-- @param subName string - 别名
-- @param objList obj - 需要找此别名的对象列表
-- @param fuzzy boolean - 模糊查询
-- @return itemObj obj - 返回的对象
function WorldBase:getObjBySubName(subName,objList,fuzzy)
	if objList==nil then
		objList = self.allItemList
	end
	if fuzzy==nil then
		fuzzy = false
	end
	for k,v in pairs(objList) do
		-- self:D('jaylog WorldBase:getObjBySubName ',v.attribute.roleId,v.subName,subName)
		if fuzzy then
			if self.sFind(subName,'BOSS')~=nil then
				if self.sFind(v.subName,subName)~=nil and v.actorType==2 then
					return v
				end
			else
				if self.sFind(v.subName,subName)~=nil then
					return v
				end
			end
		else
			if self.sFind(subName,'BOSS')~=nil then
				if v.subName==subName and v.actorType==2 then
					return v
				end
			else
				if v.subName==subName then
					return v
				end
			end
		end
	end
end

function WorldBase:createTmpHero()
	local bnum = 1
	local numYH,numNP = 1,6
	local id = '01'
	local maxNum = self.tonumber(self.setting['worldAINumYH'])
	-- if self.tonumber(self.mapModel)==103 then
	-- 	maxNum = 10
	-- end
	for bnum=1,maxNum do
		local idx = self:getHeroItemID()
		if numYH<10 then
			id = '0'..numYH
		else
			id = ''..numYH
		end
		local randLv = self:getHeroAIRandomLevel()
		-- if self.tonumber(self.mapModel)==103 then
		-- 	randLv = 60
		-- end
		local hero = self:createHeroAI(numYH,randLv,nil,idx)
		-- if self.tonumber(self.mapModel)==103 then
		-- 	hero:setAuto(false)
		-- end
		self.genTmpHero[#self.genTmpHero+1] = {itemID=hero.itemID,roleID=numYH}
		if numYH==5 then
			numYH = 1
		else
			numYH = numYH + 1
		end
	end
	local maxNum = self.tonumber(self.setting['worldAINumNP'])
	-- if self.tonumber(self.mapModel)==103 then
	-- 	maxNum = 0
	-- end
	for bnum=1,maxNum do
		local idx = self:getHeroItemID()
		if numNP<10 then
			id = '0'..numNP
		else
			id = ''..numNP
		end
		local randLv = self:getHeroAIRandomLevel()
		local hero = self:createHeroAI(numNP,randLv,nil,idx)
		self.genTmpHero[#self.genTmpHero+1] = {itemID=hero.itemID,roleID=numNP}
		if numNP==10 then
			numNP = 6
		else
			numNP = numNP + 1
		end
	end
	self:D('jaylog genTmpHero:',self.cjson.encode(self.genTmpHero))
	self.genTmpHeroTime = self.gameTime
end

function WorldBase:reviveTmpHero()
	for k,v in pairs(self.genTmpHero) do
		if self.itemListFilter.heroList[v['itemID']]==nil and self.reviveTmpHeroTime<self.gameTime then
			-- self:D('jaylog reviveTmpHero1 ',self.cjson.encode(self.genTmpHero))
			local randLv = self:getHeroAIRandomLevel()
			local hero = self:createHeroAI(v['roleID'],randLv)
			self.genTmpHero[k] = {itemID=hero.itemID,roleID=v['roleID']}
			self.reviveTmpHeroTime = self.gameTime + self.formula:getRandnum(1,3)
			-- self:D('jaylog reviveTmpHero2 ',self.cjson.encode(self.genTmpHero))
		end
	end
end

--- 创建野外小怪
-- @param v table - 小怪的信息
-- @return null
function WorldBase:createYWEnemy(v)
	local x,y = self:getRandomEnemyXY(v['groupID'])
	local isb = self.map:isBlockF(v['posX']+x,v['posY']+y)
	--判断点可以放不
	while isb==true do
		x,y = self:getRandomEnemyXY(v['groupID'])
		isb = self.map:isBlockF(v['posX']+x,v['posY']+y)
		--self:D("isb :"..(isb and "true" or "false"))
	end

	--self:D("createYWEnemy type:"..v['type'].." posX:"..v['posX'].." posY:"..v['posY'].." team:"..v['team'].." group:"..v['group'])
	local itemID = self:addMonster(v['type'],v['posX']+x,v['posY']+y,v['group'],1,v['team']) 
	if self.getMonsterIDInGroup[v['group']]==nil then
		self.getMonsterIDInGroup[v['group']] = {}
	end
	if self.HatredGrouplist[v['group']]==nil then
		self.HatredGrouplist[v['group']]={}
	end
	--仇恨分组
	local obj = self.allItemList[itemID]
	obj.Hatredlist = self.HatredGrouplist[v['group']]
	
	self.getMonsterIDInGroup[v['group']][#self.getMonsterIDInGroup[v['group']]+1] = {itemID=itemID}
end

--- 通过genYWMonster循环创建小怪
-- @param null
-- @return null
function WorldBase:createYWAllEnemy()
	--self:D("createYWEnemy list:"..self.cjson.encode(self.genYWMonster))
	for k,v in pairs(self.genYWMonster) do
		self:createYWEnemy(v)
	end 
end

--- 通过genYWMonster循环重生小怪
-- @param group string - 小怪的组
-- @return null
function WorldBase:reviveYWAllEnemy(group)
	for k,v in pairs(self.genMonsterInGroup[group]) do
		--if v['group']==group then
			self:createYWEnemy(v)
		--end
	end 
end

--- 创建野外BOSS
-- @param v table - boss的信息
-- @return null
function WorldBase:createYWBoss(v)
	local x,y = self:getRandomBossXY(v['groupID'])
	local isb = self.map:isBlockF(v['posX']+x,v['posY']+y)
	--判断点可以放不
	while isb==true do
		x,y = self:getRandomBossXY(v['groupID'])
		isb = self.map:isBlockF(v['posX']+x,v['posY']+y)
		--self:D("isb :"..(isb and "true" or "false"))
	end

	--self:D("createYWBoss type:"..v['type'].." posX:"..v['posX'].." posY:"..v['posY'].." team:"..v['team'].." group:"..v['group'])
	local obj = self:addBoss(v['type'],'','Boss',v['posX']+x,v['posY']+y) 
	--local obj=self:addBoss(1004,'',"造梦者5人（P3)",120,70,3)
	if self.getBossIDInGroup[v['group']]==nil then
		self.getBossIDInGroup[v['group']] = {}
	end
	if self.HatredGrouplist[v['group']]==nil then
		self.HatredGrouplist[v['group']]={}
	end
	--self:D("createYWBoss itemID:"..itemID)
	--仇恨分组
	-- local obj = self.allItemList[itemID]
	obj.Hatredlist = self.HatredGrouplist[v['group']]
	
	self.getBossIDInGroup[v['group']][#self.getBossIDInGroup[v['group']]+1] = {itemID=obj.itemID}
end

--- 通过genYWBoss循环创建野外BOSS
-- @param null
-- @return null
function WorldBase:createYWAllBoss()
	--self:D("createYWEnemy list:"..self.cjson.encode(self.genYWBoss))
	for k,v in pairs(self.genYWBoss) do
		self:createYWBoss(v)
	end 
end

--- 通过genYWBoss循环重生野外BOSS
-- @param null
-- @return null
function WorldBase:reviveYWAllBoss(group)
	for k,v in pairs(self.genBossInGroup[group]) do
		--if v['group']==group then
			self:createYWBoss(v)
		--end
	end 
end

--- 生成独立野外怪
-- @param null
-- @return null
function WorldBase:createYWEnemyAlone(v)
	--self:D("createYWEnemyAlone v:"..self.cjson.encode(v))
	local x,y = self:getRandomEnemyAloneXY(v['groupID'])
	local isb = self.map:isBlockF(v['posX']+x,v['posY']+y)
	--判断点可以放不
	while isb==true do
		x,y = self:getRandomEnemyAloneXY(v['groupID'])
		isb = self.map:isBlockF(v['posX']+x,v['posY']+y)
		--self:D("isb :"..(isb and "true" or "false").." X:"..(v['posX']+x).." Y:"..(v['posY']+y))
	end

	local itemID = self:addMonster(v['type'],v['posX']+x,v['posY']+y,v['group'],1,v['team']) 
	--self:D("createYWEnemyAlone type:"..v['type'].." posX:"..v['posX']+x.." posY:"..v['posY']+y.." team:"..v['team'].." group:"..v['group'])
	if self.genEnemyAloneIDInGroup[v['group']]==nil then
		self.genEnemyAloneIDInGroup[v['group']] = {}
	end
	if self.HatredGrouplist[v['group']]==nil then
		self.HatredGrouplist[v['group']]={}
	end
	self.genEnemyAloneIDInGroup[v['group']][#self.genEnemyAloneIDInGroup[v['group']]+1] = {itemID=itemID}
end

--- 根据genYWEnemyAlone生成独立野外怪
-- @param null
-- @return null
function WorldBase:createYWAllEnemyAlone()
	local I=0
	for k,v in pairs(self.genYWEnemyAlone) do
		self:createYWEnemyAlone(v)
		I = I+1
	end 
end

--- 重生独立野外怪
-- @param group table - 重生小怪的组的信息
-- @return null
function WorldBase:reviveYWAllEnemyAlone(group)
	self:createYWEnemyAlone(self.genEnemyAloneInGroup[group][1])
end

function WorldBase:getRandomEnemyAloneXY(groupID)
	local settingLocal = self.setting
	local enemy1Typelist = string.split(settingLocal["enemyAlone"..groupID.."Type"],',')
	local x,y = self.formula:getRandomCirclePoint(0,0,enemy1Typelist[3]*0.01)
	--self:D("getRandomEnemyAloneXY x:"..x.." y:"..y)
	return x,y
end

function WorldBase:getRandomBossXY(groupID)
	local settingLocal = self.setting
	local enemy1Typelist = string.split(settingLocal["boss"..groupID.."Type"],',')
			--randlist = self.formula:formationPoint(enemyAllNum,enemy1Typelist[3]*0.01)
	local x,y = self.formula:getRandomCirclePoint(0,0,enemy1Typelist[3]*0.01)
	--self:D("getRandomBossXY x:"..x.." y:"..y)
	return x,y
end

function WorldBase:getRandomEnemyXY(groupID)
	local settingLocal = self.setting
	local enemy1Typelist = string.split(settingLocal["enemy"..groupID.."Type"],',')
	local x,y = self.formula:getRandomCirclePoint(0,0,enemy1Typelist[3]*0.01)
	--self:D("getRandomEnemyXY x:"..x.." y:"..y)
	return x,y
end


function WorldBase:createYWAllNPC()
	self:D("createYWAllNPC list:"..self.cjson.encode(self.genYWNPC))
	for k,v in pairs(self.genYWNPC) do
		self:createYWNPC(v)
	end 
end

function WorldBase:createYWNPC(v)
	self:D("createYWNPC type:"..v['type'].." posX:"..v['posX'].." posY:"..v['posY'].." team:"..v['team'].." group:"..v['group'])
	local itemID = self:addNPC(v['type'],v['team'],v['posX'],v['posY'],nil,1,0.2)
	local obj = self.allItemList[itemID] 
	if v['standPoint']~=nil then
		obj.attribute.STANDPOINT = self.tonumber(v['standPoint'])
		obj.syncMsg['i']['jd'] = self.tonumber(v['standPoint'])
	end
	obj:addTaskBuff()
end

--- sync game中的star信息给前端
-- @param null
-- @return null
function WorldBase:syncGameInfo()
	if self.gameRoomSetting['ISGVB']==1 and self.gameRoomInfo['worldSubMode']==0 then
		local isSyn = false
		if not self.gameFlag['star1del'] and (self.gameTime-self.gameStartTime)>self.gameRoomInfo['delStarTime'] then
			-- self:setGameCounter('timeStar',-1)
			self.gameFlag['star1del'] = true
		end
		-- if not self.gameFlag['star2del'] then
		-- 	for k,v in pairs(self.itemListFilter.heroList) do
		-- 		if v.actorType==0 and v:isDead() and not self.gameFlag['star2del'] then
		-- 			self:setGameCounter('star',-1)
		-- 			self.gameFlag['star2del'] = true
		-- 			local gameInfo = {
		-- 				star=self.gameCounter['star'],
		-- 			}
		-- 			self:addSyncMsg({game=gameInfo})
		-- 		end
		-- 	end
		-- end
		local deadNum = 0
		for k,v in pairs(self.itemListFilter.heroList) do
			if v.actorType==0 then
				if v:isDead() then
					deadNum = deadNum + 1
				end
			end
		end
		if deadNum==1 then
			if self.gameCounter['deadStar']==2 then
				self.gameCounter['deadStar'] = 1
				isSyn = true
			elseif self.gameCounter['deadStar']==0 then
				self.gameCounter['deadStar'] = 1
				isSyn = true
			end
		elseif deadNum>=2 then
			if self.gameCounter['deadStar']>0 then
				self.gameCounter['deadStar'] = 0
				isSyn = true
			end
		elseif deadNum==0 then
			if self.gameCounter['deadStar']<2 then
				self.gameCounter['deadStar'] = 2
				isSyn = true
			end
		end
		if isSyn then
			self.gameCounter['star'] = self.gameCounter['timeStar'] + self.gameCounter['deadStar']
			local gameInfo = {
				star=self.gameCounter['star'],
			}
			self:addSyncMsg({game=gameInfo})
		end
	end
end

--- sync game中的star信息给前端选定地方触发
-- @param null
-- @return null
function WorldBase:syncGameInfoOnece()
	if self.gameRoomSetting['ISYW']==0 then
		local teamAID = {}
		local teamBID = {}
		local gameInfo = {d=0,msize=5}
		for k,v in pairs(self.itemListFilter.heroList) do
			if v.actorType==0 and v.teamOrig=='A' and v.parent==nil and (v.isSmallAI==nil or not v.isSmallAI) then
				teamAID[#teamAID+1] = k
			end
			if v.actorType==0 and v.teamOrig=='B' and v.parent==nil and (v.isSmallAI==nil or not v.isSmallAI) then
				teamBID[#teamBID+1] = k
			end
		end
		if not empty(teamAID) then
			gameInfo['teamAID'] = teamAID
		end
		if not empty(teamBID) then
			gameInfo['teamBID'] = teamBID
		end
		self:addSyncMsg({game=gameInfo})
	end
end

--- 按目標類型 執行itemList loop function call
-- @param targetType int - 目標類型取  /// 0=所有hero,1=敵兵&hero,2=敵hero,3=自身,4=隊友hero,5＝所有隊友，6=敵兵&hero&塔，7=敵塔,8=所有東西除了塔,10=所有東西除了塔+自己
-- @param team char - 施放者team
-- @param thisID int - 施放者itemID
-- @param options table - 參數 {notIncludeSelf=不包括自己,isSelfTeam=只限友方,notIncludeSelfSoldier=不包括友方士兵,includeTower=包括塔}
-- @param func function - 每個itemObj loop function call , 第一個參數為 object
-- @param ... 參數，使入function call
-- @return nil
-- @usage local targetList = {}
-- @usage local missTargetList = {}
-- @usage self.world:runTargetTypeFilter(1,self.team,self.itemID,{},function(obj,a,b,c)
-- @usage 	if obj.attribute.HP>1000 then
-- @usage 		obj:directHurt(self.itemID,1,{finalFixHurt=a+b},0)
-- @usage 		targetList[#targetList+1] = obj.itemID
-- @usage 	else
-- @usage 		c[#c+1] = obj.itemID
-- @usage 	end
-- @usage end
-- @usage ,1,2,c)
function WorldBase:runTargetTypeFilter(targetType,team,thisID,options,func,...)
	local enemy = {}
	local enemy2 = {}
	if options==nil then options={} end
	options['notIncludeSelf']=false
	options['isSelfTeam']=false
	options['notIncludeSelfSoldier']=false
	options['includeTower']=false
	if targetType=="C" then
		enemy = self.itemListFilter.soldierList
	elseif targetType=="A" then
		enemy = self.itemListFilter.teamAMemberList
	elseif targetType=="B" then
		enemy = self.itemListFilter.teamBMemberList
	elseif targetType==0 then
		enemy = self.itemListFilter.heroList
		options['isSelfTeam'] = nil
	elseif targetType==1 then
		options['notIncludeSelf'] = true
		if team=="" then
			enemy = self.itemListFilter.teamABMemberList
		elseif team=="B" then
			enemy = self.itemListFilter.teamA
		else
			enemy = self.itemListFilter.teamB
		end
	elseif targetType==2 then
		options['notIncludeSelf'] = true
		if team=="" then
			local heroTeamABList = table.deepcopy(self.itemListFilter.heroTeamAList)
			table.merge(heroTeamABList,self.itemListFilter.heroTeamBList)
			enemy = heroTeamABList
		elseif team=="B" then
			enemy = self.itemListFilter.heroTeamAList
		else
			enemy = self.itemListFilter.heroTeamBList
		end
	elseif targetType==3 then
		enemy = {}
		enemy[thisID] = self.allItemList[thisID]
	elseif targetType==4 then
		options['isSelfTeam'] = true
		if team=="" then
			enemy = self.itemListFilter.teamCMemberList
		elseif team=="B" then
			enemy = self.itemListFilter.heroTeamBList
		else
			enemy = self.itemListFilter.heroTeamAList
		end
	elseif targetType==5 then
		options['isSelfTeam'] = true
		if team=="" then
			enemy = self.itemListFilter.teamCMemberList
		elseif team=="B" then
			enemy = self.itemListFilter.teamBMemberList
		else
			enemy = self.itemListFilter.teamAMemberList
		end
	elseif targetType==6 then
		options['notIncludeSelf'] = true
		options['includeTower'] = true
		if team=="" then
			local heroTeamABList = table.deepcopy(self.itemListFilter.heroTeamAList)
			table.merge(heroTeamABList,self.itemListFilter.heroTeamBList)
			enemy = heroTeamABList
		elseif team=="B" then
			enemy = self.itemListFilter.teamA
		else
			enemy = self.itemListFilter.teamB
		end
	elseif targetType==7 then
		options['notIncludeSelf'] = true
		if team=="B" then
			enemy = self.itemListFilter.towerAList
		else
			enemy = self.itemListFilter.towerBList
		end
	elseif targetType==8 then
		options['notIncludeSelf'] = true
		enemy = self.allItemList
		options['isSelfTeam'] = nil
	elseif targetType==9 then
		options['notIncludeSelf'] = true
		options['notIncludeSelfSoldier'] = true
		enemy = self.allItemList
		options['isSelfTeam'] = nil
	elseif targetType==10 then
		enemy = self.allItemList
		options['isSelfTeam'] = nil
	-- elseif targetType==11 then
	-- 	options['notIncludeSelf'] = true
	-- 	enemy = self.itemListFilter.teamCMemberList
	-- elseif targetType==12 then
	-- 	options['notIncludeSelf'] = true
	-- 	enemy = self.itemListFilter.teamABMemberList
	--
	elseif targetType==11 then
		--搜索到拥有不可被攻击的人
		if team=="" then
			enemy = self.itemListFilter.teamCMemberList
		elseif team=="B" then
			enemy = self.itemListFilter.heroTeamBList
		else
			enemy = self.itemListFilter.heroTeamAList
		end

		if team=="" then
			enemy2 = self.itemListFilter.noBeFightTeamC
		elseif team=="B" then
			enemy2 = self.itemListFilter.noBeFightTeamB
		else
			enemy2 = self.itemListFilter.noBeFightTeamA
		end
	elseif targetType==14 then
		--找队友不包括自己
		options['notIncludeSelf'] = true
		options['isSelfTeam'] = true
		if team=="" then
			enemy = self.itemListFilter.teamCMemberList
		elseif team=="B" then
			enemy = self.itemListFilter.teamBMemberList
		else
			enemy = self.itemListFilter.teamAMemberList
		end
	end
	for k,vv in pairs(enemy) do
		if vv:isDead() or
			(options['notIncludeSelf']==true and vv.itemID==thisID) or
			(options['isSelfTeam']==true and vv.team~=team) or
			(options['isSelfTeam']==false and vv.team==team) or
			-- (vv.className=="STower" and not options['includeTower']) or
			(vv.attribute.parameterArr~=nil and vv.attribute.parameterArr["NOBEFIGHT"]~=nil) or
			(options['notIncludeSelfSoldier']==true and vv.team==team and vv.attribute.actorType==1) or
			(self.itemListFilter.noBeFightBuffList[""..vv.itemID]~=nil) or 
			(vv.statusList~=nil and (vv.statusList[73]~=nil or vv.statusList[76]~=nil))

		then
			-- nothing to do
		else
			func(vv,...)
		end
	end


	for k,vv in pairs(enemy2) do
		if vv:isDead() 
			--or
			-- (options['notIncludeSelf']==true and vv.itemID==thisID) or
			-- (options['isSelfTeam']==true and vv.team~=team) or
			-- (options['isSelfTeam']==false and vv.team==team) or
			-- -- (vv.className=="STower" and not options['includeTower']) or
			-- (vv.attribute.parameterArr~=nil and vv.attribute.parameterArr["NOBEFIGHT"]~=nil) or
			-- (options['notIncludeSelfSoldier']==true and vv.team==team and vv.attribute.actorType==1) or
			-- (self.itemListFilter.noBeFightBuffList[""..vv.itemID]~=nil)

		then
			-- nothing to do
		else
			func(vv,...)
		end
	end


end

--- 获取mapModel对应AI数据
-- @param mID integer - 地图ID
-- @param roleID integer - 角色ID
-- @param level integer - 级别
-- @param team string - 队伍 A/B
-- @return AIData table - 获取所得的AIData,json格式
function WorldBase:getAIData(mID,roleID,level,team)
	-- self:D('jaylog getAIData ',mID,roleID,level,team)
	local id,lv,tm,AIID = '','','',''
	if self.tonumber(roleID)<10 then
		id = '0'..roleID
	else
		id = roleID
	end
	if self.tonumber(level)<10 then
		lv = '0'..level
	else
		lv = level
	end
	local noTeam = false
	for k,v in pairs(self.gameRoomSetting['loadNoTeamAIWorld']) do
		if self.tonumber(self.mapModel)==v then
			noTeam = true
		end
	end
	if team==nil or noTeam then
		tm = '00'
	elseif team=='A' then
		tm = '01'
	elseif team=='B' then
		tm = '02'
	end
	local roomLv = self.mFloor(self.gameRoomInfo['openLv']*0.1)
	local sql,sql2,sql3,sql4 = '','','',''
	sql = "select * from z_AIData_"..level.." where ID='"..mID..tm..id..lv.."'"
	local data = self:getDBData(sql)
	AIID = mID..tm..id..lv
	self:D('jaylog getAIData data ',empty(data),self.tNums(data),self.cjson.encode(data))
	if data==nil or empty(data) or self.tNums(data)==0 then
		sql2 = "select * from z_AIData_"..level.." where ID='"..'9999'..tm..id..lv.."'"
		data = self:getDBData(sql2)
		AIID = '9999'..tm..id..lv
		-- if data==nil or empty(data) or self.tNums(data)==0 then
		-- 	sql3 = "select * from AIdata where ID='"..mID..tm..id..lv.."'"
		-- 	data = self:getDBData(sql3)
		-- 	if data==nil or empty(data) or self.tNums(data)==0 then
		-- 		sql4 = "select * from AIdata where ID='"..'9999'..tm..id..lv.."'"
		-- 		data = self:getDBData(sql4)
		-- 		-- self:D('jaylog getAIData1 data ',sql,sql2,self.cjson.encode(data))
		-- 		-- if data==nil or empty(data) or self.tNums(data)==0 then
		-- 		-- 	local sql3 = "select * from AIdata where ID='"..'9990'..id.."01'"
		-- 		-- 	data = self:getDBData(sql3)
		-- 		-- end
		-- 	end
		-- end
	end
	self:D('jaylog WorldBase:getAIData data ',sql,sql2,sql3,sql4,self.cjson.encode(data))
	for k,v in pairs(data) do
		-- self:D('jaylog getAIData ret data ',sql,sql2,self.cjson.encode(v['JSONDATA']))
		return v['JSONDATA'],AIID
	end
end

--- 增加AI英雄
-- @param null
-- @return null
function WorldBase:addHeroAI()
	if self.gameRoomSetting['AIMaxPlayer']>0 then
		self.gameRoomSetting['maxPlayer'] = self.gameRoomSetting['maxPlayer'] + self.gameRoomSetting['AIMaxPlayer']
	end
	if self.gameRoomSetting['ISGVB']==1 and (self.gameRoomSetting['maxPlayer']>=3 and self.gameRoomSetting['maxPlayer']<=8) then 
		local roleList,addList = {},{}
		local sum = 0
		local IDs = {}
		local team = ''
		local loginID = ''
		local itemID = 0
		local school1,school2 = 0,0
		local roleID = 0
		for k,v in pairs(self.itemListFilter.heroList) do
			if v.actorType==0 then
				-- sum = sum + 1
				-- roleID = self.tonumber(v.attribute.roleId)
				-- if roleID>5 then
				-- 	IDs[""..(roleID-5)] = 1
				-- 	IDs[""..roleID] = 1
				-- else
				-- 	IDs[""..roleID] = 1
				-- 	IDs[""..(roleID+5)] = 1
				-- end
				-- team = v.teamOrig
				-- loginID = v.loginID
				-- itemID = v.itemID
				-- if self.tonumber(self.playerList[1]['playerJson']['Player']['school'])==1 then
				-- 	school1 = school1 + 1
				-- else
				-- 	school2 = school2 + 1
				-- end
				-- --self:D('jaylog addAIhero itemID ',itemID,loginID)
				roleList[#roleList+1] = {self.tonumber(v.attribute.roleId),v.attribute.school,v.team,v.attribute.level}
			end
		end
		-- self:D('jaylog sum',sum,self.gameRoomSetting['maxPlayer'])
		-- if sum<self.gameRoomSetting['maxPlayer'] then
			-- local addNum = self.gameRoomSetting['maxPlayer'] - sum
			-- local mustID,mustIDTmp,lotteryIDTmp,lotteryID = {},{},{},{}
			-- if school1>=school2 then
			-- 	mustIDTmp = self.sSplitNumber(self.setting['AIfixedYH'],',')
			-- 	lotteryIDTmp = self.sSplitNumber(self.setting['AIrandomYH'],',')
			-- 	for k,v in pairs(mustIDTmp) do
			-- 		if IDs[''..v]==nil then
			-- 			mustID[#mustID+1] = v
			-- 		end
			-- 	end
			-- 	for k,v in pairs(lotteryIDTmp) do
			-- 		if IDs[''..v]==nil then
			-- 			lotteryID[#lotteryID+1] = v
			-- 		end
			-- 	end
			-- else
			-- 	mustIDTmp = self.sSplitNumber(self.setting['AIfixedNP'],',')
			-- 	lotteryIDTmp = self.sSplitNumber(self.setting['AIrandomNP'],',')
			-- 	for k,v in pairs(mustIDTmp) do
			-- 		if IDs[''..v]==nil then
			-- 			mustID[#mustID+1] = v
			-- 		end
			-- 	end
			-- 	for k,v in pairs(lotteryIDTmp) do
			-- 		if IDs[''..v]==nil then
			-- 			lotteryID[#lotteryID+1] = v
			-- 		end
			-- 	end
			-- end
			-- self:D('jaylog ID',self.cjson.encode(mustID),self.cjson.encode(lotteryID))
			-- for k,v in pairs(mustID) do
			-- 	if addNum>0 then
			-- 		if IDs[""..v]==nil then
			-- 			-- local idx = self:getHeroItemID()
			-- 			local id = '01'
			-- 			if v<10 then
			-- 				id = '0'..v
			-- 			else
			-- 				id = ''..v
			-- 			end
			-- 			local lv = self:getHeroAIRandomLevel()
			-- 			self:createHeroAI(v,lv,team)
			-- 		end
			-- 		addNum = addNum - 1
			-- 	end
			-- end
			-- if addNum>0 and not empty(lotteryID) then
			-- 	for i=1,addNum do
			-- 		local ridx = 1
			-- 		if addNum==1 and self.gameRoomSetting['maxPlayer']==3 then
			-- 			ridx = self.formula:getRandnum(1,#lotteryID)
			-- 		else
			-- 			ridx = i
			-- 		end
			-- 		if ridx>#lotteryID then
			-- 			ridx = ridx - #lotteryID
			-- 		end
			-- 		--如果相减后还大过lotteryID则直接取lotteryID
			-- 		if ridx>#lotteryID then
			-- 			ridx = #lotteryID
			-- 		end
			-- 		-- local idx = self:getHeroItemID()
			-- 		local id = '01'
			-- 		if lotteryID[ridx]<10 then
			-- 			id = '0'..lotteryID[ridx]
			-- 		else
			-- 			id = ''..lotteryID[ridx]
			-- 		end
			-- 		local lv = self:getHeroAIRandomLevel()
			-- 		self:createHeroAI(lotteryID[ridx],lv,team)
			-- 	end
			-- end
		-- end
		if self.gameRoomSetting['AIMaxPlayer']>0 then
			self.gameRoomSetting['maxPlayer'] = self.gameRoomSetting['maxPlayer'] - self.gameRoomSetting['AIMaxPlayer']
		end
		addList = self:getAIInfo(roleList)
		for k,v in pairs(addList) do
			self:createHeroAI(v['rid'],v['lv'],v['team'])
		end
		self:syncGameInfoOnece()
	end
	local genAI = false
	for k,v in pairs(self.gameRoomSetting['genAIPVPWorld']) do
		if self.tonumber(self.mapModel)==v then
			genAI = true
		end
	end
	if self.gameRoomSetting['ISPVP']==1 and genAI then
		local roleList,addList = {},{}
		local sum1,sum2 = 0,0
		local IDs1,IDs2 = {},{}
		local team1,team2 = 'B','A'
		local loginID = ''
		local itemID1 = 0
		local itemID2 = 0
		local minLv,maxLv = 0,0
		local randLv = 0
		for k,v in pairs(self.itemListFilter.heroList) do
			if v.actorType==0 and v.parent==nil then
				-- -- if self.playerList[k]['playerJson']['Player']['school']==1 then
				-- if v.teamOrig=='B' then
				-- 	sum1 = sum1 + 1
				-- 	IDs1[""..v.attribute.roleId] = 1
				-- 	--team1 = v.teamOrig
				-- 	loginID1 = v.loginID
				-- 	itemID1 = v.itemID
				-- 	self:D('jaylog addAIhero PVP1 itemID ',itemID1,loginID1)
				-- 	if minLv==0 or minLv>v.attribute.level then
				-- 		minLv = v.attribute.level
				-- 	end
				-- 	if maxLv==0 or maxLv<v.attribute.level then
				-- 		maxLv = v.attribute.level
				-- 	end
				-- end
				-- -- if self.playerList[k]['playerJson']['Player']['school']==2 then
				-- if v.teamOrig=='A' then
				-- 	sum2 = sum2 + 1
				-- 	IDs2[""..v.attribute.roleId] = 1
				-- 	--team2 = v.teamOrig
				-- 	loginID2 = v.loginID
				-- 	itemID2 = v.itemID
				-- 	self:D('jaylog addAIhero PVP2 itemID ',itemID2,loginID2)
				-- 	if minLv==0 or minLv>v.attribute.level then
				-- 		minLv = v.attribute.level
				-- 	end
				-- 	if maxLv==0 or maxLv<v.attribute.level then
				-- 		maxLv = v.attribute.level
				-- 	end
				-- end
				roleList[#roleList+1] = {self.tonumber(v.attribute.roleId),v.attribute.school,v.team,v.attribute.level}
			end
		end
		-- self:D('jaylog sum',sum1,sum2,self.gameRoomSetting['maxPlayer'],minLv,maxLv)
		-- if sum1<(self.gameRoomSetting['maxPlayer']*0.5) then
			-- local addNum = (self.gameRoomSetting['maxPlayer']*0.5) - sum1
			-- local mustID,mustIDTmp,lotteryIDTmp,lotteryID = {},{},{},{}
			-- mustIDTmp = self.sSplitNumber(self.setting['AIfixedYH'],',')
			-- lotteryIDTmp = self.sSplitNumber(self.setting['AIrandomYH'],',')
			-- -- 临时处理 start
			-- -- mustIDTmp = self.sSplitNumber(self.setting['AIfixedNP'],',')
			-- -- lotteryIDTmp = self.sSplitNumber(self.setting['AIrandomNP'],',')
			-- -- 临时处理 end
			-- for k,v in pairs(mustIDTmp) do
			-- 	if IDs1[''..v]==nil then
			-- 		mustID[#mustID+1] = v
			-- 	end
			-- end
			-- for k,v in pairs(lotteryIDTmp) do
			-- 	if IDs1[''..v]==nil then
			-- 		lotteryID[#lotteryID+1] = v
			-- 	end
			-- end
			-- self:D('jaylog ID',self.cjson.encode(mustID),self.cjson.encode(lotteryID),addNum)
			-- for k,v in pairs(mustID) do
			-- 	if addNum>0 then
			-- 		if IDs1[""..v]==nil then
			-- 			randLv = self.formula:getRandnum(minLv,maxLv)
			-- 			-- local idx = self:getHeroItemID()
			-- 			local id = '01'
			-- 			if v<10 then
			-- 				id = '0'..v
			-- 			else
			-- 				id = ''..v
			-- 			end
			-- 			self:createHeroAI(v,randLv,team1)
			-- 		end
			-- 		addNum = addNum - 1
			-- 	end
			-- end
			-- if addNum>0 and not empty(lotteryID) then
			-- 	for i=1,addNum do
			-- 		randLv = self.formula:getRandnum(minLv,maxLv)
			-- 		local ridx = i
			-- 		-- local idx = self:getHeroItemID()
			-- 		local id = '01'
			-- 		if lotteryID[ridx]<10 then
			-- 			id = '0'..lotteryID[ridx]
			-- 		else
			-- 			id = ''..lotteryID[ridx]
			-- 		end
			-- 		self:createHeroAI(lotteryID[ridx],randLv,team1)
			-- 	end
			-- end
		-- end
		-- if sum2<(self.gameRoomSetting['maxPlayer']*0.5) then
			-- local addNum = (self.gameRoomSetting['maxPlayer']*0.5) - sum2
			-- local mustID,mustIDTmp,lotteryIDTmp,lotteryID = {},{},{},{}
			-- mustIDTmp = self.sSplitNumber(self.setting['AIfixedNP'],',')
			-- lotteryIDTmp = self.sSplitNumber(self.setting['AIrandomNP'],',')
			-- for k,v in pairs(mustIDTmp) do
			-- 	if IDs2[''..v]==nil then
			-- 		mustID[#mustID+1] = v
			-- 	end
			-- end
			-- for k,v in pairs(lotteryIDTmp) do
			-- 	if IDs2[''..v]==nil then
			-- 		lotteryID[#lotteryID+1] = v
			-- 	end
			-- end
			-- self:D('jaylog ID',self.cjson.encode(mustID),self.cjson.encode(lotteryID))
			-- for k,v in pairs(mustID) do
			-- 	if addNum>0 then
			-- 		if IDs2[""..v]==nil then
			-- 			randLv = self.formula:getRandnum(minLv,maxLv)
			-- 			-- local idx = self:getHeroItemID()
			-- 			local id = '01'
			-- 			if v<10 then
			-- 				id = '0'..v
			-- 			else
			-- 				id = ''..v
			-- 			end
			-- 			self:createHeroAI(v,randLv,team2)
			-- 		end
			-- 		addNum = addNum - 1
			-- 	end
			-- end
			-- if addNum>0 and not empty(lotteryID) then
			-- 	for i=1,addNum do
			-- 		randLv = self.formula:getRandnum(minLv,maxLv)
			-- 		local ridx = i
			-- 		local idx = self:getHeroItemID()
			-- 		local id = '01'
			-- 		if lotteryID[ridx]<10 then
			-- 			id = '0'..lotteryID[ridx]
			-- 		else
			-- 			id = ''..lotteryID[ridx]
			-- 		end
			-- 		self:createHeroAI(lotteryID[ridx],randLv,team2)
			-- 	end
			-- end
		-- end
		if self.gameRoomSetting['AIMaxPlayer']>0 then
			self.gameRoomSetting['maxPlayer'] = self.gameRoomSetting['maxPlayer'] - self.gameRoomSetting['AIMaxPlayer']
		end
		addList = self:getAIInfo(roleList)
		for k,v in pairs(addList) do
			self:createHeroAI(v['rid'],v['lv'],v['team'])
		end
		self:syncGameInfoOnece()
	end
	-- if self.gameRoomSetting['AIMaxPlayer']>0 then
	-- 	self.gameRoomSetting['maxPlayer'] = self.gameRoomSetting['maxPlayer'] - self.gameRoomSetting['AIMaxPlayer']
	-- end
end

--- 生成AI的角色,姓名,level,playerID
-- @param roleList table - 已存在角色列表 {{roleID,school,team,level},...}
-- @return AIList table - 需要生成的AI信息列表 {{"pid":"9999010906","lv":6,"rid":9,"team":"A"},...}
function WorldBase:getAIInfo(roleList)
	self:D('jaylog getAIInfo : ',self.cjson.encode(roleList),'ISGVB',self.gameRoomSetting['ISGVB'],'ISPVP',self.gameRoomSetting['ISPVP'])
	if self.gameRoomSetting['AIMaxPlayer']>0 then
		self.gameRoomSetting['maxPlayer'] = self.gameRoomSetting['maxPlayer'] + self.gameRoomSetting['AIMaxPlayer']
	end
	local AIList = {}
	if self.gameRoomSetting['ISGVB']==1 then
		local sum = 0
		local IDs = {}
		local team = ''
		local school1,school2 = 0,0
		local roleID = 0
		for k,v in pairs(roleList) do
			sum = sum + 1
			roleID = v[1]
			if roleID>5 then
				IDs[""..(roleID-5)] = 1
				IDs[""..roleID] = 1
			else
				IDs[""..roleID] = 1
				IDs[""..(roleID+5)] = 1
			end
			team = v[3]
			if v[2]==1 then
				school1 = school1 + 1
			else
				school2 = school2 + 1
			end
		end
		self:D('jaylog sum',sum,self.gameRoomSetting['maxPlayer'])
		if sum<self.gameRoomSetting['maxPlayer'] then
			local addNum = self.gameRoomSetting['maxPlayer'] - sum
			local mustID,mustIDTmp,lotteryIDTmp,lotteryID = {},{},{},{}
			if school1>=school2 then
				mustIDTmp = self.sSplitNumber(self.setting['AIfixedYH'],',')
				lotteryIDTmp = self.sSplitNumber(self.setting['AIrandomYH'],',')
				for k,v in pairs(mustIDTmp) do
					if IDs[''..v]==nil then
						mustID[#mustID+1] = v
					end
				end
				for k,v in pairs(lotteryIDTmp) do
					if IDs[''..v]==nil then
						lotteryID[#lotteryID+1] = v
					end
				end
			else
				mustIDTmp = self.sSplitNumber(self.setting['AIfixedNP'],',')
				lotteryIDTmp = self.sSplitNumber(self.setting['AIrandomNP'],',')
				for k,v in pairs(mustIDTmp) do
					if IDs[''..v]==nil then
						mustID[#mustID+1] = v
					end
				end
				for k,v in pairs(lotteryIDTmp) do
					if IDs[''..v]==nil then
						lotteryID[#lotteryID+1] = v
					end
				end
			end
			if self.mapModel=='5005' then
				if roleList[1][1]==7 then
					mustID = {9}
				end
				if roleList[1][1]==9 then
					mustID = {7}
				end
				lotteryID = {6}
			end
			if self.mapModel=='5008' then
				if roleList[1][1]==7 then
					mustID = {9}
				end
				if roleList[1][1]==9 then
					mustID = {7}
				end
				lotteryID = {8}
			end
			self:D('jaylog ID',self.cjson.encode(mustID),self.cjson.encode(lotteryID))
			for k,v in pairs(mustID) do
				if addNum>0 then
					if IDs[""..v]==nil then
						-- local idx = self:getHeroItemID()
						local id = '01'
						if v<10 then
							id = '0'..v
						else
							id = ''..v
						end
						local lv = self:getHeroAIRandomLevel()
						-- self:createHeroAI(v,lv,team)
						local AIData,AIID = self:getAIData(self.mapModel,v,lv,team)
						local AIPlayerJson = self.cjson.decode(AIData)
						if AIList[#AIList+1]==nil then
							AIList[#AIList+1] = {}
						end
						AIList[#AIList]['rid'] = v
						AIList[#AIList]['lv'] = lv
						AIList[#AIList]['team'] = team
						AIList[#AIList]['pid'] = AIID
						AIList[#AIList]['lid'] = self:getRandomChangeName(AIPlayerJson['Player']['loginID'])
						AIList[#AIList]['wlid'] = AIPlayerJson['Player']['WEAPONLID']
						AIList[#AIList]['wrid'] = AIPlayerJson['Player']['WEAPONRID']
					end
					addNum = addNum - 1
				end
			end
			if addNum>0 and not empty(lotteryID) then
				for i=1,addNum do
					local ridx = 1
					if addNum==1 and self.gameRoomSetting['maxPlayer']==3 then
						ridx = self.formula:getRandnum(1,#lotteryID)
					else
						ridx = i
					end
					if ridx>#lotteryID then
						ridx = ridx - #lotteryID
					end
					--如果相减后还大过lotteryID则直接取lotteryID
					if ridx>#lotteryID then
						ridx = #lotteryID
					end
					-- local idx = self:getHeroItemID()
					local id = '01'
					if lotteryID[ridx]<10 then
						id = '0'..lotteryID[ridx]
					else
						id = ''..lotteryID[ridx]
					end
					local lv = self:getHeroAIRandomLevel()
					-- self:createHeroAI(lotteryID[ridx],lv,team)
					local AIData,AIID = self:getAIData(self.mapModel,lotteryID[ridx],lv,team)
					local AIPlayerJson = self.cjson.decode(AIData)
					if AIList[#AIList+1]==nil then
						AIList[#AIList+1] = {}
					end
					AIList[#AIList]['rid'] = lotteryID[ridx]
					AIList[#AIList]['lv'] = lv
					AIList[#AIList]['team'] = team
					AIList[#AIList]['pid'] = AIID
					AIList[#AIList]['lid'] = self:getRandomChangeName(AIPlayerJson['Player']['loginID'])
					AIList[#AIList]['wlid'] = AIPlayerJson['Player']['WEAPONLID']
					AIList[#AIList]['wrid'] = AIPlayerJson['Player']['WEAPONRID']
				end
			end
		end
	end
	if self.gameRoomSetting['ISPVP']==1 then
		local sum1,sum2 = 0,0
		local IDs1,IDs2 = {},{}
		local team1,team2 = 'B','A'
		local minLv,maxLv = 0,0
		local randLv = 1
		for k,v in pairs(roleList) do
			if v[3]=='B' then
				sum1 = sum1 + 1
				IDs1[""..v[1]] = 1
				if minLv==0 or minLv>v[4] then
					minLv = v[4]
				end
				if maxLv==0 or maxLv<v[4] then
					maxLv = v[4]
				end
			end
			if v[3]=='A' then
				sum2 = sum2 + 1
				IDs2[""..v[1]] = 1
				if minLv==0 or minLv>v[4] then
					minLv = v[4]
				end
				if maxLv==0 or maxLv<v[4] then
					maxLv = v[4]
				end
			end
		end
		if sum1<(self.gameRoomSetting['maxPlayer']*0.5) then
			local addNum = (self.gameRoomSetting['maxPlayer']*0.5) - sum1
			local mustID,mustIDTmp,lotteryIDTmp,lotteryID = {},{},{},{}
			mustIDTmp = self.sSplitNumber(self.setting['AIfixedYH'],',')
			lotteryIDTmp = self.sSplitNumber(self.setting['AIrandomYH'],',')
			for k,v in pairs(mustIDTmp) do
				if IDs1[''..v]==nil then
					mustID[#mustID+1] = v
				end
			end
			for k,v in pairs(lotteryIDTmp) do
				if IDs1[''..v]==nil then
					lotteryID[#lotteryID+1] = v
				end
			end
			for k,v in pairs(mustID) do
				if addNum>0 then
					if IDs1[""..v]==nil then
						randLv = self.formula:getRandnum(minLv,maxLv)
						local id = '01'
						if v<10 then
							id = '0'..v
						else
							id = ''..v
						end
						-- self:createHeroAI(v,randLv,team1)
						local AIData,AIID = self:getAIData(self.mapModel,v,randLv,team1)
						local AIPlayerJson = self.cjson.decode(AIData)
						if AIList[#AIList+1]==nil then
							AIList[#AIList+1] = {}
						end
						AIList[#AIList]['rid'] = v
						AIList[#AIList]['lv'] = randLv
						AIList[#AIList]['team'] = team1
						AIList[#AIList]['pid'] = AIID
						AIList[#AIList]['lid'] = self:getRandomChangeName(AIPlayerJson['Player']['loginID'])
						AIList[#AIList]['wlid'] = AIPlayerJson['Player']['WEAPONLID']
						AIList[#AIList]['wrid'] = AIPlayerJson['Player']['WEAPONRID']
					end
					addNum = addNum - 1
				end
			end
			if addNum>0 and not empty(lotteryID) then
				for i=1,addNum do
					randLv = self.formula:getRandnum(minLv,maxLv)
					local ridx = i
					local id = '01'
					if lotteryID[ridx]<10 then
						id = '0'..lotteryID[ridx]
					else
						id = ''..lotteryID[ridx]
					end
					-- self:createHeroAI(lotteryID[ridx],randLv,team1)
					local AIData,AIID = self:getAIData(self.mapModel,lotteryID[ridx],randLv,team1)
					local AIPlayerJson = self.cjson.decode(AIData)
					if AIList[#AIList+1]==nil then
						AIList[#AIList+1] = {}
					end
					AIList[#AIList]['rid'] = lotteryID[ridx]
					AIList[#AIList]['lv'] = randLv
					AIList[#AIList]['team'] = team1
					AIList[#AIList]['pid'] = AIID
					AIList[#AIList]['lid'] = self:getRandomChangeName(AIPlayerJson['Player']['loginID'])
					AIList[#AIList]['wlid'] = AIPlayerJson['Player']['WEAPONLID']
					AIList[#AIList]['wrid'] = AIPlayerJson['Player']['WEAPONRID']
				end
			end
		end
		if sum2<(self.gameRoomSetting['maxPlayer']*0.5) then
			local addNum = (self.gameRoomSetting['maxPlayer']*0.5) - sum2
			local mustID,mustIDTmp,lotteryIDTmp,lotteryID = {},{},{},{}
			mustIDTmp = self.sSplitNumber(self.setting['AIfixedNP'],',')
			lotteryIDTmp = self.sSplitNumber(self.setting['AIrandomNP'],',')
			for k,v in pairs(mustIDTmp) do
				if IDs2[''..v]==nil then
					mustID[#mustID+1] = v
				end
			end
			for k,v in pairs(lotteryIDTmp) do
				if IDs2[''..v]==nil then
					lotteryID[#lotteryID+1] = v
				end
			end
			self:D('jaylog getAIInfo ID',self.cjson.encode(mustID),self.cjson.encode(lotteryID))
			for k,v in pairs(mustID) do
				if addNum>0 then
					if IDs2[""..v]==nil then
						randLv = self.formula:getRandnum(minLv,maxLv)
						local id = '01'
						if v<10 then
							id = '0'..v
						else
							id = ''..v
						end
						-- self:createHeroAI(v,randLv,team2)
						local AIData,AIID = self:getAIData(self.mapModel,v,randLv,team2)
						local AIPlayerJson = self.cjson.decode(AIData)
						if AIList[#AIList+1]==nil then
							AIList[#AIList+1] = {}
						end
						AIList[#AIList]['rid'] = v
						AIList[#AIList]['lv'] = randLv
						AIList[#AIList]['team'] = team2
						AIList[#AIList]['pid'] = AIID
						AIList[#AIList]['lid'] = self:getRandomChangeName(AIPlayerJson['Player']['loginID'])
						AIList[#AIList]['wlid'] = AIPlayerJson['Player']['WEAPONLID']
						AIList[#AIList]['wrid'] = AIPlayerJson['Player']['WEAPONRID']
					end
					addNum = addNum - 1
				end
			end
			if addNum>0 and not empty(lotteryID) then
				for i=1,addNum do
					randLv = self.formula:getRandnum(minLv,maxLv)
					local ridx = i
					local id = '01'
					if lotteryID[ridx]<10 then
						id = '0'..lotteryID[ridx]
					else
						id = ''..lotteryID[ridx]
					end
					-- self:createHeroAI(lotteryID[ridx],randLv,team2)
					local AIData,AIID = self:getAIData(self.mapModel,lotteryID[ridx],randLv,team2)
					local AIPlayerJson = self.cjson.decode(AIData)
					if AIList[#AIList+1]==nil then
						AIList[#AIList+1] = {}
					end
					AIList[#AIList]['rid'] = lotteryID[ridx]
					AIList[#AIList]['lv'] = randLv
					AIList[#AIList]['team'] = team2
					AIList[#AIList]['pid'] = AIID
					AIList[#AIList]['lid'] = self:getRandomChangeName(AIPlayerJson['Player']['loginID'])
					AIList[#AIList]['wlid'] = AIPlayerJson['Player']['WEAPONLID']
					AIList[#AIList]['wrid'] = AIPlayerJson['Player']['WEAPONRID']
				end
			end
		end
	end
	if self.gameRoomSetting['AIMaxPlayer']>0 then
		self.gameRoomSetting['maxPlayer'] = self.gameRoomSetting['maxPlayer'] - self.gameRoomSetting['AIMaxPlayer']
	end
	self:D('jaylog getAIInfo:',self.cjson.encode(AIList))
	return AIList
end

--- 读取AI英雄数据并生成
-- @param roleID int - 角色ID
-- @param level int - 角色级别
-- @param team string - 队伍
-- @param itemID int - 角色顺序ID
-- @param posX int - 出生位置x
-- @param posY int - 出生位置y
-- @param loginID string - 生成AI的名字
-- @return null
function WorldBase:createHeroAI(roleID,level,team,itemID,posX,posY,loginID)
	if itemID==nil then
		itemID = self:getHeroItemID()
	else
		itemID = itemID
	end
	local playerInfo = self:getAIData(self.mapModel,roleID,level,team)
	local playerJson = self.cjson.decode(playerInfo)
	self:D('jaylog WorldBase:setHeroAIPlayerJson ',itemID,roleID,level,team,playerInfo)
	local preName = ''
	for i=1,5 do
		preName = preName..string.char(self.formula:getRandnum(65,90))
	end
	-- playerJson['Player']['loginID'] = playerJson['Player']['loginID']
	self.playerList[itemID] = {}
	self.playerList[itemID]['playerJson'] = self.tDeepcopy(playerJson)
	-- local idlen = self.sLen(self.playerList[itemID]['playerJson']['Player']['loginID'])
	-- local idnum = idlen/3
	-- local idrand = self.formula:getRandnum(1,idnum)
	-- local idadd = {'机','耿','飘','贺','聪','瞳','奋','刚','细','云','渊','皓','权','司'}
	-- local idaddrand = self.formula:getRandnum(1,#idadd)
	-- local idstr = self.sSub(self.playerList[itemID]['playerJson']['Player']['loginID'],1,(idrand-1)*3)..self.sSub(self.playerList[itemID]['playerJson']['Player']['loginID'],idrand*3+1)..idadd[idaddrand]
	-- -- self:D('jaylog WorldBase:createHeroAI idstr',idlen,idnum,idrand,idstr)
	if loginID~=nil then
		self.playerList[itemID]['playerJson']['Player']['loginID'] = loginID
	else
		self.playerList[itemID]['playerJson']['Player']['loginID'] = self:getRandomChangeName(self.playerList[itemID]['playerJson']['Player']['loginID'])
	end
	self.playerList[itemID]['i'] = itemID
	if team==nil then
		team = self:getPlayerTeam(itemID)
	end
	self.playerList[itemID]['t'] = team
	self.playerList[itemID]['id'] = self.playerList[itemID]['playerJson']['Player']['loginID']
	self.playerList[itemID]['p'] = self.playerList[itemID]['playerJson']['Player']['playerID']
	self.playerList[itemID]['online'] = true
	self.playerList[itemID]['redirectEndTime'] = 0
	local hero
	-- if self.tonumber(self.mapModel)==103 then
	-- 	local x = self.formula:getRandnum(140,150)
	-- 	local y = self.formula:getRandnum(60,80)
	-- 	hero = self:addHero(roleID,team,self.playerList[itemID]['id'],x,y,nil,itemID,true)
	-- else
	-- 临时处理 start
	-- if roleID>5 then
	-- 	roleID = roleID - 5
	-- 	self.playerList[itemID]['playerJson']['Player']['roleId'] = roleID
	-- end
	-- 临时处理 end
		hero = self:addHero(roleID,team,self.playerList[itemID]['id'],posX,posY,nil,itemID,true)
	-- end
	local defaultClose = false
	for k,v in pairs(self.gameRoomSetting['worldAIDefaultClose']) do
		if self.tonumber(self.mapModel)==v then
			defaultClose = true
		end
	end
	if not defaultClose then
		self:D('jaylog WorldBase:createHeroAI setAuto true')
		hero:setAuto(true)
	end
	return hero
end

--- 修改成随机名字
-- @param name string - 角色名
-- @return retName string - 修改后的角色名
function WorldBase:getRandomChangeName(name)
	local idlen = self.sLen(name)
	local idnum = idlen/3
	local idrand = self.formula:getRandnum(1,idnum)
	local idadd = {'机','耿','飘','贺','聪','瞳','奋','刚','细','云','渊','皓','权','司'}
	local idaddrand = self.formula:getRandnum(1,#idadd)
	local retName = self.sSub(name,1,(idrand-1)*3)..self.sSub(name,idrand*3+1)..idadd[idaddrand]
	return retName
end

--- 获取随机级别
-- @param null
-- @return null
function WorldBase:getHeroAIRandomLevel()
	local lv = 1
	if self.gameRoomSetting['ISGVB']==1 then
		-- local roomLv = self.tonumber(self.gameRoomInfo['openLv'])
		-- local minLv,maxLv = 1,1
		-- if roomLv>0 then
		-- 	if roomLv<20 then
		-- 		minLv = roomLv
		-- 		maxLv = roomLv+2
		-- 	else
		-- 		minLv = roomLv
		-- 		maxLv = roomLv+9
		-- 	end
		-- end
		local roomLv = self.sSplitNumber(self.gameRoomInfo['levelRange'],',')
		local minLv,maxLv = roomLv[1],roomLv[2]
		lv = self.formula:getRandnum(minLv,maxLv)
		self:D('jaylog WorldBase:getHeroAIRandomLevel level ',self.cjson.encode(roomLv),minLv,maxLv,lv)
	end
	if self.gameRoomSetting['ISYW']==1 then
		local minLv = self.tonumber(self.setting['open_LV'])
		local maxLv = self.tonumber(self.setting['Max_LV'])
		lv = self.formula:getRandnum(minLv,maxLv)
	end
	return lv
end

function WorldBase:syncHeroInfo()
	if self.gameRoomSetting['ISYW']==1 then
		for k,v in pairs(self.itemListFilter.heroList) do
			if v.actorType==0 and not v.isAI and v.lastAutoCallApiTime<self.gameTime and self.playerList[k]['online'] then
				if v.lastAutoCallApiTime<self.gameTime then
					v:updateInfo()
					v:updateEquipLose()
					v.lastAutoCallApiTime = v.lastAutoCallApiTime + 60
				end
			end
		end
	end
end

--- 获取GameOver的Data结构
-- @param null
-- @return null
function WorldBase:genGameOverData()
	-- new game over step start
	local winner = self.gameFlag['winTeam']
	local winarr = {}
	local winStr = ''
	local teamWinStr = {A='0',B='0'}
	local newAPIparameterArray = {}
	--local bonus = {}
	--local bonusStr = ''
	--local tmpbonus = {}
	local dpsTime = 0
	if self.startCalDPSTime>0 then
		dpsTime = self.gameTime-self.startCalDPSTime
	end
	-- if self.gameCounter.pointsA>=self.gameRoomSetting['gameLimitedPoints'] then
	-- 	winner = 'A'
	-- end
	-- if self.gameCounter.pointsB>=self.gameRoomSetting['gameLimitedPoints'] then
	-- 	winner = 'B'
	-- end
	for k,v in pairs(self.itemListFilter.heroList) do
		winarr[""..v.itemID] = 0
		if v.actorType==0 then
			if v.team==winner then
				winarr[""..v.itemID] = 1
				winStr = winStr..'1'
				if teamWinStr[v.team]=='0' then
					teamWinStr[v.team] = '1'
				end
			else
				-- PVP胜利
				if winner=='' and self.gameRoomSetting['ISPVP']==1 then
					if self.gameCounter['pointsA']==self.gameCounter['pointsB'] then
						winarr[""..v.itemID] = 2
						winStr = winStr..'2'
						winner = ''
						if teamWinStr[v.team]=='0' then
							teamWinStr[v.team] = '2'
						end
					elseif self.gameCounter['pointsA']>self.gameCounter['pointsB'] then
						if v.team=='A' then
							winarr[""..v.itemID] = 1
							winStr = winStr..'1'
							winner = 'A'
							if teamWinStr[v.team]=='0' then
								teamWinStr[v.team] = '1'
							end
						else
							winarr[""..v.itemID] = 0
							winStr = winStr..'0'
						end
					elseif self.gameCounter['pointsA']<self.gameCounter['pointsB'] then
						if v.team=='B' then
							winarr[""..v.itemID] = 1
							winStr = winStr..'1'
							winner = 'B'
							if teamWinStr[v.team]=='0' then
								teamWinStr[v.team] = '1'
							end
						else
							winarr[""..v.itemID] = 1
							winStr = winStr..'0'
						end
					else
						winStr = winStr..'0'
					end
				else
					winStr = winStr..'0'
				end
			end
		end
		-- if self.gameCounter.pointsA>=self.gameRoomSetting['gameLimitedPoints'] and v.team=='A' then
		-- 	winarr[""..v.itemID] = 1
		-- end
		-- if self.gameCounter.pointsB>=self.gameRoomSetting['gameLimitedPoints'] and v.team=='B' then
		-- 	winarr[""..v.itemID] = 1
		-- end
		-- if (bonus[v.itemID]==nil) then
		-- 	bonus[v.itemID] = {}
		-- end
		-- bonus[v.itemID][#bonus[v.itemID]+1] = {
		-- 	d=1,
		-- 	i=55001,
		-- 	q=1
		-- }
	end
	-- for kkk,vvv in pairs(bonus) do
	-- 	for kkk2,vvv2 in pairs(vvv) do
	-- 		tmpbonus[#tmpbonus+1]=vvv2['i']..","..vvv2['q']
	-- 	end
	-- end
	-- bonusStr=implode(';',tmpbonus)

	if self.gameRoomSetting['AIMaxPlayer']>0 then
		self.gameRoomSetting['maxPlayer'] = self.gameRoomSetting['maxPlayer'] + self.gameRoomSetting['AIMaxPlayer']
	end

	local peopleCount=0
	-- for i=1,self.gameRoomSetting['maxPlayer'] do
	for i,v in pairs(self.playerList) do
		if (isset(self.playerList[i])) and self.allItemList[i].parent==nil then
			peopleCount = peopleCount + 1
		end
	end

	newAPIparameterArray['sum'] = {
		game_id=self.gameID,
		startTime=os.date("%Y%m%d%H%M%S",(os.time()-math.ceil(self.startTime))),
		gameTime=self.gameTime,
		endTime=os.date("%Y%m%d%H%M%S",os.time()),
		mapModel=self.mapModel,
		mapmodel=self.mapModel,
		outcome=winner,
		scoreA=self.gameCounter['pointsA'],
		scoreB=self.gameCounter['pointsB'],
		peopleCount=peopleCount,
	}

	-- gameScore table --
	local gameOverMsgScore = {}
	self.gameOverMsg['game']['reset'] = 1
	self.gameOverMsg['game']['pointsA'] = self.gameCounter['pointsA']
	self.gameOverMsg['game']['pointsB'] = self.gameCounter['pointsB']
	self.gameOverMsg['game']['gameTime'] = self.mCeil(self.gameTime)
	local teamWinStrAll = teamWinStr['A']..teamWinStr['B']
	self:D('jaylog teamWinStrAll',teamWinStrAll)
	if teamWinStrAll=='10' then
		self.gameOverMsg['game']['w'] = 1
	elseif teamWinStrAll=='01' or teamWinStrAll=='00' then
		self.gameOverMsg['game']['w'] = 2
	elseif teamWinStrAll=='22' then
		self.gameOverMsg['game']['w'] = 3
	else
		self.gameOverMsg['game']['w'] = 4
	end
	-- self.gameOverMsg['game']['w'] = self.tonumber('9'..winStr) 	--winarr
	if self.gameFlag['star1del'] and self.gameCounter['star']>1 then
		self:setGameCounter('star',-1)
	end
	self.gameOverMsg['game']['star'] = self.gameCounter['star']
	--self.gameOverMsg['game']['bonus'] = bonus
	--[[
	local bonus = {}
	for i=1,self.maxPlayer do
		if (bonus[i]==nil) then
			bonus[i] = {}
		end
		bonus[i][#bonus[i]+1] = {
			type=1,
			id=1,
			qty=1
		}
	end
	]]
	-- for i=1,self.gameRoomSetting['maxPlayer'] do
	for i,v in pairs(self.playerList) do
		if (isset(self.playerList[i])) and self.allItemList[i].parent==nil then
			--[[
			local gameScore = {
				i = self.playerList[i]['i'],
				id = self.playerList[i]['id'],
				p = self.playerList[i]['p'],
				t = self.playerList[i]['t'],
				points = self.allItemList[i]['counter']['points'],
				bonus = bonus[i]
			}
			gameOverMsgScore[i]=gameScore
			]]
			local StartStr='1'
			local exp = 0
			local heroexp = 0
			local adjGold = 0
			local penalty = 0
			local newRank = 0
			local powreduce = 0
			local mvpplayerid = 0
			local point = 0
			local gold = 0
			local isWin = 0
			--local bonusStr = ''
			--local tmpbonus = {}
			local serverIP=""
			if (isset(self.playerList[i]['commip'])) then
				serverIP=self.playerList[i]['commip']
			end

			if winner=='C' then
				isWin = 2
			elseif self.allItemList[i].team==winner then
				isWin = 1
				--newRank = 5
			else
				if self.gameRoomSetting['ISGVB']==1 then
					self.gameCounter['star'] = 0
				end
				--newRank = 1
			end

			local angel1,angel2,angel3 = 0,0,0
			self:D('jaylog start set angel ',self.allItemList[i].attribute.energyBoard~=nil)
			if self.allItemList[i].attribute.energyBoard~=nil then
				self:D('jaylog start set angel ',self.cjson.encode(self.allItemList[i].attribute.energyBoard.energyBoardList))
				angel1 = self.allItemList[i].attribute.energyBoard.energyBoardList['1']==nil and 0 or self.allItemList[i].attribute.energyBoard.energyBoardList['1'].angelID
				angel2 = self.allItemList[i].attribute.energyBoard.energyBoardList['2']==nil and 0 or self.allItemList[i].attribute.energyBoard.energyBoardList['2'].angelID
				angel3 = self.allItemList[i].attribute.energyBoard.energyBoardList['3']==nil and 0 or self.allItemList[i].attribute.energyBoard.energyBoardList['3'].angelID
			end

			local newAPIparameter = {
						start=StartStr,
						game_id=self.gameID,
						camp=self.allItemList[i].teamOrig,
						level=self.allItemList[i].attribute.level,
						hero_id=self.playerList[i]['a'],
						serverID=self.playerList[i]['playerJson']['Player']['serverID'],
						play_win=isWin,
						play_lose=isWin==0 and 1 or 0,
						play_draw=isWin==2 and 1 or 0,
						--penalty=(penalty>0 and 1 or 0),
						play_hero_kill=self.allItemList[i]:getCounter('killhero'),
						play_assist_kill=0,							--self.gameCounter['killassistant']
						play_dead=self.allItemList[i]:getCounter('killed'),
						play_boss_kill=self.allItemList[i]:getCounter('killboss'),
						play_hurted=self.mAbs(self.allItemList[i]:getCounter('hurted')),
						play_hurt=self.mAbs(self.allItemList[i]:getCounter('hurt')),
						play_getFlag=self.allItemList[i]:getCounter('getFlag'),
						play_cure=self.mAbs(self.allItemList[i]:getCounter('cure')),
						play_hurtedBoss=self.mAbs(self.allItemList[i]:getCounter('hurtedBoss')),
						play_hurtBoss=self.mAbs(self.allItemList[i]:getCounter('hurtBoss')),
						dpsTime=dpsTime,
						ipaddr=self.allItemList[i].ipaddress,
						ping=self.allItemList[i].pingtime,
						totalIdle=self.allItemList[i].totalIdleTime,
						maxIdle=self.allItemList[i].maxIdleTime,
						serverIP=serverIP,
						prizeOperate=(self.allItemList[i].skinNum~=nil and self.allItemList[i].skinNum or 0),
						star=self.gameCounter['star'],
						--play_vs_random=(self.gameModel~=nil and self.gameModel==10) and 0 or (gamemode==1 and 1 or 0),
						--play_vs_33=(self.gameModel~=nil and self.gameModel==10) and 0 or (gamemode==2 and 1 or 0),
						--play_vs_ai=gamemode==3 and 1 or 0,
						--play_vs_guild=gamemode==4 and 1 or 0,
						--play_vs_training=(self.gameModel~=nil and self.gameModel==10) and 0 or (gamemode==6 and 1 or 0),
						--play_vs_team=self.isTeam and 1 or 0,
						--play_vs_gambling=(self.gameModel~=nil and self.gameModel==10) and 1 or 0,
						--rank=newRank,
						play_isdead=self.allItemList[i]:isDead() and 1 or 0,
						school=self.playerList[i]['playerJson']['Player']['school'],
						play_time=self.gameTime,
						play_realtime=self.gameTime-self.roomStartTime,
						--powreduce=powreduce,
						mapModel=self.gameModel,
						mapmodel=self.gameModel,
						player_rebirth=self.allItemList[i].counter['revive'],
						--adjCoin=1000,				--adjCoin
						mvplist=0,				--mvpplayerid
						star=self.gameCounter['star'],
						itemID=i,
						isAI=self.allItemList[i].isAI and 1 or 0,
						dm1=self.allItemList[i].attribute.DEMON1,
						dm2=self.allItemList[i].attribute.DEMON2,
						dm3=self.allItemList[i].attribute.DEMON3,
						dm4=self.allItemList[i].attribute.DEMON4,
						angel1=angel1,
						angel2=angel2,
						angel3=angel3,
			}
			if self:isWFRoom() then
				newAPIparameter['AImode'] = self.allItemList[i].AImode+1
			end
			if self.tonumber(self.allItemList[i].attribute.roleId)==4 or self.tonumber(self.allItemList[i].attribute.roleId)==9 then
				if self.tonumber(self.mapModel)~=self.tonumber(self.setting.newPlayerGVB) then
					newAPIparameter['skillStatus'] = self.allItemList[i]:getMode2ATKMode()
				end
			end
			-- if bonus[i]~=nil then
			-- 	for kkk,vvv in pairs(bonus[i]) do
			-- 		tmpbonus[#tmpbonus+1]=vvv['i']..","..vvv['q']
			-- 		--newAPIparameter['itemAchieve_'..vvv['i']] = vvv['q']
			-- 	end
			-- 	bonusStr=implode(';',tmpbonus)
			-- end
			if self.tonumber(self.playerList[i]['p'])<99999999 then
				newAPIparameterArray[self.sFormat(self.playerList[i]['p'])] = newAPIparameter
			else
				if self.mapModel~='8011' then
					newAPIparameterArray[self.sFormat(self.playerList[i]['p']..i)] = newAPIparameter
				end
			end
			--self:D('start to save newAPIparameterArray'..self.cjson.encode(newAPIparameter)..'   '..self.playerList[i]['p']..'  '..self.cjson.encode(newAPIparameterArray))

			if self.playerList[i]['recnt'] ==nil then
				self.playerList[i]['recnt'] =0
			end
			self:D('jaylog newAPIparameter : ',self.cjson.encode(newAPIparameter) ,' p: ',self.cjson.encode(self.playerList[i]['p']))
		end
	end

	if self.gameRoomSetting['AIMaxPlayer']>0 then
		self.gameRoomSetting['maxPlayer'] = self.gameRoomSetting['maxPlayer'] + self.gameRoomSetting['AIMaxPlayer']
	end

	return newAPIparameterArray
	
	--self.gameOverMsg['game']['gameScore'] = gameOverMsgScore
	-- self:D('jaylog gameOverMsg : ',self.cjson.encode(self.gameOverMsg))

	-- self.gameOverStatistic={}
	-- for k,value in pairs(self.itemListFilter.heroList) do
	-- 	self.gameOverStatistic[value.itemID] = {
	-- 		i = value.itemID,
	-- 		killhero = value.counter['killhero'],
	-- 		hilled = value.counter['killed'],
	-- 		hurted = value.counter['hurted'],
	-- 		hurt = value.counter['hurt'],
	-- 		cure = value.counter['cure'],
	-- 		getFlag = value.counter['getFlag'],
	-- 		points = value.counter['points']
	-- 	}
	-- end

	--战斗结算call api
	-- local finishapi = self.webapiurl..'internalapi/finishGameRoomMutil'
	-- local finishapi2 = self.webapiurl2..'internalapi/finishGameRoomMutil'
	-- if self.gameRoomSetting.ISLOCAL==1 then
	-- 	finishapi = 'http://dev8.zharev.com/AOEApi/pve/finishGame'
	-- 	finishapi2 = 'http://dev8.zharev.com/AOEApi/pve/finishGame'
	-- end
	-- self:D('jaylog newAPIparameterArray...........:' , self.cjson.encode( newAPIparameterArray ) )
	-- local url=finishapi..'/?data='..string.urlencode(self.cjson.encode(newAPIparameterArray))..'&version=999'
	-- local webresult=self:file_get_contents(url)
	-- if (webresult==false) then
	-- 	url=finishapi2..'/?data='..string.urlencode(self.cjson.encode(newAPIparameterArray))..'&version=999'
	-- 	webresult=self:file_get_contents(url)
	-- end
	-- self:D('url : ',url,' result:',webresult)

	-- new game over step end
end

--- 获取两点直线在坐标系中的角度
-- @param x1 int - 起始点x
-- @param y1 int - 起始点y
-- @param x2 int - 目的点x
-- @param y2 int - 目的点y
-- @return angle int - 坐标系中的角度
function WorldBase:getAngle(x1,y1,x2,y2)
	-- local y = self.mAbs(y2 - y1)
	-- local x = self.mAbs(x2 - x1)
	-- local z = self.mSqrt(self.mPow(x,2)+self.mPow(y,2))
	-- local cos = y/z
	-- local radina = self.mAcos(cos)
	-- local angle = self.mFloor(180/(self.mPI/radina))
	-- self:D('jaylog WorldBase:getAngle ',x1,y1,x2,y2,cos,radina,angle)
	-- if (x2>x1 and y2>y1) then
	-- 	angle = 180 - angle
	-- end

	-- if (x2==x1 and y2>y1) then
	-- 	angle = 180
	-- end

	-- if (x2>x1 and y2==y1) then
	-- 	angle = 90;
	-- end

	-- if (x2<x1 and y2>y1) then
	-- 	angle = 180+angle;
	-- end

	-- if (x2<x1 and y2==y1) then
	-- 	angle = 270;
	-- end

	-- if (x2<x1 and y2<y1) then
	-- 	angle = 360 - angle;
	-- end
	-- return angle;
	
	local angle = self.mDeg(self.mAtan2((y2-y1),(x2-x1)))
	if angle<0 then
		angle = 360 + angle
	end
	return angle
end

--- 是否无缝副本
-- @param null
-- @return null
function WorldBase:isWFRoom()
	if self.tonumber(self.mapModel)>=7000 and self.tonumber(self.mapModel)<=9000 then
		return true
	end
	return false
end

return WorldBase
