#!/bin/bash

if [ "$1" != "" ];then

ps aux |grep 'main '$1 |grep -v grep | awk '{print "sudo kill "$2}' | sh
ps aux |grep 'main '$1 |grep -v grep

else

echo "ex: killRoom.sh 3000"

fi
