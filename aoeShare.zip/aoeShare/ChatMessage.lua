local ChatMessage = class("ChatMessage")

function ChatMessage:ctor(world)
	if self.className==nil then
		self.className = 'ChatMessage'
	end

	self.world = world

end

--- 设置信息
-- @param msg string - 信息内容
-- @param mType int - 信息类型 2=阵型,3=私聊,4=组队,5=公会,6=系统,1=世界
-- @param itemID int - 玩家顺序ID
-- @return null
function ChatMessage:setMsg(msg,mType,itemID,toPid)
	self.world:D('jaylog ChatMessage:setMsg in ',msg,mType,itemID,toPid)
	mType = self.world.tonumber(mType)
	if mType==nil then
		mType = 0
	end
	if mType~=0 then
		if itemID==nil then
			itemID = 0
		end
		if toPid==nil then
			toPid = 0
		end
		local obj = self.world.itemListFilter.heroList[itemID]
		local pid = 0
		local school = 0
		local gid = 0
		local sid = 0
		local lid = ''
		local toLid = ''
		local mp3id = 0
		local rid = 0
		local toRid = 0
		if obj~=nil then
			local pInfo = self.world.cjson.decode(self.world:memcacheGet('player'..self.world.tonumber(self.world.playerList[itemID]['p'])))
			pid = self.world.tonumber(pInfo['pid'])
			school = self.world.tonumber(pInfo['school'])
			gid = self.world.tonumber(pInfo['gid'])
			sid = self.world.tonumber(pInfo['serverId'])
			lid = pInfo['lid']
			rid = pInfo['roleId']
		end
		if toPid~=0 then
			local tpInfo = self.world.cjson.decode(self.world:memcacheGet('player'..self.world.tonumber(toPid)))
			toLid = tpInfo['lid']
			toRid = pInfo['roleId']
		end
		if mType>10 then
			mp3id = self.world:redisCall('incrby','mp3idx',1)
			mType = mType - 10
		end
		local data = {i=itemID,rid=rid,pid=pid,lid=lid,gid=gid,school=school,sid=sid,trid=toRid,tpid=toPid,tlid=toLid,mType=mType,msg=msg,time=os.time(),mp3id=mp3id}
		local schoolType = mType+self.world.tonumber(school)*100+1000
		local pidType = mType+(pid%5+1)*100+1000
		local gidType = gid+10000
		local mTypeTmp = mType+100
		self.world:D('jaylog ChatMessage:setMsg out ',self.world.cjson.encode(data))
		if mType==2 then
			self.world:redisCall('rPush','aoechat'..schoolType,self.world.cjson.encode(data))
		elseif mType==3 then
			self.world:redisCall('rPush','aoechat'..pidType,self.world.cjson.encode(data))
		elseif mType==5 then
			if gid~=0 then
				self.world:redisCall('rPush','aoeguildchat'..gidType,self.world.cjson.encode(data))
			end
		else
			self.world:redisCall('rPush','aoechat'..mTypeTmp,self.world.cjson.encode(data))
		end
		return mp3id
	end
end

return ChatMessage
