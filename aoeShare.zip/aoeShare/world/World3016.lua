local World3016 = class("World3016",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World3016:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World3016"
	end

	World3016.super.ctor(self,gamePort,gameID,callBack)
	worldForHero = 3016
end

local World3017 = class("World3017",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World3017:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World3017"
	end

	World3017.super.ctor(self,gamePort,gameID,callBack)
	worldForHero = 3017
end

--- 接收client端发送数据
-- @param data table - 发送的数据table
-- @param serverTime float - 游戏时间
-- @return null
function World3017:receiveMsg(data,serverTime)
	local ret = World3017.super.receiveMsg(self,data,serverTime)
	if data==nil then
		data = {}
	end
	for k,v in pairs(data) do
		if k=='apimsgc' then
			local vdata = self.cjson.decode(v['rq'])
			if v['ctrl']~=nil and v['act']~=nil then
				if v['ctrl']=='autoMove' and v['act']=='autoMove' then
					if not self.allItemList[data['roleID']]:isDead() then
						if vdata['pID']~=nil and vdata['pID']~=0 and vdata['pID']~='' then
							if self.allItemList[data['roleID']].statusList[4134]~=nil then
								debuglog("重刷4134 1.。。。。。。。。。")
								local status = self.allItemList[data['roleID']].statusList[4134]
								self.allItemList[data['roleID']]:removeStatusList(4134)
								self.allItemList[data['roleID']]:addStatusList({zz=3,i=self.allItemList[data['roleID']].itemID,s=4134,r=self.gameTime,t=9999,p1=status['p1'],p2=status['p2'],p5=1},0.5)
							end
						end
					end
				end
			end
		end
		if self.status==self.RUNNING and k=='mc' and data['roleID'] ~=nil then
			if self.allItemList[data['roleID']].statusList[4134]~=nil then
				debuglog("重刷4134 2.。。。。。。。。。")
				local status = self.allItemList[data['roleID']].statusList[4134]
				self.allItemList[data['roleID']]:removeStatusList(4134)
				self.allItemList[data['roleID']]:addStatusList({zz=3,i=self.allItemList[data['roleID']].itemID,s=4134,r=self.gameTime,t=9999,p1=status['p1'],p2=status['p2'],p5=1},0.5)
			end
		end
		if self.status==self.RUNNING and k=='ac' and data['roleID'] ~=nil then
			if self.allItemList[data['roleID']].statusList[4134]~=nil then
				debuglog("重刷4134 3.。。。。。。。。。")
				local status = self.allItemList[data['roleID']].statusList[4134]
				self.allItemList[data['roleID']]:removeStatusList(4134)
				self.allItemList[data['roleID']]:addStatusList({zz=3,i=self.allItemList[data['roleID']].itemID,s=4134,r=self.gameTime,t=9999,p1=status['p1'],p2=status['p2'],p5=1},0.5)
			end
		end
	end
	return ret
end
return World3016