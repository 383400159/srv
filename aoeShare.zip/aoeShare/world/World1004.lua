local World1004 = class("World1004",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World1004:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World1004"
	end
	World1004.super.ctor(self,gamePort,gameID,callBack)
	worldForHero = 1004

	--野怪轮流出
	-- self.genItemList = {{itemID=160,x=79,y=198,time=0,num=0,maxNum=6},
	-- 					{itemID=160,x=72,y=203,time=0,num=0,maxNum=6},
	-- 					{itemID=160,x=162,y=280,time=0,num=0,maxNum=6},
	-- 					{itemID=160,x=150,y=290,time=0,num=0,maxNum=6}}
	self.genItemList={}
	--野怪轮流出间隔
	self.genItemCD = 3
	--野怪列表
	self.itemList = {}
	--准备进行下一批
	self.nextTime = 99999
	--当前波数时间开始
	self.startRoundsTime = 0
	--当前第几波
	self.rounds = 1 
	--总共有几波
	self.maxRounds=6
	--总基地id
	self.baseID = 0
	self.baseObj = nil
	--发兵时间
	self.startTimeTo = 30
	--活动结束时间
	self.endTime=3600


	--贡献列表 排行列表
	self.ranksList = {}
	--下次刷新列表时间
	self.nextRanksTime = 0
	--刷新buff时间
	self.nextBuffTime = 0
	--刷新buff的ID
	self.nextBuffID = 0

	self.MDList={}
	self.MTList={}
	self.MT2List={}
	self.littleBossID={}
	self.ratio = {}
	self.playerPoint = {}
	self.specialPosition = {}
	self.specialMonsterID={}
end


function World1004:init()
	World1004.super.init(self)
end

--- init时部分游戏房设置赋setting值
-- @param null
-- @return null
function World1004:gengameRoomSetting()
	--生成中心堡垒  115,244 baseID
	self:D("保卫雅典娜 生成中心堡垒",self.setting.baseID)
	local s1 = string.splitNumber(self.setting.baseID,',')
	--self.baseID = self:addMonster(s1[1],s1[2],s1[3],"A",1,"A") 
	self.baseObj = self:addBoss(9006,"A","保卫雅典娜 水晶塔",s1[2],s1[3]) 
	self.baseID = self.baseObj.itemID
	--self.baseObj  = self.allItemList[self.baseID]
	self:D("保卫雅典娜 生成中心堡垒",self.baseID)
	self.baseObj:setSubName("baseTower");
	
	local monsterDirection = string.split(self.setting.monsterDirection,';')
	
	for k,v in pairs(monsterDirection) do
		local s1 = string.splitNumber(v,',')
		self.MDList[#self.MDList+1]={s1[1],s1[2]}
	end

	local specialPosition = string.split(self.setting.specialPosition,';')
	for k,v in pairs(specialPosition) do
		local s1 = string.splitNumber(v,',')
		self.specialPosition[#self.specialPosition+1]={s1[1],s1[2]}
	end

	self.MTList = string.splitNumber(self.setting.monsterTimesAndID,',')
	self.MT2List = string.splitNumber(self.setting.monsterTimesAndID2,',')
	
	--初始化第一批怪
	for i=1,#self.MDList do
		if i%2==0 then
			self.genItemList[#self.genItemList+1]={itemID=self.MTList[1],x=self.MDList[i][1],y=self.MDList[i][2],time=0,num=0,maxNum=self.setting.monsterNum}
		else
			self.genItemList[#self.genItemList+1]={itemID=self.MT2List[1],x=self.MDList[i][1],y=self.MDList[i][2],time=0,num=0,maxNum=self.setting.monsterNum}
		end
	end

	local ib=string.split(self.setting.littleBossID,';')
	for k,v in pairs(ib) do
		local s1 = string.splitNumber(v,',')
		self.littleBossID[#self.littleBossID+1]={s1[1],s1[2]}
	end

	local pp=string.split(self.setting.playerPoint,';')
	for k,v in pairs(pp) do
		local s1 = string.splitNumber(v,',')
		self.playerPoint[#self.playerPoint+1]={s1[1],s1[2]}
	end

	self.ratio = string.splitNumber(self.setting.ratio,',')
	self.specialMonsterID = string.splitNumber(self.setting.specialMonsterID,',')
	self.genItemCD = self.setting.monsterIntervalsTime
	self.startTimeTo = self.setting.monsterTime
	self.startRoundsTime = self.setting.monsterTime
	self.endTime = self.setting.mode_Time
	self.maxRounds = #self.MTList 
end


function World1004:genItem()
	-- self:D("保卫雅典娜 genItem")
	--检测主基地有没有挂掉
	if self.baseObj~=nil and self.baseObj:isDead() then
		self:gameOver(false,self.baseObj.attribute.HP/self.baseObj.attribute.MaxHP)
	end
	--时间到
	if self.gameTime>self.endTime then
		self:gameOver(false,self.baseObj.attribute.HP/self.baseObj.attribute.MaxHP)
	end
	if self.gameTime>self.nextBuffTime and self.nextBuffID>0 then
		self:createBuffItem(self.nextBuffID)
		self.nextBuffID = 0
	end

	--检测场上怪物有没有死完
	if self.gameTime>self.startTimeTo then

		if (self.gameTime>self.nextTime or self.gameTime>(self.startRoundsTime+self.setting.monsterFFTime)) then
			--self:D("保卫雅典娜 时间",self.nextTime,self.gameTime)
			local allDead=1
			for k,v in pairs(self.itemList) do
				local obj = self.allItemList[v] 
				if obj~=nil and not obj:isDead() then
					allDead = allDead * 0
				end
			end
			--self:D("保卫雅典娜",self.gameTime,self.startTimeTo,allDead)
			if allDead==1 and self.rounds<=self.maxRounds and not empty(self.itemList)  then
				self.nextTime=self.gameTime+self.setting.refreshTime
				self.itemList={}
				--刷新buff怪
				if self.rounds%2==1 then
					self.nextBuffTime = self.gameTime+self.setting.speciaMonsterRT
					self.nextBuffID = self.mCeil(self.rounds/2)
				end
			end


			if ((allDead==1 and self.gameTime>self.nextTime) or self.gameTime>(self.startRoundsTime+self.setting.monsterFFTime)) and self.rounds<=self.maxRounds   then
				--重置重新出兵
				--self:D("保卫雅典娜  超时强行刷新下一批----- ",self.gameTime,(self.startRoundsTime+self.setting.monsterFFTime))
				self.rounds = self.rounds+1
				self.startRoundsTime = self.gameTime
				self.genItemList={}
				for i=1,#self.MDList do
					if self.rounds<=self.maxRounds then
						if i%2==0 then
							self.genItemList[#self.genItemList+1]={itemID=self.MTList[self.rounds],x=self.MDList[i][1],y=self.MDList[i][2],time=0,num=0,maxNum=self.setting.monsterNum,posNum=i}
						else
							self.genItemList[#self.genItemList+1]={itemID=self.MT2List[self.rounds],x=self.MDList[i][1],y=self.MDList[i][2],time=0,num=0,maxNum=self.setting.monsterNum,posNum=i}
						end
					else
						self.genItemList[#self.genItemList+1]={itemID=self.MTList[1],x=self.MDList[i][1],y=self.MDList[i][2],time=0,num=0,maxNum=0,posNum=i}
					end
				end

				if self.rounds%2==0 then
					for k,v in pairs(self.genItemList) do
						if v.posNum%2==0 then
							v['bossID'] = self.littleBossID[self.rounds/2][1]
							v['bossType'] =  self.littleBossID[self.rounds/2][2]
						end
					end
				end

				if self.rounds==self.maxRounds+1 then
					local r1 = self.formula:getRandnum(1,#self.genItemList)
					for k,v in pairs(self.genItemList) do
						if k==r1 then
							v['bossID'] = self.setting.bigBossID
							v['bossType'] = 2
						end
					end
				end
				allDead=0
				self:D("保卫雅典娜 重新出兵",self.rounds)
			end

			if allDead==1 and self.rounds==self.maxRounds+1 then
				self:gameOver(true,self.baseObj.attribute.HP/self.baseObj.attribute.MaxHP)
			end

		end

		self:createItem()

	end

	self:updateRanks()
end


function World1004:createItem()
	--生成小怪和boss
	for k,v in pairs(self.genItemList) do
		--召唤小boss
		if self.gameTime>v.time+self.genItemCD and v.num==v.maxNum and v.bossID~=nil then
			v.time=self.gameTime
			v.num=v.num+1
			self.nextTime=99999
			local itemID = 0
			if v.bossType==1 then
				--itemID = self:addMonster(v.bossID,v.x,v.y,"",1,"") 
				itemID = self:addCreature(v.bossID,"",v.x,v.y,nil,1,0) 
				self.itemList[#self.itemList+1]=itemID
			else
				local obj = self:addBoss(v.bossID,"","保卫雅典娜 终极boss",v.x,v.y) 
				self.itemList[#self.itemList+1]=obj.itemID
			end
			

			self:D("保卫雅典娜 boss生成",v.num,self.rounds)
		end

		if self.gameTime>v.time+self.genItemCD and v.num<v.maxNum then
			--生成一个小怪 79,196 72,203 162,280 150,290
			v.time=self.gameTime
			v.num=v.num+1
			self.nextTime=99999
			--local itemID = self:addMonster(v.itemID,v.x,v.y,"",1,"") 
			local itemID = self:addCreature(v.itemID,"",v.x,v.y,nil,1,0) 
			self.itemList[#self.itemList+1]=itemID
			self:D("保卫雅典娜 小怪生成",v.num,self.rounds)
		end
		

		if (v.num==v.maxNum and v.bossID==nil) or (v.num==v.maxNum+1 and v.bossID~=nil) then
			v.num=v.num+1
			self.nextTime=self.gameTime
			self:D("保卫雅典娜 下一波时间",self.nextTime,self.gameTime)
		end

	end
end

function World1004:createBuffItem(id)
	for k,v in pairs(self.specialPosition) do
		self:D("保卫雅典娜 添加buff怪",self.specialMonsterID[id])
		
		self:addCreature(self.specialMonsterID[id],"",v[1],v[2],nil,1,0)
	end
end
--win true or false 代表输赢
--hprate boss剩余血量比例
function World1004:gameOver(win,hprate)
	self:D("保卫雅典娜 需要结算",win,hprate)
	--更新玩家数据
	self:updatePlayerInfo(win,hprate)

	-- -- 玩家离开清除房间玩家数据 --
	-- local players={}
	-- for i=1,self.gameRoomSetting['maxPlayer'] do
	-- 	if (isset(self.playerList[i]) and self.playerList[i]['online']==false) then
	-- 		if self.gameRoomSetting['hasMapZone']~=true and (self.tonumber(self.playerList[i]['p'])>0) then
	-- 			self:redisCall('srem','room0',self.playerList[i]['p'])
	-- 		end
	-- 		if (self.tonumber(self.playerList[i]['p'])>12) then
	-- 			rc = {i=0,m=self.playerList[i]['id'].." 离开了房间",t="",d=0}
	-- 			self:addSyncMsg({rc=rc})
	-- 		end
	-- 		--self.playerList[i]=nil
	-- 	elseif (isset(self.playerList[i])) then
	-- 		players[self.playerList[i]['p']]=self.playerList[i]
	-- 		if self.gameRoomSetting['hasMapZone']~=true and (self.tonumber(self.playerList[i]['p'])>0) then
	-- 			self:redisCall('srem','room0',self.playerList[i]['p'])
	-- 		end
	-- 	end
	-- end

	-- players['END']=true
	-- self:setPlayerListMemcache(players)
	-- self:D("jaylog 有没有call到结束/////////////")
	-- self.gameOverTime = self.gameTime+5
	-- self.status=self.GAMEOVER


	World1004.super.gameOver(self)
end

function World1004:updatePlayerInfo(win,hprate)

	for k,v in pairs(self.ranksList) do
		local obj = self.allItemList[v.itemID] 
		local data = {}
		--data = {mapModel=self.world.mapModel,mapPort=self.world.gamePort,HP=self.attribute.HP,MP=self.attribute.MP,X=self.posX,Y=self.posY}
		data['info'] = {ranks=k,mapPort=self.gamePort,ctb=v.ctb,win=win,hprate=hprate}
		local ctrl = 'internalapi'
		local act = 'finishAct1'
		obj:addApiCall(data,ctrl,act)
	end
end

--- 增加AI英雄
-- @param null
-- @return null
function World1004:addHeroAI()
	self:D("保卫雅典娜 屏蔽英雄AI")
end

--计算排行榜和积分
function World1004:updateRanks()
	if self.nextRanksTime<self.gameTime then
		self.ranksList={}
		for k,v in pairs(self.allItemList) do
			if v.attribute.actorType==0 then
				local h1 = v:getCounter('hurt')--伤害总量 hurt
				local h2 = v:getCounter('cure')--治疗总量 cure
				local h3 = v:getCounter('hurted')--受伤害总量 hurted
				local ctb=h1*self.ratio[1]+h2*self.ratio[2]+h3*self.ratio[3]
				self.ranksList[#self.ranksList+1]={itemID=v.itemID,ctb=ctb}
			end
		end


		self.tSort(self.ranksList,function( a1,b1 )
				return a1['ctb'] > b1['ctb']
			end)

		self:D("保卫雅典娜 排行榜",self.cjson.encode(self.ranksList))
		self.nextRanksTime=self.gameTime+5
	end
	

end


--- 加英雄在地圖
-- @param id int - 英雄角色id
-- @param team char - "A" or "B"
-- @param loginID string - 玩家名稱
-- @param posX integer - 出生x坐标
-- @param posY integer - 出生y坐标
-- @param actorID integer - 玩家ID
-- @param isAI boolean - 是否AI
-- @return heroObj SHero - 英雄object
function World1004:addHero(id,team,loginID,posX,posY,skin,actorID,isAI)
	--重载出生位置
	local s1 = string.splitNumber(self.setting.baseID,',')
	local toX,toY = self.formula:getRandomCirclePoint(s1[2],s1[3],5,true)

	return World1004.super.addHero(self,id,team,loginID,toX,toY,skin,actorID,isAI)
end

--增加主基地的血
function World1004:addBaseHP()
	self.baseObj:adjHP(self.baseObj.attribute.MaxHP*0.01,true)
end

--主基地放技能
function World1004:useBaseSkill(skillID)
	self.baseObj:addSkillList(skillID)
end



return World1004

