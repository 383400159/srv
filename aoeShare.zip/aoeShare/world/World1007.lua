local World1007 = class("World1007",require("gameroom.world.World1002"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World1007:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World1007"
	end

	World1007.super.ctor(self,gamePort,gameID,callBack)
	worldForHero = 1002
end

return World1007