local World1997 = class("World1997",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World1997:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World1997"
	end

	World1997.super.ctor(self,gamePort,gameID,callBack)
	worldForHero = 1997
end

function World1997:gengameRoomSetting()
	World1997.super.gengameRoomSetting(self)
	self.worldQTETime = 0
	--self:setAutoCreateHeroAISetting("A",true,3,0.5,{{169,279},{172,132},{171,75}},3)
	self:setAutoCreateHeroAISetting("B",true,15,0.5,{{210/2,147/2,1}},3,nil,nil,20)
end

---用于gen地图自动生成的物品
-- @param null
-- @return null
function World1997:genItem()
	World1997.super.genItem(self)
	--检测左右台子
	self:autoCreateHeroAI('A')
	self:autoCreateHeroAI('B')
end


--- 设置双方AI参数
-- @param team str - 队team
-- @param auto bool - 开启或者关闭
-- @param addNum int - 保持数量
-- @param cd int - 补充间隔 一个个出
-- @param intXYlist table - 出生点 格式 {{313.7/2,298.2/2,1},{313.7/2,298.2/2,2}}
-- @param initR int - 出生点随机落下的半径
-- @param subName str - 别名
-- @param tolist table - 寻路点 {{173.7/2,403.8/2},{173.7/2,403.8/2}}
-- @param lv int - ai Level
-- @return null
function World1997:setAutoCreateHeroAISetting(team,auto,addNum,cd,intXYlist,initR,subName,tolist,lv)
	if self.heroAISetting == nil then
		self.heroAISetting = {}
	end
	if self.isAITeam ==nil then
		local obj  = self.allItemList[1]
		if obj.attribute.roleId>=6 then
			self.isAITeam = 'NP'
		else
			self.isAITeam = 'YH'
		end
	end
	if lv==nil then
		lv=1
	end
	self.heroAISetting[team]={auto=auto,addNum=addNum,cd=cd,intXYlist=intXYlist,initR=initR,subName=subName,tolist=tolist,lv=lv} 
end

function World1997:autoCreateHeroAI(team)

	--判断有没开启
	if self.heroAISetting==nil or self.heroAISetting[team]==nil then

		return nil
	end

	if not self.heroAISetting[team].auto then

		return nil
	end

	if self.SCAI==nil then
		self.SCAI={A={},B={}}
	end

	if self.SCAI[team].ACHAIList ==nil then
		self.SCAI[team].ACHAIList = {}
		self.SCAI[team].nextAddHeroAITime = self.gameTime
	end

	if self.SCAI[team].nextAddHeroAITime + self.heroAISetting[team].cd < self.gameTime then
		self:D("生成AI.............")
		for k,v in pairs(self.SCAI[team].ACHAIList) do
			--死亡剔除
			if v==nil or v:isDead() then
				-- if v~=nil then
				-- 	v:addStatusList({s=42,r=self.gameTime,t=9999999,i=v.itemID},60)
				-- 	self.playerList[v.itemID]['online'] = false
				-- 	self.playerList[v.itemID]['offLineTime']=self.gameTime-self.gameRoomSetting.offlineRemoveWaitTime + 60
				-- end

				table.remove(self.SCAI[team].ACHAIList,k)
			end
		end

		--for i=1,(10-#self.ACHAIList) do
		if (self.heroAISetting[team].addNum-#self.SCAI[team].ACHAIList)>0 then
			local toX,toY = self.formula:getRandomCirclePoint(0,0,self.heroAISetting[team].initR)
			local r = 0
	
			if self.isAITeam=="NP" then
				if team=="A" then
					r = self.formula:getRandnum(6,10)
				else
					r = self.formula:getRandnum(1,5)
				end
			end

			if self.isAITeam=="YH" then
				if team=="B" then
					r = self.formula:getRandnum(6,10)
				else
					r = self.formula:getRandnum(1,5)
				end
			end

			local intXYlist = self.heroAISetting[team].intXYlist
			intXYlist = table.shuffle(intXYlist)
			local obj=self:createHeroAI(r,self.heroAISetting[team].lv,team,nil,intXYlist[1][1]+toX,intXYlist[1][2]+toY)
			self.SCAI[team].ACHAIList[#self.SCAI[team].ACHAIList+1] = obj
			if self.heroAISetting[team].subName~=nil then
				obj:setSubName(self.heroAISetting[team].subName) 
			end
			if self.heroAISetting[team].tolist~=nil then
				obj:moveTo(self.heroAISetting[team].tolist[intXYlist[1][3]][1]+toX,self.heroAISetting[team].tolist[intXYlist[1][3]][2]+toY,false,10)
				obj:addStatusList({s=76,r=self.gameTime,t=(obj.moveToEndTime-self.gameTime)+0.5,i=obj.itemID},0)
				obj:setAutoBlocked(false,(obj.moveToEndTime-self.gameTime)+0.5)
				if r==5 or r==10 then
					local CWobj  = self.allItemList[obj.CWID]
					if CWobj~=nil then
						CWobj.runAI = false
						CWobj.runMOVEAI = false
						CWobj:moveTo(self.heroAISetting[team].tolist[intXYlist[1][3]][1]+toX,self.heroAISetting[team].tolist[intXYlist[1][3]][2]+toY,false,10)
						CWobj.posX = self.heroAISetting[team].tolist[intXYlist[1][3]][1]+toX
						CWobj.posY = self.heroAISetting[team].tolist[intXYlist[1][3]][2]+toY

						CWobj.AIlastCoolDown = self:getGameTime() + (obj.moveToEndTime-self.gameTime)+0.5
						self:D("宠物过墙 :",obj.itemID,r,obj.CWID)
					else
						self:D("为什么宠物会为空:",obj.itemID,r,obj.CWID)
					end
				end
				
			end
			obj.attribute.AIRoleSetting['normalSkillList'] = {}
			obj.attribute.AIRoleSetting['targetRolePower'] = {1,1,1,1,1,1,1,1,1,1}
			
			--obj.isSmallAI = true
		end

		--end
		self.SCAI[team].nextAddHeroAITime = self.gameTime
	end
	

end

return World1997