local World3009 = class("World3009",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World3009:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World3009"
	end

	World3009.super.ctor(self,gamePort,gameID,callBack)
	worldForHero = 3009
end

return World3009

