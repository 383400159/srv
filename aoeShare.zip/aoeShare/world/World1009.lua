local World1009 = class("World1009",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World1009:ctor(gamePort,gameID,callBack)
	worldForHero = 1009
	
	if self.className==nil then
		self.className="World1009"
	end

	World1009.super.ctor(self,gamePort,gameID,callBack)
	worldForHero = 1009

	--self.gameRoomSetting['maxPlayer'] = 10
	self.gameRoomSetting['hasVisibleZone'] = true
	self.gameFlag['getFlagAID'] = 0
	self.gameFlag['getFlagBID'] = 0
	self.gameFlag['waitGetFlagAID'] = {}
	self.gameFlag['waitGetFlagBID'] = {}
	self.gameFlag['flagAID'] = 0
	self.gameFlag['flagBID'] = 0
	self.gameFlag['flagTableAID'] = 0
	self.gameFlag['flagTableBID'] = 0
	self.gameFlag['isGameOver'] = false
	self.gameFlag['winTeam'] = ''
	self.gameFlag['syncPointsTime'] = 0
	self.gameFlag['syncEndInfo'] = false
	self.comFlag['teamDebug'] = false
	
	self.frameOut = {}
	self.frameMid = {}
	self.frameIn = {}
	self.frameHigh = {}
	self.frameASilver = {}
	self.frameBSilver = {}

	self:getAllPotion()
end

--- 加英雄在地圖
-- @param id int - 英雄角色id
-- @param team char - "A" or "B"
-- @param loginID string - 玩家名稱
-- @param posX integer - 出生x坐标
-- @param posY integer - 出生y坐标
-- @param actorID integer - 玩家ID
-- @return heroObj SHero - 英雄object
-- function World1009:addHero(id,team,loginID,posX,posY,skin,actorID)
-- 	local pos
-- 	if team=="A" then
-- 		pos = string.splitNumber(self.setting['heroAInitialPosition'], ',')
-- 	else
-- 		pos = string.splitNumber(self.setting['heroBInitialPosition'], ',')
-- 	end
-- 	if posX==nil or posY==nil then
-- 		posX = pos[1]
-- 		posY = pos[2]
-- 	end
-- 	local hero = World1009.super.addHero(self,id,team,loginID,posX,posY,skin,actorID)
-- 	return hero
-- end

---用于gen地图自动生成的物品
-- @param null
-- @return null
function World1009:genItem()
	for k,v in pairs(self.genPotion) do
		if v['last']<self.gameTime and self.allItemList[v['itemID']]==nil then
			-- local id = self:addPotionOnMap(v['type'],v['posX'],v['posY'])
			-- self:debuglog('jaylog World1009:genItem addPotionOnMap:',k,self.cjson.encode(v),id)
			-- self.genPotion[k]['itemID'] = id
			-- self.genPotion[k]['last'] = self.gameTime
		end
	end
end

--- RUNNING中 gameOver 检查
-- @return result bool - 是否gameOver
function World1009:gameOverCheck()
	local result = false
	result = World1009.super.gameOverCheck(self)

	if self.status~=self.GAMEOVER and self.gameStartTime>0 and self.gameRoomSetting['gameLimitedTime']+self.gameStartTime<=self:getGameTime() then
	 --self:gameOver()
	 result = true
	end

	if self.status~=self.GAMEOVER and self.gameFlag['isGameOver'] then
	 --self:gameOver()
	 result = true
	end

	return result
end

--生成传送门
function World1009:genTransitDoor()
	-- test
	--self.map:addTmpBlockByLine(65,150,55,132,99999,1)
	--self:addMonster(140,60,140,'A',99999,'')
end

--- init时部分游戏房设置赋setting值
-- @param null
-- @return null
function World1009:gengameRoomSetting()
	-- 用setting值把gameRoomSetting部分值重置
	if self.setting['win_energy']~=nil then
		self.gameRoomSetting['gameLimitedPoints'] = self.setting['win_energy']
	end
	if self.setting['enemy_energy']~=nil then
		self.gameRoomSetting['enemyEnergy'] = self.setting['enemy_energy']
	end
	if self.setting['kill_energy']~=nil then
		self.gameRoomSetting['killEnergy'] = self.setting['kill_energy']
	end
	if self.setting['mode_Time']~=nil then
		self.gameRoomSetting['gameLimitedTime'] = self.setting['mode_Time']
	end
	self.frameOut = table.deepcopy(self:splitFrame(self.setting['mapFrameOut']))
	self.frameMid = table.deepcopy(self:splitFrame(self.setting['mapFrameMiddle']))
	self.frameIn = table.deepcopy(self:splitFrame(self.setting['mapFrameIn']))
	self.frameHigh = table.deepcopy(self:splitFrame(self.setting['mapFrameHigh']))
	self.frameASilver = table.deepcopy(self:splitFrame(self.setting['mapFrameWarnA']))
	self.frameBSilver = table.deepcopy(self:splitFrame(self.setting['mapFrameWarnB']))
	--debuglog('jaylog World1009:gengameRoomSetting frameOut:'..self.cjson.encode(self.frameOut)..' frameMid:'..self.cjson.encode(self.frameMid)..' frameIn:'..self.cjson.encode(self.frameIn)..' frameHigh:'..self.cjson.encode(self.frameHigh))

	--获取地上物品设置
	local settingLocal = self.setting
	--增加野怪
	local potion1IDlist = self.sSplitNumber(settingLocal['potion1ID'],';')
	local potionNum = self.tNums(potion1IDlist)
	local potion1Typelist = self.sSplit(settingLocal['potion1Type'],';')
	local potionXY = {}
	for k,v in pairs(potion1Typelist) do
		potionXY[k] = self.sSplitNumber(v,',')
	end

	for k,v in pairs(potion1IDlist) do
		self.genPotion[#self.genPotion+1] = {
			type = v,
			time = 30,
			posX = potionXY[k][1],
			posY = potionXY[k][2],
			itemID = 0,
			last = 0,
			group = 'A',
			--team = ''
		}
		self.genPotionGroup['A'] = 30   --怪物死后刷新时间
	end
	self:D('jaylog World1009:gengameRoomSetting genPotion:',self.cjson.encode(self.genPotion))

	--召唤神龙
	local creatureID=self:addCreature(self.tostring(537),"A",43.9/2,150.8/2,nil,1,0)
	local obj  = self.allItemList[creatureID]
	--obj:addStatusList({s=76,r=self.gameTime,t=9999,i=obj.itemID},0)
	local creatureID=self:addCreature(self.tostring(537),"B",181/2,277/2,nil,1,0)
	local obj  = self.allItemList[creatureID]
	--obj:addStatusList({s=76,r=self.gameTime,t=9999,i=obj.itemID},0)


end

-- 拆分坐标范围string to table
function World1009:splitFrame(frameStr)
	local mapFrame = {}
	local mapFrameOut1 = string.split(frameStr,';')
	for k,v in pairs(mapFrameOut1) do
		local mapFrameOut2 = string.split(v,'_')
		local tmpFrame = {}
		for k1,v1 in pairs(mapFrameOut2) do
			tmpFrame[#tmpFrame+1] = string.splitNumber(v1,',')
		end
		mapFrame[#mapFrame+1] = table.deepcopy(tmpFrame)
	end
	--debuglog('jaylog World1009:splitFrame mapFrame:'..self.cjson.encode(mapFrame))
	return mapFrame
end

-- 检测是否在范围内
function World1009:inFrame(frameTable,x,y)
	local result = false
	for k,v in pairs(frameTable) do
		--debuglog('jaylog k:'..k..' v:'..self.cjson.encode(v)..' v11:'..v[1][1]..' v21:'..v[2][1]..' v12:'..v[1][2]..' v22:'..v[2][2]..' x:'..x..' y:'..y)
		if v[1][1]>v[2][1] then
			if v[2][1]<x and x<v[1][1] and v[2][2]<y and y<v[1][2] then
				result = true
				return result
			end
		else
			if v[1][1]<x and x<v[2][1] and v[1][2]<y and y<v[2][2] then
				result = true
				return result
			end
		end
	end
	return result
end

--- init时生成地图出生怪物设置
-- @param null
-- @return null
function World1009:genMonsterSetting()
	World1009.super.genMonsterSetting(self)
	self.genMonster = {}
	self.genMonsterGroup = {}
	self.genMonsterGroupLevel = {}
	local settingLocal = self.setting
	--开场水晶
	for k,v in pairs({'A','B'}) do
		self.genMonster[#self.genMonster+1] = {
			mtype = settingLocal['energy'..v..'Type'],
			time = 0,
			posX = self.tonumber(settingLocal['energy'..v..'CoordinateX']),
			posY = self.tonumber(settingLocal['energy'..v..'CoordinateY']),
			itemID = 0,
			last = 0,
			group = v,
			team = '',
		}
		self.genMonsterGroup[v] = 9999			--怪物死后刷新时间
		self.genMonsterGroupLevel[v] = 1 	--按组设置级别
	end
	self:D('jaylog World1009:genMonsterSetting genMonster:',self.cjson.encode(self.genMonster))
	for k,v in pairs(self.genMonster) do
		-- self:D('jaylog World1009:genMonsterSetting v:',self.cjson.encode(v),' k:',k)
		self:addMonster(v.mtype,v.posX,v.posY,v.group,self.genMonsterGroup[v.group],v.team)
		self:addMonster(139+k,v.posX,v.posY,v.group,self.genMonsterGroup[v.group],v.team)
	end
	--self:addMonster(101,60,22,'B',1,'B')
end

--- 生成怪物
-- @param id int - 怪物ID
-- @param x int - 怪物出生点x坐标
-- @param y int - 怪物出生点y坐标
-- @param group string - 怪物的组别，每个点的怪物可分成一组
-- @param level int - 怪物出生的级别
-- @param team string - 战场中的分队
-- @return itemID int - 怪物ID
function World1009:addMonster(id,x,y,group,level,team)
	local monsterID = World1009.super.addMonster(self,id,x,y,group,level,team)
	id = self.tonumber(id)
	if group~=nil and id~=997 and id~=998 then
		if id~=140 and id~=141 then
			local monsterObj = self.allItemList[monsterID]
			monsterObj.flagType = group
			self.gameFlag['flag'..group..'ID'] = monsterID
			local lifeTime=99999
			local attributes = {}
			attributes['buffParameter']={}
			attributes['BUFFONLY']=1
			attributes['INEVITABLEHIT'] = 1
			attributes['buffParameter']['RANGE'] = monsterObj.attribute.width * self.setting.AdjustAttRange
			--attributes['buffParameter']['INEVITABLEHIT'] = 1
			attributes['buffParameter']['creatureDirectHurCallBack'] = monsterID
			attributes['buffParameter']['buffIntervalTime'] = 0.3
			attributes['buffParameter']['buffType'] = 1
			attributes['buffParameter']['Effect'] = -1
			attributes['BUFFTIME'] = 99999
			self:D('jaylog addMonster buff:',self.cjson.encode(attributes),' id',id,' x',x,' y',y,' g',group,' lv',level,' t',team,' itemID',monsterID)
			local buff = require("gameroomcore.SBuff").new(self,monsterObj:__skillID2buffID(0),attributes,lifeTime,{99},0,monsterID,monsterID,0.1)
			--buff.debug = true
			monsterObj:addBuff(buff)
		else
			self.gameFlag['flagTable'..group..'ID'] = monsterID
		end
	end
	return monsterID
end

--- 在游戏loop中生成某些信息
-- @param null
-- @return null
function World1009:genSomeInfo()
	for k,v in pairs(self.itemListFilter.heroList) do
		local goOn = true
		if self:inFrame(self.frameIn,v.posX,v.posY) and goOn then
			if (v.statusList[997]~=nil and v.statusList[997]['p1']~=4) or v.statusList[997]==nil then
				--debuglog('jaylog add frameIn itemID'..v.itemID..' x'..v.posX..' y'..v.posY)
				v:addStatusList({s=997,r=self.gameTime,t=9999,p1=4})
			end
			goOn = false
		end
		if self:inFrame(self.frameMid,v.posX,v.posY) and goOn then
			if (v.statusList[997]~=nil and v.statusList[997]['p1']~=3) or v.statusList[997]==nil then
				--debuglog('jaylog add frameMid itemID'..v.itemID..' x'..v.posX..' y'..v.posY)
				v:addStatusList({s=997,r=self.gameTime,t=9999,p1=3})
			end
			goOn = false
		end
		if self:inFrame(self.frameOut,v.posX,v.posY) and goOn then
			if (v.statusList[997]~=nil and v.statusList[997]['p1']~=2) or v.statusList[997]==nil then
				--debuglog('jaylog add frameOut itemID'..v.itemID..' x'..v.posX..' y'..v.posY)
				v:addStatusList({s=997,r=self.gameTime,t=9999,p1=2})
			end
			goOn = false
		end
		if self:inFrame(self.frameHigh,v.posX,v.posY) and goOn then
			if (v.statusList[997]~=nil and v.statusList[997]['p1']~=1) or v.statusList[997]==nil then
				--debuglog('jaylog add frameHigh itemID'..v.itemID..' x'..v.posX..' y'..v.posY)
				v:addStatusList({s=997,r=self.gameTime,t=9999,p1=1})
			end
			goOn = false
		end
		if self.allItemList[self.gameFlag['flagAID']]==nil or (self.allItemList[self.gameFlag['flagAID']]~=nil and self.allItemList[self.gameFlag['flagAID']].attribute.roleId~=137) then
			if v.statusList[37]~=nil and self:inFrame(self.frameBSilver,v.posX,v.posY) and v.lastWarnTime<self.gameTime then
					self:D('jaylog notice 37 137 id:',v.itemID)
					v:updateSyncMsg({bc={{zz=3,mid=55,i=v.itemID}}})
					v.lastWarnTime = self.gameTime + 1
			end
		end
		if self.allItemList[self.gameFlag['flagBID']]==nil or (self.allItemList[self.gameFlag['flagBID']]~=nil and self.allItemList[self.gameFlag['flagBID']].attribute.roleId~=101) then
			if v.statusList[51]~=nil and self:inFrame(self.frameASilver,v.posX,v.posY) and v.lastWarnTime<self.gameTime then
					self:D('jaylog notice 51 101 id:',v.itemID)
					v:updateSyncMsg({bc={{zz=3,mid=55,i=v.itemID}}})
					v.lastWarnTime = self.gameTime + 1
			end
		end
	end
	if self.gameFlag['syncPointsTime']<self.gameTime then
		self:syncPointsInfo()
		self.gameFlag['syncPointsTime'] = self.gameTime + 5
	end
end

-- 发送分数给client
function World1009:syncPointsInfo()
	local game = {
		pointsA = self.gameCounter['pointsA'],
		pointsB = self.gameCounter['pointsB'],
	}
	self:addSyncMsg({game=game})
	local gameInfo
	if not self.gameFlag['syncEndInfo'] and self.gameStartTime>0 and (self.gameTime-self.gameStartTime)>(self.gameRoomSetting['gameLimitedTime']-30) then
		gameInfo = {{part=8,mType=3}}
		-- gameInfo['part'] = 8
		-- gameInfo['mType'] = 3
		self.gameFlag['syncEndInfo'] = true
	end
	self:addSyncMsg({gameinfo=gameInfo})
end

--- client端初始化房间设置
-- @param data table - client传上来的数据
-- @return data table - 原数据返回
--function World1009:clientGameInit(data)
	-- if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==5 then
	-- 	if self.itemListFilter.heroList[data['roleID']].team=='A' then
	-- 		debuglog('jaylog World1009:clientGameInit add status 995 gameTime:'..self.gameTime)
	-- 		if self.itemListFilter.heroList[data['roleID']].statusList[995]==nil then
	-- 			self.itemListFilter.heroList[data['roleID']]:addStatusList({s=995,r=self.gameTime,t=9999},0.1)
	-- 		end
	-- 		for k,v in pairs(self.itemListFilter.heroList[data['roleID']].statusList) do
	-- 			debuglog('jaylog World1009:clientGameInit status '..self.cjson.encode(v)..' itemID:'..data['roleID'])
	-- 		end
	-- 	end
	-- end
	-- return World1009.super.clientGameInit(self,data)
--end

-- function World1009:addHero(id,team,loginID,posX,posY,skin,actorID)
-- 	local hero = World1009.super.addHero(self,id,team,loginID,posX,posY,skin,actorID)
-- 	if self.itemListFilter.heroList[hero.itemID].team=='A' then
-- 		debuglog('jaylog World1009:addHero add status 995 gameTime:'..self.gameTime)
-- 		if self.itemListFilter.heroList[hero.itemID].statusList[995]==nil then
-- 			self.itemListFilter.heroList[hero.itemID]:addStatusList({s=995,r=self.gameTime,t=9999})
-- 		end
-- 	end
-- 	return hero
-- end

--- 游戏房结算,结算sql,组织gameOverMsg,call api结算统计
-- @param null
-- @return null
function World1009:gameOverOrg()
	--print(debug.traceback("", 2))
	self:D("jaylog start  gameOver...")
	-- new game over step start
	local winner = self.gameFlag['winTeam']
	local winarr = {}
	local newAPIparameterArray = {}
	local bonus = {}
	local bonusStr = ''
	local tmpbonus = {}

	for k,v in pairs(self.itemListFilter.heroList) do
		winarr[""..v.itemID] = 0
		if v.team==winner then
			winarr[""..v.itemID] = 1
		else
			if winner=='' then
				if self.gameCounter['pointsA']==self.gameCounter['pointsB'] then
					winarr[""..v.itemID] = 2
				elseif self.gameCounter['pointsA']>self.gameCounter['pointsB'] then
					if v.team=='A' then
						winarr[""..v.itemID] = 1
					end
				elseif self.gameCounter['pointsA']<self.gameCounter['pointsB'] then
					if v.team=='B' then
						winarr[""..v.itemID] = 1
					end
				end
			end
		end

		if (bonus[v.itemID]==nil) then
			bonus[v.itemID] = {}
		end
		bonus[v.itemID][#bonus[v.itemID]+1] = {
			d=1,
			i=55001,
			q=1
		}
	end

	local count=0
	for i=1,self.gameRoomSetting['maxPlayer'] do
		if (isset(self.playerList[i])) then
			count = count + 1
		end
	end

	-- save game_result --
	local sql = "update game_result set status=1,"
	.."starttime='"..os.date("%Y%m%d%H%M%S",(os.time()-math.ceil(self.startTime)))
	.."', gametime='"..self.gameTime
	.."', endtime='"..os.date("%Y%m%d%H%M%S",os.time())
	.."', mapmodel='"..self.mapModel
	.."', outcome='"..winner
	.."', scoreA='"..self.gameCounter['pointsA']
	.."', scoreB='"..self.gameCounter['pointsB']
	.."',isSurrender='"..(self.surrenderTeam~="" and 1 or 0)
	.."',trySurrender='"..self.trySurrender
	.."',peopleCount='"..count
	.."' where gameID='"..self.gameID.."'"
	debuglog('sql 1 :'..sql)
	self:saveDBData(sql)

	-- gameScore table --
	local gameOverMsgScore = {}
	self.gameOverMsg['game']['reset'] = 1
	self.gameOverMsg['game']['pointsA'] = self.gameCounter['pointsA']
	self.gameOverMsg['game']['pointsB'] = self.gameCounter['pointsB']
	self.gameOverMsg['game']['gameTime'] = self.mCeil(self.gameTime)
	self.gameOverMsg['game']['w'] = 1 	--winarr
	--self.gameOverMsg['game']['bonus'] = bonus

	for i=1,self.gameRoomSetting['maxPlayer'] do
		if (isset(self.playerList[i])) then
			--[[
			local gameScore = {
				i = self.playerList[i]['i'],
				id = self.playerList[i]['id'],
				p = self.playerList[i]['p'],
				t = self.playerList[i]['t'],
				points = self.allItemList[i]['counter']['points'],
				bonus = bonus[i]
			}
			gameOverMsgScore[i]=gameScore
			]]
			local StartStr='1'
			local exp = 0
			local heroexp = 0
			local adjGold = 0
			local penalty = 0
			local newRank = 0
			local powreduce = 0
			local mvpplayerid = 0
			local point = 0
			local gold = 0
			local isWin = 0
			local bonusStr = ''
			local tmpbonus = {}
			local serverIP=""
			if (isset(self.playerList[i]['commip'])) then
				serverIP=self.playerList[i]['commip']
			end

			local newAPIparameter = {
						start=StartStr,
						game_id=self.gameID,
						exp=exp,								--exp+vipexp+itemexp+extraExp
						silver=gold,							--gold+vipgold+itemgold+mvpgold
						hero_id=self.playerList[i]['a'],
						play_win=isWin==1 and 1 or 0,
						play_lose=isWin==0 and 1 or 0,
						play_draw=isWin==2 and 1 or 0,
						penalty=(penalty>0 and 1 or 0),
						play_hero_kill=self.gameCounter['killhero'],
						play_assist_kill=0,							--self.gameCounter['killassistant']
						play_dead=self.gameCounter['killed'],
						--play_vs_random=(self.gameModel~=nil and self.gameModel==10) and 0 or (gamemode==1 and 1 or 0),
						--play_vs_33=(self.gameModel~=nil and self.gameModel==10) and 0 or (gamemode==2 and 1 or 0),
						--play_vs_ai=gamemode==3 and 1 or 0,
						--play_vs_guild=gamemode==4 and 1 or 0,
						--play_vs_training=(self.gameModel~=nil and self.gameModel==10) and 0 or (gamemode==6 and 1 or 0),
						--play_vs_team=self.isTeam and 1 or 0,
						--play_vs_gambling=(self.gameModel~=nil and self.gameModel==10) and 1 or 0,
						rank=newRank,
						play_time=self.gameTime,
						powreduce=powreduce,
						mapmodel=self.gameModel,
						player_rebirth=self.allItemList[i].counter['revive'],
						adjCoin=1000,				--adjCoin
						mvplist=0				--mvpplayerid
			}
			if bonus[i]~=nil then
				for kkk,vvv in pairs(bonus[i]) do
					tmpbonus[#tmpbonus+1]=vvv['i']..","..vvv['q']
					newAPIparameter['itemAchieve_'..vvv['i']] = vvv['q']
				end
				bonusStr=implode(';',tmpbonus)
			end
			newAPIparameterArray[self.sFormat(self.playerList[i]['p'])] = newAPIparameter
			--debuglog('start to save newAPIparameterArray'..self.cjson.encode(newAPIparameter)..'   '..self.playerList[i]['p']..'  '..self.cjson.encode(newAPIparameterArray))

			if self.playerList[i]['recnt'] ==nil then
				self.playerList[i]['recnt'] =0
			end

			if self.allItemList[i].team==winner then
				isWin = 1
				newRank = 5
			else
				if winner=='' then
					if self.gameCounter['pointsA']==self.gameCounter['pointsB'] then
						-- 平局
						isWin = 2
					elseif self.gameCounter['pointsA']>self.gameCounter['pointsB'] then
						if self.allItemList[i].team=='A' then
							isWin = 1
						end
					elseif self.gameCounter['pointsA']<self.gameCounter['pointsB'] then
						if self.allItemList[i].team=='B' then
							isWin = 1
						end
					end
				end
				newRank = 1
			end

			--保存每个玩家战斗记录--
			sql = "insert into game_player_result (updatetime,createtime,gameID,playerID,camp,win,hero,level,equip1,equip2,equip3,equip4,equip5,equip6,equip1stlvl1,equip1stlvl3,"..
				"Struck,Killed,KillBoss,hurted,hurt,getFlag,cure,gold,exp,skill1,skill2,skill3,skill4,skill1st,skillkill1,skillkill2,skillkill3,skillkill4,fastRevive,ipaddr,ping,totalIdle,maxIdle,point,newRank,serverIP,bonus,gamePoint,prizeOperate,mvp,banHero) values (now(),now(),'"..
				self.gameID.."','"..																								--gameID
				self.playerList[i]['p'].."','"..																		--playerID
				self.allItemList[i].teamOrig.."','"..																--camp
				(isWin).."','"..																										--win
				self.playerList[i]['a'].."','"..																		--hero roleID
				self.allItemList[i].attribute.level.."','"..												--level
				"','"..														--equip1
				"','"..														--equip2
				"','"..														--equip3
				"','"..														--equip4
				"','"..														--equip5
				"','"..														--equip6
				gold.."','"..																												--equip1stlvl1
				exp.."','"..																												--equip1stlvl3
				self.allItemList[i]:getCounter('killhero').."','"..									--Struck										--self.allItemList[i].counter['killhero'].."','"..
				self.allItemList[i]:getCounter('killed').."','"..										--Killed										--self.allItemList[i].counter['killed'].."','"..
				self.allItemList[i]:getCounter('killboss').."','"..										--KillBoss
				self.mAbs(self.allItemList[i]:getCounter('hurted')).."','"..				--Assists										--self.allItemList[i].counter['killassistant'].."','"..
				self.mAbs(self.allItemList[i]:getCounter('hurt')).."','"..					--KillSoldiers							--self.allItemList[i].counter['killsoldier'].."','"..
				self.allItemList[i]:getCounter('getFlag').."','"..									--KillTowers								--self.allItemList[i].counter['killTower']
				self.mAbs(self.allItemList[i]:getCounter('cure')).."','"..					--killMonsters							--self.allItemList[i].counter['killmonster'].."','"..
				gold.."','"..																												--gold
				exp.."','"..																												--exp
				"0','"..																														--skill1
				"0','"..																														--skill2
				"0','"..																														--skill3
				"0','"..																														--skill4
				self.playerList[i]['recnt'].."','"..																--skill1st
				"0','"..																														--skillkill1
				"0','"..																														--skillkill2
				"0','"..																														--skillkill3
				"0','"..																														--skillkill4
				"0','"..																														--fastRevive
				self.allItemList[i].ipaddress.."','"..															--ipaddr
				self.allItemList[i].pingtime.."','"..																--ping
				self.allItemList[i].totalIdleTime.."','"..													--totalIdle
				self.allItemList[i].maxIdleTime.."','"..														--maxIdle
				point.."','"..																											--point
				newRank.."','"..																										--newRank
				serverIP.."','"..																										--serverIP
				bonusStr..																													--bonus
				"','0','"..																													--gamePoint
				(self.allItemList[i].skinNum~=nil and self.allItemList[i].skinNum or 0)..  		--prizeOperate
				"','0','"..																																		--mvp
				i.."')"																																			--banHero    玩家房间顺序ID
			debuglog('sql 2 every player : '..sql)

			if ( self.tonumber(self.playerList[i]['p']) >0) then
				self:saveDBData(sql)
			end
			debuglog('newAPIparameter : '..self.cjson.encode(newAPIparameter) ..' p: '..self.cjson.encode(self.playerList[i]['p']))
		end
	end
	
	--self.gameOverMsg['game']['gameScore'] = gameOverMsgScore
	debuglog('gameOverMsg : '..self.cjson.encode(self.gameOverMsg))

	self.gameOverStatistic={}
	for k,value in pairs(self.itemListFilter.heroList) do
		self.gameOverStatistic[value.itemID] = {
			i = value.itemID,
			killhero = value.counter['killhero'],
			hilled = value.counter['killed'],
			hurted = value.counter['hurted'],
			hurt = value.counter['hurt'],
			cure = value.counter['cure'],
			getFlag = value.counter['getFlag'],
			points = value.counter['points']
		}
	end

	--战斗结算call api
	local finishapi = self.webapiurl..'internalapi/finishGameRoomMutil'
	local finishapi2 = self.webapiurl2..'internalapi/finishGameRoomMutil'
	debuglog('newAPIparameterArray...........:' .. self.cjson.encode( newAPIparameterArray ) )
	local url=finishapi..'/?data='..string.urlencode(self.cjson.encode(newAPIparameterArray))..'&version=999'
	local webresult=self:file_get_contents(url)
	if (webresult==false) then
		url=finishapi2..'/?data='..string.urlencode(self.cjson.encode(newAPIparameterArray))..'&version=999'
		webresult=self:file_get_contents(url)
	end
	debuglog('url : '..url..' result:'..webresult)

	-- 玩家离开清除房间玩家数据 --
	local players={}
	for i=1,self.gameRoomSetting['maxPlayer'] do
		if (isset(self.playerList[i]) and self.playerList[i]['online']==false) then
			if self.gameRoomSetting['hasMapZone']~=true and (self.tonumber(self.playerList[i]['p'])>0) then
				self:redisCall('srem','room0',self.playerList[i]['p'])
			end
			if (self.tonumber(self.playerList[i]['p'])>12) then
				rc = {i=0,m=self.playerList[i]['id'].." 离开了房间",t="",d=0}
				self:addSyncMsg({rc=rc})
			end
			--self.playerList[i]=nil
		elseif (isset(self.playerList[i])) then
			players[self.playerList[i]['p']]=self.playerList[i]
			if self.gameRoomSetting['hasMapZone']~=true and (self.tonumber(self.playerList[i]['p'])>0) then
				self:redisCall('srem','room0',self.playerList[i]['p'])
			end
		end
	end
	players['END']=true
	self:setPlayerListMemcache(players)
	debuglog("有没有call到结束/////////////")
	self.gameOverTime = self.gameTime
	self.status=self.GAMEOVER


	-- new game over step end
end

function World1009:statusRUNNING()
	World1009.super.statusRUNNING(self)
	-- if self.gameTime>60 then
	-- 	self.gameFlag['isGameOver'] = true
	-- end
end

--- clientside操作 取得英雄資料
-- @param id int - 玩家的itemID
-- @param hero int - 查看的英雄itemID, 如無 全部英雄
-- @return heroInfo table - 英雄資料訊息
function World1009:heroInfo(id,hero)
	if self.itemListFilter.heroList[id]~=nil then
		local statistic = {}
		if hero==0 then
			if self.gameOverStatistic~=nil then
				statistic = table.deepcopy(self.gameOverStatistic)
			else
				local hurtedTotal,hurtTotal,cureTotal = 0,0,0
				local hurtedinallLast,hurtinallLast,cureinallLast = 0,0,0
				local hurtedP,hurtP,cureP = 0,0,0
				local hurtedMax,hurtMax,cureMax = 0,0,0
				local hurtedTotalB,hurtTotalB,cureTotalB = 0,0,0
				local hurtedinallLastB,hurtinallLastB,cureinallLastB = 0,0,0
				local hurtedPB,hurtPB,curePB = 0,0,0
				local hurtedMaxB,hurtMaxB,cureMaxB = 0,0,0
				for k,v in pairs(self.itemListFilter.heroList) do
					if v.actorType==0 and v.parent==nil and v.teamOrig=='A' then
						self:D('jaylog heroInfo1 loginID',v.loginID)
						hurtedTotal = hurtedTotal + self.mAbs(v:getCounter('hurted'))
						hurtTotal = hurtTotal + self.mAbs(v:getCounter('hurt'))
						cureTotal = cureTotal + self.mAbs(v:getCounter('cure'))
					end
					if v.actorType==0 and v.parent==nil and v.teamOrig=='B' then
						self:D('jaylog heroInfo1 B loginID',v.loginID)
						hurtedTotalB = hurtedTotalB + self.mAbs(v:getCounter('hurted'))
						hurtTotalB = hurtTotalB + self.mAbs(v:getCounter('hurt'))
						cureTotalB = cureTotalB + self.mAbs(v:getCounter('cure'))
					end
				end
				-- self:D('jaylog heroInfo het:',hurtedTotal,' ht:',hurtTotal,' ct:',cureTotal)
				for k,v in pairs(self.itemListFilter.heroList) do
					if v.actorType==0 and v.parent==nil then
						self:D('jaylog heroInfo2 loginID',v.loginID)
						local hurtedinall,hurtinall,cureinall = 0,0,0
						if v.teamOrig=='A' and hurtedTotal~=0 then
							hurtedinall = self.mFloor(self.mAbs(v:getCounter('hurted'))/hurtedTotal*100)
							hurtedP = hurtedP + hurtedinall
							if hurtedinallLast<hurtedinall then
								hurtedMax = v:getID()
								hurtedinallLast = hurtedinall
							end
							-- self:D('jaylog heroInfo ',self.mAbs(v:getCounter('hurted'))/hurtedTotal)
						end
						if v.teamOrig=='A' and hurtTotal~=0 then
							hurtinall = self.mFloor(self.mAbs(v:getCounter('hurt'))/hurtTotal*100)
							hurtP = hurtP + hurtinall
							if hurtinallLast<hurtinall then
								hurtMax = v:getID()
								hurtinallLast = hurtinall
							end
							-- self:D('jaylog heroInfo ',self.mAbs(v:getCounter('hurt'))/hurtTotal)
						end
						if v.teamOrig=='A' and cureTotal~=0 then
							cureinall = self.mFloor(self.mAbs(v:getCounter('cure'))/cureTotal*100)
							cureP = cureP + cureinall
							if cureinallLast<cureinall then
								cureMax = v:getID()
								cureinallLast = cureinall
							end
							-- self:D('jaylog heroInfo ',self.mAbs(v:getCounter('cure'))/cureTotal)
						end
						if v.teamOrig=='B' and hurtedTotal~=0 then
							hurtedinall = self.mFloor(self.mAbs(v:getCounter('hurted'))/hurtedTotalB*100)
							hurtedPB = hurtedPB + hurtedinall
							if hurtedinallLastB<hurtedinall then
								hurtedMax = v:getID()
								hurtedinallLast = hurtedinall
							end
							-- self:D('jaylog heroInfo ',self.mAbs(v:getCounter('hurted'))/hurtedTotal)
						end
						if v.teamOrig=='B' and hurtTotal~=0 then
							hurtinall = self.mFloor(self.mAbs(v:getCounter('hurt'))/hurtTotalB*100)
							hurtPB = hurtPB + hurtinall
							if hurtinallLastB<hurtinall then
								hurtMaxB = v:getID()
								hurtinallLastB = hurtinall
							end
							-- self:D('jaylog heroInfo ',self.mAbs(v:getCounter('hurt'))/hurtTotal)
						end
						if v.teamOrig=='B' and cureTotal~=0 then
							cureinall = self.mFloor(self.mAbs(v:getCounter('cure'))/cureTotalB*100)
							curePB = curePB + cureinall
							if cureinallLastB<cureinall then
								cureMaxB = v:getID()
								cureinallLastB = cureinall
							end
							-- self:D('jaylog heroInfo ',self.mAbs(v:getCounter('cure'))/cureTotal)
						end
						-- statistic[v:getID()] = {i=v:getID(),kh=v:getCounter('killhero'),ks=v:getCounter('killsoldier')+v:getCounter('killmonster'),
						-- kd=v:getCounter('killed'),ka=v:getCounter('killassistant'),eq1=v.equipList[1],eq2=v.equipList[2],eq3=v.equipList[3],eq4=v.equipList[4],
						-- eq5=v.equipList[5],eq6=v.equipList[6],eq7=v.equipList[7],l=v.attribute.level,t=v.teamOrig,
						-- hurted=self.mAbs(v:getCounter('hurted')),hurt=v:getCounter('hurt'),cure=self.mAbs(v:getCounter('cure')),
						-- getFlag=v:getCounter('getFlag'),points=v:getCounter('points')}
						-- self:D('jaylog heroInfo id:',k,' roleId:',v.attribute.roleId,' cure',v:getCounter('cure'),' hurted',self.mAbs(v:getCounter('hurted')),' hurt',self.mAbs(v:getCounter('hurt')),' cure',self.mAbs(v:getCounter('cure')))
						statistic[v:getID()] = {i=v:getID(),kh=v:getCounter('killhero'),ks=v:getCounter('killsoldier')+v:getCounter('killmonster'),
						kd=v:getCounter('killed'),ka=v:getCounter('killassistant'),l=v.attribute.level,t=v.teamOrig,kb=v:getCounter('killboss'),
						hurted=self.mAbs(v:getCounter('hurted')),hurt=v:getCounter('hurt'),cure=self.mAbs(v:getCounter('cure')),
						getFlag=v:getCounter('getFlag'),points=v:getCounter('points'),hurtedinall=hurtedinall,hurtinall=hurtinall,cureinall=cureinall,
						scorefin=v.attribute.school}
						self:D('jaylog heroInfo statistic:',self.cjson.encode(statistic))
					end
				end
				if hurtedP<100 and statistic[hurtedMax]~=nil and statistic[hurtedMax]['hurtedinall']~=nil then
					statistic[hurtedMax]['hurtedinall'] = statistic[hurtedMax]['hurtedinall']+100-hurtedP
				end
				if hurtP<100 and statistic[hurtMax]~=nil and statistic[hurtMax]['hurtinall']~=nil then
					statistic[hurtMax]['hurtinall'] = statistic[hurtMax]['hurtinall']+100-hurtP
				end
				if cureP<100 and statistic[cureMax]~=nil and statistic[cureMax]['cureinall']~=nil then
					statistic[cureMax]['cureinall'] = statistic[cureMax]['cureinall']+100-cureP
				end
				if hurtedPB<100 and statistic[hurtedMaxB]~=nil and statistic[hurtedMaxB]['hurtedinall']~=nil then
					statistic[hurtedMaxB]['hurtedinall'] = statistic[hurtedMaxB]['hurtedinall']+100-hurtedPB
				end
				if hurtPB<100 and statistic[hurtMaxB]~=nil and statistic[hurtMaxB]['hurtinall']~=nil then
					statistic[hurtMaxB]['hurtinall'] = statistic[hurtMaxB]['hurtinall']+100-hurtPB
				end
				if curePB<100 and statistic[cureMaxB]~=nil and statistic[cureMaxB]['cureinall']~=nil then
					statistic[cureMaxB]['cureinall'] = statistic[cureMaxB]['cureinall']+100-curePB
				end
			end
			local t = {}
			t[#t+1] = statistic[id]
			for k,v in pairs(statistic) do
				if v['t']==self.itemListFilter.heroList[id].teamOrig and k~=id then
					t[#t+1] = v
				end
			end
			for k,v in pairs(statistic) do
				if v['t']~=self.itemListFilter.heroList[id].teamOrig and k~=id then
					t[#t+1] = v
				end
			end
			statistic = t
		end
		local result = self.itemListFilter.heroList[id]:getAttribute()
		result['hi']['st'] = statistic
		if self.gameOverStatistic~=nil then
			for k,v in pairs(result['hi']['st']) do
				if v['fd'][id]~=nil then
					v['fd'] = v['fd'][id]
				end
			end
		end
		return result
	end
end


return World1009
