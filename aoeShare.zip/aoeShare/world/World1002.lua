local World1002 = class("World1002",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World1002:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World1002"
	end

	World1002.super.ctor(self,gamePort,gameID,callBack)
	worldForHero = 1002
	self.gameCounter['pointsA'] = 0
	self.gameCounter['pointsB'] = 0
end

--- 增加AI英雄
-- @param null
-- @return null
function World1002:addHeroAI()
	local data = self:memcacheGet('PVEData'..self.tonumber(self.playerList[1]['p']))
	local pveData = self.cjson.decode(data)
	for k,v in pairs(pveData) do
		for k1,v1 in pairs(v) do
			local itemID = self:getHeroItemID()
			self.playerList[itemID] = {}
			self.playerList[itemID]['playerJson'] = self.tDeepcopy(v1)
			self.playerList[itemID]['t'] = k
			self.playerList[itemID]['id'] = self.playerList[itemID]['playerJson']['Player']['loginID']
			self.playerList[itemID]['p'] = self.playerList[itemID]['playerJson']['Player']['playerID']
			self.playerList[itemID]['online'] = true
			self.playerList[itemID]['redirectEndTime'] = 0
			hero = self:addHero(self.playerList[itemID]['playerJson']['Player']['roleId'],k,self.playerList[itemID]['id'],nil,nil,nil,itemID,true)
			local defaultClose = false
			for k,v in pairs(self.gameRoomSetting['worldAIDefaultClose']) do
				if self.tonumber(self.mapModel)==v then
					defaultClose = true
				end
			end
			if not defaultClose then
				self:D('jaylog WorldBase:createHeroAI setAuto true')
				hero:setAuto(true)
			end
		end
	end
end

-- --- RUNNING 遊戲loop
-- -- @return null
function World1002:statusRUNNING()
	if not self.gameFlag.busyFlag and (self.gameTime>10 or self.gameRoomSetting['hasMapZone']==true) then
		self.gameFlag.busyFlag = true
		self:memcacheSet('gameServerLivePort'..self.gamePort,-self.gameRoomInfo['mID'])
		self:addHeroAI()
		-- self.gameCounter['pointsA'] = 3
		-- self.gameCounter['pointsB'] = 3
		-- self:syncPointsInfo()
	end
	World1002.super.statusRUNNING(self)
end

--- client端初始化房间设置
-- @param data table - client传上来的数据
-- @return data table - 原数据返回
function World1002:clientGameInit(data)
	local result = World1002.super.clientGameInit(self,data)
	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==6 then
		result['game']['pointsA'] = self.gameCounter['pointsA']
		result['game']['pointsB'] = self.gameCounter['pointsB']
	end
	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==8 then
		self.gameStartTime = self:getGameTime()
	end
	return result
end

-- --- 增加AI英雄
-- -- @param null
-- -- @return null
-- function World1002:addHeroAI()
-- 	if self.gameRoomSetting['ISPVP']==1 then
-- 		local sum1,sum2 = 0,0
-- 		local IDs1,IDs2 = {},{}
-- 		local team1,team2 = 'A','B'
-- 		local loginID = ''
-- 		local itemID1 = 0
-- 		local itemID2 = 0
-- 		local minLv,maxLv = 0,0
-- 		local randLv = 0
-- 		local teamPlayerNum = 3
-- 		for k,v in pairs(self.itemListFilter.heroList) do
-- 			if v.actorType==0 then
-- 				if self.playerList[k]['playerJson']['Player']['school']==1 then
-- 					sum1 = sum1 + 1
-- 					IDs1[""..v.attribute.roleId] = 1
-- 					--team1 = v.teamOrig
-- 					loginID1 = v.loginID
-- 					itemID1 = v.itemID
-- 					self:D('jaylog addAIhero PVP1 itemID ',itemID1,loginID1)
-- 					if minLv==0 or minLv>v.attribute.level then
-- 						minLv = v.attribute.level
-- 					end
-- 					if maxLv==0 or maxLv<v.attribute.level then
-- 						maxLv = v.attribute.level
-- 					end
-- 				end
-- 				if self.playerList[k]['playerJson']['Player']['school']==2 then
-- 					sum2 = sum2 + 1
-- 					IDs2[""..v.attribute.roleId] = 1
-- 					--team2 = v.teamOrig
-- 					loginID2 = v.loginID
-- 					itemID2 = v.itemID
-- 					self:D('jaylog addAIhero PVP2 itemID ',itemID2,loginID2)
-- 					if minLv==0 or minLv>v.attribute.level then
-- 						minLv = v.attribute.level
-- 					end
-- 					if maxLv==0 or maxLv<v.attribute.level then
-- 						maxLv = v.attribute.level
-- 					end
-- 				end
-- 			end
-- 		end
-- 		self:D('jaylog sum',sum1,sum2,teamPlayerNum)
-- 		if sum1<teamPlayerNum then
-- 			local addNum = teamPlayerNum - sum1
-- 			local mustID,mustIDTmp,lotteryIDTmp,lotteryID = {},{},{},{}
-- 			mustIDTmp = self.sSplitNumber(self.setting['AIfixedYH'],',')
-- 			lotteryIDTmp = self.sSplitNumber(self.setting['AIrandomYH'],',')
-- 			for k,v in pairs(mustIDTmp) do
-- 				if IDs1[''..v]==nil then
-- 					mustID[#mustID+1] = v
-- 				end
-- 			end
-- 			for k,v in pairs(lotteryIDTmp) do
-- 				if IDs1[''..v]==nil then
-- 					lotteryID[#lotteryID+1] = v
-- 				end
-- 			end
-- 			self:D('jaylog ID',self.cjson.encode(mustID),self.cjson.encode(lotteryID),addNum)
-- 			for k,v in pairs(mustID) do
-- 				if addNum>0 then
-- 					if IDs1[""..v]==nil then
-- 						randLv = self.formula:getRandnum(minLv,maxLv)
-- 						-- local idx = self:getHeroItemID()
-- 						local id = '01'
-- 						if v<10 then
-- 							id = '0'..v
-- 						else
-- 							id = ''..v
-- 						end
-- 						self:createHeroAI(v,randLv,team1)
-- 					end
-- 					addNum = addNum - 1
-- 				end
-- 			end
-- 			if addNum>0 and not empty(lotteryID) then
-- 				for i=1,addNum do
-- 					randLv = self.formula:getRandnum(minLv,maxLv)
-- 					local ridx = i
-- 					-- local idx = self:getHeroItemID()
-- 					local id = '01'
-- 					if lotteryID[ridx]<10 then
-- 						id = '0'..lotteryID[ridx]
-- 					else
-- 						id = ''..lotteryID[ridx]
-- 					end
-- 					self:createHeroAI(lotteryID[ridx],randLv,team1)
-- 				end
-- 			end
-- 		end
-- 		if sum2<teamPlayerNum then
-- 			local addNum = teamPlayerNum - sum2
-- 			local mustID,mustIDTmp,lotteryIDTmp,lotteryID = {},{},{},{}
-- 			mustIDTmp = self.sSplitNumber(self.setting['AIfixedNP'],',')
-- 			lotteryIDTmp = self.sSplitNumber(self.setting['AIrandomNP'],',')
-- 			for k,v in pairs(mustIDTmp) do
-- 				if IDs1[''..v]==nil then
-- 					mustID[#mustID+1] = v
-- 				end
-- 			end
-- 			for k,v in pairs(lotteryIDTmp) do
-- 				if IDs2[''..v]==nil then
-- 					lotteryID[#lotteryID+1] = v
-- 				end
-- 			end
-- 			self:D('jaylog ID',self.cjson.encode(mustID),self.cjson.encode(lotteryID))
-- 			for k,v in pairs(mustID) do
-- 				if addNum>0 then
-- 					if IDs2[""..v]==nil then
-- 						randLv = self.formula:getRandnum(minLv,maxLv)
-- 						-- local idx = self:getHeroItemID()
-- 						local id = '01'
-- 						if v<10 then
-- 							id = '0'..v
-- 						else
-- 							id = ''..v
-- 						end
-- 						self:createHeroAI(v,randLv,team2)
-- 					end
-- 					addNum = addNum - 1
-- 				end
-- 			end
-- 			if addNum>0 and not empty(lotteryID) then
-- 				for i=1,addNum do
-- 					randLv = self.formula:getRandnum(minLv,maxLv)
-- 					local ridx = i
-- 					local idx = self:getHeroItemID()
-- 					local id = '01'
-- 					if lotteryID[ridx]<10 then
-- 						id = '0'..lotteryID[ridx]
-- 					else
-- 						id = ''..lotteryID[ridx]
-- 					end
-- 					self:createHeroAI(lotteryID[ridx],randLv,team2)
-- 				end
-- 			end
-- 		end
-- 	end
-- end

-- --- RUNNING中 gameOver 检查
-- -- @return result bool - 是否gameOver
function World1002:gameOverCheck()
	local result = false
	-- result = World1002.super.gameOverCheck(self)

	if self.status~=self.GAMEOVER and self.gameRoomSetting['gameLimitedTime']+self.gameStartTime<=self:getGameTime() then
		result = true
		self.gameFlag['winTeam'] = 'B'
	end

	if not result and self.gameStartTime>0 then
		local deadNumA,deadNumB = 0,0
		local teamNumA,teamNumB = 0,0
		for k,v in pairs(self.itemListFilter.heroList) do
			if v.actorType==0 and v.teamOrig=='A' then
				if v:isDead() then
					deadNumA = deadNumA + 1
				end
				teamNumA = teamNumA + 1
			end
			if v.actorType==0 and v.teamOrig=='B' then
				if v:isDead() then
					deadNumB = deadNumB + 1
				end
				teamNumB = teamNumB + 1
			end
		end
		if deadNumA==teamNumA then
			result = true
			self.gameFlag['winTeam'] = 'B'
			return result
		end
		if deadNumB==teamNumB then
			result = true
			self.gameFlag['winTeam'] = 'A'
			return result
		end
	end
	return result
end

-- -- 发送分数给client
function World1002:syncPointsInfo()
	self:D('jaylog World1002 syncPointsInfo')
	local gameInfo = {
		pointsA = self.gameCounter['pointsA'],
		pointsB = self.gameCounter['pointsB'],
	}
	self:addSyncMsg({game=gameInfo})
end

return World1002