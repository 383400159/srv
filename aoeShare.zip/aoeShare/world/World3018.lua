local World3018 = class("World3018",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World3018:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World3018"
	end

	World3018.super.ctor(self,gamePort,gameID,callBack)
	worldForHero = 3018
end

function World3018:gengameRoomSetting()
	World3018.super.gengameRoomSetting(self)
	--天平AI行为
	self.tpAIMoveTime = 0
	self.tpAMoveList = {}
	self.tpBMoveList = {}
	self.tpSetting = {}
	local Aset=string.splitNumber(self.setting.balanceAreaA,',')
	local Bset=string.splitNumber(self.setting.balanceAreaB,',')
	self.tpSetting[1]={x=Aset[1],y=Aset[2],r=Aset[3]}
	self.tpSetting[2]={x=Bset[1],y=Bset[2],r=Bset[3]}
	self.nextMoveAITime = 0
end

--- 接收client端发送数据
-- @param data table - 发送的数据table
-- @param serverTime float - 游戏时间
-- @return null
function World3018:receiveMsg(data,serverTime)
	local ret = World3018.super.receiveMsg(self,data,serverTime)
	if data==nil then
		data = {}
	end
	for k,v in pairs(data) do
		if k=='apimsgc' then
			local vdata = self.cjson.decode(v['rq'])
			if v['ctrl']~=nil and v['act']~=nil then
				if v['ctrl']=='autoMove' and v['act']=='autoMove' then
					if not self.allItemList[data['roleID']]:isDead() then
						if vdata['pID']~=nil and vdata['pID']~=0 and vdata['pID']~='' then
							if self.allItemList[data['roleID']].statusList[4016]~=nil then
								self:D("重刷4016 1.。。。。。。。。。",data['roleID'])
								local status = self.allItemList[data['roleID']].statusList[4016]
								self.allItemList[data['roleID']]:removeStatusList(4016)
								self.allItemList[data['roleID']]:addStatusList({zz=3,i=self.allItemList[data['roleID']].itemID,s=4016,r=self.gameTime,t=9999,p1=status['p1'],p2=status['p2'],p5=1},0.5)
							end
						end
					end
				end
			end
		end
		if self.status==self.RUNNING and k=='mc' and data['roleID'] ~=nil then
			if self.allItemList[data['roleID']].statusList[4016]~=nil then
				self:D("重刷4016 2.。。。。。。。。。",data['roleID'])
				local status = self.allItemList[data['roleID']].statusList[4016]
				self.allItemList[data['roleID']]:removeStatusList(4016)
				self.allItemList[data['roleID']]:addStatusList({zz=3,i=self.allItemList[data['roleID']].itemID,s=4016,r=self.gameTime,t=9999,p1=status['p1'],p2=status['p2'],p5=1},0.5)
			end
		end
		if self.status==self.RUNNING and k=='ac' and data['roleID'] ~=nil then
			if self.allItemList[data['roleID']].statusList[4016]~=nil then
				self:D("重刷4016 3.。。。。。。。。。",data['roleID'])
				local status = self.allItemList[data['roleID']].statusList[4016]
				self.allItemList[data['roleID']]:removeStatusList(4016)
				self.allItemList[data['roleID']]:addStatusList({zz=3,i=self.allItemList[data['roleID']].itemID,s=4016,r=self.gameTime,t=9999,p1=status['p1'],p2=status['p2'],p5=1},0.5)
			end
		end
	end
	return ret
end



return World3018