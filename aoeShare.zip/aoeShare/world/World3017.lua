local World3017 = class("World3017",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World3017:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World3017"
	end

	World3017.super.ctor(self,gamePort,gameID,callBack)
	worldForHero = 3017
end

return World3017