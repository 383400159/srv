local World1003 = class("World1003",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World1003:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World1003"
	end
	World1003.super.ctor(self,gamePort,gameID,callBack)
	self.gameRoomSetting['autoAddCreature']=true
	--采集列表
	self.gatherList = {}
	worldForHero = 1003
	--发兵时间
	self.startTimeTo = 30
	--活动结束时间
	self.endTime=3600
	--排行榜刷新时间
	self.nextRanksTime=0
end

function World1003:init()
	World1003.super.init(self)
end


--- 生成独立野外怪
-- @param null
-- @return null
function World1003:createYWEnemyAlone(v)
	self:D("采矿的createYWEnemy",v['KS'])

	self:D("createYWEnemyAlone v:"..self.cjson.encode(v))
	local x,y
	if v['KS']~=1 then
		self:D("KS 0")
		x,y = self:getRandomEnemyAloneXY(v['groupID'])
	else
		self:D("KS 1")
		x,y = self:getRandomEnemyAloneKSXY(v['groupID'])
	end

	local isb = self.map:isBlockF(v['posX']+x,v['posY']+y)
	--判断点可以放不
	while isb==true do
		x,y = self:getRandomEnemyAloneXY(v['groupID'])
		isb = self.map:isBlockF(v['posX']+x,v['posY']+y)
		--self:D("isb :"..(isb and "true" or "false").." X:"..(v['posX']+x).." Y:"..(v['posY']+y))
	end
	local itemID=self:addCreature(v['type'],"",v['posX']+x,v['posY']+y,nil,1,0)
	-- local obj = self.allItemList[itemID] 
	-- obj:createInit()
	--local itemID = self:addMonster(v['type'],v['posX']+x,v['posY']+y,v['group'],1,v['team']) 
	--self:D("createYWEnemyAlone type:"..v['type'].." posX:"..v['posX']+x.." posY:"..v['posY']+y.." team:"..v['team'].." group:"..v['group'])
	if self.genEnemyAloneIDInGroup[v['group']]==nil then
		self.genEnemyAloneIDInGroup[v['group']] = {}
	end
	if self.HatredGrouplist[v['group']]==nil then
		self.HatredGrouplist[v['group']]={}
	end
	self.genEnemyAloneIDInGroup[v['group']][#self.genEnemyAloneIDInGroup[v['group']]+1] = {itemID=itemID}
end

function World1003:getRandomEnemyAloneXY(groupID)
	local settingLocal = self.setting
	local enemy1Typelist = string.split(settingLocal["enemyAlone"..groupID.."Type"],',')
	local x,y = self.formula:getRandomCirclePoint(0,0,enemy1Typelist[3]*0.01)
	--self:D("getRandomEnemyAloneXY x:"..x.." y:"..y)
	return x,y
end

function World1003:getRandomEnemyAloneKSXY(groupID)
	local settingLocal = self.setting
	local enemy1Typelist = string.split(settingLocal["enemyAloneKS"..groupID.."Type"],',')
	local x,y = self.formula:getRandomCirclePoint(0,0,enemy1Typelist[3]*0.01)
	--self:D("getRandomEnemyAloneXY x:"..x.." y:"..y)
	return x,y
end

---用于gen地图自动生成的物品
-- @param null
-- @return null
function World1003:genItem()

	--时间到结算
	if self.gameTime>self.endTime then
		
	end
	World1003.super.genItem(self)

	-- if  self.gameTime>self.startTimeTo and (self.gameRoomSetting['ISYW']==1 or self.gameRoomSetting['autoAddCreature']) then
	-- 	if self.genItemTime<self.gameTime then
	-- 		--野怪复活
	-- 		for k,grouplist in pairs(self.getMonsterIDInGroup) do
	-- 			local isdead = 1
	-- 			for j,v in pairs(grouplist) do
	-- 				local obj = self.allItemList[v['itemID']] 
	-- 				if obj==nil or obj~=nil and obj:isDead() then
	-- 					isdead = isdead*1
	-- 				else
	-- 					isdead = isdead*0
	-- 				end
	-- 			end
	-- 			if isdead==1 then
	-- 				--self:D("需要重新生成:"..k)
	-- 				self.getMonsterIDInGroup[k]=nil
	-- 				self.reviveMonsterlist[#self.reviveMonsterlist+1]={group=k,time=self.gameTime+self.formula:getRandnum(1,self.genMonsterInGroup[k][1]['reviveTime'])}
	-- 				--self:reviveYWAllEnemy(k)
	-- 			end
	-- 		end
			
	-- 		for r,v in pairs(self.reviveMonsterlist) do
	-- 			if v['time']<self.gameTime then
	-- 				--self:D("时间到 执行复活...")
	-- 				self:reviveYWAllEnemy(v['group'])
	-- 				table.remove(self.reviveMonsterlist,r)
	-- 			end
	-- 		end

	-- 		--boss复活
	-- 		for k,grouplist in pairs(self.getBossIDInGroup) do
	-- 			local isdead = 1
	-- 			for j,v in pairs(grouplist) do
	-- 				local obj = self.allItemList[v['itemID']] 
	-- 				if obj==nil or obj~=nil and obj:isDead() then
	-- 					isdead = isdead*1
	-- 				else
	-- 					isdead = isdead*0
	-- 				end
	-- 			end
	-- 			if isdead==1 then
	-- 				--self:D("需要重新生成:"..k)
	-- 				self.getBossIDInGroup[k]=nil
	-- 				self.reviveBosslist[#self.reviveBosslist+1]={group=k,time=self.gameTime+self.formula:getRandnum(1,self.genBossInGroup[k][1]['reviveTime'])}
	-- 				--self:reviveYWAllEnemy(k)
	-- 			end
	-- 		end
			
	-- 		for r,v in pairs(self.reviveBosslist) do
	-- 			if v['time']<self.gameTime then
	-- 				--self:D("时间到 执行复活BOSS...")
	-- 				self:reviveYWAllBoss(v['group'])
	-- 				table.remove(self.reviveBosslist,r)
	-- 			end
	-- 		end

	-- 		--散落怪生成
	-- 		for k,grouplist in pairs(self.genEnemyAloneIDInGroup) do
	-- 			local isdead = 1
	-- 			for j,v in pairs(grouplist) do
	-- 				local obj = self.allItemList[v['itemID']] 
	-- 				if obj==nil or obj~=nil and obj:isDead() then
	-- 					isdead = isdead*1
	-- 					table.remove(grouplist,j)
	-- 					--self:D("需要EnemyAlone重新生成:"..k)
	-- 					self.revivEnemyAlonelist[#self.revivEnemyAlonelist+1]={group=k,time=self.gameTime+self.formula:getRandnum(1,self.genEnemyAloneInGroup[k][1]['reviveTime'])}
	-- 				else
	-- 					isdead = isdead*0
	-- 				end							
	-- 				--剔除死亡的	
	-- 			end
	-- 		end

	-- 		for r,v in pairs(self.revivEnemyAlonelist) do
	-- 			if v['time']<self.gameTime then
	-- 				--self:D("时间到 执行复活...")
	-- 				self:reviveYWAllEnemyAlone(v['group'])
	-- 				table.remove(self.revivEnemyAlonelist,r)
	-- 			end
	-- 		end
	-- 		self.genItemTime = self.gameTime+1
	-- 	end
	-- 	if self.genTmpHeroTime+10<self.gameTime then
	-- 		self:reviveTmpHero()
	-- 		self.genTmpHeroTime = self.gameTime
	-- 	end
	-- end


	self:updateRanks()
end




--- init时生成地图出生怪物设置
-- @param null
-- @return null
function World1003:genMonsterSetting()
	World1003.super.genMonsterSetting(self)

	local settingLocal = self.setting	
	--添加散落小怪
	local dowhile = true
	local l = 0
	while (dowhile) do
		if settingLocal["enemyAloneKS"..(l+1).."ID"]~=nil and settingLocal["enemyAloneKS"..(l+1).."ID"]~='' then
			l = l + 1
		else
			dowhile = false
		end
	end

	if l>0 then
		self:D("fenglog 野外地图 enemyAlone l："..l)
		for i=1,l do
			self:D("fenglog 野外地图 enemyAlone:"..settingLocal["enemyAloneKS"..i.."ID"])
			local enemy1Typelist = string.split(settingLocal["enemyAloneKS"..i.."ID"],',')
			local enemy1Type = enemy1Typelist[1]
			local enemyNum = enemy1Typelist[2]
			local enemy1Typelist = string.split(settingLocal["enemyAloneKS"..i.."Type"],',')
			
			for j=1,enemyNum do
				self.genYWEnemyAlone[#self.genYWEnemyAlone+1] = {
					type = enemy1Type,
					time = 5,
					posX = enemy1Typelist[1],
					posY = enemy1Typelist[2],
					group = 'enemyAlone'..i,
					groupID = i,
					team = '',
					KS=1,
					--reviveTime = self.tonumber(enemy1Typelist[4])
					reviveTime = 2
				}
				local eID = #self.genEnemyAloneInGroup+1
				if self.genEnemyAloneInGroup['enemyAlone'..eID]==nil then
					self.genEnemyAloneInGroup['enemyAlone'..eID] = {}
				end
				self.genEnemyAloneInGroup['enemyAlone'..eID][#self.genEnemyAloneInGroup['enemyAlone'..eID]+1] =  self.genYWEnemyAlone[#self.genYWEnemyAlone]

			end
		end
	end



end


--计算排行榜和积分
function World1003:updateRanks()
	if self.nextRanksTime<self.gameTime then
		self.ranksList={}
		for k,v in pairs(self.allItemList) do
			if v.attribute.actorType==0 then
				local miningNum = string.splitNumber(self.setting.miningNum,',')
				local ctb=v.gatherList[1]*miningNum[1]+v.gatherList[2]*miningNum[2]+v.gatherList[3]*miningNum[3]+v.gatherList[4]*self.setting.killEnemyNum+v.gatherList[5]*self.setting.killMonsterNum
				self.ranksList[#self.ranksList+1]={itemID=v.itemID,ctb=ctb}
			end
		end


		self.tSort(self.ranksList,function( a1,b1 )
				return a1['ctb'] > b1['ctb']
			end)

		self:D("保卫雅典娜 排行榜",self.cjson.encode(self.ranksList))
		self.nextRanksTime=self.gameTime+5
	end
	

end

function World1003:updatePlayerInfo()

	for k,v in pairs(ranksList) do
		local obj = self.allItemList[v.itemID] 
		local data = {}
		--data = {mapModel=self.world.mapModel,mapPort=self.world.gamePort,HP=self.attribute.HP,MP=self.attribute.MP,X=self.posX,Y=self.posY}
		data['info'] = {ranks=k,mapPort=self.world.gamePort,ctb=v.ctb}
		local ctrl = 'internalapi'
		local act = 'finishAct1'
		obj:addApiCall(data,ctrl,act)
	end
end

--win true or false 代表输赢
--hprate boss剩余血量比例
function World1003:gameOver()

	--更新玩家数据
	self:updatePlayerInfo()

	-- 玩家离开清除房间玩家数据 --
	local players={}
	for i=1,self.gameRoomSetting['maxPlayer'] do
		if (isset(self.playerList[i]) and self.playerList[i]['online']==false) then
			if self.gameRoomSetting['hasMapZone']~=true and (self.tonumber(self.playerList[i]['p'])>0) then
				self:redisCall('srem','room0',self.playerList[i]['p'])
			end
			if (self.tonumber(self.playerList[i]['p'])>12) then
				rc = {i=0,m=self.playerList[i]['id'].." 离开了房间",t="",d=0}
				self:addSyncMsg({rc=rc})
			end
			--self.playerList[i]=nil
		elseif (isset(self.playerList[i])) then
			players[self.playerList[i]['p']]=self.playerList[i]
			if self.gameRoomSetting['hasMapZone']~=true and (self.tonumber(self.playerList[i]['p'])>0) then
				self:redisCall('srem','room0',self.playerList[i]['p'])
			end
		end
	end

	players['END']=true
	self:setPlayerListMemcache(players)
	self:D("jaylog 有没有call到结束/////////////")
	self.gameOverTime = self.gameTime+5
	self.status=self.GAMEOVER
end



--- 增加AI英雄
-- @param null
-- @return null
function World1003:addHeroAI()
end

return World1003

