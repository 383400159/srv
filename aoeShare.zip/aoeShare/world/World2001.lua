local World2001 = class("World2001",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World2001:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World2001"
	end

	World2001.super.ctor(self,gamePort,gameID,callBack)

	worldForHero = 2001
end

function World2001:runExtraParam(extraParam)
	if extraParam==nil then
		extraParam = {}
	end
	local pos = extraParam['POSITION']
	for k,v in pairs(self.gameFlag['passTransitDoorID']) do
		local obj = self.allItemList[v]
		obj:addStatusList({s=4008,r=self.gameTime,t=1})
		self:debuglog('jaylog start ready to moveTo itemID:',v,' x:',obj.posX,' y:',obj.posY,' tox:',pos[1],' toy:',pos[2],' lid:',obj.attribute.loginID)
		-- local attributes = {}
		-- attributes['DIZZY_RATE'] = 100
		-- local buff = require("gameroomcore.SBuff").new(self,obj:__skillID2buffID(1),attributes,1,{},0,obj.itemID,obj.itemID)
		-- obj:addBuff(buff)
		local shareObj
		if obj.sharedID>0 and self.allItemList[obj.sharedID]~=nil then
			shareObj = self.allItemList[obj.sharedID]
			obj:moveTo(shareObj.posX,shareObj.posY,true,1,99999)
		else
			obj:moveTo(pos[1],pos[2],true,1,99999)
		end
		
		-- obj:removeBUff('SLEEP')
		-- obj:removeBUff('DIZZY')
		obj:removeStatusList(4010)
		debuglog('jaylog part 2 shareObj: objID'..obj.itemID..' shareObjID:'..obj.sharedID)
		if obj.sharedID>0 and self.allItemList[obj.sharedID]~=nil then
			shareObj:setShared(0)
			shareObj:addStatusList({s=42,r=self:getGameTime(),t=999},0)
			shareObj.attribute.HP = 0
			shareObj:directHurt(self.itemID,1,{},0)
		end
		if obj.sharedID>0 then
			obj:setShared(0)
		end
		obj.inTransitDoor = false
	end
	self.gameFlag['passTransitDoorNum'] = 0
	self.gameFlag['passTransitDoorID'] = {}
	return true
end

return World2001

