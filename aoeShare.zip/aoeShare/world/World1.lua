
--require "gameroom.functions"
--require "gameroom.Config"

local cjson = require(Config.cjson)

local World1 = class("World1",require("gameroom.WorldBase"))

worldForHero = 1

--self.isTraining 多人对战 與 積分。。是registerPlayer 時做的。。因為kevin 那邊會傳一個參數來。我設在 self.isTraining
--因為 self.isTraining  分別就做gameover  和 會不會掛機托管
--world4.lua public needSameGuild=true;   <= 就是這個參數 工会战

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World1:ctor(gamePort,gameID,callBack)

	World1.super.ctor(self,gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World1"
	end
	--debuglog("World start new .." .. cjson.encode(self.className) )
	self.formula = require("gameroom.formula")
	-- 房间设置
	self.gameRoomSetting = {
		version = "1.0",
		byPassStatus = {},
		modelMaxRevive = 0,
		gameLimitedTime = 1800,
		maxPlayer = 10,
		soldierLevel = {S8M=944,S1town=955,S12M=966,S2town=977,S15M=988,Snotown=999},
		sendToClientStatusList = {DIZZY=3,FROZEN=19,POISON=20,BURN=21,SLEEP=22,PARALYSIS=23,BLEED=24,OUTCTL=32,IMMUNEAP=33,IMMUNEAD=34,SILIENCE=35,STONE=36,INVICINBLE=38,IMMUNECONTROL=39,IMMUNEDEBUFF=40,STOPMOVE=43,OUTCTL_BOSS=44,SENSE=46,ROLEBUFFSKILLA=993},
		checkEffectStatusList = {'DIZZY','FROZEN','POISON','BURN','SLEEP','PARALYSIS','BLEED','OUTCTL','IMMUNEAP','IMMUNEAD','SILIENCE','STONE','INVICINBLE','IMMUNECONTROL','IMMUNEDEBUFF','STOPMOVE','OUTCTL_BOSS','SENSE','ROLEBUFFSKILLA'},
		cancelBulletStatus = {3,22,23,32,35,36},
		sendToClientStatusBuffList = {DEF_DOWN=1,DEF_UP=2,CRI_UP=4,COOLDOWN_TIME=5,ATK_UP=6,ATK_DOWN=7,MSPD_UP=8,MSPD_DOWN=10,MDEF_DOWN=11,MDEF_UP=12,
		HP_UP=13,HP_DOWN=14,HIT_UP=15,HIT_DOWN=16,DODGE_UP=17,DODGE_DOWN=18,ATKDIS_DOWN=27,ATKDIS_UP=28,HURTAD_HURT=29,HURTAP_HURT=30,CRI_DOWN=45},
		modelall_maxRevive = 3,
		model9_maxRevive = 5,
		model10_maxRevive = 9,
		model10_needGold = 20,
		gameLimitedPoints = 500,
		enemyEnergy = 200,
		sameTeam = false
	}
	self.map = nil
	self.mapSize = 0
	self.bulletID = 1
	self.itemID = 1


	self.syncMsg = {} -- sync to client message

	-- list
	self.playerList = {}  -- player info
	self.kickedPlayerList = {}
	self.monitorPlayerList = {}
	self.bulletList = {}  -- bullet
	self.equipList = {}  -- equip item list ( preload item )
	self.allItemList = {}  -- all items

	-- two teams points counter
	self.counter = {
		pointsA = 0,
		pointsB = 0,
		towerA = 0,
		towerB = 0,
		towerC = 0
	}

	-- game over msg, pass to client
	self.gameOverMsg = {
		game = {
			--start=1,
			d=0,
			reset=1,
			pointsA = 0,	--team A points
			pointsB = 0,	--team B points
			w = {},		--winner team
			gameTime = 0,	--game total time
			bonus = {}	--all player's get: bonus
		}
	}

	--游戏内时间项
	self.gameTime = 0 		--游戏时间
	self.serverTime = 0 	--服务器时间
	self.startTime = 0 		--开始时间
	self.readyTime = 0 		--准备时间
	self.startWaitingTime = 0 		
	self.syncRoomInfoTime = 0
	self.genMonsterTime = 0
	self.waitQuit = 0

	--common setting
	self.getEnergyPlayerID = 0 		--记录当前取得水晶的玩家ID

	--common attribute data
	self.attrData = {}
	self.attrSkill = {}
	--enemy data
	self.enemyAll = {}						--所有怪物的基础数据
	self.enemySkillAll = {}				--所有怪物的技能数据
	self.enemyOne = {
		eType = 0,
		moveMode = 0,
		attackMode = 0,
		HP = 0 ,
		MP = 0 ,
		MaxHP = 1000 ,
		MaxMP = 1000 ,
		ATK = 0 ,
		DEF = 0 ,
		MDEF = 0 ,
		HIT = 0 ,
		DODGE = 0 , 
		CRI = 0 ,
		ASPD = 0 ,
		MSPD = 0 ,
		FIRER = 0 ,
		ICER = 0 ,
		LIGHTR = 0 , 
		POISONR = 0 ,
		--半径 
		width = 1 ,
		ATTRNG = 1000 ,
		VISRNG = 1000 ,
		PARAM = {}
	}

	--获得中央水晶状态标记
	self.energyStatus = {
		s=37,
		t=300,
		r=300
	}

	--game flag
	self.gameFlag = {
		lastCountTime = 0,
		killB1ID = 0,	--杀中间水晶怪物的玩家
		lastEnergyID = 0,	--上次站在水晶位置的玩家
		lastEnergyTime = 0,	--上次开始咏唱的时间
		passTransitDoorNum = 0,	--通过传送门人数
		passTransitDoorID = {},
		allStopMove = false,
	}

	--只在单程序内部用的变量请组织成table，其他程序中都要用到的全局变量保持不变


	--self.initHeroes = false
	self.gameOverTime = 0 		--游戏结算时间
	self.gameOverWaitTime = 0 		--游戏结算等待时间
	
	--self.surrenderTeam = ''


	--游戏结算通信接口
	--self.webapiurl = 'http://114.119.43.215/AOEApi/'
	--self.webapiurl2 = 'http://114.119.43.215/AOEApi/'

	--self.gameModel = 6
	self.maxPlayer = 10 					--游戏最大玩家数
	self.modelMaxRevive = 0
	self.trySurrender=0
	self.gameLimitedTime = 1800 	--游戏限制结束时间
	self.minimumPlayer = 2

	self.towerBaseA = 1
	self.towerBaseB = 1
	self.status = self.WAITB
	self.gameModel = 0
	self.waitingTime = 99



	-- runtime parameter
	self.initHeroes = false
	self.gameOverTime = 0
	self.map = nil
	self.mapSize = 0
	self.forceUpdate = false
	self.forceUpdateSoldier = false
	
	self.AIHelper = false
	self.numOfKillA = 0
	self.numOfKillB = 0
	self.totalTower = 0
	self.towerAPos = {}
	self.towerBPos = {}
	

	self.is3V3 = false
	self.isTraining = false
	self.lastSyncPingTime = 0
	
	
	
	self.genSoldierTime = 10
	self.genSoldierLastTime = 10
	self.genSoldier = {}
	self.genSoldierLevel = {}
	self.genSoldierType = 1
	self.genSoldierCount = 0
	self.genMonster = {}
	self.genMonsterGroup = {}
	self.genMonsterGroupLevel = {}
	self.genMonsterGroupOrder = {}
	self.numOfTowerA = 0
	self.numOfTowerB = 0
	self.numOfTowerAR = 0
	self.numOfTowerAL = 0
	self.numOfTowerAC = 0
	self.numOfTowerBR = 0
	self.numOfTowerBL = 0
	self.numOfTowerBC = 0
	self.towerLevelUpTime = 0
	
	self.surrenderWaitTime = 0
	self.surrenderTeam = ""
	self.surrenderTime = {}
	self.lastBCMsg98 = 0
	self.AISpecialSkillTime = 0
	self.firstKill = false
		--	self.stopUpdate = false

	self.transitDoor = {}
	self.transitDoorInCoord = {}

	self.lastInstantBuffEquip = {}
	self.lastInstantBuffEquipTime = 0
	self.instantBuffEquipIntervalTime = 0
	self.instantBuffEquipCoord = {}
	self.instantBuffEquipIDs = {}

	self.jackpotEnemy = {}
	self.vipSetting = {}
	self.bonusMonster = {hero=0}

	self.needLimitItemHeroes = {}
	self.needCashItemHeroes = {}
	self.nameHeroes = {}
	self.skinHeroes = {}
	self.skinepicHeroes = {}
	self.needCashItemHeroes2 = {}

	worldForHero = 1

	--AI posTargetList
	self.posTargetList = {}
	self.AITargetList = {}

end

--- 接收client端发送数据
-- @param data table - 发送的数据table
-- @param serverTime float - 游戏时间
-- @return null
function World1:receiveMsg(data,serverTime)
	if self.status==self.RUNNING then
		self:setGameTime(serverTime)
	end
	if data ==nil then
		data = {}
	end

	local ret = nil
	--debuglog('World1:receiveMsg == '..self.cjson.encode(data))
	for k,v in pairs(data) do
		if k=='apimsgc' then
			local vdata = self.cjson.decode(v['rq'])
			debuglog('jaylog WorldBase:receiveMsg vdata:'..self.cjson.encode(vdata))
			if vdata['rtype']=='autoMove' and vdata['pID']~=nil and vdata['pID']~=0 and vdata['pID']~='' then
				self.allItemList[data['roleID']]:setAutoFollow(self.tonumber(vdata['pID']))
			end
		end
		if k=='l' then
			self:login(data)
			ret = data
		end
		if k=='game' and data['roleID']~=nil then
			ret = self:clientGameInit(data)
		end
		if k=='ping' and data['roleID']~=nil and self.itemListFilter.heroList[data['roleID']]~=nil then
			self.itemListFilter.heroList[data['roleID']]:setPing(data['ping'])
		end

		if  data~=nil and  data['roleID']~=nil and self.playerList[data['roleID']]~=nil and self.playerList[data['roleID']]['apm'] ==nil then
			self.playerList[data['roleID']]['apm'] = 0
		end

		if self.status==self.RUNNING and k=='mc' and data['roleID'] ~=nil then
			if self.className=='World3' then
				if self.partWaitTime>self.gameTime or self.gameFlag['allStopMove'] then
					--debuglog('jaylog World1 k-mc')
					return nil
				end
			end
			if self.itemListFilter.heroList[data['roleID']]~=nil then
				self.itemListFilter.heroList[data['roleID']].lastMoveTime = self.gameTime
				self.itemListFilter.heroList[data['roleID']]:control()
				self.itemListFilter.heroList[data['roleID']]:setAutoMove()
				self.itemListFilter.heroList[data['roleID']]:setAutoFollow()
				if self.itemListFilter.heroList[data['roleID']].statusList[41]~=nil and self.itemListFilter.heroList[data['roleID']].attribute.actorType==0 then
					--self.itemListFilter.heroList[data['roleID']]:removeStatusList(41,0)	--移动删除咏唱状态
					self.gameFlag['lastEnergyID'] = 0
					self.gameFlag['lastEnergyTime'] = 0
				end
			end
			if  data['roleID']~=nil and data['mc']['j']==nil then
				data['mc']['j'] = 0
			end
			local a = self:moveHero(data['roleID'],data['mc']['x'],data['mc']['y'],data['mc']['j'])
			if self.playerList[data['roleID']]~=nil then
				self.playerList[data['roleID']]['apm'] = self.playerList[data['roleID']]['apm'] + 1
			end
			if type(a)=="table" then
				ret = {t=self.gameTime,m={{i=data['roleID'],m=a['m'],d=a['d']}}}
			else
				ret = nil
			end
		end
		if self.status==self.RUNNING and k=='ac' and data['roleID'] ~=nil then
			--[[
			if v['m']==6 then
				return {game={reset=9}}
			end
			]]
			if self.className=='World3' then
				if self.partWaitTime>self.gameTime or self.gameFlag['allStopMove'] then
					return nil
				end
			end
			if self.itemListFilter.heroList[data['roleID']]~=nil then
				self.itemListFilter.heroList[data['roleID']]:control()
				self.itemListFilter.heroList[data['roleID']]:setAutoMove()
				self.itemListFilter.heroList[data['roleID']]:setAutoFollow()
			end
			--m=9,增加咏唱状态41
			if data['m']==9  and self.itemListFilter.heroList[data['roleID']].attribute.actorType==0 then
				self.itemListFilter.heroList[data['roleID']]:addStatusList({s=41,r=self.gameTime,t=3},0)
				self.gameFlag['lastEnergyTime'] = self.gameTime
				self.gameFlag['lastEnergyID'] = data['roleID']
				return nil
			end
			local a = self:attackHero(data['roleID'],data['ac'])
			if self.playerList[data['roleID']]~=nil then
				self.playerList[data['roleID']]['apm'] = self.playerList[data['roleID']]['apm'] + 1
			end
			if type(a)=="table" then
				ret = a
			else
				ret = nil
			end
		end
		if k=='st' and data['roleID'] ~=nil  then
			if self.itemListFilter.heroList[data['roleID']]~=nil then
				self.itemListFilter.heroList[data['roleID']]:control()
			end
			local id,id2
			if data['roleID']>90 and self.itemListFilter.heroList[data['roleID']-90]~=nil then
				id = data['roleID']-90
			else
				id = data['roleID']
			end
			if data['st']['i']>90 then
				id2 = data['st']['i']-90
			else
				id2 = data['st']['i']
			end
			local a = self:heroInfo(id,id2)
			if type(a)=="table" then
				--debuglog('jayLog start return heroInfo : '..self.cjson.encode(a))
				ret = a
			else
				ret = nil
			end
		end
		if k=='lo' then
			self.pendingUpdateCache=true
			data = self:logout(data)
			self.pendingUpdateCache=false
		end
		if k=='ric' and data['roleID'] ~=nil then
			if self.playerList[data['roleID']]~=nil then
			data = self:selectHero(data)
			end
		end
		if k=='rcc' and data['roleID'] ~=nil then
			if self.itemListFilter.heroList[data['roleID']]~=nil then
				self.itemListFilter.heroList[data['roleID']]:control()
			end
			if self.playerList[data['roleID']]~=nil then
				if self.playerList[data['roleID']]['ok']~=nil then
					delay = -1
				else
					delay = self.waitingTime - (self.serverTime - self.startWaitingTime)
				end
				if data['rcc']['t']==nil then data['rcc']['t'] = "" end
				local rc = {i=data['roleID'],m=data['rcc']['m'],t=data['rcc']['t'],d=delay}
				if data['rcc']['t']~="" then
					rc['zz'] = 2
				end
				self:addSyncMsg({rc=rc})
			end
		end
		if k=='auto' and data['roleID'] ~=nil then
			if self.is3V3 then
				data['auto'] = 1
				ret = data
			end
			if self.itemListFilter.heroList[data['roleID']]~=nil then
				self.itemListFilter.heroList[data['roleID']]:setAuto(data['auto']==2)
			end
			ret = data
		end
		if k=='extra' and data['extra']['closeRoom']~=nil and data['extra']['closeRoom']=="now" then
			--self.gameLimitedTime = self.gameTime
			self.gameRoomSetting['gameLimitedTime'] = self.gameTime
			ret = data
		end
	end
	return ret
		--debuglog('World1:receiveMsg end '..cjson.encode(data))
end

--- client端初始化房间设置
-- @param data table - client传上来的数据
-- @return data table - 原数据返回
function World1:clientGameInit(data)
	--debuglog("enter "..cjson.encode(data))
	-- print("clientGameInit status  : .." , self.status)
	-- print("clientGameInit READY  : .." , self.READY)
	-- print("clientGameInit start  : .." , data['game']['start'])
	-- print("clientGameInit roleID  : .." , data['roleID'])
	-- player ready for game start (after selected hero)
	debuglog('start clientGameInit status:'..self.status..' data:'..self.cjson.encode(data))

	if self.status==self.WAITB and data['roleID']~=nil and self.playerList[data['roleID']] ~=nil and self.playerList[data['roleID']]['a']>0 and data['game']['reset']==nil and (data['game']['start']==nil or data['game']['start']==0) then
	--if self.status==self.WAITB and self.playerList[data['roleID']] ~=nil and self.playerList[data['roleID']]['a']>0 and data['game']['reset']==nil and (data['game']['start']==nil or data['game']['start']==0) then
		debuglog('start0 '..self.cjson.encode(self.needSameGuild)..' '..self.playerList[data['roleID']]['guild'])
		if (self.needSameGuild and self.playerList[data['roleID']]['guild']==0) then
		return {zz=1}
		end
		self.waitingTime=self.setting.time_chooseHERO+2

		self.playerList[data['roleID']]['ok']=0
		self:addSyncMsg({ri={id=self.playerList[data['roleID']]['id'],i=self.playerList[data['roleID']]['i'],a=self.playerList[data['roleID']]['a'],t=self.playerList[data['roleID']]['t'],tf=self.playerList[data['roleID']]['tf'],eg=self.playerList[data['roleID']]['eg'],si=self.playerList[data['roleID']]['si'],d=-1,gn=(self.playerList[data['roleID']]['guild']>0 and self.guildName[self.playerList[data['roleID']]['i']] or ""),ba=self.playerList[data['roleID']]['ba']}})

		self:loginWaitingList({})
		debuglog('start0 '..self.cjson.encode(self.serverSetting))
		return {zz=1,server=self.serverSetting}
	end

	if data['roleID']~=nil and self.playerList[data['roleID']]~=nil and self.status==self.READY and data['game']['start']~=nil and data['game']['start']==1 then
		local items = {}
		for k,v in pairs(self.itemListFilter.heroList) do
			items[#items+1] = v:getAllInfo()
		end
		for k,v in pairs(self.itemListFilter.towerList) do
			items[#items+1] = v:getAllInfo()
		end
		self.playerList[data['roleID']]['ok']=1
		return {zz=1,i=items,t=self:getGameTime()}
	end
	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==1 then
		for k,v in pairs(self.itemListFilter.heroList) do
			debuglog('jaylog start 1 hero itmeID:'..k..' roleId:'..v.attribute.roleId)
		end
		self.itemListFilter.heroList[data['roleID']]:addApiJobGetTask()
		local items = {}
		local mitems = {}
		for k,v in pairs(self.itemListFilter.heroList) do
			items[#items+1] = v:getAllInfo()
			mitems[#mitems+1] = v:__genMoveMsg(true)
			--debuglog('jayLog Items : '..self.cjson.encode(items))
		end
		debuglog('jaylog clientInit start 1 Items:'..self.cjson.encode(items))
		--return {zz=1,game={start=2,msize=self.mapSize},i=items,t=self:getGameTime()}
		return {zz=1,game={start=5,msize=self.mapSize},i=items,m=mitems,t=self:getGameTime()}
	end
	--[[
	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==2 then
		local items = {}
		for k,v in pairs(self.itemListFilter.towerList) do
			items[#items+1] = v:getAllInfo()
		end
		return {zz=2,game={start=3,msize=self.mapSize},i=items,t=self:getGameTime()}
	end
	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==3 then
		local items = {}
		for k,v in pairs(self.itemListFilter.soldierList) do
			if v.teamOrig=="A" then
				items[#items+1] = v:getAllInfo()
			end
		end
		return {zz=1,game={start=4,msize=self.mapSize},i=items,t=self:getGameTime()}
	end
	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==4 then
		local items = {}
		for k,v in pairs(self.itemListFilter.soldierList) do
			if v.teamOrig=="B" then
				items[#items+1] = v:getAllInfo()
			end
		end
		return {zz=1,game={start=5,msize=self.mapSize},i=items,t=self:getGameTime()}
	end
	]]
	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==5 then
		local items = {}
		local mitems = {}
		for k,v in pairs(self.itemListFilter.soldierList) do
			--if v.teamOrig=="" then
			if v.deadTime<self.gameTime then
				--self.forceUpdate = true
				items[#items+1] = v:getAllInfo()
				mitems[#mitems+1] = v:__genMoveMsg(true)
			end
			--end
		end
		for k,v in pairs(self.itemListFilter.npcList) do
			--if v.teamOrig=="" then
			if v.deadTime<self.gameTime then
				--self.forceUpdate = true
				items[#items+1] = v:getAllInfo()
				mitems[#mitems+1] = v:__genMoveMsg(true)
			end
			--end
		end
		for k,v in pairs(self.itemListFilter.noBeFightList) do
			--if v.teamOrig=="" then
			if v.deadTime<self.gameTime then
				--self.forceUpdate = true
				items[#items+1] = v:getAllInfo()
				mitems[#mitems+1] = v:__genMoveMsg(true)
			end
			--end
		end
		self.forceUpdate = true
		debuglog('start 5 syn msg:'..self.cjson.encode(mitems))
		--return {zz=1,game={start=6,msize=self.mapSize},i=items,t=self:getGameTime()}
		return {zz=1,game={start=8,msize=self.mapSize},i=items,m=mitems,t=self:getGameTime()}
	end
	--[[
	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==6 then
		local items = {}
		self.forceUpdate = true
		local id = data['roleID']
		if data['roleID']>90 then
			id = data['roleID']-90
		end
		local a = self:heroInfo(id,id)
		for k,v in pairs(self.itemListFilter.heroList) do
			items[#items+1] = v:__genMoveMsg(true)
		end
		return {zz=1,game={start=7,msize=self.mapSize},m=items,t=self:getGameTime()}	--,hi=a['hi']
	end
	if self.status==self.RUNNING and data['game']['start']~=nil and data['game']['start']==7 then
		local items = {}
		self.forceUpdate = true
		for k,v in pairs(self.itemListFilter.soldierList) do
			items[#items+1] = v:__genMoveMsg(true)
		end
		return {zz=1,game={start=8,msize=self.mapSize},m=items,t=self:getGameTime()}     --1uto=self.itemListFilter.heroList[data['roleID'] ].isAuto and 2 or 0}
	end
	]]

	local team = ""
	local teamlist = {}
	local surrenderTime = 0
	if (self.status==self.RUNNING and isset(data['game']['reset']) and data['game']['reset']==2 and (self.setting.surrender_time>self.gameTime and  ISDEV==nil and  ISUAT==nil) ) then

		self:addSyncMsg({bc={{mid=46,zz=3,i=data['roleID']}}})
	elseif (self.status==self.RUNNING and data['game']['reset']~=nil and data['game']['reset']==2) then

			if (self.playerList[data['roleID']]['t']~="B") then
				team="A"
				teamlist=self.itemListFilter.heroTeamAList
			else
				team="B"
				teamlist=self.itemListFilter.heroTeamBList
			end

			if (self.lastSurrenderTime[team]>self.gameTime and  ISDEV==nil and  ISUAT==nil) then

				self:addSyncMsg({bc={{mid=47,zz=3,i=data['roleID']}}})
			else

			surrenderTime1=15
			--print("SET 投降时间 surrenderTime"..self.cjson.encode(self.surrenderTime))
			if (self.surrenderTime[team]==0 or self.surrenderTime[team]==nil) then
				self.surrenderTime[team]=self:getGameTime()+surrenderTime1
				--print("SET 投降时间 1surrenderTime"..self.cjson.encode(self.surrenderTime))
				self.trySurrender = self.trySurrender + 1
				for k,value in pairs(teamlist) do
					--print("投降那队的id:"..value.itemID)
					if (value.teamOrig==team) then
					if (value.itemID==data['roleID']) then
						value.isSurrender=true
						value.surrenderOrder=1
					else
						value.isSurrender=nil
						value.surrenderOrder=0
					end
					if value.syncMsg['s'] == nil then
						value.syncMsg['s'] = {}
					end
					--print("投降p1",1)
					--print("投降p2",(value.isSurrender==nil and 0 or 1))

					value.syncMsg['s'][#value.syncMsg['s']+1]={s=31,r=surrenderTime1-1,t=surrenderTime1,i=value.itemID,d=0,p1=1,p2=(value.isSurrender==nil and 0 or 1)}
					--value.statusList[31]={s=31,r=self.gameTime,t=surrenderTime1+1,i=value.itemID,p1=1,p2=(value.isSurrender==nil and 0 or 1)}
					value:addStatusList({s=31,r=self.gameTime,t=surrenderTime1+1,i=value.itemID,p1=1,p2=(value.isSurrender==nil and 0 or 1)})
					end
				end

			else

				local obj=self.allItemList[data['roleID']]
				if (obj.statusList[31]~=nil and obj.isSurrender==nil) then
					obj.isSurrender=true
					--print("同意投降.................")
					surrenderTime=15
					local numOfA=0
					local numOfD=0
					local orderlist={}

					for k,value in pairs(teamlist) do
						if (value.teamOrig==team) then
						if (value.isSurrender==false) then
							numOfD = numOfD + 1
							if (value.surrenderOrder>0) then
								orderlist[value.surrenderOrder]=2
							end
						elseif (value.isSurrender==true) then
							numOfA = numOfA + 1
							if (value.surrenderOrder>0) then
								orderlist[value.surrenderOrder]=1
							end
						end
						end
					end
					--print("投降35")
					table.sort(orderlist)
					local p1=1
					for kk,vv in pairs(orderlist) do
						p1=p1+math.pow(10,(numOfD+numOfA-kk))*vv
						--print("投降xp1",p1)
					end

					obj.surrenderOrder=numOfD+numOfA
					obj.statusList[31]['p2']=1
					for k,value in pairs(teamlist) do
						if (value.teamOrig==team) then
							if (isset(value.statusList[31])) then
								if value.syncMsg['s'] == nil then
									value.syncMsg['s'] ={}
								end
								 --	print("投降p1",p1)
								 --	print("投降p2",(value.isSurrender==nil and 0 or 1))
								 --如果在status r = 結束時間 t = total 時間
								value.syncMsg['s'][#value.syncMsg['s']+1]={s=31,r=surrenderTime-(self.gameTime-value.statusList[31]['r'])-1,t=surrenderTime-(self.gameTime-value.statusList[31]['r']),i=value.itemID,p1=p1,p2=(value.isSurrender==nil and 0 or 1)}
								value:addStatusList({s=31,r=value.statusList[31].r,t=value.statusList[31].t,i=value.statusList[31].i,p1=p1,p2=(value.isSurrender==nil and 0 or 1)})
								 --value.statusList[31]={s=31,r=self.gameTime,t=surrenderTime1+1,i=value.itemID,p1=p1,p2=(value.isSurrender==nil and 0 or 1)}
								 --value.statusList[31]['p1']=p1
							end
						end
					end

				end
			end
		end
	end

	if (self.status==self.RUNNING and data['game']['reset']~=nil and data['game']['reset']==3) then

		if (self.playerList[data['roleID']]['t']~="B") then
			team="A"
			teamlist=self.itemListFilter.heroTeamAList
		else
			team="B"
			teamlist=self.itemListFilter.heroTeamBList
		end
				--echo "Log9\t".date("Y-m-d H:i:s")."\t"."surrender reject team ".data['roleID']."\n"
		surrenderTime=15
		if (self.surrenderTime[team]>0) then
			local obj=self.allItemList[data['roleID']]
			if (isset(obj.statusList[31]) and obj.isSurrender==nil) then
				obj.isSurrender=false
				local numOfA=0
				local numOfD=0
				local orderlist={}
				for k,value in pairs(teamlist) do
					if (value.teamOrig==team) then
					if (value.isSurrender==false) then
						numOfD = numOfD + 1
						if (value.surrenderOrder>0) then
							orderlist[value.surrenderOrder]=2
						end
					elseif (value.isSurrender==true) then
						numOfA = numOfA + 1
						if (value.surrenderOrder>0) then
							orderlist[value.surrenderOrder]=1
						end
					end
					end
				end
				local p1=2
				table.sort(orderlist)
				for kk,vv in pairs(orderlist) do
					p1=p1+math.pow(10,(numOfD+numOfA-kk))*vv
				end

				obj.surrenderOrder=numOfD+numOfA
				obj.statusList[31]['p2']=1
				for k,value in pairs(teamlist) do
					if (value.teamOrig==team and isset(value.statusList[31])) then
						if value.syncMsg['s'] == nil then
								value.syncMsg['s'] ={}
						end
						value.syncMsg['s'][#value.syncMsg['s']+1]={s=31,r=surrenderTime-(self.gameTime-value.statusList[31]['r'])-1,t=surrenderTime-(self.gameTime-value.statusList[31]['r']),i=value.itemID,p1=p1,p2=(value.isSurrender==nil and 0 or 1)}
						value.statusList[31]['p1']=p1
					end
				end
			end
		end
	end

	return data
end

--- 玩家断线后设置玩家离线
-- @param data table - clinent发送的数据
-- @return data table - 原数据返回
function World1:logout(data)
	if data['roleID']==nil or data['loginID']==nil then
		return data
	end
	if self.playerList[data['roleID']]~=nil then
		self.playerList[data['roleID']]['online'] = false
	end
	if self.status>=self.READY and self.status<self.GAMEOVER then
		return data
	end
end

function World1:login(data)
	-- print("...................lua 版的login  2222 \n")
	-- print("login status star : "..self.status)
	-- print("login GAMEOVER star : "..self.GAMEOVER)
	-- print("login WAITB star : "..self.WAITB)
	-- print("login gameModel star : "..self.gameModel)
	-- print("login READY star : "..self.READY)
	-- print("call 没 call.......................")

	local ver1 = 2
	local ver2 = 2
	if (self.status>=self.GAMEOVER and self.gameOverTime>self:getGameTime()) or data['l']['ver']==nil or (ver1<ver2) then
		data['l'] = {}
		data['l']['t'] = 'C'
		if data['l']['ver']==nil or (ver1<ver2) then
			data['l']['i'] = -4
		else
			data['l']['i'] = -3
			if data['i']~=nil and self.playerList[data['i']]~=nil and self.playerList[data['i']]['p']==data['l']['p'] then
				self.playerList[data['i']] = nil
				players = {}
				for i=1,self.gameRoomSetting['maxPlayer'] do
					if self.playerList[i]~=nil then
						players[self.playerList[i]['p']] = table.deepcopy(self.playerList[i])
					end
				end
				self:setPlayerListMemcache(players)
			end
		end
		return data
	end

	if self.playerList[data['l']['i']]==nil then
		data['l'] = {}
		data['l']['i'] = -1
		return data
	end

	--if self.gameModel==11 and self.status==self.WAITB then
	--登录直接开始
	if self.gameModel==11 then
		--self:ready()
	end

	local found = false

	data['ri'] = {}
	--data['l']['i'] = -2
	local guildList = {A=0,B=0}
	local delay = -1
	for i=1,self.gameRoomSetting['maxPlayer'] do
		if self.playerList[i]~=nil and self.playerList[i]['id']~=nil then
			delay = -1
			--if self.playerList[i]['ok']==nil then
			--	delay = self.waitingTime - (self.serverTime - self.startWaitingTime)
				--debuglog("server time "..self.serverTime.." start "..self.startWaitingTime.." wait "..self.waitingTime)
			--end
			data['ri'][#data['ri']+1] = {
				id=self.playerList[i]['id'],
				i=self.playerList[i]['i'],
				a=self.playerList[i]['a'],
				t=self.playerList[i]['t'],
				--tf=self.playerList[i]['tf'],
				--eg=self.playerList[i]['eg'],
				--si=self.playerList[i]['si'],
				--delay=delay
				--gn=self.playerList[i]['guildName'],
				--ba=self.playerList[i]['ba']
			}
			if self.playerList[i]['id']==data['l']['id'] then
				found = true
				data['l']['i']=i
				data['l']['a']=self.playerList[i]['a']
				if self.gameRoomSetting['sameTeam'] then
					data['l']['t']="A"
				else
					data['l']['t']=((i%2==1) and "A" or "B")
				end
				data['l']['mid']=self.gameID
				data['l']['m']=self.playerList[i]['m']
				data['l']['msize']=self.mapSize
				--data['l']['oh']=self.playerList[i]['oh']
				--data['l']['ph']=table.values(self.playerList[i]['ph'])
				--data['l']['hh']=self.playerList[i]['hh']

				--if self.banHeroes[data['l']['t']]~=nil then
				--	data['l']['bh'] = table.values(self.banHeroes[data['l']['t']])
				--end
				-- self.playerList[i]['online'] = true
				self.playerList[i]['recnt'] = self.playerList[i]['recnt'] + 1
				self.playerList[i]['ip'] = data['l']['ip']
				--print("setIPaddress1 :",data['l']['ip'])
								if isset(self.allItemList[i]) then
									--print("setIPaddress:",data['l']['ip'])
										self.allItemList[i]:setIPaddress(data['l']['ip'])
										--self.allItemList[i]:setAI(0)
								end
			end
		end
	end
	debuglog("skinHeroes  world1 data-ph"..self.cjson.encode(data['l']['ph']))
	data['l']['run'] = 1

	-- print('login ok ~~~ '..cjson.encode(data))
	-- print("login status end : "..self.status)
	-- print("login GAMEOVER end : "..self.GAMEOVER)
	-- print("login WAITB end : "..self.WAITB)
	-- print("login gameModel end : "..self.gameModel)
	-- print("login READY end : "..self.READY)
	if self.status>=self.READY then
		 return data
	end

	--data['l']['run'] = 0
	--print("run ============= 0")
	--return self:loginWaitingList(data)
	--return data
end

--暂时废弃
-- function World1:createEquip(id,classtype,level)
	-- if classtype ==nil then
	-- 	classtype = 0
	-- end

	-- if level == nil then
	-- 	level = 1
	-- end
	-- local classtable ={}
	-- classtable['6'] =  'SEquip6'
	-- classtable['7'] =  'SEquip7'
	-- classtable['12'] =  'SEquip12'
	-- classtable['13'] =  'SEquip13'
	-- classtable['14'] =  'SEquip14'
	-- classtable['19'] =  'SEquip19'
	-- classtable['20'] =  'SEquip20'
	-- classtable['21'] =  'SEquip21'
	-- classtable['26'] =  'SEquip26'
	-- classtable['27'] =  'SEquip27'
	-- classtable['28'] =  'SEquip28'
	-- classtable['30'] =  'SEquip30'
	-- classtable['32'] =  'SEquip32'
	-- classtable['33'] =  'SEquip33'
	-- classtable['34'] =  'SEquip34'
	-- classtable['35'] =  'SEquip35'
	-- classtable['40'] =  'SEquip40'
	-- classtable['41'] =  'SEquip41'
	-- classtable['42'] =  'SEquip42'
	-- classtable['43'] =  'SEquip43'
	-- classtable['44'] =  'SEquip44'
	-- classtable['45'] =  'SEquip45'
	-- classtable['46'] =  'SEquip46'
	-- classtable['47'] =  'SEquip47'
	-- classtable['48'] =  'SEquip48'
	-- classtable['49'] =  'SEquip49'
	-- classtable['50'] =  'SEquip50'
	-- classtable['51'] =  'SEquip51'
	-- classtable['52'] =  'SEquip52'
	-- classtable['53'] =  'SEquip'
	-- classtable['54'] =  'SEquip'
	-- classtable['55'] =  'SEquip'
	-- classtable['56'] =  'SEquip56'
	-- classtable['57'] =  'SEquip'
	-- classtable['58'] =  'SEquip58'
	-- classtable['59'] =  'SEquip'
	-- classtable['60'] =  'SEquip'
	-- classtable['61'] =  'SEquip'
	-- classtable['62'] =  'SEquip'
	-- classtable['63'] =  'SEquip'
	-- classtable['64'] =  'SEquip'
	-- classtable['65'] =  'SEquip'
	-- classtable['66'] =  'SEquip'
	-- classtable['67'] =  'SEquip'
	-- classtable['68'] =  'SEquip'
	-- classtable['69'] =  'SEquip'
	-- classtable['70'] =  'SEquip'
	-- classtable['71'] =  'SEquip'
	-- classtable['72'] =  'SEquip'
	-- classtable['73'] =  'SEquip'
	-- classtable['75'] =  'SEquip75'
	-- classtable['76'] =  'SEquip76'
	-- classtable['77'] =  'SEquip77'
	-- classtable['78'] =  'SEquip78'
	-- classtable['79'] =  'SEquip79'
	-- classtable['80'] =  'SEquip80'
	-- classtable['81'] =  'SEquip81'
	-- classtable['82'] =  'SEquip82'
	-- classtable['83'] =  'SEquip83'
	-- classtable['104']='SEquip6'
	-- classtable['105']='SEquip6'
	-- classtable['106']='SEquip6'
	-- classtable['107']='SEquip7'
	-- classtable['108']='SEquip7'
	-- classtable['109']='SEquip7'
	-- classtable['110']='SEquip12'
	-- classtable['111']='SEquip12'
	-- classtable['112']='SEquip12'
	-- classtable['113']='SEquip13'
	-- classtable['114']='SEquip13'
	-- classtable['115']='SEquip13'
	-- classtable['116']='SEquip14'
	-- classtable['117']='SEquip14'
	-- classtable['118']='SEquip14'
	-- classtable['119']='SEquip19'
	-- classtable['120']='SEquip19'
	-- classtable['121']='SEquip19'
	-- classtable['122']='SEquip20'
	-- classtable['123']='SEquip20'
	-- classtable['124']='SEquip20'
	-- classtable['125']='SEquip21'
	-- classtable['126']='SEquip21'
	-- classtable['127']='SEquip21'
	-- classtable['128']='SEquip26'
	-- classtable['129']='SEquip26'
	-- classtable['130']='SEquip26'
	-- classtable['131']='SEquip27'
	-- classtable['132']='SEquip27'
	-- classtable['133']='SEquip27'
	-- classtable['134']='SEquip28'
	-- classtable['135']='SEquip28'
	-- classtable['136']='SEquip28'
	-- classtable['137']='SEquip33'
	-- classtable['138']='SEquip33'
	-- classtable['139']='SEquip33'
	-- classtable['140']='SEquip34'
	-- classtable['141']='SEquip34'
	-- classtable['142']='SEquip34'
	-- classtable['143']='SEquip35'
	-- classtable['144']='SEquip35'
	-- classtable['145']='SEquip35'
	-- classtable['146']='SEquip40'
	-- classtable['147']='SEquip40'
	-- classtable['148']='SEquip40'
	-- classtable['149']='SEquip41'
	-- classtable['150']='SEquip41'
	-- classtable['151']='SEquip41'
	-- classtable['152']='SEquip42'
	-- classtable['153']='SEquip42'
	-- classtable['154']='SEquip42'
	-- --[[
	-- if classtype == 0 then
	-- 	if classtable[self.tostring(id)]~=nil then
	-- 		local class1 = classtable[self.tostring(id)]
	-- 		local x = require('gameroom.'..class1).new(id,self)
	-- 		x.className = 'SEquip'..id
	-- 		return x
	-- 	else
	-- 		local x = require("gameroom.SEquip").new(id,self)
	-- 		x.className = 'SEquip'..id
	-- 		return x
	-- 	end
	-- end
	-- ]]
	-- if classtype == 1 then
	-- end
-- end

--- 游戏房结算,结算sql,组织gameOverMsg,call api结算统计
-- @param null
-- @return null
function World1:gameOver()
		debuglog("start  gameOver...")
		-- new game over step start
		local winner = ''
		local winarr = {}
		local newAPIparameterArray = {}
		local bonus = {}
		local bonusStr = ''
		local tmpbonus = {}
		if self.counter.pointsA>=self.gameRoomSetting['gameLimitedPoints'] then
			winner = 'A'
		end
		if self.counter.pointsB>=self.gameRoomSetting['gameLimitedPoints'] then
			winner = 'B'
		end
		for k,v in pairs(self.itemListFilter.heroList) do
			winarr[""..v.itemID] = 0
			v.counterObj:setCounter("battle_pvp")
			if self.counter.pointsA>=self.gameRoomSetting['gameLimitedPoints'] and v.team=='A' then
				v.counterObj:setCounter("battle_pvpWin")
				winarr[""..v.itemID] = 1
			end
			v:addApiJobUpdateTask()
			if self.counter.pointsB>=self.gameRoomSetting['gameLimitedPoints'] and v.team=='B' then
				winarr[""..v.itemID] = 1
			end
			if (bonus[""..v.itemID]==nil) then
				bonus[""..v.itemID] = {}
			end
			bonus[""..v.itemID][#bonus[""..v.itemID]+1] = {
				d=1,
				i=1,
				q=1
			}
		end
		for kkk,vvv in pairs(bonus) do
			for kkk2,vvv2 in pairs(vvv) do
				tmpbonus[#tmpbonus+1]=vvv2['i']..","..vvv2['q']
			end
		end
		bonusStr=implode(';',tmpbonus)

		local count=0
		for i=1,self.gameRoomSetting['maxPlayer'] do
			if (isset(self.playerList[i])) then
				count = count + 1
			end
		end

		-- save game_result --
		local sql = "update game_result set status=1,"
		.."starttime='"..os.date("%Y%m%d%H%M%S",(os.time()-math.ceil(self.startTime)))
		.."', gametime='"..self.gameTime
		.."', endtime='"..os.date("%Y%m%d%H%M%S",os.time())
		.."', mapmodel='"..(self.gameModel==10 and 10 or (self.mapSize==9 and 9 or (self.className=="World3" and 3 or (self.className=="World4" and (self.isTeam and 8 or 4) or (self.isTraining and 6 or 1)))))
		.."', outcome='"..winner
		.."', scoreA='"..self.counter['pointsA']
		.."', scoreB='"..self.counter['pointsB']
		.."',isSurrender='"..(self.surrenderTeam~="" and 1 or 0)
		.."',trySurrender='"..self.trySurrender
		.."',peopleCount='"..count
		.."' where gameID='"..self.gameID.."'"
		debuglog('sql 1 :'..sql)
		self:saveDBData(sql)

		-- gameScore table --
		local gameOverMsgScore = {}
		self.gameOverMsg['game']['reset'] = 1
		self.gameOverMsg['game']['pointsA'] = self.counter['pointsA']
		self.gameOverMsg['game']['pointsB'] = self.counter['pointsB']
		self.gameOverMsg['game']['gameTime'] = self.gameTime
		self.gameOverMsg['game']['w'] = winarr
		self.gameOverMsg['game']['bonus'] = bonusStr
		--[[
		local bonus = {}
		for i=1,self.maxPlayer do
			if (bonus[i]==nil) then
				bonus[i] = {}
			end
			bonus[i][#bonus[i]+1] = {
				type=1,
				id=1,
				qty=1
			}
		end
		]]
		for i=1,self.gameRoomSetting['maxPlayer'] do
			if (isset(self.playerList[i])) then
				--[[
				local gameScore = {
					i = self.playerList[i]['i'],
					id = self.playerList[i]['id'],
					p = self.playerList[i]['p'],
					t = self.playerList[i]['t'],
					points = self.allItemList[i]['counter']['points'],
					bonus = bonus[i]
				}
				gameOverMsgScore[i]=gameScore
				]]

				-- print("游戏结束的时候需要扣除体力 start:",StartStr)
				-- print("游戏结束的时候需要扣除体力 powreduce:",powreduce)
				-- print("结算的时候金币奖励 ,i:",i)
				-- print("结算的时候金币奖励 ,gold:",gold)
				-- print("结算的时候金币奖励 ,vipgold:",vipgold)
				-- print("结算的时候金币奖励 ,itemgold:",itemgold)
				-- print("结算的时候金币奖励 ,mvpgold:",mvpgold)
				local StartStr='1'
				local exp = 0
				local heroexp = 0
				local adjGold = 0
				local penalty = 0
				local newRank = 0
				local powreduce = 0
				local mvpplayerid = 0
				local point = 0
				local gold = 0
				local isWin = 0
				local bonusStr = ''
				local tmpbonus = {}
				local serverIP=""
				if (isset(self.playerList[i]['commip'])) then
					serverIP=self.playerList[i]['commip']
				end

				for kkk,vvv in pairs(bonus) do
					for kkk2,vvv2 in pairs(vvv) do
						tmpbonus[#tmpbonus+1]=vvv2['i']..","..vvv2['q']
					end
				end
				bonusStr=implode(';',tmpbonus)

				local newAPIparameter = {
							start=StartStr,
							game_id=self.gameID,
							exp=exp,								--exp+vipexp+itemexp+extraExp
							silver=gold,							--gold+vipgold+itemgold+mvpgold
							hero_id=self.playerList[i]['a'],
							play_win=isWin==1 and 1 or 0,
							play_lose=isWin==0 and 1 or 0,
							play_draw=isWin==2 and 1 or 0,
							penalty=(penalty>0 and 1 or 0),
							play_hero_kill=self.counter['killhero'],
							play_assist_kill=0,							--self.counter['killassistant']
							play_dead=self.counter['killed'],
							play_pvp=1,
							play_gvb=0,
							play_vs_random=(self.gameModel~=nil and self.gameModel==10) and 0 or (gamemode==1 and 1 or 0),
							play_vs_33=(self.gameModel~=nil and self.gameModel==10) and 0 or (gamemode==2 and 1 or 0),
							play_vs_ai=gamemode==3 and 1 or 0,
							play_vs_guild=gamemode==4 and 1 or 0,
							play_vs_training=(self.gameModel~=nil and self.gameModel==10) and 0 or (gamemode==6 and 1 or 0),
							play_vs_team=self.isTeam and 1 or 0,
							play_vs_gambling=(self.gameModel~=nil and self.gameModel==10) and 1 or 0,
							rank=newRank,
							play_time=self.gameTime,
							powreduce=powreduce,
							mapmodel=self.gameModel,
							player_rebirth=self.allItemList[i].counter['revive'],
							adjGold=0,				--adjGold
							mvplist=0				--mvpplayerid
				}
				newAPIparameterArray[self.sFormat(self.playerList[i]['p'])] = newAPIparameter
				--debuglog('start to save newAPIparameterArray'..self.cjson.encode(newAPIparameter)..'   '..self.playerList[i]['p']..'  '..self.cjson.encode(newAPIparameterArray))

				if self.playerList[i]['recnt'] ==nil then
					self.playerList[i]['recnt'] =0
				end

				if self.allItemList[i].team==winner then
					isWin = 1
				end

				--保存每个玩家战斗记录--
				sql = "insert into game_player_result (updatetime,createtime,gameID,playerID,camp,win,hero,level,equip1,equip2,equip3,equip4,equip5,equip6,equip1stlvl1,equip1stlvl3,"..
					"Struck,Killed,Assists,KillSoldiers,KillTowers,killMonsters,gold,exp,skill1,skill2,skill3,skill4,skill1st,skillkill1,skillkill2,skillkill3,skillkill4,fastRevive,ipaddr,ping,totalIdle,maxIdle,point,newRank,serverIP,bonus,gamePoint,prizeOperate,mvp,banHero) values (now(),now(),'"..
					self.gameID.."','"..																								--gameID
					self.playerList[i]['p'].."','"..																		--playerID
					self.allItemList[i].teamOrig.."','"..																--camp
					(isWin).."','"..																										--win
					self.playerList[i]['a'].."','"..																		--hero roleID
					self.allItemList[i].attribute.level.."','"..												--level
					"','"..														--equip1
					"','"..														--equip2
					"','"..														--equip3
					"','"..														--equip4
					"','"..														--equip5
					"','"..														--equip6
					gold.."','"..																												--equip1stlvl1
					exp.."','"..																												--equip1stlvl3
					self.allItemList[i]:getCounter('killhero').."','"..									--Struck										--self.allItemList[i].counter['killhero'].."','"..
					self.allItemList[i]:getCounter('killed').."','"..										--Killed										--self.allItemList[i].counter['killed'].."','"..
					self.mAbs(self.allItemList[i]:getCounter('hurted')).."','"..				--Assists										--self.allItemList[i].counter['killassistant'].."','"..
					self.mAbs(self.allItemList[i]:getCounter('hurt')).."','"..					--KillSoldiers							--self.allItemList[i].counter['killsoldier'].."','"..
					self.allItemList[i]:getCounter('getFlag').."','"..									--KillTowers								--self.allItemList[i].counter['killTower']
					self.mAbs(self.allItemList[i]:getCounter('cure')).."','"..					--killMonsters							--self.allItemList[i].counter['killmonster'].."','"..
					gold.."','"..																												--gold
					exp.."','"..																												--exp
					"0','"..																														--skill1
					"0','"..																														--skill2
					"0','"..																														--skill3
					"0','"..																														--skill4
					self.playerList[i]['recnt'].."','"..																--skill1st
					"0','"..																														--skillkill1
					"0','"..																														--skillkill2
					"0','"..																														--skillkill3
					"0','"..																														--skillkill4
					"0','"..																														--fastRevive
					self.allItemList[i].ipaddress.."','"..															--ipaddr
					self.allItemList[i].pingtime.."','"..																--ping
					self.allItemList[i].totalIdleTime.."','"..													--totalIdle
					self.allItemList[i].maxIdleTime.."','"..														--maxIdle
					point.."','"..																											--point
					newRank.."','"..																										--newRank
					serverIP.."','"..																										--serverIP
					bonusStr..																													--bonus
					"','0','"..																													--gamePoint
					(self.allItemList[i].skinNum~=nil and self.allItemList[i].skinNum or 0)..  		--prizeOperate
					"','0','"..																																		--mvp
					i.."')"																																			--banHero    玩家房间顺序ID
				debuglog('sql 2 every player : '..sql)

				if ( self.tonumber(self.playerList[i]['p']) >0) then
					self:saveDBData(sql)
				end
				debuglog('newAPIparameter : '..self.cjson.encode(newAPIparameter) ..' p: '..self.cjson.encode(self.playerList[i]['p']))
			end
		end
		
		--self.gameOverMsg['game']['gameScore'] = gameOverMsgScore
		debuglog('gameOverMsg : '..self.cjson.encode(self.gameOverMsg))

		self.gameOverStatistic={}
		for k,value in pairs(self.itemListFilter.heroList) do
			self.gameOverStatistic[value.itemID] = {
				i = value.itemID,
				killhero = value.counter['killhero'],
				hilled = value.counter['killed'],
				hurted = value.counter['hurted'],
				hurt = value.counter['hurt'],
				cure = value.counter['cure'],
				getFlag = value.counter['getFlag'],
				points = value.counter['points']
			}
		end

		--战斗结算call api
		local finishapi = self.webapiurl..'internalapi/finishGameRoomMutil'
		local finishapi2 = self.webapiurl2..'internalapi/finishGameRoomMutil'
		debuglog('newAPIparameterArray...........:' .. self.cjson.encode( newAPIparameterArray ) )
		local url=finishapi..'/?data='..string.urlencode(self.cjson.encode(newAPIparameterArray))..'&version=999'
		local webresult=self:file_get_contents(url)
		if (webresult==false) then
			url=finishapi2..'/?data='..string.urlencode(self.cjson.encode(newAPIparameterArray))..'&version=999'
			webresult=self:file_get_contents(url)
		end
		debuglog('url : '..url..' result:'..webresult)

		-- 玩家离开清除房间玩家数据 --
		local players={}
		for i=1,self.gameRoomSetting['maxPlayer'] do
			if (isset(self.playerList[i]) and self.playerList[i]['online']==false) then
				if self.gameRoomSetting['hasMapZone']~=true and (self.tonumber(self.playerList[i]['p'])>0) then
				self:redisCall('srem','room0',self.playerList[i]['p'])
				end
				if (self.tonumber(self.playerList[i]['p'])>12) then
					rc = {i=0,m=self.playerList[i]['id'].." 离开了房间",t="",d=0}
					self:addSyncMsg({rc=rc})
				end
				--self.playerList[i]=nil
			elseif (isset(self.playerList[i])) then
				players[self.playerList[i]['p']]=self.playerList[i]
				if self.gameRoomSetting['hasMapZone']~=true and (self.tonumber(self.playerList[i]['p'])>0) then
				self:redisCall('srem','room0',self.playerList[i]['p'])
				end
			end
		end
		for i=91,100 do
			if self.gameRoomSetting['hasMapZone']~=true and (isset(self.monitorPlayerList[i])) then
				self:redisCall('srem','room0',self.monitorPlayerList[i]['p'])
				--self.monitorPlayerList[i]=nil
			end
		end
		players['END']=true
		self:setPlayerListMemcache(players)
		debuglog("有没有call到结束/////////////")
		self.gameOverTime = self.gameTime
		self.status=self.GAMEOVER


		-- new game over step end
end

--- 取api返回数据
-- @param rUrl string - 整个url,包括所有参数
-- @return b string - call url返回的结果
function World1:file_get_contents( rUrl )
	local url = require("socket.url")
		local http = require("socket.http")
		local b,h = http.request(rUrl)
		if h==200 then
			print("file_get_contents 成功...",rUrl)
			 return b
		end
	return ""
end


---设置地图size
-- @param total int - 游戏房间人数
-- @return null
-- function World1:setMapSize(total)
	-- --- self.mapSize , 1 = 1v1 , 2 = 3v3 , 9 = 5v5 , 10 = 2v2
	-- self.mapSize = math.floor(total/2)
	-- if self.gameModel==11 then
	-- 	self.mapSize = 10
	-- end

-- end

--- GAMEOVER 游戏结束时执行
-- @param null
-- @return null
function World1:statusGAMEOVER()
	if (self.gameOverTime<=self.gameTime and self.gameOverWaitTime<=self.gameTime and self.gameOverMsg~=nil) then
		debuglog('jayLog start syn gameOverMsg:'..self.cjson.encode(self.gameOverMsg))
		self:addSyncMsg(self.gameOverMsg)
		self.gameOverWaitTime = self.gameTime + 1
	end

	if (self.gameOverTime+5<=self.gameTime) then
		self.gameOverMsg = nil
		os.exit()
	end
end


--- RUNNING 遊戲loop
-- @return null
function World1:statusRUNNING()

	if self.status~=self.GAMEOVER and self.counter['pointsA']>=self.gameRoomSetting['gameLimitedPoints'] or self.counter['pointsB']>=self.gameRoomSetting['gameLimitedPoints'] then
		self:gameOver()
		return nil
	end
	--debuglog('gameLimitedTime:'..self.cjson.encode(self.gameRoomSetting)..' gameTime:'..self:getGameTime())

	if self.status~=self.GAMEOVER and self.gameRoomSetting['gameLimitedTime']<=self:getGameTime() then   		-- and (self.isTeam or self.gameModel==10 or self.gameModel==11 or self.gameModel==99)
		self:gameOver()
		return nil
	end


	local tmpPointOfA = self.counter['pointsA']
	local tmpPointOfB = self.counter['pointsB']
	--local tmpNumOfKillA = self.numOfKillA
	--local tmpNumOfKillB = self.numOfKillB

	--self:genTransitDoor()

	--self:genInstantBuffEquip()

	--------  start core world


	self.numOfKillA = 0
	self.numOfKillB = 0

	-- all item move calculation
	self:moveCalculation()

	-- hero and soldier move and update loop
	for k,v in pairs(self.itemListFilter.soldierList) do
		if self.forceUpdateSoldier then
				v.dirty = true
		end
		v:syncInfo()
		if not v:isDead() then
			v:move()
		end
	end
	for k,v in pairs(self.itemListFilter.heroList) do
		if self.gameFlag['lastEnergyID']~=0 and self.gameFlag['lastEnergyTime']~=0 and self.gameFlag['lastEnergyID']==v.itemID and (self.gameFlag['lastEnergyTime']+3)<self.gameTime then
			v:addStatusList(self.energyStatus,0)
			self.gameFlag['lastEnergyID'] = 0
			self.gameFlag['lastEnergyTime'] = 0
		end
		if self.forceUpdate then
			v.dirty = true
		end
		v:syncInfo()
		if not v:isDead() then
			v:move()
			if v.autoMove then
				local path = v.movePath[""..self.mapModel]
				--debuglog('jaylog autoMove '..self.mapModel..' '..self.cjson.encode(v.movePath)..' x:'..v.posX..' y:'..v.posY)
				v:moveTo(path['toX'],path['toY'])
			elseif v.autoFollow then
				local x,y = 0,0
				local targetObj = self.allItemList[v.autoFollowTargetID]
				if targetObj==nil then
					v:setAutoFollow()
				else
					local len = self.setting['followStopRange']/self.setting['AdjustVisRange']
					local dist = self.setting['autoFollowRange']/self.setting['AdjustVisRange']
					if v:distance(targetObj.posX,targetObj.posY,v.autoFollowTargetID)>dist and v.autoFollowTime<self.gameTime then
						x = v.posX - targetObj.posX
						y = v.posY - targetObj.posY
						if x<0 then
							x = targetObj.posX-len
						elseif x==0 then
							x = targetObj.posX
						else
							x = targetObj.posX+len
						end
						if y<0 then
							y = targetObj.posY-len
						elseif y==0 then
							y = targetObj.posY
						else
							y = targetObj.posY+len
						end
						v:moveTo(x,y)
						v.autoFollowTime = self.gameTime + 1
					end
				end
			end
		end
	end

	-- calcutation visible or not
	--self:calVisible()

	-- tower update loop
	--[[
	for k,v in pairs(self.itemListFilter.towerList) do
		if self.forceUpdate then
			v.dirty = true
		end
		v:syncInfo()
	end
	]]

	-- equipOnMap update and fight loop
	--[[
	for k,v in pairs(self.itemListFilter.equipOnMapList) do
		if self.forceUpdateSoldier then
			v.dirty = true
		end
		v:syncInfo()
		v:fight()
	end
	]]

	-- hero fight loop
	for k,v in pairs(self.itemListFilter.heroList) do
		if not v:isDead() then
			v:fight()
		else
			v:revive()
		end
	end

	-- soldier fight loop
	local killID = 0
	for k,v in pairs(self.itemListFilter.soldierList) do
		if not v:isDead() then
			v:fight()
		end
	end

	-- bullet calculation
	self:bulletFight()


	-- equipOnMap fight loop
	--[[
	for k,v in pairs(self.itemListFilter.equipOnMapList) do
		if not v:isDead(1) then
			v:fight()
		end
	end
	]]

	--self:genSoldierItem()
	self:genMonsterItem()
	self:genMonsterCount()

	-- remove item and output item msg
	self:syncItemMsgAndremoveItem()


	-- clear hero flag
	for k,v in pairs(self.itemListFilter.heroList) do
		v.lastHeroAttack = -1
		v.lastHeroAttackForTower = -1
	end

	-- sync ping time to players
	if self.lastSyncPingTime<self:getGameTime() then
		self.lastSyncPingTime = self:getGameTime() + 5
		local pt = {}
		for k,v in pairs(self.itemListFilter.heroList) do
				local ping = v.lastpingtime
				if ping>5 then ping = 5 end
			pt[#pt+1] = {i=v.itemID,t=ping}
		end
		self:addSyncMsg({pt=pt})
	end

	--------  end core world

	-- check any player still in gameroom or not .. if no one here .. exit game
	local allLeft = true
	for i=1,self.gameRoomSetting['maxPlayer'] do
		if self.playerList[i]~=nil and (self.playerList[i]['online']==nil or self.playerList[i]['online']) then
			allLeft = false
		end
	end
	
	--debuglog('allLeft : '..self.cjson.encode(allLeft)..' playerList : '..self.cjson.encode(self.playerList))
	if not allLeft then
		--debuglog('not allLeft')
		self.waitQuit = -1
	elseif self.waitQuit<0 then
		debuglog('waitQuit add 60')
		self.waitQuit = self:getGameTime()+60
	elseif self.waitQuit<self:getGameTime() then
		self:gameOver()
	end
end

--- 取野怪起始坐标及组别设置
-- @param null
-- @return null
function World1:genMonsterSetting()
	local settingLocal = self.setting
	--增加四个塔的怪物
	for i=1,4 do
		self.genMonster[i] = {
			type = 104,	--self.tonumber(settingLocal['tower'..i..'Type']),
			time = self.tonumber(settingLocal['tower_save']),
			posX = self.tonumber(settingLocal['fangyuta'..i..'CoordinateX']),
			posY = self.tonumber(settingLocal['fangyuta'..i..'CoordinateY']),
			itemID = 0,
			last = 0,
			group = 'A'..i,
			team = ''
		}
		self.genMonsterGroup['A'..i] = self.tonumber(settingLocal['tower_save'])		--怪物死后刷新时间
		self.genMonsterGroupLevel['A'..i] = 1 							--按组设置级别
	end
	--增加中央水晶的怪物
	self.genMonster[5] = {
		type = 101,	--self.tonumber(settingLocal['energyType']),
		time = 0,
		posX = self.tonumber(settingLocal['energyCoordinateX']),
		posY = self.tonumber(settingLocal['energyCoordinateY']),
		itemID = 0,
		last = 0,
		group = 'B1',
		team = ''
	}
	self.genMonsterGroup['B1'] = 9999
	self.genMonsterGroupLevel['B1'] = 1
end

--- 游戏loop中执行，如果达成条件生成野怪
-- @param null
-- @return null
function World1:genMonsterItem()
	-- jay real code start
	local genGroup = {}
	local killID = 0
	local killB1ID = self.gameFlag['killB1ID']
	local addPoints = self.gameRoomSetting['enemyEnergy']
	local settingLocal = self.setting
	--debuglog('genMonster :'..self.cjson.encode(self.genMonster))
	for k,v in pairs(self.genMonster) do
		if (self.allItemList[v['itemID']]~=nil) then
			--debuglog('genMonster allItemList : '..v['itemID'])
			killID = self.allItemList[v['itemID']].attribute.killByPlayerID
		end
		--debuglog('itemID:'..v['itemID']..'  '..killID)
		if (v['group']=="B1") then
			if ((v['itemID']>0 and self.allItemList[v['itemID']]~=nil) or killB1ID>0) then
				--print('jaylog B1 killID:'..killID)
				--debuglog('jayLog B1 itemID>0 '..v['itemID'])
				if killID~=nil and killID>0 and killB1ID==0 and self.allItemList[v['itemID']].deadTime>0 then
					if(self.itemListFilter.heroList[killID].statusList[self.energyStatus['s']]==nil) then
						debuglog('jaylog Soldier be kill mark status')
						self.gameFlag['killB1ID'] = killID
						killB1ID = killID
						self.energyStatus['r'] = self:getGameTime()
						debuglog('jayLog ready to addStatusList 37 : '..self.cjson.encode(self.energyStatus))
						self.itemListFilter.heroList[killID]:addStatusList(self.energyStatus,0)
						debuglog('jaylog now statusList:'..self.cjson.encode(self.itemListFilter.heroList[killID].statusList[self.energyStatus['s']]))
					end
				end
				if (killB1ID>0 and self.itemListFilter.heroList[killB1ID]:isDead()) then
					debuglog('jayLog hero dead monster will rebirth addPoints:'..addPoints)
					v['last'] = self:getGameTime()
					v['itemID'] = 0
					v['posX'] = self.itemListFilter.heroList[killB1ID].posX
					v['posY'] = self.itemListFilter.heroList[killB1ID].posY
					self.itemListFilter.heroList[killB1ID]:removeStatusList(self.energyStatus['s'],0)
					self.gameFlag['killB1ID'] = 0
					self.genMonsterGroup[v['group']] = 0
				elseif (killB1ID>0 and self:inTower(killB1ID)) then
					debuglog('jayLog hero in Tower monster will rebirth addPoints:'..addPoints)
					self.itemListFilter.heroList[killB1ID]:setCounter('points',addPoints)
					self.itemListFilter.heroList[killB1ID]:setCounter('getFlag',1)
					self:setCounter('points'..self.itemListFilter.heroList[killB1ID].team,addPoints)
					debuglog('jayLog addPoints count pointsA:'..self.counter['pointsA']..' pointsB:'..self.counter['pointsB']..' lastCountTime:'..self.gameFlag['lastCountTime']..' gameTime:'..self:getGameTime())
					v['last'] = self:getGameTime()
					v['itemID'] = 0
					v['posX'] = self.tonumber(settingLocal['energyCoordinateX'])
					v['posY'] = self.tonumber(settingLocal['energyCoordinateY'])
					self.itemListFilter.heroList[killB1ID]:removeStatusList(self.energyStatus['s'],0)
					self.gameFlag['killB1ID'] = 0
					self.genMonsterGroup[v['group']] = 0
				else
					genGroup[v['group']] = -1
				end
			end
		else
			if (v['itemID']>0) then
				if (self.allItemList[v['itemID']]~=nil and self.allItemList[v['itemID']].deadTime>0 and killID>0) then
					debuglog('jayLog ===== monster dead will rebirth '..self.cjson.encode(v)..' killID:'..killID..' team:'..self.itemListFilter.heroList[killID].team)
					v['last'] = self.allItemList[v['itemID']].deadTime
					v['itemID'] = 0
					--if v['group']~='A1' then
						v['team'] = self.allItemList[killID].team
					--end
				elseif (self.allItemList[v['itemID']]==nil) then
					v['last'] = self:getGameTime()
					v['itemID'] = 0
				else
					genGroup[v['group']] = -1
				end
			end
		end
		if genGroup[v['group']]==nil or (genGroup[v['group']]>0 and v['last']>genGroup[v['group']]) then
			genGroup[v['group']] = v['last']
		end
	end
	if table.nums(genGroup)==0 then
		return nil
	end

	for k,v in pairs(genGroup) do
		if (v==0) then
			for k1,v1 in pairs(self.genMonster) do
				if (v1['group']==k) then
					--debuglog('jaylog first addMonster: type:'..v1['type']..' x:'..v1['posX']..' y:'..v1['posY']..' group:'..v1['group']..' lv:'..self.genMonsterGroupLevel[v1['group']]..' team:'..v1['team'])
					--debuglog('jaylog genMonster genGroup: '..self.cjson.encode(genGroup)..' genMonsterGroup: '..self.cjson.encode(self.genMonsterGroup)..' genMonster:'..self.cjson.encode(self.genMonster)..' gameTime:'..self:getGameTime())
					v1['itemID'] = self:addMonster(v1['type'],v1['posX'],v1['posY'],v1['group'],self.genMonsterGroupLevel[v1['group']],v1['team'])
					v1['last'] = self:getGameTime()
					if(k=='B1') then
						self.genMonsterGroup[k] = 9999
					end
				end
			end
		end
		if (v>0 and v+self.genMonsterGroup[k]<self:getGameTime()) then
			for k1,v1 in pairs(self.genMonster) do
				if v1['group']==k then
					--debuglog('jaylog now is addMonster: type:'..v1['type']..' x:'..v1['posX']..' y:'..v1['posY']..' group:'..v1['group']..' lv:'..self.genMonsterGroupLevel[v1['group']]..' team:'..v1['team'])
					--debuglog('jaylog genMonster genGroup: '..self.cjson.encode(genGroup)..' genMonsterGroup: '..self.cjson.encode(self.genMonsterGroup)..' genMonster:'..self.cjson.encode(self.genMonster)..' gameTime:'..self:getGameTime())
					v1['itemID'] = self:addMonster(v1['type'],v1['posX'],v1['posY'],v1['group'],self.genMonsterGroupLevel[v1['group']],v1['team'])
					if(k=='B1') then
						self.genMonsterGroup[k] = 9999
					end
				end
			end
		end
	end
	-- jay real code end
end

--- 判断玩家是否在自己塔附近
-- @param id int - 玩家id
-- @return result boolean - 是 or 否
function World1:inTower(id)
	local settingLocal = self.setting
	local towerSelf = {}
	local x = self.itemListFilter.heroList[id].posX
	local y = self.itemListFilter.heroList[id].posY
	local team = self.itemListFilter.heroList[id].team
	local ret = false
	for i=1,4 do
		local result = self.mPow((x-settingLocal['fangyuta'..i..'CoordinateX']),2)+self.mPow((y-settingLocal['fangyuta'..i..'CoordinateY']),2)
		if result<self.mPow(2,2) and team==self.genMonster[i]['team'] then
			debuglog('jayLog true getEnergy inTower : x:'..x..' y:'..y..' tX:'..settingLocal['fangyuta'..i..'CoordinateX']..' tY:'..settingLocal['fangyuta'..i..'CoordinateY']..' id:'..id..' team:'..team)
			return true
		else
			--debuglog('jayLog false getEnergy inTower : x:'..x..' y:'..y..' tX:'..settingLocal['fangyuta'..i..'CoordinateX']..' tY:'..settingLocal['fangyuta'..i..'CoordinateY']..' id:'..id..' team:'..team)
			--ret=false
		end
	end
	return ret
end

--- 获得怪物塔数,并统计增加点数
-- @param null
-- @return null
function World1:genMonsterCount()
	local pointsAorg = self.counter['pointsA']
	local pointsBorg = self.counter['pointsB']
	local towerTmpA = self.counter['towerA']	-- 现时塔数
	local towerTmpB = self.counter['towerB']	
	local towerTmpC = self.counter['towerC']
	local towerTmp1 = 0
	local towerTmp2 = 0
	local towerTmp3 = 0		-- 统计塔数
	local gameInfo = {}
	local gfin = {}
	local efin = {}
	local sfin = {}
	for k,v in pairs(self.genMonster) do
		if v.group~='B1' then
			if v.team=="A" then
				towerTmp1 = towerTmp1 + 1
			elseif v.team=="B" then
				towerTmp2 = towerTmp2 + 1
			else
				towerTmp3 = towerTmp3 + 1
			end
		end
	end

	if (self:getGameTime()-self.gameFlag['lastCountTime'])>1 then
		if towerTmp1>0 then
			self:setCounter('pointsA',self.setting['tower'..towerTmp1..'_energy'])
		end
		if towerTmp2>0 then
			self:setCounter('pointsB',self.setting['tower'..towerTmp2..'_energy'])
		end
		self.gameFlag['lastCountTime'] = self:getGameTime()
		for k,v in pairs(self.itemListFilter.heroList) do
			if v.team=="A" and towerTmp1>0 then
				v:setCounter('points',self.setting['tower'..towerTmp1..'_energy'])
			end
			if v.team=="B" and towerTmp2>0 then
				v:setCounter('points',self.setting['tower'..towerTmp2..'_energy'])
			end
		end
	end

	if towerTmpA~=towerTmp1 or towerTmpB~=towerTmp2 or towerTmpC~=towerTmp3 then
		self.counter['towerA'] = towerTmp1
		self.counter['towerB'] = towerTmp2
		self.counter['towerC'] = towerTmp3
		gameInfo = {
			pointsA = self.counter['pointsA'],
			pointsB = self.counter['pointsB'],
			towerA = towerTmp1,
			towerB = towerTmp2,
			towerC = towerTmp3,
			start = self.forceUpdate and 1 or 0,
			d = 0,
			reset = self.status==self.GAMEOVER and 1 or 0,
			msize = self.mapSize
		}
		debuglog('jaylog start syn Tower count : '..self.cjson.encode(gameInfo))
		self:addSyncMsg({game=gameInfo})
	elseif (self.counter['pointsA']>0 or self.counter['pointsB']>0) and (pointsAorg~=self.counter['pointsA'] or pointsBorg~=self.counter['pointsB']) then
		gameInfo = {
			pointsA = self.counter['pointsA'],
			pointsB = self.counter['pointsB'],
			towerA = towerTmp1,
			towerB = towerTmp2,
			towerC = towerTmp3,
		}
		--debuglog('jayLog start syn points count : '..self.cjson.encode(gameInfo))
		self:addSyncMsg({game=gameInfo})
	end
end

--- 取得遊戲統計
-- @param name string - 名稱
-- @return counter int - 數值
function World1:getCounter(name)
	if self.counter[name]==nil then
		return 0
	end
	return self.counter[name]
end

--- 累加遊戲統計
-- @param name string - 名稱
-- @param addValue int - 加值 預設+1
-- @return counter int - 數值
function World1:setCounter(name,addValue)
	if addValue==nil then addValue = 1 end
	if self.counter[name]==nil then self.counter[name] = 0 end
	self.counter[name] = self.counter[name] + addValue
end

--- init时部分游戏房设置赋setting值
-- @param null
-- @return null
function World1:gengameRoomSetting()
	-- 用setting值把gameRoomSetting部分值重置
	--debuglog('gameRoomSetting1 : '..self.cjson.encode(self.gameRoomSetting)..' setting : '..self.cjson.encode(self.Setting))
	if self.setting['win_energy']==nil then
		self.gameRoomSetting['gameLimitedPoints'] = 500
	else
		self.gameRoomSetting['gameLimitedPoints'] = self.setting['win_energy']
	end
	if self.setting['enemy_energy']==nil then
		self.gameRoomSetting['enemyEnergy'] = 200
	else
		self.gameRoomSetting['enemyEnergy'] = self.setting['enemy_energy']
	end
	if self.setting['mode_Time']==nil then
		self.gameRoomSetting['gameLimitedTime'] = 1800
	else
		self.gameRoomSetting['gameLimitedTime'] = self.setting['mode_Time']
	end
	--debuglog('gameRoomSetting2 : '..self.cjson.encode(self.gameRoomSetting))
end

-- 重写genTransitDoor令其不生成
function World1:genTransitDoor()
end

return World1
