local World2002 = class("World2002",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World2002:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World2002"
	end

	World2002.super.ctor(self,gamePort,gameID,callBack)
	worldForHero = 2002
end

return World2002

