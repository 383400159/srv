local World3015 = class("World3015",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World3015:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World3015"
	end

	World3015.super.ctor(self,gamePort,gameID,callBack)
	worldForHero = 3015
end

return World3015