local World3 = class("World3",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World3:ctor(gamePort,gameID,callBack)
	worldForHero = 3
	
	if self.className==nil then
		self.className="World3"
		self.worldNum = string.sub(self.className,6)
	end

	World3.super.ctor(self,gamePort,gameID,callBack)

	--self.gameRoomSetting['sameTeam'] = true
	--self.gameRoomSetting['maxPlayer'] = 9
	self.gameRoomSetting['setLinePosition'] = {}
	self.gameRoomSetting['setLineOrder'] = {}
	self.gameRoomSetting['setLineSwitch'] = {}
	self.gameRoomSetting['setLineLenTime'] = 0
	self.gameRoomSetting['setLineMoveDis'] = {}

	--self.bossAll = {}
	--self.bossSkillAll = {}
	self.lotteryList = {}   --每个玩家对应的抽奖物品ID获得的随机数
	self.lotteryControl = {}  --玩家上传信息
	
	self.partType = 1         --第几阶段 1、2、3、4
	self.partSubType = 1			--第几阶段的中间串插阶段
	self.partFinish = true		--阶段完成
	self.partWaitTime = 0     --第几阶段等待时间
	self.partStartTime = 0    --阶段开始时间
	self.partDelayTime1 = 0   --测试用开场白放送延迟时间
	self.partFinishTime = 0 	--下一阶段完成时间

	self.bossObj1 = nil
	self.bossObj2 = nil
	self.bossObj3 = nil
	self.camObj = nil
	self.transitDoor = nil
	self.monsterGroup = {}

	self.preSkill = 0
	self.preSkillWaitTime = 0		--技能等待时间
	self.skillDelayTime = {}    --转场景施放技能间隔时间

	self.deadNum = 0
	self.startGameTime = 0			--激活BOSS开始时间
	self.lineOrder = {}					--列队顺序itemID=orderNo

	self.gameFlag['inCamEnd'] = false		--列队镜头完成
	self.gameFlag['isWin'] = 0	--胜利或失败状态
	self.gameFlag['passTransitDoorNum'] = 0	--通过传送门人数
	self.gameFlag['passTransitDoorLastNum'] = 0	--通过传送门剩余人数
	self.gameFlag['passTransitDoorID'] = {}
	self.gameFlag['allStopMove'] = false

	worldForHero = 3
end

--- load enemy data when ready
-- @param null
-- @return null
--function World3:__loadFlow()
	--debuglog('jaylog start loadBoss')
	--local keyMap = {type='eType',fire_resistance='FIRER',ice_resistance='ICER',lightning_resistance='LIGHTR',poison_resistance='POISONR',attRange='ATTRNGR',visRange='VISRNGR'}
	-- local sql = "select * from flow_condition where world='"..self.sSub(self.className,6).."' order by part,step"
	-- local data = self:getDBData(sql)
	-- --self:debuglog('jaylog World3:__loadFlow data:',self.cjson.encode(data))
	-- local flowTmp = {}
	-- local paramTmp,paramTmp2,paramTmp3,paramTmp4,param
	-- --debuglog('end dataAll : '..self.cjson.encode(data))
	-- for k,v in pairs(data) do
	-- 	flowTmp = {}
	-- 	for k1,v1 in pairs(v) do
	-- 		param = {}
	-- 		if k1=='extraCondition' then
	-- 			if v1~='' then
	-- 				paramTmp = self.sSplit(v1,';')
	-- 				for k2,v2 in pairs(paramTmp) do
	-- 					paramTmp2 = self.sSplit(v2,'=')
	-- 					if self.sFind(paramTmp2[2],'_')~=nil then
	-- 						paramTmp3 = self.sSplit(paramTmp2[2],'_')
	-- 						for k3,v3 in pairs(paramTmp3) do
	-- 							if param[paramTmp2[1]]==nil then
	-- 								param[paramTmp2[1]] = {}
	-- 							end
	-- 							param[paramTmp2[1]][#param[paramTmp2[1]]+1] = self.sSplitNumber(v3,',')
	-- 						end
	-- 					else
	-- 						if self.sFind(paramTmp2[1],'SUBNAME')~=nil or self.sFind(paramTmp2[1],'BUFFNAME')~=nil or self.sFind(paramTmp2[1],'TEAM')~=nil then
	-- 							param[paramTmp2[1]] = self.sSplit(paramTmp2[2],',')
	-- 						else
	-- 							param[paramTmp2[1]] = self.sSplitNumber(paramTmp2[2],',')
	-- 						end
	-- 					end
	-- 				end
	-- 				flowTmp['extraCondition'] = self.tDeepcopy(param)
	-- 			else
	-- 				flowTmp['extraCondition'] = {}
	-- 			end
	-- 		elseif (k1=='extraParam') then
	-- 			if self.sFind(v1,'SUMMON')~=nil then
	-- 				paramTmp = self.sSplit(v1,';')
	-- 				for k2,v2 in pairs(paramTmp) do
	-- 					paramTmp2 = self.sSplit(v2,'=')
	-- 					if self.sFind(paramTmp2[2],':')~=nil then
	-- 						paramTmp3 = self.sSplit(paramTmp2[2],',')
	-- 						for k3,v3 in pairs(paramTmp3) do
	-- 							paramTmp4 = self.sSplit(v3,':')
	-- 							if param[paramTmp2[1]]==nil then
	-- 								param[paramTmp2[1]] = {}
	-- 							end
	-- 							if param[paramTmp2[1]][paramTmp3[1]]==nil then
	-- 								param[paramTmp2[1]][paramTmp3[1]] = {}
	-- 							end
	-- 							param[paramTmp2[1]][paramTmp3[1]][paramTmp4[1]] = self.tonumber(paramTmp4[2])
	-- 						end
	-- 					elseif self.sFind(paramTmp2[2],'SUBNAME')~=nil then
	-- 						param[paramTmp2[1]] = self.tonumber(paramTmp2[2])
	-- 					else
	-- 						param[paramTmp2[1]] = self.sSplitNumber(paramTmp2[2],',')
	-- 					end
	-- 				end
	-- 				flowTmp['extraParam'] = self.tDeepcopy(param)
	-- 			elseif v1~='' then
	-- 				paramTmp = self.sSplit(v1,';')
	-- 				for k2,v2 in pairs(paramTmp) do
	-- 					paramTmp2 = self.sSplit(v2,'=')
	-- 					if self.sFind(paramTmp2[2],'_')~=nil then
	-- 						paramTmp3 = self.sSplit(paramTmp2[2],'_')
	-- 						for k3,v3 in pairs(paramTmp3) do
	-- 							if param[paramTmp2[1]]==nil then
	-- 								param[paramTmp2[1]] = {}
	-- 							end
	-- 							param[paramTmp2[1]][#param[paramTmp2[1]]+1] = self.sSplitNumber(v3,',')
	-- 						end
	-- 					else
	-- 						if self.sFind(paramTmp2[1],'SUBNAME')~=nil or self.sFind(paramTmp2[1],'BUFFNAME')~=nil or self.sFind(paramTmp2[1],'TEAM')~=nil then
	-- 							param[paramTmp2[1]] = self.sSplit(paramTmp2[2],',')
	-- 						else
	-- 							param[paramTmp2[1]] = self.sSplitNumber(paramTmp2[2],',')
	-- 						end
	-- 					end
	-- 				end
	-- 				flowTmp['extraParam'] = self.tDeepcopy(param)
	-- 			else
	-- 				flowTmp['extraParam'] = {}
	-- 			end
	-- 		elseif k1=='parameter' then
	-- 			if v1~='' then
	-- 				flowTmp['parameter'] = self.sSplit(v1,',')
	-- 			else
	-- 				flowTmp['parameter'] = {}
	-- 			end
	-- 		elseif k1=='condition' then
	-- 			if v1~='' then
	-- 				flowTmp['condition'] = self.sSplit(v1,',')
	-- 			else
	-- 				flowTmp['condition'] = {}
	-- 			end
	-- 		else
	-- 			flowTmp[k1] = v1
	-- 		end
	-- 	end
	-- 	if self.bossFlow[v['part']]==nil then
	-- 		self.bossFlow[v['part']] = {}
	-- 	end
	-- 	self.bossFlow[v['part']][v['step']] = self.tDeepcopy(flowTmp)
	-- end
	--debuglog('jaylog end bossFlowAll : '..self.cjson.encode(self.bossFlow))
--end

function World3:gengameRoomSetting()
	--debuglog('jaylog ======= gameRoomSetting:'..self.cjson.encode(self.setting['p2Delay']))
	self.skillDelayTime[1] = string.splitNumber(self.setting['p2Delay'],',')
	self.skillDelayTime[2] = string.splitNumber(self.setting['p3Delay'],',')
	--self.gameRoomSetting['sameTeam'] = true
	--self.gameRoomSetting['maxPlayer'] = 9
	-- local tmpPos = string.split(self.setting['setLinePosition'],';')
	-- for k,v in pairs(tmpPos) do
	-- 	local tmpSubPos = string.splitNumber(v,',')
	-- 	self.gameRoomSetting['setLinePosition'][tmpSubPos[1]] = {x=tmpSubPos[2],y=tmpSubPos[3]}
	-- end
	-- local tmpOrd = string.split(self.setting['setLineOrder'],';')
	-- for k,v in pairs(tmpOrd) do
	-- 	self.gameRoomSetting['setLineOrder'][k] = string.splitNumber(v,',')
	-- end
	-- local tmpSwh = string.split(self.setting['setLineSwitch'],';')
	-- local tmpSubSwh = {}
	-- for k,v in pairs(tmpSwh) do
	-- 	tmpSubSwh[k] = string.splitNumber(v,',')
	-- end
	-- if tmpSubSwh[1][1]<tmpSubSwh[2][1] then
	-- 	self.gameRoomSetting['setLineSwitch'][1] = tmpSubSwh[1][1]
	-- 	self.gameRoomSetting['setLineSwitch'][2] = tmpSubSwh[2][1]
	-- else
	-- 	self.gameRoomSetting['setLineSwitch'][1] = tmpSubSwh[2][1]
	-- 	self.gameRoomSetting['setLineSwitch'][2] = tmpSubSwh[1][1]
	-- end
	-- if tmpSubSwh[1][2]<tmpSubSwh[2][2] then
	-- 	self.gameRoomSetting['setLineSwitch'][3] = tmpSubSwh[1][2]
	-- 	self.gameRoomSetting['setLineSwitch'][4] = tmpSubSwh[2][2]
	-- else
	-- 	self.gameRoomSetting['setLineSwitch'][3] = tmpSubSwh[2][2]
	-- 	self.gameRoomSetting['setLineSwitch'][4] = tmpSubSwh[1][2]
	-- end
	-- self.gameRoomSetting['setLineLenTime'] = self.tonumber(self.setting['setLineLenTime'])
	-- self.gameRoomSetting['setLineMoveDis'] = string.splitNumber(self.setting['setLineMoveDis'],',')
end

function World3:genMonsterItem()
end

--注释此function不执行
function World3:genMonsterCount()
end

--- 加Boss在地圖
-- @param id int - boss角色id
-- @param team char - "A" or "B"
-- @param loginID string - 玩家名稱
-- @param posX integer - 出生x坐标
-- @param posY integer - 出生y坐标
-- @return heroObj SHero - 英雄object
function World3:addBoss(id,team,loginID,posX,posY,skin,actorID)
	if (posX==nil or posY==nil) then
		local pos = string.splitNumber(self.setting['bossID'],',')
		posX = pos[1]
		posY = pos[2]
	end
	self:debuglog('jaylog World3 addBoss id:'..id..' t:'..team..' lid:'..loginID..' posX:'..posX..' posY:'..posY..' sk:'..skin)
	local boss = World3.super.addBoss(self,id,team,loginID,posX,posY,skin,actorID)
	return boss
end

function World3:init()
	World3.super.init(self)
	--self:createGVBEnemy()
	-- local pos = string.splitNumber(self.setting['bossID'],',')
	-- self.bossObj1 = self:addBoss(1001,'B','BOSS',pos[1],pos[2],2)
	-- self.bossObj1:addStatusList({s=10001,r=self.gameTime,t=99999,i=self.bossObj1.itemID},0.5)
	-- self.bossObj1.changePartHP = self.bossObj1.attribute.MaxHP * 0.5
end

function World3:inTower(id)
	return false
end

-- function World3:gameOverCheck()
-- 	local result = false
-- 	result = World3.super.gameOverCheck(self)

-- 	if self.deadNum==table.nums(self.playerList) then
-- 		result = true
-- 	end

-- 	return result
-- end

--function World3:checkCondition(conditon,extraCondition)
	-- --self:debuglog('jaylog World3:checkCondition conditon:'..self.cjson.encode(conditon)..' extra:'..self.cjson.encode(extraCondition)..' part:'..self.partType..' subPart:'..self.partSubType)
	-- for k,v in pairs(conditon) do
	-- 	if self.sFind(v,'NOCONDITION')~=nil then
	-- 		return true
	-- 	end
	-- 	if self.sFind(v,'TRIGGER')~=nil or self.sFind(v,'ROLEHP')~=nil then
	-- 		--self:debuglog('jaylog World3:checkCondition k:'..k..' v:'..self.cjson.encode(v))
	-- 		for k1,v1 in pairs(self.itemListFilter.heroList) do
	-- 			if self.sFind(v,'TRIGGER')~=nil then
	-- 				local sx = extraCondition['POSITIONS'][1][1]
	-- 				local sy = extraCondition['POSITIONS'][1][2]
	-- 				local ex = extraCondition['POSITIONS'][2][1]
	-- 				local ey = extraCondition['POSITIONS'][2][2]
	-- 				if extraCondition['POSITIONS'][1][1]>extraCondition['POSITIONS'][2][1] then
	-- 					sx = extraCondition['POSITIONS'][2][1]
	-- 					ex = extraCondition['POSITIONS'][1][1]
	-- 				end
	-- 				if extraCondition['POSITIONS'][1][2]>extraCondition['POSITIONS'][2][2] then
	-- 					sy = extraCondition['POSITIONS'][2][2]
	-- 					ey = extraCondition['POSITIONS'][1][2]
	-- 				end
	-- 				if self.sFind(v,'ALL')~=nil then
	-- 					if sx>v1.posX or v1.posX>ex and sy>v1.posY or v1.posY>ey then
	-- 						--debuglog('jaylog World3:checkCondition All position: sx:'..sx..' '..v1.posX..' ex:'..ex..' sy:'..sy..' '..v1.posY..' ey:'..ey)
	-- 						return false
	-- 					end
	-- 				else
	-- 					if sx<=v1.posX and v1.posX<=ex and sy<=v1.posY and v1.posY<=ey then
	-- 						--debuglog('jaylog World3:checkCondition notAll position: sx:'..sx..' '..v1.posX..' ex:'..ex..' sy:'..sy..' '..v1.posY..' ey:'..ey)
	-- 						return true
	-- 					end
	-- 				end
	-- 			end
	-- 			if self.sFind(v,'ROLEHP')~=nil then
	-- 				if extraCondition['SUBNAME'][1]==v1.subName then
	-- 					if self.sFind(v,'LESS') then
	-- 						if v1.attribute.HP<=(v1.attribute.MaxHP*extraCondition['NUM'][1]*0.01) then
	-- 							return true
	-- 						end
	-- 					end
	-- 					if self.sFind(v,'MORE') then
	-- 						if v1.attribute.HP>=(v1.attribute.MaxHP*extraCondition['NUM'][1]*0.01) then
	-- 							return true
	-- 						end
	-- 					end
	-- 				end
	-- 			end
	-- 		end
	-- 		if self.sFind(v,'TRIGGER')~=nil and self.sFind(v,'ALL')~=nil then
	-- 			return true
	-- 		end
	-- 	end
	-- 	if self.sFind(v,'ROLESHP')~=nil then
	-- 		local hp1 = 9999999
	-- 		local hp2 = 9999999
	-- 		for k1,v1 in pairs(self.itemListFilter.heroList) do
	-- 			if v1.subName==extraCondition['SUBNAME'][1] then
	-- 				hp1 = v1.attribute.HP
	-- 			end
	-- 			if v1.subName==extraCondition['SUBNAME'][2] then
	-- 				hp2 = v1.attribute.HP
	-- 			end
	-- 		end
	-- 		if hp1<=extraCondition['NUM'][1] and hp2<=extraCondition['NUM'][1] then
	-- 			return true
	-- 		else
	-- 			return false
	-- 		end
	-- 	end
	-- 	if self.sFind(v,'KILL')~=nil then
	-- 		--self:debuglog('jaylog World3:checkCondition k:'..k..' v:'..self.cjson.encode(v))
	-- 		-- for k1,v1 in pairs(self.monsterGroup) do
	-- 		-- 	if self.itemListFilter.soldierList[v1]~=nil and not self.itemListFilter.soldierList[v1]:isDead() then
	-- 		-- 		return false
	-- 		-- 	end
	-- 		-- end
	-- 		--debuglog('jaylog KILL start time:'..self.gameTime)
	-- 		for k,v in pairs(self.itemListFilter.soldierList) do
	-- 			if v.subName==extraCondition['SUBNAME'][1] and not v:isDead() then
	-- 				return false
	-- 			end
	-- 		end
	-- 		--debuglog('jaylog KILL end time:'..self.gameTime)
	-- 		return true
	-- 	end
	-- 	if self.sFind(v,'RUNEXTRACHECK')~=nil then
	-- 		--self:debuglog('jaylog World3:checkCondition runExtraCheck')
	-- 		return self:runExtraCheck()
	-- 	end
	-- end
--end

--function World3:runExtraCheck()
	--return true
--end

--function World3:excuteParam(parameter,extraParam)
	-- self:debuglog('jaylog World3:excuteParam param:'..self.cjson.encode(parameter)..' extra:'..self.cjson.encode(extraParam))
	-- for k,v in pairs(parameter) do
	-- 	if self.sFind(v,'NEW')~=nil then
	-- 		--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v))
	-- 		if extraParam['ID']~=nil then
	-- 			if extraParam['ID'][1]>99 and extraParam['ID'][1]<1000 then
	-- 				local monsterID = self:addMonster(self.tostring(extraParam['ID'][1]),extraParam['POSITION'][1],extraParam['POSITION'][2],nil,1,'B')
	-- 				local monsterObj = self.allItemList[monsterID]
	-- 				if self.sFind(v,'BLOCK')~=nil then
	-- 					monsterObj:setBlockLenWidth(extraParam['BLOCKLEN'][1],extraParam['BLOCKWIDTH'][1])
	-- 				end
	-- 				--self.monsterGroup[#self.monsterGroup] = monster.itemID
	-- 				monsterObj:setSubName(extraParam['SUBNAME'][1])
	-- 				parameter[k] = nil
	-- 			end
	-- 			if extraParam['ID'][1]>1000 and extraParam['ID'][1]<2000 then
	-- 				local boss = self:addBoss(extraParam['ID'][1],'',extraParam['SUBNAME'][1],extraParam['POSITION'][1],extraParam['POSITION'][2],extraParam['SKINNO'][1])
	-- 				boss:setSubName(extraParam['SUBNAME'][1])
	-- 				parameter[k] = nil
	-- 			end
	-- 		end
	-- 		if self.sFind(v,'GROUP')~=nil then
	-- 			self:callCreature(extraParam)
	-- 			parameter[k] = nil
	-- 		end
	-- 		if self.sFind(v,'BLOCK')~=nil then
	-- 			self.map:addTmpBlockByLine(extraParam['POSITIONS'][1][1],extraParam['POSITIONS'][1][2],extraParam['POSITIONS'][2][1],extraParam['POSITIONS'][2][2],extraParam['TIMELEN'][1],extraParam['BLOCKID'][1])
	-- 			parameter[k] = nil
	-- 		end
	-- 	end
	-- 	if self.sFind(v,'GAMEOVER')~=nil then
	-- 		--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v))
	-- 		self.gameFlag['isGameOver'] = true
	-- 		parameter[k] = nil
	-- 	end
	-- 	if self.sFind(v,'SHOWDIALOG')~=nil then
	-- 		self:addSyncMsg({game={stage=self.worldNum,bossID=extraParam['ID'][1],step=extraParam['STEP'][1],mType=1}})
	-- 		parameter[k] = nil
	-- 	end
	-- 	if self.sFind(v,'SHOWCARTOON')~=nil then
	-- 		parameter[k] = nil
	-- 	end
	-- 	if self.sFind(v,'SETUIID')~=nil then
	-- 		local bossList = {}
	-- 		for k,v in pairs(self.itemListFilter.heroList) do
	-- 			if self.sFind(v.subName,'BOSS')~=nil then
	-- 				bossList[self.tonumber(self.sSub(v.subName,5))] = v.itemID
	-- 			end
	-- 		end
	-- 		local maxnum = self.tMaxn(bossList)
	-- 		for i=1,maxnum do
	-- 			if bossList[i]==nil then
	-- 				bossList[i] = 0
	-- 			end
	-- 		end
	-- 		self:addSyncMsg({game={part=extraParam['ID'][1],partBoss=bossList}})
	-- 		parameter[k] = nil
	-- 	end
	-- 	if v=='STOPAI' then
	-- 		for k1,v1 in pairs(self.itemListFilter.heroList) do
	-- 			if self.sFind(v1.subName,'BOSS')~=nil then
	-- 				v1.autoFightAI.runAI = false
	-- 				v1.autoFightAI.runMoveAI = false
	-- 			end
	-- 		end
	-- 		for k1,v1 in pairs(self.itemListFilter.soldierList) do
	-- 			v1.autoFightAI.runAI = false
	-- 			v1.autoFightAI.runMoveAI = false
	-- 		end
	-- 		parameter[k] = nil
	-- 	end
	-- 	if v=='STARTAI' then
	-- 		for k1,v1 in pairs(self.itemListFilter.heroList) do
	-- 			if self.sFind(v1.subName,'BOSS')~=nil then
	-- 				v1.autoFightAI.runAI = true
	-- 				v1.autoFightAI.runMoveAI = true
	-- 			end
	-- 		end
	-- 		for k1,v1 in pairs(self.itemListFilter.soldierList) do
	-- 			v1.autoFightAI.runAI = true
	-- 			v1.autoFightAI.runMoveAI = true
	-- 		end
	-- 		parameter[k] = nil
	-- 	end
	-- 	if v=='OUTOFCTRL' then
	-- 		for k1,v1 in pairs(self.itemListFilter.heroList) do
	-- 			if v1.actorType==0 then
	-- 				v1:setOutOfCtlAllTime(self.gameTime + extraParam['TIMELEN'][1])
	-- 			end
	-- 		end
	-- 		parameter[k] = nil
	-- 	end
	-- 	for k1,v1 in pairs(self.itemListFilter.heroList) do
	-- 		if self.sFind(v,'SETCHANGEPARTHP')~=nil then
	-- 			if v1.subName==extraParam['SUBNAME'][1] then
	-- 				--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v)..' v1id:'..v1.itemID..' ext:'..self.cjson.encode(extraParam))
	-- 				v1.changePartHP = v1.attribute.MaxHP*extraParam['NUM'][1]*0.01
	-- 				parameter[k] = nil
	-- 			end
	-- 		end
	-- 		if self.sFind(v,'SETBOSSPART')~=nil then
	-- 			if v1.subName==extraParam['SUBNAME'][1] then
	-- 				--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v)..' v1id:'..v1.itemID..' ext:'..self.cjson.encode(extraParam))
	-- 				v1.attribute.partType = extraParam['NUM'][1]
	-- 				v1.attribute.partTypeStartTime = self.gameTime
	-- 				parameter[k] = nil
	-- 			end
	-- 		end
	-- 		if v=='MOVE' then
	-- 			--self:debuglog('jaylog World3:excuteParam endTime:'..v1.moveToEndTime..' gt:'..self.gameTime)
	-- 			if v1.subName==extraParam['SUBNAME'][1] and v1.moveToEndTime<self.gameTime and v1.lastSkill==0 and v1.lastCoolDownTime<self.gameTime then
	-- 				--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v)..' ext:'..self.cjson.encode(extraParam))
	-- 				v1:moveTo(extraParam['POSITION'][1],extraParam['POSITION'][2])
	-- 				parameter[k] = nil
	-- 			end
	-- 		end
	-- 		if self.sFind(v,'CASTSKILL')~=nil then
	-- 			if v1.subName==extraParam['SUBNAME'][1] and v1.moveToEndTime<self.gameTime and v1.lastCoolDownTime<self.gameTime and (v1.lastSkill==nil or v1.lastSkill==0) then
	-- 				--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v)..' ext:'..self.cjson.encode(extraParam))
	-- 				v1.lastSkill = v1:skillAttack(extraParam['ID'][1],k1)
	-- 				if v1.lastSkill~=nil then
	-- 					v1.lastSkill = 0
	-- 					parameter[k] = nil
	-- 				end
	-- 			end
	-- 		end
	-- 		if self.sFind(v,'ADDSTATUS')~=nil then
	-- 			if v1.subName==extraParam['SUBNAME'][1] then
	-- 				--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v)..' heroList'..' ext:'..self.cjson.encode(extraParam))
	-- 				local data = {s=extraParam['ID'][1],t=extraParam['TIMELEN'][1]}
	-- 				if extraParam['PARAM1']~=nil then
	-- 					data['p1'] = extraParam['PARAM1'][1]
	-- 				end
	-- 				if extraParam['PARAM2']~=nil then
	-- 					data['p2'] = extraParam['PARAM2'][1]
	-- 				end
	-- 				if extraParam['PARAM3']~=nil then
	-- 					data['p3'] = extraParam['PARAM3'][1]
	-- 				end
	-- 				v1:addStatusList(data)
	-- 				parameter[k] = nil
	-- 			end
	-- 		end
	-- 		if self.sFind(v,'CLEANSTATUS')~=nil then
	-- 			if v1.subName==extraParam['SUBNAME'][1] then
	-- 				--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v)..' heroList'..' ext:'..self.cjson.encode(extraParam))
	-- 				v1:removeStatusList(extraParam['ID'][1])
	-- 				parameter[k] = nil
	-- 			end
	-- 		end
	-- 		if self.sFind(v,'CLEANBUFF')~=nil then
	-- 			if extraParam['TEAM']~=nil then
	-- 				if v1.teamOrig==extraParam['TEAM'][1] then
	-- 					--self:debuglog('jaylog World3:excuteParam TEAM k:'..k..' v:'..self.cjson.encode(v)..' heroList'..' ext:'..self.cjson.encode(extraParam))
	-- 					v1:removeBUff(extraParam['BUFFNAME'][1])
	-- 					parameter[k] = nil
	-- 				end
	-- 			end
	-- 			if extraParam['SUBNAME']~=nil then
	-- 				if v1.subName==extraParam['SUBNAME'][1] then
	-- 					--self:debuglog('jaylog World3:excuteParam SUBNAME k:'..k..' v:'..self.cjson.encode(v)..' heroList'..' ext:'..self.cjson.encode(extraParam))
	-- 					v1:removeBUff(extraParam['BUFFNAME'][1])
	-- 					parameter[k] = nil
	-- 				end
	-- 			end
	-- 		end
	-- 	end
	-- 	for k1,v1 in pairs(self.itemListFilter.soldierList) do
	-- 		if self.sFind(v,'ADDSTATUS')~=nil then
	-- 			if v1.subName==extraParam['SUBNAME'][1] then
	-- 				--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v)..' soldierList'..' ext:'..self.cjson.encode(extraParam))
	-- 				local data = {s=extraParam['ID'][1],t=extraParam['TIMELEN'][1]}
	-- 				if extraParam['PARAM1']~=nil then
	-- 					data['p1'] = extraParam['PARAM1'][1]
	-- 				end
	-- 				if extraParam['PARAM2']~=nil then
	-- 					data['p2'] = extraParam['PARAM2'][1]
	-- 				end
	-- 				if extraParam['PARAM3']~=nil then
	-- 					data['p3'] = extraParam['PARAM3'][1]
	-- 				end
	-- 				v1:addStatusList(data)
	-- 				parameter[k] = nil
	-- 			end
	-- 		end
	-- 		if self.sFind(v,'CLEANSTATUS')~=nil then
	-- 			if v1.subName==extraParam['SUBNAME'][1] then
	-- 				--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v)..' soldierList'..' ext:'..self.cjson.encode(extraParam))
	-- 				v1:removeStatusList(extraParam['ID'][1])
	-- 				parameter[k] = nil
	-- 			end
	-- 		end
	-- 		if self.sFind(v,'CLEANBUFF')~=nil then
	-- 			if extraParam['TEAM']~=nil then
	-- 				if v1.teamOrig==extraParam['TEAM'][1] then
	-- 					--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v)..' soldierList'..' ext:'..self.cjson.encode(extraParam))
	-- 					v1:removeBUff(extraParam['BUFFNAME'][1])
	-- 					parameter[k] = nil
	-- 				end
	-- 			end
	-- 			if extraParam['SUBNAME']~=nil then
	-- 				if v1.subName==extraParam['SUBNAME'][1] then
	-- 					--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v)..' soldierList'..' ext:'..self.cjson.encode(extraParam))
	-- 					v1:removeBUff(extraParam['BUFFNAME'][1])
	-- 					parameter[k] = nil
	-- 				end
	-- 			end
	-- 		end
	-- 		if self.sFind(v,'CLOSE')~=nil then
	-- 			if self.sFind(v,'BLOCK')~=nil then
	-- 				self.map:removeTmpBlockByLine(extraParam['BLOCKID'][1])
	-- 				parameter[k] = nil
	-- 			else
	-- 				if v1.subName==extraParam['SUBNAME'][1] then
	-- 					--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v)..' soldierList'..' ext:'..self.cjson.encode(extraParam))
	-- 					v1.attribute.HP = 0
	-- 					v1:directHurt(v1.itemID,1,{},0)
	-- 					parameter[k] = nil
	-- 				end
	-- 			end
	-- 		end
	-- 	end
	-- 	for k1,v1 in pairs(self.itemListFilter.noBeFightList) do
	-- 		if self.sFind(v,'ADDSTATUS')~=nil then
	-- 			if v1.subName==extraParam['SUBNAME'][1] then
	-- 				--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v)..' soldierList'..' ext:'..self.cjson.encode(extraParam))
	-- 				local data = {s=extraParam['ID'][1],t=extraParam['TIMELEN'][1]}
	-- 				if extraParam['PARAM1']~=nil then
	-- 					data['p1'] = extraParam['PARAM1'][1]
	-- 				end
	-- 				if extraParam['PARAM2']~=nil then
	-- 					data['p2'] = extraParam['PARAM2'][1]
	-- 				end
	-- 				if extraParam['PARAM3']~=nil then
	-- 					data['p3'] = extraParam['PARAM3'][1]
	-- 				end
	-- 				v1:addStatusList(data)
	-- 				parameter[k] = nil
	-- 			end
	-- 		end
	-- 		if self.sFind(v,'CLEANSTATUS')~=nil then
	-- 			if v1.subName==extraParam['SUBNAME'][1] then
	-- 				--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v)..' soldierList'..' ext:'..self.cjson.encode(extraParam))
	-- 				v1:removeStatusList(extraParam['ID'][1])
	-- 				parameter[k] = nil
	-- 			end
	-- 		end
	-- 		if self.sFind(v,'CLEANBUFF')~=nil then
	-- 			if extraParam['TEAM']~=nil then
	-- 				if v1.teamOrig==extraParam['TEAM'][1] then
	-- 					--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v)..' soldierList'..' ext:'..self.cjson.encode(extraParam))
	-- 					v1:removeBUff(extraParam['BUFFNAME'][1])
	-- 					parameter[k] = nil
	-- 				end
	-- 			end
	-- 			if extraParam['SUBNAME']~=nil then
	-- 				if v1.subName==extraParam['SUBNAME'][1] then
	-- 					--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v)..' soldierList'..' ext:'..self.cjson.encode(extraParam))
	-- 					v1:removeBUff(extraParam['BUFFNAME'][1])
	-- 					parameter[k] = nil
	-- 				end
	-- 			end
	-- 		end
	-- 		if self.sFind(v,'CLOSE')~=nil then
	-- 			if self.sFind(v,'BLOCK')~=nil then
	-- 				self.map:removeTmpBlockByLine(extraParam['BLOCKID'][1])
	-- 				parameter[k] = nil
	-- 			else
	-- 				if v1.subName==extraParam['SUBNAME'][1] then
	-- 					--self:debuglog('jaylog World3:excuteParam k:'..k..' v:'..self.cjson.encode(v)..' soldierList'..' ext:'..self.cjson.encode(extraParam))
	-- 					v1.attribute.HP = 0
	-- 					v1:directHurt(v1.itemID,1,{},0)
	-- 					parameter[k] = nil
	-- 				end
	-- 			end
	-- 		end
	-- 	end
	-- 	if self.sFind(v,'RUNFUNC')~=nil then
	-- 		local ret = false
	-- 		if self.sFind(v,'TRANSPOSITION')~=nil then
	-- 			--self:debuglog('jaylog World3:excuteParam TRANSPOSITION k:'..k..' v:'..self.cjson.encode(v)..' ext:'..self.cjson.encode(extraParam))
	-- 			ret = self:runTransposition(extraParam['TRANSPOSITIONSET'],extraParam['TRANSPOSITIONORDER'],extraParam['TRANSPOSITIONMOVE'])
	-- 		end
	-- 		if self.sFind(v,'EXTRAFUNC')~=nil then
	-- 			--self:debuglog('jaylog World3:excuteParam EXTRAFUNC k:'..k..' v:'..self.cjson.encode(v)..' ext:'..self.cjson.encode(extraParam))
	-- 			ret = self:runExtraParam()
	-- 		end
	-- 		if ret then
	-- 			parameter[k] = nil
	-- 		end
	-- 	end
	-- end
	-- self:debuglog('jaylog World3:excuteParam ret param:'..self.cjson.encode(parameter))
	-- return parameter
--end

--- 流程方法，按位置排列并移动指定距离
-- @param linePosition table - 位置点集，ex:[{顺序号,x,y},{顺序号,x,y},...]
-- @param lineOrder table - 角色位置顺序，ex:[[roleID,roleID,roleID],[roleID,roleID,roleID]]
-- @param lineMoveDis table - 角色到达位置点集后偏移量，ex:[x,y]
-- @return stepNo int - 执行到的步骤1或2
--function World3:runTransposition(linePosition,lineOrder,lineMoveDis)
	-- -- set line order
	-- local setLineOrder = {}
	-- local itemOrder = {}
	-- if self.itemListFilter.heroList[1].attribute.roleId<6 then
	-- 	setLineOrder = lineOrder[1]
	-- else
	-- 	setLineOrder = lineOrder[2]
	-- end
	-- for k,v in pairs(setLineOrder) do
	-- 	for k1,v1 in pairs(self.itemListFilter.heroList) do
	-- 		if v1.attribute.roleId==v then
	-- 			itemOrder[v1.itemID] = table.nums(itemOrder)+1
	-- 		end
	-- 	end
	-- end
	-- -- start move
	-- if lineMoveDis==nil then
	-- 	for k,v in pairs(linePosition) do
	-- 		for k1,v1 in pairs(self.itemListFilter.heroList) do
	-- 			if itemOrder[v1.itemID]==v[1] then
	-- 				v1:moveTo(v[2],v[3],true,1,99999)
	-- 			end
	-- 		end
	-- 	end
	-- else
	-- 	for k,v in pairs(linePosition) do
	-- 		for k1,v1 in pairs(self.itemListFilter.heroList) do
	-- 			if itemOrder[v1.itemID]==v[1] then
	-- 				v1:moveTo(v[2]+lineMoveDis[1],v[3]+lineMoveDis[2],true,7)
	-- 			end
	-- 		end
	-- 	end
	-- end
	-- return true
--end

function World3:runExtraParam(extraParam)
	if extraParam==nil then
		extraParam = {}
	end
	local pos = extraParam['POSITION']
	for k,v in pairs(self.gameFlag['passTransitDoorID']) do
		local obj = self.allItemList[v]
		obj:addStatusList({s=4008,r=self.gameTime,t=1})
		self:debuglog('jaylog start ready to moveTo itemID:',v,' x:',obj.posX,' y:',obj.posY,' tox:',pos[1],' toy:',pos[2],' lid:',obj.attribute.loginID)
		-- local attributes = {}
		-- attributes['DIZZY_RATE'] = 100
		-- local buff = require("gameroomcore.SBuff").new(self,obj:__skillID2buffID(1),attributes,1,{},0,obj.itemID,obj.itemID)
		-- obj:addBuff(buff)
		local shareObj
		if obj.sharedID>0 and self.allItemList[obj.sharedID]~=nil then
			shareObj = self.allItemList[obj.sharedID]
			obj:moveTo(shareObj.posX,shareObj.posY,true,1,99999)
		else
			obj:moveTo(pos[1],pos[2],true,1,99999)
		end
		
		-- obj:removeBUff('SLEEP')
		-- obj:removeBUff('DIZZY')
		obj:removeStatusList(4010)
		debuglog('jaylog part 2 shareObj: objID'..obj.itemID..' shareObjID:'..obj.sharedID)
		if obj.sharedID>0 and self.allItemList[obj.sharedID]~=nil then
			shareObj:setShared(0)
			shareObj:addStatusList({s=42,r=self:getGameTime(),t=999},0)
			shareObj.attribute.HP = 0
			shareObj:directHurt(self.itemID,1,{},0)
		end
		if obj.sharedID>0 then
			obj:setShared(0)
		end
		obj.inTransitDoor = false
	end
	self.gameFlag['passTransitDoorNum'] = 0
	self.gameFlag['passTransitDoorID'] = {}
	return true
end

--function World3:excuteFlow()
	-- --if self.partFinishTime<self.gameTime then
	-- 	local flowCond
	-- 	if self.bossFlow[self.partType]~=nil then
	-- 		flowCond = self.bossFlow[self.partType][self.partSubType]
	-- 	end
	-- 	local condition
	-- 	if flowCond~=nil then
	-- 		condition = flowCond['condition']
	-- 		extraCondition = flowCond['extraCondition']
	-- 	end
	-- 	--self:debuglog('jaylog World3:excuteFlow cond:'..self.cjson.encode(flowCond))
	-- 	if condition~=nil then
	-- 		if self.partFinish then
	-- 			local ret = self:checkCondition(condition,extraCondition)
	-- 			if ret then
	-- 				self:debuglog('jaylog World3:excuteFlow checkCondition ok '..self.partStartTime..' '..self.gameTime..' '..self.cjson.encode(self.partFinish))
	-- 				self.partStartTime = self.gameTime + flowCond['delay']
	-- 				self.partFinish = false
	-- 			end
	-- 		end
	-- 		if self.partStartTime<self.gameTime and (not self.partFinish) then
	-- 			local parameter = flowCond['parameter']
	-- 			local extraParam = flowCond['extraParam']
	-- 			self.bossFlow[self.partType][self.partSubType]['parameter'] = self:excuteParam(parameter,extraParam)
	-- 			self:debuglog('jaylog World3:excuteFlow start excuteParam:'..self.partStartTime..' '..self.cjson.encode(parameter)..' '..self.cjson.encode(extraParam))
	-- 			if self.tNums(self.bossFlow[self.partType][self.partSubType]['parameter'])==0 then
	-- 				self.partType = flowCond['nextPart']
	-- 				self.partSubType = flowCond['nextStep']
	-- 				self.partFinish = true
	-- 			end
	-- 		end
	-- 	end
	-- --end
--end

--function World3:paramAddStatus(itemID,status,timelen,param1,param2,param3)
	-- local data = {s=status[1],t=extraParam['TIMELEN'][1]}
	-- if param1~=nil then
	-- 	data['p1'] = param1[1]
	-- end
	-- if param2~=nil then
	-- 	data['p2'] = param2[1]
	-- end
	-- if param3~=nil then
	-- 	data['p3'] = param3[1]
	-- end
	-- self.allItemList[itemID]:addStatusList(data)
--end

--- RUNNING 遊戲loop
-- @return null
function World3:statusRUNNING()
	World3.super.statusRUNNING(self)
	for k,v in pairs(self.itemListFilter.heroList) do
		if v.sharedID>0 and v.attribute.actorType==0 and v.statusList[4007]~=nil then
			--print('jaylog moveTo shareObj: lastMoveTime',v.lastMoveTime,' gameTime:',self.gameTime)
			--if (self.gameTime-v.lastMoveTime)>2 then
			--self:debuglog('jaylog moveTo shareObj ',v.outOfCtlTime)
			if (self.gameTime-v.lastControlTime)>4 then
				local shareObj = self.allItemList[v.sharedID]
				if shareObj~=nil then
					v:moveTo(shareObj.posX,shareObj.posY,false,10)
				end
			end
		end
	end
end

function World3:gameOverCheck()
	local ret = World3.super.gameOverCheck(self)
	if ret and self.gameFlag['isGameOver'] then
		self.gameFlag['winTeam'] = 'A'
	end
	local deadNum = 0
	if not ret and self.tNums(self.playerList)>0 then
		for k,v in pairs(self.itemListFilter.heroList) do
			if v.teamOrig=='A' and v:isDead() then
				deadNum = deadNum + 1
			end
		end
		if deadNum==table.nums(self.playerList) then
			ret = true
		end
	end
	return ret
end

function World3:statusRUNNINGorg()
	-- -- if self.status~=self.GAMEOVER and self.bossObj1~=nil and self.bossObj3~=nil and self.bossObj1.attribute.HP<=0 and self.bossObj3.attribute.HP<=0 then
	-- --   self:gameOver()
	-- --   return nil
	-- -- end
	-- if self.gameTime>10 and self.gameTime<11 then
	-- 	self.bossObj1:addStatusList({s=10001,r=self.gameTime,t=99999,i=self.bossObj1.itemID})
	-- end

	-- --debuglog('jaylog now partType is '..self.partType..' '..self.bossObj1.itemID)--..' wt:'..self.partWaitTime..' gt:'..self.gameTime..' '..self.bossObj1.attribute.HP..' '..(self.bossObj1.attribute.MaxHP*0.5))
	-- if self.status~=self.GAMEOVER and self.partType==1 and self.partWaitTime==0 and self.bossObj1~=nil and self.bossObj1.attribute.HP<=(self.bossObj1.attribute.MaxHP*self.tonumber(self.bossObj1.attribute.parameterArr['P2HP'])*0.01) then
	-- --if self.gameTime>30 and self.status~=self.GAMEOVER and self.partType==1 and self.partWaitTime==0 and self.bossObj1~=nil then
	-- 	--debuglog('jaylog now partType is '..self.partType..' ready to partType '..(self.partType+1)..' '..self.bossObj1.attribute.HP..' '..self.bossObj1.itemID..' runAI:'..self.cjson.encode(self.bossObj1.autoFightAI.runAI)..' p2Delay:'..self.cjson.encode(self.skillDelayTime))
	-- 	if self.bossObj1.autoFightAI.runAI==true then
	-- 		self.bossObj1.skinNum = 3
	-- 		local result = self.bossObj1:getAllInfo()
	-- 		self.bossObj1:updateSyncMsg({i=result})
	-- 		debuglog('jaylog part 1 to 2 sync boss 1 msg:'..self.cjson.encode(result))
	-- 		self.partStartTime = self.gameTime
	-- 		--debuglog('jaylog now set AI not run '..self.partStartTime)
	-- 		self.bossObj1.autoFightAI.runAI = false
	-- 		self.bossObj1.autoFightAI.runMoveAI = false
	-- 		for k,v in pairs(self.itemListFilter.soldierList) do
	-- 			v.autoFightAI.runAI = false
	-- 		end
	-- 	end
	-- 	if self.bossObj1.attackTarget==nil then
	-- 		local attackID = 1
	-- 	else
	-- 		local attackID = self.bossObj1.attackTarget
	-- 	end
	-- 	--debuglog('jaylog now lastCoolDownTime:'..self.bossObj1.lastCoolDownTime)
	-- 	if self.onlyOneOne==nil then
	-- 		self.onlyOneOne = 0
	-- 	else
	-- 		if self.bossObj1.lastCoolDownTime<=self.gameTime and self.preSkill==0 then
	-- 	--if self.partStartTime+self.skillDelayTime[1]<=self.gameTime and self.preSkill==0 then
	-- 		--self.partStartTime = self.partStartTime + self.skillDelayTime[1]
	-- 			local m2 = self.bossObj1:skillAttack(2,self.bossObj1.itemID)
	-- 			debuglog('jaylog part 1 finish mode 2 '..self.cjson.encode(m2))
	-- 			self.preSkill = 2
	-- 		end
	-- 	end
	-- 	if self.bossObj1.lastCoolDownTime+self.skillDelayTime[self.partType][1]<=self.gameTime and self.preSkill==2 then
	-- 		local pos = string.splitNumber(self.setting['bossID'],',')
	-- 		self.bossObj1:moveTo(pos[1],pos[2])
	-- 		self.partStartTime = self.bossObj1.lastCoolDownTime + self.skillDelayTime[self.partType][1]
	-- 		self.preSkill = 3
	-- 		if #self.bossObj1.paths>0 then
	-- 			debuglog('jaylog partType 1 to 2 moveTo paths:'..(#self.bossObj1.paths)..' pathsT:'..self.bossObj1.paths[#self.bossObj1.paths].t..' gameTime:'..self.gameTime)
	-- 			self.preSkillWaitTime = self.bossObj1.paths[#self.bossObj1.paths].t - self.gameTime
	-- 		end
	-- 		if self.preSkillWaitTime==0 then
	-- 			self.preSkillWaitTime = 0.2
	-- 		end
	-- 		--debuglog('jaylog finish mode 3 '..self.preSkillWaitTime)
	-- 	end
	-- 	if self.preSkill==3 and self.bossObj1.lastCoolDownTime+self.skillDelayTime[self.partType][1]+self.preSkillWaitTime<=self.gameTime then
	-- 		local pos = string.splitNumber(self.setting['bossID'],',')
	-- 		self.bossObj1:moveTo(pos[1],(pos[2]+1))
	-- 		self.preSkill = 31
	-- 		self.preSkillWaitTime = 0
	-- 		if #self.bossObj1.paths>0 then
	-- 			self.preSkillWaitTime = self.bossObj1.paths[#self.bossObj1.paths].t - self.gameTime
	-- 		end
	-- 		--debuglog('jaylog finish mode 3 lc:'..self.bossObj1.lastCoolDownTime..' sd:'..self.skillDelayTime[self.partType][2]..' gt:'..self.gameTime)
	-- 	end
	-- 	if self.bossObj1.lastCoolDownTime+self.skillDelayTime[self.partType][1]+self.skillDelayTime[self.partType][2]+self.preSkillWaitTime<=self.gameTime and self.preSkill==31 then
	-- 		local m9 = self.bossObj1:skillAttack(9,self.bossObj1.itemID)
	-- 		self.partStartTime = self.bossObj1.lastCoolDownTime + self.skillDelayTime[self.partType][2]
	-- 		debuglog('jaylog part 1 finish mode 9 '..self.cjson.encode(m9))
	-- 		if m9~=nil then
	-- 			self.preSkill = 9
	-- 		end
	-- 	end
	-- 	if self.preSkill==9 and self.bossObj1.lastCoolDownTime<=self.gameTime then
	-- 		local pos = string.splitNumber(self.setting['bossID'],',')
	-- 		self.bossObj1:moveTo(pos[1],(pos[2]+1))
	-- 		self.preSkill = 10
	-- 		self.preSkillWaitTime = 0
	-- 		if #self.bossObj1.paths>0 then
	-- 			self.preSkillWaitTime = self.bossObj1.paths[#self.bossObj1.paths].t - self.gameTime
	-- 		end
	-- 		--debuglog('jaylog finish mode 3 lc:'..self.bossObj1.lastCoolDownTime..' sd:'..self.skillDelayTime[self.partType][2]..' gt:'..self.gameTime)
	-- 	end
	-- 	if self.bossObj1.lastCoolDownTime+self.skillDelayTime[self.partType][3]+self.preSkillWaitTime<=self.gameTime and self.preSkill==10 then
	-- 		local m8 = self.bossObj1:skillAttack(8,self.bossObj1.itemID)
	-- 		debuglog('jaylog part 1 finish mode 8 '..self.cjson.encode(m8))
	-- 		if m8~=nil then
	-- 			self.preSkill = 8
	-- 			self.bossObj1:addStatusList({s=41,r=self.gameTime,t=9999,i=self.bossObj1.itemID}) 
	-- 		end
	-- 	end
	-- 	if self.preSkill==8 then
	-- 		--self.partType = 1
	-- 		self.bossObj1.attribute.partType = 2
	-- 		self.bossObj1.attribute.partTypeStartTime = self.gameTime
	-- 		if self.bossObj2~=nil then
	-- 			self.bossObj2.attribute.partType = 2
	-- 			self.bossObj2.attribute.partTypeStartTime = self.gameTime
	-- 			for k,v in pairs(self.bossObj2.statusList) do
	-- 				debuglog('jaylog bossObj2 statusList status:'..k..' st:'..self.cjson.encode(v))
	-- 			end
	-- 		end
	-- 		self.bossObj1.changePartHP = self.bossObj1.attribute.MaxHP * 0.15
	-- 		self.bossObj2.changePartHP = self.bossObj2.attribute.MaxHP * 0.15
	-- 		self.partWaitTime = self.gameTime + 3
	-- 		--self:addSyncMsg({game={stage=self.worldNum,bossID=1001,step=self.partType}})
	-- 		self.canChangePart = false
	-- 		for k,v in pairs(self.bossObj1.statusList) do
	-- 			debuglog('jaylog bossObj1 statusList status:'..k..' st:'..self.cjson.encode(v))
	-- 		end
	-- 	end
	-- end

	-- if self.status~=self.GAMEOVER and self.partType==1 and self.partWaitTime~=0 and self.partWaitTime<=self.gameTime then
	-- 	--debuglog('jaylog partType 1 to 2 sleep off')
	-- 	for k,v in pairs(self.itemListFilter.teamA) do
	-- 		v:removeBUff('SLEEP')
	-- 		v:removeBUff('DIZZY')
	-- 	end
	-- 	self.bossObj1.autoFightAI.runAI = true
	-- 	self.bossObj1.autoFightAI.runMoveAI = true
	-- 	for k,v in pairs(self.itemListFilter.soldierList) do
	-- 		v.autoFightAI.runAI = true
	-- 	end
	-- 	self.partType = 2
	-- end

	-- if self.status~=self.GAMEOVER and self.partType==2 and self.partSubType==0 and self.bossObj2~=nil and self.bossObj2.attribute.HP<=(self.bossObj2.attribute.MaxHP*self.tonumber(self.bossObj1.attribute.parameterArr['P2BHP'])*0.01) then
	-- 	--self.partWaitTime = self.gameTime + 1
	-- 	if self.bossObj2.autoFightAI.runAI==true then
	-- 		self.bossObj2.autoFightAI.runAI = false
	-- 		self.bossObj2.autoFightAI.runMoveAI = false
	-- 		for k,v in pairs(self.itemListFilter.soldierList) do
	-- 			v.autoFightAI.runAI = false
	-- 		end
	-- 	end
	-- 	--if self.partWaitTime<=self.gameTime then
	-- 		self.bossObj1:removeBUff('INVICINBLE')
	-- 		self.bossObj1:removeStatusList(41)
	-- 		--self.allItemList[202]:goToDead(self.allItemList[202].itemID,1,0)
	-- 		if self.allItemList[self.transitDoor.itemID]~=nil then
	-- 			self.transitDoor:addStatusList({s=42,r=self:getGameTime(),t=999},0)
	-- 			self.transitDoor.attribute.HP = 0
	-- 			self.transitDoor:directHurt(self.transitDoor.itemID,1,{},0)
	-- 		end
	-- 		if self.bossObj2.lastCoolDownTime<=self.gameTime and self.preSkill==8 then
	-- 			local m2 = self.bossObj2:skillAttack(2,self.bossObj2.itemID)
	-- 			if m2~=nil then
	-- 				self.bossObj2:addStatusList({s=41,r=self.gameTime,t=9999,i=self.bossObj2.itemID},(self.bossObj2.lastCoolDownTime-self.gameTime)+0.5)
	-- 				debuglog('jaylog part 2 finish mode 2 '..self.cjson.encode(m2))
	-- 				self.preSkill = 82
	-- 			end
	-- 		end
	-- 		-- if self.bossObj2.lastCoolDownTime+0.5<=self.gameTime and self.preSkill==81 then
	-- 		-- 	self.bossObj2:addStatusList({s=41,r=self.gameTime,t=9999,i=self.bossObj2.itemID})
	-- 		-- 	self.preSkill = 82
	-- 		-- end
	-- 		if self.bossObj2.lastCoolDownTime+3.5<=self.gameTime and self.preSkill==82 then
	-- 			local pos = string.splitNumber(self.setting['p2SendBackPos'],',')
	-- 			for k,v in pairs(self.gameFlag['passTransitDoorID']) do
	-- 				local obj = self.allItemList[v]
	-- 				obj:addStatusList({s=4008,r=self.gameTime,t=1})
	-- 				debuglog('jaylog start ready to moveTo itemID:'..v..' x:'..obj.posX..' y:'..obj.posY..' tox:'..pos[1]..' toy:'..pos[2])
	-- 				local attributes = {}
	-- 				attributes['DIZZY_RATE'] = 100
	-- 				local buff = require("gameroomcore.SBuff").new(self,obj:__skillID2buffID(1),attributes,1,{},0,obj.itemID,obj.itemID)
	-- 				obj:addBuff(buff)
	-- 				obj:moveTo(pos[1],pos[2],true,1,99999)
	-- 				obj:removeBUff('SLEEP')
	-- 				obj:removeBUff('DIZZY')
	-- 				obj:removeStatusList(4010)
	-- 				debuglog('jaylog part 2 shareObj: objID'..obj.itemID..' shareObjID:'..obj.sharedID)
	-- 				self.bossObj1.changePartHP = self.bossObj1.attribute.MaxHP * 0.1
	-- 				self.bossObj2.changePartHP = self.bossObj1.attribute.MaxHP * 0.1
	-- 				if obj.sharedID>0 and self.allItemList[obj.sharedID]~=nil then
	-- 					local shareObj = self.allItemList[obj.sharedID]
	-- 					shareObj:setShared(0)
	-- 					shareObj:addStatusList({s=42,r=self:getGameTime(),t=999},0)
	-- 					shareObj.attribute.HP = 0
	-- 					shareObj:directHurt(self.itemID,1,{},0)
	-- 				end
	-- 				if obj.sharedID>0 then
	-- 					obj:setShared(0)
	-- 				end
	-- 				obj.inTransitDoor = false
	-- 			end
	-- 			self.gameFlag['passTransitDoorNum'] = 0
	-- 			self.gameFlag['passTransitDoorID'] = {}
	-- 			for k,v in pairs(self.itemListFilter.soldierList) do
	-- 				v.autoFightAI.runAI = true
	-- 			end
	-- 			self.preSkill = 83
	-- 			self.partSubType = 21      --第2和第3阶段的中间阶段
	-- 		end
	-- 	--end
	-- end

	-- if self.status~=self.GAMEOVER and self.partSubType==21 and self.bossObj1~=nil and self.bossObj1.attribute.HP<=(self.bossObj1.attribute.MaxHP*self.tonumber(self.bossObj1.attribute.parameterArr['P3HP'])*0.01) then
	-- 	--debuglog('jaylog now partType is '..self.partType..' ready to partType '..(self.partType+1)..' '..self.itemListFilter.teamB[101].attribute.HP..' '..self.itemListFilter.teamB[101].itemID)
	-- 	if self.bossObj1.autoFightAI.runAI then
	-- 		self.bossObj1.autoFightAI.runAI = false
	-- 		self.bossObj1.autoFightAI.runMoveAI = false
	-- 		for k,v in pairs(self.itemListFilter.soldierList) do
	-- 			v.autoFightAI.runAI = false
	-- 		end
	-- 	end
	-- 	if self.onlyOneOneOne==nil then
	-- 		self.onlyOneOneOne = 0
	-- 	else
	-- 		if self.bossObj1.lastCoolDownTime<=self.gameTime and self.preSkill==83 then
	-- 	--if self.partStartTime+self.skillDelayTime[1]<=self.gameTime and self.preSkill==0 then
	-- 		--self.partStartTime = self.partStartTime + self.skillDelayTime[1]
	-- 			local m2 = self.bossObj1:skillAttack(2,self.bossObj1.itemID)
	-- 			if m2~=nil then
	-- 				debuglog('jaylog finish mode 2 '..self.cjson.encode(m2)..' gameTime:'..self.gameTime)
	-- 				self.preSkill = 22
	-- 			end
	-- 		end
	-- 	end
	-- 	if self.bossObj1.lastCoolDownTime+self.skillDelayTime[self.partType][1]<=self.gameTime and self.preSkill==22 then
	-- 		debuglog('jaylog finish mode 23 addStatusList '..' gameTime:'..self.gameTime)
	-- 		self.bossObj1:addStatusList({s=41,r=self.gameTime,t=self.bossObj1.attribute.skills[12].parameters.CHANTTIME,i=self.bossObj1.itemID})
	-- 		self.preSkill = 23
	-- 	end
	-- 	if self.bossObj1.lastCoolDownTime+self.skillDelayTime[self.partType][1]+self.bossObj1.attribute.skills[12].parameters.CHANTTIME<=self.gameTime and self.preSkill==23 then
	-- 		local m12 = self.bossObj1:skillAttack(12,self.bossObj1.itemID)
	-- 		if m12~=nil then
	-- 			debuglog('jaylog finish mode 12 '..self.cjson.encode(m12)..' gameTime:'..self.gameTime)
	-- 			--镜头定目标
	-- 			self.bossObj3:addStatusList({s=10005,r=self.gameTime,t=self.tonumber(self.setting['setP3DreambodyLenTime']),p1=self.tonumber(self.setting['setP3DreambodyCameraModeID'])})
	-- 			self.preSkill = 12
	-- 		end
	-- 	end
	-- 	if self.bossObj1.lastCoolDownTime+self.skillDelayTime[self.partType][3]<=self.gameTime and self.preSkill==12 then
	-- 		debuglog('jaylog partType 2 to 3 sleep off')
	-- 		for k,v in pairs(self.itemListFilter.teamA) do
	-- 			v:removeBUff('SLEEP')
	-- 			v:removeBUff('DIZZY')
	-- 		end
	-- 		self.partType = 3
	-- 		self.partSubType = 99
	-- 		self.bossObj1.attribute.partType = 3
	-- 		self.bossObj1.attribute.partTypeStartTime = self.gameTime
	-- 		if self.bossObj3~=nil then
	-- 			self.bossObj3.attribute.partType = 3
	-- 			self.bossObj3.attribute.partTypeStartTime = self.gameTime
	-- 			self.bossObj3:syncStatus()
	-- 			for k,v in pairs(self.bossObj3.statusList) do
	-- 				debuglog('jaylog bossObj3 statusList status:'..k..' st:'..self.cjson.encode(v))
	-- 			end
	-- 		end
	-- 		self.partWaitTime = self.gameTime + 3
	-- 		--self:addSyncMsg({game={stage=self.worldNum,bossID=1001,step=self.partType}})
	-- 		self.bossObj1.autoFightAI.runAI = true
	-- 		self.bossObj1.autoFightAI.runMoveAI = true
	-- 		self.bossObj1.changePartHP = 0
	-- 		self.bossObj2.changePartHP = 0
	-- 		for k,v in pairs(self.itemListFilter.soldierList) do
	-- 			v.autoFightAI.runAI = true
	-- 		end
	-- 	end
	-- end

	-- -- normal step --
	-- --if self.partWaitTime<=self.gameTime then
	-- 	if self.status~=self.GAMEOVER and self.bossObj1~=nil and self.bossObj3~=nil and self.bossObj1.attribute.HP<=0 and self.bossObj3.attribute.HP<=0 then
	-- 		if self.onlyOne~=nil then
	-- 			debuglog('jaylog GAMEOVER boss3 dead')
	-- 			self.gameFlag['isWin'] = 1
	-- 			self:gameOver()
	-- 			return nil
	-- 		end
	-- 		self.onlyOne = 0
	-- 	end

	-- 	if self.status~=self.GAMEOVER and self.gameRoomSetting['gameLimitedTime']<=self:getGameTime() then
	-- 		debuglog('jaylog GAMEOVER limitTime')
	-- 		self:gameOver()
	-- 		return nil
	-- 	end

	-- 	self:moveCalculation()

	-- 	for k,v in pairs(self.itemListFilter.soldierList) do
	-- 		if self.forceUpdateSoldier then
	-- 				v.dirty = true
	-- 		end
	-- 		v:syncInfo()
	-- 		if not v:isDead() then
	-- 			v:move()
	-- 		end
	-- 	end

	-- 	for k,v in pairs(self.itemListFilter.npcList) do
	-- 		if self.forceUpdateSoldier then
	-- 				v.dirty = true
	-- 		end
	-- 		v:syncInfo()
	-- 		if not v:isDead() then
	-- 			v:move()
	-- 		end
	-- 	end

	-- 	for k,v in pairs(self.itemListFilter.noBeFightList) do
	-- 		if self.forceUpdateSoldier then
	-- 				v.dirty = true
	-- 		end
	-- 		v:syncInfo()
	-- 		if not v:isDead() then
	-- 			v:move()
	-- 		end
	-- 	end

	-- 	for k,v in pairs(self.itemListFilter.heroList) do
	-- 		if self.forceUpdate then
	-- 			v.dirty = true
	-- 		end
	-- 		v:syncInfo()
	-- 		if not v:isDead() then
	-- 			v:move()
	-- 			if (self.partWaitTime>self.gameTime or self.gameFlag['allStopMove']) and v.attribute.actorType==0 then
	-- 				if self.gameFlag['allStopMove'] then
	-- 					--debuglog('jaylog preInCam:'..v.preInCam..' setLinePosition:'..self.cjson.encode(self.gameRoomSetting['setLinePosition']))
	-- 					if v.preInCam==0 then
	-- 						self:genLineOrder()
	-- 						v:setOutOfCtlAllTime(self.gameTime + self.gameRoomSetting['setLineLenTime'])
	-- 						v:moveTo(self.gameRoomSetting['setLinePosition'][self.lineOrder[v.itemID]]['x'],self.gameRoomSetting['setLinePosition'][self.lineOrder[v.itemID]]['y'],true,1,99999)
	-- 						v.inCamTime = self.gameTime + 1
	-- 						v.preInCam = 1
	-- 						--debuglog('jaylog preInCam:'..v.preInCam..' inCamTime:'..v.inCamTime..' paths:'..self.cjson.encode(v.paths))
	-- 					end
	-- 					if v.preInCam==1 and v.inCamTime<self.gameTime then
	-- 						self:genLineOrder()
	-- 						--debuglog('jaylog itemID:'..v.itemID..' preInCam:'..v.preInCam..' inCamTime:'..v.inCamTime..' x:'..v.posX..' y:'..v.posY..' tox:'..self.gameRoomSetting['setLinePosition'][self.lineOrder[v.itemID]]['x']+self.gameRoomSetting['setLineMoveDis'][1]..' toy:'..self.gameRoomSetting['setLinePosition'][self.lineOrder[v.itemID]]['y']+self.gameRoomSetting['setLineMoveDis'][2])
	-- 						v:moveTo(self.gameRoomSetting['setLinePosition'][self.lineOrder[v.itemID]]['x']+self.gameRoomSetting['setLineMoveDis'][1],self.gameRoomSetting['setLinePosition'][self.lineOrder[v.itemID]]['y']+self.gameRoomSetting['setLineMoveDis'][2],true,7)
	-- 						v.inCamTime = self.gameTime + self.gameRoomSetting['setLineLenTime']
	-- 						v.preInCam = 2
	-- 					end
	-- 					if v.preInCam==2 and v.inCamTime<self.gameTime then
	-- 						self.gameFlag['allStopMove'] = false
	-- 						self.gameFlag['inCamEnd'] = true
	-- 						for k,v in pairs(self.itemListFilter.soldierList) do
	-- 							v.autoFightAI.runAI = true
	-- 						end
	-- 					end
	-- 				end
	-- 			else
	-- 				if v.autoMove then
	-- 					local path = v.movePath[""..self.mapModel]
	-- 					v:moveTo(path['toX'],path['toY'])
	-- 				elseif v.autoFollow then
	-- 					local x,y = 0,0
	-- 					local targetObj = self.allItemList[v.autoFollowTargetID]
	-- 					if targetObj==nil then
	-- 						v:setAutoFollow()
	-- 					else	
	-- 						local len = self.setting['followStopRange']/self.setting['AdjustVisRange']
	-- 						local dist = self.setting['autoFollowRange']/self.setting['AdjustVisRange']
	-- 						if v:distance(targetObj.posX,targetObj.posY,v.autoFollowTargetID)>dist and v.autoFollowTime<self.gameTime then
	-- 							x = v.posX - targetObj.posX
	-- 							y = v.posY - targetObj.posY
	-- 							if x<0 then
	-- 								x = targetObj.posX-len
	-- 							elseif x==0 then
	-- 								x = targetObj.posX
	-- 							else
	-- 								x = targetObj.posX+len
	-- 							end
	-- 							if y<0 then
	-- 								y = targetObj.posY-len
	-- 							elseif y==0 then
	-- 								y = targetObj.posY
	-- 							else
	-- 								y = targetObj.posY+len
	-- 							end
	-- 							v:moveTo(x,y)
	-- 							v.autoFollowTime = self.gameTime + 1
	-- 						end
	-- 					end
	-- 				elseif v.sharedID>0 and v.attribute.actorType==0 and v.statusList[4007]~=nil then
	-- 					--print('jaylog moveTo shareObj: lastMoveTime',v.lastMoveTime,' gameTime:',self.gameTime)
	-- 					if (self.gameTime-v.lastMoveTime)>2 then
	-- 						local shareObj = self.allItemList[v.sharedID]
	-- 						if shareObj~=nil then
	-- 							v:moveTo(shareObj.posX,shareObj.posY)
	-- 						end
	-- 					end
	-- 				end
	-- 				if self.gameFlag['inCamEnd']==false and self.gameFlag['allStopMove']==false and self.gameRoomSetting['setLineSwitch'][1]<v.posX and v.posX<self.gameRoomSetting['setLineSwitch'][2] and self.gameRoomSetting['setLineSwitch'][3]<v.posY and v.posY<self.gameRoomSetting['setLineSwitch'][4] then
	-- 					--debuglog('jaylog setLineSwitch x:'..v.posX..' x:'..self.cjson.encode(self.gameRoomSetting['setLineSwitch'])..' y:'..v.posY)
	-- 					self:genLineOrder()
	-- 					self.gameFlag['allStopMove'] = true
	-- 					for k,v in pairs(self.itemListFilter.soldierList) do
	-- 						v.autoFightAI.runAI = false
	-- 					end
	-- 					--镜头定目标
	-- 					self.camObj:addStatusList({s=10005,r=self.gameTime,t=self.tonumber(self.gameRoomSetting['setLineLenTime']),p1=self.tonumber(self.setting['setLineCameraModeID'])})
	-- 				end
	-- 			end
	-- 		end
	-- 	end

	-- 	-- hero fight loop
	-- 	self.deadNum = 0
	-- 	for k,v in pairs(self.itemListFilter.heroList) do
	-- 		if not v:isDead() then
	-- 			if self.partWaitTime>self.gameTime and v.attribute.actorType==0 then
	-- 			else
	-- 				v:fight()
	-- 			end
	-- 		else
	-- 			if v.attribute.actorType==2 and self.partType==3 then
	-- 				if v.coexistID~=nil and v.coexistID>0 and self.allItemList[v.coexistID]~=nil and not self.allItemList[v.coexistID]:isDead() then
	-- 					debuglog('jaylog now call skill 13 revive boss '..v.coexistID..' '..v.itemID..' '..v.coexistRevivetTime..' isDead:'..self.cjson.encode(v:isDead())..' status:'..v.status)
	-- 					local shareObj = self.allItemList[v.coexistID]
	-- 					debuglog('jaylog coexTime:'..shareObj.coexistRevivetTime..' gameTime:'..self.gameTime..' lastCoolDownTime:'..shareObj.lastCoolDownTime)
	-- 					if shareObj.lastCoolDownTime<=self:getGameTime() then
	-- 						print('jaylog real call skill 13 ',self.cjson.encode(shareObj.buffList[shareObj:__skillID2buffID(13,0)]))
	-- 						if shareObj.buffList[shareObj:__skillID2buffID(13,0)]==nil then
	-- 							debuglog('jaylog real start call skill 13')
	-- 							shareObj:skillAttack(13,v.itemID)
	-- 						end
	-- 					end
	-- 				end
	-- 				v:revive()
	-- 			end
	-- 			if v.teamOrig=='A' then
	-- 				--debuglog('jaylog dead hero: '..v.itemID..' '..v.attribute.roleId)
	-- 				self.deadNum = self.deadNum + 1
	-- 			end
	-- 		end
	-- 	end

	-- 	if self.deadNum==table.nums(self.playerList) then
	-- 		debuglog('jaylog all player dead')
	-- 		self:gameOver()
	-- 		return nil
	-- 	end

	-- 	-- soldier fight loop
	-- 	local killID = 0
	-- 	for k,v in pairs(self.itemListFilter.soldierList) do
	-- 		if not v:isDead() then
	-- 			v:fight()
	-- 		end
	-- 	end

	-- 	for k,v in pairs(self.itemListFilter.npcList) do
	-- 		if not v:isDead() then
	-- 			v:fight()
	-- 		end
	-- 	end

	-- 	for k,v in pairs(self.itemListFilter.noBeFightList) do
	-- 		if not v:isDead() then
	-- 			v:fight()
	-- 		end
	-- 	end

	-- 	self:bulletFight()

	-- 	self:syncItemMsgAndremoveItem()

	-- --end


	-- -- check any player still in gameroom or not .. if no one here .. exit game
	-- local allLeft = true
	-- for i=1,self.gameRoomSetting['maxPlayer'] do
	-- 	if self.playerList[i]~=nil and (self.playerList[i]['online']==nil or self.playerList[i]['online']) then
	-- 		allLeft = false
	-- 	end
	-- end

	-- if not allLeft then
	-- 	self.waitQuit = -1
	-- elseif self.waitQuit<0 then
	-- 	debuglog('waitQuit add 60')
	-- 	self.waitQuit = self:getGameTime()+60
	-- elseif self.waitQuit<self:getGameTime() then
	-- 	self:gameOver()
	-- end
end

function World3:statusREADY()
	World3.super.statusREADY(self)
end

function World3:lotteryNum()
	local idList = {121,201,111}
	for k1,cashID in pairs(idList) do
		for k,v in pairs(self.itemListFilter.teamA) do
			if v.attribute.roleId<11 then
				local rand = self.mCeil(self.formula:getRandnum(1,100))
				if self.lotteryList[""..cashID]==nil then
					self.lotteryList[""..cashID] = {}
				end
				self.lotteryList[""..cashID][""..k] = rand
				if self.lotteryControl[""..cashID]==nil then
					self.lotteryControl[""..cashID] = {}
				end
				self.lotteryControl[""..cashID][""..k] = 0
			end
		end
	end
end

function World3:skipLotteryNum()
	for k,v in pairs(self.lotteryList) do
		for k,v in pairs(table_name) do
			print(k,v)
		end
	end
end

function World3:statusGAMEOVER()
	if (self.gameOverTime<=self.gameTime and self.gameOverWaitTime<=self.gameTime and self.gameOverMsg~=nil) then
		debuglog('jayLog start syn gameOverMsg:'..self.cjson.encode(self.gameOverMsg))
		self:addSyncMsg(self.gameOverMsg)
		self.gameOverWaitTime = self.gameTime + 1
	end

	-- if (self.gameTime==self.gameOverTime+10) then
	--   self:addSyncMsg({game={lotteryNum=self.lotteryList}})
	-- end

	if (self.gameOverTime+10<=self.gameTime) then
		debuglog('jayLog os exit:'..self.cjson.encode(self.gameOverMsg))
		self.gameOverMsg = nil
		os.exit()
	end
end

--- 游戏房结算,结算sql,组织gameOverMsg,call api结算统计
-- @param null
-- @return null
function World3:gameOverOrg()
		-- debuglog("start  gameOver...")
		-- -- new game over step start
		-- local winner = ''
		-- local winarr = {}
		-- local newAPIparameterArray = {}
		-- local bonus = {}
		-- local bonusStr = ''
		-- local tmpbonus = {}
		-- for k,v in pairs(self.itemListFilter.heroList) do
		-- 	if v.actorType==0 then
		-- 		v.counterObj:setCounter("battle_gvb")
		-- 		if self.gameFlag['isWin']==1 then
		-- 			winner = v.teamOrig
		-- 			winarr[""..v.itemID] = 1
		-- 			v.counterObj:setCounter("battle_gvbWin")
		-- 		end
		-- 		v:addApiJobUpdateTask()
		-- 	end
		-- 	if (bonus[""..v.itemID]==nil) then
		-- 		bonus[""..v.itemID] = {}
		-- 	end
		-- 	bonus[""..v.itemID][#bonus[""..v.itemID]+1] = {
		-- 		d=1,
		-- 		i=1,
		-- 		q=1
		-- 	}
		-- end
		-- for kkk,vvv in pairs(bonus) do
		-- 	for kkk2,vvv2 in pairs(vvv) do
		-- 		tmpbonus[#tmpbonus+1]=vvv2['i']..","..vvv2['q']
		-- 	end
		-- end
		-- bonusStr=implode(';',tmpbonus)

		-- local count=0
		-- for i=1,self.gameRoomSetting['maxPlayer'] do
		-- 	if (isset(self.playerList[i])) then
		-- 		count = count + 1
		-- 	end
		-- end

		-- -- save game_result --
		-- local sql = "update game_result set status=1,"
		-- .."starttime='"..os.date("%Y%m%d%H%M%S",(os.time()-math.ceil(self.startTime)))
		-- .."', gametime='"..self.gameTime
		-- .."', endtime='"..os.date("%Y%m%d%H%M%S",os.time())
		-- .."', mapmodel='"..(self.gameModel==10 and 10 or (self.mapSize==9 and 9 or (self.className=="World3" and 3 or (self.className=="World4" and (self.isTeam and 8 or 4) or (self.isTraining and 6 or 1)))))
		-- .."', outcome='"..winner
		-- .."', scoreA='"..self.gameCounter['pointsA']
		-- .."', scoreB='"..self.gameCounter['pointsB']
		-- .."',isSurrender='"..(self.surrenderTeam~="" and 1 or 0)
		-- .."',trySurrender='"..self.trySurrender
		-- .."',peopleCount='"..count
		-- .."' where gameID='"..self.gameID.."'"
		-- debuglog('sql 1 :'..sql)
		-- self:saveDBData(sql)

		-- -- gameScore table --
		-- local gameOverMsgScore = {}
		-- self.gameOverMsg['game']['reset'] = 1
		-- self.gameOverMsg['game']['pointsA'] = self.gameCounter['pointsA']
		-- self.gameOverMsg['game']['pointsB'] = self.gameCounter['pointsB']
		-- self.gameOverMsg['game']['gameTime'] = self.gameTime
		-- self.gameOverMsg['game']['w'] = winarr
		-- self.gameOverMsg['game']['bonus'] = bonusStr

		-- for i=1,self.gameRoomSetting['maxPlayer'] do
		-- 	if (isset(self.playerList[i])) then
		-- 		local StartStr='1'
		-- 		local exp = 0
		-- 		local heroexp = 0
		-- 		local adjGold = 0
		-- 		local penalty = 0
		-- 		local newRank = 0
		-- 		local powreduce = 0
		-- 		local mvpplayerid = 0
		-- 		local point = 0
		-- 		local gold = 0
		-- 		local isWin = self.gameFlag['isWin']
		-- 		local bonusStr = ''
		-- 		local tmpbonus = {}
		-- 		local serverIP=""
		-- 		if (isset(self.playerList[i]['commip'])) then
		-- 			serverIP=self.playerList[i]['commip']
		-- 		end

		-- 		for kkk,vvv in pairs(bonus) do
		-- 			for kkk2,vvv2 in pairs(vvv) do
		-- 				tmpbonus[#tmpbonus+1]=vvv2['i']..","..vvv2['q']
		-- 			end
		-- 		end
		-- 		bonusStr=implode(';',tmpbonus)

		-- 		local newAPIparameter = {
		-- 					start=StartStr,
		-- 					game_id=self.gameID,
		-- 					exp=exp,                --exp+vipexp+itemexp+extraExp
		-- 					silver=gold,              --gold+vipgold+itemgold+mvpgold
		-- 					hero_id=self.playerList[i]['a'],
		-- 					play_win=isWin==1 and 1 or 0,
		-- 					play_lose=isWin==0 and 1 or 0,
		-- 					play_draw=isWin==2 and 1 or 0,
		-- 					penalty=(penalty>0 and 1 or 0),
		-- 					play_hero_kill=self.counter['killhero'],
		-- 					play_assist_kill=0,             --self.counter['killassistant']
		-- 					play_dead=self.counter['killed'],
		-- 					play_pvp=0,
		-- 					play_gvb=1,
		-- 					play_vs_random=(self.gameModel~=nil and self.gameModel==10) and 0 or (gamemode==1 and 1 or 0),
		-- 					play_vs_33=(self.gameModel~=nil and self.gameModel==10) and 0 or (gamemode==2 and 1 or 0),
		-- 					play_vs_ai=gamemode==3 and 1 or 0,
		-- 					play_vs_guild=gamemode==4 and 1 or 0,
		-- 					play_vs_training=(self.gameModel~=nil and self.gameModel==10) and 0 or (gamemode==6 and 1 or 0),
		-- 					play_vs_team=self.isTeam and 1 or 0,
		-- 					play_vs_gambling=(self.gameModel~=nil and self.gameModel==10) and 1 or 0,
		-- 					rank=newRank,
		-- 					play_time=self.gameTime,
		-- 					powreduce=powreduce,
		-- 					mapmodel=self.gameModel,
		-- 					--player_rebirth=self.allItemList[i].counter['revive'],
		-- 					adjGold=0,        --adjGold
		-- 					mvplist=0       --mvpplayerid
		-- 		}
		-- 		newAPIparameterArray[self.sFormat(self.playerList[i]['p'])] = newAPIparameter
		-- 		--debuglog('start to save newAPIparameterArray'..self.cjson.encode(newAPIparameter)..'   '..self.playerList[i]['p']..'  '..self.cjson.encode(newAPIparameterArray))

		-- 		if self.playerList[i]['recnt'] ==nil then
		-- 			self.playerList[i]['recnt'] =0
		-- 		end

		-- 		if self.allItemList[i].team==winner then
		-- 			isWin = 1
		-- 		end

		-- 		--保存每个玩家战斗记录--
		-- 		sql = "insert into game_player_result (updatetime,createtime,gameID,playerID,camp,win,hero,level,equip1,equip2,equip3,equip4,equip5,equip6,equip1stlvl1,equip1stlvl3,"..
		-- 			"Struck,Killed,Assists,KillSoldiers,KillTowers,killMonsters,gold,exp,skill1,skill2,skill3,skill4,skill1st,skillkill1,skillkill2,skillkill3,skillkill4,fastRevive,ipaddr,ping,totalIdle,maxIdle,point,newRank,serverIP,bonus,gamePoint,prizeOperate,mvp,banHero) values (now(),now(),'"..
		-- 			self.gameID.."','"..                                                --gameID
		-- 			self.playerList[i]['p'].."','"..                                    --playerID
		-- 			self.allItemList[i].teamOrig.."','"..                               --camp
		-- 			(isWin).."','"..                                                    --win
		-- 			self.playerList[i]['a'].."','"..                                    --hero roleID
		-- 			self.allItemList[i].attribute.level.."','"..                        --level
		-- 			"','"..                           --equip1
		-- 			"','"..                           --equip2
		-- 			"','"..                           --equip3
		-- 			"','"..                           --equip4
		-- 			"','"..                           --equip5
		-- 			"','"..                           --equip6
		-- 			gold.."','"..                                                       --equip1stlvl1
		-- 			exp.."','"..                                                        --equip1stlvl3
		-- 			self.allItemList[i]:getCounter('killhero').."','"..                 --Struck                    --self.allItemList[i].counter['killhero'].."','"..
		-- 			self.allItemList[i]:getCounter('killed').."','"..                   --Killed                    --self.allItemList[i].counter['killed'].."','"..
		-- 			self.mAbs(self.allItemList[i]:getCounter('hurted')).."','"..        --Assists                   --self.allItemList[i].counter['killassistant'].."','"..
		-- 			self.mAbs(self.allItemList[i]:getCounter('hurt')).."','"..          --KillSoldiers              --self.allItemList[i].counter['killsoldier'].."','"..
		-- 			self.allItemList[i]:getCounter('getFlag').."','"..                  --KillTowers                --self.allItemList[i].counter['killTower']
		-- 			self.mAbs(self.allItemList[i]:getCounter('cure')).."','"..          --killMonsters              --self.allItemList[i].counter['killmonster'].."','"..
		-- 			gold.."','"..                                                       --gold
		-- 			exp.."','"..                                                        --exp
		-- 			"0','"..                                                            --skill1
		-- 			"0','"..                                                            --skill2
		-- 			"0','"..                                                            --skill3
		-- 			"0','"..                                                            --skill4
		-- 			self.playerList[i]['recnt'].."','"..                                --skill1st
		-- 			"0','"..                                                            --skillkill1
		-- 			"0','"..                                                            --skillkill2
		-- 			"0','"..                                                            --skillkill3
		-- 			"0','"..                                                            --skillkill4
		-- 			"0','"..                                                            --fastRevive
		-- 			self.allItemList[i].ipaddress.."','"..                              --ipaddr
		-- 			self.allItemList[i].pingtime.."','"..                               --ping
		-- 			self.allItemList[i].totalIdleTime.."','"..                          --totalIdle
		-- 			self.allItemList[i].maxIdleTime.."','"..                            --maxIdle
		-- 			point.."','"..                                                      --point
		-- 			newRank.."','"..                                                    --newRank
		-- 			serverIP.."','"..                                                   --serverIP
		-- 			bonusStr..                                                          --bonus
		-- 			"','0','"..                                                         --gamePoint
		-- 			(self.allItemList[i].skinNum~=nil and self.allItemList[i].skinNum or 0)..     --prizeOperate
		-- 			"','0','"..                                                                   --mvp
		-- 			i.."')"                                                                     --banHero    玩家房间顺序ID
		-- 		debuglog('sql 2 every player : '..sql)

		-- 		if ( self.tonumber(self.playerList[i]['p']) >0) then
		-- 			self:saveDBData(sql)
		-- 		end
		-- 		debuglog('newAPIparameter : '..self.cjson.encode(newAPIparameter) ..' p: '..self.cjson.encode(self.playerList[i]['p']))
		-- 	end
		-- end
		
		-- --self.gameOverMsg['game']['gameScore'] = gameOverMsgScore
		-- debuglog('gameOverMsg : '..self.cjson.encode(self.gameOverMsg))

		-- self.gameOverStatistic={}
		-- for k,value in pairs(self.itemListFilter.heroList) do
		-- 	self.gameOverStatistic[value.itemID] = {
		-- 		i = value.itemID,
		-- 		killhero = value.counter['killhero'],
		-- 		hilled = value.counter['killed'],
		-- 		hurted = value.counter['hurted'],
		-- 		hurt = value.counter['hurt'],
		-- 		cure = value.counter['cure'],
		-- 		getFlag = value.counter['getFlag'],
		-- 		points = value.counter['points']
		-- 	}
		-- end

		-- --战斗结算call api
		-- local finishapi = self.webapiurl..'internalapi/finishGameRoomMutil'
		-- local finishapi2 = self.webapiurl2..'internalapi/finishGameRoomMutil'
		-- debuglog('newAPIparameterArray...........:' .. self.cjson.encode( newAPIparameterArray ) )
		-- local url=finishapi..'/?data='..string.urlencode(self.cjson.encode(newAPIparameterArray))..'&version=999'
		-- local webresult=self:file_get_contents(url)
		-- if (webresult==false) then
		-- 	url=finishapi2..'/?data='..string.urlencode(self.cjson.encode(newAPIparameterArray))..'&version=999'
		-- 	webresult=self:file_get_contents(url)
		-- end
		-- debuglog('url : '..url..' result:'..webresult)

		-- -- 玩家离开清除房间玩家数据 --
		-- local players={}
		-- for i=1,self.gameRoomSetting['maxPlayer'] do
		-- 	if (isset(self.playerList[i]) and self.playerList[i]['online']==false) then
		-- 		if self.gameRoomSetting['hasMapZone']~=true and (self.tonumber(self.playerList[i]['p'])>0) then
		-- 		self:redisCall('srem','room0',self.playerList[i]['p'])
		-- 		end
		-- 		if (self.tonumber(self.playerList[i]['p'])>12) then
		-- 			rc = {i=0,m=self.playerList[i]['id'].." 离开了房间",t="",d=0}
		-- 			self:addSyncMsg({rc=rc})
		-- 		end
		-- 		--self.playerList[i]=nil
		-- 	elseif (isset(self.playerList[i])) then
		-- 		players[self.playerList[i]['p']]=self.playerList[i]
		-- 		if self.gameRoomSetting['hasMapZone']~=true and (self.tonumber(self.playerList[i]['p'])>0) then
		-- 		self:redisCall('srem','room0',self.playerList[i]['p'])
		-- 		end
		-- 	end
		-- end
		-- for i=91,100 do
		-- 	if self.gameRoomSetting['hasMapZone']~=true and (isset(self.monitorPlayerList[i])) then
		-- 		self:redisCall('srem','room0',self.monitorPlayerList[i]['p'])
		-- 		--self.monitorPlayerList[i]=nil
		-- 	end
		-- end
		-- players['END']=true
		-- self:setPlayerListMemcache(players)
		-- debuglog("有没有call到结束/////////////")
		-- self.gameOverTime = self.gameTime
		-- self.gameOverWaitTime = self.gameTime+5
		-- self.status=self.GAMEOVER


		-- -- new game over step end
end

--- 取野怪起始坐标及组别设置
-- @param null
-- @return null
function World3:genMonsterSetting()
	-- local settingLocal = self.setting
	-- --增加野怪
	-- local list = string.split(settingLocal['enemy1ID'],';')
	-- local randlist = {}
	-- local enemyAllNum = 0
	-- for k,v in pairs(list) do
	-- 	local enemy1IDlist = string.split(v,',')
	-- 	local enemyType = enemy1IDlist[1]
	-- 	local enemyNum = enemy1IDlist[2]
	-- 	enemyAllNum = enemyAllNum + enemyNum
	-- end
	-- local enemy1Typelist = string.split(settingLocal['enemy1Type'],',')
	-- randlist = self.formula:formationPoint(enemyAllNum,enemy1Typelist[3]*0.01)

	-- for k,v in pairs(list) do
	-- 	local enemy1IDlist = string.split(v,',')
	-- 	local enemyType = enemy1IDlist[1]
	-- 	local enemyNum = enemy1IDlist[2]
	-- 	for i=1,enemyNum do
	-- 		--local x,y = self.formula:getRandomCirclePoint(enemy1Typelist[1],enemy1Typelist[2],enemy1Typelist[3]*0.01)
	-- 		local x = randlist[1][1]+enemy1Typelist[1]
	-- 		local y = randlist[1][2]+enemy1Typelist[2]
	-- 		table.remove(randlist,1)
	-- 		self.genMonster[#self.genMonster+1] = {
	-- 			type = enemyType, --self.tonumber(settingLocal['tower'..i..'Type']),
	-- 			time = 60,
	-- 			posX = x,
	-- 			posY = y,
	-- 			--itemID = 0,
	-- 			--last = 0,
	-- 			group = 'A1',
	-- 			team = 'B'
	-- 		}
	-- 	end
	-- 	self.genMonsterGroup['A1'] = 60   --怪物死后刷新时间
	-- 	self.genMonsterGroupLevel['A1'] = 1               --按组设置级别

	-- end

	-- --增加野怪
	-- local list = string.split(settingLocal['enemy2ID'],';')
	-- local randlist = {}
	-- local enemyAllNum = 0
	-- for k,v in pairs(list) do
	-- 	local enemy1IDlist = string.split(v,',')
	-- 	local enemyType = enemy1IDlist[1]
	-- 	local enemyNum = enemy1IDlist[2]
	-- 	enemyAllNum = enemyAllNum + enemyNum
	-- end
	-- local enemy1Typelist = string.split(settingLocal['enemy2Type'],',')
	-- randlist = self.formula:formationPoint(enemyAllNum,enemy1Typelist[3]*0.01)

	-- for k,v in pairs(list) do
	-- 	local enemy1IDlist = string.split(v,',')
	-- 	local enemyType = enemy1IDlist[1]
	-- 	local enemyNum = enemy1IDlist[2]
	-- 	for i=1,enemyNum do
	-- 		--local x,y = self.formula:getRandomCirclePoint(enemy1Typelist[1],enemy1Typelist[2],enemy1Typelist[3]*0.01)
	-- 		local x = randlist[1][1]+enemy1Typelist[1]
	-- 		local y = randlist[1][2]+enemy1Typelist[2]
	-- 		table.remove(randlist,1)
	-- 		self.genMonster[#self.genMonster+1] = {
	-- 			type = enemyType, --self.tonumber(settingLocal['tower'..i..'Type']),
	-- 			time = 60,
	-- 			posX = x,
	-- 			posY = y,
	-- 			--itemID = 0,
	-- 			--last = 0,
	-- 			group = 'A2',
	-- 			team = 'B'
	-- 		}
	-- 	end
	-- 	self.genMonsterGroup['A2'] = 60   --怪物死后刷新时间
	-- 	self.genMonsterGroupLevel['A2'] = 1               --按组设置级别

	-- end

	-- --增加特殊野怪用于定镜头
	-- local list = string.split(settingLocal['enemy3ID'],';')
	-- local enemy3Typelist = string.split(settingLocal['enemy3Type'],',')
	-- for k,v in pairs(list) do
	-- 	local enemy3IDlist = string.split(v,',')
	-- 	local enemyType = enemy3IDlist[1]
	-- 	local enemyNum = enemy3IDlist[2]
	-- 	for i=1,enemyNum do
	-- 		local x = enemy3Typelist[1]
	-- 		local y = enemy3Typelist[2]
	-- 		self.genMonster[#self.genMonster+1] = {
	-- 			type = enemyType, --self.tonumber(settingLocal['tower'..i..'Type']),
	-- 			time = 60,
	-- 			posX = x,
	-- 			posY = y,
	-- 			--itemID = 0,
	-- 			--last = 0,
	-- 			group = 'A3',
	-- 			team = 'B'
	-- 		}
	-- 	end
	-- 	self.genMonsterGroup['A3'] = 99999   --怪物死后刷新时间
	-- 	self.genMonsterGroupLevel['A3'] = 1               --按组设置级别
	-- end

end


function World3:createGVBEnemy()
		for k,v in pairs(self.genMonster) do
			--self:addCreature(v['type'],v['team'],v['posX'],v['posY'],self.bossObj1,1,0.1)
			if self.tonumber(v['type'])==999 then
				local camID = self:addMonster(v['type'],v['posX'],v['posY'],v['group'],1,v['team']) 
				self.camObj = self.allItemList[camID]
				debuglog('jaylog add camObj camId:'..camID..' hp:'..self.camObj.attribute.HP..' x:'..self.camObj.posX..' y:'..self.camObj.posY)
			else
				self:addMonster(v['type'],v['posX'],v['posY'],v['group'],1,v['team'])  
			end
		end  
end

function World3:genLineOrder()
	local setLineOrder = {}
	self.lineOrder = {}
	if self.itemListFilter.heroList[1].attribute.roleId<6 then
		setLineOrder = self.gameRoomSetting['setLineOrder'][1]
	else
		setLineOrder = self.gameRoomSetting['setLineOrder'][2]
	end
	for k,v in pairs(setLineOrder) do
		for k1,v1 in pairs(self.itemListFilter.heroList) do
			if v1.attribute.roleId==v then
				self.lineOrder[v1.itemID] = table.nums(self.lineOrder)+1
			end
		end
	end
	--debuglog('jaylog World3:genLineOrder lineOrder:'..self.cjson.encode(self.lineOrder))
end

return World3

