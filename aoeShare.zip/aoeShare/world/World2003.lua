local World2003 = class("World2003",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World2003:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World2003"
	end

	World2003.super.ctor(self,gamePort,gameID,callBack)
	worldForHero = 2003
end

return World2003

