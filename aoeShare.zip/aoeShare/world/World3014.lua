local World3014 = class("World3014",require("gameroom.WorldBase"))

--- Constructor
-- @param gamePort int - port number / room number
-- @param gameID int - gameID , from DB
-- @param callBack object - callback for some compatiable with client side
-- @return null
function World3014:ctor(gamePort,gameID,callBack)
	if self.className==nil then
		self.className="World3014"
	end

	World3014.super.ctor(self,gamePort,gameID,callBack)
	worldForHero = 0
end

return World3014